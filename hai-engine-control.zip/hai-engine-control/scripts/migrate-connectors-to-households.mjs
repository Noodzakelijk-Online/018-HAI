/**
 * Migration script: Assign existing connectors to users' first household
 * 
 * This script:
 * 1. Finds all connectors without a householdId
 * 2. For each connector's userId, finds their first household
 * 3. Assigns the connector to that household
 * 4. If user has no household, creates one automatically
 */

import { drizzle } from 'drizzle-orm/mysql2';
import { eq, isNull } from 'drizzle-orm';
import { connectors, households, householdMembers } from '../drizzle/schema.ts';
import mysql from 'mysql2/promise';

async function migrateConnectorsToHouseholds() {
  console.log('[Migration] Starting connector household assignment...');
  
  // Create database connection
  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  const db = drizzle(connection);
  
  try {
    // Get all connectors without a householdId
    const orphanedConnectors = await db
      .select()
      .from(connectors)
      .where(isNull(connectors.householdId));
    
    console.log(`[Migration] Found ${orphanedConnectors.length} connectors without household assignment`);
    
    for (const connector of orphanedConnectors) {
      // Find user's first household
      const userHouseholds = await db
        .select({ householdId: householdMembers.householdId })
        .from(householdMembers)
        .where(eq(householdMembers.userId, connector.userId))
        .limit(1);
      
      let targetHouseholdId;
      
      if (userHouseholds.length > 0) {
        // User has a household, use it
        targetHouseholdId = userHouseholds[0].householdId;
        console.log(`[Migration] Connector "${connector.name}" → Household ${targetHouseholdId} (existing)`);
      } else {
        // User has no household, create one
        const [newHousehold] = await db
          .insert(households)
          .values({
            name: `${connector.userId}'s Household`,
          });
        
        targetHouseholdId = newHousehold.insertId;
        
        // Add user as owner
        await db
          .insert(householdMembers)
          .values({
            householdId: targetHouseholdId,
            userId: connector.userId,
            role: 'owner',
          });
        
        console.log(`[Migration] Created household ${targetHouseholdId} for user ${connector.userId}`);
        console.log(`[Migration] Connector "${connector.name}" → Household ${targetHouseholdId} (new)`);
      }
      
      // Assign connector to household
      await db
        .update(connectors)
        .set({ householdId: targetHouseholdId })
        .where(eq(connectors.id, connector.id));
    }
    
    console.log('[Migration] ✅ Connector household assignment complete!');
    
  } catch (error) {
    console.error('[Migration] ❌ Error during migration:', error);
    throw error;
  } finally {
    await connection.end();
  }
}

// Run migration
migrateConnectorsToHouseholds()
  .then(() => {
    console.log('[Migration] Done!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('[Migration] Failed:', error);
    process.exit(1);
  });
