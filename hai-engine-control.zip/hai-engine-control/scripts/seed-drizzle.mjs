import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import { engines, services } from "../drizzle/schema.ts";

const DATABASE_URL = process.env.DATABASE_URL;
const connection = await mysql.createConnection(DATABASE_URL);
const db = drizzle(connection);

const initialEngines = [
  {
    engineId: "hle",
    name: "Household Ledger Engine",
    description: "Event sourcing and audit trail",
    status: "running",
    autonomyLevel: 0,
    priority: "critical",
    dependencies: [],
  },
  {
    engineId: "frontier",
    name: "Frontier Engine",
    description: "Capability discovery and service integration",
    status: "running",
    autonomyLevel: 2,
    priority: "critical",
    dependencies: ["hle", "sme", "policy"],
  },
  {
    engineId: "sme",
    name: "Self-Model Engine",
    description: "Learns user preferences and patterns",
    status: "running",
    autonomyLevel: 0,
    priority: "high",
    dependencies: ["hle"],
  },
  {
    engineId: "policy",
    name: "Policy Engine",
    description: "Enforces user-defined rules",
    status: "running",
    autonomyLevel: 0,
    priority: "high",
    dependencies: ["hle", "sme"],
  },
];

console.log("Seeding engines...");
for (const engine of initialEngines) {
  try {
    await db.insert(engines).values(engine);
    console.log(`✓ ${engine.name}`);
  } catch (e) {
    console.log(`✓ ${engine.name} (already exists)`);
  }
}

await connection.end();
console.log("Done!");
