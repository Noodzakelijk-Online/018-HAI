#!/bin/bash

# Auto-answer drizzle-kit push prompts with "create" option
# This script sends Enter key repeatedly to select the default "create" option

cd /home/ubuntu/hai-engine-control

# Run drizzle-kit push and automatically answer prompts
(
  # Wait a bit for the first prompt
  sleep 3
  
  # Send Enter 200 times (more than enough for all prompts)
  for i in {1..200}; do
    echo ""
    sleep 0.1
  done
) | pnpm drizzle-kit push --verbose 2>&1
