#!/usr/bin/env node

/**
 * Seed Sample Activities
 * 
 * Populates the database with sample autonomous activities for demo/testing.
 */

import mysql from 'mysql2/promise';

const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  console.error('ERROR: DATABASE_URL environment variable is required');
  process.exit(1);
}

const connection = await mysql.createConnection(DATABASE_URL);

// Sample activities
const sampleActivities = [
  // Morning activities
  {
    engine: 'communication',
    action: 'send_email',
    title: 'Sent morning briefing to team',
    description: 'Compiled overnight updates and sent summary email to 12 team members',
    metadata: JSON.stringify({ recipients: 12, attachments: 2 }),
    impact: 'high',
    status: 'completed',
    createdAt: getTodayTime(8, 30),
  },
  {
    engine: 'decision',
    action: 'approve_request',
    title: 'Approved 3 pending requests',
    description: 'Reviewed and approved expense reports, vacation requests, and purchase orders based on policy guidelines',
    metadata: JSON.stringify({ requests: 3, totalAmount: 4500 }),
    impact: 'medium',
    status: 'completed',
    createdAt: getTodayTime(9, 15),
  },
  {
    engine: 'task',
    action: 'schedule_meeting',
    title: 'Scheduled weekly sync meeting',
    description: 'Found optimal time slot for 8 participants and sent calendar invites',
    metadata: JSON.stringify({ participants: 8, duration: 60 }),
    impact: 'medium',
    status: 'completed',
    createdAt: getTodayTime(10, 0),
  },
  
  // Afternoon activities
  {
    engine: 'communication',
    action: 'respond_inquiry',
    title: 'Responded to 15 customer inquiries',
    description: 'Processed support tickets and sent personalized responses with solutions',
    metadata: JSON.stringify({ tickets: 15, avgResponseTime: 180 }),
    impact: 'high',
    status: 'completed',
    createdAt: getTodayTime(13, 45),
  },
  {
    engine: 'task',
    action: 'data_analysis',
    title: 'Generated monthly sales report',
    description: 'Analyzed sales data, created visualizations, and compiled executive summary',
    metadata: JSON.stringify({ dataPoints: 1250, charts: 5 }),
    impact: 'high',
    status: 'completed',
    createdAt: getTodayTime(14, 30),
  },
  {
    engine: 'decision',
    action: 'prioritize_tasks',
    title: 'Reprioritized project backlog',
    description: 'Analyzed 47 tasks and reordered based on urgency, dependencies, and resource availability',
    metadata: JSON.stringify({ tasks: 47, changed: 12 }),
    impact: 'medium',
    status: 'completed',
    createdAt: getTodayTime(15, 20),
  },
  
  // Evening activities
  {
    engine: 'communication',
    action: 'send_notification',
    title: 'Sent end-of-day summary',
    description: 'Compiled daily accomplishments and sent summary to stakeholders',
    metadata: JSON.stringify({ recipients: 5, highlights: 8 }),
    impact: 'medium',
    status: 'completed',
    createdAt: getTodayTime(17, 30),
  },
  {
    engine: 'task',
    action: 'backup_data',
    title: 'Completed automated backups',
    description: 'Backed up 3 databases and 250GB of files to secure storage',
    metadata: JSON.stringify({ databases: 3, size: '250GB' }),
    impact: 'high',
    status: 'completed',
    createdAt: getTodayTime(18, 0),
  },
  
  // In-progress activities
  {
    engine: 'task',
    action: 'process_invoices',
    title: 'Processing monthly invoices',
    description: 'Reviewing and categorizing 28 invoices for payment approval',
    metadata: JSON.stringify({ total: 28, processed: 15 }),
    impact: 'medium',
    status: 'in_progress',
    createdAt: getTodayTime(16, 45),
  },
  {
    engine: 'decision',
    action: 'analyze_metrics',
    title: 'Analyzing performance metrics',
    description: 'Reviewing KPIs and preparing recommendations for optimization',
    metadata: JSON.stringify({ metrics: 12, analyzed: 8 }),
    impact: 'high',
    status: 'in_progress',
    createdAt: getTodayTime(17, 0),
  },
];

function getTodayTime(hour, minute) {
  const now = new Date();
  now.setHours(hour, minute, 0, 0);
  return now;
}

async function seed() {
  console.log('🌱 Seeding sample activities...');
  
  try {
    // Insert activities
    for (const activity of sampleActivities) {
      await connection.execute(
        `INSERT INTO hai_activities (engine, action, title, description, metadata, impact, status, createdAt)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          activity.engine,
          activity.action,
          activity.title,
          activity.description,
          activity.metadata,
          activity.impact,
          activity.status,
          activity.createdAt,
        ]
      );
    }
    
    console.log(`✓ Inserted ${sampleActivities.length} sample activities`);
    console.log('✓ Seeding complete!');
    
    // Summary
    console.log('\nSummary:');
    console.log(`  Communication: ${sampleActivities.filter(a => a.engine === 'communication').length}`);
    console.log(`  Decision: ${sampleActivities.filter(a => a.engine === 'decision').length}`);
    console.log(`  Task: ${sampleActivities.filter(a => a.engine === 'task').length}`);
    console.log(`  Completed: ${sampleActivities.filter(a => a.status === 'completed').length}`);
    console.log(`  In Progress: ${sampleActivities.filter(a => a.status === 'in_progress').length}`);
    
  } catch (error) {
    console.error('✗ Seeding failed:', error);
    process.exit(1);
  } finally {
    await connection.end();
  }
}

seed();
