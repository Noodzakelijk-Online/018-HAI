/**
 * Migration script: Assign existing agents to users' first household
 * 
 * This script:
 * 1. Finds all agents without a householdId
 * 2. For each agent's userId, finds their first household
 * 3. Assigns the agent to that household
 * 4. If user has no household, creates one automatically
 */

import { drizzle } from 'drizzle-orm/mysql2';
import { eq, isNull, and } from 'drizzle-orm';
import { agents, households, householdMembers } from '../drizzle/schema.ts';
import mysql from 'mysql2/promise';

async function migrateAgentsToHouseholds() {
  console.log('[Migration] Starting agent household assignment...');
  
  // Create database connection
  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  const db = drizzle(connection);
  
  try {
    // Get all agents without a householdId
    const orphanedAgents = await db
      .select()
      .from(agents)
      .where(isNull(agents.householdId));
    
    console.log(`[Migration] Found ${orphanedAgents.length} agents without household assignment`);
    
    for (const agent of orphanedAgents) {
      // Find user's first household
      const userHouseholds = await db
        .select({ householdId: householdMembers.householdId })
        .from(householdMembers)
        .where(eq(householdMembers.userId, agent.userId))
        .limit(1);
      
      let targetHouseholdId;
      
      if (userHouseholds.length > 0) {
        // User has a household, use it
        targetHouseholdId = userHouseholds[0].householdId;
        console.log(`[Migration] Agent "${agent.name}" → Household ${targetHouseholdId} (existing)`);
      } else {
        // User has no household, create one
        const [newHousehold] = await db
          .insert(households)
          .values({
            name: `${agent.userId}'s Household`,
          });
        
        targetHouseholdId = newHousehold.insertId;
        
        // Add user as owner
        await db
          .insert(householdMembers)
          .values({
            householdId: targetHouseholdId,
            userId: agent.userId,
            role: 'owner',
          });
        
        console.log(`[Migration] Created household ${targetHouseholdId} for user ${agent.userId}`);
        console.log(`[Migration] Agent "${agent.name}" → Household ${targetHouseholdId} (new)`);
      }
      
      // Assign agent to household
      await db
        .update(agents)
        .set({ householdId: targetHouseholdId })
        .where(eq(agents.id, agent.id));
    }
    
    console.log('[Migration] ✅ Agent household assignment complete!');
    
  } catch (error) {
    console.error('[Migration] ❌ Error during migration:', error);
    throw error;
  } finally {
    await connection.end();
  }
}

// Run migration
migrateAgentsToHouseholds()
  .then(() => {
    console.log('[Migration] Done!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('[Migration] Failed:', error);
    process.exit(1);
  });
