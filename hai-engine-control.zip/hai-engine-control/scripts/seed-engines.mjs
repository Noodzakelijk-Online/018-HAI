import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";

const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  console.error("DATABASE_URL environment variable is not set");
  process.exit(1);
}

const connection = await mysql.createConnection(DATABASE_URL);
const db = drizzle(connection);

// Initial engine configurations
const initialEngines = [
  {
    engineId: "hle",
    name: "Household Ledger Engine",
    description: "Event sourcing and audit trail for all household operations. Tracks signals, tasks, drafts, approvals, and provides materialized projections.",
    status: "running",
    autonomyLevel: 0,
    priority: "critical",
    dependencies: [],
    lastHealthCheck: new Date(),
  },
  {
    engineId: "frontier",
    name: "Frontier Engine",
    description: "Capability discovery and autonomous service integration. Researches, prototypes, and acquires new services with owner approval.",
    status: "running",
    autonomyLevel: 2,
    priority: "critical",
    dependencies: ["hle", "sme", "policy"],
  },
  {
    engineId: "sme",
    name: "Self-Model Engine",
    description: "Learns user preferences, communication patterns, and decision-making criteria from historical interactions.",
    status: "running",
    autonomyLevel: 0,
    priority: "high",
    dependencies: ["hle"],
  },
  {
    engineId: "policy",
    name: "Policy Engine",
    description: "Enforces user-defined rules and constraints. Evaluates policies and prevents unauthorized actions.",
    status: "running",
    autonomyLevel: 0,
    priority: "high",
    dependencies: ["hle", "sme"],
  },
  {
    engineId: "decision",
    name: "Decision Engine",
    description: "Makes autonomous decisions within policy constraints. Provides confidence scoring and explanations.",
    status: "running",
    autonomyLevel: 2,
    priority: "medium",
    dependencies: ["policy", "sme", "hle"],
  },
  {
    engineId: "task_orchestration",
    name: "Task Orchestration Engine",
    description: "Manages task lifecycle and execution. Handles scheduling, dependencies, and parallel execution.",
    status: "running",
    autonomyLevel: 2,
    priority: "high",
    dependencies: ["hle", "decision"],
  },
  {
    engineId: "connector_framework",
    name: "Connector Framework",
    description: "Unified interface for external service integrations. Manages OAuth, rate limiting, and error handling.",
    status: "running",
    autonomyLevel: 0,
    priority: "critical",
    dependencies: ["hle"],
  },
  {
    engineId: "kge",
    name: "Knowledge Graph Engine",
    description: "Semantic understanding and relationship mapping. Extracts entities and builds knowledge graphs.",
    status: "initializing",
    autonomyLevel: 0,
    priority: "high",
    dependencies: ["hle"],
  },
  {
    engineId: "playbook",
    name: "Playbook Engine",
    description: "Executes predefined workflows and automations. Supports conditional logic and error handling.",
    status: "stopped",
    autonomyLevel: 3,
    priority: "medium",
    dependencies: ["task_orchestration", "policy"],
  },
  {
    engineId: "communication",
    name: "Communication Engine",
    description: "Composes and sends messages across platforms. Adapts tone and style based on user preferences.",
    status: "stopped",
    autonomyLevel: 2,
    priority: "medium",
    dependencies: ["sme", "connector_framework", "hle"],
  },
  {
    engineId: "analytics",
    name: "Analytics Engine",
    description: "Provides insights and reporting. Tracks metrics, detects anomalies, and generates dashboards.",
    status: "stopped",
    autonomyLevel: 0,
    priority: "low",
    dependencies: ["hle", "kge"],
  },
];

// Initial services for Frontier Engine
const initialServices = [
  {
    serviceId: "gmail",
    name: "Gmail",
    description: "Google email service with powerful search and organization features",
    category: "communication",
    apiEndpoint: "https://gmail.googleapis.com",
    authType: "oauth",
    capabilities: ["email_read", "email_send", "email_search", "labels", "attachments"],
    tosUrl: "https://policies.google.com/terms",
    privacyPolicyUrl: "https://policies.google.com/privacy",
    legalFlags: ["gdpr_compliant", "requires_oauth"],
    freeTier: true,
    status: "available",
  },
  {
    serviceId: "google_calendar",
    name: "Google Calendar",
    description: "Calendar and scheduling service from Google",
    category: "productivity",
    apiEndpoint: "https://www.googleapis.com/calendar/v3",
    authType: "oauth",
    capabilities: ["event_read", "event_create", "event_update", "recurring_events"],
    tosUrl: "https://policies.google.com/terms",
    privacyPolicyUrl: "https://policies.google.com/privacy",
    legalFlags: ["gdpr_compliant", "requires_oauth"],
    freeTier: true,
    status: "available",
  },
  {
    serviceId: "trello",
    name: "Trello",
    description: "Visual project management and task tracking",
    category: "productivity",
    apiEndpoint: "https://api.trello.com/1",
    authType: "oauth",
    capabilities: ["board_management", "card_management", "checklist_management", "attachments"],
    tosUrl: "https://trello.com/legal/terms",
    privacyPolicyUrl: "https://trello.com/legal/privacy",
    legalFlags: ["gdpr_compliant"],
    freeTier: true,
    status: "available",
  },
  {
    serviceId: "lastpass",
    name: "LastPass",
    description: "Password manager and secure credential storage",
    category: "security",
    apiEndpoint: "https://lastpass.com/api",
    authType: "api_key",
    capabilities: ["credential_storage", "credential_retrieval", "secure_notes", "2fa"],
    tosUrl: "https://www.lastpass.com/legal/terms-of-service",
    privacyPolicyUrl: "https://www.lastpass.com/legal/privacy-policy",
    legalFlags: ["gdpr_compliant", "requires_2fa"],
    freeTier: false,
    status: "available",
  },
];

console.log("Seeding engines...");

for (const engine of initialEngines) {
  try {
    await db.execute(
      `INSERT INTO engines (engineId, name, description, status, autonomyLevel, priority, dependencies, lastHealthCheck, createdAt, updatedAt)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
       ON DUPLICATE KEY UPDATE
         name = VALUES(name),
         description = VALUES(description),
         status = VALUES(status),
         autonomyLevel = VALUES(autonomyLevel),
         priority = VALUES(priority),
         dependencies = VALUES(dependencies),
         lastHealthCheck = VALUES(lastHealthCheck),
         updatedAt = NOW()`,
      [
        engine.engineId,
        engine.name,
        engine.description,
        engine.status,
        engine.autonomyLevel,
        engine.priority,
        JSON.stringify(engine.dependencies),
        engine.lastHealthCheck,
      ]
    );
    console.log(`✓ Seeded engine: ${engine.name}`);
  } catch (error) {
    console.error(`✗ Failed to seed engine ${engine.name}:`, error.message);
  }
}

console.log("\nSeeding services...");

for (const service of initialServices) {
  try {
    await db.execute(
      `INSERT INTO services (serviceId, name, description, category, apiEndpoint, authType, capabilities, tosUrl, privacyPolicyUrl, legalFlags, freeTier, status, createdAt, updatedAt)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
       ON DUPLICATE KEY UPDATE
         name = VALUES(name),
         description = VALUES(description),
         category = VALUES(category),
         apiEndpoint = VALUES(apiEndpoint),
         authType = VALUES(authType),
         capabilities = VALUES(capabilities),
         tosUrl = VALUES(tosUrl),
         privacyPolicyUrl = VALUES(privacyPolicyUrl),
         legalFlags = VALUES(legalFlags),
         freeTier = VALUES(freeTier),
         status = VALUES(status),
         updatedAt = NOW()`,
      [
        service.serviceId,
        service.name,
        service.description,
        service.category,
        service.apiEndpoint,
        service.authType,
        JSON.stringify(service.capabilities),
        service.tosUrl,
        service.privacyPolicyUrl,
        JSON.stringify(service.legalFlags),
        service.freeTier,
        service.status,
      ]
    );
    console.log(`✓ Seeded service: ${service.name}`);
  } catch (error) {
    console.error(`✗ Failed to seed service ${service.name}:`, error.message);
  }
}

await connection.end();
console.log("\n✓ Seeding complete!");
