# Fara-7B Research Findings

## Overview
Fara-7B is Microsoft's first agentic small language model (SLM) designed specifically for computer use. With only 7 billion parameters, it achieves state-of-the-art performance on computer use agent (CUA) benchmarks.

## Key Capabilities

### Visual Perception
- **Screenshot-only operation**: Perceives webpages using only browser window screenshots
- **No accessibility trees**: Does not rely on DOM parsing or accessibility information
- **Human-like interaction**: Uses the same modalities as humans to interact with computers

### Action Execution
- **Direct coordinate prediction**: Clicks on directly predicted (x,y) coordinates
- **Playwright integration**: Uses standard Playwright mouse and keyboard actions
  - `click(x,y)` - Click at specific coordinates
  - `type()` - Type text
  - `web_search()` - Perform web searches
  - `visit_url()` - Navigate to URLs
- **Multi-step tasks**: Executes complex workflows across multiple steps

### Architecture
- **Base model**: Qwen2.5-VL-7B (chosen for grounding tasks and long context support)
- **Context window**: Up to 128k tokens
- **Training approach**: Supervised fine-tuning (no reinforcement learning)
- **Prediction format**: "observe-think-act" sequence
  - Reasoning message ("thinking")
  - Tool call (action)

## Training Data
- **Synthetic data pipeline**: Novel generation approach building on AgentInstruct
- **Real web pages**: Tasks sourced from actual human users
- **Multi-step trajectories**: Linearized solving pipelines

## Deployment Options

### 1. Microsoft Foundry (Azure)
- Cloud-hosted API access
- Production-ready deployment
- API endpoints for integration

### 2. Hugging Face
- Open-weight model under MIT license
- Download and self-host
- URL: https://huggingface.co/microsoft/Fara-7B

### 3. Local Deployment (Copilot+ PCs)
- Quantized and silicon-optimized version
- Runs on Windows 11 Copilot+ PCs
- Turnkey experimentation
- No cloud dependency

### 4. Magentic-UI Integration
- Research prototype from Microsoft Research AI Frontiers
- Pre-built UI for Fara-7B
- Ready for experimentation

## Use Cases
- Automating everyday web tasks
- Filling out forms
- Searching for information
- Booking travel
- Managing accounts
- Shopping and reservations

## Safety Considerations
⚠️ **Important**: Fara-7B is an experimental release

- Run in sandboxed environments
- Monitor execution closely
- Avoid sensitive data
- Avoid high-risk domains
- Responsible use is essential

## Performance
- Outperforms other CUA models of comparable size
- State-of-the-art on computer use benchmarks
- Efficient 7B parameter model

## Integration Requirements

### Input Format
- **Screenshots**: Latest 3 browser window screenshots
- **User messages**: Complete conversation history
- **Action history**: All previous actions taken

### Output Format
- **Reasoning**: Thinking about next action
- **Tool call**: Specific action to execute

### Tools Available
- Mouse actions (click, move, drag)
- Keyboard actions (type, press keys)
- Browser macros (search, navigate)
- Scrolling and navigation

## API Usage

### System Prompt
```
You are a web automation agent that performs actions on websites to fulfill user requests by calling various tools.

You should stop execution at Critical Points. A Critical Point occurs in tasks like:
- Checkout
- Book
- Purchase
- Call
- Email
- Order

A Critical Point requires the user's permission or personal/sensitive information (name, email, credit card, address, payment information, resume, etc.) to complete a transaction (purchase, reservation, sign-up, etc.), or to communicate as a human would (call, email, apply to a job, etc.).

Guideline: Solve the task as far as possible up until a Critical Point.
```

### Available Actions
- `key` - Press keyboard keys
- `type` - Type text
- `mouse_move` - Move cursor to (x,y)
- `left_click` - Click left mouse button
- `scroll` - Scroll up/down
- `visit_url` - Navigate to URL
- `web_search` - Perform web search
- `history_back` - Go back in browser
- `pause_and_memorize_fact` - Store information
- `wait` - Wait for specified seconds
- `terminate` - End task with status

### Technical Requirements
- **Packages**: torch >=2.7.1, transformers >=4.53.3, vllm >=0.10.0
- **GPUs**: NVIDIA A6000, A100, H100
- **OS**: Ubuntu 24.04.3 LTS
- **Precision**: bf16 recommended
- **Server**: vLLM for optimal performance

### Performance Benchmarks
| Benchmark | Fara-7B Score |
|-----------|---------------|
| WebVoyager | 73.5% |
| Online-M2W | 34.1% |
| DeepShop | 26.2% |
| WebTailBench | 38.4% |

## Installation & Deployment

### Option 1: Azure Foundry (Recommended)
**No GPU required** - Cloud-hosted API

1. Deploy Fara-7B on Azure Foundry
2. Get endpoint URL and API key
3. Configure endpoint:
```json
{
  "model": "Fara-7B",
  "base_url": "https://your-endpoint.inference.ml.azure.com/",
  "api_key": "YOUR_API_KEY_HERE"
}
```

### Option 2: Self-Hosted (vLLM)
**Requires GPU** - Local deployment

```bash
# Clone repository
git clone https://github.com/microsoft/fara.git
cd fara

# Setup environment
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
playwright install

# Start vLLM server
vllm serve "microsoft/Fara-7B" --port 5000 --dtype auto

# Test with CLI
fara-cli --task "whats the weather in new york now"
```

### Option 3: Hugging Face Direct
```python
from transformers import AutoModel, AutoTokenizer

model = AutoModel.from_pretrained("microsoft/Fara-7B")
tokenizer = AutoTokenizer.from_pretrained("microsoft/Fara-7B")
```

## HAI Integration Strategy

### Phase 1: API Integration
1. Set up Azure Foundry access or vLLM server
2. Create Fara-7B service wrapper
3. Implement screenshot capture pipeline
4. Build action execution layer

### Phase 2: Computer Control
1. Implement Playwright-based action executor
2. Create screen capture service
3. Build task queue system
4. Add safety mechanisms

### Phase 3: Autonomous Workflows
1. Design task templates
2. Implement multi-step orchestration
3. Add error handling and retry logic
4. Create monitoring dashboard

## Resources
- **Research Blog**: https://www.microsoft.com/en-us/research/blog/fara-7b-an-efficient-agentic-model-for-computer-use/
- **ArXiv Paper**: https://arxiv.org/abs/2511.19663
- **Hugging Face**: https://huggingface.co/microsoft/Fara-7B
- **GitHub**: https://github.com/microsoft/fara
- **Azure Foundry**: https://labs.ai.azure.com/projects/fara-7b/
