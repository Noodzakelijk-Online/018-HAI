# HAI Engine Control - Testing Guide

**Version:** 1.0  
**Last Updated:** December 6, 2025  
**Author:** Manus AI

---

## Overview

This document outlines testing strategies, validation procedures, and quality assurance processes for HAI Engine Control. Comprehensive testing ensures reliable autonomous operation, data integrity, and user trust in AI-powered decision-making.

---

## Testing Strategy

HAI Engine Control employs multi-layered testing approach covering unit tests, integration tests, end-to-end workflows, and AI agent validation.

**Test Coverage Goals:**
- Unit Tests: 80% code coverage
- Integration Tests: All API endpoints
- E2E Tests: Critical user workflows
- AI Agent Tests: Task execution accuracy > 85%

---

## Unit Testing

Unit tests validate individual functions and components in isolation using Vitest framework.

### Running Unit Tests

Execute test suite with coverage reporting:

```bash
pnpm test
pnpm test:coverage
```

### Example Test: Email Classification

```typescript
import { describe, it, expect, vi } from 'vitest';
import { classifyEmail } from '../server/services/emailAutoResponse';

describe('Email Classification', () => {
  it('should classify urgent emails correctly', async () => {
    const email = {
      from: 'boss@company.com',
      subject: 'URGENT: Server down',
      body: 'Production server is not responding. Need immediate attention.'
    };

    const classification = await classifyEmail(email);

    expect(classification.category).toBe('urgent');
    expect(classification.priority).toBeGreaterThanOrEqual(4);
    expect(classification.requiresResponse).toBe(true);
  });

  it('should detect spam emails', async () => {
    const email = {
      from: 'winner@lottery.com',
      subject: 'You won $1,000,000!!!',
      body: 'Click here to claim your prize...'
    };

    const classification = await classifyEmail(email);

    expect(classification.category).toBe('spam');
    expect(classification.suggestedAction).toBe('ignore');
  });
});
```

### Example Test: Task Routing

```typescript
import { describe, it, expect } from 'vitest';
import { analyzeTask } from '../server/services/taskAnalyzer';

describe('Task Routing', () => {
  it('should route sensitive tasks to Fara-7B', async () => {
    const analysis = await analyzeTask({
      title: 'Check bank account balance',
      description: 'Log into online banking and verify current balance',
      privacyLevel: 'sensitive'
    });

    expect(analysis.recommendedAgent).toBe('fara');
    expect(analysis.reasoning).toContain('privacy');
  });

  it('should route desktop tasks to Lux', async () => {
    const analysis = await analyzeTask({
      title: 'Create Excel spreadsheet',
      description: 'Open Excel and create budget template',
      privacyLevel: 'normal'
    });

    expect(analysis.recommendedAgent).toMatch(/lux/);
  });
});
```

---

## Integration Testing

Integration tests verify API endpoints, database operations, and service interactions.

### tRPC Endpoint Testing

```typescript
import { describe, it, expect, beforeAll } from 'vitest';
import { createCaller } from '../server/routers';
import { createMockContext } from '../server/_core/test-utils';

describe('Task API', () => {
  let caller: ReturnType<typeof createCaller>;

  beforeAll(() => {
    const ctx = createMockContext({
      user: { id: 1, role: 'user' }
    });
    caller = createCaller(ctx);
  });

  it('should create task successfully', async () => {
    const task = await caller.tasks.create({
      title: 'Test task',
      description: 'Integration test',
      priority: 'medium'
    });

    expect(task.id).toBeDefined();
    expect(task.status).toBe('pending');
  });

  it('should list user tasks', async () => {
    const result = await caller.tasks.list({
      status: 'pending',
      limit: 10
    });

    expect(Array.isArray(result.tasks)).toBe(true);
    expect(result.total).toBeGreaterThanOrEqual(0);
  });
});
```

### Database Integration Tests

```typescript
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { getDb } from '../server/db';
import { tasks } from '../drizzle/schema';

describe('Database Operations', () => {
  let db: Awaited<ReturnType<typeof getDb>>;

  beforeEach(async () => {
    db = await getDb();
  });

  afterEach(async () => {
    // Clean up test data
    if (db) {
      await db.delete(tasks).where(eq(tasks.title, 'Test Task'));
    }
  });

  it('should insert and retrieve task', async () => {
    const [inserted] = await db.insert(tasks).values({
      userId: 1,
      title: 'Test Task',
      description: 'Test description',
      status: 'pending',
      priority: 'medium'
    });

    const retrieved = await db.select().from(tasks).where(eq(tasks.id, inserted.insertId));

    expect(retrieved[0].title).toBe('Test Task');
  });
});
```

---

## End-to-End Testing

E2E tests validate complete user workflows using Playwright.

### Setup Playwright

```bash
pnpm add -D @playwright/test
npx playwright install
```

### Example E2E Test: Task Creation Flow

```typescript
import { test, expect } from '@playwright/test';

test.describe('Task Management', () => {
  test.beforeEach(async ({ page }) => {
    // Login
    await page.goto('http://localhost:3000');
    await page.click('text=Sign in');
    // Complete OAuth flow (mock or real)
  });

  test('should create and execute task', async ({ page }) => {
    // Navigate to dashboard
    await page.goto('http://localhost:3000');
    await expect(page.locator('h1')).toContainText('Dashboard');

    // Create new task
    await page.click('button:has-text("New Task")');
    await page.fill('input[name="title"]', 'Test automation task');
    await page.fill('textarea[name="description"]', 'Automated E2E test');
    await page.selectOption('select[name="priority"]', 'high');
    await page.click('button:has-text("Create")');

    // Verify task appears in list
    await expect(page.locator('text=Test automation task')).toBeVisible();

    // Check task status updates
    await page.waitForSelector('text=in_progress', { timeout: 10000 });
  });

  test('should approve pending action', async ({ page }) => {
    await page.goto('http://localhost:3000/approvals');

    // Wait for approval items to load
    await page.waitForSelector('[data-testid="approval-item"]');

    // Click approve on first item
    await page.click('[data-testid="approval-item"]:first-child button:has-text("Approve")');

    // Verify success toast
    await expect(page.locator('text=Approved successfully')).toBeVisible();
  });
});
```

### Example E2E Test: Connector Setup

```typescript
test('should connect Gmail account', async ({ page }) => {
  await page.goto('http://localhost:3000/connectors');

  // Click connect Gmail
  await page.click('button:has-text("Connect Gmail")');

  // OAuth flow (mock in test environment)
  await expect(page).toHaveURL(/oauth/);
  
  // After OAuth completion
  await page.waitForURL('http://localhost:3000/connectors');
  await expect(page.locator('text=Gmail connected')).toBeVisible();
});
```

---

## AI Agent Testing

Validate AI agent execution accuracy and reliability.

### Lux Execution Tests

```typescript
import { describe, it, expect } from 'vitest';
import { executeLuxTask } from '../server/services/luxAgent';

describe('Lux Agent Execution', () => {
  it('should complete simple browser task', async () => {
    const result = await executeLuxTask({
      instruction: 'Go to google.com and search for "weather"',
      mode: 'actor',
      timeout: 30
    });

    expect(result.success).toBe(true);
    expect(result.steps.length).toBeGreaterThan(0);
  }, 60000); // 60s timeout

  it('should handle desktop application task', async () => {
    const result = await executeLuxTask({
      instruction: 'Open Notepad and type "Hello World"',
      mode: 'tasker',
      timeout: 60
    });

    expect(result.success).toBe(true);
    expect(result.result).toContain('Notepad');
  }, 90000);
});
```

### Task Routing Accuracy Tests

```typescript
describe('Task Routing Accuracy', () => {
  const testCases = [
    {
      task: { title: 'Check email', privacyLevel: 'sensitive' },
      expectedAgent: 'fara',
      reason: 'Privacy-sensitive email access'
    },
    {
      task: { title: 'Create PowerPoint', privacyLevel: 'normal' },
      expectedAgent: 'lux',
      reason: 'Desktop application control'
    },
    {
      task: { title: 'Google search', privacyLevel: 'public' },
      expectedAgent: 'fara',
      reason: 'Simple browser task, cost optimization'
    }
  ];

  testCases.forEach(({ task, expectedAgent, reason }) => {
    it(`should route "${task.title}" to ${expectedAgent}`, async () => {
      const analysis = await analyzeTask(task);
      
      expect(analysis.recommendedAgent).toContain(expectedAgent);
      expect(analysis.reasoning.toLowerCase()).toContain(reason.toLowerCase());
      expect(analysis.confidence).toBeGreaterThan(70);
    });
  });
});
```

---

## Performance Testing

Measure system performance under load and identify bottlenecks.

### Load Testing with Artillery

Create `artillery.yml` configuration:

```yaml
config:
  target: 'http://localhost:3000'
  phases:
    - duration: 60
      arrivalRate: 10
      name: Warm up
    - duration: 120
      arrivalRate: 50
      name: Sustained load
    - duration: 60
      arrivalRate: 100
      name: Peak load

scenarios:
  - name: 'Task creation workflow'
    flow:
      - post:
          url: '/api/trpc/tasks.create'
          json:
            title: 'Load test task'
            description: 'Performance testing'
            priority: 'medium'
      - get:
          url: '/api/trpc/tasks.list'
```

Run load test:

```bash
pnpm add -D artillery
npx artillery run artillery.yml
```

### Database Query Performance

```typescript
import { describe, it, expect } from 'vitest';
import { getDb } from '../server/db';
import { tasks } from '../drizzle/schema';

describe('Query Performance', () => {
  it('should retrieve tasks within 100ms', async () => {
    const db = await getDb();
    const start = Date.now();

    await db.select().from(tasks).limit(50);

    const duration = Date.now() - start;
    expect(duration).toBeLessThan(100);
  });

  it('should handle concurrent queries', async () => {
    const db = await getDb();
    const queries = Array(10).fill(null).map(() =>
      db.select().from(tasks).limit(10)
    );

    const start = Date.now();
    await Promise.all(queries);
    const duration = Date.now() - start;

    expect(duration).toBeLessThan(500);
  });
});
```

---

## Security Testing

Validate authentication, authorization, and data protection mechanisms.

### Authentication Tests

```typescript
describe('Authentication Security', () => {
  it('should reject unauthenticated requests', async () => {
    const ctx = createMockContext({ user: null });
    const caller = createCaller(ctx);

    await expect(
      caller.tasks.list()
    ).rejects.toThrow('UNAUTHORIZED');
  });

  it('should enforce role-based access', async () => {
    const ctx = createMockContext({ user: { id: 1, role: 'user' } });
    const caller = createCaller(ctx);

    await expect(
      caller.system.notifyOwner({ title: 'Test', content: 'Test' })
    ).rejects.toThrow('FORBIDDEN');
  });
});
```

### Data Encryption Tests

```typescript
import { encryptData, decryptData } from '../server/services/encryption';

describe('Data Encryption', () => {
  it('should encrypt and decrypt correctly', async () => {
    const original = 'Sensitive data';
    const key = 'user-encryption-key';

    const encrypted = await encryptData(original, key);
    expect(encrypted).not.toBe(original);

    const decrypted = await decryptData(encrypted, key);
    expect(decrypted).toBe(original);
  });

  it('should fail with wrong key', async () => {
    const encrypted = await encryptData('data', 'correct-key');

    await expect(
      decryptData(encrypted, 'wrong-key')
    ).rejects.toThrow();
  });
});
```

---

## Validation Checklist

Use this checklist before production deployment:

### Functional Validation

- [ ] User authentication works (login, logout, session persistence)
- [ ] Task creation and execution complete successfully
- [ ] Email classification accuracy > 85%
- [ ] Calendar scheduling finds available slots correctly
- [ ] Approval queue shows pending items
- [ ] Connectors sync data without errors
- [ ] AI agent routing selects appropriate agent
- [ ] WebSocket real-time updates function
- [ ] Theme toggle switches correctly
- [ ] Keyboard shortcuts respond
- [ ] Global search returns relevant results

### Performance Validation

- [ ] Dashboard loads in < 2 seconds
- [ ] API response time < 200ms (p95)
- [ ] Database queries optimized with indexes
- [ ] No memory leaks during extended operation
- [ ] Handles 100 concurrent users
- [ ] Task execution completes within timeout
- [ ] File uploads process without blocking

### Security Validation

- [ ] All endpoints require authentication
- [ ] RBAC enforced for admin operations
- [ ] Sensitive data encrypted at rest
- [ ] HTTPS enforced in production
- [ ] Security headers configured
- [ ] Rate limiting prevents abuse
- [ ] SQL injection protection verified
- [ ] XSS prevention validated
- [ ] CSRF tokens implemented

### Compatibility Validation

- [ ] Works in Chrome, Firefox, Safari, Edge
- [ ] Mobile responsive (375px, 768px, 1024px)
- [ ] Touch interactions functional on tablets
- [ ] Screen reader accessible
- [ ] Keyboard navigation complete
- [ ] Works with Fara-7B local model
- [ ] Works with Lux cloud API
- [ ] Database compatible (MySQL, TiDB)

---

## Continuous Integration

Automate testing in CI/CD pipeline:

### GitHub Actions Workflow

```yaml
name: CI

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: pnpm/action-setup@v2
      - uses: actions/setup-node@v3
        with:
          node-version: '22'
          cache: 'pnpm'
      
      - run: pnpm install
      - run: pnpm test:coverage
      - run: pnpm build
      
      - name: Upload coverage
        uses: codecov/codecov-action@v3
```

---

## Monitoring and Alerting

Set up production monitoring to catch issues early:

### Health Check Endpoint

```typescript
app.get('/health', async (req, res) => {
  const checks = {
    database: await checkDatabase(),
    redis: await checkRedis(),
    luxApi: await checkLuxApi(),
    faraModel: await checkFaraModel()
  };

  const healthy = Object.values(checks).every(v => v === true);

  res.status(healthy ? 200 : 503).json({
    status: healthy ? 'healthy' : 'degraded',
    checks,
    timestamp: new Date().toISOString()
  });
});
```

### Error Rate Monitoring

Track error rates and alert when thresholds exceeded:

- API error rate > 5%
- Task failure rate > 10%
- Database connection failures
- AI agent timeout rate > 15%

---

## Conclusion

Comprehensive testing ensures HAI Engine Control operates reliably and securely in production. Regular test execution, performance monitoring, and security audits maintain system quality as features evolve.

---

**Document Version:** 1.0  
**Next Review:** March 2026
