# HAI Hybrid AI Architecture: Fara-7B + OpenAGI Lux

**Date:** December 3, 2025  
**Purpose:** Design complementary AI system leveraging both Fara-7B and OpenAGI Lux for optimal autonomous computer control

---

## Executive Summary

HAI will use a **hybrid dual-AI architecture** that combines:
- **Fara-7B** (Microsoft) - Browser-focused, open-source, self-hosted
- **OpenAGI Lux** - Desktop applications, cloud/edge, superior performance

This approach maximizes capabilities while minimizing costs and maintaining flexibility.

---

## Why Hybrid Architecture?

### Fara-7B Strengths
✅ **Open-source** - Free to use, no API costs  
✅ **Self-hosted** - Complete privacy, no data leaves user's PC  
✅ **Browser-focused** - Optimized for web automation  
✅ **Customizable** - Can fine-tune for specific use cases  
✅ **Offline capable** - Works without internet  

### OpenAGI Lux Strengths
✅ **83.6% success rate** - Industry-leading performance  
✅ **Desktop app control** - Excel, Slack, Adobe, any Windows app  
✅ **10x cheaper** - Lower cost than OpenAI/Anthropic  
✅ **Built-in safety** - Refuses dangerous actions automatically  
✅ **Three execution modes** - Actor (fast), Tasker (stable), Thinker (complex)  
✅ **Edge deployment** - Intel partnership for on-device optimization  

### Combined Benefits
🚀 **Best of both worlds** - Privacy + Performance  
💰 **Cost optimization** - Use free Fara-7B for simple tasks, Lux for complex  
🔒 **Privacy control** - Sensitive tasks stay local (Fara-7B), others use cloud (Lux)  
⚡ **Speed flexibility** - Fast local execution OR powerful cloud processing  
🛡️ **Redundancy** - Fallback if one system fails  

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    HAI Master Orchestrator                   │
│                  (Task Analysis & Routing)                   │
└─────────────────────────────────────────────────────────────┘
                              │
                              ├─────────────────────────────────┐
                              │                                 │
                    ┌─────────▼─────────┐           ┌──────────▼──────────┐
                    │   Fara-7B Agent   │           │   Lux Agent         │
                    │   (Self-Hosted)   │           │   (Cloud/Edge)      │
                    └─────────┬─────────┘           └──────────┬──────────┘
                              │                                 │
                    ┌─────────▼─────────┐           ┌──────────▼──────────┐
                    │  Browser Control  │           │  Desktop App        │
                    │  (Playwright)     │           │  Control (Native)   │
                    └───────────────────┘           └─────────────────────┘
                              │                                 │
                    ┌─────────▼─────────┐           ┌──────────▼──────────┐
                    │  Web Apps:        │           │  Desktop Apps:      │
                    │  - Gmail Web      │           │  - Outlook Desktop  │
                    │  - Google Calendar│           │  - Excel            │
                    │  - Banking Sites  │           │  - Slack            │
                    │  - Research       │           │  - Adobe            │
                    └───────────────────┘           └─────────────────────┘
```

---

## Task Routing System

### Intelligent Task Distribution

The **HAI Master Orchestrator** analyzes each task and routes it to the optimal AI agent based on:

1. **Task Type** (browser vs desktop app)
2. **Privacy Level** (sensitive vs non-sensitive)
3. **Complexity** (simple vs multi-step)
4. **Speed Requirements** (urgent vs background)
5. **Cost Considerations** (free vs paid API)

### Routing Decision Tree

```
Task Received
    │
    ├─ Is it a browser-based task?
    │   ├─ YES → Is it sensitive data?
    │   │   ├─ YES → Route to Fara-7B (local, private)
    │   │   └─ NO → Is it complex?
    │   │       ├─ YES → Route to Lux Thinker (better performance)
    │   │       └─ NO → Route to Fara-7B (free)
    │   │
    │   └─ NO → Is it a desktop application?
    │       ├─ YES → Route to Lux (only option for desktop)
    │       └─ NO → Route to Lux Actor (general purpose)
```

### Routing Rules Table

| Task Category | Example | Primary Agent | Fallback | Reasoning |
|--------------|---------|---------------|----------|-----------|
| **Browser - Sensitive** | Online banking, tax filing | Fara-7B | None | Privacy-critical, keep local |
| **Browser - Simple** | Search Google, read article | Fara-7B | Lux Actor | Free, fast, sufficient |
| **Browser - Complex** | Multi-step research, form filling | Lux Thinker | Fara-7B | Better success rate |
| **Desktop - Any** | Excel, Slack, Outlook | Lux | None | Only Lux supports desktop |
| **Urgent** | Quick lookup, fast action | Lux Actor | Fara-7B | Near-instant speed |
| **Background** | Long research, data crawling | Fara-7B | Lux Tasker | Cost-effective |
| **High-Stakes** | Email to boss, calendar invite | Lux Tasker | Fara-7B | Ultra-stable execution |

---

## Lux Execution Modes

OpenAGI Lux offers **three execution modes** that HAI can leverage:

### 1. **Lux Actor** - Fast & Direct
- **Speed:** Near-instant (seconds)
- **Use Case:** Immediate, well-defined tasks
- **Example:** "Navigate to NASDAQ and find Apple's insider activity"
- **HAI Use:** Quick lookups, simple actions, urgent tasks

### 2. **Lux Tasker** - Stable & Controlled
- **Speed:** Moderate (minutes)
- **Use Case:** Step-by-step workflows, QA testing
- **Example:** "Fill out this form with user data, verify each field"
- **HAI Use:** High-stakes actions (emails, calendar), data entry

### 3. **Lux Thinker** - Complex & Autonomous
- **Speed:** Slow (hours)
- **Use Case:** Vague goals, multi-step research
- **Example:** "Research best CRM tools, compare features, create report"
- **HAI Use:** Deep research, complex workflows, autonomous projects

---

## SDK Integration Details

### OpenAGI Lux SDK

**Installation:**
```bash
pip install oagi
```

**Authentication:**
```bash
export OAGI_API_KEY=sk-...
export OAGI_BASE_URL=https://api.agiopen.org
```

**Basic Usage:**
```python
from oagi import Agent

# Actor mode (fast)
agent = Agent(model="lux-actor-1")
agent.run("Go to https://agiopen.org")

# Tasker mode (stable)
agent = Agent(model="lux-tasker-1")
agent.run("Fill out the contact form with my details")

# Thinker mode (complex)
agent = Agent(model="lux-thinker-1")
agent.run("Research top 5 project management tools and create comparison")
```

**Pricing:**
- **Free tier:** $10 credits for new users (dozens of sessions)
- **Paid:** Pay-as-you-go (10x cheaper than OpenAI/Anthropic)

**Permissions Required (Windows):**
- Screen recording (for screenshots)
- Accessibility (for mouse/keyboard control)

### Fara-7B Integration

**Installation:**
```bash
# Install vLLM for model serving
pip install vllm

# Install Playwright for browser control
pip install playwright
playwright install chromium

# Download Fara-7B model (14GB)
huggingface-cli download microsoft/Fara-7B
```

**Basic Usage:**
```python
from vllm import LLM
from playwright.sync_api import sync_playwright

# Initialize Fara-7B
llm = LLM(model="microsoft/Fara-7B")

# Browser automation
with sync_playwright() as p:
    browser = p.chromium.launch()
    page = browser.new_page()
    
    # Fara-7B generates actions based on screenshots
    screenshot = page.screenshot()
    action = llm.generate(screenshot, goal="Find login button")
    
    # Execute action
    page.click(action.selector)
```

**Cost:**
- **Free** (open-source model)
- **Hardware:** Requires GPU (8GB+ VRAM recommended)

---

## HAI Implementation Plan

### Phase 1: Lux Integration (Week 1-2)

**Goal:** Get Lux working in HAI desktop app

1. **Install Lux SDK**
   ```bash
   cd /home/ubuntu/hai-engine-control
   pip install oagi
   ```

2. **Create Lux Service** (`server/services/luxAgent.ts`)
   - Wrapper around Python `oagi` CLI
   - Execute Lux commands via child_process
   - Parse execution results
   - Handle errors and retries

3. **Add Lux Router** (`server/api/routers/lux.ts`)
   - `executeLuxTask` - Run Lux agent with task description
   - `getLuxStatus` - Check if Lux is available
   - `getLuxHistory` - View past Lux executions

4. **Update Task Queue**
   - Add `agentType` field: "fara" | "lux-actor" | "lux-tasker" | "lux-thinker"
   - Route tasks to appropriate agent

5. **Test Basic Lux Execution**
   - Simple task: "Go to https://agiopen.org"
   - Verify screenshot capture works
   - Verify action execution works

### Phase 2: Fara-7B Integration (Week 3-4)

**Goal:** Get Fara-7B running locally

1. **Create Python Installer** (`electron/installers/pythonInstaller.ts`)
   - Download embedded Python 3.11
   - Install PyTorch, vLLM, Playwright
   - Download Fara-7B model (14GB) with progress UI
   - Show installation progress in Electron window

2. **Create Fara-7B Service** (`server/services/faraAgent.ts`)
   - Start vLLM server with Fara-7B model
   - Manage Playwright browser instances
   - Execute browser automation tasks
   - Screenshot → LLM → Action loop

3. **Add Fara Router** (`server/api/routers/fara.ts`)
   - `executeFaraTask` - Run Fara-7B agent
   - `getFaraStatus` - Check model status
   - `getFaraHistory` - View execution history

4. **Test Fara-7B Execution**
   - Simple task: "Search Google for OpenAGI"
   - Verify local execution works
   - Measure performance vs Lux

### Phase 3: Task Routing System (Week 5)

**Goal:** Intelligent task distribution

1. **Create Task Analyzer** (`server/services/taskAnalyzer.ts`)
   ```typescript
   interface TaskAnalysis {
     taskType: 'browser' | 'desktop' | 'general';
     privacyLevel: 'sensitive' | 'normal' | 'public';
     complexity: 'simple' | 'moderate' | 'complex';
     urgency: 'immediate' | 'normal' | 'background';
     estimatedDuration: number; // seconds
   }
   
   function analyzeTask(taskDescription: string): TaskAnalysis {
     // Use LLM to analyze task characteristics
     // Return structured analysis
   }
   ```

2. **Create Task Router** (`server/services/taskRouter.ts`)
   ```typescript
   function routeTask(task: Task, analysis: TaskAnalysis): AgentType {
     // Desktop apps → Lux only
     if (analysis.taskType === 'desktop') {
       return analysis.urgency === 'immediate' ? 'lux-actor' : 'lux-tasker';
     }
     
     // Sensitive browser tasks → Fara-7B (local)
     if (analysis.privacyLevel === 'sensitive') {
       return 'fara';
     }
     
     // Complex browser tasks → Lux Thinker (better performance)
     if (analysis.complexity === 'complex') {
       return 'lux-thinker';
     }
     
     // Simple browser tasks → Fara-7B (free)
     return 'fara';
   }
   ```

3. **Update Master Orchestrator**
   - Integrate task analyzer
   - Route tasks automatically
   - Show routing decision in UI
   - Allow manual override

### Phase 4: UI Integration (Week 6)

**Goal:** User-facing controls

1. **Task Creation UI**
   - Add "Agent Preference" dropdown
   - Options: Auto (recommended), Fara-7B, Lux Actor, Lux Tasker, Lux Thinker
   - Show estimated cost and speed

2. **Execution Monitoring**
   - Live screenshot preview (what agent sees)
   - Action log (what agent does)
   - Progress indicator
   - Pause/Resume/Cancel buttons

3. **Agent Statistics**
   - Success rate per agent
   - Average execution time
   - Total cost (Lux API usage)
   - Cost savings from Fara-7B

4. **Settings Page**
   - Toggle Fara-7B on/off (if GPU unavailable)
   - Lux API key management
   - Privacy preferences (prefer local vs cloud)
   - Cost limits (max $ per day for Lux)

### Phase 5: Advanced Features (Week 7-8)

**Goal:** Production-ready system

1. **Fallback System**
   - If Lux fails → retry with Fara-7B
   - If Fara-7B fails → retry with Lux
   - Automatic error recovery

2. **Cost Optimization**
   - Track Lux API usage
   - Show cost breakdown per task
   - Alert when approaching budget limit
   - Suggest switching to Fara-7B for cost savings

3. **Performance Monitoring**
   - Benchmark Fara-7B vs Lux on same tasks
   - A/B testing for routing rules
   - Continuous improvement of routing logic

4. **Safety Layer**
   - Pre-execution approval for high-risk actions
   - Lux built-in safety + HAI approval queue
   - User-defined safety rules

---

## Database Schema Updates

### New Tables

**`ai_agents`** - Track available AI agents
```sql
CREATE TABLE ai_agents (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(50) NOT NULL, -- 'fara-7b', 'lux-actor', 'lux-tasker', 'lux-thinker'
  type VARCHAR(20) NOT NULL, -- 'browser', 'desktop', 'general'
  status VARCHAR(20) NOT NULL, -- 'available', 'unavailable', 'error'
  capabilities JSON, -- { browserControl: true, desktopControl: false, ... }
  costPerTask DECIMAL(10,4), -- NULL for free (Fara-7B), $ for Lux
  averageSuccessRate DECIMAL(5,2), -- 0-100%
  averageExecutionTime INT, -- seconds
  lastHealthCheck TIMESTAMP,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**`task_executions`** - Track task execution history
```sql
CREATE TABLE task_executions (
  id INT PRIMARY KEY AUTO_INCREMENT,
  taskId INT NOT NULL,
  agentId INT NOT NULL,
  status VARCHAR(20) NOT NULL, -- 'running', 'completed', 'failed', 'cancelled'
  startedAt TIMESTAMP,
  completedAt TIMESTAMP,
  duration INT, -- seconds
  cost DECIMAL(10,4), -- $ spent on Lux API
  screenshots JSON, -- Array of screenshot URLs
  actions JSON, -- Array of actions taken
  result TEXT, -- Final result or error message
  metadata JSON,
  FOREIGN KEY (taskId) REFERENCES tasks(id),
  FOREIGN KEY (agentId) REFERENCES ai_agents(id)
);
```

**`task_routing_decisions`** - Audit trail for routing logic
```sql
CREATE TABLE task_routing_decisions (
  id INT PRIMARY KEY AUTO_INCREMENT,
  taskId INT NOT NULL,
  analysis JSON, -- TaskAnalysis object
  selectedAgent VARCHAR(50) NOT NULL,
  routingReason TEXT, -- Why this agent was chosen
  manualOverride BOOLEAN DEFAULT FALSE,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (taskId) REFERENCES tasks(id)
);
```

### Updated Tables

**`tasks`** - Add agent routing fields
```sql
ALTER TABLE tasks ADD COLUMN agentType VARCHAR(50); -- 'fara', 'lux-actor', 'lux-tasker', 'lux-thinker'
ALTER TABLE tasks ADD COLUMN privacyLevel VARCHAR(20); -- 'sensitive', 'normal', 'public'
ALTER TABLE tasks ADD COLUMN estimatedCost DECIMAL(10,4); -- Estimated $ cost
ALTER TABLE tasks ADD COLUMN actualCost DECIMAL(10,4); -- Actual $ cost after execution
```

---

## Cost Analysis

### Fara-7B Costs
- **Model:** Free (open-source)
- **Hosting:** $0 (runs on user's PC)
- **Electricity:** ~$0.01/hour (GPU power consumption)
- **Total:** Essentially free

### Lux Costs
- **Free tier:** $10 credits (dozens of sessions)
- **Paid tier:** ~$0.10-$0.50 per task (estimated, 10x cheaper than OpenAI)
- **Total:** Pay-as-you-go

### Hybrid Savings Example

**Scenario:** User runs 100 tasks/month

**All Lux:**
- 100 tasks × $0.30 = $30/month

**Hybrid (70% Fara, 30% Lux):**
- 70 tasks × $0 (Fara) = $0
- 30 tasks × $0.30 (Lux) = $9/month
- **Savings:** $21/month (70% reduction)

**Hybrid (90% Fara, 10% Lux):**
- 90 tasks × $0 (Fara) = $0
- 10 tasks × $0.30 (Lux) = $3/month
- **Savings:** $27/month (90% reduction)

---

## Security & Privacy

### Fara-7B (Local)
✅ **Complete privacy** - All data stays on user's PC  
✅ **No internet required** - Offline execution  
✅ **No API keys** - No external authentication  
✅ **User control** - Full visibility into model behavior  

### Lux (Cloud/Edge)
⚠️ **Screenshots sent to cloud** - For analysis  
✅ **Built-in safety** - Refuses dangerous actions  
✅ **API key authentication** - Secure access  
✅ **Edge deployment option** - Intel partnership for on-device (future)  

### Hybrid Security Strategy
1. **Sensitive tasks** → Always use Fara-7B (local)
2. **Non-sensitive tasks** → Use Lux (cloud) for better performance
3. **User choice** → Allow manual override in settings
4. **Audit trail** → Log all routing decisions
5. **Transparency** → Show user which agent is used for each task

---

## Next Steps

### Immediate (This Week)
1. ✅ Research OpenAGI Lux capabilities
2. ✅ Design hybrid architecture
3. ⬜ Install Lux SDK and test basic execution
4. ⬜ Update HAI database schema
5. ⬜ Create Lux service wrapper

### Short-term (Next 2 Weeks)
6. ⬜ Build task routing system
7. ⬜ Integrate Lux into HAI dashboard
8. ⬜ Create execution monitoring UI
9. ⬜ Test Lux with real HAI tasks
10. ⬜ Implement cost tracking

### Medium-term (Month 2)
11. ⬜ Complete Fara-7B integration
12. ⬜ Build Python installer for desktop app
13. ⬜ Implement fallback system
14. ⬜ Add performance benchmarking
15. ⬜ Deploy to production

---

## Conclusion

The **hybrid Fara-7B + Lux architecture** gives HAI:

🎯 **Best Performance** - Lux for desktop apps, complex tasks  
💰 **Lowest Cost** - Fara-7B for simple, frequent tasks  
🔒 **Maximum Privacy** - Fara-7B for sensitive data  
⚡ **Optimal Speed** - Lux Actor for urgent tasks  
🛡️ **Built-in Safety** - Lux safety + HAI approval queue  
🔄 **Redundancy** - Fallback if one system fails  

This is the optimal architecture for HAI's autonomous household AI vision.
