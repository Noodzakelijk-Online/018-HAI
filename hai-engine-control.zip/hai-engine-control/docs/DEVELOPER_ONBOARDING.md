# HAI Engine Control Center - Developer Onboarding

## Project Overview

**HAI (Household AI)** is an autonomous AI assistant designed to operate as a **Master Orchestrator** for users' digital lives. It connects to all user accounts (Gmail, Calendar, banking, etc.), analyzes everything autonomously, identifies issues/opportunities, and takes action with minimal human intervention.

### Vision

Transform HAI from a web application into a **Windows 11 desktop application** that:
- Automatically installs all dependencies (Python, AI models, databases)
- Runs in the background with system tray integration
- Integrates **Fara-7B** (Microsoft's agentic AI model) for autonomous computer control
- Operates completely locally for privacy and control

---

## Current Architecture

### Tech Stack

**Frontend:**
- React 19 + TypeScript
- Tailwind CSS 4
- Wouter (routing)
- tRPC React Query (type-safe API)
- shadcn/ui components

**Backend:**
- Node.js 22 + Express 4
- tRPC 11 (end-to-end type safety)
- Drizzle ORM
- MySQL/TiDB database (currently)
- Better-sqlite3 (for desktop migration - in progress)

**Desktop (In Progress):**
- Electron (wrapper created, not yet functional)
- System tray integration (designed)
- Service manager for background processes (designed)

**AI Integration (Planned):**
- Fara-7B (Microsoft's 7B parameter agentic model for computer control)
- Playwright (browser automation for Fara-7B)
- vLLM (model serving)

---

## Project Structure

```
hai-engine-control/
├── client/                    # React frontend
│   ├── src/
│   │   ├── pages/            # Page components
│   │   │   ├── HAIDashboard.tsx        # Main dashboard
│   │   │   ├── MasterOrchestrator.tsx  # Central control hub
│   │   │   ├── Connectors.tsx          # Account connections (Gmail, Calendar)
│   │   │   └── ...
│   │   ├── components/       # Reusable UI components
│   │   │   ├── DashboardLayout.tsx     # Sidebar navigation layout
│   │   │   ├── ApprovalQueueWidget.tsx # Approval workflow UI
│   │   │   └── ui/                     # shadcn/ui components
│   │   ├── lib/trpc.ts      # tRPC client setup
│   │   └── App.tsx          # Routes and layout
│   └── index.html
│
├── server/                    # Node.js backend
│   ├── _core/                # Framework internals (OAuth, context, etc.)
│   │   ├── index.ts         # Express server entry point
│   │   ├── oauth.ts         # Manus OAuth integration
│   │   ├── trpc.ts          # tRPC setup
│   │   └── llm.ts           # LLM integration helper
│   ├── api/
│   │   ├── routers/         # tRPC routers
│   │   │   ├── connectors.ts          # Account connector management
│   │   │   ├── orchestrator.ts        # Master Orchestrator logic
│   │   │   ├── approvalQueue.ts       # Approval workflow
│   │   │   └── ...
│   │   └── routes/          # Express routes (OAuth callbacks)
│   │       └── googleOAuth.ts         # Google OAuth flow
│   ├── services/
│   │   ├── orchestratorEngine.ts      # Analysis engine
│   │   ├── googleOAuthService.ts      # Google OAuth client
│   │   └── workers/                   # Background jobs
│   │       ├── EmailMonitorWorker.ts  # Email monitoring
│   │       └── WorkerManager.ts       # Job scheduler
│   ├── db.ts                # Database connection & queries
│   └── routers.ts           # Main tRPC router
│
├── drizzle/                  # Database schema
│   └── schema.ts            # Drizzle ORM schema (MySQL currently)
│
├── electron/                 # Desktop app (IN PROGRESS)
│   ├── main.ts              # Electron main process
│   ├── preload.ts           # IPC bridge
│   ├── tray.ts              # System tray menu
│   └── services/
│       └── serviceManager.ts # Backend/Fara-7B service manager
│
├── docs/                     # Documentation
│   ├── fara-7b-research.md           # Fara-7B capabilities & API
│   ├── fara-7b-architecture.md       # Integration design
│   └── desktop-app-architecture.md   # Desktop app design
│
└── todo.md                   # Feature tracking
```

---

## Key Features (Implemented)

### 1. **HAI Dashboard**
- **Location:** `client/src/pages/HAIDashboard.tsx`
- **Purpose:** Main control center showing AI activities, statistics, timeline
- **Features:**
  - Activity statistics (emails sent, events created, decisions made)
  - Timeline of autonomous actions grouped by time of day
  - Household selector for multi-household support
  - Approval queue widget for critical decisions

### 2. **Master Orchestrator**
- **Location:** `client/src/pages/MasterOrchestrator.tsx`, `server/services/orchestratorEngine.ts`
- **Purpose:** Central AI brain that analyzes all connected accounts
- **Features:**
  - System status monitoring (connected accounts, active agents)
  - Intelligent insights with priority-based recommendations
  - Account type cards (Email, Calendar, Financial, Documents)
  - Quick actions for common operations

### 3. **Account Connectors (ServiceHub)**
- **Location:** `client/src/pages/Connectors.tsx`, `server/api/routers/connectors.ts`
- **Purpose:** Connect user accounts (Gmail, Google Calendar, etc.)
- **Features:**
  - OAuth integration for Gmail and Calendar
  - Service templates for quick setup
  - Connection status monitoring
  - Privacy controls (data type selection, sync frequency)

### 4. **Approval Queue**
- **Location:** `client/src/components/ApprovalQueueWidget.tsx`, `server/api/routers/approvalQueue.ts`
- **Purpose:** Human-in-the-loop for high-stakes decisions
- **Features:**
  - Pending approval items with context
  - Approve/reject workflow
  - Priority-based sorting
  - Expiration handling

### 5. **Background Workers**
- **Location:** `server/services/workers/`
- **Purpose:** Autonomous monitoring and action execution
- **Features:**
  - Email monitoring (EmailMonitorWorker)
  - Approval queue cleanup
  - Job scheduling and retry logic

---

## Key Features (Planned/In Progress)

### 6. **Fara-7B Integration** 🚧
- **Status:** Research complete, implementation pending
- **Purpose:** Enable HAI to autonomously control the user's computer
- **Capabilities:**
  - Browser automation (click, type, navigate)
  - Multi-step task execution
  - Visual understanding (screenshots)
  - Decision-making with Critical Point detection
- **Tech:** Fara-7B model + vLLM + Playwright
- **Docs:** `docs/fara-7b-research.md`, `docs/fara-7b-architecture.md`

### 7. **Desktop Application** 🚧
- **Status:** Electron wrapper created, not functional yet
- **Purpose:** Package HAI as a Windows 11 desktop app
- **Features:**
  - System tray integration
  - Background operation
  - Automatic dependency installation (Python, Fara-7B, database)
  - Service management (backend, Fara-7B, database)
- **Blocker:** Database migration from MySQL to SQLite (215 TypeScript errors)
- **Docs:** `docs/desktop-app-architecture.md`

### 8. **Autonomous Actions** 🚧
- **Status:** Architecture designed, not implemented
- **Purpose:** Execute actions based on Master Orchestrator analysis
- **Examples:**
  - Send email responses
  - Schedule calendar events
  - Resolve scheduling conflicts
  - Categorize and archive emails
- **Integration:** Connects Orchestrator Engine → Action Queue → Connectors

---

## Database Schema (Key Tables)

### Core Tables

**`users`** - User accounts with Manus OAuth
- `id`, `openId`, `name`, `email`, `role` (admin/user)
- 2FA support, password reset, account locking

**`households`** - Multi-household support
- `id`, `name`, `settings` (JSON)

**`household_members`** - User-household relationships
- `householdId`, `userId`, `role` (owner/member)

**`connectors`** - Connected accounts (Gmail, Calendar, etc.)
- `connectorType` (gmail, calendar, financial, documents)
- `status` (connected, pending_auth, error)
- `accessToken`, `refreshToken`, `tokenExpiresAt` (OAuth)
- `syncSettings` (privacy controls)

**`approval_queue`** - Pending decisions
- `type` (email_response, calendar_event, task_execution, decision)
- `suggestedAction`, `reasoning`, `confidence`
- `status` (pending, approved, rejected, expired)
- `priority` (low, medium, high, urgent)

**`events`** - Event sourcing for AI actions
- `eventType`, `source`, `target`, `payload`
- `metadata` (timestamp, userId, priority, correlationId)

**`agents`** - Distributed AI agents
- `agentId`, `type`, `status`, `capabilities`
- `lastHeartbeat` (health monitoring)

---

## Current State & Blockers

### ✅ Working
1. **Web application** - Fully functional at `https://3000-***.manusvm.computer/`
2. **Dashboard UI** - Clean, modern design with statistics and timeline
3. **Master Orchestrator page** - System status and insights
4. **Google OAuth** - Gmail/Calendar connection flow (frontend + backend)
5. **Approval Queue** - Widget integrated into dashboard
6. **Background workers** - Email monitoring, job scheduling

### 🚧 In Progress
1. **Desktop application** - Electron wrapper created but not functional
2. **SQLite migration** - Attempted but rolled back (215 TS errors)
3. **Fara-7B integration** - Research complete, implementation pending

### ❌ Blockers
1. **Database migration** - MySQL → SQLite conversion broke TypeScript types
   - **Impact:** Desktop app cannot use MySQL (requires local database)
   - **Options:**
     a. Fix 215 TypeScript errors (time-consuming)
     b. Use embedded MySQL/MariaDB instead of SQLite
     c. Implement hybrid approach (MySQL for web, SQLite for desktop)

2. **Electron build** - Cannot test desktop app until database is resolved

3. **Fara-7B deployment** - Need to decide:
   - Azure Foundry (cloud, costs money)
   - Self-hosted vLLM (local, requires GPU)
   - Hybrid (cloud for testing, local for production)

---

## Technical Decisions & Patterns

### 1. **tRPC for Type Safety**
- **Pattern:** Define procedures in `server/routers.ts`, consume with `trpc.*.useQuery/useMutation`
- **Benefit:** End-to-end type safety, no manual API contracts
- **Example:**
  ```typescript
  // Server
  export const appRouter = router({
    approvalQueue: router({
      getPending: protectedProcedure
        .input(z.object({ householdId: z.number() }))
        .query(({ input }) => getApprovalQueue(input.householdId))
    })
  });
  
  // Client
  const { data } = trpc.approvalQueue.getPending.useQuery({ householdId: 1 });
  ```

### 2. **Drizzle ORM**
- **Pattern:** Schema-first, type-safe SQL queries
- **Benefit:** TypeScript types generated from schema
- **Migration:** `pnpm db:push` (schema → database)

### 3. **Event Sourcing**
- **Pattern:** All AI actions logged as events in `events` table
- **Benefit:** Audit trail, replay capability, analytics
- **Schema:** `eventType`, `source`, `target`, `payload`, `metadata`

### 4. **Background Workers**
- **Pattern:** `WorkerManager` schedules jobs, workers execute
- **Benefit:** Autonomous operation, retry logic, error handling
- **Example:** `EmailMonitorWorker` checks Gmail every 5 minutes

### 5. **Approval Workflow**
- **Pattern:** Critical decisions → approval queue → user approval → action execution
- **Benefit:** Human-in-the-loop for high-stakes decisions
- **Trigger:** Low confidence (<70%), high impact, or policy violation

---

## Development Workflow

### Setup
```bash
cd /home/ubuntu/hai-engine-control
pnpm install                    # Install dependencies
pnpm db:push                    # Push schema to database
pnpm dev                        # Start dev server (port 3000)
```

### Key Commands
```bash
pnpm dev                        # Start development server
pnpm build                      # Build for production
pnpm db:push                    # Push schema changes to database
pnpm vitest                     # Run tests
pnpm build:electron             # Compile Electron (not working yet)
pnpm electron:dev               # Start Electron app (not working yet)
```

### Environment Variables
```bash
DATABASE_URL                    # MySQL connection string (auto-injected)
GOOGLE_OAUTH_CLIENT_ID          # Google OAuth credentials
GOOGLE_OAUTH_CLIENT_SECRET      # Google OAuth credentials
JWT_SECRET                      # Session signing
VITE_APP_TITLE                  # App branding
VITE_APP_LOGO                   # App logo URL
```

### Testing
- **Unit tests:** `server/__tests__/*.test.ts` (vitest)
- **Integration tests:** Test OAuth flow, database operations
- **Manual testing:** Use browser at `https://3000-***.manusvm.computer/`

---

## Next Steps (Priority Order)

### Immediate (Week 1-2)

1. **Resolve Database Strategy** 🔥
   - **Decision needed:** SQLite vs Embedded MySQL vs Hybrid
   - **Impact:** Blocks desktop app development
   - **Recommendation:** Use embedded MySQL (MariaDB) to avoid breaking changes

2. **Complete Electron Integration**
   - Fix database connection in Electron context
   - Test system tray and service manager
   - Create basic installer (NSIS)

3. **Build Python/Fara-7B Installer**
   - Download embedded Python 3.11
   - Install PyTorch, vLLM, Playwright
   - Download Fara-7B model (14GB)
   - Show progress UI in Electron window

### Short-term (Week 3-4)

4. **Implement Fara-7B Integration**
   - Create task queue system (database schema + API)
   - Build Fara-7B service wrapper (start/stop/monitor)
   - Implement browser automation interface
   - Add Critical Point detection for safety

5. **Build Autonomous Action System**
   - Connect Master Orchestrator → Action Queue
   - Implement action executors (email, calendar, etc.)
   - Add retry logic and error handling
   - Integrate with approval workflow

### Medium-term (Month 2)

6. **Desktop App Polish**
   - Auto-start on Windows boot
   - Update notifications
   - Settings UI (preferences, privacy controls)
   - Uninstaller

7. **Financial Account Integration**
   - Research banking APIs (Plaid, Yodlee)
   - Implement OAuth flow
   - Add transaction monitoring
   - Expense categorization

8. **Document Management**
   - Google Drive integration
   - Dropbox integration
   - Local file monitoring
   - Document search and organization

---

## Known Issues

### TypeScript Errors (Non-blocking)
- **EmailMonitorWorker.ts:** Event type mismatch (missing `target` field)
- **WorkerManager.ts:** MapIterator requires `--downlevelIteration` flag
- **Total:** ~27 errors (not breaking, just warnings)

### Database Connection Errors (Intermittent)
- **Symptom:** "read ECONNRESET" or "connect ETIMEDOUT"
- **Cause:** MySQL connection pool exhaustion or network issues
- **Workaround:** Restart server, check DATABASE_URL

### Connectors Page (Fixed)
- **Issue:** React hooks error from calling hooks in loop
- **Fix:** Removed `useQuery` calls from `.map()` iteration
- **Status:** ✅ Resolved

### SQLite Migration (Rolled Back)
- **Issue:** 215 TypeScript errors from schema conversion
- **Cause:** MySQL types (timestamp, enum, json) incompatible with SQLite
- **Status:** ❌ Rolled back, needs different approach

---

## Architecture Diagrams

### Current System Flow
```
User Browser
    ↓
React Frontend (tRPC Client)
    ↓
Express Server (tRPC Server)
    ↓
┌─────────────┬──────────────┬─────────────┐
│  Routers    │  Services    │  Workers    │
│  (API)      │  (Logic)     │  (Jobs)     │
└─────────────┴──────────────┴─────────────┘
    ↓
MySQL Database (Drizzle ORM)
    ↓
Connected Accounts (Gmail, Calendar via OAuth)
```

### Target Desktop Architecture
```
Windows 11 Desktop
    ↓
Electron App (System Tray)
    ↓
┌──────────────┬───────────────┬──────────────┐
│  Frontend    │  Backend      │  Fara-7B     │
│  (React)     │  (Express)    │  (vLLM)      │
└──────────────┴───────────────┴──────────────┘
    ↓
SQLite/Embedded MySQL (Local Database)
    ↓
┌──────────────┬───────────────┬──────────────┐
│  Gmail       │  Calendar     │  Browser     │
│  (OAuth)     │  (OAuth)      │  (Playwright)│
└──────────────┴───────────────┴──────────────┘
```

---

## Resources

### Documentation
- **Fara-7B Research:** `docs/fara-7b-research.md`
- **Desktop Architecture:** `docs/desktop-app-architecture.md`
- **TODO Tracking:** `todo.md`

### External Links
- **Fara-7B Paper:** https://www.microsoft.com/en-us/research/blog/fara-7b-an-efficient-agentic-model-for-computer-use/
- **Fara-7B Model:** https://huggingface.co/microsoft/Fara-7B
- **Drizzle ORM Docs:** https://orm.drizzle.team/
- **tRPC Docs:** https://trpc.io/
- **Electron Docs:** https://www.electronjs.org/

### Current Checkpoint
- **Version:** `6f08b573` (after SQLite rollback)
- **URL:** `manus-webdev://6f08b573`
- **Status:** Stable, all features working

---

## Questions for New Developer

1. **Database Strategy:** SQLite (fix 215 errors) vs Embedded MySQL (easier) vs Hybrid (complex)?
2. **Fara-7B Deployment:** Cloud (Azure Foundry) vs Local (vLLM) vs Hybrid?
3. **Priority:** Desktop app first or Fara-7B integration first?
4. **Timeline:** What's the target launch date for MVP?

---

## Contact & Collaboration

- **Project Owner:** [Your Name]
- **New Developer:** [Developer Name]
- **Repository:** `/home/ubuntu/hai-engine-control`
- **Live Demo:** `https://3000-izc4rc5ce22ox3gm7qpja-d0a8cd11.manusvm.computer/`

Welcome to the team! 🚀
