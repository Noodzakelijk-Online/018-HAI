# OpenAGI Lux - Quick Start Guide for HAI

**Purpose:** Get Lux SDK working in HAI desktop application  
**Time:** 30 minutes  
**Prerequisites:** Python 3.10+, Windows 11

---

## Step 1: Install Lux SDK

```bash
# Navigate to HAI project
cd /home/ubuntu/hai-engine-control

# Install OpenAGI SDK
pip install oagi
```

This installs the complete SDK including:
- Desktop automation
- Server capabilities  
- All dependencies

---

## Step 2: Get API Key

1. Visit https://developer.agiopen.org/
2. Sign in (creates account if needed)
3. Click "Create an API Key"
4. Give it a name (e.g., "HAI Desktop App")
5. Copy the key (starts with `sk-`)
6. **Store securely** - treat like a password

**Free Credits:** New users get $10 in credits (dozens of agent sessions)

---

## Step 3: Configure Environment

```bash
# Set API key
export OAGI_API_KEY=sk-your-key-here
export OAGI_BASE_URL=https://api.agiopen.org
```

For Windows (PowerShell):
```powershell
$env:OAGI_API_KEY="sk-your-key-here"
$env:OAGI_BASE_URL="https://api.agiopen.org"
```

---

## Step 4: Enable Permissions

```bash
# Request screen recording and accessibility permissions
oagi agent permission
```

**Windows Users:**
- Allow screen recording when prompted
- Allow accessibility access when prompted
- Restart terminal if needed

---

## Step 5: Test Basic Execution

```bash
# Run a simple task
oagi agent run "Go to https://agiopen.org" --model "lux-actor-1"
```

**What happens:**
1. Agent takes screenshot of your screen
2. Lux analyzes the visual interface
3. Agent predicts keyboard/mouse actions
4. Agent executes actions (opens browser, navigates)
5. Real-time feedback in terminal

---

## Step 6: Test Different Modes

### Actor (Fast - seconds)
```bash
oagi agent run "Find Apple's stock price on Google" --model "lux-actor-1"
```

### Tasker (Stable - minutes)
```bash
oagi agent run "Fill out contact form at example.com with test data" --model "lux-tasker-1"
```

### Thinker (Complex - hours)
```bash
oagi agent run "Research top 3 CRM tools and create comparison" --model "lux-thinker-1"
```

---

## Step 7: Integrate into HAI

### Create Lux Service Wrapper

**File:** `server/services/luxAgent.ts`

```typescript
import { spawn } from 'child_process';

export interface LuxTask {
  goal: string;
  model: 'lux-actor-1' | 'lux-tasker-1' | 'lux-thinker-1';
}

export interface LuxResult {
  success: boolean;
  output: string;
  screenshots: string[];
  actions: any[];
  duration: number;
  cost: number;
  error?: string;
}

export async function executeLuxTask(task: LuxTask): Promise<LuxResult> {
  const startTime = Date.now();
  
  return new Promise((resolve, reject) => {
    // Spawn oagi CLI process
    const process = spawn('oagi', [
      'agent',
      'run',
      task.goal,
      '--model',
      task.model,
      '--output-format',
      'json'
    ], {
      env: {
        ...process.env,
        OAGI_API_KEY: process.env.OAGI_API_KEY,
        OAGI_BASE_URL: process.env.OAGI_BASE_URL
      }
    });
    
    let stdout = '';
    let stderr = '';
    
    process.stdout.on('data', (data) => {
      stdout += data.toString();
    });
    
    process.stderr.on('data', (data) => {
      stderr += data.toString();
    });
    
    process.on('close', (code) => {
      const duration = Date.now() - startTime;
      
      if (code === 0) {
        try {
          const result = JSON.parse(stdout);
          resolve({
            success: true,
            output: result.output,
            screenshots: result.screenshots || [],
            actions: result.actions || [],
            duration: duration / 1000, // Convert to seconds
            cost: result.cost || 0
          });
        } catch (error) {
          resolve({
            success: true,
            output: stdout,
            screenshots: [],
            actions: [],
            duration: duration / 1000,
            cost: 0
          });
        }
      } else {
        reject({
          success: false,
          output: '',
          screenshots: [],
          actions: [],
          duration: duration / 1000,
          cost: 0,
          error: stderr || `Process exited with code ${code}`
        });
      }
    });
  });
}

export async function checkLuxStatus(): Promise<boolean> {
  try {
    const result = await executeLuxTask({
      goal: 'test',
      model: 'lux-actor-1'
    });
    return result.success;
  } catch {
    return false;
  }
}
```

### Create Lux Router

**File:** `server/api/routers/lux.ts`

```typescript
import { z } from 'zod';
import { router, protectedProcedure } from '../../_core/trpc';
import { executeLuxTask, checkLuxStatus } from '../../services/luxAgent';

export const luxRouter = router({
  execute: protectedProcedure
    .input(z.object({
      goal: z.string(),
      model: z.enum(['lux-actor-1', 'lux-tasker-1', 'lux-thinker-1'])
    }))
    .mutation(async ({ input }) => {
      const result = await executeLuxTask(input);
      
      // TODO: Save execution to database (task_executions table)
      
      return result;
    }),
    
  checkStatus: protectedProcedure
    .query(async () => {
      const isAvailable = await checkLuxStatus();
      return { available: isAvailable };
    })
});
```

### Update Main Router

**File:** `server/routers.ts`

```typescript
import { luxRouter } from './api/routers/lux';

export const appRouter = router({
  // ... existing routers
  lux: luxRouter,
});
```

### Create UI Component

**File:** `client/src/components/LuxExecutor.tsx`

```typescript
import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select } from '@/components/ui/select';

export function LuxExecutor() {
  const [goal, setGoal] = useState('');
  const [model, setModel] = useState<'lux-actor-1' | 'lux-tasker-1' | 'lux-thinker-1'>('lux-actor-1');
  
  const executeMutation = trpc.lux.execute.useMutation();
  
  const handleExecute = async () => {
    const result = await executeMutation.mutateAsync({ goal, model });
    console.log('Lux result:', result);
  };
  
  return (
    <div className="space-y-4">
      <Textarea
        placeholder="What should Lux do? (e.g., Go to Google and search for OpenAGI)"
        value={goal}
        onChange={(e) => setGoal(e.target.value)}
      />
      
      <Select value={model} onChange={(e) => setModel(e.target.value as any)}>
        <option value="lux-actor-1">Actor (Fast - seconds)</option>
        <option value="lux-tasker-1">Tasker (Stable - minutes)</option>
        <option value="lux-thinker-1">Thinker (Complex - hours)</option>
      </Select>
      
      <Button onClick={handleExecute} disabled={executeMutation.isLoading}>
        {executeMutation.isLoading ? 'Executing...' : 'Execute with Lux'}
      </Button>
      
      {executeMutation.data && (
        <div className="mt-4 p-4 bg-gray-100 rounded">
          <h3>Result:</h3>
          <pre>{JSON.stringify(executeMutation.data, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}
```

---

## Step 8: Test HAI Integration

1. Start HAI dev server
   ```bash
   pnpm dev
   ```

2. Open browser to HAI dashboard

3. Navigate to Lux Executor page

4. Enter a simple goal: "Go to https://agiopen.org"

5. Select "Actor" mode

6. Click "Execute with Lux"

7. Watch the agent work!

---

## Troubleshooting

### "Permission denied" error
- Run `oagi agent permission` again
- Restart terminal
- Check Windows privacy settings

### "API key invalid" error
- Verify `OAGI_API_KEY` is set correctly
- Check key starts with `sk-`
- Get new key from https://developer.agiopen.org/

### "Model not found" error
- Verify model name is correct: `lux-actor-1`, `lux-tasker-1`, or `lux-thinker-1`
- Check API base URL is `https://api.agiopen.org`

### Agent not taking actions
- Ensure screen is visible (not locked)
- Close overlapping windows
- Use single monitor (primary screen)

---

## Next Steps

1. ✅ Lux SDK installed and working
2. ⬜ Integrate with HAI task queue
3. ⬜ Add task routing logic (Fara vs Lux)
4. ⬜ Build execution monitoring UI
5. ⬜ Implement cost tracking
6. ⬜ Add approval workflow for high-stakes tasks

---

## Resources

- **Lux Documentation:** https://developer.agiopen.org/docs/
- **Discord Community:** https://discord.gg/openagi
- **API Reference:** https://developer.agiopen.org/docs/api
- **Examples:** https://lux.agiopen.org/use-cases
