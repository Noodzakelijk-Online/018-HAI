# HAI Engine Control - Production Deployment Guide

**Version:** 1.0  
**Last Updated:** December 6, 2025  
**Author:** Manus AI

---

## Overview

This document provides comprehensive instructions for deploying HAI Engine Control Center to production environments. The system features a hybrid AI architecture combining local Fara-7B processing with cloud-based OpenAGI Lux execution, enabling autonomous computer control with optimal privacy and performance.

---

## Architecture Summary

HAI Engine Control operates as a **desktop application** with three primary components:

**Frontend Layer** - React 19 application with real-time WebSocket communication, providing dashboard interfaces for task management, agent monitoring, and system configuration.

**Backend Layer** - Node.js Express server with tRPC endpoints, handling authentication via Manus OAuth, database operations through Drizzle ORM, and orchestration of AI agents.

**AI Layer** - Hybrid execution environment routing tasks between Fara-7B (local, privacy-focused) and OpenAGI Lux (cloud, high-performance) based on task characteristics and user preferences.

---

## Prerequisites

### System Requirements

**Operating System:** Windows 10/11 (64-bit) for desktop deployment, or Linux (Ubuntu 22.04+) for server deployment.

**Hardware Minimum:** 16GB RAM, 4-core CPU, 50GB available storage, GPU with 8GB VRAM (recommended for Fara-7B local execution).

**Software Dependencies:** Node.js 22.x, Python 3.11+, MySQL 8.0+ or compatible database (TiDB Cloud supported), Redis 7.0+ (optional, for production queue management).

### Required Accounts

**Manus Platform** - Active account with OAuth application configured at https://manus.im for authentication services.

**OpenAGI Developer** - API key from https://developer.agiopen.org for Lux cloud execution (free tier includes $10 credits).

**Email Provider** - Gmail or Outlook OAuth credentials for email connector integration.

**Calendar Provider** - Google Calendar OAuth credentials for calendar automation features.

---

## Installation Steps

### Step 1: Clone and Install Dependencies

Navigate to your desired installation directory and execute the following commands:

```bash
git clone <repository-url> hai-engine-control
cd hai-engine-control
pnpm install
```

The installation process will download all Node.js dependencies including React, Express, tRPC, Drizzle ORM, and supporting libraries. This typically requires 5-10 minutes depending on network speed.

### Step 2: Configure Environment Variables

Create a `.env` file in the project root directory with the following configuration:

```env
# Database Configuration
DATABASE_URL=mysql://user:password@host:port/database

# Manus OAuth
VITE_APP_ID=your_manus_app_id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://oauth.manus.im
JWT_SECRET=your_jwt_secret_key

# OpenAGI Lux
OAGI_API_KEY=your_openagi_api_key
OAGI_BASE_URL=https://api.agiopen.org

# Fara-7B (Optional - for local AI)
FARA_MODEL_PATH=/path/to/fara-7b-model
FARA_ENABLED=true

# Redis (Optional - for production queue)
REDIS_URL=redis://localhost:6379

# Application Settings
NODE_ENV=production
PORT=3000
VITE_APP_TITLE=HAI Engine Control
VITE_APP_LOGO=https://your-cdn.com/logo.png
```

**Security Note:** Never commit the `.env` file to version control. Use environment-specific configuration management tools like AWS Secrets Manager or Azure Key Vault for production deployments.

### Step 3: Database Setup

Execute database migrations to create required tables:

```bash
pnpm db:push
```

This command applies the schema defined in `drizzle/schema.ts`, creating tables for users, tasks, agents, connectors, households, approvals, and AI execution tracking.

**Important:** The migration process may prompt for confirmation when modifying existing tables. Review changes carefully before proceeding in production environments.

### Step 4: Build Application

Generate production-optimized builds for both frontend and backend:

```bash
pnpm build
```

The build process performs TypeScript compilation, React optimization with code splitting, and asset bundling. Output files are placed in `dist/` directory.

### Step 5: Start Production Server

Launch the application server:

```bash
pnpm start
```

The server initializes on the configured PORT (default 3000) and establishes database connections, WebSocket listeners, and background worker processes for email monitoring and approval queue management.

---

## Fara-7B Local Installation

For privacy-sensitive deployments requiring local AI execution, install Microsoft's Fara-7B model:

### Download Model Files

Obtain Fara-7B weights from Microsoft Research (approximately 14GB):

```bash
# Create model directory
mkdir -p /opt/hai/models

# Download via Hugging Face (requires authentication)
huggingface-cli download microsoft/fara-7b --local-dir /opt/hai/models/fara-7b
```

### Install Python Dependencies

Create isolated Python environment and install required packages:

```bash
python3.11 -m venv /opt/hai/venv
source /opt/hai/venv/bin/activate
pip install fara-7b playwright torch transformers
playwright install chromium
```

### Configure HAI Integration

Update environment variables to enable Fara-7B:

```env
FARA_MODEL_PATH=/opt/hai/models/fara-7b
FARA_ENABLED=true
PYTHON_PATH=/opt/hai/venv/bin/python
```

The system automatically routes browser automation tasks to Fara-7B when enabled, falling back to Lux for desktop application control.

---

## OpenAGI Lux Configuration

Cloud-based AI execution requires minimal setup:

### Obtain API Key

Register at https://developer.agiopen.org and create new API key from dashboard. Free tier includes $10 credits (approximately 100-200 task executions).

### Configure Execution Modes

Lux supports three execution modes optimized for different scenarios:

**Actor Mode** - Fastest execution (1-2 seconds), suitable for simple tasks like clicking buttons or filling forms. Recommended for real-time user interactions.

**Tasker Mode** - Balanced performance (5-10 seconds), handles multi-step workflows with contextual understanding. Default mode for most automation tasks.

**Thinker Mode** - Comprehensive analysis (15-30 seconds), provides detailed planning and error recovery. Best for complex, high-stakes operations.

Configure default mode in `server/services/luxAgent.ts` or allow dynamic selection via task routing system.

---

## Desktop Application Packaging

Convert web application to standalone desktop executable:

### Electron Build Configuration

The project includes Electron wrapper in `electron/` directory. Configure build settings in `electron-builder.yml`:

```yaml
appId: com.hai.engine-control
productName: HAI Engine Control
directories:
  buildResources: electron/resources
  output: dist-electron
win:
  target:
    - nsis
    - portable
  icon: electron/resources/icon.ico
nsis:
  oneClick: false
  allowToChangeInstallationDirectory: true
  createDesktopShortcut: true
  createStartMenuShortcut: true
```

### Bundle Python Runtime

Include Python interpreter and AI models in installer:

```bash
# Download embedded Python
wget https://www.python.org/ftp/python/3.11.0/python-3.11.0-embed-amd64.zip
unzip python-3.11.0-embed-amd64.zip -d electron/resources/python

# Copy Fara-7B model (if using local AI)
cp -r /opt/hai/models/fara-7b electron/resources/models/
```

### Build Installer

Generate Windows installer:

```bash
pnpm electron:build
```

Output includes NSIS installer (`.exe`) and portable version in `dist-electron/` directory. Installer size ranges from 200MB (without Fara-7B) to 15GB (with local AI models).

---

## Production Optimizations

### Database Indexing

Add performance indexes for frequently queried tables:

```sql
CREATE INDEX idx_tasks_status ON tasks(status, priority);
CREATE INDEX idx_tasks_user ON tasks(userId, createdAt);
CREATE INDEX idx_connectors_type ON connectors(connectorType, status);
CREATE INDEX idx_events_timestamp ON hai_events(timestamp);
CREATE INDEX idx_approvals_status ON approval_queue(status, expiresAt);
```

These indexes significantly improve dashboard load times and task filtering performance.

### Redis Queue Configuration

For high-volume deployments, enable Redis-backed task queue:

```bash
# Install Redis
docker run -d --name redis -p 6379:6379 redis:7-alpine

# Install BullMQ
pnpm add bullmq ioredis
```

Update `server/services/taskQueue.ts` to use Redis instead of in-memory queue, enabling distributed processing and automatic retry mechanisms.

### CDN Integration

Serve static assets via Content Delivery Network:

```bash
# Upload build assets to S3
aws s3 sync dist/assets s3://your-bucket/hai-assets --acl public-read

# Update Vite config for CDN base URL
# vite.config.ts
export default defineConfig({
  base: 'https://cdn.example.com/hai-assets/'
})
```

CDN distribution reduces latency for global users and offloads bandwidth from application servers.

---

## Security Hardening

### Enable Security Headers

Apply security middleware in Express server:

```typescript
import { securityHeadersMiddleware } from './server/_core/securityHeaders';

app.use(securityHeadersMiddleware);
```

This configures Content Security Policy, HSTS, X-Frame-Options, and other protective headers preventing common web vulnerabilities.

### Configure Rate Limiting

Protect API endpoints from abuse:

```typescript
import { rateLimiterMiddleware } from './server/_core/rateLimiter';

app.use('/api', rateLimiterMiddleware);
```

Default configuration allows 100 requests per minute per IP address, with exponential backoff for repeated violations.

### Enable End-to-End Encryption

Encrypt sensitive data at rest:

```typescript
import { encryptData, decryptData } from './server/services/encryption';

// Encrypt before database storage
const encrypted = await encryptData(sensitiveData, userKey);

// Decrypt when retrieving
const decrypted = await decryptData(encrypted, userKey);
```

Encryption uses AES-256-GCM with PBKDF2 key derivation, ensuring zero-knowledge architecture where server cannot access user data without encryption keys.

---

## Monitoring and Observability

### Application Logging

Configure structured logging with Winston:

```typescript
import winston from 'winston';

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [
    new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
    new winston.transports.File({ filename: 'logs/combined.log' })
  ]
});
```

Logs capture authentication events, task executions, AI agent decisions, and system errors for debugging and audit trails.

### Performance Monitoring

Integrate application performance monitoring:

```bash
# Install Datadog APM
pnpm add dd-trace

# Initialize at application entry
require('dd-trace').init({
  service: 'hai-engine-control',
  env: 'production'
});
```

APM provides real-time visibility into request latency, database query performance, and AI execution times.

### Health Checks

Implement health check endpoint for load balancers:

```typescript
app.get('/health', async (req, res) => {
  const dbHealthy = await checkDatabaseConnection();
  const redisHealthy = await checkRedisConnection();
  
  res.status(dbHealthy && redisHealthy ? 200 : 503).json({
    status: dbHealthy && redisHealthy ? 'healthy' : 'degraded',
    database: dbHealthy,
    redis: redisHealthy,
    timestamp: new Date().toISOString()
  });
});
```

---

## Backup and Recovery

### Database Backups

Schedule automated backups:

```bash
# Daily backup script
#!/bin/bash
BACKUP_DIR=/var/backups/hai
DATE=$(date +%Y%m%d_%H%M%S)

mysqldump -u user -p database > $BACKUP_DIR/hai_$DATE.sql
gzip $BACKUP_DIR/hai_$DATE.sql

# Retain last 30 days
find $BACKUP_DIR -name "hai_*.sql.gz" -mtime +30 -delete
```

Store backups in geographically distributed locations (S3 with cross-region replication recommended).

### Disaster Recovery

Document recovery procedures:

**RTO (Recovery Time Objective):** 4 hours  
**RPO (Recovery Point Objective):** 24 hours

Recovery steps involve restoring latest database backup, redeploying application from version control, and reconfiguring environment variables from secure storage.

---

## Troubleshooting

### Common Issues

**Issue:** TypeScript compilation errors during build  
**Solution:** Clear node_modules and reinstall dependencies: `rm -rf node_modules && pnpm install`

**Issue:** Database connection failures  
**Solution:** Verify DATABASE_URL format and network connectivity. Check firewall rules allow MySQL port 3306.

**Issue:** OAuth authentication redirects fail  
**Solution:** Ensure callback URL registered in Manus OAuth application matches deployed domain.

**Issue:** Lux API returns 401 Unauthorized  
**Solution:** Verify OAGI_API_KEY is valid and not expired. Check API key permissions in OpenAGI dashboard.

**Issue:** Fara-7B model fails to load  
**Solution:** Confirm FARA_MODEL_PATH points to valid model directory and Python environment has required dependencies.

### Support Resources

**Documentation:** https://docs.hai-engine.com  
**Community Forum:** https://community.hai-engine.com  
**GitHub Issues:** https://github.com/hai-engine/control/issues  
**Email Support:** support@hai-engine.com

---

## Conclusion

Following this deployment guide ensures HAI Engine Control operates reliably in production environments. The hybrid AI architecture provides flexibility to balance privacy, performance, and cost based on organizational requirements. Regular monitoring and maintenance keep the system secure and performant as usage scales.

For advanced deployment scenarios including Kubernetes orchestration, multi-region distribution, or enterprise SSO integration, consult the Enterprise Deployment Guide or contact support for customized assistance.

---

**Document Version:** 1.0  
**Next Review:** March 2026
