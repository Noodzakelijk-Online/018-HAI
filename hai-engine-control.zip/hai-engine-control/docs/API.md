# HAI Engine Control - API Documentation

**Version:** 1.0  
**Last Updated:** December 6, 2025  
**Author:** Manus AI

---

## Overview

HAI Engine Control exposes a type-safe API through tRPC, enabling frontend-backend communication with automatic TypeScript type inference. All endpoints require authentication via Manus OAuth unless explicitly marked as public.

**Base URL:** `https://your-domain.com/api/trpc`  
**Protocol:** HTTP/HTTPS with JSON payloads  
**Authentication:** JWT tokens in HTTP-only cookies

---

## Authentication Endpoints

### Get Current User

Retrieves authenticated user information including profile details and permissions.

**Endpoint:** `auth.me`  
**Method:** Query  
**Authentication:** Required

**Response:**

```typescript
{
  id: number;
  openId: string;
  name: string | null;
  email: string | null;
  role: 'admin' | 'user';
  createdAt: Date;
  lastSignedIn: Date;
}
```

**Example Usage:**

```typescript
const { data: user } = trpc.auth.me.useQuery();
console.log(user?.name); // "John Doe"
```

### Logout

Terminates current session and clears authentication cookies.

**Endpoint:** `auth.logout`  
**Method:** Mutation  
**Authentication:** Required

**Response:**

```typescript
{
  success: true;
}
```

**Example Usage:**

```typescript
const logout = trpc.auth.logout.useMutation();
await logout.mutateAsync();
```

---

## Task Management Endpoints

### List Tasks

Retrieves paginated list of tasks with optional filtering by status, priority, or agent type.

**Endpoint:** `tasks.list`  
**Method:** Query  
**Authentication:** Required

**Parameters:**

```typescript
{
  status?: 'pending' | 'in_progress' | 'completed' | 'failed';
  priority?: 'low' | 'medium' | 'high' | 'urgent';
  agentType?: 'fara' | 'lux-actor' | 'lux-tasker' | 'lux-thinker';
  limit?: number; // Default: 50
  offset?: number; // Default: 0
}
```

**Response:**

```typescript
{
  tasks: Array<{
    id: number;
    userId: number;
    title: string;
    description: string;
    status: string;
    priority: string;
    agentType: string | null;
    privacyLevel: 'sensitive' | 'normal' | 'public';
    estimatedCost: number;
    actualCost: number | null;
    createdAt: Date;
    completedAt: Date | null;
  }>;
  total: number;
}
```

### Create Task

Submits new task for AI agent execution with automatic routing based on task characteristics.

**Endpoint:** `tasks.create`  
**Method:** Mutation  
**Authentication:** Required

**Parameters:**

```typescript
{
  title: string;
  description: string;
  priority?: 'low' | 'medium' | 'high' | 'urgent';
  privacyLevel?: 'sensitive' | 'normal' | 'public';
  metadata?: Record<string, any>;
}
```

**Response:**

```typescript
{
  id: number;
  title: string;
  status: 'pending';
  agentType: string; // Automatically assigned by routing system
  estimatedCost: number;
  createdAt: Date;
}
```

**Example Usage:**

```typescript
const createTask = trpc.tasks.create.useMutation();
const task = await createTask.mutateAsync({
  title: "Schedule meeting with team",
  description: "Find available time slot next week and send calendar invites",
  priority: "high",
  privacyLevel: "normal"
});
```

---

## AI Agent Endpoints

### Execute Lux Task

Directly executes task using OpenAGI Lux with specified execution mode.

**Endpoint:** `lux.execute`  
**Method:** Mutation  
**Authentication:** Required

**Parameters:**

```typescript
{
  instruction: string;
  mode?: 'actor' | 'tasker' | 'thinker'; // Default: 'tasker'
  maxSteps?: number; // Default: 10
  timeout?: number; // Seconds, default: 300
}
```

**Response:**

```typescript
{
  success: boolean;
  result: string;
  steps: Array<{
    action: string;
    screenshot?: string; // Base64 encoded
    timestamp: Date;
  }>;
  executionTime: number; // Milliseconds
  cost: number; // USD
}
```

**Example Usage:**

```typescript
const executeLux = trpc.lux.execute.useMutation();
const result = await executeLux.mutateAsync({
  instruction: "Open Excel and create a budget spreadsheet with categories",
  mode: "tasker"
});
```

### Analyze Task Routing

Determines optimal AI agent for task execution without actually executing the task.

**Endpoint:** `tasks.analyze`  
**Method:** Query  
**Authentication:** Required

**Parameters:**

```typescript
{
  title: string;
  description: string;
  privacyLevel?: 'sensitive' | 'normal' | 'public';
}
```

**Response:**

```typescript
{
  recommendedAgent: 'fara' | 'lux-actor' | 'lux-tasker' | 'lux-thinker';
  reasoning: string;
  estimatedCost: number;
  estimatedDuration: number; // Seconds
  confidence: number; // 0-100
}
```

---

## Email Automation Endpoints

### Classify Email

Analyzes email content and determines category, priority, and suggested action.

**Endpoint:** `email.classify`  
**Method:** Mutation  
**Authentication:** Required

**Parameters:**

```typescript
{
  from: string;
  subject: string;
  body: string;
  metadata?: {
    previousThread?: string;
    senderHistory?: string;
  };
}
```

**Response:**

```typescript
{
  category: 'urgent' | 'routine' | 'important' | 'spam' | 'personal';
  priority: number; // 1-5
  sentiment: 'positive' | 'neutral' | 'negative';
  requiresResponse: boolean;
  suggestedAction: 'reply' | 'forward' | 'archive' | 'flag' | 'ignore';
  reasoning: string;
  confidence: number; // 0-100
}
```

### Generate Email Response

Creates contextual email response using LLM based on original message and user preferences.

**Endpoint:** `email.generateResponse`  
**Method:** Mutation  
**Authentication:** Required

**Parameters:**

```typescript
{
  from: string;
  subject: string;
  body: string;
  userPreferences?: {
    tone?: 'formal' | 'casual' | 'friendly' | 'professional';
    signatureTemplate?: string;
    responseGuidelines?: string;
  };
}
```

**Response:**

```typescript
{
  subject: string;
  body: string;
  tone: string;
  confidence: number;
  requiresApproval: boolean;
}
```

**Example Usage:**

```typescript
const generateResponse = trpc.email.generateResponse.useMutation();
const response = await generateResponse.mutateAsync({
  from: "client@example.com",
  subject: "Project timeline question",
  body: "When can we expect the final deliverables?",
  userPreferences: {
    tone: "professional",
    signatureTemplate: "Best regards,\nJohn Doe\nProject Manager"
  }
});
```

---

## Connector Management Endpoints

### List Connectors

Retrieves all configured account connectors with status and sync information.

**Endpoint:** `connectors.list`  
**Method:** Query  
**Authentication:** Required

**Response:**

```typescript
{
  connectors: Array<{
    id: number;
    connectorType: 'gmail' | 'google_calendar' | 'outlook' | 'slack';
    name: string;
    status: 'active' | 'inactive' | 'error';
    lastSync: Date | null;
    syncFrequency: number; // Minutes
    errorMessage: string | null;
  }>;
}
```

### Connect Account

Initiates OAuth flow for connecting new account.

**Endpoint:** `connectors.connect`  
**Method:** Mutation  
**Authentication:** Required

**Parameters:**

```typescript
{
  connectorType: 'gmail' | 'google_calendar' | 'outlook' | 'slack';
  name?: string; // Optional display name
}
```

**Response:**

```typescript
{
  authUrl: string; // Redirect user to this URL
  connectorId: number;
}
```

### Disconnect Account

Removes connector and revokes OAuth tokens.

**Endpoint:** `connectors.disconnect`  
**Method:** Mutation  
**Authentication:** Required

**Parameters:**

```typescript
{
  connectorId: number;
}
```

**Response:**

```typescript
{
  success: boolean;
}
```

---

## Approval Queue Endpoints

### List Pending Approvals

Retrieves items awaiting user approval with pagination.

**Endpoint:** `approvals.list`  
**Method:** Query  
**Authentication:** Required

**Parameters:**

```typescript
{
  status?: 'pending' | 'approved' | 'rejected' | 'expired';
  limit?: number;
  offset?: number;
}
```

**Response:**

```typescript
{
  items: Array<{
    id: number;
    type: 'email_response' | 'calendar_event' | 'task_execution';
    title: string;
    description: string;
    metadata: Record<string, any>;
    priority: 'low' | 'medium' | 'high' | 'urgent';
    status: string;
    expiresAt: Date;
    createdAt: Date;
  }>;
  total: number;
}
```

### Approve Item

Approves pending action and triggers execution.

**Endpoint:** `approvals.approve`  
**Method:** Mutation  
**Authentication:** Required

**Parameters:**

```typescript
{
  approvalId: number;
  modifications?: Record<string, any>; // Optional changes before execution
}
```

**Response:**

```typescript
{
  success: boolean;
  executionId?: number; // If action was immediately executed
}
```

### Reject Item

Rejects pending action and prevents execution.

**Endpoint:** `approvals.reject`  
**Method:** Mutation  
**Authentication:** Required

**Parameters:**

```typescript
{
  approvalId: number;
  reason?: string;
}
```

**Response:**

```typescript
{
  success: boolean;
}
```

---

## System Administration Endpoints

### Send Owner Notification

Sends notification to project owner (admin only).

**Endpoint:** `system.notifyOwner`  
**Method:** Mutation  
**Authentication:** Required (Admin role)

**Parameters:**

```typescript
{
  title: string;
  content: string;
}
```

**Response:**

```typescript
{
  success: boolean;
}
```

---

## Error Handling

All API endpoints follow consistent error response format:

```typescript
{
  error: {
    code: string; // 'UNAUTHORIZED', 'BAD_REQUEST', 'INTERNAL_SERVER_ERROR', etc.
    message: string;
    data?: any; // Additional error context
  }
}
```

**Common Error Codes:**

| Code | HTTP Status | Description |
|------|-------------|-------------|
| UNAUTHORIZED | 401 | Missing or invalid authentication token |
| FORBIDDEN | 403 | Insufficient permissions for requested operation |
| BAD_REQUEST | 400 | Invalid parameters or malformed request |
| NOT_FOUND | 404 | Requested resource does not exist |
| CONFLICT | 409 | Operation conflicts with current state |
| INTERNAL_SERVER_ERROR | 500 | Unexpected server error |
| TIMEOUT | 408 | Operation exceeded maximum execution time |

**Example Error Response:**

```typescript
{
  error: {
    code: 'UNAUTHORIZED',
    message: 'Authentication required',
    data: {
      loginUrl: 'https://oauth.manus.im/login'
    }
  }
}
```

---

## Rate Limiting

API endpoints enforce rate limits to prevent abuse and ensure fair resource allocation.

**Default Limits:**
- 100 requests per minute per IP address
- 1000 requests per hour per authenticated user
- 50 concurrent requests per user

**Rate Limit Headers:**

```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1701878400
```

When rate limit is exceeded, API returns 429 status code with retry-after header indicating seconds until limit resets.

---

## Webhooks

HAI Engine Control supports webhooks for real-time event notifications.

### Configure Webhook

Register webhook URL to receive event notifications:

```typescript
const webhook = await trpc.webhooks.create.mutateAsync({
  url: 'https://your-app.com/webhook',
  events: ['task.completed', 'approval.required', 'connector.error'],
  secret: 'your-webhook-secret'
});
```

### Webhook Payload

All webhook requests include signature header for verification:

```
X-HAI-Signature: sha256=<hmac-signature>
```

**Payload Format:**

```typescript
{
  event: string;
  timestamp: string;
  data: {
    // Event-specific data
  }
}
```

**Supported Events:**

| Event | Description |
|-------|-------------|
| task.created | New task submitted |
| task.completed | Task execution finished |
| task.failed | Task execution encountered error |
| approval.required | Action requires user approval |
| approval.approved | Approval granted |
| approval.rejected | Approval denied |
| connector.synced | Connector completed sync |
| connector.error | Connector encountered error |

---

## SDK Examples

### React Frontend

```typescript
import { trpc } from '@/lib/trpc';

function TaskList() {
  const { data, isLoading } = trpc.tasks.list.useQuery({
    status: 'pending',
    limit: 20
  });

  const createTask = trpc.tasks.create.useMutation({
    onSuccess: () => {
      // Invalidate and refetch
      trpc.useUtils().tasks.list.invalidate();
    }
  });

  return (
    <div>
      {data?.tasks.map(task => (
        <div key={task.id}>{task.title}</div>
      ))}
    </div>
  );
}
```

### Node.js Backend

```typescript
import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import type { AppRouter } from './server/routers';

const client = createTRPCProxyClient<AppRouter>({
  links: [
    httpBatchLink({
      url: 'https://your-domain.com/api/trpc',
      headers: {
        authorization: `Bearer ${token}`
      }
    })
  ]
});

const tasks = await client.tasks.list.query({ status: 'pending' });
```

---

## Versioning

API follows semantic versioning with backward compatibility guarantees within major versions. Breaking changes are introduced only in major version updates with migration guides provided.

**Current Version:** 1.0  
**Deprecation Policy:** Deprecated endpoints remain functional for minimum 6 months with warning headers before removal.

---

## Support

For API questions, bug reports, or feature requests:

**Documentation:** https://docs.hai-engine.com/api  
**GitHub Issues:** https://github.com/hai-engine/control/issues  
**Email:** api-support@hai-engine.com

---

**Document Version:** 1.0  
**Next Review:** March 2026
