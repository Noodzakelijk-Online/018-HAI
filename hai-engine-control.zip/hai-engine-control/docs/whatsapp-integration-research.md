# WhatsApp Integration Research

**Author:** Manus AI  
**Date:** December 9, 2025

---

## Integration Methods

### 1. WhatsApp Cloud API (Official - Recommended)

**Provider:** Meta  
**Documentation:** https://developers.facebook.com/docs/whatsapp/cloud-api/

**Capabilities:**
- ✅ Send text messages, rich media, interactive messages
- ✅ Receive incoming messages via webhooks
- ✅ Make and receive calls
- ✅ Create and manage group conversations
- ✅ Message status updates via webhooks
- ❌ **Cannot access historical messages** (only receives new messages after setup)

**Requirements:**
- Meta Business Account
- WhatsApp Business Account (WABA)
- Business phone number verification
- OAuth access tokens
- User opt-in before messaging

**Rate Limits:**
- 200 requests/hour per app per WABA (default)
- 1 message every 6 seconds to same user (pair rate limit)
- Quality rating affects messaging limits

**Best For:**
- Real-time message monitoring (new messages only)
- Autonomous responses to incoming messages
- Proactive notifications to customers

**Limitations:**
- Cannot retrieve past conversation history
- Requires business verification
- Only works for business accounts

---

### 2. whatsapp-web.js (Unofficial - Full Access)

**Library:** https://github.com/pedroslopez/whatsapp-web.js  
**Type:** Node.js library using Puppeteer

**Capabilities:**
- ✅ **Full access to all message history**
- ✅ Read all conversations and threads
- ✅ Send messages programmatically
- ✅ Access contact list
- ✅ Download media attachments
- ✅ Works with personal WhatsApp accounts
- ✅ Real-time message monitoring

**How It Works:**
- Launches WhatsApp Web in headless browser via Puppeteer
- Connects to your personal WhatsApp account
- Accesses internal WhatsApp Web functions
- Maintains persistent session

**Requirements:**
- Node.js environment
- Puppeteer (headless Chrome)
- QR code scan for initial authentication
- Persistent session storage

**Risks:**
- ⚠️ Unofficial API - violates WhatsApp Terms of Service
- ⚠️ Risk of account ban
- ⚠️ May break with WhatsApp Web updates
- ⚠️ Requires keeping browser session alive

**Best For:**
- **Acquiring full message history** (this is what you need!)
- Personal account automation
- Development/testing environments

---

### 3. Chat Export (Manual - Backup Method)

**Method:** WhatsApp built-in export feature

**Capabilities:**
- ✅ Export individual conversations to .txt files
- ✅ Includes timestamps, sender names, messages
- ✅ Can include media attachments
- ✅ No API required

**Process:**
1. Open conversation in WhatsApp
2. Tap More > Export Chat
3. Choose "With Media" or "Without Media"
4. Receive .txt file + media folder

**Format:**
```
[12/9/25, 2:30:15 PM] John Doe: Hey, how are you?
[12/9/25, 2:31:42 PM] You: I'm good! How about you?
[12/9/25, 2:32:10 PM] John Doe: <Media omitted>
```

**Best For:**
- One-time historical data import
- Backup and archival
- Compliance/legal requirements

**Limitations:**
- Manual process (one chat at a time)
- No automation
- Requires user action for each export

---

## Recommended Architecture for HAI

### Hybrid Approach: whatsapp-web.js + Cloud API

**Phase 1: Historical Acquisition (whatsapp-web.js)**
Use whatsapp-web.js to perform one-time acquisition of all historical messages:

1. User authenticates via QR code scan
2. HAI connects to WhatsApp Web session
3. Iterate through all conversations
4. Download all messages + metadata
5. Store in HAI database
6. Download media attachments to S3

**Phase 2: Real-Time Monitoring (Cloud API or whatsapp-web.js)**
After initial acquisition, monitor new messages:

- **Option A:** Continue using whatsapp-web.js for real-time updates
- **Option B:** Switch to Cloud API if user has business account

**Phase 3: Analysis & Synthesis**
Process all messages with LLM:

1. Sentiment analysis per conversation
2. Topic extraction and categorization
3. Relationship strength scoring
4. Action item detection
5. Conversation summarization
6. Search index creation

---

## Implementation Plan

### Database Schema

```sql
-- Contacts
CREATE TABLE whatsapp_contacts (
  id INT PRIMARY KEY AUTO_INCREMENT,
  userId INT NOT NULL,
  phone VARCHAR(20) NOT NULL,
  name VARCHAR(255),
  profilePicUrl TEXT,
  isGroup BOOLEAN DEFAULT FALSE,
  groupMembers JSON,
  lastMessageAt TIMESTAMP,
  messageCount INT DEFAULT 0,
  relationshipScore DECIMAL(3,2),
  createdAt TIMESTAMP DEFAULT NOW(),
  updatedAt TIMESTAMP DEFAULT NOW(),
  UNIQUE KEY (userId, phone)
);

-- Messages
CREATE TABLE whatsapp_messages (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  userId INT NOT NULL,
  contactId INT NOT NULL,
  messageId VARCHAR(255),
  sender VARCHAR(255),
  content TEXT,
  mediaType ENUM('text', 'image', 'video', 'audio', 'document'),
  mediaUrl TEXT,
  timestamp TIMESTAMP NOT NULL,
  isFromMe BOOLEAN DEFAULT FALSE,
  sentiment ENUM('positive', 'neutral', 'negative'),
  topics JSON,
  hasActionItem BOOLEAN DEFAULT FALSE,
  createdAt TIMESTAMP DEFAULT NOW(),
  INDEX (userId, contactId, timestamp),
  INDEX (userId, timestamp),
  FULLTEXT INDEX (content)
);

-- Conversation Insights
CREATE TABLE whatsapp_insights (
  id INT PRIMARY KEY AUTO_INCREMENT,
  userId INT NOT NULL,
  contactId INT NOT NULL,
  period ENUM('daily', 'weekly', 'monthly'),
  periodStart DATE NOT NULL,
  messageCount INT,
  avgSentiment DECIMAL(3,2),
  topTopics JSON,
  actionItems JSON,
  summary TEXT,
  createdAt TIMESTAMP DEFAULT NOW(),
  UNIQUE KEY (userId, contactId, period, periodStart)
);
```

### Service Architecture

```
┌─────────────────────────────────────────────────────────┐
│              WhatsApp Integration Layer                  │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ┌──────────────────┐      ┌──────────────────┐        │
│  │  whatsapp-web.js │      │  Cloud API       │        │
│  │  Connector       │      │  Connector       │        │
│  └────────┬─────────┘      └────────┬─────────┘        │
│           │                          │                   │
│           └──────────┬───────────────┘                   │
│                      │                                   │
│           ┌──────────▼─────────┐                        │
│           │  Message Sync      │                        │
│           │  Service           │                        │
│           └──────────┬─────────┘                        │
│                      │                                   │
└──────────────────────┼─────────────────────────────────┘
                       │
┌──────────────────────▼─────────────────────────────────┐
│              Analysis & Synthesis Layer                 │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │  Sentiment   │  │  Topic       │  │  Action Item │ │
│  │  Analyzer    │  │  Extractor   │  │  Detector    │ │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘ │
│         │                  │                  │          │
│         └──────────────────┼──────────────────┘          │
│                            │                             │
│                 ┌──────────▼─────────┐                  │
│                 │  LLM Synthesis     │                  │
│                 │  Engine            │                  │
│                 └──────────┬─────────┘                  │
│                            │                             │
└────────────────────────────┼─────────────────────────────┘
                             │
┌────────────────────────────▼─────────────────────────────┐
│                    Storage Layer                         │
├──────────────────────────────────────────────────────────┤
│  MySQL (messages, contacts, insights) + S3 (media)      │
└──────────────────────────────────────────────────────────┘
```

---

## Security & Privacy Considerations

### Data Protection
- All messages encrypted at rest (E2E encryption in database)
- Media files encrypted in S3
- Access control via RBAC
- Audit logging for all message access

### WhatsApp Terms Compliance
- whatsapp-web.js violates ToS - use at own risk
- Recommend Cloud API for production
- Implement rate limiting to avoid bans
- Never spam or send unsolicited messages

### User Consent
- Explicit user consent before accessing WhatsApp data
- Clear privacy policy disclosure
- Option to delete all data
- Opt-out mechanism

---

## Next Steps

1. **Implement whatsapp-web.js connector** for historical acquisition
2. **Create message sync service** with incremental updates
3. **Build LLM analysis pipeline** for sentiment, topics, action items
4. **Design WhatsApp dashboard UI** with conversation insights
5. **Add autonomous features** (auto-respond, summaries, reminders)

---

## References

- [WhatsApp Cloud API Documentation](https://developers.facebook.com/docs/whatsapp/cloud-api/)
- [whatsapp-web.js GitHub](https://github.com/pedroslopez/whatsapp-web.js)
- [WhatsApp Chat Export Format](https://faq.whatsapp.com/209942271778103)
