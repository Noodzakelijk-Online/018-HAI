# HAI Desktop Application Architecture

## Overview

Transform HAI from a web application into a **Windows 11 desktop application** with integrated Fara-7B AI agent. The application will auto-install all dependencies and run as a unified background service.

## User Experience

### Installation Flow

1. **User downloads** `HAI-Setup.exe` (single installer file)
2. **Installer runs** and shows progress:
   - ✓ Installing HAI Engine
   - ✓ Installing Python 3.11
   - ✓ Downloading Fara-7B model (14GB)
   - ✓ Installing AI dependencies
   - ✓ Setting up database
   - ✓ Configuring services
3. **Installation complete** → HAI starts automatically
4. **System tray icon** appears → HAI running in background
5. **Browser opens** → HAI dashboard at `http://localhost:3000`

### Daily Usage

- **Background operation**: HAI runs silently in background
- **System tray**: Click icon to open dashboard, view status, or quit
- **Auto-start**: HAI starts automatically when Windows boots
- **Notifications**: Desktop notifications for task completion
- **Task submission**: Use dashboard to give Fara-7B tasks
- **Live monitoring**: Watch Fara-7B work in real-time

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     Windows 11 Desktop                           │
│                                                                   │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │              Electron Application (HAI.exe)                 │ │
│  │                                                              │ │
│  │  ┌────────────────────────────────────────────────────────┐│ │
│  │  │         System Tray Manager                            ││ │
│  │  │  • Show/Hide Dashboard                                 ││ │
│  │  │  • Service Status                                      ││ │
│  │  │  • Quick Actions                                       ││ │
│  │  │  • Quit Application                                    ││ │
│  │  └────────────────────────────────────────────────────────┘│ │
│  │                                                              │ │
│  │  ┌────────────────────────────────────────────────────────┐│ │
│  │  │         Process Manager (Node.js Main Process)         ││ │
│  │  │  ┌──────────────┐  ┌──────────────┐  ┌─────────────┐ ││ │
│  │  │  │ HAI Backend  │  │ Fara-7B Mgr  │  │  Database   │ ││ │
│  │  │  │ (Express)    │  │ (Python)     │  │  (SQLite)   │ ││ │
│  │  │  └──────────────┘  └──────────────┘  └─────────────┘ ││ │
│  │  └────────────────────────────────────────────────────────┘│ │
│  │                                                              │ │
│  │  ┌────────────────────────────────────────────────────────┐│ │
│  │  │         BrowserView (Renderer Process)                 ││ │
│  │  │         HAI Dashboard (React)                          ││ │
│  │  │         http://localhost:3000                          ││ │
│  │  └────────────────────────────────────────────────────────┘│ │
│  └──────────────────────────────────────────────────────────────┘ │
│                                                                   │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │         Embedded Python Environment                         │ │
│  │  ┌──────────────────────────────────────────────────────┐  │ │
│  │  │  vLLM Server (localhost:5000)                         │  │ │
│  │  │  Serving Fara-7B Model                                │  │ │
│  │  └──────────────────────────────────────────────────────┘  │ │
│  │  ┌──────────────────────────────────────────────────────┐  │ │
│  │  │  Playwright Browser Automation                        │  │ │
│  │  │  Executes Fara-7B Actions                             │  │ │
│  │  └──────────────────────────────────────────────────────┘  │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                   │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │         Local Storage                                       │ │
│  │  • AppData/Local/HAI/                                       │ │
│  │    - database.sqlite                                        │ │
│  │    - models/ (Fara-7B weights)                              │ │
│  │    - screenshots/                                           │ │
│  │    - logs/                                                  │ │
│  │    - config.json                                            │ │
│  └────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

## Technology Stack

### Desktop Application Framework

**Electron** - Cross-platform desktop app framework
- **Main Process**: Node.js backend, manages services
- **Renderer Process**: React frontend (existing HAI dashboard)
- **IPC**: Communication between main and renderer
- **Native APIs**: System tray, notifications, auto-start

### Backend Services

**Node.js/Express** - Existing HAI backend
- Runs in Electron main process
- Manages Fara-7B service
- Handles task queue
- Serves React frontend

**SQLite** - Local database
- Replace MySQL with SQLite for desktop
- All data stored locally
- No cloud dependencies
- Fast and lightweight

### AI Integration

**Embedded Python** - Bundled Python environment
- Python 3.11 embedded distribution
- Isolated from system Python
- Includes all dependencies (PyTorch, vLLM, Playwright)
- Managed by Electron main process

**Fara-7B** - AI agent model
- Downloaded on first run (14GB)
- Served via vLLM on localhost:5000
- Controlled by HAI backend
- Executes tasks via Playwright

## Directory Structure

```
HAI-Desktop/
├── electron/                    # Electron main process
│   ├── main.ts                  # Entry point
│   ├── tray.ts                  # System tray manager
│   ├── services/
│   │   ├── faraManager.ts       # Fara-7B process manager
│   │   ├── pythonManager.ts     # Python environment manager
│   │   ├── databaseManager.ts   # SQLite manager
│   │   └── updateManager.ts     # Auto-update
│   └── installers/
│       ├── pythonInstaller.ts   # Install embedded Python
│       ├── faraInstaller.ts     # Download Fara-7B model
│       └── dependencyInstaller.ts # Install Python packages
│
├── server/                      # Existing HAI backend (unchanged)
│   ├── api/
│   ├── services/
│   └── ...
│
├── client/                      # Existing HAI frontend (unchanged)
│   ├── src/
│   └── ...
│
├── python-embedded/             # Embedded Python (bundled in installer)
│   ├── python.exe
│   ├── Lib/
│   └── Scripts/
│
├── resources/                   # Application resources
│   ├── icon.ico                 # App icon
│   ├── tray-icon.png            # System tray icon
│   └── installer-banner.png     # Installer UI
│
├── installer/                   # Installer configuration
│   ├── build.js                 # Electron Builder config
│   └── nsis/                    # Windows installer scripts
│
└── package.json                 # Electron app configuration
```

## Installation Process

### Installer Components

**NSIS (Nullsoft Scriptable Install System)**
- Creates `HAI-Setup.exe`
- Custom UI with progress bars
- Handles file extraction
- Creates shortcuts
- Registers auto-start

### Installation Steps

1. **Extract Application Files**
   - Copy Electron app to `C:\Program Files\HAI\`
   - Extract embedded Python to `AppData\Local\HAI\python\`
   - Create data directory at `AppData\Local\HAI\data\`

2. **Install Python Dependencies**
   ```bash
   # Run embedded pip
   python.exe -m pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
   python.exe -m pip install vllm transformers playwright
   playwright install chromium
   ```

3. **Download Fara-7B Model**
   ```bash
   # Download from Hugging Face
   python.exe -c "from transformers import AutoModel; AutoModel.from_pretrained('microsoft/Fara-7B', cache_dir='models/')"
   ```

4. **Initialize Database**
   ```typescript
   // Create SQLite database
   await createDatabase('AppData/Local/HAI/data/database.sqlite');
   await runMigrations();
   ```

5. **Configure Services**
   ```json
   {
     "fara": {
       "enabled": true,
       "port": 5000,
       "modelPath": "models/Fara-7B"
     },
     "backend": {
       "port": 3000
     }
   }
   ```

6. **Create Shortcuts**
   - Desktop shortcut
   - Start Menu entry
   - Auto-start registry entry

## Service Management

### Process Manager

**Electron Main Process** manages all services:

```typescript
class ServiceManager {
  private services: Map<string, ChildProcess> = new Map();
  
  async startAll() {
    await this.startDatabase();
    await this.startFaraService();
    await this.startBackend();
  }
  
  async startFaraService() {
    // Start vLLM server
    const pythonPath = path.join(app.getPath('userData'), 'python', 'python.exe');
    const modelPath = path.join(app.getPath('userData'), 'models', 'Fara-7B');
    
    const faraProcess = spawn(pythonPath, [
      '-m', 'vllm.entrypoints.openai.api_server',
      '--model', modelPath,
      '--port', '5000',
      '--dtype', 'auto'
    ]);
    
    this.services.set('fara', faraProcess);
    
    // Wait for service to be ready
    await this.waitForService('http://localhost:5000/health');
  }
  
  async startBackend() {
    // Start Express server
    const backendPath = path.join(__dirname, 'server', 'index.js');
    const backendProcess = fork(backendPath);
    
    this.services.set('backend', backendProcess);
  }
  
  async stopAll() {
    for (const [name, process] of this.services) {
      process.kill();
    }
  }
}
```

### Health Monitoring

```typescript
class HealthMonitor {
  async checkServices() {
    const status = {
      fara: await this.checkFara(),
      backend: await this.checkBackend(),
      database: await this.checkDatabase()
    };
    
    // Update system tray icon based on status
    tray.setIcon(this.getIconForStatus(status));
    
    return status;
  }
  
  async checkFara(): Promise<boolean> {
    try {
      const response = await fetch('http://localhost:5000/health');
      return response.ok;
    } catch {
      return false;
    }
  }
}
```

## System Tray Integration

### Tray Menu

```typescript
const trayMenu = Menu.buildFromTemplate([
  {
    label: 'Open HAI Dashboard',
    click: () => showMainWindow()
  },
  { type: 'separator' },
  {
    label: 'Services',
    submenu: [
      {
        label: '● Fara-7B: Running',
        enabled: false
      },
      {
        label: '● Backend: Running',
        enabled: false
      },
      {
        label: 'Restart Services',
        click: () => restartServices()
      }
    ]
  },
  { type: 'separator' },
  {
    label: 'Active Tasks',
    submenu: [
      {
        label: 'No active tasks',
        enabled: false
      }
    ]
  },
  { type: 'separator' },
  {
    label: 'Settings',
    click: () => showSettings()
  },
  {
    label: 'Quit HAI',
    click: () => app.quit()
  }
]);
```

### Notifications

```typescript
function notifyTaskComplete(task: Task) {
  new Notification({
    title: 'Task Completed',
    body: `${task.description} - ${task.status}`,
    icon: path.join(__dirname, 'resources', 'icon.png')
  }).show();
}
```

## Database Migration (MySQL → SQLite)

### Schema Conversion

**Differences to handle:**
- `AUTO_INCREMENT` → `AUTOINCREMENT`
- `DATETIME` → `TEXT` (ISO 8601 format)
- `JSON` → `TEXT` (JSON string)
- `ENUM` → `TEXT` with CHECK constraint

**Migration Script**:
```typescript
// Convert MySQL schema to SQLite
async function migrateDrizzleSchema() {
  // Update drizzle/schema.ts
  // Replace mysqlTable with sqliteTable
  // Replace mysql types with sqlite types
  
  // Example:
  // FROM: mysqlTable, int(), varchar(), timestamp()
  // TO:   sqliteTable, integer(), text(), text()
}
```

### Connection Configuration

```typescript
// server/db.ts
import { drizzle } from 'drizzle-orm/better-sqlite3';
import Database from 'better-sqlite3';

const dbPath = path.join(app.getPath('userData'), 'data', 'database.sqlite');
const sqlite = new Database(dbPath);
export const db = drizzle(sqlite);
```

## Task Queue Integration

### Frontend Integration (Existing Dashboard)

Add Fara-7B task submission to existing dashboard:

```typescript
// client/src/pages/HAIDashboard.tsx
function HAIDashboard() {
  const [taskDescription, setTaskDescription] = useState('');
  const submitTask = trpc.fara.submitTask.useMutation();
  const activeTasks = trpc.fara.getActiveTasks.useQuery();
  
  return (
    <div>
      {/* Existing dashboard content */}
      
      {/* New Fara-7B Task Section */}
      <Card>
        <CardHeader>
          <CardTitle>🤖 AI Agent Tasks</CardTitle>
        </CardHeader>
        <CardContent>
          <Input
            placeholder="What should HAI do? (e.g., 'Book a restaurant for 2 people tomorrow at 7pm')"
            value={taskDescription}
            onChange={(e) => setTaskDescription(e.target.value)}
          />
          <Button onClick={() => submitTask.mutate({ description: taskDescription })}>
            Start Task
          </Button>
          
          {/* Active Tasks List */}
          {activeTasks.data?.map(task => (
            <TaskCard key={task.id} task={task} />
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
```

### Backend API

```typescript
// server/api/routers/fara.ts
export const faraRouter = router({
  submitTask: protectedProcedure
    .input(z.object({
      description: z.string(),
      startUrl: z.string().optional(),
      priority: z.number().default(0)
    }))
    .mutation(async ({ input, ctx }) => {
      // Create task in database
      const task = await db.insert(fara_tasks).values({
        userId: ctx.user.id,
        taskDescription: input.description,
        status: 'pending',
        priority: input.priority,
        startUrl: input.startUrl
      });
      
      // Notify task queue
      await taskQueue.enqueue(task.id);
      
      return task;
    }),
    
  getActiveTasks: protectedProcedure.query(async ({ ctx }) => {
    return db.select()
      .from(fara_tasks)
      .where(
        and(
          eq(fara_tasks.userId, ctx.user.id),
          inArray(fara_tasks.status, ['pending', 'running', 'paused'])
        )
      );
  })
});
```

## Auto-Update System

### Electron Builder Auto-Update

```typescript
// electron/main.ts
import { autoUpdater } from 'electron-updater';

autoUpdater.checkForUpdatesAndNotify();

autoUpdater.on('update-available', () => {
  dialog.showMessageBox({
    type: 'info',
    title: 'Update Available',
    message: 'A new version of HAI is available. Download now?',
    buttons: ['Yes', 'Later']
  }).then(result => {
    if (result.response === 0) {
      autoUpdater.downloadUpdate();
    }
  });
});

autoUpdater.on('update-downloaded', () => {
  dialog.showMessageBox({
    type: 'info',
    title: 'Update Ready',
    message: 'Update downloaded. Restart HAI to install?',
    buttons: ['Restart', 'Later']
  }).then(result => {
    if (result.response === 0) {
      autoUpdater.quitAndInstall();
    }
  });
});
```

## Security Considerations

### Local-Only Operation

- All data stored locally (no cloud sync)
- No external API calls except Fara-7B model download
- User data never leaves the PC
- SQLite database encrypted at rest (optional)

### Sandboxed Execution

- Fara-7B runs in isolated browser context
- No access to user's main browser
- Separate cookie/storage per task
- Can limit network access to specific domains

### User Permissions

- Require approval for sensitive actions (Critical Points)
- Log all Fara-7B actions
- User can pause/stop tasks at any time
- Emergency stop button in system tray

## Performance Optimization

### Resource Management

- **GPU Usage**: Fara-7B uses GPU if available (CUDA)
- **CPU Fallback**: Falls back to CPU if no GPU
- **Memory**: ~8GB RAM minimum, 16GB recommended
- **Disk Space**: ~20GB for model + dependencies

### Lazy Loading

- Download Fara-7B model only when first task is submitted
- Install Python dependencies on-demand
- Start services only when needed

### Background Operation

- Minimize to system tray (not taskbar)
- Reduce CPU usage when idle
- Suspend Fara-7B service when no tasks
- Wake on task submission

## Development Workflow

### Local Development

```bash
# Install dependencies
npm install

# Start Electron in development mode
npm run electron:dev

# This will:
# 1. Start Vite dev server (React frontend)
# 2. Start Express backend
# 3. Launch Electron window
# 4. Enable hot reload
```

### Building Installer

```bash
# Build for Windows
npm run build:win

# Output: dist/HAI-Setup.exe
```

### Testing

```bash
# Unit tests
npm test

# Integration tests
npm run test:integration

# Test installer on clean VM
# (Use Windows 11 VM without Python/Node installed)
```

## Deployment Checklist

- [ ] Convert MySQL schema to SQLite
- [ ] Update database connection in `server/db.ts`
- [ ] Create Electron main process (`electron/main.ts`)
- [ ] Implement service manager
- [ ] Create system tray integration
- [ ] Build Python installer script
- [ ] Create Fara-7B downloader
- [ ] Configure Electron Builder
- [ ] Design installer UI
- [ ] Implement auto-update
- [ ] Add crash reporting
- [ ] Create user documentation
- [ ] Test on clean Windows 11
- [ ] Build final installer
- [ ] Code sign installer (optional)

## Future Enhancements

1. **Multi-Platform Support**: macOS and Linux versions
2. **Cloud Sync**: Optional cloud backup of tasks/data
3. **Mobile Companion**: Mobile app to monitor HAI
4. **Voice Control**: Voice commands for task submission
5. **Plugin System**: Community-developed extensions
6. **Team Features**: Share tasks across household members

## Conclusion

This architecture transforms HAI into a complete desktop application that users can simply download and install. All complexity is hidden - users just see a single installer that sets up everything automatically. The result is a powerful AI agent that runs locally, respects privacy, and integrates seamlessly with Windows 11.
