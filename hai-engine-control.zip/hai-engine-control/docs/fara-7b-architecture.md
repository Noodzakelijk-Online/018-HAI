# Fara-7B Integration Architecture for HAI

## Overview

This document outlines the architecture for integrating Microsoft's Fara-7B agentic AI model into the HAI (Household AI) Engine Control Center, enabling autonomous computer operation and task execution.

## System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     HAI Control Center (Web UI)                  │
│  ┌──────────────┐  ┌──────────────┐  ┌────────────────────────┐│
│  │  Dashboard   │  │Master Orch.  │  │  Fara-7B Control Panel ││
│  └──────────────┘  └──────────────┘  └────────────────────────┘│
└──────────────────────────────┬──────────────────────────────────┘
                               │ tRPC API
┌──────────────────────────────┴──────────────────────────────────┐
│                      HAI Backend (Node.js/Express)               │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │              Fara-7B Service Orchestrator                 │  │
│  │  ┌────────────┐  ┌──────────────┐  ┌─────────────────┐  │  │
│  │  │Task Queue  │  │Action Logger │  │Safety Monitor   │  │  │
│  │  └────────────┘  └──────────────┘  └─────────────────┘  │  │
│  └──────────────────────────────────────────────────────────┘  │
│                               │                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │           Fara-7B API Client (Azure/vLLM)                 │  │
│  └──────────────────────────────────────────────────────────┘  │
└──────────────────────────────┬──────────────────────────────────┘
                               │ HTTP/WebSocket
┌──────────────────────────────┴──────────────────────────────────┐
│                    Fara-7B Model Service                         │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  Azure Foundry API  OR  vLLM Self-Hosted (Port 5000)     │  │
│  └──────────────────────────────────────────────────────────┘  │
└──────────────────────────────┬──────────────────────────────────┘
                               │ Actions
┌──────────────────────────────┴──────────────────────────────────┐
│                   Computer Control Layer                         │
│  ┌────────────┐  ┌──────────────┐  ┌─────────────────────────┐│
│  │ Playwright │  │Screenshot    │  │  Action Executor         ││
│  │ Browser    │  │Capture       │  │  (mouse, keyboard, etc.) ││
│  └────────────┘  └──────────────┘  └─────────────────────────┘│
└─────────────────────────────────────────────────────────────────┘
```

## Core Components

### 1. Fara-7B Service Orchestrator

**Purpose**: Central coordination layer between HAI and Fara-7B

**Responsibilities**:
- Manage Fara-7B API connections (Azure Foundry or vLLM)
- Queue and prioritize autonomous tasks
- Coordinate screenshot capture and action execution
- Enforce safety policies and critical point detection
- Log all actions for audit trail

**Implementation**: `server/services/faraService.ts`

### 2. Screenshot Capture Service

**Purpose**: Capture browser/desktop screenshots for Fara-7B visual perception

**Capabilities**:
- Capture full browser window screenshots
- Support multiple screenshot formats (PNG, JPEG)
- Maintain screenshot history (last 3 screenshots as per Fara-7B requirements)
- Optimize image size for API transmission

**Implementation**: `server/services/screenshotService.ts`

**Technology**: Playwright's `page.screenshot()` API

### 3. Action Executor

**Purpose**: Execute actions predicted by Fara-7B

**Supported Actions**:
- **Mouse**: `mouse_move(x, y)`, `left_click()`
- **Keyboard**: `type(text)`, `key(keys[])`
- **Browser**: `visit_url(url)`, `web_search(query)`, `history_back()`, `scroll(pixels)`
- **Control**: `wait(seconds)`, `terminate(status)`
- **Memory**: `pause_and_memorize_fact(fact)`

**Safety Features**:
- Critical Point detection (checkout, purchase, email, etc.)
- Action validation before execution
- Rollback capability for reversible actions
- Rate limiting to prevent abuse

**Implementation**: `server/services/actionExecutor.ts`

### 4. Task Queue System

**Purpose**: Manage autonomous task execution

**Features**:
- Priority-based task scheduling
- Multi-step task orchestration
- Error handling and retry logic
- Task status tracking (pending, running, completed, failed)
- User approval workflow for sensitive tasks

**Database Schema**:
```typescript
export const fara_tasks = mysqlTable("fara_tasks", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  householdId: int("householdId"),
  taskDescription: text("taskDescription").notNull(),
  status: mysqlEnum("status", ["pending", "running", "paused", "completed", "failed"]).notNull(),
  priority: int("priority").default(0),
  startUrl: text("startUrl"),
  maxSteps: int("maxSteps").default(100),
  currentStep: int("currentStep").default(0),
  actionHistory: json("actionHistory").$type<Array<{
    step: number;
    thought: string;
    action: string;
    arguments: any;
    observation: string;
    timestamp: string;
  }>>(),
  screenshots: json("screenshots").$type<string[]>(), // Paths to screenshot files
  result: text("result"),
  error: text("error"),
  requiresApproval: boolean("requiresApproval").default(false),
  approvedBy: int("approvedBy"),
  approvedAt: timestamp("approvedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  completedAt: timestamp("completedAt"),
});
```

### 5. Safety Monitor

**Purpose**: Enforce safety policies and prevent harmful actions

**Critical Point Detection**:
- Checkout/Purchase operations
- Email/Call actions
- Account sign-in
- Personal information entry
- File uploads/downloads
- System-level operations

**Safety Mechanisms**:
- Pre-execution validation
- User approval for sensitive operations
- Sandboxed execution environment
- Action logging and audit trail
- Emergency stop capability
- Rate limiting (max actions per minute)

**Implementation**: `server/services/safetyMonitor.ts`

### 6. Fara-7B API Client

**Purpose**: Interface with Fara-7B model (Azure or self-hosted)

**Configuration**:
```typescript
interface FaraConfig {
  deploymentType: 'azure' | 'vllm';
  baseUrl: string;
  apiKey?: string; // For Azure
  model: string; // "Fara-7B"
  maxTokens: number; // 128k context
  temperature: number;
}
```

**Request Format**:
```typescript
interface FaraRequest {
  messages: Array<{
    role: 'system' | 'user' | 'assistant';
    content: string | Array<{
      type: 'text' | 'image_url';
      text?: string;
      image_url?: { url: string };
    }>;
  }>;
  tools: Array<{
    type: 'function';
    function: {
      name: string;
      description: string;
      parameters: object;
    };
  }>;
}
```

**Response Format**:
```typescript
interface FaraResponse {
  thought: string; // Reasoning about next action
  tool_call: {
    name: 'computer_use';
    arguments: {
      action: string;
      [key: string]: any;
    };
  };
}
```

**Implementation**: `server/services/faraClient.ts`

## Data Flow

### Task Execution Flow

1. **User submits task** via HAI Dashboard
   - Example: "Book a restaurant reservation for 2 people tomorrow at 7pm"
   
2. **Task Queue** creates new task record
   - Status: `pending`
   - Priority: based on user settings
   
3. **Fara Service Orchestrator** picks up task
   - Status: `pending` → `running`
   - Initialize browser with Playwright
   - Navigate to start URL (if specified)
   
4. **Main execution loop** (max 100 steps):
   
   a. **Screenshot Capture**
      - Capture current browser state
      - Store in screenshot history (keep last 3)
   
   b. **Fara-7B Inference**
      - Send request with:
        - System prompt (safety guidelines)
        - User task description
        - Last 3 screenshots
        - Complete action history
      - Receive response:
        - Thought (reasoning)
        - Tool call (action to execute)
   
   c. **Safety Check**
      - Check if action hits Critical Point
      - If yes:
        - Pause execution
        - Request user approval
        - Wait for approval/rejection
   
   d. **Action Execution**
      - Execute validated action via Playwright
      - Log action and result
      - Update task record
   
   e. **Termination Check**
      - If action is `terminate`:
        - Status: `running` → `completed` or `failed`
        - Save final result
        - Break loop
      - If max steps reached:
        - Status: `running` → `failed`
        - Error: "Max steps exceeded"
   
5. **Post-execution**
   - Close browser
   - Save screenshots to storage
   - Notify user of completion
   - Update Master Orchestrator insights

### Screenshot Management

```typescript
interface ScreenshotHistory {
  screenshots: Array<{
    step: number;
    path: string; // Local file path
    url: string; // S3 URL for persistence
    timestamp: string;
  }>;
  current: number; // Current step
}

// Keep only last 3 screenshots in memory for API calls
function getRecentScreenshots(history: ScreenshotHistory): string[] {
  return history.screenshots
    .slice(-3)
    .map(s => s.path);
}
```

## Frontend Components

### 1. Fara Control Panel (`client/src/pages/FaraControl.tsx`)

**Features**:
- Submit new autonomous tasks
- View task queue and status
- Real-time execution monitoring
- Screenshot viewer (live updates)
- Action history timeline
- Manual intervention controls (pause, resume, stop)
- Approval workflow for Critical Points

**UI Sections**:
- Task submission form
- Active task monitor with live screenshots
- Task history list
- Action log viewer
- Safety alerts and approval requests

### 2. Live Execution Monitor

**Real-time Updates**:
- WebSocket connection for live updates
- Screenshot stream (updated each step)
- Action log (thought → action → observation)
- Progress indicator (current step / max steps)
- Safety alerts

### 3. Task Templates

**Pre-built Templates**:
- "Book restaurant reservation"
- "Find and compare products"
- "Search for information and summarize"
- "Fill out form with provided data"
- "Schedule meeting based on calendar availability"

## Security & Safety

### 1. Sandboxed Execution

- Run Fara-7B tasks in isolated browser contexts
- No access to user's main browser session
- Separate cookie/storage per task
- Network isolation options

### 2. Critical Point System

**Automatic Pause Triggers**:
- Payment/checkout pages
- Login forms
- Email composition
- Phone call initiation
- File upload dialogs
- System settings changes

**User Approval Flow**:
1. Fara-7B detects Critical Point
2. Pause execution
3. Show user:
   - Current screenshot
   - Proposed action
   - Risk assessment
4. User chooses:
   - Approve → Continue execution
   - Reject → Terminate task
   - Modify → Adjust parameters and continue

### 3. Action Logging & Audit Trail

**Log Every Action**:
- Timestamp
- Task ID
- Step number
- Thought (reasoning)
- Action type and arguments
- Execution result
- Screenshot before/after
- User approval (if required)

**Storage**:
- Database: Action metadata
- S3: Screenshots and detailed logs
- Retention: 30 days (configurable)

### 4. Rate Limiting

- Max 10 actions per minute per user
- Max 5 concurrent tasks per household
- Max 100 steps per task
- Cooldown period after failed tasks

## Deployment Options

### Option 1: Azure Foundry (Recommended for Production)

**Advantages**:
- No GPU infrastructure required
- Managed service with SLA
- Auto-scaling
- Built-in security

**Setup**:
1. Deploy Fara-7B on Azure Foundry
2. Configure endpoint in HAI:
```typescript
FARA_DEPLOYMENT_TYPE=azure
FARA_BASE_URL=https://your-endpoint.inference.ml.azure.com/
FARA_API_KEY=your-api-key
```

### Option 2: Self-Hosted vLLM (For Privacy/Control)

**Advantages**:
- Complete data privacy
- Lower latency (local network)
- No API costs
- Full control

**Requirements**:
- GPU server (NVIDIA A6000/A100/H100)
- Ubuntu 24.04 LTS
- 32GB+ VRAM
- Docker (optional)

**Setup**:
```bash
# On GPU server
vllm serve "microsoft/Fara-7B" --port 5000 --dtype auto --tensor-parallel-size 2

# In HAI
FARA_DEPLOYMENT_TYPE=vllm
FARA_BASE_URL=http://gpu-server:5000
```

## Performance Considerations

### 1. Screenshot Optimization

- Compress screenshots before API transmission
- Use JPEG for screenshots (smaller size)
- Resize to optimal resolution (1428x896 as per Fara-7B)
- Cache screenshots locally

### 2. API Request Optimization

- Batch screenshot uploads
- Reuse browser contexts
- Implement request queuing
- Use connection pooling

### 3. Scalability

- Horizontal scaling: Multiple Fara-7B instances
- Load balancing across instances
- Task queue with Redis for distributed processing
- Separate screenshot storage service

## Monitoring & Observability

### Metrics to Track

- Task completion rate
- Average steps per task
- Critical Point hit rate
- User approval rate
- Error rate by error type
- Average task duration
- API latency

### Logging

- Structured logging (JSON format)
- Log levels: DEBUG, INFO, WARN, ERROR
- Correlation IDs for task tracing
- Integration with logging service (e.g., Azure Monitor)

### Alerts

- Task failure rate > 20%
- API errors
- Safety violations
- Resource exhaustion
- Unusual activity patterns

## Future Enhancements

1. **Multi-modal Support**: Desktop app control beyond browser
2. **Learning from Feedback**: Fine-tune on user-approved actions
3. **Task Chaining**: Compose complex workflows from simple tasks
4. **Collaborative Agents**: Multiple Fara-7B instances working together
5. **Voice Control**: Voice commands for task submission
6. **Mobile App**: Monitor and approve tasks from mobile device

## Implementation Roadmap

### Phase 1: Foundation (Week 1-2)
- [ ] Set up Fara-7B API client (Azure Foundry)
- [ ] Implement screenshot capture service
- [ ] Build basic action executor
- [ ] Create task queue database schema

### Phase 2: Core Features (Week 3-4)
- [ ] Implement main execution loop
- [ ] Build safety monitor with Critical Point detection
- [ ] Create Fara Control Panel UI
- [ ] Add task history and logging

### Phase 3: Safety & UX (Week 5-6)
- [ ] Implement approval workflow
- [ ] Add live execution monitor
- [ ] Create task templates
- [ ] Build action audit trail

### Phase 4: Production Ready (Week 7-8)
- [ ] Add comprehensive error handling
- [ ] Implement rate limiting
- [ ] Set up monitoring and alerts
- [ ] Performance optimization
- [ ] Security hardening
- [ ] Documentation and testing

## Conclusion

This architecture provides a robust foundation for integrating Fara-7B into HAI, enabling autonomous computer operation while maintaining strong safety guardrails and user control. The modular design allows for incremental implementation and future enhancements.
