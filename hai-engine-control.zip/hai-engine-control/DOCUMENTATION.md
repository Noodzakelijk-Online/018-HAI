# HAI Engine Control Center - Complete Documentation

**Version:** 1.0.0  
**Author:** Manus AI  
**Last Updated:** November 6, 2025

---

## Table of Contents

1. [Introduction](#introduction)
2. [System Architecture](#system-architecture)
3. [Engine Overview](#engine-overview)
4. [Core Engines](#core-engines)
5. [Advanced Engines](#advanced-engines)
6. [Integration & Workflows](#integration--workflows)
7. [API Reference](#api-reference)
8. [Usage Examples](#usage-examples)
9. [Deployment & Operations](#deployment--operations)

---

## Introduction

The **HAI Engine Control Center** is a comprehensive platform for managing and orchestrating multiple AI-powered engines in a household automation context. The system provides real-time monitoring, autonomous decision-making, task orchestration, and multi-channel communication capabilities.

### Key Features

The platform delivers enterprise-grade automation through eleven specialized engines working in concert. Each engine operates at a defined autonomy level, from fully manual (Level 0) to fully autonomous (Level 3), enabling graduated delegation of household management tasks.

**Core Capabilities:**

The system provides conversational interaction through an AI-powered chat interface, enabling natural language control of all engines. Task orchestration manages complex workflows with dependency resolution and parallel execution. Policy enforcement ensures all operations comply with user-defined rules and constraints. The analytics engine delivers insights through comprehensive reporting and visualization.

**Advanced Features:**

Self-modeling capabilities learn user preferences and patterns over time. Knowledge graph technology maps relationships between entities for context-aware decision-making. Playbook automation executes predefined workflows with conditional branching. Multi-channel communication handles email, notifications, SMS, and chat messaging. The frontier engine discovers and integrates new services dynamically.

### System Requirements

The platform runs on modern web browsers with JavaScript enabled and requires a MySQL-compatible database for persistence. The backend service operates on Node.js 22+ with TypeScript support. Real-time features utilize WebSocket connections through the EventBus system.

---

## System Architecture

### Technology Stack

The application follows a modern full-stack architecture with clear separation of concerns. The frontend leverages React 19 with TypeScript for type safety, Tailwind CSS 4 for styling, and shadcn/ui components for consistent design. The backend runs on Express 4 with tRPC 11 for end-to-end type-safe API calls, Drizzle ORM for database access, and SuperJSON for seamless data serialization.

### Architectural Patterns

**Event-Driven Architecture:**

The EventBus serves as the central nervous system, enabling real-time communication between engines. Events flow through a publish-subscribe pattern, allowing engines to react to system changes without tight coupling. This architecture supports both synchronous request-response patterns and asynchronous event processing.

**Service-Oriented Design:**

Each engine operates as an independent service with well-defined interfaces. Services communicate through tRPC procedures for synchronous operations and EventBus events for asynchronous workflows. This modularity enables independent scaling, testing, and deployment of individual engines.

**Data Flow:**

User interactions flow through the React frontend to tRPC endpoints, which invoke engine services. Services access the database through Drizzle ORM and publish events to the EventBus. Other engines subscribe to relevant events and react accordingly, creating a responsive and coordinated system.

### Database Schema

The system uses a normalized relational schema with dedicated tables for each engine's domain. Core tables include users, engines, tasks, policies, and events. Advanced engines add specialized tables for conversations, decisions, knowledge graphs, playbooks, and communications. All tables use auto-incrementing integer primary keys and timestamp fields for audit trails.

---

## Engine Overview

### Autonomy Levels

The system defines four autonomy levels that determine how engines operate:

**Level 0 (Manual):** Engines require explicit user approval for every action. Suitable for critical operations like financial transactions or sensitive data access. Examples include the Connector Framework and Household Ledger.

**Level 1 (Assisted):** Engines suggest actions but wait for user confirmation. Provides recommendations with explanations, allowing users to learn system capabilities. The Analytics Engine operates at this level.

**Level 2 (Conditional):** Engines act autonomously within policy constraints. Can execute routine operations without approval but escalate edge cases. Decision Engine, Task Orchestration, Communication Engine, and Frontier Engine operate here.

**Level 3 (Autonomous):** Engines operate fully independently within their domain. Handle complex workflows and adapt to changing conditions. The Playbook Engine represents this highest level of automation.

### Priority Levels

Engines are assigned priority levels that determine resource allocation and escalation paths:

**Critical:** System-essential engines that must always be operational. Includes Policy Engine and Household Ledger for compliance and audit requirements.

**High:** Core functionality engines that directly impact user experience. Task Orchestration, Decision Engine, and Knowledge Graph operate at this level.

**Medium:** Enhancement engines that add value but aren't essential. Communication Engine, Playbook Engine, and Self-Model Engine fall into this category.

**Low:** Experimental or optional engines. Analytics Engine and Frontier Engine operate with lower priority.

---

## Core Engines

### 1. Analytics Engine (Level 0, Low Priority)

The Analytics Engine provides insights and reporting capabilities across all system operations. It aggregates data from multiple sources, generates visualizations, and delivers actionable intelligence.

**Capabilities:**

Data collection occurs continuously from all engines through EventBus subscriptions. The engine maintains time-series data for trending analysis and supports custom report generation. Visualization options include charts, graphs, and dashboards. Export functionality supports CSV, JSON, and PDF formats.

**Use Cases:**

Performance monitoring tracks system health metrics like response times, error rates, and resource utilization. Usage analytics reveal patterns in task execution, policy violations, and user interactions. Trend analysis identifies long-term patterns in household operations. Custom reports support specific analytical needs like energy consumption or task completion rates.

**API Endpoints:**

```typescript
// Get system-wide analytics
trpc.analytics.getSystemStats.useQuery();

// Generate custom report
trpc.analytics.generateReport.useMutation({
  type: 'usage',
  startDate: '2025-01-01',
  endDate: '2025-01-31',
  metrics: ['tasks', 'events', 'decisions']
});
```

### 2. Decision Engine (Level 2, High Priority)

The Decision Engine makes autonomous decisions within policy constraints. It evaluates options, applies decision frameworks, and executes approved actions.

**Decision Frameworks:**

The engine supports multiple decision-making approaches. Rule-based decisions apply if-then logic for straightforward scenarios. Weighted scoring evaluates options against multiple criteria with configurable weights. Cost-benefit analysis compares financial implications. Risk assessment evaluates potential downsides and mitigation strategies.

**Decision Process:**

Each decision follows a structured workflow. The engine receives a decision request with context and options. It evaluates each option against applicable policies and decision criteria. Options are scored and ranked based on the selected framework. The engine either executes the top-ranked option (if autonomy permits) or requests user approval. All decisions are logged with full audit trails.

**Integration:**

The Decision Engine integrates deeply with the Policy Engine to ensure compliance. It publishes decision events to the EventBus, allowing other engines to react. Task Orchestration can trigger decisions as part of workflows. The Knowledge Graph provides context for more informed decisions.

**API Endpoints:**

```typescript
// Create a decision
trpc.decision.create.useMutation({
  title: 'Select dinner restaurant',
  description: 'Choose restaurant for Friday dinner',
  options: [
    { label: 'Italian Restaurant', value: 'italian', metadata: { cost: 50, distance: 2 } },
    { label: 'Sushi Bar', value: 'sushi', metadata: { cost: 70, distance: 5 } }
  ],
  criteria: { cost: 0.6, distance: 0.4 }
});

// Get decision history
trpc.decision.list.useQuery({ status: 'approved', limit: 10 });
```

### 3. Self-Model Engine (Level 0, Medium Priority)

The Self-Model Engine learns user preferences and patterns over time. It builds a comprehensive model of user behavior, preferences, and habits to enable personalized automation.

**Learning Mechanisms:**

Explicit feedback comes from user ratings, preferences, and corrections. Implicit learning observes user behavior patterns like timing preferences, frequency of actions, and choice patterns. The engine employs collaborative filtering to suggest preferences based on similar users. Temporal analysis identifies time-based patterns like morning routines or weekend behaviors.

**Model Components:**

Preference profiles store user likes, dislikes, and neutral items across categories. Behavioral patterns capture routine actions and their typical timing. Context associations link preferences to situations like weather, time of day, or social context. Confidence scores indicate the reliability of learned patterns.

**Applications:**

Personalized recommendations suggest tasks, services, or actions based on learned preferences. Predictive scheduling anticipates user needs and pre-emptively prepares resources. Adaptive interfaces adjust UI elements based on usage patterns. Anomaly detection flags unusual behavior that might indicate errors or security issues.

**API Endpoints:**

```typescript
// Record user preference
trpc.selfModel.recordPreference.useMutation({
  category: 'food',
  item: 'pizza',
  rating: 5,
  context: { dayOfWeek: 'Friday', time: 'evening' }
});

// Get recommendations
trpc.selfModel.getRecommendations.useQuery({
  category: 'restaurants',
  context: { dayOfWeek: 'Saturday', time: 'lunch' },
  limit: 5
});
```

### 4. Policy Engine (Level 0, Critical Priority)

The Policy Engine enforces user-defined rules and constraints across all system operations. It acts as a gatekeeper, ensuring no action violates established policies.

**Policy Types:**

Permission policies define what actions are allowed or forbidden. Resource policies control access to services, data, and system resources. Time-based policies restrict operations to specific time windows. Budget policies enforce spending limits. Safety policies prevent dangerous or irreversible actions.

**Policy Evaluation:**

Every significant system action passes through policy evaluation. The engine checks all applicable policies in priority order. Conflicting policies are resolved using precedence rules (deny-by-default). Evaluation results include pass/fail status and violation details. Failed evaluations trigger notifications and logging.

**Policy Management:**

Users define policies through a declarative interface. Policies support conditions, exceptions, and temporal validity. The engine maintains a policy history for audit purposes. Policy changes take effect immediately across the system.

**API Endpoints:**

```typescript
// Create a policy
trpc.policies.create.useMutation({
  name: 'No purchases over $100',
  description: 'Require approval for large purchases',
  type: 'budget',
  conditions: { amount: { gt: 100 } },
  action: 'require_approval',
  isActive: true
});

// Evaluate action against policies
trpc.policies.evaluate.useMutation({
  action: 'purchase',
  context: { amount: 150, category: 'electronics' }
});
```

### 5. Task Orchestration Engine (Level 2, High Priority)

The Task Orchestration Engine manages task lifecycle and execution. It handles task creation, scheduling, dependency resolution, and parallel execution.

**Task Management:**

Tasks are created with metadata including title, description, priority, and deadline. The engine assigns tasks to appropriate executors (engines or external services). Status tracking covers pending, in_progress, completed, failed, and cancelled states. Dependencies ensure tasks execute in the correct order.

**Execution Strategies:**

Sequential execution runs tasks one after another. Parallel execution launches multiple independent tasks simultaneously. Conditional execution branches based on task results. Retry logic handles transient failures with exponential backoff.

**Integration:**

Task Orchestration coordinates with all engines. It triggers Playbook executions for complex workflows. Communication Engine sends notifications about task status. Knowledge Graph provides context for task execution. Decision Engine resolves ambiguities in task requirements.

**API Endpoints:**

```typescript
// Create a task
trpc.tasks.create.useMutation({
  title: 'Weekly grocery shopping',
  description: 'Buy items from shopping list',
  priority: 'medium',
  deadline: '2025-11-10T18:00:00Z',
  assignedTo: 'user',
  metadata: { category: 'shopping', recurring: 'weekly' }
});

// Update task status
trpc.tasks.updateStatus.useMutation({
  id: 123,
  status: 'completed',
  result: { itemsPurchased: 15, totalCost: 85.50 }
});
```

---

## Advanced Engines

### 6. Knowledge Graph Engine (Level 0, High Priority)

The Knowledge Graph Engine maintains a semantic network of entities and relationships. It enables context-aware operations by mapping connections between people, places, concepts, and events.

**Graph Structure:**

Entities represent discrete objects with types (person, organization, place, concept, event). Relationships connect entities with labeled edges indicating the connection type. Properties store attributes on both entities and relationships. The graph supports directed and weighted edges for nuanced modeling.

**Advanced Algorithms:**

Shortest path finding identifies connections between entities using Dijkstra's algorithm. Centrality analysis measures entity importance through degree, betweenness, and closeness metrics. Community detection groups related entities into clusters. Temporal tracking maintains relationship history and evolution.

**Query Capabilities:**

The engine supports complex graph queries. Path queries find all routes between entities. Neighborhood queries retrieve entities within N hops. Pattern matching identifies subgraph structures. Inference rules derive new relationships from existing ones.

**API Endpoints:**

```typescript
// Add entity
trpc.knowledgeGraph.addEntity.useMutation({
  name: 'John Doe',
  type: 'person',
  properties: { age: 35, occupation: 'engineer' }
});

// Add relationship
trpc.knowledgeGraph.addRelationship.useMutation({
  fromId: 1,
  toId: 2,
  type: 'works_with',
  properties: { since: '2020-01-01', department: 'engineering' }
});

// Find shortest path
trpc.knowledgeGraph.findShortestPath.useQuery({
  fromId: 1,
  toId: 5
});

// Get entity clusters
trpc.knowledgeGraph.getClusters.useQuery();
```

### 7. Playbook Engine (Level 3, Medium Priority)

The Playbook Engine executes predefined workflows with full autonomy. It supports complex automation scenarios with conditional logic, loops, and parallel execution.

**Workflow Definition:**

Playbooks consist of sequential steps with defined actions. Each step specifies an action type (engine call, condition evaluation, loop, parallel execution). Steps can branch based on conditions or previous results. Variables flow through the execution context, enabling dynamic behavior.

**Action Types:**

Action steps invoke engine operations like sending messages or creating tasks. Condition steps evaluate expressions and branch execution paths. Loop steps repeat actions until a condition is met. Parallel steps execute multiple actions concurrently. Each action supports parameters and variable substitution.

**Execution Engine:**

The engine processes playbooks step-by-step, maintaining execution state. It handles errors gracefully with retry logic and failure paths. Execution logs capture each step's result for debugging. The engine publishes events at key lifecycle points (started, step completed, finished, failed).

**Template Library:**

Reusable templates provide starting points for common workflows. Templates support variable placeholders for customization. Users can create playbooks from templates with specific parameters. Popular templates include morning routines, email triage, and meeting preparation.

**API Endpoints:**

```typescript
// Create playbook
trpc.playbook.create.useMutation({
  name: 'Morning Routine',
  description: 'Automated morning workflow',
  category: 'automation',
  definition: {
    steps: [
      {
        id: 'step1',
        name: 'Check Weather',
        type: 'action',
        action: 'check_weather',
        params: { location: 'current' },
        onSuccess: 'step2'
      },
      {
        id: 'step2',
        name: 'Send Summary',
        type: 'action',
        action: 'send_notification',
        params: {
          recipient: 'user',
          subject: 'Morning Summary',
          body: 'Weather: {{weather}}'
        }
      }
    ],
    variables: {},
    triggers: ['time:08:00']
  }
});

// Execute playbook
trpc.playbook.execute.useMutation({ playbookId: 1 });

// Get execution status
trpc.playbook.getExecution.useQuery({ executionId: 123 });
```

### 8. Communication Engine (Level 2, Medium Priority)

The Communication Engine handles multi-channel messaging with template support and delivery tracking. It unifies email, notifications, SMS, and chat into a single interface.

**Channel Support:**

Email delivery uses SMTP with HTML and plain text support. In-app notifications leverage the built-in notification system. SMS messaging integrates with providers like Twilio. Chat messages support real-time delivery through WebSocket connections.

**Template System:**

Templates define reusable message structures with variable placeholders. Variables use {{variableName}} syntax for substitution. Templates support conditional content and loops. The engine tracks template usage for analytics.

**Delivery Management:**

Messages queue for asynchronous delivery with retry logic. Status tracking covers draft, queued, sent, delivered, failed, and bounced states. Retry attempts use exponential backoff for transient failures. Delivery receipts update message status automatically.

**Integration:**

Playbook Engine can send messages as workflow actions. Task Orchestration sends notifications about task status. Decision Engine communicates approval requests. All engines can trigger communications through simple API calls.

**API Endpoints:**

```typescript
// Send message
trpc.communication.sendMessage.useMutation({
  channel: 'email',
  recipient: 'user@example.com',
  subject: 'Task Completed',
  body: 'Your task "Weekly Shopping" has been completed.',
  metadata: { taskId: 123 }
});

// Create template
trpc.communication.createTemplate.useMutation({
  name: 'Task Completion',
  description: 'Notification for completed tasks',
  channel: 'notification',
  subject: 'Task Completed: {{taskTitle}}',
  body: 'Your task "{{taskTitle}}" has been completed successfully.',
  variables: ['taskTitle']
});

// Get message history
trpc.communication.getMessages.useQuery({
  channel: 'email',
  status: 'sent',
  limit: 20
});
```

### 9. Household Ledger Engine (Level 0, Critical Priority)

The Household Ledger provides immutable event sourcing and audit trails for all operations. It maintains a complete history of system actions for compliance and debugging.

**Event Sourcing:**

Every significant system action generates a ledger event. Events are immutable once written, ensuring audit integrity. The ledger supports event replay for state reconstruction. Sequence numbers guarantee ordering and detect gaps.

**Event Structure:**

Each event includes a unique ID, timestamp, event type, actor, and payload. Metadata captures context like IP address, user agent, and session ID. Events link to related entities through foreign keys. Tags enable efficient querying and filtering.

**Query Capabilities:**

The ledger supports temporal queries to retrieve events within time ranges. Actor queries find all actions by a specific user or engine. Type queries filter by event category. Full-text search enables keyword-based discovery.

**Compliance:**

The ledger satisfies audit requirements for regulated environments. It provides non-repudiation through cryptographic signatures. Retention policies ensure data preservation. Export functionality supports compliance reporting.

**API Endpoints:**

```typescript
// Query ledger events
trpc.ledger.query.useQuery({
  startDate: '2025-11-01',
  endDate: '2025-11-30',
  eventType: 'task.completed',
  limit: 100
});

// Get event details
trpc.ledger.getEvent.useQuery({ eventId: 12345 });

// Export audit trail
trpc.ledger.export.useMutation({
  format: 'csv',
  startDate: '2025-01-01',
  endDate: '2025-12-31'
});
```

### 10. Frontier Engine (Level 2, Low Priority)

The Frontier Engine discovers and integrates new services dynamically. It explores available APIs, tests capabilities, and registers them with the system.

**Service Discovery:**

The engine maintains a registry of known service providers. It periodically scans for new services through API directories and registries. Discovery includes capability detection and compatibility testing. Successful discoveries are registered for system use.

**Integration Testing:**

New services undergo automated testing before activation. Tests verify API availability, authentication, and basic functionality. Performance benchmarks measure response times and reliability. Security scans check for vulnerabilities.

**Dynamic Registration:**

Approved services register with the Connector Framework. The engine generates integration code and configuration. Documentation is auto-generated from API specifications. Services become available to other engines immediately.

**API Endpoints:**

```typescript
// Discover services
trpc.frontier.discover.useMutation({
  category: 'weather',
  region: 'US'
});

// Test service
trpc.frontier.testService.useMutation({
  serviceId: 'weather-api-123',
  testCases: ['getCurrentWeather', 'getForecast']
});

// Register service
trpc.frontier.register.useMutation({
  serviceId: 'weather-api-123',
  name: 'Weather API',
  capabilities: ['current', 'forecast', 'alerts']
});
```

### 11. Connector Framework (Level 0, Critical Priority)

The Connector Framework provides a unified interface for external services. It handles authentication, rate limiting, error handling, and response normalization.

**Connector Types:**

REST API connectors handle HTTP-based services with JSON or XML responses. GraphQL connectors support modern graph-based APIs. WebSocket connectors enable real-time bidirectional communication. Database connectors provide direct data access.

**Authentication:**

The framework supports multiple authentication schemes including API keys, OAuth 2.0, JWT tokens, and basic authentication. Credentials are stored securely and rotated automatically. Token refresh happens transparently.

**Error Handling:**

Connectors implement retry logic with exponential backoff. Circuit breakers prevent cascading failures. Fallback strategies provide degraded functionality. All errors are logged with full context.

**API Endpoints:**

```typescript
// List available connectors
trpc.connectors.list.useQuery();

// Invoke connector
trpc.connectors.invoke.useMutation({
  connectorId: 'weather-api',
  method: 'getCurrentWeather',
  params: { location: 'San Francisco' }
});

// Get connector status
trpc.connectors.getStatus.useQuery({ connectorId: 'weather-api' });
```

---

## Integration & Workflows

### Cross-Engine Communication

Engines communicate through two primary mechanisms: synchronous tRPC calls for request-response patterns and asynchronous EventBus messages for fire-and-forget notifications.

**Synchronous Integration:**

Direct engine-to-engine calls occur through service imports. For example, the Playbook Engine imports CommunicationEngine to send messages. This pattern suits operations requiring immediate results or error handling.

**Asynchronous Integration:**

EventBus enables loose coupling between engines. An engine publishes an event without knowing subscribers. Interested engines subscribe to event types and react independently. This pattern supports scalability and resilience.

### Common Workflow Patterns

**Approval Workflow:**

A task requires user approval before execution. Task Orchestration creates a decision through Decision Engine. Decision Engine evaluates policies and requests user input if needed. Upon approval, Task Orchestration proceeds with execution. Communication Engine notifies the user of completion.

**Automated Workflow:**

A playbook executes a morning routine autonomously. Playbook Engine triggers at 8:00 AM. It checks weather through Connector Framework. Knowledge Graph provides context about user preferences. Communication Engine sends a personalized summary. All actions log to Household Ledger.

**Data-Driven Workflow:**

Analytics Engine detects unusual spending patterns. It queries Knowledge Graph for transaction context. Decision Engine evaluates whether to alert the user. Communication Engine sends a notification if thresholds are exceeded. Policy Engine logs the decision for audit.

### Event Catalog

The system defines standard event types for inter-engine communication:

**Task Events:**
- `task.created`: New task added to the system
- `task.started`: Task execution began
- `task.completed`: Task finished successfully
- `task.failed`: Task encountered an error

**Communication Events:**
- `communication.message.queued`: Message queued for delivery
- `communication.message.sent`: Message successfully sent
- `communication.message.failed`: Message delivery failed

**Playbook Events:**
- `playbook.execution.started`: Playbook execution began
- `playbook.execution.step.completed`: Individual step finished
- `playbook.execution.completed`: Playbook finished successfully
- `playbook.execution.failed`: Playbook encountered an error

**Decision Events:**
- `decision.created`: New decision requires evaluation
- `decision.approved`: Decision approved for execution
- `decision.rejected`: Decision rejected by user or policy

---

## API Reference

### Authentication

All API endpoints require authentication through Manus OAuth. The system maintains session cookies for authenticated users. API calls include user context automatically through tRPC middleware.

### Error Handling

API errors follow standard HTTP status codes and tRPC error types:

- `BAD_REQUEST`: Invalid input parameters
- `UNAUTHORIZED`: Authentication required
- `FORBIDDEN`: Insufficient permissions
- `NOT_FOUND`: Resource does not exist
- `INTERNAL_SERVER_ERROR`: Server-side error

Error responses include descriptive messages and error codes for client handling.

### Rate Limiting

API endpoints implement rate limiting to prevent abuse. Limits vary by endpoint criticality:

- Read operations: 100 requests per minute
- Write operations: 20 requests per minute
- Bulk operations: 5 requests per minute

Rate limit headers indicate remaining quota and reset time.

### Pagination

List endpoints support pagination through `limit` and `offset` parameters:

```typescript
trpc.tasks.list.useQuery({
  limit: 20,
  offset: 40,
  status: 'in_progress'
});
```

Responses include total count and pagination metadata.

---

## Usage Examples

### Example 1: Creating an Automated Morning Routine

This example demonstrates creating a playbook that executes every morning at 8:00 AM, checks the weather, retrieves calendar events, and sends a summary notification.

```typescript
// Create the morning routine playbook
const playbook = await trpc.playbook.create.mutate({
  name: 'Morning Routine',
  description: 'Automated morning summary with weather and calendar',
  category: 'automation',
  definition: {
    steps: [
      {
        id: 'check_weather',
        name: 'Check Weather',
        type: 'action',
        action: 'connector_invoke',
        params: {
          connectorId: 'weather-api',
          method: 'getCurrentWeather',
          location: 'current'
        },
        onSuccess: 'check_calendar'
      },
      {
        id: 'check_calendar',
        name: 'Get Calendar Events',
        type: 'action',
        action: 'connector_invoke',
        params: {
          connectorId: 'calendar-api',
          method: 'getEvents',
          timeframe: 'today'
        },
        onSuccess: 'send_summary'
      },
      {
        id: 'send_summary',
        name: 'Send Morning Summary',
        type: 'action',
        action: 'send_notification',
        params: {
          recipient: 'user',
          subject: 'Good Morning!',
          body: 'Weather: {{weather}}\nEvents: {{events}}'
        }
      }
    ],
    variables: {
      weather: '',
      events: ''
    },
    triggers: ['time:08:00']
  }
});

// The playbook will execute automatically at 8:00 AM each day
```

### Example 2: Policy-Constrained Task Execution

This example shows how to create a task that requires policy evaluation before execution.

```typescript
// Define a budget policy
await trpc.policies.create.mutate({
  name: 'Large Purchase Approval',
  description: 'Require approval for purchases over $100',
  type: 'budget',
  conditions: {
    action: 'purchase',
    amount: { gt: 100 }
  },
  action: 'require_approval',
  isActive: true
});

// Create a task that will be evaluated against policies
const task = await trpc.tasks.create.mutate({
  title: 'Purchase new laptop',
  description: 'Buy laptop for home office',
  priority: 'high',
  metadata: {
    action: 'purchase',
    amount: 1200,
    category: 'electronics'
  }
});

// Task Orchestration will automatically check policies
// If amount > $100, Decision Engine creates an approval request
// User receives notification through Communication Engine
// Upon approval, task proceeds to execution
```

### Example 3: Knowledge Graph-Enhanced Decision Making

This example demonstrates using the Knowledge Graph to provide context for decision-making.

```typescript
// Build knowledge graph with entities and relationships
await trpc.knowledgeGraph.addEntity.mutate({
  name: 'Italian Restaurant',
  type: 'place',
  properties: { cuisine: 'italian', priceRange: '$$', rating: 4.5 }
});

await trpc.knowledgeGraph.addEntity.mutate({
  name: 'User',
  type: 'person',
  properties: { name: 'John' }
});

await trpc.knowledgeGraph.addRelationship.mutate({
  fromId: 2, // User
  toId: 1, // Italian Restaurant
  type: 'likes',
  properties: { frequency: 'often', lastVisit: '2025-10-15' }
});

// Create decision with Knowledge Graph context
const decision = await trpc.decision.create.mutate({
  title: 'Choose dinner restaurant',
  description: 'Select restaurant for Friday dinner',
  options: [
    { label: 'Italian Restaurant', value: 'italian', metadata: { entityId: 1 } },
    { label: 'Sushi Bar', value: 'sushi', metadata: { entityId: 3 } }
  ],
  useKnowledgeGraph: true
});

// Decision Engine queries Knowledge Graph for user preferences
// It finds the 'likes' relationship and weights the Italian restaurant higher
// Decision is made automatically if autonomy level permits
```

---

## Deployment & Operations

### Environment Configuration

The system requires several environment variables for operation:

**Database Configuration:**
- `DATABASE_URL`: MySQL connection string
- `DATABASE_POOL_SIZE`: Connection pool size (default: 10)

**Authentication:**
- `JWT_SECRET`: Session signing secret
- `OAUTH_SERVER_URL`: Manus OAuth backend URL
- `OWNER_OPEN_ID`: System owner identifier

**External Services:**
- `BUILT_IN_FORGE_API_URL`: Manus API endpoint
- `BUILT_IN_FORGE_API_KEY`: API authentication token

### Database Migrations

Schema changes use Drizzle Kit for migrations:

```bash
# Generate migration from schema changes
pnpm drizzle-kit generate

# Apply migrations to database
pnpm db:push

# Rollback last migration
pnpm db:rollback
```

### Monitoring & Logging

The system provides comprehensive logging at multiple levels:

**Application Logs:**
- Engine operations log to console with structured format
- Log levels: DEBUG, INFO, WARN, ERROR
- Logs include timestamp, source, and context

**Event Logs:**
- All EventBus messages are logged
- Event history available through Events page
- Queryable by type, source, and time range

**Audit Logs:**
- Household Ledger captures all significant actions
- Immutable audit trail for compliance
- Exportable for external analysis

### Performance Optimization

**Database Optimization:**
- Add indexes on frequently queried columns
- Use connection pooling for concurrent requests
- Implement query result caching for read-heavy operations

**Frontend Optimization:**
- Enable tRPC query caching with appropriate stale times
- Implement optimistic updates for instant UI feedback
- Use React.memo for expensive component renders

**Backend Optimization:**
- Batch database operations where possible
- Use async/await for I/O-bound operations
- Implement rate limiting to prevent abuse

### Backup & Recovery

**Database Backups:**
- Automated daily backups of MySQL database
- Backup retention: 30 days
- Point-in-time recovery supported

**Configuration Backups:**
- Export policies, playbooks, and templates regularly
- Store backups in version control
- Document custom configurations

**Disaster Recovery:**
- Maintain off-site backup copies
- Test recovery procedures quarterly
- Document recovery time objectives (RTO) and recovery point objectives (RPO)

### Security Best Practices

**Authentication & Authorization:**
- Enforce strong password policies
- Implement multi-factor authentication for sensitive operations
- Use role-based access control (RBAC)

**Data Protection:**
- Encrypt sensitive data at rest
- Use TLS for all network communication
- Implement data retention policies

**Vulnerability Management:**
- Keep dependencies updated
- Scan for security vulnerabilities regularly
- Follow secure coding practices

---

## Conclusion

The HAI Engine Control Center provides a comprehensive platform for household automation with enterprise-grade capabilities. Its modular architecture, event-driven design, and graduated autonomy levels enable sophisticated automation while maintaining user control.

The system continues to evolve with new engines, enhanced integrations, and improved intelligence. Future enhancements may include machine learning for predictive automation, voice interface integration, and expanded external service support.

For questions, issues, or feature requests, please refer to the project repository or contact the development team.

---

**Document Version:** 1.0.0  
**Last Updated:** November 6, 2025  
**Author:** Manus AI
