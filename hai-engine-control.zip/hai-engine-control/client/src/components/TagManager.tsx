import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Edit, Trash2, Tag as TagIcon } from "lucide-react";
import { toast } from "sonner";

interface TagManagerProps {
  serviceId?: number;
  onTagsChange?: () => void;
}

const DEFAULT_COLORS = [
  "#ef4444", // red
  "#f97316", // orange
  "#f59e0b", // amber
  "#eab308", // yellow
  "#84cc16", // lime
  "#22c55e", // green
  "#10b981", // emerald
  "#14b8a6", // teal
  "#06b6d4", // cyan
  "#0ea5e9", // sky
  "#3b82f6", // blue
  "#6366f1", // indigo
  "#8b5cf6", // violet
  "#a855f7", // purple
  "#d946ef", // fuchsia
  "#ec4899", // pink
];

export function TagManager({ serviceId, onTagsChange }: TagManagerProps) {
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingTag, setEditingTag] = useState<any>(null);
  const [newTag, setNewTag] = useState({ name: "", color: "#3b82f6" });

  const utils = trpc.useUtils();
  const { data: allTags = [] } = trpc.tags.list.useQuery();
  const { data: serviceTags = [] } = trpc.tags.getServiceTags.useQuery(
    { serviceId: serviceId! },
    { enabled: !!serviceId }
  );

  const createMutation = trpc.tags.create.useMutation({
    onSuccess: () => {
      utils.tags.list.invalidate();
      setIsCreateOpen(false);
      setNewTag({ name: "", color: "#3b82f6" });
      toast.success("Tag created");
    },
    onError: (error) => {
      toast.error(`Failed to create tag: ${error.message}`);
    },
  });

  const updateMutation = trpc.tags.update.useMutation({
    onSuccess: () => {
      utils.tags.list.invalidate();
      if (serviceId) utils.tags.getServiceTags.invalidate({ serviceId });
      setIsEditOpen(false);
      setEditingTag(null);
      toast.success("Tag updated");
    },
    onError: (error) => {
      toast.error(`Failed to update tag: ${error.message}`);
    },
  });

  const deleteMutation = trpc.tags.delete.useMutation({
    onSuccess: () => {
      utils.tags.list.invalidate();
      if (serviceId) utils.tags.getServiceTags.invalidate({ serviceId });
      toast.success("Tag deleted");
      onTagsChange?.();
    },
    onError: (error) => {
      toast.error(`Failed to delete tag: ${error.message}`);
    },
  });

  const addToServiceMutation = trpc.tags.addToService.useMutation({
    onSuccess: () => {
      if (serviceId) utils.tags.getServiceTags.invalidate({ serviceId });
      toast.success("Tag added to service");
      onTagsChange?.();
    },
    onError: (error) => {
      toast.error(`Failed to add tag: ${error.message}`);
    },
  });

  const removeFromServiceMutation = trpc.tags.removeFromService.useMutation({
    onSuccess: () => {
      if (serviceId) utils.tags.getServiceTags.invalidate({ serviceId });
      toast.success("Tag removed from service");
      onTagsChange?.();
    },
    onError: (error) => {
      toast.error(`Failed to remove tag: ${error.message}`);
    },
  });

  const handleCreate = () => {
    if (!newTag.name.trim()) {
      toast.error("Tag name is required");
      return;
    }
    createMutation.mutate(newTag);
  };

  const handleUpdate = () => {
    if (!editingTag?.name.trim()) {
      toast.error("Tag name is required");
      return;
    }
    updateMutation.mutate({
      id: editingTag.id,
      name: editingTag.name,
      color: editingTag.color,
    });
  };

  const handleDelete = (tagId: number) => {
    if (confirm("Delete this tag? It will be removed from all services.")) {
      deleteMutation.mutate({ id: tagId });
    }
  };

  const handleToggleTag = (tagId: number) => {
    const isAssigned = serviceTags.some((t) => t.id === tagId);
    if (isAssigned) {
      removeFromServiceMutation.mutate({ serviceId: serviceId!, tagId });
    } else {
      addToServiceMutation.mutate({ serviceId: serviceId!, tagId });
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <TagIcon className="h-5 w-5 text-muted-foreground" />
          <h3 className="font-semibold">Tags</h3>
        </div>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm">
              <Plus className="mr-2 h-4 w-4" />
              New Tag
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Tag</DialogTitle>
              <DialogDescription>Add a new tag to organize your services</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="tag-name">Tag Name</Label>
                <Input
                  id="tag-name"
                  placeholder="Work, Personal, Client..."
                  value={newTag.name}
                  onChange={(e) => setNewTag({ ...newTag, name: e.target.value })}
                />
              </div>
              <div className="grid gap-2">
                <Label>Color</Label>
                <div className="grid grid-cols-8 gap-2">
                  {DEFAULT_COLORS.map((color) => (
                    <button
                      key={color}
                      className={`h-8 w-8 rounded border-2 transition-all ${
                        newTag.color === color ? "border-foreground scale-110" : "border-transparent"
                      }`}
                      style={{ backgroundColor: color }}
                      onClick={() => setNewTag({ ...newTag, color })}
                    />
                  ))}
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleCreate} disabled={createMutation.isPending}>
                {createMutation.isPending ? "Creating..." : "Create Tag"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Tag List */}
      <div className="flex flex-wrap gap-2">
        {allTags.length === 0 ? (
          <p className="text-sm text-muted-foreground">No tags yet. Create one to get started.</p>
        ) : (
          allTags.map((tag) => {
            const isAssigned = serviceId ? serviceTags.some((t) => t.id === tag.id) : false;
            return (
              <div key={tag.id} className="group relative">
                <Badge
                  variant={isAssigned ? "default" : "outline"}
                  className="cursor-pointer pr-8"
                  style={
                    isAssigned
                      ? { backgroundColor: tag.color, borderColor: tag.color }
                      : { borderColor: tag.color, color: tag.color }
                  }
                  onClick={() => serviceId && handleToggleTag(tag.id)}
                >
                  {tag.name}
                </Badge>
                <div className="absolute right-1 top-1/2 -translate-y-1/2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    className="h-4 w-4 flex items-center justify-center hover:text-foreground"
                    onClick={(e) => {
                      e.stopPropagation();
                      setEditingTag(tag);
                      setIsEditOpen(true);
                    }}
                  >
                    <Edit className="h-3 w-3" />
                  </button>
                  <button
                    className="h-4 w-4 flex items-center justify-center hover:text-destructive"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDelete(tag.id);
                    }}
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Edit Dialog */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Tag</DialogTitle>
            <DialogDescription>Update tag name and color</DialogDescription>
          </DialogHeader>
          {editingTag && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-tag-name">Tag Name</Label>
                <Input
                  id="edit-tag-name"
                  value={editingTag.name}
                  onChange={(e) => setEditingTag({ ...editingTag, name: e.target.value })}
                />
              </div>
              <div className="grid gap-2">
                <Label>Color</Label>
                <div className="grid grid-cols-8 gap-2">
                  {DEFAULT_COLORS.map((color) => (
                    <button
                      key={color}
                      className={`h-8 w-8 rounded border-2 transition-all ${
                        editingTag.color === color ? "border-foreground scale-110" : "border-transparent"
                      }`}
                      style={{ backgroundColor: color }}
                      onClick={() => setEditingTag({ ...editingTag, color })}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdate} disabled={updateMutation.isPending}>
              {updateMutation.isPending ? "Updating..." : "Update Tag"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
