import { useState } from "react";
import { serviceTemplates, serviceCategories, ServiceTemplate } from "@shared/serviceTemplates";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Search, Sparkles } from "lucide-react";

interface ServiceTemplateSelectorProps {
  onSelect: (template: ServiceTemplate) => void;
}

export function ServiceTemplateSelector({ onSelect }: ServiceTemplateSelectorProps) {
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const filteredTemplates = serviceTemplates.filter((template) => {
    const matchesSearch =
      search === "" ||
      template.name.toLowerCase().includes(search.toLowerCase()) ||
      template.description.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = !selectedCategory || template.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = Object.entries(serviceCategories);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Sparkles className="h-5 w-5 text-primary" />
        <h3 className="font-semibold">Quick Add from Templates</h3>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search templates..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap gap-2">
        <Badge
          variant={selectedCategory === null ? "default" : "outline"}
          className="cursor-pointer"
          onClick={() => setSelectedCategory(null)}
        >
          All
        </Badge>
        {categories.map(([key, { label, icon }]) => (
          <Badge
            key={key}
            variant={selectedCategory === key ? "default" : "outline"}
            className="cursor-pointer"
            onClick={() => setSelectedCategory(key)}
          >
            {icon} {label}
          </Badge>
        ))}
      </div>

      {/* Templates Grid */}
      <ScrollArea className="h-[400px] pr-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {filteredTemplates.map((template) => (
            <Button
              key={template.name}
              variant="outline"
              className="h-auto p-4 flex flex-col items-start gap-2 hover:border-primary"
              onClick={() => onSelect(template)}
            >
              <div className="flex items-center gap-2 w-full">
                <span className="text-2xl">{template.icon}</span>
                <div className="flex-1 text-left">
                  <p className="font-medium">{template.name}</p>
                  <p className="text-xs text-muted-foreground line-clamp-1">
                    {template.description}
                  </p>
                </div>
              </div>
              <Badge variant="secondary" className="text-xs">
                {serviceCategories[template.category].icon}{" "}
                {serviceCategories[template.category].label}
              </Badge>
            </Button>
          ))}
        </div>

        {filteredTemplates.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <p>No templates found matching your search.</p>
          </div>
        )}
      </ScrollArea>

      <p className="text-xs text-muted-foreground">
        💡 Tip: Templates pre-fill the service name and URL. You can customize them after adding.
      </p>
    </div>
  );
}
