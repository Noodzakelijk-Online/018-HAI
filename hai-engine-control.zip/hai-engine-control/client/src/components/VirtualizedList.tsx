/**
 * VirtualizedList Component
 * 
 * A performant list component that only renders visible items.
 * Uses react-window for virtualization to handle large datasets efficiently.
 * 
 * Performance benefits:
 * - Only renders visible items (typically 10-20 instead of 100s)
 * - Reduces DOM nodes by 90%+
 * - Smooth scrolling even with 10,000+ items
 */

import { FixedSizeList as List } from 'react-window';
import { useRef, useCallback, CSSProperties } from 'react';

interface VirtualizedListProps<T> {
  items: T[];
  height: number;
  itemHeight: number;
  renderItem: (item: T, index: number, style: CSSProperties) => React.ReactNode;
  className?: string;
  overscanCount?: number;
}

/**
 * Generic virtualized list component
 * 
 * @example
 * <VirtualizedList
 *   items={activities}
 *   height={400}
 *   itemHeight={72}
 *   renderItem={(item, index, style) => (
 *     <div style={style} key={item.id}>
 *       <ActivityCard activity={item} />
 *     </div>
 *   )}
 * />
 */
export function VirtualizedList<T>({
  items,
  height,
  itemHeight,
  renderItem,
  className,
  overscanCount = 5,
}: VirtualizedListProps<T>) {
  const listRef = useRef<List>(null);

  const Row = useCallback(
    ({ index, style }: { index: number; style: CSSProperties }) => {
      const item = items[index];
      return renderItem(item, index, style);
    },
    [items, renderItem]
  );

  if (items.length === 0) {
    return null;
  }

  return (
    <List
      ref={listRef}
      className={className}
      height={height}
      itemCount={items.length}
      itemSize={itemHeight}
      width="100%"
      overscanCount={overscanCount}
    >
      {Row}
    </List>
  );
}

/**
 * Auto-sizing virtualized list that fills its container
 */
interface AutoSizeVirtualizedListProps<T> extends Omit<VirtualizedListProps<T>, 'height'> {
  minHeight?: number;
  maxHeight?: number;
}

export function AutoSizeVirtualizedList<T>({
  items,
  itemHeight,
  renderItem,
  className,
  overscanCount = 5,
  minHeight = 200,
  maxHeight = 600,
}: AutoSizeVirtualizedListProps<T>) {
  // Calculate optimal height based on item count
  const calculatedHeight = Math.min(
    Math.max(items.length * itemHeight, minHeight),
    maxHeight
  );

  return (
    <VirtualizedList
      items={items}
      height={calculatedHeight}
      itemHeight={itemHeight}
      renderItem={renderItem}
      className={className}
      overscanCount={overscanCount}
    />
  );
}

/**
 * Hook to determine if virtualization should be used
 * Returns true if list has more than threshold items
 */
export function useVirtualization(itemCount: number, threshold: number = 20): boolean {
  return itemCount > threshold;
}

export default VirtualizedList;
