import { useEffect, useRef, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ZoomIn, ZoomOut, Maximize2, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';

export interface GraphNode {
  id: string;
  label: string;
  type: string;
  properties?: Record<string, any>;
  x?: number;
  y?: number;
}

export interface GraphEdge {
  id: string;
  from: string;
  to: string;
  label?: string;
  weight?: number;
}

interface GraphVisualizationProps {
  nodes: GraphNode[];
  edges: GraphEdge[];
  onNodeClick?: (node: GraphNode) => void;
  onEdgeClick?: (edge: GraphEdge) => void;
  highlightedNodes?: string[];
  highlightedEdges?: string[];
}

const nodeColors: Record<string, string> = {
  person: '#3b82f6',
  organization: '#8b5cf6',
  place: '#10b981',
  concept: '#f59e0b',
  event: '#ef4444',
  default: '#6b7280',
};

export function GraphVisualization({
  nodes,
  edges,
  onNodeClick,
  onEdgeClick,
  highlightedNodes = [],
  highlightedEdges = [],
}: GraphVisualizationProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  // Initialize node positions using force-directed layout simulation
  useEffect(() => {
    if (nodes.length === 0) return;

    // Simple circular layout for initial positions
    const centerX = 400;
    const centerY = 300;
    const radius = Math.min(300, 50 + nodes.length * 10);

    nodes.forEach((node, i) => {
      if (!node.x || !node.y) {
        const angle = (i / nodes.length) * 2 * Math.PI;
        node.x = centerX + radius * Math.cos(angle);
        node.y = centerY + radius * Math.sin(angle);
      }
    });

    // Simple force simulation (simplified)
    const iterations = 50;
    for (let iter = 0; iter < iterations; iter++) {
      // Repulsion between nodes
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[j].x! - nodes[i].x!;
          const dy = nodes[j].y! - nodes[i].y!;
          const dist = Math.sqrt(dx * dx + dy * dy) || 1;
          const force = 1000 / (dist * dist);

          nodes[i].x! -= (dx / dist) * force;
          nodes[i].y! -= (dy / dist) * force;
          nodes[j].x! += (dx / dist) * force;
          nodes[j].y! += (dy / dist) * force;
        }
      }

      // Attraction along edges
      edges.forEach((edge) => {
        const fromNode = nodes.find((n) => n.id === edge.from);
        const toNode = nodes.find((n) => n.id === edge.to);

        if (fromNode && toNode) {
          const dx = toNode.x! - fromNode.x!;
          const dy = toNode.y! - fromNode.y!;
          const dist = Math.sqrt(dx * dx + dy * dy) || 1;
          const force = dist * 0.01;

          fromNode.x! += (dx / dist) * force;
          fromNode.y! += (dy / dist) * force;
          toNode.x! -= (dx / dist) * force;
          toNode.y! -= (dy / dist) * force;
        }
      });
    }
  }, [nodes.length, edges.length]);

  // Draw graph
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Apply transformations
    ctx.save();
    ctx.translate(pan.x, pan.y);
    ctx.scale(zoom, zoom);

    // Draw edges
    edges.forEach((edge) => {
      const fromNode = nodes.find((n) => n.id === edge.from);
      const toNode = nodes.find((n) => n.id === edge.to);

      if (!fromNode || !toNode) return;

      const isHighlighted = highlightedEdges.includes(edge.id);

      ctx.beginPath();
      ctx.moveTo(fromNode.x!, fromNode.y!);
      ctx.lineTo(toNode.x!, toNode.y!);
      ctx.strokeStyle = isHighlighted ? '#3b82f6' : '#d1d5db';
      ctx.lineWidth = isHighlighted ? 3 : 1;
      ctx.stroke();

      // Draw arrow
      const angle = Math.atan2(toNode.y! - fromNode.y!, toNode.x! - fromNode.x!);
      const arrowSize = 10;
      ctx.beginPath();
      ctx.moveTo(
        toNode.x! - 20 * Math.cos(angle),
        toNode.y! - 20 * Math.sin(angle)
      );
      ctx.lineTo(
        toNode.x! - 20 * Math.cos(angle) - arrowSize * Math.cos(angle - Math.PI / 6),
        toNode.y! - 20 * Math.sin(angle) - arrowSize * Math.sin(angle - Math.PI / 6)
      );
      ctx.lineTo(
        toNode.x! - 20 * Math.cos(angle) - arrowSize * Math.cos(angle + Math.PI / 6),
        toNode.y! - 20 * Math.sin(angle) - arrowSize * Math.sin(angle + Math.PI / 6)
      );
      ctx.closePath();
      ctx.fillStyle = isHighlighted ? '#3b82f6' : '#d1d5db';
      ctx.fill();

      // Draw edge label
      if (edge.label) {
        const midX = (fromNode.x! + toNode.x!) / 2;
        const midY = (fromNode.y! + toNode.y!) / 2;
        ctx.font = '10px sans-serif';
        ctx.fillStyle = '#6b7280';
        ctx.textAlign = 'center';
        ctx.fillText(edge.label, midX, midY - 5);
      }
    });

    // Draw nodes
    nodes.forEach((node) => {
      const isHighlighted = highlightedNodes.includes(node.id);
      const isSelected = selectedNode?.id === node.id;
      const matches = searchTerm && node.label.toLowerCase().includes(searchTerm.toLowerCase());

      const color = nodeColors[node.type] || nodeColors.default;
      const radius = isSelected ? 25 : isHighlighted || matches ? 22 : 20;

      // Draw node circle
      ctx.beginPath();
      ctx.arc(node.x!, node.y!, radius, 0, 2 * Math.PI);
      ctx.fillStyle = color;
      ctx.fill();

      if (isSelected || isHighlighted) {
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 3;
        ctx.stroke();
      }

      // Draw node label
      ctx.font = isSelected ? 'bold 12px sans-serif' : '11px sans-serif';
      ctx.fillStyle = '#1f2937';
      ctx.textAlign = 'center';
      ctx.fillText(node.label, node.x!, node.y! + radius + 15);
    });

    ctx.restore();
  }, [nodes, edges, zoom, pan, highlightedNodes, highlightedEdges, selectedNode, searchTerm]);

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left - pan.x) / zoom;
    const y = (e.clientY - rect.top - pan.y) / zoom;

    // Find clicked node
    const clickedNode = nodes.find((node) => {
      const dx = x - node.x!;
      const dy = y - node.y!;
      return Math.sqrt(dx * dx + dy * dy) < 20;
    });

    if (clickedNode) {
      setSelectedNode(clickedNode);
      onNodeClick?.(clickedNode);
    } else {
      setSelectedNode(null);
    }
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging) return;
    setPan({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleZoomIn = () => setZoom((z) => Math.min(z * 1.2, 3));
  const handleZoomOut = () => setZoom((z) => Math.max(z / 1.2, 0.3));
  const handleResetView = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  const filteredNodes = searchTerm
    ? nodes.filter((n) => n.label.toLowerCase().includes(searchTerm.toLowerCase()))
    : nodes;

  return (
    <div className="space-y-4">
      {/* Controls */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Knowledge Graph</CardTitle>
              <CardDescription>
                {nodes.length} nodes, {edges.length} relationships
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative w-64">
                <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search nodes..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8"
                />
              </div>
              <Button variant="outline" size="sm" onClick={handleZoomIn}>
                <ZoomIn className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={handleZoomOut}>
                <ZoomOut className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={handleResetView}>
                <Maximize2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      <div className="flex gap-4">
        {/* Canvas */}
        <Card className="flex-1">
          <CardContent className="p-0">
            <canvas
              ref={canvasRef}
              width={800}
              height={600}
              className="w-full h-[600px] cursor-move"
              onClick={handleCanvasClick}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
            />
          </CardContent>
        </Card>

        {/* Node details */}
        {selectedNode && (
          <Card className="w-80 flex-shrink-0">
            <CardHeader>
              <CardTitle className="text-base">{selectedNode.label}</CardTitle>
              <CardDescription>
                <Badge variant="secondary">{selectedNode.type}</Badge>
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {selectedNode.properties &&
                Object.entries(selectedNode.properties).map(([key, value]) => (
                  <div key={key} className="text-sm">
                    <span className="font-medium text-muted-foreground">{key}:</span>{' '}
                    <span>{String(value)}</span>
                  </div>
                ))}

              <div className="pt-4 border-t">
                <div className="text-sm font-medium mb-2">Connections</div>
                <div className="space-y-1">
                  {edges
                    .filter((e) => e.from === selectedNode.id || e.to === selectedNode.id)
                    .map((edge) => {
                      const otherNodeId = edge.from === selectedNode.id ? edge.to : edge.from;
                      const otherNode = nodes.find((n) => n.id === otherNodeId);
                      return (
                        <div key={edge.id} className="text-xs text-muted-foreground">
                          {edge.from === selectedNode.id ? '→' : '←'} {otherNode?.label}{' '}
                          {edge.label && `(${edge.label})`}
                        </div>
                      );
                    })}
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Legend */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-wrap gap-4">
            {Object.entries(nodeColors).map(([type, color]) => (
              <div key={type} className="flex items-center gap-2">
                <div
                  className="w-4 h-4 rounded-full"
                  style={{ backgroundColor: color }}
                />
                <span className="text-sm capitalize">{type}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
