import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Mail, Plus, X } from "lucide-react";
import { toast } from "sonner";

interface EmailComposerDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSend: (email: EmailData) => Promise<void>;
  connectorName?: string;
}

export interface EmailData {
  to: string[];
  cc?: string[];
  bcc?: string[];
  subject: string;
  body: string;
}

export function EmailComposerDialog({
  open,
  onOpenChange,
  onSend,
  connectorName = "Gmail",
}: EmailComposerDialogProps) {
  const [to, setTo] = useState<string[]>([""]);
  const [cc, setCc] = useState<string[]>([]);
  const [bcc, setBcc] = useState<string[]>([]);
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);
  const [showCc, setShowCc] = useState(false);
  const [showBcc, setShowBcc] = useState(false);

  const handleAddRecipient = (
    type: "to" | "cc" | "bcc",
    setter: React.Dispatch<React.SetStateAction<string[]>>
  ) => {
    setter((prev) => [...prev, ""]);
  };

  const handleRemoveRecipient = (
    index: number,
    setter: React.Dispatch<React.SetStateAction<string[]>>
  ) => {
    setter((prev) => prev.filter((_, i) => i !== index));
  };

  const handleRecipientChange = (
    index: number,
    value: string,
    setter: React.Dispatch<React.SetStateAction<string[]>>
  ) => {
    setter((prev) => prev.map((email, i) => (i === index ? value : email)));
  };

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleSend = async () => {
    // Validate recipients
    const validTo = to.filter((email) => email.trim() !== "");
    if (validTo.length === 0) {
      toast.error("Please enter at least one recipient");
      return;
    }

    // Validate email format
    const allEmails = [...validTo, ...cc, ...bcc].filter((e) => e.trim() !== "");
    const invalidEmails = allEmails.filter((email) => !validateEmail(email));
    if (invalidEmails.length > 0) {
      toast.error(`Invalid email address: ${invalidEmails[0]}`);
      return;
    }

    // Validate subject
    if (!subject.trim()) {
      toast.error("Please enter a subject");
      return;
    }

    // Validate body
    if (!body.trim()) {
      toast.error("Please enter a message");
      return;
    }

    setSending(true);
    try {
      await onSend({
        to: validTo,
        cc: cc.filter((e) => e.trim() !== ""),
        bcc: bcc.filter((e) => e.trim() !== ""),
        subject,
        body,
      });

      // Reset form
      setTo([""]);
      setCc([]);
      setBcc([]);
      setSubject("");
      setBody("");
      setShowCc(false);
      setShowBcc(false);
      onOpenChange(false);
    } catch (error: any) {
      // Error is handled by parent component
      console.error("Email send error:", error);
    } finally {
      setSending(false);
    }
  };

  const handleClose = () => {
    if (sending) return;
    
    // Warn if there's unsaved content
    const hasContent = to.some(e => e.trim()) || subject.trim() || body.trim();
    if (hasContent && !confirm("Discard draft email?")) {
      return;
    }

    // Reset form
    setTo([""]);
    setCc([]);
    setBcc([]);
    setSubject("");
    setBody("");
    setShowCc(false);
    setShowBcc(false);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5" />
            Compose Email
          </DialogTitle>
          <DialogDescription>
            Send email via {connectorName} connector
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* To Field */}
          <div className="space-y-2">
            <Label htmlFor="to">To *</Label>
            {to.map((email, index) => (
              <div key={index} className="flex gap-2">
                <Input
                  id={index === 0 ? "to" : undefined}
                  type="email"
                  placeholder="recipient@example.com"
                  value={email}
                  onChange={(e) =>
                    handleRecipientChange(index, e.target.value, setTo)
                  }
                  disabled={sending}
                />
                {to.length > 1 && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleRemoveRecipient(index, setTo)}
                    disabled={sending}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            ))}
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleAddRecipient("to", setTo)}
              disabled={sending}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Recipient
            </Button>
          </div>

          {/* CC/BCC Toggle */}
          <div className="flex gap-2">
            {!showCc && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowCc(true)}
                disabled={sending}
              >
                Add CC
              </Button>
            )}
            {!showBcc && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowBcc(true)}
                disabled={sending}
              >
                Add BCC
              </Button>
            )}
          </div>

          {/* CC Field */}
          {showCc && (
            <div className="space-y-2">
              <Label htmlFor="cc">CC</Label>
              {cc.length === 0 ? (
                <div className="flex gap-2">
                  <Input
                    id="cc"
                    type="email"
                    placeholder="cc@example.com"
                    value=""
                    onChange={(e) => setCc([e.target.value])}
                    disabled={sending}
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setShowCc(false)}
                    disabled={sending}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <>
                  {cc.map((email, index) => (
                    <div key={index} className="flex gap-2">
                      <Input
                        type="email"
                        placeholder="cc@example.com"
                        value={email}
                        onChange={(e) =>
                          handleRecipientChange(index, e.target.value, setCc)
                        }
                        disabled={sending}
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleRemoveRecipient(index, setCc)}
                        disabled={sending}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleAddRecipient("cc", setCc)}
                    disabled={sending}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add CC
                  </Button>
                </>
              )}
            </div>
          )}

          {/* BCC Field */}
          {showBcc && (
            <div className="space-y-2">
              <Label htmlFor="bcc">BCC</Label>
              {bcc.length === 0 ? (
                <div className="flex gap-2">
                  <Input
                    id="bcc"
                    type="email"
                    placeholder="bcc@example.com"
                    value=""
                    onChange={(e) => setBcc([e.target.value])}
                    disabled={sending}
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setShowBcc(false)}
                    disabled={sending}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <>
                  {bcc.map((email, index) => (
                    <div key={index} className="flex gap-2">
                      <Input
                        type="email"
                        placeholder="bcc@example.com"
                        value={email}
                        onChange={(e) =>
                          handleRecipientChange(index, e.target.value, setBcc)
                        }
                        disabled={sending}
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleRemoveRecipient(index, setBcc)}
                        disabled={sending}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleAddRecipient("bcc", setBcc)}
                    disabled={sending}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add BCC
                  </Button>
                </>
              )}
            </div>
          )}

          {/* Subject Field */}
          <div className="space-y-2">
            <Label htmlFor="subject">Subject *</Label>
            <Input
              id="subject"
              placeholder="Email subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              disabled={sending}
            />
          </div>

          {/* Body Field */}
          <div className="space-y-2">
            <Label htmlFor="body">Message *</Label>
            <Textarea
              id="body"
              placeholder="Write your message here..."
              value={body}
              onChange={(e) => setBody(e.target.value)}
              disabled={sending}
              rows={10}
              className="resize-none"
            />
            <p className="text-xs text-muted-foreground">
              {body.length} characters
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={handleClose}
            disabled={sending}
          >
            Cancel
          </Button>
          <Button onClick={handleSend} disabled={sending}>
            {sending ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Sending...
              </>
            ) : (
              <>
                <Mail className="h-4 w-4 mr-2" />
                Send Email
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
