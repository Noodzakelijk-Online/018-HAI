/**
 * DateRangePicker Component
 * 
 * Provides date selection with quick filter presets for timeline filtering.
 */

import React, { useState } from 'react';
import { format, subDays, startOfDay, endOfDay, isToday, isYesterday } from 'date-fns';
import { Calendar as CalendarIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Badge } from '@/components/ui/badge';

interface DateRangePickerProps {
  selectedDate: Date;
  onDateChange: (date: Date) => void;
}

const quickFilters = [
  { label: 'Today', days: 0 },
  { label: 'Yesterday', days: 1 },
  { label: 'Last 7 days', days: 7 },
];

export function DateRangePicker({ selectedDate, onDateChange }: DateRangePickerProps) {
  const [isOpen, setIsOpen] = useState(false);

  const handleQuickFilter = (days: number) => {
    const date = days === 0 ? new Date() : subDays(new Date(), days);
    onDateChange(startOfDay(date));
    setIsOpen(false);
  };

  const handleDateSelect = (date: Date | undefined) => {
    if (date) {
      onDateChange(startOfDay(date));
      setIsOpen(false);
    }
  };

  const getDateLabel = () => {
    if (isToday(selectedDate)) return 'Today';
    if (isYesterday(selectedDate)) return 'Yesterday';
    return format(selectedDate, 'MMM d, yyyy');
  };

  return (
    <div className="flex items-center gap-2 flex-wrap">
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            className="justify-start text-left font-normal"
          >
            <CalendarIcon className="mr-2 h-4 w-4" />
            {getDateLabel()}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <div className="p-3 border-b">
            <p className="text-sm font-medium mb-2">Quick Filters</p>
            <div className="flex flex-wrap gap-2">
              {quickFilters.map((filter) => (
                <Button
                  key={filter.label}
                  variant="outline"
                  size="sm"
                  onClick={() => handleQuickFilter(filter.days)}
                  className="text-xs"
                >
                  {filter.label}
                </Button>
              ))}
            </div>
          </div>
          <Calendar
            mode="single"
            selected={selectedDate}
            onSelect={handleDateSelect}
            initialFocus
            disabled={(date) => date > new Date()}
          />
        </PopoverContent>
      </Popover>

      {!isToday(selectedDate) && (
        <Badge variant="secondary" className="ml-2">
          Viewing past activities
        </Badge>
      )}
    </div>
  );
}
