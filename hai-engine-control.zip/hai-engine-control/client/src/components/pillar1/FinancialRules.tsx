/**
 * Financial Rules Component
 * 
 * Manages financial rules, recurring bills, and anomaly detection.
 * Part of Pillar 1: Decision Authority
 */

import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  DollarSign,
  Plus,
  AlertTriangle,
  CheckCircle2,
  Clock,
  TrendingUp,
  Building2,
  CreditCard,
  Calendar,
  Shield,
  Trash2,
  Edit,
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface FinancialRulesProps {
  householdId: number;
  className?: string;
}

type RuleType = 'auto_approve_threshold' | 'vendor_trust' | 'category_limit' | 'recurring_bill' | 'anomaly_threshold' | 'time_based';

const ruleTypeLabels: Record<RuleType, string> = {
  auto_approve_threshold: 'Auto-Approve Threshold',
  vendor_trust: 'Vendor Trust',
  category_limit: 'Category Limit',
  recurring_bill: 'Recurring Bill',
  anomaly_threshold: 'Anomaly Threshold',
  time_based: 'Time-Based',
};

export function FinancialRules({ householdId, className }: FinancialRulesProps) {
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [newRule, setNewRule] = useState({
    ruleName: '',
    ruleType: 'auto_approve_threshold' as RuleType,
    vendorName: '',
    category: '',
    maxAmount: '',
    requiresApproval: false,
    notifyOnExecution: true,
    priority: 50,
  });

  // Fetch data
  const { data: rules, isLoading: rulesLoading, refetch: refetchRules } = trpc.pillar1.financial.rules.useQuery(
    { householdId },
    { refetchInterval: 30000 }
  );

  const { data: upcomingBills, isLoading: billsLoading } = trpc.pillar1.financial.upcomingBills.useQuery(
    { householdId, daysAhead: 14 },
    { refetchInterval: 60000 }
  );

  const { data: statistics } = trpc.pillar1.financial.statistics.useQuery(
    { householdId },
    { refetchInterval: 30000 }
  );

  // Mutations
  const createRuleMutation = trpc.pillar1.financial.createRule.useMutation({
    onSuccess: () => {
      toast.success('Financial rule created');
      refetchRules();
      setCreateDialogOpen(false);
      resetNewRule();
    },
    onError: (error) => {
      toast.error(`Failed to create rule: ${error.message}`);
    },
  });

  const deleteRuleMutation = trpc.pillar1.financial.deleteRule.useMutation({
    onSuccess: () => {
      toast.success('Rule deleted');
      refetchRules();
    },
    onError: (error) => {
      toast.error(`Failed to delete rule: ${error.message}`);
    },
  });

  const resetNewRule = () => {
    setNewRule({
      ruleName: '',
      ruleType: 'auto_approve_threshold',
      vendorName: '',
      category: '',
      maxAmount: '',
      requiresApproval: false,
      notifyOnExecution: true,
      priority: 50,
    });
  };

  const handleCreateRule = () => {
    createRuleMutation.mutate({
      householdId,
      ruleName: newRule.ruleName,
      ruleType: newRule.ruleType,
      vendorName: newRule.vendorName || undefined,
      category: newRule.category || undefined,
      maxAmount: newRule.maxAmount ? parseFloat(newRule.maxAmount) : undefined,
      requiresApproval: newRule.requiresApproval,
      notifyOnExecution: newRule.notifyOnExecution,
      priority: newRule.priority,
    });
  };

  return (
    <div className={cn("space-y-6", className)}>
      {/* Statistics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4 text-blue-500" />
              <span className="text-sm text-muted-foreground">Active Rules</span>
            </div>
            <p className="text-2xl font-bold mt-2">{statistics?.activeRules ?? 0}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-purple-500" />
              <span className="text-sm text-muted-foreground">Recurring Bills</span>
            </div>
            <p className="text-2xl font-bold mt-2">{statistics?.recurringBills ?? 0}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-yellow-500" />
              <span className="text-sm text-muted-foreground">Upcoming Bills</span>
            </div>
            <p className="text-2xl font-bold mt-2">{statistics?.upcomingBills ?? 0}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-red-500" />
              <span className="text-sm text-muted-foreground">Anomalies</span>
            </div>
            <p className="text-2xl font-bold mt-2">{statistics?.detectedAnomalies ?? 0}</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="rules" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="rules">Financial Rules</TabsTrigger>
          <TabsTrigger value="bills">Upcoming Bills</TabsTrigger>
          <TabsTrigger value="anomalies">Anomalies</TabsTrigger>
        </TabsList>

        {/* Rules Tab */}
        <TabsContent value="rules">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Financial Rules
                </CardTitle>
                <CardDescription>
                  Define auto-approval thresholds and vendor trust levels
                </CardDescription>
              </div>
              <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Rule
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Create Financial Rule</DialogTitle>
                    <DialogDescription>
                      Define a new rule for autonomous financial decisions
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label>Rule Name</Label>
                      <Input
                        placeholder="e.g., Auto-approve Netflix"
                        value={newRule.ruleName}
                        onChange={(e) => setNewRule({ ...newRule, ruleName: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Rule Type</Label>
                      <Select
                        value={newRule.ruleType}
                        onValueChange={(value: RuleType) => setNewRule({ ...newRule, ruleType: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.entries(ruleTypeLabels).map(([value, label]) => (
                            <SelectItem key={value} value={value}>
                              {label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Vendor Name (optional)</Label>
                      <Input
                        placeholder="e.g., Netflix, Amazon"
                        value={newRule.vendorName}
                        onChange={(e) => setNewRule({ ...newRule, vendorName: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Category (optional)</Label>
                      <Input
                        placeholder="e.g., Entertainment, Utilities"
                        value={newRule.category}
                        onChange={(e) => setNewRule({ ...newRule, category: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Max Amount ($)</Label>
                      <Input
                        type="number"
                        placeholder="e.g., 100"
                        value={newRule.maxAmount}
                        onChange={(e) => setNewRule({ ...newRule, maxAmount: e.target.value })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>Requires Approval</Label>
                      <Switch
                        checked={newRule.requiresApproval}
                        onCheckedChange={(checked) => setNewRule({ ...newRule, requiresApproval: checked })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>Notify on Execution</Label>
                      <Switch
                        checked={newRule.notifyOnExecution}
                        onCheckedChange={(checked) => setNewRule({ ...newRule, notifyOnExecution: checked })}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button
                      onClick={handleCreateRule}
                      disabled={!newRule.ruleName || createRuleMutation.isPending}
                    >
                      {createRuleMutation.isPending ? 'Creating...' : 'Create Rule'}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[300px]">
                {rulesLoading ? (
                  <div className="flex items-center justify-center h-48">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
                  </div>
                ) : !rules || rules.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
                    <Shield className="h-12 w-12 mb-4 opacity-20" />
                    <p>No financial rules defined</p>
                    <p className="text-sm">Create rules to automate financial decisions</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {rules.map((rule: any) => (
                      <div
                        key={rule.id}
                        className="p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-medium">{rule.ruleName}</span>
                              <Badge variant={rule.isActive ? 'default' : 'secondary'}>
                                {rule.isActive ? 'Active' : 'Inactive'}
                              </Badge>
                              <Badge variant="outline">
                                {ruleTypeLabels[rule.ruleType as RuleType]}
                              </Badge>
                            </div>
                            <div className="text-sm text-muted-foreground space-x-2">
                              {rule.vendorName && <span>Vendor: {rule.vendorName}</span>}
                              {rule.category && <span>• Category: {rule.category}</span>}
                              {rule.maxAmount && <span>• Max: ${rule.maxAmount}</span>}
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => deleteRuleMutation.mutate({ ruleId: rule.id })}
                            >
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Bills Tab */}
        <TabsContent value="bills">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Upcoming Bills
              </CardTitle>
              <CardDescription>
                Bills due in the next 14 days
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[300px]">
                {billsLoading ? (
                  <div className="flex items-center justify-center h-48">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
                  </div>
                ) : !upcomingBills || upcomingBills.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
                    <Calendar className="h-12 w-12 mb-4 opacity-20" />
                    <p>No upcoming bills</p>
                    <p className="text-sm">HAI will detect recurring bills automatically</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {upcomingBills.map((bill: any) => (
                      <div
                        key={bill.id}
                        className="p-4 rounded-lg border bg-card"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="p-2 rounded-lg bg-green-500/10">
                              <Building2 className="h-4 w-4 text-green-500" />
                            </div>
                            <div>
                              <p className="font-medium">{bill.vendorName}</p>
                              <p className="text-sm text-muted-foreground">
                                {bill.category} • {bill.frequency}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-lg">${bill.expectedAmount}</p>
                            <p className="text-sm text-muted-foreground">
                              Due: {bill.nextExpectedDate ? new Date(bill.nextExpectedDate).toLocaleDateString() : 'Unknown'}
                            </p>
                          </div>
                        </div>
                        {bill.autoPayEnabled && (
                          <Badge className="mt-2" variant="outline">
                            <CheckCircle2 className="h-3 w-3 mr-1" />
                            Auto-pay enabled
                          </Badge>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Anomalies Tab */}
        <TabsContent value="anomalies">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-yellow-500" />
                Detected Anomalies
              </CardTitle>
              <CardDescription>
                Unusual transactions that need your attention
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
                <CheckCircle2 className="h-12 w-12 mb-4 text-green-500 opacity-50" />
                <p>No anomalies detected</p>
                <p className="text-sm">HAI is monitoring your transactions</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
