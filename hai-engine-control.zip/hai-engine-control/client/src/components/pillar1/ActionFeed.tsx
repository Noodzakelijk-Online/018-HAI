/**
 * Action Feed Component
 * 
 * Displays real-time autonomous actions with override capabilities.
 * Part of Pillar 1: Decision Authority
 */

import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  XCircle, 
  Play, 
  Pause,
  RotateCcw,
  ChevronRight,
  Zap,
  Mail,
  Calendar,
  DollarSign,
  Shield,
  Home,
  Heart,
  Users,
  Wrench
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';

interface ActionFeedProps {
  householdId: number;
  className?: string;
}

type ActionStatus = 'pending' | 'executing' | 'completed' | 'failed' | 'cancelled' | 'overridden' | 'rolled_back';
type ActionCategory = 'communication' | 'financial' | 'scheduling' | 'household' | 'health' | 'security' | 'maintenance' | 'social';

interface Action {
  id: number;
  actionType: string;
  actionCategory: string;
  targetService: string;
  actionDescription: string;
  confidenceScore: number;
  priorityScore: number;
  status: ActionStatus;
  scheduledAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

const statusConfig: Record<ActionStatus, { icon: typeof CheckCircle2; color: string; label: string }> = {
  pending: { icon: Clock, color: 'text-yellow-500', label: 'Pending' },
  executing: { icon: Play, color: 'text-blue-500', label: 'Executing' },
  completed: { icon: CheckCircle2, color: 'text-green-500', label: 'Completed' },
  failed: { icon: XCircle, color: 'text-red-500', label: 'Failed' },
  cancelled: { icon: XCircle, color: 'text-gray-500', label: 'Cancelled' },
  overridden: { icon: AlertCircle, color: 'text-orange-500', label: 'Overridden' },
  rolled_back: { icon: RotateCcw, color: 'text-purple-500', label: 'Rolled Back' },
};

const categoryConfig: Record<ActionCategory, { icon: typeof Mail; color: string }> = {
  communication: { icon: Mail, color: 'bg-blue-500/10 text-blue-500' },
  financial: { icon: DollarSign, color: 'bg-green-500/10 text-green-500' },
  scheduling: { icon: Calendar, color: 'bg-purple-500/10 text-purple-500' },
  household: { icon: Home, color: 'bg-orange-500/10 text-orange-500' },
  health: { icon: Heart, color: 'bg-red-500/10 text-red-500' },
  security: { icon: Shield, color: 'bg-yellow-500/10 text-yellow-500' },
  maintenance: { icon: Wrench, color: 'bg-gray-500/10 text-gray-500' },
  social: { icon: Users, color: 'bg-pink-500/10 text-pink-500' },
};

export function ActionFeed({ householdId, className }: ActionFeedProps) {
  const [selectedAction, setSelectedAction] = useState<Action | null>(null);
  const [overrideDialogOpen, setOverrideDialogOpen] = useState(false);
  const [overrideReason, setOverrideReason] = useState('');

  // Fetch action feed with real-time updates
  const { data: actions, isLoading, refetch } = trpc.pillar1.action.feed.useQuery(
    { householdId, limit: 20 },
    { refetchInterval: 5000 }
  );

  // Mutations
  const cancelMutation = trpc.pillar1.action.cancel.useMutation({
    onSuccess: () => {
      toast.success('Action cancelled successfully');
      refetch();
      setOverrideDialogOpen(false);
    },
    onError: (error) => {
      toast.error(`Failed to cancel: ${error.message}`);
    },
  });

  const executeMutation = trpc.pillar1.action.execute.useMutation({
    onSuccess: () => {
      toast.success('Action executed successfully');
      refetch();
    },
    onError: (error) => {
      toast.error(`Failed to execute: ${error.message}`);
    },
  });

  const rollbackMutation = trpc.pillar1.action.rollback.useMutation({
    onSuccess: () => {
      toast.success('Action rolled back successfully');
      refetch();
      setOverrideDialogOpen(false);
    },
    onError: (error) => {
      toast.error(`Failed to rollback: ${error.message}`);
    },
  });

  const handleCancel = (action: Action) => {
    setSelectedAction(action);
    setOverrideDialogOpen(true);
  };

  const handleConfirmCancel = () => {
    if (!selectedAction) return;
    
    if (selectedAction.status === 'completed') {
      rollbackMutation.mutate({ actionId: selectedAction.id, reason: overrideReason });
    } else {
      cancelMutation.mutate({ actionId: selectedAction.id, reason: overrideReason });
    }
  };

  const handleExecute = (actionId: number) => {
    executeMutation.mutate({ actionId });
  };

  const getConfidenceColor = (score: number) => {
    if (score >= 0.8) return 'text-green-500';
    if (score >= 0.6) return 'text-yellow-500';
    return 'text-red-500';
  };

  if (isLoading) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Action Feed
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-48">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className={className}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-yellow-500" />
            Action Feed
          </CardTitle>
          <CardDescription>
            Real-time autonomous actions - click to override
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[400px] pr-4">
            {!actions || actions.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
                <Zap className="h-12 w-12 mb-4 opacity-20" />
                <p>No actions yet</p>
                <p className="text-sm">HAI will show actions here as they occur</p>
              </div>
            ) : (
              <div className="space-y-3">
                {actions.map((action: Action) => {
                  const status = statusConfig[action.status as ActionStatus] || statusConfig.pending;
                  const category = categoryConfig[action.actionCategory as ActionCategory] || categoryConfig.household;
                  const StatusIcon = status.icon;
                  const CategoryIcon = category.icon;

                  return (
                    <div
                      key={action.id}
                      className={cn(
                        "p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors cursor-pointer",
                        action.status === 'pending' && "border-yellow-500/50",
                        action.status === 'executing' && "border-blue-500/50 animate-pulse"
                      )}
                      onClick={() => setSelectedAction(action)}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-start gap-3 flex-1 min-w-0">
                          <div className={cn("p-2 rounded-lg", category.color)}>
                            <CategoryIcon className="h-4 w-4" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-medium truncate">
                                {action.actionDescription}
                              </span>
                            </div>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <StatusIcon className={cn("h-3 w-3", status.color)} />
                              <span>{status.label}</span>
                              <span>•</span>
                              <span className={getConfidenceColor(action.confidenceScore)}>
                                {Math.round(action.confidenceScore * 100)}% confidence
                              </span>
                              <span>•</span>
                              <span>
                                {formatDistanceToNow(new Date(action.createdAt), { addSuffix: true })}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {action.status === 'pending' && (
                            <>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleExecute(action.id);
                                }}
                              >
                                <Play className="h-3 w-3 mr-1" />
                                Execute
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleCancel(action);
                                }}
                              >
                                <XCircle className="h-3 w-3 mr-1" />
                                Cancel
                              </Button>
                            </>
                          )}
                          {action.status === 'completed' && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleCancel(action);
                              }}
                            >
                              <RotateCcw className="h-3 w-3 mr-1" />
                              Rollback
                            </Button>
                          )}
                          <ChevronRight className="h-4 w-4 text-muted-foreground" />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Override Dialog */}
      <Dialog open={overrideDialogOpen} onOpenChange={setOverrideDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {selectedAction?.status === 'completed' ? 'Rollback Action' : 'Cancel Action'}
            </DialogTitle>
            <DialogDescription>
              {selectedAction?.status === 'completed'
                ? 'This will attempt to undo the completed action. HAI will learn from this override.'
                : 'This will prevent the action from executing. HAI will learn from this override.'}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <p className="text-sm font-medium mb-2">Action:</p>
            <p className="text-sm text-muted-foreground mb-4">
              {selectedAction?.actionDescription}
            </p>
            <Textarea
              placeholder="Reason for override (optional - helps HAI learn)"
              value={overrideReason}
              onChange={(e) => setOverrideReason(e.target.value)}
              rows={3}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOverrideDialogOpen(false)}>
              Keep Action
            </Button>
            <Button
              variant="destructive"
              onClick={handleConfirmCancel}
              disabled={cancelMutation.isPending || rollbackMutation.isPending}
            >
              {cancelMutation.isPending || rollbackMutation.isPending ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
              ) : null}
              {selectedAction?.status === 'completed' ? 'Rollback' : 'Cancel'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
