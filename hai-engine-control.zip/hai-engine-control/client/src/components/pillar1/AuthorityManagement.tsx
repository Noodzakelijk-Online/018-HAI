/**
 * Authority Management Component
 * 
 * Manages authority levels, escalations, and delegations.
 * Part of Pillar 1: Decision Authority
 */

import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import {
  Shield,
  Users,
  ArrowUpCircle,
  Clock,
  CheckCircle2,
  XCircle,
  Crown,
  User,
  UserCheck,
  UserCog,
  UserX,
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface AuthorityManagementProps {
  householdId: number;
  currentMemberId: number;
  className?: string;
}

const levelIcons: Record<string, typeof Crown> = {
  'Guest': UserX,
  'Member': User,
  'Trusted Member': UserCheck,
  'Manager': UserCog,
  'Owner': Crown,
};

const levelColors: Record<string, string> = {
  'Guest': 'bg-gray-500/10 text-gray-500',
  'Member': 'bg-blue-500/10 text-blue-500',
  'Trusted Member': 'bg-green-500/10 text-green-500',
  'Manager': 'bg-purple-500/10 text-purple-500',
  'Owner': 'bg-yellow-500/10 text-yellow-500',
};

export function AuthorityManagement({ householdId, currentMemberId, className }: AuthorityManagementProps) {
  const [selectedEscalation, setSelectedEscalation] = useState<any>(null);
  const [escalationDialogOpen, setEscalationDialogOpen] = useState(false);
  const [resolutionNotes, setResolutionNotes] = useState('');

  // Fetch data
  const { data: levels } = trpc.pillar1.authority.levels.useQuery();
  
  const { data: pendingEscalations, refetch: refetchEscalations } = trpc.pillar1.authority.pendingEscalations.useQuery(
    { householdId },
    { refetchInterval: 10000 }
  );

  const { data: requirements } = trpc.pillar1.authority.requirements.useQuery();

  const { data: statistics } = trpc.pillar1.authority.statistics.useQuery(
    { householdId },
    { refetchInterval: 30000 }
  );

  // Mutations
  const resolveEscalationMutation = trpc.pillar1.authority.resolveEscalation.useMutation({
    onSuccess: () => {
      toast.success('Escalation resolved');
      refetchEscalations();
      setEscalationDialogOpen(false);
      setResolutionNotes('');
    },
    onError: (error) => {
      toast.error(`Failed to resolve: ${error.message}`);
    },
  });

  const handleResolveEscalation = (approved: boolean) => {
    if (!selectedEscalation) return;
    
    resolveEscalationMutation.mutate({
      escalationId: selectedEscalation.id,
      approved,
      resolvedByMemberId: currentMemberId,
      notes: resolutionNotes || undefined,
    });
  };

  return (
    <div className={cn("space-y-6", className)}>
      {/* Statistics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-blue-500" />
              <span className="text-sm text-muted-foreground">Total Members</span>
            </div>
            <p className="text-2xl font-bold mt-2">{statistics?.totalMembers ?? 0}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <ArrowUpCircle className="h-4 w-4 text-yellow-500" />
              <span className="text-sm text-muted-foreground">Pending Escalations</span>
            </div>
            <p className="text-2xl font-bold mt-2">{statistics?.pendingEscalations ?? 0}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-purple-500" />
              <span className="text-sm text-muted-foreground">Active Delegations</span>
            </div>
            <p className="text-2xl font-bold mt-2">{statistics?.activeDelegations ?? 0}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4 text-green-500" />
              <span className="text-sm text-muted-foreground">Authority Levels</span>
            </div>
            <p className="text-2xl font-bold mt-2">{levels?.length ?? 0}</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="levels" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="levels">Authority Levels</TabsTrigger>
          <TabsTrigger value="escalations">
            Escalations
            {(pendingEscalations?.length ?? 0) > 0 && (
              <Badge variant="destructive" className="ml-2">
                {pendingEscalations?.length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="requirements">Requirements</TabsTrigger>
        </TabsList>

        {/* Authority Levels Tab */}
        <TabsContent value="levels">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Authority Levels
              </CardTitle>
              <CardDescription>
                Hierarchy of permissions and capabilities
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {levels?.map((level: any) => {
                  const Icon = levelIcons[level.levelName] || User;
                  const colorClass = levelColors[level.levelName] || 'bg-gray-500/10 text-gray-500';
                  
                  return (
                    <div
                      key={level.id}
                      className="p-4 rounded-lg border bg-card"
                    >
                      <div className="flex items-start gap-4">
                        <div className={cn("p-3 rounded-lg", colorClass)}>
                          <Icon className="h-6 w-6" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-semibold text-lg">{level.levelName}</span>
                            <Badge variant="outline">Level {level.levelNumber}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-3">
                            {level.levelDescription}
                          </p>
                          <div className="flex flex-wrap gap-2">
                            {level.maxFinancialAmount !== null && (
                              <Badge variant="secondary">
                                Max: ${level.maxFinancialAmount}
                              </Badge>
                            )}
                            {level.maxFinancialAmount === null && (
                              <Badge variant="secondary">Unlimited Financial</Badge>
                            )}
                            {level.canAccessSensitiveData && (
                              <Badge variant="secondary">Sensitive Data</Badge>
                            )}
                            {level.canModifySettings && (
                              <Badge variant="secondary">Modify Settings</Badge>
                            )}
                            {level.canInviteMembers && (
                              <Badge variant="secondary">Invite Members</Badge>
                            )}
                            {level.canRemoveMembers && (
                              <Badge variant="secondary">Remove Members</Badge>
                            )}
                          </div>
                        </div>
                        {statistics?.byLevel?.[level.levelName] && (
                          <div className="text-right">
                            <p className="text-2xl font-bold">{statistics.byLevel[level.levelName]}</p>
                            <p className="text-sm text-muted-foreground">members</p>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Escalations Tab */}
        <TabsContent value="escalations">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ArrowUpCircle className="h-5 w-5 text-yellow-500" />
                Pending Escalations
              </CardTitle>
              <CardDescription>
                Actions requiring higher authority approval
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                {!pendingEscalations || pendingEscalations.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
                    <CheckCircle2 className="h-12 w-12 mb-4 text-green-500 opacity-50" />
                    <p>No pending escalations</p>
                    <p className="text-sm">All actions are within authority limits</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {pendingEscalations.map((escalation: any) => (
                      <div
                        key={escalation.id}
                        className="p-4 rounded-lg border bg-card border-yellow-500/50"
                      >
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <Badge variant="outline" className="text-yellow-500 border-yellow-500">
                                Level {escalation.fromAuthorityLevel} → {escalation.toAuthorityLevel}
                              </Badge>
                              <span className="text-sm text-muted-foreground">
                                {formatDistanceToNow(new Date(escalation.createdAt), { addSuffix: true })}
                              </span>
                            </div>
                            <p className="font-medium mb-1">{escalation.escalationReason}</p>
                            {escalation.expiresAt && (
                              <p className="text-sm text-muted-foreground">
                                Expires: {formatDistanceToNow(new Date(escalation.expiresAt), { addSuffix: true })}
                              </p>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-green-500 border-green-500 hover:bg-green-500/10"
                              onClick={() => {
                                setSelectedEscalation(escalation);
                                setEscalationDialogOpen(true);
                              }}
                            >
                              <CheckCircle2 className="h-4 w-4 mr-1" />
                              Approve
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-red-500 border-red-500 hover:bg-red-500/10"
                              onClick={() => {
                                setSelectedEscalation(escalation);
                                setEscalationDialogOpen(true);
                              }}
                            >
                              <XCircle className="h-4 w-4 mr-1" />
                              Deny
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Requirements Tab */}
        <TabsContent value="requirements">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Action Requirements
              </CardTitle>
              <CardDescription>
                Authority levels required for different action types
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px]">
                <div className="space-y-2">
                  {requirements?.map((req: any) => (
                    <div
                      key={req.id}
                      className="p-3 rounded-lg border bg-card flex items-center justify-between"
                    >
                      <div>
                        <span className="font-medium">{req.actionType}</span>
                        {req.actionCategory && (
                          <span className="text-sm text-muted-foreground ml-2">
                            ({req.actionCategory})
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge>Level {req.requiredAuthorityLevel}</Badge>
                        {req.emergencyOverride && (
                          <Badge variant="outline" className="text-yellow-500">
                            Emergency Override
                          </Badge>
                        )}
                        {req.businessHoursOnly && (
                          <Badge variant="outline">Business Hours Only</Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Escalation Resolution Dialog */}
      <Dialog open={escalationDialogOpen} onOpenChange={setEscalationDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Resolve Escalation</DialogTitle>
            <DialogDescription>
              Review and approve or deny this escalation request
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            {selectedEscalation && (
              <>
                <p className="text-sm font-medium mb-2">Reason:</p>
                <p className="text-sm text-muted-foreground mb-4">
                  {selectedEscalation.escalationReason}
                </p>
                <p className="text-sm font-medium mb-2">Authority Change:</p>
                <p className="text-sm text-muted-foreground mb-4">
                  Level {selectedEscalation.fromAuthorityLevel} → Level {selectedEscalation.toAuthorityLevel}
                </p>
              </>
            )}
            <Textarea
              placeholder="Resolution notes (optional)"
              value={resolutionNotes}
              onChange={(e) => setResolutionNotes(e.target.value)}
              rows={3}
            />
          </div>
          <DialogFooter className="flex gap-2">
            <Button variant="outline" onClick={() => setEscalationDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => handleResolveEscalation(false)}
              disabled={resolveEscalationMutation.isPending}
            >
              <XCircle className="h-4 w-4 mr-1" />
              Deny
            </Button>
            <Button
              onClick={() => handleResolveEscalation(true)}
              disabled={resolveEscalationMutation.isPending}
            >
              <CheckCircle2 className="h-4 w-4 mr-1" />
              Approve
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
