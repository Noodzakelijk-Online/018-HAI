import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Activity, Clock, TrendingUp } from "lucide-react";
import { trpc } from "@/lib/trpc";

interface HealthStatusBadgeProps {
  serviceId: number;
  hasUrl: boolean;
}

export function HealthStatusBadge({ serviceId, hasUrl }: HealthStatusBadgeProps) {
  const { data: healthStats, isLoading } = trpc.connectors.getHealthStats.useQuery(
    { connectorId: serviceId },
    {
      enabled: hasUrl, // Only fetch if service has a URL
      refetchInterval: 5 * 60 * 1000, // Refetch every 5 minutes
    }
  );

  if (!hasUrl) {
    return (
      <Badge variant="secondary" className="gap-1">
        <Activity className="h-3 w-3" />
        No URL
      </Badge>
    );
  }

  if (isLoading || !healthStats) {
    return (
      <Badge variant="secondary" className="gap-1">
        <Activity className="h-3 w-3" />
        Checking...
      </Badge>
    );
  }

  const getStatusColor = () => {
    if (healthStats.totalChecks === 0) {
      return "secondary";
    }

    if (healthStats.uptime >= 99) {
      return "default"; // Green
    } else if (healthStats.uptime >= 95) {
      return "outline"; // Yellow
    } else {
      return "destructive"; // Red
    }
  };

  const getStatusIcon = () => {
    if (healthStats.totalChecks === 0) {
      return <Clock className="h-3 w-3" />;
    }

    if (healthStats.lastCheckStatus === "success") {
      return <Activity className="h-3 w-3 text-green-600" />;
    } else if (healthStats.lastCheckStatus === "timeout") {
      return <Clock className="h-3 w-3 text-yellow-600" />;
    } else {
      return <Activity className="h-3 w-3 text-red-600" />;
    }
  };

  const formatLastCheck = () => {
    if (!healthStats.lastCheckTime) return "Never";
    
    const lastCheck = new Date(healthStats.lastCheckTime);
    const now = new Date();
    const diffMs = now.getTime() - lastCheck.getTime();
    const diffMins = Math.floor(diffMs / 60000);

    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins}m ago`;
    
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays}d ago`;
  };

  if (healthStats.totalChecks === 0) {
    return (
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge variant="secondary" className="gap-1 cursor-help">
            <Clock className="h-3 w-3" />
            Pending
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          <p>No health checks yet</p>
          <p className="text-xs text-muted-foreground mt-1">
            First check will run within 5 minutes
          </p>
        </TooltipContent>
      </Tooltip>
    );
  }

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Badge variant={getStatusColor()} className="gap-1 cursor-help">
          {getStatusIcon()}
          {healthStats.uptime.toFixed(1)}%
        </Badge>
      </TooltipTrigger>
      <TooltipContent className="max-w-xs">
        <div className="space-y-2">
          <div className="flex items-center justify-between gap-4">
            <span className="text-sm font-semibold">Uptime</span>
            <span className="text-sm">{healthStats.uptime.toFixed(1)}%</span>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="text-sm font-semibold">Avg Response</span>
            <span className="text-sm">{healthStats.avgResponseTime}ms</span>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="text-sm font-semibold">Last Check</span>
            <span className="text-sm">{formatLastCheck()}</span>
          </div>
          <div className="flex items-center justify-between gap-4">
            <span className="text-sm font-semibold">Status</span>
            <span className="text-sm capitalize">{healthStats.lastCheckStatus || "Unknown"}</span>
          </div>
          <div className="pt-2 border-t text-xs text-muted-foreground">
            {healthStats.successfulChecks} / {healthStats.totalChecks} checks successful
          </div>
        </div>
      </TooltipContent>
    </Tooltip>
  );
}
