import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export function RealTimeActivityFeed() {
  const [activities, setActivities] = useState<any[]>([]);

  useEffect(() => {
    // TODO: Connect to WebSocket for real-time updates
    // const ws = new WebSocket('ws://localhost:3000/activities');
    // ws.onmessage = (event) => {
    //   const newActivity = JSON.parse(event.data);
    //   setActivities(prev => [newActivity, ...prev].slice(0, 10));
    // };
  }, []);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
          </span>
          Live Activity Feed
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {activities.length === 0 && (
            <p className="text-sm text-muted-foreground">No recent activities</p>
          )}
          {activities.map((activity, i) => (
            <div key={i} className="flex items-center justify-between p-2 rounded-md bg-muted">
              <span className="text-sm">{activity.title}</span>
              <Badge>{activity.engine}</Badge>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
