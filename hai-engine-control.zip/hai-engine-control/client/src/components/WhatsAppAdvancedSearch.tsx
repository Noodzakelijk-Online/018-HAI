/**
 * WhatsApp Advanced Search Component
 * 
 * Full-text search with filters for contact, date range, sentiment
 */

import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Search, Filter, Loader2 } from 'lucide-react';
import { Link } from 'wouter';

export default function WhatsAppAdvancedSearch() {
  const [query, setQuery] = useState('');
  const [contactId, setContactId] = useState<number | undefined>();
  const [sentiment, setSentiment] = useState<'positive' | 'negative' | 'neutral' | undefined>();
  const [isFromMe, setIsFromMe] = useState<boolean | undefined>();
  
  const { data: searchResults, isLoading, refetch } = trpc.whatsapp.advancedSearch.useQuery({
    query,
    contactId,
    sentiment,
    isFromMe,
    limit: 50
  }, {
    enabled: false // Only search when user clicks button
  });
  
  const { data: contacts } = trpc.whatsapp.getContacts.useQuery();
  
  const handleSearch = () => {
    if (query.trim()) {
      refetch();
    }
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Advanced Search</CardTitle>
        <CardDescription>
          Search across all your WhatsApp messages with filters
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Search Input */}
        <div className="flex gap-2">
          <Input
            placeholder="Search messages..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
          />
          <Button onClick={handleSearch} disabled={isLoading}>
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
          </Button>
        </div>
        
        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Select value={contactId?.toString()} onValueChange={(v) => setContactId(v ? parseInt(v) : undefined)}>
            <SelectTrigger>
              <SelectValue placeholder="All contacts" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All contacts</SelectItem>
              {contacts?.map(contact => (
                <SelectItem key={contact.id} value={contact.id.toString()}>
                  {contact.name || contact.phone}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select value={sentiment} onValueChange={(v) => setSentiment(v as any)}>
            <SelectTrigger>
              <SelectValue placeholder="Any sentiment" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Any sentiment</SelectItem>
              <SelectItem value="positive">Positive</SelectItem>
              <SelectItem value="negative">Negative</SelectItem>
              <SelectItem value="neutral">Neutral</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={isFromMe?.toString()} onValueChange={(v) => setIsFromMe(v === 'true' ? true : v === 'false' ? false : undefined)}>
            <SelectTrigger>
              <SelectValue placeholder="Any sender" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Any sender</SelectItem>
              <SelectItem value="true">From me</SelectItem>
              <SelectItem value="false">From contact</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        {/* Results */}
        {searchResults && (
          <div className="space-y-4 mt-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">
                {searchResults.total} results
              </h3>
              {searchResults.hasMore && (
                <Badge variant="secondary">Showing {searchResults.results.length} of {searchResults.total}</Badge>
              )}
            </div>
            
            <div className="space-y-2">
              {searchResults.results.map((result) => (
                <Link key={result.id} href={`/whatsapp/conversation/${result.contactId}`}>
                  <div className="p-4 border rounded-lg hover:bg-accent cursor-pointer transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="font-medium">{result.contactName || result.contactPhone}</div>
                        <div className="text-sm text-muted-foreground">
                          {new Date(result.timestamp).toLocaleString()}
                        </div>
                        <div 
                          className="mt-2 text-sm"
                          dangerouslySetInnerHTML={{ __html: result.highlightedContent || result.content }}
                        />
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        {result.sentiment && (
                          <Badge variant={
                            result.sentiment === 'positive' ? 'default' :
                            result.sentiment === 'negative' ? 'destructive' : 'secondary'
                          }>
                            {result.sentiment}
                          </Badge>
                        )}
                        {result.isFromMe && (
                          <Badge variant="outline">Me</Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
