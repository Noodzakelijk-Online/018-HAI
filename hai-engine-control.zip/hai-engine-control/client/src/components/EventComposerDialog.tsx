import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Calendar, Plus, X } from "lucide-react";
import { toast } from "sonner";

interface EventComposerDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSend: (event: EventData) => Promise<void>;
  connectorName?: string;
}

export interface EventData {
  title: string;
  start: Date;
  end: Date;
  description?: string;
  location?: string;
  attendees?: string[];
}

export function EventComposerDialog({
  open,
  onOpenChange,
  onSend,
  connectorName = "Calendar",
}: EventComposerDialogProps) {
  const [title, setTitle] = useState("");
  const [startDate, setStartDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endDate, setEndDate] = useState("");
  const [endTime, setEndTime] = useState("");
  const [location, setLocation] = useState("");
  const [description, setDescription] = useState("");
  const [attendees, setAttendees] = useState<string[]>([]);
  const [showAttendees, setShowAttendees] = useState(false);
  const [creating, setCreating] = useState(false);

  const handleAddAttendee = () => {
    setAttendees((prev) => [...prev, ""]);
  };

  const handleRemoveAttendee = (index: number) => {
    setAttendees((prev) => prev.filter((_, i) => i !== index));
  };

  const handleAttendeeChange = (index: number, value: string) => {
    setAttendees((prev) => prev.map((email, i) => (i === index ? value : email)));
  };

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleCreate = async () => {
    // Validate title
    if (!title.trim()) {
      toast.error("Please enter an event title");
      return;
    }

    // Validate start date/time
    if (!startDate || !startTime) {
      toast.error("Please enter start date and time");
      return;
    }

    // Validate end date/time
    if (!endDate || !endTime) {
      toast.error("Please enter end date and time");
      return;
    }

    // Parse dates
    const start = new Date(`${startDate}T${startTime}`);
    const end = new Date(`${endDate}T${endTime}`);

    // Validate date range
    if (end <= start) {
      toast.error("End time must be after start time");
      return;
    }

    // Validate attendees
    const validAttendees = attendees.filter((email) => email.trim() !== "");
    const invalidEmails = validAttendees.filter((email) => !validateEmail(email));
    if (invalidEmails.length > 0) {
      toast.error(`Invalid email address: ${invalidEmails[0]}`);
      return;
    }

    setCreating(true);
    try {
      await onSend({
        title,
        start,
        end,
        description: description.trim() || undefined,
        location: location.trim() || undefined,
        attendees: validAttendees.length > 0 ? validAttendees : undefined,
      });

      // Reset form
      setTitle("");
      setStartDate("");
      setStartTime("");
      setEndDate("");
      setEndTime("");
      setLocation("");
      setDescription("");
      setAttendees([]);
      setShowAttendees(false);
      onOpenChange(false);
    } catch (error: any) {
      // Error is handled by parent component
      console.error("Event creation error:", error);
    } finally {
      setCreating(false);
    }
  };

  const handleClose = () => {
    if (creating) return;

    // Warn if there's unsaved content
    const hasContent = title.trim() || startDate || startTime || description.trim();
    if (hasContent && !confirm("Discard draft event?")) {
      return;
    }

    // Reset form
    setTitle("");
    setStartDate("");
    setStartTime("");
    setEndDate("");
    setEndTime("");
    setLocation("");
    setDescription("");
    setAttendees([]);
    setShowAttendees(false);
    onOpenChange(false);
  };

  // Set default times when dates are selected
  const handleStartDateChange = (date: string) => {
    setStartDate(date);
    if (!startTime) {
      // Default to next hour
      const now = new Date();
      const nextHour = new Date(now.getTime() + 60 * 60 * 1000);
      nextHour.setMinutes(0);
      setStartTime(nextHour.toTimeString().slice(0, 5));
    }
    if (!endDate) {
      setEndDate(date);
    }
    if (!endTime && startTime) {
      // Default to 1 hour after start
      const [hours, minutes] = startTime.split(":");
      const endHour = (parseInt(hours) + 1) % 24;
      setEndTime(`${endHour.toString().padStart(2, "0")}:${minutes}`);
    }
  };

  const handleStartTimeChange = (time: string) => {
    setStartTime(time);
    if (!endTime) {
      // Default to 1 hour after start
      const [hours, minutes] = time.split(":");
      const endHour = (parseInt(hours) + 1) % 24;
      setEndTime(`${endHour.toString().padStart(2, "0")}:${minutes}`);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Create Calendar Event
          </DialogTitle>
          <DialogDescription>
            Create event via {connectorName} connector
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Title Field */}
          <div className="space-y-2">
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              placeholder="Team Meeting"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              disabled={creating}
            />
          </div>

          {/* Start Date/Time */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="start-date">Start Date *</Label>
              <Input
                id="start-date"
                type="date"
                value={startDate}
                onChange={(e) => handleStartDateChange(e.target.value)}
                disabled={creating}
                min={new Date().toISOString().split("T")[0]}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="start-time">Start Time *</Label>
              <Input
                id="start-time"
                type="time"
                value={startTime}
                onChange={(e) => handleStartTimeChange(e.target.value)}
                disabled={creating}
              />
            </div>
          </div>

          {/* End Date/Time */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="end-date">End Date *</Label>
              <Input
                id="end-date"
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                disabled={creating}
                min={startDate || new Date().toISOString().split("T")[0]}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="end-time">End Time *</Label>
              <Input
                id="end-time"
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                disabled={creating}
              />
            </div>
          </div>

          {/* Location Field */}
          <div className="space-y-2">
            <Label htmlFor="location">Location</Label>
            <Input
              id="location"
              placeholder="Conference Room A or https://meet.google.com/..."
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              disabled={creating}
            />
          </div>

          {/* Description Field */}
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Agenda, notes, or additional details..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              disabled={creating}
              rows={4}
              className="resize-none"
            />
          </div>

          {/* Attendees Toggle */}
          {!showAttendees && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowAttendees(true)}
              disabled={creating}
            >
              Add Attendees
            </Button>
          )}

          {/* Attendees Field */}
          {showAttendees && (
            <div className="space-y-2">
              <Label>Attendees</Label>
              {attendees.length === 0 ? (
                <div className="flex gap-2">
                  <Input
                    type="email"
                    placeholder="attendee@example.com"
                    value=""
                    onChange={(e) => setAttendees([e.target.value])}
                    disabled={creating}
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setShowAttendees(false)}
                    disabled={creating}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <>
                  {attendees.map((email, index) => (
                    <div key={index} className="flex gap-2">
                      <Input
                        type="email"
                        placeholder="attendee@example.com"
                        value={email}
                        onChange={(e) => handleAttendeeChange(index, e.target.value)}
                        disabled={creating}
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleRemoveAttendee(index)}
                        disabled={creating}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleAddAttendee}
                    disabled={creating}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Attendee
                  </Button>
                </>
              )}
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose} disabled={creating}>
            Cancel
          </Button>
          <Button onClick={handleCreate} disabled={creating}>
            {creating ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Creating...
              </>
            ) : (
              <>
                <Calendar className="h-4 w-4 mr-2" />
                Create Event
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
