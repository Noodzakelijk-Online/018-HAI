// @ts-nocheck
import React, { useState, useEffect } from 'react';
import { 
  AlertTriangle, 
  XCircle, 
  AlertCircle, 
  Info,
  Search,
  Filter,
  Download,
  Trash2,
  RefreshCw,
  Clock,
  Code,
  MapPin,
  Bug,
  Zap,
  Eye,
  EyeOff
} from 'lucide-react';

const ErrorTracker = () => {
  const [errors, setErrors] = useState([]);
  const [filteredErrors, setFilteredErrors] = useState([]);
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedError, setSelectedError] = useState(null);
  const [isTracking, setIsTracking] = useState(true);

  // Error categories
  const errorTypes = {
    javascript: { label: 'JavaScript', color: 'text-red-400', icon: Code },
    network: { label: 'Network', color: 'text-orange-400', icon: Zap },
    render: { label: 'Render', color: 'text-yellow-400', icon: Eye },
    promise: { label: 'Promise', color: 'text-purple-400', icon: AlertCircle },
    resource: { label: 'Resource', color: 'text-blue-400', icon: MapPin }
  };

  // Initialize error tracking
  useEffect(() => {
    if (isTracking) {
      setupErrorTracking();
    }
    return () => {
      // Cleanup listeners when component unmounts
    };
  }, [isTracking]);

  // Filter errors based on search and filter criteria
  useEffect(() => {
    let filtered = errors;

    if (filter !== 'all') {
      filtered = filtered.filter(error => error.type === filter);
    }

    if (searchTerm) {
      filtered = filtered.filter(error => 
        error.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
        error.stack.toLowerCase().includes(searchTerm.toLowerCase()) ||
        error.source.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredErrors(filtered);
  }, [errors, filter, searchTerm]);

  const setupErrorTracking = () => {
    // JavaScript errors
    const handleError = (event) => {
      const error = {
        id: Date.now() + Math.random(),
        type: 'javascript',
        level: 'error',
        message: event.error?.message || event.message || 'Unknown error',
        stack: event.error?.stack || 'No stack trace available',
        source: event.filename || 'Unknown source',
        line: event.lineno || 0,
        column: event.colno || 0,
        timestamp: new Date(),
        count: 1,
        userAgent: navigator.userAgent,
        url: window.location.href
      };
      addError(error);
    };

    // Unhandled promise rejections
    const handleUnhandledRejection = (event) => {
      const error = {
        id: Date.now() + Math.random(),
        type: 'promise',
        level: 'error',
        message: event.reason?.message || 'Unhandled promise rejection',
        stack: event.reason?.stack || 'No stack trace available',
        source: 'Promise rejection',
        line: 0,
        column: 0,
        timestamp: new Date(),
        count: 1,
        userAgent: navigator.userAgent,
        url: window.location.href
      };
      addError(error);
    };

    // Resource loading errors
    const handleResourceError = (event) => {
      if (event.target !== window) {
        const error = {
          id: Date.now() + Math.random(),
          type: 'resource',
          level: 'error',
          message: `Failed to load resource: ${event.target.src || event.target.href}`,
          stack: 'Resource loading error',
          source: event.target.tagName || 'Unknown element',
          line: 0,
          column: 0,
          timestamp: new Date(),
          count: 1,
          userAgent: navigator.userAgent,
          url: window.location.href
        };
        addError(error);
      }
    };

    // Console error interception
    const originalConsoleError = console.error;
    console.error = (...args) => {
      const error = {
        id: Date.now() + Math.random(),
        type: 'javascript',
        level: 'error',
        message: args.map(arg => typeof arg === 'string' ? arg : JSON.stringify(arg)).join(' '),
        stack: new Error().stack || 'No stack trace available',
        source: 'Console',
        line: 0,
        column: 0,
        timestamp: new Date(),
        count: 1,
        userAgent: navigator.userAgent,
        url: window.location.href
      };
      addError(error);
      originalConsoleError.apply(console, args);
    };

    // Console warn interception
    const originalConsoleWarn = console.warn;
    console.warn = (...args) => {
      const error = {
        id: Date.now() + Math.random(),
        type: 'javascript',
        level: 'warning',
        message: args.map(arg => typeof arg === 'string' ? arg : JSON.stringify(arg)).join(' '),
        stack: new Error().stack || 'No stack trace available',
        source: 'Console',
        line: 0,
        column: 0,
        timestamp: new Date(),
        count: 1,
        userAgent: navigator.userAgent,
        url: window.location.href
      };
      addError(error);
      originalConsoleWarn.apply(console, args);
    };

    // Add event listeners
    window.addEventListener('error', handleError, true);
    window.addEventListener('unhandledrejection', handleUnhandledRejection);
    window.addEventListener('error', handleResourceError, true);

    // Cleanup function
    return () => {
      window.removeEventListener('error', handleError, true);
      window.removeEventListener('unhandledrejection', handleUnhandledRejection);
      window.removeEventListener('error', handleResourceError, true);
      console.error = originalConsoleError;
      console.warn = originalConsoleWarn;
    };
  };

  const addError = (newError) => {
    setErrors(prev => {
      // Check for duplicate errors
      const existingError = prev.find(error => 
        error.message === newError.message && 
        error.source === newError.source &&
        error.line === newError.line
      );

      if (existingError) {
        // Update count for existing error
        return prev.map(error => 
          error.id === existingError.id 
            ? { ...error, count: error.count + 1, timestamp: new Date() }
            : error
        );
      } else {
        // Add new error
        return [newError, ...prev.slice(0, 99)]; // Keep only last 100 errors
      }
    });
  };

  const clearErrors = () => {
    setErrors([]);
    setSelectedError(null);
  };

  const exportErrors = () => {
    const data = {
      timestamp: new Date().toISOString(),
      errors: errors,
      summary: {
        total: errors.length,
        byType: Object.keys(errorTypes).reduce((acc, type) => {
          acc[type] = errors.filter(error => error.type === type).length;
          return acc;
        }, {}),
        byLevel: {
          error: errors.filter(error => error.level === 'error').length,
          warning: errors.filter(error => error.level === 'warning').length
        }
      }
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `error-report-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const formatTimestamp = (timestamp) => {
    return new Date(timestamp).toLocaleTimeString();
  };

  const getErrorIcon = (level) => {
    switch (level) {
      case 'error': return XCircle;
      case 'warning': return AlertTriangle;
      default: return Info;
    }
  };

  const getErrorColor = (level) => {
    switch (level) {
      case 'error': return 'text-red-400';
      case 'warning': return 'text-yellow-400';
      default: return 'text-blue-400';
    }
  };

  const ErrorItem = ({ error, onClick }) => {
    const Icon = getErrorIcon(error.level);
    const TypeIcon = errorTypes[error.type]?.icon || Bug;
    
    return (
      <div 
        className={`error-item ${error.level} p-3 cursor-pointer hover:bg-debug-panel border-l-4 ${
          error.level === 'error' ? 'border-red-500' : 'border-yellow-500'
        }`}
        onClick={() => onClick(error)}
      >
        <div className="flex items-start space-x-3">
          <Icon className={`w-4 h-4 mt-0.5 ${getErrorColor(error.level)}`} />
          <div className="flex-1 min-w-0">
            <div className="flex items-center space-x-2 mb-1">
              <TypeIcon className={`w-3 h-3 ${errorTypes[error.type]?.color}`} />
              <span className="text-xs font-medium text-debug-muted uppercase">
                {errorTypes[error.type]?.label || error.type}
              </span>
              <span className="text-xs text-debug-muted">{formatTimestamp(error.timestamp)}</span>
              {error.count > 1 && (
                <span className="bg-red-500 text-white text-xs px-1.5 py-0.5 rounded-full">
                  {error.count}
                </span>
              )}
            </div>
            <p className="text-sm text-debug-text font-medium truncate">
              {error.message}
            </p>
            <p className="text-xs text-debug-muted truncate">
              {error.source}:{error.line}:{error.column}
            </p>
          </div>
        </div>
      </div>
    );
  };

  const ErrorDetails = ({ error, onClose }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-debug-panel border border-debug-border rounded-lg max-w-4xl max-h-[80vh] w-full mx-4 overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-debug-border">
          <h3 className="font-semibold text-debug-text">Error Details</h3>
          <button onClick={onClose} className="p-1 hover:bg-debug-bg rounded">
            <XCircle className="w-4 h-4" />
          </button>
        </div>
        <div className="p-4 overflow-auto max-h-96">
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-debug-muted">Message</label>
              <p className="text-debug-text bg-debug-bg p-2 rounded mt-1">{error.message}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-debug-muted">Stack Trace</label>
              <pre className="text-xs text-debug-text bg-debug-bg p-2 rounded mt-1 overflow-auto">
                {error.stack}
              </pre>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-debug-muted">Source</label>
                <p className="text-debug-text">{error.source}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-debug-muted">Location</label>
                <p className="text-debug-text">{error.line}:{error.column}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-debug-muted">Type</label>
                <p className="text-debug-text">{errorTypes[error.type]?.label || error.type}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-debug-muted">Count</label>
                <p className="text-debug-text">{error.count}</p>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-debug-muted">User Agent</label>
              <p className="text-xs text-debug-text bg-debug-bg p-2 rounded mt-1">{error.userAgent}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-debug-muted">URL</label>
              <p className="text-xs text-debug-text bg-debug-bg p-2 rounded mt-1">{error.url}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-full flex flex-col bg-debug-bg text-debug-text">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-debug-border">
        <div className="flex items-center space-x-2">
          <AlertTriangle className="w-5 h-5 text-debug-accent" />
          <h3 className="font-semibold">Error Tracker</h3>
          <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">
            {errors.length}
          </span>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsTracking(!isTracking)}
            className={`px-3 py-1 rounded text-xs font-medium ${
              isTracking 
                ? 'bg-green-500 text-white' 
                : 'bg-debug-panel text-debug-text border border-debug-border'
            }`}
          >
            {isTracking ? 'Tracking' : 'Paused'}
          </button>
          <button
            onClick={exportErrors}
            className="p-2 hover:bg-debug-panel rounded"
            title="Export Errors"
          >
            <Download className="w-4 h-4" />
          </button>
          <button
            onClick={clearErrors}
            className="p-2 hover:bg-debug-panel rounded"
            title="Clear Errors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="p-4 border-b border-debug-border space-y-3">
        <div className="flex items-center space-x-2">
          <Search className="w-4 h-4 text-debug-muted" />
          <input
            type="text"
            placeholder="Search errors..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1 bg-debug-panel border border-debug-border rounded px-3 py-1 text-sm text-debug-text placeholder-debug-muted focus:outline-none focus:border-debug-accent"
          />
        </div>
        <div className="flex items-center space-x-2">
          <Filter className="w-4 h-4 text-debug-muted" />
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="bg-debug-panel border border-debug-border rounded px-3 py-1 text-sm text-debug-text focus:outline-none focus:border-debug-accent"
          >
            <option value="all">All Types</option>
            {Object.entries(errorTypes).map(([key, type]) => (
              <option key={key} value={key}>{type.label}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Error List */}
      <div className="flex-1 overflow-auto">
        {filteredErrors.length === 0 ? (
          <div className="flex items-center justify-center h-full text-debug-muted">
            <div className="text-center">
              <Bug className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No errors found</p>
              {!isTracking && (
                <p className="text-xs mt-2">Error tracking is paused</p>
              )}
            </div>
          </div>
        ) : (
          <div className="divide-y divide-debug-border">
            {filteredErrors.map((error) => (
              <ErrorItem
                key={error.id}
                error={error}
                onClick={setSelectedError}
              />
            ))}
          </div>
        )}
      </div>

      {/* Error Details Modal */}
      {selectedError && (
        <ErrorDetails
          error={selectedError}
          onClose={() => setSelectedError(null)}
        />
      )}
    </div>
  );
};

export { ErrorTracker };
