// @ts-nocheck
import React, { useState, useEffect, useRef } from 'react';
import { 
  Activity, 
  Cpu, 
  MemoryStick, 
  HardDrive, 
  Zap, 
  Clock,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  RefreshCw,
  Download,
  Settings
} from 'lucide-react';

const PerformanceMonitor = () => {
  const [metrics, setMetrics] = useState({
    fps: 60,
    memory: { used: 0, total: 0 },
    cpu: 0,
    renderTime: 0,
    bundleSize: 0,
    networkLatency: 0
  });
  
  const [history, setHistory] = useState({
    fps: [],
    memory: [],
    cpu: [],
    renderTime: []
  });
  
  const [isRecording, setIsRecording] = useState(false);
  const [alerts, setAlerts] = useState([]);
  const intervalRef = useRef(null);
  const performanceObserver = useRef(null);

  // Performance thresholds
  const thresholds = {
    fps: { warning: 30, critical: 15 },
    memory: { warning: 50, critical: 80 }, // MB
    cpu: { warning: 70, critical: 90 }, // %
    renderTime: { warning: 16, critical: 32 } // ms
  };

  // Initialize performance monitoring
  useEffect(() => {
    initializePerformanceMonitoring();
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (performanceObserver.current) performanceObserver.current.disconnect();
    };
  }, []);

  const initializePerformanceMonitoring = () => {
    // FPS monitoring
    let lastTime = performance.now();
    let frameCount = 0;
    
    const measureFPS = () => {
      frameCount++;
      const currentTime = performance.now();
      if (currentTime - lastTime >= 1000) {
        const fps = Math.round((frameCount * 1000) / (currentTime - lastTime));
        updateMetric('fps', fps);
        frameCount = 0;
        lastTime = currentTime;
      }
      requestAnimationFrame(measureFPS);
    };
    measureFPS();

    // Memory monitoring
    if ('memory' in performance) {
      intervalRef.current = setInterval(() => {
        const memory = performance.memory;
        updateMetric('memory', {
          used: Math.round(memory.usedJSHeapSize / 1024 / 1024),
          total: Math.round(memory.totalJSHeapSize / 1024 / 1024)
        });
      }, 1000);
    }

    // Performance Observer for render times
    if ('PerformanceObserver' in window) {
      performanceObserver.current = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        entries.forEach((entry) => {
          if (entry.entryType === 'measure') {
            updateMetric('renderTime', Math.round(entry.duration));
          }
        });
      });
      
      try {
        performanceObserver.current.observe({ entryTypes: ['measure'] });
      } catch (e) {
        console.warn('Performance Observer not supported');
      }
    }

    // CPU usage estimation (approximate)
    let lastCPUTime = performance.now();
    setInterval(() => {
      const currentTime = performance.now();
      const timeDiff = currentTime - lastCPUTime;
      // Simulate CPU usage based on frame timing
      const estimatedCPU = Math.min(100, Math.max(0, (timeDiff - 16) * 2));
      updateMetric('cpu', Math.round(estimatedCPU));
      lastCPUTime = currentTime;
    }, 1000);
  };

  const updateMetric = (key, value) => {
    setMetrics(prev => ({ ...prev, [key]: value }));
    
    if (isRecording) {
      setHistory(prev => ({
        ...prev,
        [key]: [...prev[key].slice(-59), { time: Date.now(), value }]
      }));
    }

    // Check thresholds and create alerts
    checkThresholds(key, value);
  };

  const checkThresholds = (metric, value) => {
    const threshold = thresholds[metric];
    if (!threshold) return;

    const actualValue = typeof value === 'object' ? value.used : value;
    let level = null;

    if (actualValue >= threshold.critical) {
      level = 'critical';
    } else if (actualValue >= threshold.warning) {
      level = 'warning';
    }

    if (level) {
      const alert = {
        id: Date.now(),
        metric,
        level,
        value: actualValue,
        threshold: threshold[level],
        timestamp: new Date().toLocaleTimeString()
      };

      setAlerts(prev => [alert, ...prev.slice(0, 9)]);
    }
  };

  const getMetricStatus = (metric, value) => {
    const threshold = thresholds[metric];
    if (!threshold) return 'normal';

    const actualValue = typeof value === 'object' ? value.used : value;
    
    if (actualValue >= threshold.critical) return 'critical';
    if (actualValue >= threshold.warning) return 'warning';
    return 'normal';
  };

  const formatBytes = (bytes) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const exportMetrics = () => {
    const data = {
      timestamp: new Date().toISOString(),
      metrics,
      history,
      alerts
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `performance-metrics-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const MetricCard = ({ title, value, unit, icon: Icon, status, trend }) => (
    <div className={`performance-metric bg-debug-panel border border-debug-border rounded-lg p-4 ${
      status === 'critical' ? 'border-red-500' : 
      status === 'warning' ? 'border-yellow-500' : 
      'border-debug-border'
    }`}>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center space-x-2">
          <Icon className="w-4 h-4 text-debug-accent" />
          <span className="text-sm font-medium text-debug-text">{title}</span>
        </div>
        {trend && (
          <div className="flex items-center space-x-1">
            {trend > 0 ? (
              <TrendingUp className="w-3 h-3 text-red-400" />
            ) : (
              <TrendingDown className="w-3 h-3 text-green-400" />
            )}
            <span className="text-xs text-debug-muted">{Math.abs(trend)}%</span>
          </div>
        )}
      </div>
      <div className="flex items-baseline space-x-1">
        <span className={`text-2xl font-bold ${
          status === 'critical' ? 'text-red-400' :
          status === 'warning' ? 'text-yellow-400' :
          'text-debug-text'
        }`}>
          {typeof value === 'object' ? value.used : value}
        </span>
        <span className="text-sm text-debug-muted">{unit}</span>
        {typeof value === 'object' && (
          <span className="text-xs text-debug-muted">/ {value.total} MB</span>
        )}
      </div>
      {status !== 'normal' && (
        <div className="mt-2 flex items-center space-x-1">
          <AlertTriangle className="w-3 h-3 text-yellow-400" />
          <span className="text-xs text-yellow-400">
            {status === 'critical' ? 'Critical' : 'Warning'} threshold reached
          </span>
        </div>
      )}
    </div>
  );

  const MiniChart = ({ data, color = '#3b82f6' }) => {
    if (!data || data.length === 0) return null;

    const max = Math.max(...data.map(d => d.value));
    const min = Math.min(...data.map(d => d.value));
    const range = max - min || 1;

    return (
      <div className="h-16 flex items-end space-x-1">
        {data.slice(-20).map((point, index) => (
          <div
            key={index}
            className="flex-1 bg-current opacity-70 rounded-t"
            style={{
              height: `${((point.value - min) / range) * 100}%`,
              color,
              minHeight: '2px'
            }}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="h-full flex flex-col bg-debug-bg text-debug-text">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-debug-border">
        <div className="flex items-center space-x-2">
          <Activity className="w-5 h-5 text-debug-accent" />
          <h3 className="font-semibold">Performance Monitor</h3>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsRecording(!isRecording)}
            className={`px-3 py-1 rounded text-xs font-medium ${
              isRecording 
                ? 'bg-red-500 text-white' 
                : 'bg-debug-panel text-debug-text border border-debug-border'
            }`}
          >
            {isRecording ? 'Stop Recording' : 'Start Recording'}
          </button>
          <button
            onClick={exportMetrics}
            className="p-2 hover:bg-debug-panel rounded"
            title="Export Metrics"
          >
            <Download className="w-4 h-4" />
          </button>
          <button className="p-2 hover:bg-debug-panel rounded" title="Settings">
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="flex-1 p-4 space-y-4 overflow-auto">
        <div className="grid grid-cols-2 gap-4">
          <MetricCard
            title="FPS"
            value={metrics.fps}
            unit="fps"
            icon={Zap}
            status={getMetricStatus('fps', metrics.fps)}
          />
          <MetricCard
            title="Memory"
            value={metrics.memory}
            unit="MB"
            icon={MemoryStick}
            status={getMetricStatus('memory', metrics.memory)}
          />
          <MetricCard
            title="CPU"
            value={metrics.cpu}
            unit="%"
            icon={Cpu}
            status={getMetricStatus('cpu', metrics.cpu)}
          />
          <MetricCard
            title="Render Time"
            value={metrics.renderTime}
            unit="ms"
            icon={Clock}
            status={getMetricStatus('renderTime', metrics.renderTime)}
          />
        </div>

        {/* Performance Charts */}
        {isRecording && (
          <div className="space-y-4">
            <h4 className="font-medium text-debug-text">Performance History</h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-debug-panel border border-debug-border rounded-lg p-4">
                <h5 className="text-sm font-medium text-debug-text mb-2">FPS</h5>
                <MiniChart data={history.fps} color="#10b981" />
              </div>
              <div className="bg-debug-panel border border-debug-border rounded-lg p-4">
                <h5 className="text-sm font-medium text-debug-text mb-2">Memory</h5>
                <MiniChart data={history.memory} color="#3b82f6" />
              </div>
              <div className="bg-debug-panel border border-debug-border rounded-lg p-4">
                <h5 className="text-sm font-medium text-debug-text mb-2">CPU</h5>
                <MiniChart data={history.cpu} color="#f59e0b" />
              </div>
              <div className="bg-debug-panel border border-debug-border rounded-lg p-4">
                <h5 className="text-sm font-medium text-debug-text mb-2">Render Time</h5>
                <MiniChart data={history.renderTime} color="#ef4444" />
              </div>
            </div>
          </div>
        )}

        {/* Alerts */}
        {alerts.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-medium text-debug-text">Recent Alerts</h4>
            <div className="space-y-2 max-h-32 overflow-auto">
              {alerts.map((alert) => (
                <div
                  key={alert.id}
                  className={`p-2 rounded border-l-4 ${
                    alert.level === 'critical' 
                      ? 'border-red-500 bg-red-900/20' 
                      : 'border-yellow-500 bg-yellow-900/20'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">
                      {alert.metric.toUpperCase()} {alert.level}
                    </span>
                    <span className="text-xs text-debug-muted">{alert.timestamp}</span>
                  </div>
                  <p className="text-xs text-debug-muted">
                    Value: {alert.value} (threshold: {alert.threshold})
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export { PerformanceMonitor };
