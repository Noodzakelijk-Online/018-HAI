// @ts-nocheck
import React, { useState, useEffect, useRef } from 'react';
import { 
  Database, 
  RefreshCw, 
  Search, 
  ChevronRight, 
  ChevronDown,
  Copy,
  Download,
  Eye,
  EyeOff,
  Filter,
  Trash2,
  AlertCircle,
  CheckCircle,
  Clock
} from 'lucide-react';

/**
 * StateInspector Component
 * 
 * Provides real-time inspection of application state including:
 * - Redux/Context state
 * - Component state
 * - Local storage
 * - Session storage
 * - Cookies
 * - IndexedDB (if applicable)
 * 
 * Features:
 * - Tree view with expand/collapse
 * - Search and filter
 * - Copy to clipboard
 * - Export state as JSON
 * - Real-time updates
 * - State diff tracking
 */
export const StateInspector = () => {
  const [stateData, setStateData] = useState({});
  const [expandedPaths, setExpandedPaths] = useState(new Set(['root']));
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTab, setSelectedTab] = useState('app');
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [refreshInterval, setRefreshInterval] = useState(1000);
  const [showDiff, setShowDiff] = useState(false);
  const [previousState, setPreviousState] = useState(null);
  const intervalRef = useRef(null);

  // Tabs for different state sources
  const tabs = [
    { id: 'app', label: 'App State', icon: Database },
    { id: 'local', label: 'Local Storage', icon: Database },
    { id: 'session', label: 'Session Storage', icon: Database },
    { id: 'cookies', label: 'Cookies', icon: Database }
  ];

  // Collect state from various sources
  const collectState = () => {
    const state = {};

    switch (selectedTab) {
      case 'app':
        // Collect from window.__REDUX_STATE__ or window.__APP_STATE__
        state.redux = window.__REDUX_STATE__ || null;
        state.context = window.__CONTEXT_STATE__ || null;
        
        // Collect React component states (if available through React DevTools)
        if (window.__REACT_DEVTOOLS_GLOBAL_HOOK__) {
          state.reactDevTools = 'Available - Use React DevTools for component inspection';
        }
        
        // Custom app state
        state.custom = window.__HAI_STATE__ || null;
        break;

      case 'local':
        // Collect from localStorage
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          try {
            state[key] = JSON.parse(localStorage.getItem(key));
          } catch {
            state[key] = localStorage.getItem(key);
          }
        }
        break;

      case 'session':
        // Collect from sessionStorage
        for (let i = 0; i < sessionStorage.length; i++) {
          const key = sessionStorage.key(i);
          try {
            state[key] = JSON.parse(sessionStorage.getItem(key));
          } catch {
            state[key] = sessionStorage.getItem(key);
          }
        }
        break;

      case 'cookies':
        // Parse cookies
        document.cookie.split(';').forEach(cookie => {
          const [key, value] = cookie.trim().split('=');
          if (key) {
            state[key] = decodeURIComponent(value || '');
          }
        });
        break;

      default:
        break;
    }

    return state;
  };

  // Refresh state data
  const refreshState = () => {
    const newState = collectState();
    
    if (showDiff) {
      setPreviousState(stateData);
    }
    
    setStateData(newState);
  };

  // Auto-refresh effect
  useEffect(() => {
    refreshState();

    if (autoRefresh) {
      intervalRef.current = setInterval(refreshState, refreshInterval);
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [selectedTab, autoRefresh, refreshInterval]);

  // Toggle expand/collapse for tree nodes
  const toggleExpand = (path) => {
    const newExpanded = new Set(expandedPaths);
    if (newExpanded.has(path)) {
      newExpanded.delete(path);
    } else {
      newExpanded.add(path);
    }
    setExpandedPaths(newExpanded);
  };

  // Copy to clipboard
  const copyToClipboard = (data) => {
    const text = typeof data === 'string' ? data : JSON.stringify(data, null, 2);
    navigator.clipboard.writeText(text).then(() => {
      console.log('Copied to clipboard');
    });
  };

  // Export state as JSON file
  const exportState = () => {
    const dataStr = JSON.stringify(stateData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `state-${selectedTab}-${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Render value based on type
  const renderValue = (value, path) => {
    if (value === null) {
      return <span className="text-gray-500">null</span>;
    }
    if (value === undefined) {
      return <span className="text-gray-500">undefined</span>;
    }
    if (typeof value === 'boolean') {
      return <span className="text-purple-400">{value.toString()}</span>;
    }
    if (typeof value === 'number') {
      return <span className="text-green-400">{value}</span>;
    }
    if (typeof value === 'string') {
      return <span className="text-yellow-400">"{value}"</span>;
    }
    if (Array.isArray(value)) {
      return (
        <span className="text-blue-400">
          Array[{value.length}]
        </span>
      );
    }
    if (typeof value === 'object') {
      return (
        <span className="text-blue-400">
          Object {'{'}...{'}'}
        </span>
      );
    }
    return <span className="text-gray-400">{String(value)}</span>;
  };

  // Render tree node
  const renderTreeNode = (key, value, path = 'root', level = 0) => {
    const currentPath = `${path}.${key}`;
    const isExpanded = expandedPaths.has(currentPath);
    const isExpandable = typeof value === 'object' && value !== null;
    const hasChanged = showDiff && previousState && 
      JSON.stringify(previousState[key]) !== JSON.stringify(value);

    // Filter by search term
    if (searchTerm && !currentPath.toLowerCase().includes(searchTerm.toLowerCase())) {
      return null;
    }

    return (
      <div key={currentPath} className="text-xs font-mono">
        <div
          className={`flex items-center space-x-2 py-1 px-2 hover:bg-gray-700 rounded cursor-pointer ${
            hasChanged ? 'bg-yellow-900 bg-opacity-20' : ''
          }`}
          style={{ paddingLeft: `${level * 16 + 8}px` }}
          onClick={() => isExpandable && toggleExpand(currentPath)}
        >
          {isExpandable && (
            <span className="text-gray-500">
              {isExpanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
            </span>
          )}
          
          <span className="text-blue-300">{key}:</span>
          
          {!isExpanded && <span>{renderValue(value, currentPath)}</span>}
          
          <button
            onClick={(e) => {
              e.stopPropagation();
              copyToClipboard(value);
            }}
            className="ml-auto p-1 hover:bg-gray-600 rounded opacity-0 group-hover:opacity-100"
            title="Copy to clipboard"
          >
            <Copy size={10} />
          </button>
          
          {hasChanged && (
            <span className="text-yellow-400" title="Value changed">
              <AlertCircle size={10} />
            </span>
          )}
        </div>

        {isExpanded && isExpandable && (
          <div>
            {Object.entries(value).map(([childKey, childValue]) =>
              renderTreeNode(childKey, childValue, currentPath, level + 1)
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full bg-gray-900 text-white">
      {/* Header */}
      <div className="flex items-center justify-between p-3 border-b border-gray-700">
        <div className="flex items-center space-x-2">
          <Database size={14} className="text-blue-400" />
          <span className="text-sm font-medium">State Inspector</span>
        </div>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={refreshState}
            className="p-1 hover:bg-gray-700 rounded transition-colors"
            title="Refresh state"
          >
            <RefreshCw size={12} />
          </button>
          
          <button
            onClick={exportState}
            className="p-1 hover:bg-gray-700 rounded transition-colors"
            title="Export state"
          >
            <Download size={12} />
          </button>
          
          <button
            onClick={() => setShowDiff(!showDiff)}
            className={`p-1 rounded transition-colors ${
              showDiff ? 'bg-blue-600' : 'hover:bg-gray-700'
            }`}
            title="Show diff"
          >
            <Eye size={12} />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-700">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setSelectedTab(tab.id)}
              className={`flex items-center space-x-1 px-3 py-2 text-xs transition-colors ${
                selectedTab === tab.id
                  ? 'bg-gray-700 text-white border-b-2 border-blue-400'
                  : 'text-gray-400 hover:text-white hover:bg-gray-700'
              }`}
            >
              <Icon size={10} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Controls */}
      <div className="flex items-center space-x-2 p-2 border-b border-gray-700">
        <div className="flex-1 relative">
          <Search size={12} className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-500" />
          <input
            type="text"
            placeholder="Search state..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-7 pr-2 py-1 text-xs bg-gray-800 border border-gray-700 rounded focus:outline-none focus:border-blue-500"
          />
        </div>
        
        <label className="flex items-center space-x-1 text-xs">
          <input
            type="checkbox"
            checked={autoRefresh}
            onChange={(e) => setAutoRefresh(e.target.checked)}
            className="form-checkbox h-3 w-3 text-blue-500"
          />
          <span>Auto</span>
        </label>
        
        <select
          value={refreshInterval}
          onChange={(e) => setRefreshInterval(Number(e.target.value))}
          className="px-2 py-1 text-xs bg-gray-800 border border-gray-700 rounded focus:outline-none focus:border-blue-500"
          disabled={!autoRefresh}
        >
          <option value={500}>500ms</option>
          <option value={1000}>1s</option>
          <option value={2000}>2s</option>
          <option value={5000}>5s</option>
        </select>
      </div>

      {/* State Tree */}
      <div className="flex-1 overflow-auto p-2">
        {Object.keys(stateData).length === 0 ? (
          <div className="flex items-center justify-center h-full text-gray-500 text-xs">
            <div className="text-center">
              <Database size={24} className="mx-auto mb-2 opacity-50" />
              <p>No state data available</p>
              <p className="text-xs mt-1">Select a different tab or refresh</p>
            </div>
          </div>
        ) : (
          <div className="group">
            {Object.entries(stateData).map(([key, value]) =>
              renderTreeNode(key, value)
            )}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between px-3 py-1 text-xs border-t border-gray-700 bg-gray-800">
        <span className="text-gray-400">
          {Object.keys(stateData).length} keys
        </span>
        
        <div className="flex items-center space-x-2">
          {autoRefresh && (
            <span className="flex items-center space-x-1 text-green-400">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span>Auto-refresh</span>
            </span>
          )}
          
          <span className="text-gray-500">
            <Clock size={10} className="inline mr-1" />
            {new Date().toLocaleTimeString()}
          </span>
        </div>
      </div>
    </div>
  );
};

export default StateInspector;
