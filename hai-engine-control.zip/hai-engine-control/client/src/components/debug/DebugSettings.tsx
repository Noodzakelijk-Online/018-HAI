// @ts-nocheck
import React, { useState, useEffect } from 'react';
import { 
  Settings, 
  Save, 
  RotateCcw,
  Download,
  Upload,
  Trash2,
  Eye,
  EyeOff,
  Bell,
  BellOff,
  Zap,
  Shield,
  Database,
  Network,
  Monitor,
  AlertCircle,
  CheckCircle,
  Info,
  HelpCircle
} from 'lucide-react';

/**
 * DebugSettings Component
 * 
 * Provides configuration options for the debug tool:
 * - Performance monitoring settings
 * - Error tracking preferences
 * - Network monitoring options
 * - Log retention settings
 * - Export/import configuration
 * - Reset to defaults
 * - Keyboard shortcuts
 * - Notification preferences
 * 
 * Settings are persisted to localStorage
 */
export const DebugSettings = () => {
  const [settings, setSettings] = useState({
    // Performance settings
    performanceMonitoring: {
      enabled: true,
      fpsThreshold: 30,
      memoryWarningThreshold: 80,
      updateInterval: 1000,
      showFPS: true,
      showMemory: true,
      showCPU: true
    },
    
    // Error tracking settings
    errorTracking: {
      enabled: true,
      captureStackTraces: true,
      groupSimilarErrors: true,
      maxErrors: 100,
      autoReport: false,
      notifyOnError: true
    },
    
    // Network monitoring settings
    networkMonitoring: {
      enabled: true,
      captureHeaders: true,
      capturePayload: true,
      maxRequests: 100,
      slowRequestThreshold: 1000,
      notifyOnSlowRequest: true,
      notifyOnError: true
    },
    
    // Log viewer settings
    logViewer: {
      enabled: true,
      maxLogs: 1000,
      autoScroll: true,
      showTimestamps: true,
      defaultLevel: 'all',
      captureConsole: true
    },
    
    // State inspector settings
    stateInspector: {
      enabled: true,
      autoRefresh: true,
      refreshInterval: 1000,
      showDiff: false,
      expandByDefault: false
    },
    
    // General settings
    general: {
      theme: 'dark',
      position: 'bottom-right',
      defaultTab: 'console',
      keyboardShortcuts: true,
      persistPosition: true,
      showNotifications: true
    }
  });

  const [hasChanges, setHasChanges] = useState(false);
  const [saveStatus, setSaveStatus] = useState(null);

  // Load settings from localStorage on mount
  useEffect(() => {
    const savedSettings = localStorage.getItem('debugToolSettings');
    if (savedSettings) {
      try {
        setSettings(JSON.parse(savedSettings));
      } catch (error) {
        console.error('Failed to load debug settings:', error);
      }
    }
  }, []);

  // Update setting value
  const updateSetting = (category, key, value) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [key]: value
      }
    }));
    setHasChanges(true);
  };

  // Save settings to localStorage
  const saveSettings = () => {
    try {
      localStorage.setItem('debugToolSettings', JSON.stringify(settings));
      setHasChanges(false);
      setSaveStatus('success');
      setTimeout(() => setSaveStatus(null), 2000);
      
      // Dispatch custom event to notify other components
      window.dispatchEvent(new CustomEvent('debugSettingsChanged', { detail: settings }));
    } catch (error) {
      console.error('Failed to save debug settings:', error);
      setSaveStatus('error');
      setTimeout(() => setSaveStatus(null), 2000);
    }
  };

  // Reset to default settings
  const resetSettings = () => {
    if (confirm('Are you sure you want to reset all settings to defaults?')) {
      localStorage.removeItem('debugToolSettings');
      window.location.reload();
    }
  };

  // Export settings as JSON
  const exportSettings = () => {
    const dataStr = JSON.stringify(settings, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `debug-settings-${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Import settings from JSON file
  const importSettings = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const importedSettings = JSON.parse(e.target.result);
        setSettings(importedSettings);
        setHasChanges(true);
        setSaveStatus('imported');
        setTimeout(() => setSaveStatus(null), 2000);
      } catch (error) {
        console.error('Failed to import settings:', error);
        alert('Invalid settings file');
      }
    };
    reader.readAsText(file);
  };

  // Clear all debug data
  const clearAllData = () => {
    if (confirm('Are you sure you want to clear all debug data? This action cannot be undone.')) {
      // Clear debug-related localStorage items
      const keysToRemove = [];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key.startsWith('debug_') || key === 'debugToolSettings') {
          keysToRemove.push(key);
        }
      }
      keysToRemove.forEach(key => localStorage.removeItem(key));
      
      alert('All debug data has been cleared');
    }
  };

  // Render setting section
  const renderSection = (title, icon, children) => {
    const Icon = icon;
    return (
      <div className="mb-4 border border-gray-700 rounded-lg overflow-hidden">
        <div className="flex items-center space-x-2 px-3 py-2 bg-gray-800 border-b border-gray-700">
          <Icon size={14} className="text-blue-400" />
          <span className="text-sm font-medium">{title}</span>
        </div>
        <div className="p-3 space-y-3">
          {children}
        </div>
      </div>
    );
  };

  // Render toggle setting
  const renderToggle = (category, key, label, description) => (
    <div className="flex items-start justify-between">
      <div className="flex-1">
        <label className="text-xs font-medium text-gray-300">{label}</label>
        {description && (
          <p className="text-xs text-gray-500 mt-0.5">{description}</p>
        )}
      </div>
      <label className="relative inline-flex items-center cursor-pointer ml-4">
        <input
          type="checkbox"
          checked={settings[category][key]}
          onChange={(e) => updateSetting(category, key, e.target.checked)}
          className="sr-only peer"
        />
        <div className="w-9 h-5 bg-gray-700 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-600"></div>
      </label>
    </div>
  );

  // Render number input setting
  const renderNumberInput = (category, key, label, min, max, step = 1) => (
    <div className="flex items-center justify-between">
      <label className="text-xs font-medium text-gray-300">{label}</label>
      <input
        type="number"
        value={settings[category][key]}
        onChange={(e) => updateSetting(category, key, Number(e.target.value))}
        min={min}
        max={max}
        step={step}
        className="w-20 px-2 py-1 text-xs bg-gray-800 border border-gray-700 rounded focus:outline-none focus:border-blue-500"
      />
    </div>
  );

  // Render select input setting
  const renderSelect = (category, key, label, options) => (
    <div className="flex items-center justify-between">
      <label className="text-xs font-medium text-gray-300">{label}</label>
      <select
        value={settings[category][key]}
        onChange={(e) => updateSetting(category, key, e.target.value)}
        className="px-2 py-1 text-xs bg-gray-800 border border-gray-700 rounded focus:outline-none focus:border-blue-500"
      >
        {options.map(option => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );

  return (
    <div className="flex flex-col h-full bg-gray-900 text-white">
      {/* Header */}
      <div className="flex items-center justify-between p-3 border-b border-gray-700">
        <div className="flex items-center space-x-2">
          <Settings size={14} className="text-blue-400" />
          <span className="text-sm font-medium">Debug Settings</span>
        </div>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={saveSettings}
            disabled={!hasChanges}
            className={`flex items-center space-x-1 px-2 py-1 text-xs rounded transition-colors ${
              hasChanges
                ? 'bg-blue-600 hover:bg-blue-700 text-white'
                : 'bg-gray-700 text-gray-500 cursor-not-allowed'
            }`}
          >
            <Save size={12} />
            <span>Save</span>
          </button>
          
          {saveStatus === 'success' && (
            <span className="flex items-center space-x-1 text-green-400 text-xs">
              <CheckCircle size={12} />
              <span>Saved</span>
            </span>
          )}
          
          {saveStatus === 'error' && (
            <span className="flex items-center space-x-1 text-red-400 text-xs">
              <AlertCircle size={12} />
              <span>Error</span>
            </span>
          )}
          
          {saveStatus === 'imported' && (
            <span className="flex items-center space-x-1 text-blue-400 text-xs">
              <CheckCircle size={12} />
              <span>Imported</span>
            </span>
          )}
        </div>
      </div>

      {/* Settings Content */}
      <div className="flex-1 overflow-auto p-3">
        {/* Performance Monitoring */}
        {renderSection('Performance Monitoring', Monitor, (
          <>
            {renderToggle('performanceMonitoring', 'enabled', 'Enable Performance Monitoring', 'Track FPS, memory, and CPU usage')}
            {renderToggle('performanceMonitoring', 'showFPS', 'Show FPS', 'Display frames per second')}
            {renderToggle('performanceMonitoring', 'showMemory', 'Show Memory', 'Display memory usage')}
            {renderToggle('performanceMonitoring', 'showCPU', 'Show CPU', 'Display CPU usage')}
            {renderNumberInput('performanceMonitoring', 'fpsThreshold', 'FPS Warning Threshold', 10, 60)}
            {renderNumberInput('performanceMonitoring', 'memoryWarningThreshold', 'Memory Warning (%)', 50, 100)}
            {renderNumberInput('performanceMonitoring', 'updateInterval', 'Update Interval (ms)', 100, 5000, 100)}
          </>
        ))}

        {/* Error Tracking */}
        {renderSection('Error Tracking', AlertCircle, (
          <>
            {renderToggle('errorTracking', 'enabled', 'Enable Error Tracking', 'Capture and display errors')}
            {renderToggle('errorTracking', 'captureStackTraces', 'Capture Stack Traces', 'Include stack traces in error reports')}
            {renderToggle('errorTracking', 'groupSimilarErrors', 'Group Similar Errors', 'Combine duplicate errors')}
            {renderToggle('errorTracking', 'notifyOnError', 'Notify on Error', 'Show notification when errors occur')}
            {renderToggle('errorTracking', 'autoReport', 'Auto Report Errors', 'Automatically send error reports')}
            {renderNumberInput('errorTracking', 'maxErrors', 'Max Errors to Store', 10, 1000, 10)}
          </>
        ))}

        {/* Network Monitoring */}
        {renderSection('Network Monitoring', Network, (
          <>
            {renderToggle('networkMonitoring', 'enabled', 'Enable Network Monitoring', 'Track HTTP requests and responses')}
            {renderToggle('networkMonitoring', 'captureHeaders', 'Capture Headers', 'Include request/response headers')}
            {renderToggle('networkMonitoring', 'capturePayload', 'Capture Payload', 'Include request/response bodies')}
            {renderToggle('networkMonitoring', 'notifyOnSlowRequest', 'Notify on Slow Requests', 'Alert when requests are slow')}
            {renderToggle('networkMonitoring', 'notifyOnError', 'Notify on Network Errors', 'Alert when requests fail')}
            {renderNumberInput('networkMonitoring', 'maxRequests', 'Max Requests to Store', 10, 1000, 10)}
            {renderNumberInput('networkMonitoring', 'slowRequestThreshold', 'Slow Request Threshold (ms)', 100, 10000, 100)}
          </>
        ))}

        {/* Log Viewer */}
        {renderSection('Log Viewer', Database, (
          <>
            {renderToggle('logViewer', 'enabled', 'Enable Log Viewer', 'Capture and display console logs')}
            {renderToggle('logViewer', 'captureConsole', 'Capture Console', 'Intercept console.log/warn/error')}
            {renderToggle('logViewer', 'autoScroll', 'Auto Scroll', 'Automatically scroll to new logs')}
            {renderToggle('logViewer', 'showTimestamps', 'Show Timestamps', 'Display log timestamps')}
            {renderNumberInput('logViewer', 'maxLogs', 'Max Logs to Store', 100, 10000, 100)}
            {renderSelect('logViewer', 'defaultLevel', 'Default Log Level', [
              { value: 'all', label: 'All' },
              { value: 'debug', label: 'Debug' },
              { value: 'info', label: 'Info' },
              { value: 'warn', label: 'Warn' },
              { value: 'error', label: 'Error' }
            ])}
          </>
        ))}

        {/* State Inspector */}
        {renderSection('State Inspector', Database, (
          <>
            {renderToggle('stateInspector', 'enabled', 'Enable State Inspector', 'Inspect application state')}
            {renderToggle('stateInspector', 'autoRefresh', 'Auto Refresh', 'Automatically refresh state')}
            {renderToggle('stateInspector', 'showDiff', 'Show Diff', 'Highlight state changes')}
            {renderToggle('stateInspector', 'expandByDefault', 'Expand by Default', 'Expand all state nodes')}
            {renderNumberInput('stateInspector', 'refreshInterval', 'Refresh Interval (ms)', 100, 5000, 100)}
          </>
        ))}

        {/* General Settings */}
        {renderSection('General', Settings, (
          <>
            {renderToggle('general', 'keyboardShortcuts', 'Keyboard Shortcuts', 'Enable keyboard shortcuts')}
            {renderToggle('general', 'persistPosition', 'Persist Position', 'Remember panel position')}
            {renderToggle('general', 'showNotifications', 'Show Notifications', 'Display system notifications')}
            {renderSelect('general', 'theme', 'Theme', [
              { value: 'dark', label: 'Dark' },
              { value: 'light', label: 'Light' }
            ])}
            {renderSelect('general', 'position', 'Default Position', [
              { value: 'top-left', label: 'Top Left' },
              { value: 'top-right', label: 'Top Right' },
              { value: 'bottom-left', label: 'Bottom Left' },
              { value: 'bottom-right', label: 'Bottom Right' }
            ])}
            {renderSelect('general', 'defaultTab', 'Default Tab', [
              { value: 'console', label: 'Console' },
              { value: 'performance', label: 'Performance' },
              { value: 'errors', label: 'Errors' },
              { value: 'network', label: 'Network' },
              { value: 'state', label: 'State' },
              { value: 'logs', label: 'Logs' }
            ])}
          </>
        ))}

        {/* Actions */}
        <div className="border border-gray-700 rounded-lg overflow-hidden">
          <div className="flex items-center space-x-2 px-3 py-2 bg-gray-800 border-b border-gray-700">
            <Zap size={14} className="text-blue-400" />
            <span className="text-sm font-medium">Actions</span>
          </div>
          <div className="p-3 space-y-2">
            <button
              onClick={exportSettings}
              className="w-full flex items-center justify-center space-x-2 px-3 py-2 text-xs bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded transition-colors"
            >
              <Download size={12} />
              <span>Export Settings</span>
            </button>
            
            <label className="w-full flex items-center justify-center space-x-2 px-3 py-2 text-xs bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded transition-colors cursor-pointer">
              <Upload size={12} />
              <span>Import Settings</span>
              <input
                type="file"
                accept=".json"
                onChange={importSettings}
                className="hidden"
              />
            </label>
            
            <button
              onClick={clearAllData}
              className="w-full flex items-center justify-center space-x-2 px-3 py-2 text-xs bg-yellow-900 hover:bg-yellow-800 border border-yellow-700 rounded transition-colors"
            >
              <Trash2 size={12} />
              <span>Clear All Debug Data</span>
            </button>
            
            <button
              onClick={resetSettings}
              className="w-full flex items-center justify-center space-x-2 px-3 py-2 text-xs bg-red-900 hover:bg-red-800 border border-red-700 rounded transition-colors"
            >
              <RotateCcw size={12} />
              <span>Reset to Defaults</span>
            </button>
          </div>
        </div>

        {/* Keyboard Shortcuts */}
        <div className="border border-gray-700 rounded-lg overflow-hidden mt-4">
          <div className="flex items-center space-x-2 px-3 py-2 bg-gray-800 border-b border-gray-700">
            <HelpCircle size={14} className="text-blue-400" />
            <span className="text-sm font-medium">Keyboard Shortcuts</span>
          </div>
          <div className="p-3 space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-gray-400">Toggle Debug Panel</span>
              <kbd className="px-2 py-1 bg-gray-800 border border-gray-700 rounded">Ctrl + Shift + D</kbd>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Clear Console</span>
              <kbd className="px-2 py-1 bg-gray-800 border border-gray-700 rounded">Ctrl + L</kbd>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Export Logs</span>
              <kbd className="px-2 py-1 bg-gray-800 border border-gray-700 rounded">Ctrl + E</kbd>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between px-3 py-1 text-xs border-t border-gray-700 bg-gray-800">
        <span className="text-gray-400">
          Debug Tool v1.0.0
        </span>
        
        {hasChanges && (
          <span className="flex items-center space-x-1 text-yellow-400">
            <AlertCircle size={10} />
            <span>Unsaved changes</span>
          </span>
        )}
      </div>
    </div>
  );
};

export default DebugSettings;
