// @ts-nocheck
import React, { useState, useEffect, useRef } from 'react';
import { 
  Clock, 
  Search, 
  Filter, 
  Download, 
  Trash2, 
  AlertCircle,
  AlertTriangle,
  Info,
  CheckCircle,
  XCircle,
  Bug,
  Terminal,
  Copy,
  Eye,
  EyeOff,
  ChevronDown,
  ChevronRight,
  Pause,
  Play,
  SkipBack
} from 'lucide-react';

/**
 * LogViewer Component
 * 
 * Displays application logs with:
 * - Multiple log levels (debug, info, warn, error)
 * - Real-time log streaming
 * - Search and filter capabilities
 * - Export logs
 * - Clear logs
 * - Timestamp formatting
 * - Log grouping
 * - Stack trace viewing
 * 
 * Integrates with:
 * - console.log/warn/error interception
 * - Custom logging service
 * - Error monitoring service
 */
export const LogViewer = () => {
  const [logs, setLogs] = useState([]);
  const [filteredLogs, setFilteredLogs] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [levelFilter, setLevelFilter] = useState('all');
  const [isPaused, setIsPaused] = useState(false);
  const [autoScroll, setAutoScroll] = useState(true);
  const [expandedLogs, setExpandedLogs] = useState(new Set());
  const [showTimestamps, setShowTimestamps] = useState(true);
  const logsEndRef = useRef(null);
  const logsContainerRef = useRef(null);

  // Log levels configuration
  const logLevels = [
    { id: 'all', label: 'All', icon: Terminal, color: 'text-gray-400' },
    { id: 'debug', label: 'Debug', icon: Bug, color: 'text-blue-400' },
    { id: 'info', label: 'Info', icon: Info, color: 'text-green-400' },
    { id: 'warn', label: 'Warn', icon: AlertTriangle, color: 'text-yellow-400' },
    { id: 'error', label: 'Error', icon: XCircle, color: 'text-red-400' }
  ];

  // Intercept console methods
  useEffect(() => {
    const originalConsole = {
      log: console.log,
      info: console.info,
      warn: console.warn,
      error: console.error,
      debug: console.debug
    };

    const createLogEntry = (level, args) => {
      return {
        id: Date.now() + Math.random(),
        timestamp: new Date(),
        level,
        message: args.map(arg => 
          typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg)
        ).join(' '),
        args,
        stack: level === 'error' ? new Error().stack : null
      };
    };

    // Override console methods
    console.log = (...args) => {
      originalConsole.log(...args);
      if (!isPaused) {
        setLogs(prev => [...prev, createLogEntry('info', args)]);
      }
    };

    console.info = (...args) => {
      originalConsole.info(...args);
      if (!isPaused) {
        setLogs(prev => [...prev, createLogEntry('info', args)]);
      }
    };

    console.warn = (...args) => {
      originalConsole.warn(...args);
      if (!isPaused) {
        setLogs(prev => [...prev, createLogEntry('warn', args)]);
      }
    };

    console.error = (...args) => {
      originalConsole.error(...args);
      if (!isPaused) {
        setLogs(prev => [...prev, createLogEntry('error', args)]);
      }
    };

    console.debug = (...args) => {
      originalConsole.debug(...args);
      if (!isPaused) {
        setLogs(prev => [...prev, createLogEntry('debug', args)]);
      }
    };

    // Cleanup: restore original console methods
    return () => {
      console.log = originalConsole.log;
      console.info = originalConsole.info;
      console.warn = originalConsole.warn;
      console.error = originalConsole.error;
      console.debug = originalConsole.debug;
    };
  }, [isPaused]);

  // Filter logs based on search and level
  useEffect(() => {
    let filtered = logs;

    // Filter by level
    if (levelFilter !== 'all') {
      filtered = filtered.filter(log => log.level === levelFilter);
    }

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(log =>
        log.message.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredLogs(filtered);
  }, [logs, searchTerm, levelFilter]);

  // Auto-scroll to bottom
  useEffect(() => {
    if (autoScroll && logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [filteredLogs, autoScroll]);

  // Clear all logs
  const clearLogs = () => {
    setLogs([]);
    setFilteredLogs([]);
    setExpandedLogs(new Set());
  };

  // Export logs as JSON
  const exportLogs = () => {
    const dataStr = JSON.stringify(logs, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `logs-${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Export logs as text
  const exportLogsAsText = () => {
    const text = logs.map(log => 
      `[${log.timestamp.toISOString()}] [${log.level.toUpperCase()}] ${log.message}`
    ).join('\n');
    
    const dataBlob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `logs-${Date.now()}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Copy log to clipboard
  const copyLog = (log) => {
    const text = `[${log.timestamp.toISOString()}] [${log.level.toUpperCase()}] ${log.message}`;
    navigator.clipboard.writeText(text).then(() => {
      console.log('Log copied to clipboard');
    });
  };

  // Toggle log expansion
  const toggleExpand = (logId) => {
    const newExpanded = new Set(expandedLogs);
    if (newExpanded.has(logId)) {
      newExpanded.delete(logId);
    } else {
      newExpanded.add(logId);
    }
    setExpandedLogs(newExpanded);
  };

  // Get icon for log level
  const getLogIcon = (level) => {
    const levelConfig = logLevels.find(l => l.id === level);
    if (!levelConfig) return Info;
    return levelConfig.icon;
  };

  // Get color for log level
  const getLogColor = (level) => {
    const levelConfig = logLevels.find(l => l.id === level);
    if (!levelConfig) return 'text-gray-400';
    return levelConfig.color;
  };

  // Format timestamp
  const formatTimestamp = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    
    if (diff < 1000) return 'just now';
    if (diff < 60000) return `${Math.floor(diff / 1000)}s ago`;
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    
    return timestamp.toLocaleTimeString();
  };

  return (
    <div className="flex flex-col h-full bg-gray-900 text-white">
      {/* Header */}
      <div className="flex items-center justify-between p-3 border-b border-gray-700">
        <div className="flex items-center space-x-2">
          <Clock size={14} className="text-blue-400" />
          <span className="text-sm font-medium">Log Viewer</span>
          <span className="text-xs text-gray-500">({filteredLogs.length} logs)</span>
        </div>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsPaused(!isPaused)}
            className={`p-1 rounded transition-colors ${
              isPaused ? 'bg-yellow-600' : 'hover:bg-gray-700'
            }`}
            title={isPaused ? 'Resume logging' : 'Pause logging'}
          >
            {isPaused ? <Play size={12} /> : <Pause size={12} />}
          </button>
          
          <button
            onClick={clearLogs}
            className="p-1 hover:bg-gray-700 rounded transition-colors"
            title="Clear logs"
          >
            <Trash2 size={12} />
          </button>
          
          <button
            onClick={exportLogsAsText}
            className="p-1 hover:bg-gray-700 rounded transition-colors"
            title="Export as text"
          >
            <Download size={12} />
          </button>
          
          <button
            onClick={() => setShowTimestamps(!showTimestamps)}
            className={`p-1 rounded transition-colors ${
              showTimestamps ? 'bg-blue-600' : 'hover:bg-gray-700'
            }`}
            title="Toggle timestamps"
          >
            <Clock size={12} />
          </button>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center space-x-2 p-2 border-b border-gray-700">
        <div className="flex-1 relative">
          <Search size={12} className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-500" />
          <input
            type="text"
            placeholder="Search logs..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-7 pr-2 py-1 text-xs bg-gray-800 border border-gray-700 rounded focus:outline-none focus:border-blue-500"
          />
        </div>
        
        <select
          value={levelFilter}
          onChange={(e) => setLevelFilter(e.target.value)}
          className="px-2 py-1 text-xs bg-gray-800 border border-gray-700 rounded focus:outline-none focus:border-blue-500"
        >
          {logLevels.map(level => (
            <option key={level.id} value={level.id}>
              {level.label}
            </option>
          ))}
        </select>
        
        <label className="flex items-center space-x-1 text-xs">
          <input
            type="checkbox"
            checked={autoScroll}
            onChange={(e) => setAutoScroll(e.target.checked)}
            className="form-checkbox h-3 w-3 text-blue-500"
          />
          <span>Auto-scroll</span>
        </label>
      </div>

      {/* Logs */}
      <div 
        ref={logsContainerRef}
        className="flex-1 overflow-auto p-2 font-mono text-xs"
      >
        {filteredLogs.length === 0 ? (
          <div className="flex items-center justify-center h-full text-gray-500">
            <div className="text-center">
              <Terminal size={24} className="mx-auto mb-2 opacity-50" />
              <p>No logs to display</p>
              {isPaused && (
                <p className="text-xs mt-1 text-yellow-400">
                  Logging is paused
                </p>
              )}
            </div>
          </div>
        ) : (
          <div className="space-y-1">
            {filteredLogs.map((log) => {
              const Icon = getLogIcon(log.level);
              const isExpanded = expandedLogs.has(log.id);
              const hasStack = log.stack && log.level === 'error';

              return (
                <div
                  key={log.id}
                  className={`p-2 rounded border border-gray-700 hover:bg-gray-800 transition-colors ${
                    log.level === 'error' ? 'bg-red-900 bg-opacity-10' :
                    log.level === 'warn' ? 'bg-yellow-900 bg-opacity-10' :
                    ''
                  }`}
                >
                  <div className="flex items-start space-x-2">
                    {hasStack && (
                      <button
                        onClick={() => toggleExpand(log.id)}
                        className="mt-0.5 text-gray-500 hover:text-white"
                      >
                        {isExpanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
                      </button>
                    )}
                    
                    <Icon size={12} className={`mt-0.5 ${getLogColor(log.level)}`} />
                    
                    {showTimestamps && (
                      <span className="text-gray-500 text-xs">
                        {formatTimestamp(log.timestamp)}
                      </span>
                    )}
                    
                    <span className={`uppercase text-xs font-bold ${getLogColor(log.level)}`}>
                      {log.level}
                    </span>
                    
                    <span className="flex-1 text-gray-300 break-all">
                      {log.message}
                    </span>
                    
                    <button
                      onClick={() => copyLog(log)}
                      className="p-1 hover:bg-gray-600 rounded opacity-0 group-hover:opacity-100"
                      title="Copy log"
                    >
                      <Copy size={10} />
                    </button>
                  </div>

                  {isExpanded && hasStack && (
                    <div className="mt-2 pl-6 text-xs text-gray-400 border-l-2 border-red-500">
                      <pre className="whitespace-pre-wrap">{log.stack}</pre>
                    </div>
                  )}
                </div>
              );
            })}
            <div ref={logsEndRef} />
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between px-3 py-1 text-xs border-t border-gray-700 bg-gray-800">
        <div className="flex items-center space-x-4">
          <span className="text-gray-400">
            Total: {logs.length} | Filtered: {filteredLogs.length}
          </span>
          
          {isPaused && (
            <span className="flex items-center space-x-1 text-yellow-400">
              <Pause size={10} />
              <span>Paused</span>
            </span>
          )}
        </div>
        
        <span className="text-gray-500">
          {new Date().toLocaleTimeString()}
        </span>
      </div>
    </div>
  );
};

export default LogViewer;
