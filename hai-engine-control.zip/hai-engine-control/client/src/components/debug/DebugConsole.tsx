// @ts-nocheck
import React, { useState, useEffect, useRef } from 'react';
import { 
  Terminal, 
  Play, 
  Trash2, 
  Copy, 
  Download, 
  Search,
  Filter,
  ChevronRight,
  AlertCircle,
  Info,
  CheckCircle,
  XCircle
} from 'lucide-react';

const DebugConsole = () => {
  const [logs, setLogs] = useState([]);
  const [command, setCommand] = useState('');
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isAutoScroll, setIsAutoScroll] = useState(true);
  const consoleRef = useRef(null);
  const inputRef = useRef(null);

  // Log levels with colors and icons
  const logLevels = {
    log: { color: 'text-gray-300', bg: 'bg-gray-800', icon: Info },
    info: { color: 'text-blue-400', bg: 'bg-blue-900/20', icon: Info },
    warn: { color: 'text-yellow-400', bg: 'bg-yellow-900/20', icon: AlertCircle },
    error: { color: 'text-red-400', bg: 'bg-red-900/20', icon: XCircle },
    success: { color: 'text-green-400', bg: 'bg-green-900/20', icon: CheckCircle }
  };

  // Intercept console methods
  useEffect(() => {
    const originalConsole = {
      log: console.log,
      info: console.info,
      warn: console.warn,
      error: console.error
    };

    const addLog = (level, args) => {
      const timestamp = new Date().toLocaleTimeString();
      const message = args.map(arg => 
        typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg)
      ).join(' ');

      setLogs(prev => [...prev, {
        id: Date.now() + Math.random(),
        level,
        message,
        timestamp,
        args
      }]);
    };

    // Override console methods
    console.log = (...args) => {
      originalConsole.log(...args);
      addLog('log', args);
    };

    console.info = (...args) => {
      originalConsole.info(...args);
      addLog('info', args);
    };

    console.warn = (...args) => {
      originalConsole.warn(...args);
      addLog('warn', args);
    };

    console.error = (...args) => {
      originalConsole.error(...args);
      addLog('error', args);
    };

    // Add initial welcome message
    addLog('info', ['Debug Console initialized']);

    // Cleanup
    return () => {
      console.log = originalConsole.log;
      console.info = originalConsole.info;
      console.warn = originalConsole.warn;
      console.error = originalConsole.error;
    };
  }, []);

  // Auto-scroll to bottom
  useEffect(() => {
    if (isAutoScroll && consoleRef.current) {
      consoleRef.current.scrollTop = consoleRef.current.scrollHeight;
    }
  }, [logs, isAutoScroll]);

  // Execute command
  const executeCommand = () => {
    if (!command.trim()) return;

    // Add command to logs
    setLogs(prev => [...prev, {
      id: Date.now() + Math.random(),
      level: 'log',
      message: `> ${command}`,
      timestamp: new Date().toLocaleTimeString(),
      isCommand: true
    }]);

    try {
      // Execute the command (using Function constructor instead of eval for build compatibility)
      const result = new Function('return ' + command)();
      
      // Add result to logs
      setLogs(prev => [...prev, {
        id: Date.now() + Math.random() + 1,
        level: 'success',
        message: result !== undefined ? String(result) : 'undefined',
        timestamp: new Date().toLocaleTimeString(),
        isResult: true
      }]);
    } catch (error) {
      // Add error to logs
      setLogs(prev => [...prev, {
        id: Date.now() + Math.random() + 1,
        level: 'error',
        message: error.message,
        timestamp: new Date().toLocaleTimeString(),
        isResult: true
      }]);
    }

    setCommand('');
  };

  // Filter logs
  const filteredLogs = logs.filter(log => {
    const matchesFilter = filter === 'all' || log.level === filter;
    const matchesSearch = !searchTerm || log.message.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  // Clear logs
  const clearLogs = () => {
    setLogs([]);
  };

  // Copy logs to clipboard
  const copyLogs = () => {
    const logText = filteredLogs.map(log => 
      `[${log.timestamp}] ${log.level.toUpperCase()}: ${log.message}`
    ).join('\n');
    
    navigator.clipboard.writeText(logText);
    console.info('Logs copied to clipboard');
  };

  // Download logs
  const downloadLogs = () => {
    const logText = filteredLogs.map(log => 
      `[${log.timestamp}] ${log.level.toUpperCase()}: ${log.message}`
    ).join('\n');
    
    const blob = new Blob([logText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `debug-logs-${new Date().toISOString().slice(0, 19)}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Handle key press
  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      executeCommand();
    }
  };

  return (
    <div className="flex flex-col h-full bg-gray-900">
      {/* Toolbar */}
      <div className="flex items-center justify-between p-2 border-b border-gray-700 bg-gray-800">
        <div className="flex items-center space-x-2">
          <Terminal size={16} className="text-blue-400" />
          <span className="text-sm font-medium">Console</span>
          
          {/* Filter */}
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="bg-gray-700 text-white text-xs px-2 py-1 rounded border border-gray-600"
          >
            <option value="all">All</option>
            <option value="log">Log</option>
            <option value="info">Info</option>
            <option value="warn">Warn</option>
            <option value="error">Error</option>
          </select>
          
          {/* Search */}
          <div className="relative">
            <Search size={12} className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search logs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-gray-700 text-white text-xs pl-6 pr-2 py-1 rounded border border-gray-600 w-32"
            />
          </div>
        </div>
        
        <div className="flex items-center space-x-1">
          <button
            onClick={copyLogs}
            className="p-1 hover:bg-gray-700 rounded transition-colors"
            title="Copy logs"
          >
            <Copy size={12} />
          </button>
          
          <button
            onClick={downloadLogs}
            className="p-1 hover:bg-gray-700 rounded transition-colors"
            title="Download logs"
          >
            <Download size={12} />
          </button>
          
          <button
            onClick={clearLogs}
            className="p-1 hover:bg-gray-700 rounded transition-colors text-red-400"
            title="Clear logs"
          >
            <Trash2 size={12} />
          </button>
        </div>
      </div>

      {/* Console Output */}
      <div 
        ref={consoleRef}
        className="flex-1 overflow-y-auto p-2 font-mono text-xs"
        onScroll={(e) => {
          const { scrollTop, scrollHeight, clientHeight } = e.target;
          setIsAutoScroll(scrollTop + clientHeight >= scrollHeight - 10);
        }}
      >
        {filteredLogs.map((log) => {
          const logConfig = logLevels[log.level] || logLevels.log;
          const Icon = logConfig.icon;
          
          return (
            <div
              key={log.id}
              className={`flex items-start space-x-2 py-1 px-2 rounded mb-1 ${logConfig.bg} ${
                log.isCommand ? 'border-l-2 border-blue-400' : 
                log.isResult ? 'border-l-2 border-green-400' : ''
              }`}
            >
              <div className="flex items-center space-x-1 min-w-0">
                <Icon size={12} className={logConfig.color} />
                <span className="text-gray-500 text-xs">
                  {log.timestamp}
                </span>
              </div>
              
              <div className="flex-1 min-w-0">
                <pre className={`${logConfig.color} whitespace-pre-wrap break-words`}>
                  {log.message}
                </pre>
              </div>
            </div>
          );
        })}
        
        {filteredLogs.length === 0 && (
          <div className="text-gray-500 text-center py-8">
            No logs to display
          </div>
        )}
      </div>

      {/* Command Input */}
      <div className="border-t border-gray-700 bg-gray-800 p-2">
        <div className="flex items-center space-x-2">
          <ChevronRight size={14} className="text-blue-400" />
          <input
            ref={inputRef}
            type="text"
            value={command}
            onChange={(e) => setCommand(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Enter JavaScript command..."
            className="flex-1 bg-gray-700 text-white text-sm px-2 py-1 rounded border border-gray-600 focus:outline-none focus:border-blue-400"
          />
          <button
            onClick={executeCommand}
            disabled={!command.trim()}
            className="p-1 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed rounded transition-colors"
            title="Execute command"
          >
            <Play size={12} />
          </button>
        </div>
        
        <div className="text-xs text-gray-500 mt-1">
          Tip: Use JavaScript expressions. Try: document.title, window.location, or any global variable
        </div>
      </div>
    </div>
  );
};

export { DebugConsole };
export default DebugConsole;
