// @ts-nocheck
import React, { useState, useEffect } from 'react';
import { 
  Network, 
  Globe, 
  Clock, 
  Download, 
  Upload,
  AlertCircle,
  CheckCircle,
  XCircle,
  RefreshCw,
  Search,
  Filter,
  Trash2,
  Eye,
  Code,
  Zap
} from 'lucide-react';

const NetworkMonitor = () => {
  const [requests, setRequests] = useState([]);
  const [filteredRequests, setFilteredRequests] = useState([]);
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [isMonitoring, setIsMonitoring] = useState(true);
  const [stats, setStats] = useState({
    total: 0,
    success: 0,
    error: 0,
    pending: 0,
    avgResponseTime: 0
  });

  // Request status types
  const statusTypes = {
    pending: { color: 'text-yellow-400', bg: 'bg-yellow-900/20', icon: RefreshCw },
    success: { color: 'text-green-400', bg: 'bg-green-900/20', icon: CheckCircle },
    error: { color: 'text-red-400', bg: 'bg-red-900/20', icon: XCircle },
    timeout: { color: 'text-orange-400', bg: 'bg-orange-900/20', icon: Clock }
  };

  // HTTP methods with colors
  const methodColors = {
    GET: 'text-blue-400',
    POST: 'text-green-400',
    PUT: 'text-yellow-400',
    DELETE: 'text-red-400',
    PATCH: 'text-purple-400',
    OPTIONS: 'text-gray-400',
    HEAD: 'text-cyan-400'
  };

  useEffect(() => {
    if (isMonitoring) {
      setupNetworkMonitoring();
    }
  }, [isMonitoring]);

  useEffect(() => {
    filterRequests();
    updateStats();
  }, [requests, filter, searchTerm]);

  const setupNetworkMonitoring = () => {
    // Intercept fetch requests
    const originalFetch = window.fetch;
    window.fetch = async (...args) => {
      const [resource, config = {}] = args;
      const url = typeof resource === 'string' ? resource : resource.url;
      const method = config.method || 'GET';
      
      const requestId = Date.now() + Math.random();
      const startTime = performance.now();
      
      // Add pending request
      const pendingRequest = {
        id: requestId,
        url,
        method,
        status: 'pending',
        startTime,
        endTime: null,
        duration: null,
        size: null,
        headers: config.headers || {},
        body: config.body || null,
        timestamp: new Date()
      };
      
      addRequest(pendingRequest);

      try {
        const response = await originalFetch(...args);
        const endTime = performance.now();
        const duration = Math.round(endTime - startTime);
        
        // Update request with response data
        const completedRequest = {
          ...pendingRequest,
          status: response.ok ? 'success' : 'error',
          statusCode: response.status,
          statusText: response.statusText,
          endTime,
          duration,
          size: response.headers.get('content-length') || null,
          responseHeaders: Object.fromEntries(response.headers.entries())
        };
        
        updateRequest(requestId, completedRequest);
        return response;
      } catch (error) {
        const endTime = performance.now();
        const duration = Math.round(endTime - startTime);
        
        // Update request with error data
        const errorRequest = {
          ...pendingRequest,
          status: 'error',
          error: error.message,
          endTime,
          duration
        };
        
        updateRequest(requestId, errorRequest);
        throw error;
      }
    };

    // Intercept XMLHttpRequest
    const originalXHROpen = XMLHttpRequest.prototype.open;
    const originalXHRSend = XMLHttpRequest.prototype.send;
    
    XMLHttpRequest.prototype.open = function(method, url, ...args) {
      this._debugInfo = {
        method,
        url,
        startTime: null,
        requestId: Date.now() + Math.random()
      };
      return originalXHROpen.call(this, method, url, ...args);
    };
    
    XMLHttpRequest.prototype.send = function(body) {
      if (this._debugInfo) {
        this._debugInfo.startTime = performance.now();
        this._debugInfo.body = body;
        
        // Add pending request
        const pendingRequest = {
          id: this._debugInfo.requestId,
          url: this._debugInfo.url,
          method: this._debugInfo.method,
          status: 'pending',
          startTime: this._debugInfo.startTime,
          endTime: null,
          duration: null,
          size: null,
          headers: {},
          body: body || null,
          timestamp: new Date()
        };
        
        addRequest(pendingRequest);
        
        // Handle response
        this.addEventListener('loadend', () => {
          const endTime = performance.now();
          const duration = Math.round(endTime - this._debugInfo.startTime);
          
          const completedRequest = {
            ...pendingRequest,
            status: this.status >= 200 && this.status < 300 ? 'success' : 'error',
            statusCode: this.status,
            statusText: this.statusText,
            endTime,
            duration,
            size: this.getResponseHeader('content-length') || null,
            responseHeaders: this.getAllResponseHeaders()
          };
          
          updateRequest(this._debugInfo.requestId, completedRequest);
        });
      }
      
      return originalXHRSend.call(this, body);
    };

    // Cleanup function
    return () => {
      window.fetch = originalFetch;
      XMLHttpRequest.prototype.open = originalXHROpen;
      XMLHttpRequest.prototype.send = originalXHRSend;
    };
  };

  const addRequest = (request) => {
    setRequests(prev => [request, ...prev.slice(0, 99)]); // Keep only last 100 requests
  };

  const updateRequest = (requestId, updatedRequest) => {
    setRequests(prev => 
      prev.map(req => req.id === requestId ? updatedRequest : req)
    );
  };

  const filterRequests = () => {
    let filtered = requests;

    if (filter !== 'all') {
      filtered = filtered.filter(request => request.status === filter);
    }

    if (searchTerm) {
      filtered = filtered.filter(request => 
        request.url.toLowerCase().includes(searchTerm.toLowerCase()) ||
        request.method.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredRequests(filtered);
  };

  const updateStats = () => {
    const total = requests.length;
    const success = requests.filter(r => r.status === 'success').length;
    const error = requests.filter(r => r.status === 'error').length;
    const pending = requests.filter(r => r.status === 'pending').length;
    
    const completedRequests = requests.filter(r => r.duration !== null);
    const avgResponseTime = completedRequests.length > 0 
      ? Math.round(completedRequests.reduce((sum, r) => sum + r.duration, 0) / completedRequests.length)
      : 0;

    setStats({ total, success, error, pending, avgResponseTime });
  };

  const clearRequests = () => {
    setRequests([]);
    setSelectedRequest(null);
  };

  const exportRequests = () => {
    const data = {
      timestamp: new Date().toISOString(),
      requests: requests,
      stats: stats
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `network-requests-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const formatDuration = (duration) => {
    if (duration === null) return '-';
    if (duration < 1000) return `${duration}ms`;
    return `${(duration / 1000).toFixed(2)}s`;
  };

  const formatSize = (size) => {
    if (!size) return '-';
    const bytes = parseInt(size);
    if (bytes < 1024) return `${bytes}B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)}KB`;
    return `${(bytes / 1024 / 1024).toFixed(1)}MB`;
  };

  const getStatusIcon = (status) => {
    return statusTypes[status]?.icon || AlertCircle;
  };

  const RequestItem = ({ request, onClick }) => {
    const StatusIcon = getStatusIcon(request.status);
    const statusConfig = statusTypes[request.status] || statusTypes.error;
    
    return (
      <div 
        className="network-request p-3 cursor-pointer hover:bg-debug-panel border-b border-debug-border"
        onClick={() => onClick(request)}
      >
        <div className="flex items-center space-x-3">
          <StatusIcon className={`w-4 h-4 ${statusConfig.color} ${
            request.status === 'pending' ? 'animate-spin' : ''
          }`} />
          <div className="flex-1 min-w-0">
            <div className="flex items-center space-x-2 mb-1">
              <span className={`text-xs font-bold ${methodColors[request.method] || 'text-gray-400'}`}>
                {request.method}
              </span>
              {request.statusCode && (
                <span className={`text-xs ${
                  request.statusCode >= 200 && request.statusCode < 300 
                    ? 'text-green-400' 
                    : 'text-red-400'
                }`}>
                  {request.statusCode}
                </span>
              )}
              <span className="text-xs text-debug-muted">
                {formatDuration(request.duration)}
              </span>
              {request.size && (
                <span className="text-xs text-debug-muted">
                  {formatSize(request.size)}
                </span>
              )}
            </div>
            <p className="text-sm text-debug-text truncate">
              {request.url}
            </p>
            <p className="text-xs text-debug-muted">
              {new Date(request.timestamp).toLocaleTimeString()}
            </p>
          </div>
        </div>
      </div>
    );
  };

  const RequestDetails = ({ request, onClose }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-debug-panel border border-debug-border rounded-lg max-w-4xl max-h-[80vh] w-full mx-4 overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-debug-border">
          <h3 className="font-semibold text-debug-text">Request Details</h3>
          <button onClick={onClose} className="p-1 hover:bg-debug-bg rounded">
            <XCircle className="w-4 h-4" />
          </button>
        </div>
        <div className="p-4 overflow-auto max-h-96">
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-debug-muted">Method</label>
                <p className={`font-bold ${methodColors[request.method] || 'text-gray-400'}`}>
                  {request.method}
                </p>
              </div>
              <div>
                <label className="text-sm font-medium text-debug-muted">Status</label>
                <p className={statusTypes[request.status]?.color || 'text-gray-400'}>
                  {request.statusCode ? `${request.statusCode} ${request.statusText}` : request.status}
                </p>
              </div>
              <div>
                <label className="text-sm font-medium text-debug-muted">Duration</label>
                <p className="text-debug-text">{formatDuration(request.duration)}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-debug-muted">Size</label>
                <p className="text-debug-text">{formatSize(request.size)}</p>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-debug-muted">URL</label>
              <p className="text-debug-text bg-debug-bg p-2 rounded mt-1 break-all">
                {request.url}
              </p>
            </div>
            {request.headers && Object.keys(request.headers).length > 0 && (
              <div>
                <label className="text-sm font-medium text-debug-muted">Request Headers</label>
                <pre className="text-xs text-debug-text bg-debug-bg p-2 rounded mt-1 overflow-auto">
                  {JSON.stringify(request.headers, null, 2)}
                </pre>
              </div>
            )}
            {request.responseHeaders && (
              <div>
                <label className="text-sm font-medium text-debug-muted">Response Headers</label>
                <pre className="text-xs text-debug-text bg-debug-bg p-2 rounded mt-1 overflow-auto">
                  {typeof request.responseHeaders === 'string' 
                    ? request.responseHeaders 
                    : JSON.stringify(request.responseHeaders, null, 2)
                  }
                </pre>
              </div>
            )}
            {request.body && (
              <div>
                <label className="text-sm font-medium text-debug-muted">Request Body</label>
                <pre className="text-xs text-debug-text bg-debug-bg p-2 rounded mt-1 overflow-auto">
                  {typeof request.body === 'string' ? request.body : JSON.stringify(request.body, null, 2)}
                </pre>
              </div>
            )}
            {request.error && (
              <div>
                <label className="text-sm font-medium text-debug-muted">Error</label>
                <p className="text-red-400 bg-debug-bg p-2 rounded mt-1">{request.error}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-full flex flex-col bg-debug-bg text-debug-text">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-debug-border">
        <div className="flex items-center space-x-2">
          <Network className="w-5 h-5 text-debug-accent" />
          <h3 className="font-semibold">Network Monitor</h3>
          <span className="bg-blue-500 text-white text-xs px-2 py-1 rounded-full">
            {requests.length}
          </span>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsMonitoring(!isMonitoring)}
            className={`px-3 py-1 rounded text-xs font-medium ${
              isMonitoring 
                ? 'bg-green-500 text-white' 
                : 'bg-debug-panel text-debug-text border border-debug-border'
            }`}
          >
            {isMonitoring ? 'Monitoring' : 'Paused'}
          </button>
          <button
            onClick={exportRequests}
            className="p-2 hover:bg-debug-panel rounded"
            title="Export Requests"
          >
            <Download className="w-4 h-4" />
          </button>
          <button
            onClick={clearRequests}
            className="p-2 hover:bg-debug-panel rounded"
            title="Clear Requests"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="p-4 border-b border-debug-border">
        <div className="grid grid-cols-5 gap-4 text-center">
          <div>
            <div className="text-lg font-bold text-debug-text">{stats.total}</div>
            <div className="text-xs text-debug-muted">Total</div>
          </div>
          <div>
            <div className="text-lg font-bold text-green-400">{stats.success}</div>
            <div className="text-xs text-debug-muted">Success</div>
          </div>
          <div>
            <div className="text-lg font-bold text-red-400">{stats.error}</div>
            <div className="text-xs text-debug-muted">Error</div>
          </div>
          <div>
            <div className="text-lg font-bold text-yellow-400">{stats.pending}</div>
            <div className="text-xs text-debug-muted">Pending</div>
          </div>
          <div>
            <div className="text-lg font-bold text-debug-text">{stats.avgResponseTime}ms</div>
            <div className="text-xs text-debug-muted">Avg Time</div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="p-4 border-b border-debug-border space-y-3">
        <div className="flex items-center space-x-2">
          <Search className="w-4 h-4 text-debug-muted" />
          <input
            type="text"
            placeholder="Search requests..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1 bg-debug-panel border border-debug-border rounded px-3 py-1 text-sm text-debug-text placeholder-debug-muted focus:outline-none focus:border-debug-accent"
          />
        </div>
        <div className="flex items-center space-x-2">
          <Filter className="w-4 h-4 text-debug-muted" />
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="bg-debug-panel border border-debug-border rounded px-3 py-1 text-sm text-debug-text focus:outline-none focus:border-debug-accent"
          >
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="success">Success</option>
            <option value="error">Error</option>
          </select>
        </div>
      </div>

      {/* Request List */}
      <div className="flex-1 overflow-auto">
        {filteredRequests.length === 0 ? (
          <div className="flex items-center justify-center h-full text-debug-muted">
            <div className="text-center">
              <Globe className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No network requests found</p>
              {!isMonitoring && (
                <p className="text-xs mt-2">Network monitoring is paused</p>
              )}
            </div>
          </div>
        ) : (
          <div>
            {filteredRequests.map((request) => (
              <RequestItem
                key={request.id}
                request={request}
                onClick={setSelectedRequest}
              />
            ))}
          </div>
        )}
      </div>

      {/* Request Details Modal */}
      {selectedRequest && (
        <RequestDetails
          request={selectedRequest}
          onClose={() => setSelectedRequest(null)}
        />
      )}
    </div>
  );
};

export { NetworkMonitor };
