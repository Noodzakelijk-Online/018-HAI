import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { Shield, Copy, Download, AlertCircle, CheckCircle2, Smartphone } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export function TwoFactorSetup() {
  const [isSetupOpen, setIsSetupOpen] = useState(false);
  const [isDisableOpen, setIsDisableOpen] = useState(false);
  const [setupStep, setSetupStep] = useState<'qr' | 'verify' | 'backup'>("qr");
  const [verificationCode, setVerificationCode] = useState("");
  const [disablePassword, setDisablePassword] = useState("");
  const [setupData, setSetupData] = useState<{
    secret: string;
    qrCodeUrl: string;
    manualEntryKey: string;
  } | null>(null);
  const [backupCodes, setBackupCodes] = useState<string[]>([]);

  const utils = trpc.useUtils();
  const { data: status, isLoading } = trpc.authentication.get2FAStatus.useQuery();

  const setup2FAMutation = trpc.authentication.setup2FA.useMutation({
    onSuccess: (data) => {
      setSetupData(data);
      setSetupStep("qr");
      setIsSetupOpen(true);
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const enable2FAMutation = trpc.authentication.enable2FA.useMutation({
    onSuccess: (data) => {
      setBackupCodes(data.backupCodes);
      setSetupStep("backup");
      utils.authentication.get2FAStatus.invalidate();
      toast.success("2FA enabled successfully!");
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const disable2FAMutation = trpc.authentication.disable2FA.useMutation({
    onSuccess: () => {
      setIsDisableOpen(false);
      setDisablePassword("");
      utils.authentication.get2FAStatus.invalidate();
      toast.success("2FA disabled");
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const regenerateCodesMutation = trpc.authentication.regenerateBackupCodes.useMutation({
    onSuccess: (data) => {
      setBackupCodes(data.backupCodes);
      setSetupStep("backup");
      setIsSetupOpen(true);
      toast.success("New backup codes generated");
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const handleStartSetup = () => {
    setup2FAMutation.mutate();
  };

  const handleVerify = () => {
    if (!setupData || !verificationCode) {
      toast.error("Please enter the verification code");
      return;
    }

    if (verificationCode.length !== 6) {
      toast.error("Verification code must be 6 digits");
      return;
    }

    enable2FAMutation.mutate({
      secret: setupData.secret,
      token: verificationCode,
    });
  };

  const handleDisable = () => {
    if (!disablePassword) {
      toast.error("Please enter your password");
      return;
    }

    disable2FAMutation.mutate({
      password: disablePassword,
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard");
  };

  const downloadBackupCodes = () => {
    const text = `HAI Engine Control Center - 2FA Backup Codes\n\nGenerated: ${new Date().toLocaleString()}\n\n${backupCodes.join('\n')}\n\nKeep these codes in a safe place. Each code can only be used once.`;
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `2fa-backup-codes-${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success("Backup codes downloaded");
  };

  const handleSetupComplete = () => {
    setIsSetupOpen(false);
    setSetupStep("qr");
    setVerificationCode("");
    setSetupData(null);
    setBackupCodes([]);
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Two-Factor Authentication</CardTitle>
          <CardDescription>Loading...</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield className="h-6 w-6 text-primary" />
            <div>
              <CardTitle>Two-Factor Authentication (2FA)</CardTitle>
              <CardDescription>
                Add an extra layer of security to your account
              </CardDescription>
            </div>
          </div>
          {status?.enabled ? (
            <Badge className="bg-green-600 gap-1">
              <CheckCircle2 className="h-3 w-3" />
              Enabled
            </Badge>
          ) : (
            <Badge variant="secondary">Disabled</Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {status?.enabled ? (
          <div className="space-y-4">
            <div className="p-4 bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-lg">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5" />
                <div className="flex-1">
                  <p className="font-semibold text-green-900 dark:text-green-100">
                    2FA is Active
                  </p>
                  <p className="text-sm text-green-700 dark:text-green-300 mt-1">
                    Your account is protected with two-factor authentication.
                    You have {status.backupCodesRemaining} backup code{status.backupCodesRemaining !== 1 ? 's' : ''} remaining.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => regenerateCodesMutation.mutate()}
                disabled={regenerateCodesMutation.isPending}
              >
                {regenerateCodesMutation.isPending ? "Generating..." : "Regenerate Backup Codes"}
              </Button>
              <Button
                variant="destructive"
                onClick={() => setIsDisableOpen(true)}
              >
                Disable 2FA
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="p-4 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground">
                Two-factor authentication adds an extra layer of security by requiring a code from your phone in addition to your password.
              </p>
            </div>
            <Button onClick={handleStartSetup} disabled={setup2FAMutation.isPending}>
              <Smartphone className="mr-2 h-4 w-4" />
              {setup2FAMutation.isPending ? "Setting up..." : "Enable 2FA"}
            </Button>
          </div>
        )}

        {/* Setup Dialog */}
        <Dialog open={isSetupOpen} onOpenChange={setIsSetupOpen}>
          <DialogContent className="max-w-md">
            {setupStep === "qr" && setupData && (
              <>
                <DialogHeader>
                  <DialogTitle>Set Up Two-Factor Authentication</DialogTitle>
                  <DialogDescription>
                    Scan this QR code with your authenticator app
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="flex justify-center p-4 bg-white rounded-lg">
                    <img
                      src={setupData.qrCodeUrl}
                      alt="2FA QR Code"
                      className="w-48 h-48"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Or enter this code manually:</Label>
                    <div className="flex gap-2">
                      <Input
                        value={setupData.manualEntryKey}
                        readOnly
                        className="font-mono text-sm"
                      />
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => copyToClipboard(setupData.manualEntryKey)}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="p-3 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg">
                    <p className="text-sm text-blue-900 dark:text-blue-100">
                      <strong>Recommended apps:</strong> Google Authenticator, Authy, Microsoft Authenticator
                    </p>
                  </div>
                </div>
                <DialogFooter>
                  <Button onClick={() => setSetupStep("verify")}>
                    Next
                  </Button>
                </DialogFooter>
              </>
            )}

            {setupStep === "verify" && (
              <>
                <DialogHeader>
                  <DialogTitle>Verify Your Authenticator</DialogTitle>
                  <DialogDescription>
                    Enter the 6-digit code from your authenticator app
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="verify-code">Verification Code</Label>
                    <Input
                      id="verify-code"
                      placeholder="000000"
                      value={verificationCode}
                      onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                      maxLength={6}
                      className="text-center text-2xl font-mono tracking-widest"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button
                    variant="outline"
                    onClick={() => setSetupStep("qr")}
                  >
                    Back
                  </Button>
                  <Button
                    onClick={handleVerify}
                    disabled={enable2FAMutation.isPending || verificationCode.length !== 6}
                  >
                    {enable2FAMutation.isPending ? "Verifying..." : "Verify & Enable"}
                  </Button>
                </DialogFooter>
              </>
            )}

            {setupStep === "backup" && backupCodes.length > 0 && (
              <>
                <DialogHeader>
                  <DialogTitle>Save Your Backup Codes</DialogTitle>
                  <DialogDescription>
                    Store these codes in a safe place. Each can only be used once.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="p-4 bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-800 rounded-lg">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5" />
                      <p className="text-sm text-yellow-900 dark:text-yellow-100">
                        <strong>Important:</strong> Save these codes now. You won't be able to see them again.
                      </p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2 p-4 bg-muted rounded-lg font-mono text-sm">
                    {backupCodes.map((code, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <span className="text-muted-foreground">{index + 1}.</span>
                        <span>{code}</span>
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => copyToClipboard(backupCodes.join('\n'))}
                    >
                      <Copy className="mr-2 h-4 w-4" />
                      Copy
                    </Button>
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={downloadBackupCodes}
                    >
                      <Download className="mr-2 h-4 w-4" />
                      Download
                    </Button>
                  </div>
                </div>
                <DialogFooter>
                  <Button onClick={handleSetupComplete}>
                    Done
                  </Button>
                </DialogFooter>
              </>
            )}
          </DialogContent>
        </Dialog>

        {/* Disable Dialog */}
        <Dialog open={isDisableOpen} onOpenChange={setIsDisableOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Disable Two-Factor Authentication</DialogTitle>
              <DialogDescription>
                Enter your password to confirm
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="p-3 bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-800 rounded-lg">
                <p className="text-sm text-yellow-900 dark:text-yellow-100">
                  <strong>Warning:</strong> Disabling 2FA will make your account less secure.
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="disable-password">Password</Label>
                <Input
                  id="disable-password"
                  type="password"
                  value={disablePassword}
                  onChange={(e) => setDisablePassword(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => {
                  setIsDisableOpen(false);
                  setDisablePassword("");
                }}
              >
                Cancel
              </Button>
              <Button
                variant="destructive"
                onClick={handleDisable}
                disabled={disable2FAMutation.isPending || !disablePassword}
              >
                {disable2FAMutation.isPending ? "Disabling..." : "Disable 2FA"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}
