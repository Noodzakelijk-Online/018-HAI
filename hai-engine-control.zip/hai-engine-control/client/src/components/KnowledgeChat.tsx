/**
 * Knowledge Chat Component
 * 
 * A conversational interface for adding knowledge to HAI's memory.
 * Users can naturally express facts, thoughts, preferences, and observations
 * through chat, and the system will extract and store the knowledge.
 */

import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { 
  Send, 
  Brain, 
  Sparkles, 
  Check, 
  X, 
  Loader2,
  MessageSquare,
  Database,
  Heart,
  Clock,
  Users,
  Calendar,
  Lightbulb,
  HelpCircle,
  RefreshCw
} from "lucide-react";

interface ChatMessage {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: Date;
  extractedKnowledge?: ExtractedKnowledge[];
  pendingConfirmation?: boolean;
}

interface ExtractedKnowledge {
  id: string;
  type: string;
  content: string;
  confidence: number;
  entities?: string[];
  confirmed?: boolean;
  rejected?: boolean;
}

const KNOWLEDGE_TYPE_CONFIG: Record<string, { icon: typeof Brain; color: string; label: string }> = {
  fact: { icon: Database, color: "text-blue-500 bg-blue-500/10", label: "Fact" },
  preference: { icon: Heart, color: "text-pink-500 bg-pink-500/10", label: "Preference" },
  routine: { icon: Clock, color: "text-green-500 bg-green-500/10", label: "Routine" },
  relationship: { icon: Users, color: "text-purple-500 bg-purple-500/10", label: "Relationship" },
  event: { icon: Calendar, color: "text-orange-500 bg-orange-500/10", label: "Event" },
  skill: { icon: Sparkles, color: "text-yellow-500 bg-yellow-500/10", label: "Skill" },
  insight: { icon: Lightbulb, color: "text-indigo-500 bg-indigo-500/10", label: "Insight" },
  observation: { icon: Brain, color: "text-cyan-500 bg-cyan-500/10", label: "Observation" },
};

const SUGGESTED_PROMPTS = [
  "I prefer my coffee black in the morning",
  "My birthday is on March 15th",
  "I work best in the early morning hours",
  "I'm allergic to peanuts",
  "My favorite restaurant is the Italian place downtown",
];

interface KnowledgeChatProps {
  householdId: number;
  onKnowledgeAdded?: () => void;
  className?: string;
  height?: string | number;
}

export function KnowledgeChat({ 
  householdId, 
  onKnowledgeAdded,
  className,
  height = "600px" 
}: KnowledgeChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      role: "assistant",
      content: "Hi! I'm here to help you add knowledge to HAI's memory. Just tell me anything you'd like me to remember - facts about yourself, preferences, routines, relationships, or any observations. I'll extract the key information and ask you to confirm before saving.",
      timestamp: new Date(),
    }
  ]);
  const [input, setInput] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const chatMutation = trpc.knowledgeBase.chat.useMutation({
    onSuccess: (response) => {
      const assistantMessage: ChatMessage = {
        id: `assistant-${Date.now()}`,
        role: "assistant",
        content: response.message,
        timestamp: new Date(),
        extractedKnowledge: response.extractedKnowledge?.map((k: any, i: number) => ({
          id: `knowledge-${Date.now()}-${i}`,
          type: k.type,
          content: k.content,
          confidence: k.confidence,
          entities: k.entities,
        })),
        pendingConfirmation: response.extractedKnowledge && response.extractedKnowledge.length > 0,
      };
      setMessages(prev => [...prev, assistantMessage]);
      setIsProcessing(false);
    },
    onError: (error) => {
      toast.error("Failed to process message: " + error.message);
      setIsProcessing(false);
    }
  });

  const addKnowledgeMutation = trpc.knowledgeBase.add.useMutation({
    onSuccess: () => {
      toast.success("Knowledge saved to memory!");
      onKnowledgeAdded?.();
    },
    onError: (error) => {
      toast.error("Failed to save knowledge: " + error.message);
    }
  });

  // Scroll to bottom when messages change
  useEffect(() => {
    const viewport = scrollAreaRef.current?.querySelector(
      '[data-radix-scroll-area-viewport]'
    ) as HTMLDivElement;
    
    if (viewport) {
      requestAnimationFrame(() => {
        viewport.scrollTo({
          top: viewport.scrollHeight,
          behavior: 'smooth'
        });
      });
    }
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedInput = input.trim();
    if (!trimmedInput || isProcessing) return;

    // Add user message
    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      content: trimmedInput,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsProcessing(true);

    // Send to backend for processing
    chatMutation.mutate({
      message: trimmedInput,
      householdId,
      conversationHistory: messages.slice(-10).map(m => ({
        role: m.role,
        content: m.content,
      })),
    });

    textareaRef.current?.focus();
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleConfirmKnowledge = async (messageId: string, knowledgeId: string) => {
    setMessages(prev => prev.map(msg => {
      if (msg.id === messageId && msg.extractedKnowledge) {
        return {
          ...msg,
          extractedKnowledge: msg.extractedKnowledge.map(k => 
            k.id === knowledgeId ? { ...k, confirmed: true } : k
          ),
        };
      }
      return msg;
    }));

    // Find the knowledge item and save it
    const message = messages.find(m => m.id === messageId);
    const knowledge = message?.extractedKnowledge?.find(k => k.id === knowledgeId);
    
    if (knowledge) {
      await addKnowledgeMutation.mutateAsync({
        householdId,
        type: knowledge.type as any,
        content: knowledge.content,
        source: "chat",
        importance: knowledge.confidence,
        tags: knowledge.entities,
      });
    }
  };

  const handleRejectKnowledge = (messageId: string, knowledgeId: string) => {
    setMessages(prev => prev.map(msg => {
      if (msg.id === messageId && msg.extractedKnowledge) {
        return {
          ...msg,
          extractedKnowledge: msg.extractedKnowledge.map(k => 
            k.id === knowledgeId ? { ...k, rejected: true } : k
          ),
        };
      }
      return msg;
    }));
    toast.info("Knowledge item rejected");
  };

  const handleSuggestedPrompt = (prompt: string) => {
    setInput(prompt);
    textareaRef.current?.focus();
  };

  const getTypeConfig = (type: string) => {
    return KNOWLEDGE_TYPE_CONFIG[type] || KNOWLEDGE_TYPE_CONFIG.fact;
  };

  return (
    <div 
      className={cn(
        "flex flex-col bg-card text-card-foreground rounded-lg border shadow-sm",
        className
      )}
      style={{ height }}
    >
      {/* Header */}
      <div className="flex items-center gap-2 p-4 border-b">
        <MessageSquare className="h-5 w-5 text-primary" />
        <h3 className="font-semibold">Knowledge Chat</h3>
        <Badge variant="secondary" className="ml-auto">
          {messages.filter(m => m.extractedKnowledge?.some(k => k.confirmed)).length} saved
        </Badge>
      </div>

      {/* Messages Area */}
      <ScrollArea ref={scrollAreaRef} className="flex-1">
        <div className="flex flex-col gap-4 p-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={cn(
                "flex gap-3",
                message.role === "user" ? "justify-end" : "justify-start"
              )}
            >
              {message.role === "assistant" && (
                <div className="size-8 shrink-0 rounded-full bg-primary/10 flex items-center justify-center">
                  <Brain className="size-4 text-primary" />
                </div>
              )}
              
              <div className={cn(
                "flex flex-col gap-2 max-w-[80%]",
                message.role === "user" ? "items-end" : "items-start"
              )}>
                <div className={cn(
                  "rounded-lg px-4 py-2",
                  message.role === "user" 
                    ? "bg-primary text-primary-foreground" 
                    : "bg-muted"
                )}>
                  <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                </div>

                {/* Extracted Knowledge Cards */}
                {message.extractedKnowledge && message.extractedKnowledge.length > 0 && (
                  <div className="flex flex-col gap-2 w-full">
                    <p className="text-xs text-muted-foreground">
                      Extracted knowledge ({message.extractedKnowledge.length} items):
                    </p>
                    {message.extractedKnowledge.map((knowledge) => {
                      const config = getTypeConfig(knowledge.type);
                      const Icon = config.icon;
                      
                      return (
                        <Card 
                          key={knowledge.id} 
                          className={cn(
                            "p-3 transition-all",
                            knowledge.confirmed && "border-green-500/50 bg-green-500/5",
                            knowledge.rejected && "border-red-500/50 bg-red-500/5 opacity-50"
                          )}
                        >
                          <div className="flex items-start gap-3">
                            <div className={cn("p-2 rounded-lg", config.color)}>
                              <Icon className="size-4" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                <Badge variant="outline" className="text-xs">
                                  {config.label}
                                </Badge>
                                <span className="text-xs text-muted-foreground">
                                  {Math.round(knowledge.confidence * 100)}% confidence
                                </span>
                              </div>
                              <p className="text-sm">{knowledge.content}</p>
                              {knowledge.entities && knowledge.entities.length > 0 && (
                                <div className="flex flex-wrap gap-1 mt-2">
                                  {knowledge.entities.map((entity, i) => (
                                    <Badge key={i} variant="secondary" className="text-xs">
                                      {entity}
                                    </Badge>
                                  ))}
                                </div>
                              )}
                            </div>
                            
                            {/* Confirmation buttons */}
                            {!knowledge.confirmed && !knowledge.rejected && (
                              <div className="flex gap-1">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-8 w-8 p-0 text-green-500 hover:text-green-600 hover:bg-green-500/10"
                                  onClick={() => handleConfirmKnowledge(message.id, knowledge.id)}
                                  disabled={addKnowledgeMutation.isPending}
                                >
                                  {addKnowledgeMutation.isPending ? (
                                    <Loader2 className="size-4 animate-spin" />
                                  ) : (
                                    <Check className="size-4" />
                                  )}
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-8 w-8 p-0 text-red-500 hover:text-red-600 hover:bg-red-500/10"
                                  onClick={() => handleRejectKnowledge(message.id, knowledge.id)}
                                >
                                  <X className="size-4" />
                                </Button>
                              </div>
                            )}
                            
                            {knowledge.confirmed && (
                              <Badge className="bg-green-500/10 text-green-500 border-green-500/20">
                                <Check className="size-3 mr-1" />
                                Saved
                              </Badge>
                            )}
                            
                            {knowledge.rejected && (
                              <Badge className="bg-red-500/10 text-red-500 border-red-500/20">
                                <X className="size-3 mr-1" />
                                Rejected
                              </Badge>
                            )}
                          </div>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </div>

              {message.role === "user" && (
                <div className="size-8 shrink-0 rounded-full bg-primary flex items-center justify-center">
                  <span className="text-xs font-medium text-primary-foreground">You</span>
                </div>
              )}
            </div>
          ))}

          {/* Loading indicator */}
          {isProcessing && (
            <div className="flex gap-3 justify-start">
              <div className="size-8 shrink-0 rounded-full bg-primary/10 flex items-center justify-center">
                <Brain className="size-4 text-primary" />
              </div>
              <div className="bg-muted rounded-lg px-4 py-2">
                <div className="flex items-center gap-2">
                  <Loader2 className="size-4 animate-spin" />
                  <span className="text-sm text-muted-foreground">Processing...</span>
                </div>
              </div>
            </div>
          )}

          {/* Suggested prompts for empty state */}
          {messages.length === 1 && (
            <div className="flex flex-col gap-2 mt-4">
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <HelpCircle className="size-3" />
                Try saying something like:
              </p>
              <div className="flex flex-wrap gap-2">
                {SUGGESTED_PROMPTS.map((prompt, i) => (
                  <Button
                    key={i}
                    variant="outline"
                    size="sm"
                    className="text-xs h-auto py-1.5 px-3"
                    onClick={() => handleSuggestedPrompt(prompt)}
                  >
                    {prompt}
                  </Button>
                ))}
              </div>
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Input Area */}
      <form onSubmit={handleSubmit} className="p-4 border-t">
        <div className="flex gap-2">
          <Textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Tell me something to remember..."
            className="min-h-[44px] max-h-32 resize-none"
            rows={1}
            disabled={isProcessing}
          />
          <Button 
            type="submit" 
            size="icon"
            disabled={!input.trim() || isProcessing}
          >
            {isProcessing ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <Send className="size-4" />
            )}
          </Button>
        </div>
        <p className="text-xs text-muted-foreground mt-2">
          Press Enter to send, Shift+Enter for new line
        </p>
      </form>
    </div>
  );
}

export default KnowledgeChat;
