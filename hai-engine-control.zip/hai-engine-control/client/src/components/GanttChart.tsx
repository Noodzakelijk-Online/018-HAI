import { useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

interface GanttTask {
  id: string;
  title: string;
  start: Date;
  end: Date;
  progress: number;
  dependencies?: string[];
  assignee?: string;
}

interface GanttChartProps {
  tasks: GanttTask[];
  onTaskClick?: (task: GanttTask) => void;
}

export function GanttChart({ tasks, onTaskClick }: GanttChartProps) {
  const { minDate, maxDate, totalDays } = useMemo(() => {
    if (tasks.length === 0) {
      const now = new Date();
      return {
        minDate: now,
        maxDate: new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000),
        totalDays: 30,
      };
    }

    const dates = tasks.flatMap(t => [t.start, t.end]);
    const min = new Date(Math.min(...dates.map(d => d.getTime())));
    const max = new Date(Math.max(...dates.map(d => d.getTime())));
    const days = Math.ceil((max.getTime() - min.getTime()) / (24 * 60 * 60 * 1000));

    return {
      minDate: min,
      maxDate: max,
      totalDays: Math.max(days, 7),
    };
  }, [tasks]);

  const getTaskPosition = (task: GanttTask) => {
    const startOffset = (task.start.getTime() - minDate.getTime()) / (24 * 60 * 60 * 1000);
    const duration = (task.end.getTime() - task.start.getTime()) / (24 * 60 * 60 * 1000);

    return {
      left: `${(startOffset / totalDays) * 100}%`,
      width: `${Math.max((duration / totalDays) * 100, 2)}%`,
    };
  };

  const generateTimelineMarkers = () => {
    const markers = [];
    const markerCount = Math.min(totalDays, 14); // Show max 14 markers
    const interval = Math.ceil(totalDays / markerCount);

    for (let i = 0; i <= markerCount; i++) {
      const date = new Date(minDate.getTime() + i * interval * 24 * 60 * 60 * 1000);
      markers.push({
        position: (i * interval / totalDays) * 100,
        label: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      });
    }

    return markers;
  };

  const timelineMarkers = generateTimelineMarkers();

  if (tasks.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Gantt Chart</CardTitle>
          <CardDescription>No tasks to display</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Gantt Chart</CardTitle>
        <CardDescription>
          {tasks.length} tasks from {minDate.toLocaleDateString()} to {maxDate.toLocaleDateString()}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Timeline header */}
          <div className="relative h-8 border-b">
            {timelineMarkers.map((marker, idx) => (
              <div
                key={idx}
                className="absolute top-0 text-xs text-muted-foreground"
                style={{ left: `${marker.position}%` }}
              >
                <div className="h-2 w-px bg-border" />
                <span className="ml-1">{marker.label}</span>
              </div>
            ))}
          </div>

          {/* Task rows */}
          <div className="space-y-2">
            {tasks.map((task) => {
              const position = getTaskPosition(task);
              const isOverdue = task.end < new Date() && task.progress < 100;

              return (
                <div key={task.id} className="relative">
                  {/* Task label */}
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-medium truncate max-w-[200px]">
                      {task.title}
                    </span>
                    {task.assignee && (
                      <span className="text-xs text-muted-foreground">
                        ({task.assignee})
                      </span>
                    )}
                  </div>

                  {/* Task bar */}
                  <div className="relative h-8 bg-muted rounded">
                    <div
                      className={`absolute top-0 h-full rounded cursor-pointer transition-all hover:opacity-80 ${
                        isOverdue
                          ? 'bg-destructive'
                          : task.progress === 100
                          ? 'bg-green-500'
                          : 'bg-primary'
                      }`}
                      style={position}
                      onClick={() => onTaskClick?.(task)}
                    >
                      {/* Progress bar */}
                      <div
                        className="h-full bg-white/20 rounded-l"
                        style={{ width: `${task.progress}%` }}
                      />

                      {/* Task info */}
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-xs text-white font-medium px-2 truncate">
                          {task.progress}%
                        </span>
                      </div>
                    </div>

                    {/* Dependency lines (simplified) */}
                    {task.dependencies && task.dependencies.length > 0 && (
                      <div className="absolute -left-2 top-1/2 -translate-y-1/2 w-2 h-px bg-border" />
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Legend */}
          <div className="flex items-center gap-4 pt-4 border-t text-sm">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-primary rounded" />
              <span className="text-muted-foreground">In Progress</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-green-500 rounded" />
              <span className="text-muted-foreground">Completed</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-destructive rounded" />
              <span className="text-muted-foreground">Overdue</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
