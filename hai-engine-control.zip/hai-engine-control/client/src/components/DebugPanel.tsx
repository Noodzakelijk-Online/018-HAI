// @ts-nocheck
import React, { useState, useEffect, useRef } from 'react';
import { 
  Bug, 
  Monitor, 
  Activity, 
  AlertTriangle, 
  Settings, 
  Terminal,
  Eye,
  EyeOff,
  Maximize2,
  Minimize2,
  X,
  RefreshCw,
  Download,
  Upload,
  Trash2,
  Search,
  Filter,
  Clock,
  Zap,
  Database,
  Network,
  Cpu,
  MemoryStick,
  HardDrive
} from 'lucide-react';
import { DebugConsole } from './debug/DebugConsole';
import { PerformanceMonitor } from './debug/PerformanceMonitor';
import { ErrorTracker } from './debug/ErrorTracker';
import { NetworkMonitor } from './debug/NetworkMonitor';
import { StateInspector } from './debug/StateInspector';
import { LogViewer } from './debug/LogViewer';
import { DebugSettings } from './debug/DebugSettings';

const DebugPanel = ({ isVisible, onToggle }) => {
  const [activeTab, setActiveTab] = useState('console');
  const [isExpanded, setIsExpanded] = useState(false);
  const [position, setPosition] = useState({ x: 20, y: 20 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const panelRef = useRef(null);

  // Debug panel tabs configuration
  const tabs = [
    { id: 'console', label: 'Console', icon: Terminal, color: 'text-blue-500' },
    { id: 'performance', label: 'Performance', icon: Activity, color: 'text-green-500' },
    { id: 'errors', label: 'Errors', icon: AlertTriangle, color: 'text-red-500' },
    { id: 'network', label: 'Network', icon: Network, color: 'text-purple-500' },
    { id: 'state', label: 'State', icon: Database, color: 'text-yellow-500' },
    { id: 'logs', label: 'Logs', icon: Clock, color: 'text-indigo-500' },
    { id: 'settings', label: 'Settings', icon: Settings, color: 'text-gray-500' }
  ];

  // Handle dragging
  const handleMouseDown = (e) => {
    if (e.target.closest('.debug-panel-content')) return;
    
    setIsDragging(true);
    const rect = panelRef.current.getBoundingClientRect();
    setDragOffset({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    });
  };

  const handleMouseMove = (e) => {
    if (!isDragging) return;
    
    const newX = e.clientX - dragOffset.x;
    const newY = e.clientY - dragOffset.y;
    
    // Keep panel within viewport bounds
    const maxX = window.innerWidth - (isExpanded ? 800 : 400);
    const maxY = window.innerHeight - (isExpanded ? 600 : 300);
    
    setPosition({
      x: Math.max(0, Math.min(newX, maxX)),
      y: Math.max(0, Math.min(newY, maxY))
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, dragOffset]);

  // Render tab content
  const renderTabContent = () => {
    switch (activeTab) {
      case 'console':
        return <DebugConsole />;
      case 'performance':
        return <PerformanceMonitor />;
      case 'errors':
        return <ErrorTracker />;
      case 'network':
        return <NetworkMonitor />;
      case 'state':
        return <StateInspector />;
      case 'logs':
        return <LogViewer />;
      case 'settings':
        return <DebugSettings />;
      default:
        return <DebugConsole />;
    }
  };

  if (!isVisible) {
    return (
      <button
        onClick={onToggle}
        className="fixed bottom-4 right-4 z-50 bg-gray-900 text-white p-3 rounded-full shadow-lg hover:bg-gray-800 transition-colors"
        title="Open Debug Panel"
      >
        <Bug size={20} />
      </button>
    );
  }

  return (
    <div
      ref={panelRef}
      className={`fixed z-50 bg-gray-900 text-white rounded-lg shadow-2xl transition-all duration-300 ${
        isExpanded ? 'w-[800px] h-[600px]' : 'w-[400px] h-[300px]'
      }`}
      style={{
        left: position.x,
        top: position.y,
        cursor: isDragging ? 'grabbing' : 'grab'
      }}
      onMouseDown={handleMouseDown}
    >
      {/* Header */}
      <div className="flex items-center justify-between p-3 border-b border-gray-700 bg-gray-800 rounded-t-lg">
        <div className="flex items-center space-x-2">
          <Bug size={16} className="text-blue-400" />
          <span className="text-sm font-medium">Debug Panel</span>
        </div>
        
        <div className="flex items-center space-x-1">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 hover:bg-gray-700 rounded transition-colors"
            title={isExpanded ? 'Minimize' : 'Maximize'}
          >
            {isExpanded ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
          </button>
          
          <button
            onClick={onToggle}
            className="p-1 hover:bg-gray-700 rounded transition-colors"
            title="Close Debug Panel"
          >
            <X size={14} />
          </button>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex border-b border-gray-700 bg-gray-800">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-1 px-3 py-2 text-xs transition-colors ${
                activeTab === tab.id
                  ? 'bg-gray-700 text-white border-b-2 border-blue-400'
                  : 'text-gray-400 hover:text-white hover:bg-gray-700'
              }`}
            >
              <Icon size={12} className={activeTab === tab.id ? tab.color : ''} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Content Area */}
      <div className="debug-panel-content flex-1 overflow-hidden">
        {renderTabContent()}
      </div>

      {/* Status Bar */}
      <div className="flex items-center justify-between px-3 py-1 text-xs bg-gray-800 border-t border-gray-700 rounded-b-lg">
        <div className="flex items-center space-x-4">
          <span className="flex items-center space-x-1">
            <div className="w-2 h-2 bg-green-400 rounded-full"></div>
            <span>Connected</span>
          </span>
          
          <span className="text-gray-400">
            {new Date().toLocaleTimeString()}
          </span>
        </div>
        
        <div className="flex items-center space-x-2 text-gray-400">
          <Cpu size={12} />
          <span>Debug Mode</span>
        </div>
      </div>
    </div>
  );
};

export default DebugPanel;
