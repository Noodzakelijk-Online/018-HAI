/**
 * Knowledge Graph Visualization Component
 * 
 * Interactive D3.js force-directed graph for visualizing
 * entities and their relationships in the knowledge base.
 */

import { useEffect, useRef, useState, useCallback } from "react";
import * as d3 from "d3";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { 
  ZoomIn, 
  ZoomOut, 
  Maximize2, 
  RefreshCw, 
  Search,
  Filter,
  X,
  Info
} from "lucide-react";

interface GraphNode {
  id: string;
  label: string;
  type: string;
  size: number;
  metadata?: Record<string, unknown>;
}

interface GraphLink {
  source: string;
  target: string;
  type: string;
  strength: number;
}

interface GraphData {
  nodes: GraphNode[];
  links: GraphLink[];
}

const NODE_COLORS: Record<string, string> = {
  person: "#8b5cf6",      // Purple
  organization: "#3b82f6", // Blue
  place: "#22c55e",       // Green
  event: "#f97316",       // Orange
  concept: "#06b6d4",     // Cyan
  object: "#eab308",      // Yellow
  document: "#ec4899",    // Pink
  service: "#14b8a6",     // Teal
  task: "#f43f5e",        // Rose
  goal: "#a855f7",        // Violet
  skill: "#84cc16",       // Lime
  preference: "#f472b6",  // Pink
  topic: "#6366f1",       // Indigo
  default: "#6b7280",     // Gray
};

const RELATIONSHIP_COLORS: Record<string, string> = {
  related_to: "#94a3b8",
  part_of: "#3b82f6",
  causes: "#f97316",
  depends_on: "#8b5cf6",
  similar_to: "#22c55e",
  opposite_of: "#ef4444",
  precedes: "#06b6d4",
  follows: "#14b8a6",
  default: "#64748b",
};

interface KnowledgeGraphProps {
  householdId: number;
  width?: number;
  height?: number;
  className?: string;
}

export function KnowledgeGraph({ 
  householdId, 
  width = 800, 
  height = 600,
  className 
}: KnowledgeGraphProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState<string>("all");
  const [graphData, setGraphData] = useState<GraphData>({ nodes: [], links: [] });
  const [dimensions, setDimensions] = useState({ width, height });

  // Fetch graph data
  const { data: entities } = trpc.knowledgeBase.getEntities?.useQuery(
    { householdId, limit: 100 },
    { enabled: !!householdId }
  );

  const { data: relationships } = trpc.knowledgeBase.getRelationships?.useQuery(
    { householdId, limit: 200 },
    { enabled: !!householdId }
  );

  // Transform data for D3
  useEffect(() => {
    if (!entities && !relationships) {
      // Generate sample data if no real data
      const sampleNodes: GraphNode[] = [
        { id: "1", label: "User Preferences", type: "concept", size: 30 },
        { id: "2", label: "Morning Routine", type: "concept", size: 25 },
        { id: "3", label: "Coffee", type: "preference", size: 20 },
        { id: "4", label: "Work Schedule", type: "concept", size: 25 },
        { id: "5", label: "Family", type: "person", size: 28 },
        { id: "6", label: "Health Goals", type: "goal", size: 22 },
        { id: "7", label: "Exercise", type: "skill", size: 20 },
        { id: "8", label: "Meetings", type: "event", size: 18 },
      ];

      const sampleLinks: GraphLink[] = [
        { source: "1", target: "3", type: "related_to", strength: 0.8 },
        { source: "2", target: "3", type: "part_of", strength: 0.9 },
        { source: "2", target: "7", type: "part_of", strength: 0.7 },
        { source: "4", target: "8", type: "related_to", strength: 0.8 },
        { source: "5", target: "1", type: "related_to", strength: 0.6 },
        { source: "6", target: "7", type: "depends_on", strength: 0.9 },
        { source: "1", target: "6", type: "related_to", strength: 0.5 },
      ];

      setGraphData({ nodes: sampleNodes, links: sampleLinks });
      return;
    }

    const nodes: GraphNode[] = (entities || []).map((e: any) => ({
      id: e.id.toString(),
      label: e.name || e.label,
      type: e.type || "concept",
      size: Math.min(40, Math.max(15, (e.mentions || 1) * 5)),
      metadata: e.metadata,
    }));

    const links: GraphLink[] = (relationships || []).map((r: any) => ({
      source: r.sourceId.toString(),
      target: r.targetId.toString(),
      type: r.type || "related_to",
      strength: r.strength || 0.5,
    }));

    setGraphData({ nodes, links });
  }, [entities, relationships]);

  // Handle resize
  useEffect(() => {
    const handleResize = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        setDimensions({
          width: rect.width || width,
          height: rect.height || height,
        });
      }
    };

    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [width, height]);

  // D3 Force Simulation
  useEffect(() => {
    if (!svgRef.current || graphData.nodes.length === 0) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const { width: w, height: h } = dimensions;

    // Filter nodes based on search and type
    let filteredNodes = graphData.nodes;
    let filteredLinks = graphData.links;

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filteredNodes = filteredNodes.filter(n => 
        n.label.toLowerCase().includes(query)
      );
      const nodeIds = new Set(filteredNodes.map(n => n.id));
      filteredLinks = filteredLinks.filter(l => 
        nodeIds.has(l.source as string) && nodeIds.has(l.target as string)
      );
    }

    if (filterType !== "all") {
      filteredNodes = filteredNodes.filter(n => n.type === filterType);
      const nodeIds = new Set(filteredNodes.map(n => n.id));
      filteredLinks = filteredLinks.filter(l => 
        nodeIds.has(l.source as string) && nodeIds.has(l.target as string)
      );
    }

    // Create container group for zoom
    const g = svg.append("g");

    // Add zoom behavior
    const zoom = d3.zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.1, 4])
      .on("zoom", (event) => {
        g.attr("transform", event.transform);
      });

    svg.call(zoom);

    // Create force simulation
    const simulation = d3.forceSimulation(filteredNodes as any)
      .force("link", d3.forceLink(filteredLinks)
        .id((d: any) => d.id)
        .distance(100)
        .strength((d: any) => d.strength || 0.5))
      .force("charge", d3.forceManyBody().strength(-300))
      .force("center", d3.forceCenter(w / 2, h / 2))
      .force("collision", d3.forceCollide().radius((d: any) => d.size + 10));

    // Create arrow markers for directed edges
    svg.append("defs").selectAll("marker")
      .data(Object.keys(RELATIONSHIP_COLORS))
      .enter().append("marker")
      .attr("id", d => `arrow-${d}`)
      .attr("viewBox", "0 -5 10 10")
      .attr("refX", 20)
      .attr("refY", 0)
      .attr("markerWidth", 6)
      .attr("markerHeight", 6)
      .attr("orient", "auto")
      .append("path")
      .attr("fill", d => RELATIONSHIP_COLORS[d] || RELATIONSHIP_COLORS.default)
      .attr("d", "M0,-5L10,0L0,5");

    // Create links
    const link = g.append("g")
      .attr("class", "links")
      .selectAll("line")
      .data(filteredLinks)
      .enter().append("line")
      .attr("stroke", d => RELATIONSHIP_COLORS[d.type] || RELATIONSHIP_COLORS.default)
      .attr("stroke-opacity", 0.6)
      .attr("stroke-width", d => Math.max(1, d.strength * 3))
      .attr("marker-end", d => `url(#arrow-${d.type})`);

    // Create link labels
    const linkLabel = g.append("g")
      .attr("class", "link-labels")
      .selectAll("text")
      .data(filteredLinks)
      .enter().append("text")
      .attr("font-size", "10px")
      .attr("fill", "#94a3b8")
      .attr("text-anchor", "middle")
      .text(d => d.type.replace(/_/g, " "));

    // Create node groups
    const node = g.append("g")
      .attr("class", "nodes")
      .selectAll("g")
      .data(filteredNodes)
      .enter().append("g")
      .attr("cursor", "pointer")
      .call(d3.drag<SVGGElement, GraphNode>()
        .on("start", (event, d: any) => {
          if (!event.active) simulation.alphaTarget(0.3).restart();
          d.fx = d.x;
          d.fy = d.y;
        })
        .on("drag", (event, d: any) => {
          d.fx = event.x;
          d.fy = event.y;
        })
        .on("end", (event, d: any) => {
          if (!event.active) simulation.alphaTarget(0);
          d.fx = null;
          d.fy = null;
        }) as any);

    // Add circles to nodes
    node.append("circle")
      .attr("r", d => d.size)
      .attr("fill", d => NODE_COLORS[d.type] || NODE_COLORS.default)
      .attr("stroke", "#fff")
      .attr("stroke-width", 2)
      .on("click", (event, d) => {
        event.stopPropagation();
        setSelectedNode(d);
      })
      .on("mouseover", function() {
        d3.select(this)
          .transition()
          .duration(200)
          .attr("stroke-width", 4);
      })
      .on("mouseout", function() {
        d3.select(this)
          .transition()
          .duration(200)
          .attr("stroke-width", 2);
      });

    // Add labels to nodes
    node.append("text")
      .attr("dy", d => d.size + 15)
      .attr("text-anchor", "middle")
      .attr("font-size", "12px")
      .attr("fill", "#e2e8f0")
      .text(d => d.label.length > 15 ? d.label.substring(0, 15) + "..." : d.label);

    // Add type icons
    node.append("text")
      .attr("dy", 5)
      .attr("text-anchor", "middle")
      .attr("font-size", d => d.size * 0.6)
      .attr("fill", "#fff")
      .text(d => d.type.charAt(0).toUpperCase());

    // Update positions on tick
    simulation.on("tick", () => {
      link
        .attr("x1", (d: any) => d.source.x)
        .attr("y1", (d: any) => d.source.y)
        .attr("x2", (d: any) => d.target.x)
        .attr("y2", (d: any) => d.target.y);

      linkLabel
        .attr("x", (d: any) => (d.source.x + d.target.x) / 2)
        .attr("y", (d: any) => (d.source.y + d.target.y) / 2);

      node.attr("transform", (d: any) => `translate(${d.x},${d.y})`);
    });

    // Click on background to deselect
    svg.on("click", () => setSelectedNode(null));

    return () => {
      simulation.stop();
    };
  }, [graphData, dimensions, searchQuery, filterType]);

  const handleZoomIn = () => {
    if (svgRef.current) {
      const svg = d3.select(svgRef.current);
      svg.transition().call(
        d3.zoom<SVGSVGElement, unknown>().scaleBy as any,
        1.5
      );
    }
  };

  const handleZoomOut = () => {
    if (svgRef.current) {
      const svg = d3.select(svgRef.current);
      svg.transition().call(
        d3.zoom<SVGSVGElement, unknown>().scaleBy as any,
        0.67
      );
    }
  };

  const handleReset = () => {
    if (svgRef.current) {
      const svg = d3.select(svgRef.current);
      svg.transition().call(
        d3.zoom<SVGSVGElement, unknown>().transform as any,
        d3.zoomIdentity
      );
    }
  };

  const uniqueTypes = [...new Set(graphData.nodes.map(n => n.type))];

  return (
    <Card className={className}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            Knowledge Graph
            <Badge variant="secondary">{graphData.nodes.length} entities</Badge>
          </CardTitle>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" onClick={handleZoomIn}>
              <ZoomIn className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={handleZoomOut}>
              <ZoomOut className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={handleReset}>
              <Maximize2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        <div className="flex gap-2 mt-2">
          <div className="relative flex-1">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search entities..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8 h-8"
            />
          </div>
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-32 h-8">
              <Filter className="h-3 w-3 mr-1" />
              <SelectValue placeholder="Filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              {uniqueTypes.map(type => (
                <SelectItem key={type} value={type}>
                  <span className="flex items-center gap-2">
                    <span 
                      className="w-2 h-2 rounded-full" 
                      style={{ backgroundColor: NODE_COLORS[type] || NODE_COLORS.default }}
                    />
                    {type}
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      
      <CardContent className="p-0 relative">
        <div 
          ref={containerRef} 
          className="w-full bg-background/50 rounded-b-lg overflow-hidden"
          style={{ height: height }}
        >
          <svg
            ref={svgRef}
            width="100%"
            height="100%"
            viewBox={`0 0 ${dimensions.width} ${dimensions.height}`}
            preserveAspectRatio="xMidYMid meet"
          />
        </div>

        {/* Legend */}
        <div className="absolute bottom-4 left-4 bg-card/90 backdrop-blur-sm rounded-lg p-3 border shadow-sm">
          <p className="text-xs font-medium mb-2">Entity Types</p>
          <div className="flex flex-wrap gap-2">
            {Object.entries(NODE_COLORS).slice(0, 6).map(([type, color]) => (
              <div key={type} className="flex items-center gap-1">
                <span 
                  className="w-3 h-3 rounded-full" 
                  style={{ backgroundColor: color }}
                />
                <span className="text-xs text-muted-foreground capitalize">{type}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Selected Node Info */}
        {selectedNode && (
          <div className="absolute top-4 right-4 bg-card/90 backdrop-blur-sm rounded-lg p-4 border shadow-lg max-w-xs">
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center gap-2">
                <span 
                  className="w-4 h-4 rounded-full" 
                  style={{ backgroundColor: NODE_COLORS[selectedNode.type] || NODE_COLORS.default }}
                />
                <span className="font-medium">{selectedNode.label}</span>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-6 w-6"
                onClick={() => setSelectedNode(null)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            <Badge variant="outline" className="mb-2 capitalize">{selectedNode.type}</Badge>
            {selectedNode.metadata && (
              <div className="text-xs text-muted-foreground mt-2">
                <p className="flex items-center gap-1">
                  <Info className="h-3 w-3" />
                  {Object.keys(selectedNode.metadata).length} properties
                </p>
              </div>
            )}
          </div>
        )}

        {/* Empty state */}
        {graphData.nodes.length === 0 && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center text-muted-foreground">
              <RefreshCw className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p>No entities to display</p>
              <p className="text-sm">Add knowledge to build the graph</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default KnowledgeGraph;
