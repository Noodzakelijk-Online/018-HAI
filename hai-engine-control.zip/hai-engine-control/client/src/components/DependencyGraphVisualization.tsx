import { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ZoomIn, ZoomOut, Maximize2, RefreshCw } from 'lucide-react';

interface DependencyNode {
  id: string;
  name: string;
  category?: string;
  level?: number;
}

interface DependencyEdge {
  sourceServiceId: string;
  targetServiceId: string;
  triggerType: 'on_success' | 'on_failure' | 'on_complete' | 'scheduled';
  priority: number;
  enabled: boolean;
}

interface Props {
  nodes: DependencyNode[];
  edges: DependencyEdge[];
  onNodeClick?: (nodeId: string) => void;
  onEdgeClick?: (edge: DependencyEdge) => void;
}

interface SimulationNode extends d3.SimulationNodeDatum {
  id: string;
  name: string;
  category?: string;
  level?: number;
}

interface SimulationLink extends d3.SimulationLinkDatum<SimulationNode> {
  triggerType: string;
  priority: number;
  enabled: boolean;
}

const categoryColors: Record<string, string> = {
  Intelligence: '#8b5cf6',
  Integration: '#3b82f6',
  Learning: '#06b6d4',
  Security: '#ef4444',
  Optimization: '#22c55e',
  default: '#6b7280',
};

const triggerTypeColors: Record<string, string> = {
  on_success: '#22c55e',
  on_failure: '#ef4444',
  on_complete: '#3b82f6',
  scheduled: '#f59e0b',
};

export default function DependencyGraphVisualization({ nodes, edges, onNodeClick, onEdgeClick }: Props) {
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);
  const [dimensions, setDimensions] = useState({ width: 800, height: 500 });

  // Update dimensions on resize
  useEffect(() => {
    const updateDimensions = () => {
      if (containerRef.current) {
        const { width, height } = containerRef.current.getBoundingClientRect();
        setDimensions({ width: Math.max(width, 400), height: Math.max(height, 400) });
      }
    };

    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    return () => window.removeEventListener('resize', updateDimensions);
  }, []);

  useEffect(() => {
    if (!svgRef.current || nodes.length === 0) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const { width, height } = dimensions;

    // Create zoom behavior
    const zoom = d3.zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.3, 3])
      .on('zoom', (event) => {
        container.attr('transform', event.transform);
      });

    svg.call(zoom);

    // Create container for zoom/pan
    const container = svg.append('g');

    // Create arrow markers for edges
    const defs = svg.append('defs');
    
    Object.entries(triggerTypeColors).forEach(([type, color]) => {
      defs.append('marker')
        .attr('id', `arrow-${type}`)
        .attr('viewBox', '0 -5 10 10')
        .attr('refX', 25)
        .attr('refY', 0)
        .attr('markerWidth', 6)
        .attr('markerHeight', 6)
        .attr('orient', 'auto')
        .append('path')
        .attr('fill', color)
        .attr('d', 'M0,-5L10,0L0,5');
    });

    // Prepare data for simulation
    const simulationNodes: SimulationNode[] = nodes.map(n => ({
      id: n.id,
      name: n.name || n.id,
      category: n.category,
      level: n.level,
    }));

    const nodeMap = new Map(simulationNodes.map(n => [n.id, n]));

    const simulationLinks: SimulationLink[] = edges
      .filter(e => nodeMap.has(e.sourceServiceId) && nodeMap.has(e.targetServiceId))
      .map(e => ({
        source: e.sourceServiceId,
        target: e.targetServiceId,
        triggerType: e.triggerType,
        priority: e.priority,
        enabled: e.enabled,
      }));

    // Create force simulation
    const simulation = d3.forceSimulation<SimulationNode>(simulationNodes)
      .force('link', d3.forceLink<SimulationNode, SimulationLink>(simulationLinks)
        .id(d => d.id)
        .distance(120))
      .force('charge', d3.forceManyBody().strength(-400))
      .force('center', d3.forceCenter(width / 2, height / 2))
      .force('collision', d3.forceCollide().radius(40));

    // Create links (edges)
    const link = container.append('g')
      .attr('class', 'links')
      .selectAll('path')
      .data(simulationLinks)
      .join('path')
      .attr('stroke', d => triggerTypeColors[d.triggerType] || '#999')
      .attr('stroke-width', d => d.enabled ? 2 : 1)
      .attr('stroke-opacity', d => d.enabled ? 0.8 : 0.3)
      .attr('stroke-dasharray', d => d.enabled ? 'none' : '5,5')
      .attr('fill', 'none')
      .attr('marker-end', d => `url(#arrow-${d.triggerType})`)
      .style('cursor', 'pointer')
      .on('click', (event, d) => {
        event.stopPropagation();
        if (onEdgeClick) {
          const edge = edges.find(e => 
            e.sourceServiceId === (typeof d.source === 'object' ? d.source.id : d.source) &&
            e.targetServiceId === (typeof d.target === 'object' ? d.target.id : d.target)
          );
          if (edge) onEdgeClick(edge);
        }
      });

    // Create node groups
    const node = container.append('g')
      .attr('class', 'nodes')
      .selectAll('g')
      .data(simulationNodes)
      .join('g')
      .style('cursor', 'pointer')
      .call(d3.drag<SVGGElement, SimulationNode>()
        .on('start', (event, d) => {
          if (!event.active) simulation.alphaTarget(0.3).restart();
          d.fx = d.x;
          d.fy = d.y;
        })
        .on('drag', (event, d) => {
          d.fx = event.x;
          d.fy = event.y;
        })
        .on('end', (event, d) => {
          if (!event.active) simulation.alphaTarget(0);
          d.fx = null;
          d.fy = null;
        }));

    // Add circles to nodes
    node.append('circle')
      .attr('r', 20)
      .attr('fill', d => categoryColors[d.category || 'default'] || categoryColors.default)
      .attr('stroke', '#fff')
      .attr('stroke-width', 2)
      .on('mouseover', function(event, d) {
        d3.select(this).attr('r', 25);
        setHoveredNode(d.id);
      })
      .on('mouseout', function(event, d) {
        d3.select(this).attr('r', 20);
        setHoveredNode(null);
      })
      .on('click', (event, d) => {
        event.stopPropagation();
        setSelectedNode(d.id);
        if (onNodeClick) onNodeClick(d.id);
      });

    // Add labels to nodes
    node.append('text')
      .text(d => {
        const name = d.name || d.id;
        return name.length > 15 ? name.substring(0, 12) + '...' : name;
      })
      .attr('text-anchor', 'middle')
      .attr('dy', 35)
      .attr('font-size', '10px')
      .attr('fill', 'currentColor')
      .attr('pointer-events', 'none');

    // Add icons/initials to nodes
    node.append('text')
      .text(d => {
        const name = d.name || d.id;
        return name.split('-').map(w => w[0]?.toUpperCase() || '').join('').substring(0, 2);
      })
      .attr('text-anchor', 'middle')
      .attr('dy', 5)
      .attr('font-size', '12px')
      .attr('font-weight', 'bold')
      .attr('fill', '#fff')
      .attr('pointer-events', 'none');

    // Update positions on tick
    simulation.on('tick', () => {
      link.attr('d', d => {
        const sourceNode = typeof d.source === 'object' ? d.source : nodeMap.get(d.source as string);
        const targetNode = typeof d.target === 'object' ? d.target : nodeMap.get(d.target as string);
        if (!sourceNode || !targetNode) return '';
        
        const dx = (targetNode.x || 0) - (sourceNode.x || 0);
        const dy = (targetNode.y || 0) - (sourceNode.y || 0);
        const dr = Math.sqrt(dx * dx + dy * dy) * 1.5;
        
        return `M${sourceNode.x},${sourceNode.y}A${dr},${dr} 0 0,1 ${targetNode.x},${targetNode.y}`;
      });

      node.attr('transform', d => `translate(${d.x || 0},${d.y || 0})`);
    });

    // Click on background to deselect
    svg.on('click', () => {
      setSelectedNode(null);
    });

    // Cleanup
    return () => {
      simulation.stop();
    };
  }, [nodes, edges, dimensions, onNodeClick, onEdgeClick]);

  const handleZoomIn = () => {
    if (svgRef.current) {
      const svg = d3.select(svgRef.current);
      svg.transition().duration(300).call(
        d3.zoom<SVGSVGElement, unknown>().scaleBy as any,
        1.3
      );
    }
  };

  const handleZoomOut = () => {
    if (svgRef.current) {
      const svg = d3.select(svgRef.current);
      svg.transition().duration(300).call(
        d3.zoom<SVGSVGElement, unknown>().scaleBy as any,
        0.7
      );
    }
  };

  const handleReset = () => {
    if (svgRef.current) {
      const svg = d3.select(svgRef.current);
      svg.transition().duration(500).call(
        d3.zoom<SVGSVGElement, unknown>().transform as any,
        d3.zoomIdentity
      );
    }
  };

  return (
    <Card className="h-full">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Service Dependency Graph</CardTitle>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" onClick={handleZoomOut}>
              <ZoomOut className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={handleZoomIn}>
              <ZoomIn className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={handleReset}>
              <Maximize2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        {/* Legend */}
        <div className="flex flex-wrap gap-4 mt-2 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-muted-foreground">Trigger:</span>
            {Object.entries(triggerTypeColors).map(([type, color]) => (
              <div key={type} className="flex items-center gap-1">
                <div className="w-3 h-0.5" style={{ backgroundColor: color }} />
                <span>{type.replace('on_', '')}</span>
              </div>
            ))}
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div ref={containerRef} className="w-full h-[500px] relative">
          <svg
            ref={svgRef}
            width={dimensions.width}
            height={dimensions.height}
            className="w-full h-full"
          />
          
          {/* Tooltip for hovered node */}
          {hoveredNode && (
            <div className="absolute top-2 left-2 bg-card border rounded-lg p-2 shadow-lg text-sm">
              <p className="font-medium">{hoveredNode}</p>
              <p className="text-muted-foreground text-xs">Click to select, drag to move</p>
            </div>
          )}
          
          {/* Selected node info */}
          {selectedNode && (
            <div className="absolute bottom-2 left-2 bg-card border rounded-lg p-3 shadow-lg max-w-xs">
              <p className="font-medium mb-1">{selectedNode}</p>
              <div className="text-xs text-muted-foreground">
                <p>Dependencies: {edges.filter(e => e.targetServiceId === selectedNode).length}</p>
                <p>Dependents: {edges.filter(e => e.sourceServiceId === selectedNode).length}</p>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
