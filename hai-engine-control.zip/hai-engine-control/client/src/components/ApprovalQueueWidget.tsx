import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  CheckCircle2, 
  XCircle, 
  Mail, 
  Calendar, 
  Brain,
  Clock,
  AlertCircle
} from "lucide-react";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface ApprovalItem {
  id: number;
  type: string;
  title: string;
  description: string | null;
  metadata: any;
  suggestedAction: string | null;
  reasoning: string | null;
  confidence: number | null;
  status: string;
  priority: string;
  householdId: number;
  createdBy: number | null;
  reviewedBy: number | null;
  createdAt: Date;
  reviewedAt: Date | null;
  expiresAt: Date | null;
}

const getItemIcon = (type: string) => {
  switch (type) {
    case "email_response":
      return <Mail className="h-5 w-5" />;
    case "calendar_event":
      return <Calendar className="h-5 w-5" />;
    case "decision":
    case "task_execution":
      return <Brain className="h-5 w-5" />;
    default:
      return <AlertCircle className="h-5 w-5" />;
  }
};

const getPriorityColor = (priority: string) => {
  switch (priority) {
    case "urgent":
    case "high":
      return "destructive";
    case "medium":
      return "default";
    case "low":
    default:
      return "secondary";
  }
};

const getPriorityLabel = (priority: string) => {
  return priority.charAt(0).toUpperCase() + priority.slice(1);
};

interface ApprovalQueueWidgetProps {
  householdId?: number;
}

export default function ApprovalQueueWidget({ householdId }: ApprovalQueueWidgetProps) {
  const [selectedItem, setSelectedItem] = useState<ApprovalItem | null>(null);
  const [actionType, setActionType] = useState<"approve" | "reject" | null>(null);
  const [rejectionReason, setRejectionReason] = useState("");

  const utils = trpc.useUtils();
  const { data: pendingItems = [], isLoading } = trpc.approvalQueue.getPending.useQuery(
    { householdId: householdId || 0 },
    { enabled: !!householdId }
  );

  const approveMutation = trpc.approvalQueue.approve.useMutation({
    onSuccess: () => {
      toast.success("Item approved successfully");
      utils.approvalQueue.getPending.invalidate();
      setSelectedItem(null);
      setActionType(null);
    },
    onError: (error) => {
      toast.error(`Failed to approve: ${error.message}`);
    },
  });

  const rejectMutation = trpc.approvalQueue.reject.useMutation({
    onSuccess: () => {
      toast.success("Item rejected");
      utils.approvalQueue.getPending.invalidate();
      setSelectedItem(null);
      setActionType(null);
      setRejectionReason("");
    },
    onError: (error) => {
      toast.error(`Failed to reject: ${error.message}`);
    },
  });

  const handleApprove = (item: ApprovalItem) => {
    setSelectedItem(item);
    setActionType("approve");
  };

  const handleReject = (item: ApprovalItem) => {
    setSelectedItem(item);
    setActionType("reject");
  };

  const confirmApprove = () => {
    if (selectedItem) {
      approveMutation.mutate({ id: selectedItem.id });
    }
  };

  const confirmReject = () => {
    if (selectedItem) {
      rejectMutation.mutate({ 
        id: selectedItem.id
      });
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Pending Approvals</CardTitle>
          <CardDescription>Loading...</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  if (pendingItems.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Pending Approvals</CardTitle>
          <CardDescription>No pending approvals</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <CheckCircle2 className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-sm text-muted-foreground">
              All caught up! HAI will notify you when decisions need your approval.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Pending Approvals</CardTitle>
          <CardDescription>
            {pendingItems.length} {pendingItems.length === 1 ? "item" : "items"} awaiting your review
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {pendingItems.map((item) => (
              <Card key={item.id} className="border-l-4 border-l-primary">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 mt-1">
                      {getItemIcon(item.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="font-semibold text-sm">{item.title}</h4>
                        <Badge variant={getPriorityColor(item.priority)}>
                          {getPriorityLabel(item.priority)}
                        </Badge>
                        <Badge variant="outline" className="capitalize">
                          {item.type.replace("_", " ")}
                        </Badge>
                      </div>
                      {item.description && (
                        <p className="text-sm text-muted-foreground mb-3">
                          {item.description}
                        </p>
                      )}
                      {item.expiresAt && (
                        <div className="flex items-center gap-1 text-xs text-muted-foreground mb-3">
                          <Clock className="h-3 w-3" />
                          <span>
                            Expires: {new Date(item.expiresAt).toLocaleString()}
                          </span>
                        </div>
                      )}
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleApprove(item)}
                          disabled={approveMutation.isPending || rejectMutation.isPending}
                        >
                          <CheckCircle2 className="h-4 w-4 mr-1" />
                          Approve
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleReject(item)}
                          disabled={approveMutation.isPending || rejectMutation.isPending}
                        >
                          <XCircle className="h-4 w-4 mr-1" />
                          Reject
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Approve Confirmation Dialog */}
      <AlertDialog open={actionType === "approve"} onOpenChange={(open) => !open && setActionType(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Approve this action?</AlertDialogTitle>
            <AlertDialogDescription>
              {selectedItem && (
                <>
                  <p className="font-semibold mb-2">{selectedItem.title}</p>
                  <p>{selectedItem.description}</p>
                  <p className="mt-4 text-sm">
                    HAI will execute this action immediately after approval.
                  </p>
                </>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmApprove}>
              Approve
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Reject Confirmation Dialog */}
      <AlertDialog open={actionType === "reject"} onOpenChange={(open) => !open && setActionType(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Reject this action?</AlertDialogTitle>
            <AlertDialogDescription>
              {selectedItem && (
                <>
                  <p className="font-semibold mb-2">{selectedItem.title}</p>
                  <p className="mb-4">{selectedItem.description}</p>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">
                      Reason for rejection (optional):
                    </label>
                    <textarea
                      className="w-full min-h-[80px] px-3 py-2 text-sm border rounded-md"
                      placeholder="Help HAI learn by explaining why you rejected this..."
                      value={rejectionReason}
                      onChange={(e) => setRejectionReason(e.target.value)}
                    />
                  </div>
                </>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmReject} className="bg-destructive text-destructive-foreground">
              Reject
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
