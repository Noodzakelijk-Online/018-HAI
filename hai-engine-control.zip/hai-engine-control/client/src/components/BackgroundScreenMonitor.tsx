import { useEffect, useRef } from "react";
import { io, Socket } from "socket.io-client";

/**
 * Background Screen Monitor
 * 
 * Runs silently in the background to:
 * - Receive screen streams from Desktop Agent
 * - Process OCR data in real-time
 * - Feed screen context to HAI's thinking engine
 * 
 * No UI - this is purely a background service.
 */
export function BackgroundScreenMonitor() {
  const socketRef = useRef<Socket | null>(null);
  const isConnectedRef = useRef(false);

  useEffect(() => {
    // Initialize WebSocket connection to screen stream service
    const socket = io({
      path: "/api/socket.io",
      transports: ["websocket", "polling"],
    });

    socketRef.current = socket;

    socket.on("connect", () => {
      console.log("[BackgroundScreenMonitor] Connected to screen stream service");
      isConnectedRef.current = true;
      
      // Subscribe to PC screen stream
      socket.emit("subscribe", { stream: "pc-screen" });
      
      // Subscribe to phone screen stream
      socket.emit("subscribe", { stream: "phone-screen" });
      
      // Subscribe to OCR data
      socket.emit("subscribe", { stream: "ocr-data" });
    });

    socket.on("disconnect", () => {
      console.log("[BackgroundScreenMonitor] Disconnected from screen stream service");
      isConnectedRef.current = false;
    });

    // Handle PC screen frames (we don't render them, just log for debugging)
    socket.on("pc-screen-frame", (data: { image: string; timestamp: number }) => {
      // Screen frame received - could be sent to HAI for analysis
      // For now, just log to confirm it's working
      console.log("[BackgroundScreenMonitor] PC screen frame received", {
        timestamp: data.timestamp,
        imageSize: data.image.length,
      });
    });

    // Handle phone screen frames
    socket.on("phone-screen-frame", (data: { image: string; timestamp: number }) => {
      console.log("[BackgroundScreenMonitor] Phone screen frame received", {
        timestamp: data.timestamp,
        imageSize: data.image.length,
      });
    });

    // Handle OCR data - this is the important one for HAI's context
    socket.on("ocr-data", (data: {
      text: string;
      confidence: number;
      source: "pc" | "phone";
      timestamp: number;
    }) => {
      console.log("[BackgroundScreenMonitor] OCR data received", {
        source: data.source,
        textLength: data.text.length,
        confidence: data.confidence,
        preview: data.text.substring(0, 100),
      });
      
      // TODO: Send OCR data to ThinkingEngine for context awareness
      // This would call: trpc.thinking.updateScreenContext.mutate({ text: data.text, source: data.source })
    });

    // Handle errors
    socket.on("error", (error: Error) => {
      console.error("[BackgroundScreenMonitor] Socket error:", error);
    });

    // Cleanup on unmount
    return () => {
      if (socketRef.current) {
        socketRef.current.disconnect();
        socketRef.current = null;
      }
    };
  }, []);

  // This component renders nothing - it's purely a background service
  return null;
}
