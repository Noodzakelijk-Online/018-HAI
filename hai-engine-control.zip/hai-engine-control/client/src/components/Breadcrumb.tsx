import { ChevronRight, Home } from "lucide-react";
import { Link, useLocation } from "wouter";

export interface BreadcrumbItem {
  label: string;
  href?: string;
}

interface BreadcrumbProps {
  items?: BreadcrumbItem[];
}

/**
 * Breadcrumb navigation component
 * Automatically generates breadcrumbs from URL path if items not provided
 */
export function Breadcrumb({ items }: BreadcrumbProps) {
  const [location] = useLocation();

  // Auto-generate breadcrumbs from path if not provided
  const breadcrumbs = items || generateBreadcrumbsFromPath(location);

  return (
    <nav className="flex items-center space-x-1 text-sm text-muted-foreground mb-4">
      <Link href="/" className="flex items-center hover:text-foreground transition-colors">
        <Home className="h-4 w-4" />
      </Link>
      
      {breadcrumbs.map((item, index) => (
        <div key={index} className="flex items-center space-x-1">
          <ChevronRight className="h-4 w-4" />
          {item.href && index < breadcrumbs.length - 1 ? (
            <Link href={item.href} className="hover:text-foreground transition-colors">
              {item.label}
            </Link>
          ) : (
            <span className="text-foreground font-medium">{item.label}</span>
          )}
        </div>
      ))}
    </nav>
  );
}

/**
 * Generate breadcrumbs from URL path
 */
function generateBreadcrumbsFromPath(path: string): BreadcrumbItem[] {
  if (path === '/') return [];

  const segments = path.split('/').filter(Boolean);
  const breadcrumbs: BreadcrumbItem[] = [];

  let currentPath = '';
  segments.forEach((segment, index) => {
    currentPath += `/${segment}`;
    
    // Convert kebab-case to Title Case
    const label = segment
      .split('-')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');

    breadcrumbs.push({
      label,
      href: index < segments.length - 1 ? currentPath : undefined,
    });
  });

  return breadcrumbs;
}

/**
 * Common breadcrumb configurations for different pages
 */
export const breadcrumbConfigs: Record<string, BreadcrumbItem[]> = {
  '/engines': [{ label: 'Engines' }],
  '/tasks': [{ label: 'Tasks' }],
  '/chat': [{ label: 'Chat' }],
  '/profile': [{ label: 'Profile' }],
  '/decisions': [{ label: 'Decisions' }],
  '/approvals': [{ label: 'Approvals' }],
  '/needs': [{ label: 'Needs' }],
  '/policies': [{ label: 'Policies' }],
  '/events': [{ label: 'Events' }],
  '/ledger': [{ label: 'Ledger' }],
  '/frontier': [{ label: 'Frontier' }],
  '/knowledge-graph': [{ label: 'Knowledge Graph' }],
  '/playbooks': [{ label: 'Playbooks' }],
  '/communication': [{ label: 'Communication' }],
  '/connectors': [{ label: 'Connectors' }],
  '/services': [{ label: 'Services' }],
};
