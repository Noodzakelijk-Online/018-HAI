/**
 * Knowledge Graph Explorer
 * 
 * Interactive visualization of knowledge entities and relationships using React Flow
 */

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { Plus, Search, ZoomIn, ZoomOut } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import {
  ReactFlow,
  Background,
  Controls,
  type Edge,
  MarkerType,
  type Node,
  addEdge,
  useEdgesState,
  useNodesState,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";

export default function KnowledgeGraphExplorer() {
  const [searchTerm, setSearchTerm] = useState("");
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);

  // Fetch entities and relationships
  const { data: entities } = trpc.level5.knowledge.getAllEntities.useQuery();
  const { data: relationships } = trpc.level5.knowledge.getAllRelationships.useQuery();

  // Convert entities and relationships to React Flow format
  useEffect(() => {
    if (!entities || !relationships) return;

    // Filter entities by search term
    const filteredEntities = searchTerm
      ? entities.filter(e =>
          e.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          e.type.toLowerCase().includes(searchTerm.toLowerCase())
        )
      : entities;

    // Create nodes from entities
    const newNodes: Node[] = filteredEntities.map((entity, index) => ({
      id: entity.id.toString(),
      type: "default",
      position: {
        x: (index % 5) * 250,
        y: Math.floor(index / 5) * 150,
      },
      data: {
        label: (
          <div className="text-center">
            <div className="font-bold">{entity.name}</div>
            <div className="text-xs text-muted-foreground">{entity.type}</div>
          </div>
        ),
      },
      style: {
        background: getNodeColor(entity.type),
        color: "#fff",
        border: "2px solid #222",
        borderRadius: "8px",
        padding: "10px",
        minWidth: "150px",
      },
    }));

    // Create edges from relationships
    const entityIds = new Set(filteredEntities.map(e => e.id.toString()));
    const newEdges: Edge[] = relationships
      .filter(rel =>
        entityIds.has(rel.sourceId.toString()) &&
        entityIds.has(rel.targetId.toString())
      )
      .map(rel => ({
        id: rel.id.toString(),
        source: rel.sourceId.toString(),
        target: rel.targetId.toString(),
        label: rel.type,
        type: "smoothstep",
        animated: true,
        markerEnd: {
          type: MarkerType.ArrowClosed,
        },
        style: {
          stroke: "#888",
        },
      }));

    setNodes(newNodes);
    setEdges(newEdges);
  }, [entities, relationships, searchTerm, setNodes, setEdges]);

  const onConnect = useCallback(
    (params: any) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="flex items-center gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search entities..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Add Entity
        </Button>
      </div>

      {/* Graph Visualization */}
      <Card>
        <CardHeader>
          <CardTitle>Knowledge Graph</CardTitle>
          <CardDescription>
            {entities?.length || 0} entities, {relationships?.length || 0} relationships
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[600px] border rounded-lg bg-background">
            <ReactFlow
              nodes={nodes}
              edges={edges}
              onNodesChange={onNodesChange}
              onEdgesChange={onEdgesChange}
              onConnect={onConnect}
              fitView
            >
              <Background />
              <Controls />
            </ReactFlow>
          </div>
        </CardContent>
      </Card>

      {/* Legend */}
      <Card>
        <CardHeader>
          <CardTitle>Entity Types</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {["person", "concept", "event", "location", "organization", "other"].map(type => (
              <div key={type} className="flex items-center gap-2">
                <div
                  className="w-4 h-4 rounded"
                  style={{ background: getNodeColor(type) }}
                />
                <span className="text-sm capitalize">{type}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Helper function to get node color based on entity type
function getNodeColor(type: string): string {
  const colors: Record<string, string> = {
    person: "#3b82f6",      // blue
    concept: "#8b5cf6",     // purple
    event: "#f59e0b",       // amber
    location: "#10b981",    // green
    organization: "#ef4444", // red
    other: "#6b7280",       // gray
  };
  return colors[type.toLowerCase()] || colors.other;
}
