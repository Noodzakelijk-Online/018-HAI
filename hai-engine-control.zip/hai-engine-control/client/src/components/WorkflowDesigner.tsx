import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Play,
  Square,
  GitBranch,
  Repeat,
  Mail,
  MessageSquare,
  Database,
  Plus,
  Trash2,
  Settings,
} from 'lucide-react';

export type WorkflowNodeType =
  | 'start'
  | 'end'
  | 'action'
  | 'condition'
  | 'loop'
  | 'email'
  | 'notification'
  | 'database';

export interface WorkflowNode {
  id: string;
  type: WorkflowNodeType;
  label: string;
  config?: Record<string, any>;
  position: { x: number; y: number };
}

export interface WorkflowConnection {
  id: string;
  from: string;
  to: string;
  label?: string;
}

interface WorkflowDesignerProps {
  nodes: WorkflowNode[];
  connections: WorkflowConnection[];
  onNodesChange?: (nodes: WorkflowNode[]) => void;
  onConnectionsChange?: (connections: WorkflowConnection[]) => void;
  onNodeClick?: (node: WorkflowNode) => void;
  onAddNode?: (type: WorkflowNodeType) => void;
  readOnly?: boolean;
}

const nodeIcons: Record<WorkflowNodeType, React.ReactNode> = {
  start: <Play className="h-4 w-4" />,
  end: <Square className="h-4 w-4" />,
  action: <Settings className="h-4 w-4" />,
  condition: <GitBranch className="h-4 w-4" />,
  loop: <Repeat className="h-4 w-4" />,
  email: <Mail className="h-4 w-4" />,
  notification: <MessageSquare className="h-4 w-4" />,
  database: <Database className="h-4 w-4" />,
};

const nodeColors: Record<WorkflowNodeType, string> = {
  start: 'bg-green-500 hover:bg-green-600',
  end: 'bg-red-500 hover:bg-red-600',
  action: 'bg-blue-500 hover:bg-blue-600',
  condition: 'bg-yellow-500 hover:bg-yellow-600',
  loop: 'bg-purple-500 hover:bg-purple-600',
  email: 'bg-pink-500 hover:bg-pink-600',
  notification: 'bg-indigo-500 hover:bg-indigo-600',
  database: 'bg-orange-500 hover:bg-orange-600',
};

const nodeTypes: { type: WorkflowNodeType; label: string }[] = [
  { type: 'action', label: 'Action' },
  { type: 'condition', label: 'Condition' },
  { type: 'loop', label: 'Loop' },
  { type: 'email', label: 'Email' },
  { type: 'notification', label: 'Notification' },
  { type: 'database', label: 'Database' },
];

export function WorkflowDesigner({
  nodes,
  connections,
  onNodesChange,
  onNodeClick,
  onAddNode,
  readOnly = false,
}: WorkflowDesignerProps) {
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [connectingFrom, setConnectingFrom] = useState<string | null>(null);

  const handleNodeClick = (node: WorkflowNode) => {
    if (readOnly) {
      onNodeClick?.(node);
      return;
    }

    if (connectingFrom) {
      // Create connection
      if (connectingFrom !== node.id) {
        // onConnectionsChange would be called here
      }
      setConnectingFrom(null);
    } else {
      setSelectedNode(node.id);
      onNodeClick?.(node);
    }
  };

  const handleDeleteNode = (nodeId: string) => {
    if (readOnly) return;
    const newNodes = nodes.filter((n) => n.id !== nodeId);
    onNodesChange?.(newNodes);
  };

  const startConnection = (nodeId: string) => {
    if (readOnly) return;
    setConnectingFrom(nodeId);
  };

  // Calculate connection paths (simplified)
  const getConnectionPath = (from: WorkflowNode, to: WorkflowNode) => {
    const fromX = from.position.x + 100; // Assuming node width of 200px
    const fromY = from.position.y + 40; // Center of node
    const toX = to.position.x;
    const toY = to.position.y + 40;

    const midX = (fromX + toX) / 2;

    return `M ${fromX} ${fromY} C ${midX} ${fromY}, ${midX} ${toY}, ${toX} ${toY}`;
  };

  return (
    <div className="flex gap-4 h-[600px]">
      {/* Toolbar */}
      {!readOnly && (
        <Card className="w-64 flex-shrink-0">
          <CardHeader>
            <CardTitle className="text-base">Add Nodes</CardTitle>
            <CardDescription>Drag or click to add</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {nodeTypes.map((nodeType) => (
              <Button
                key={nodeType.type}
                variant="outline"
                className="w-full justify-start"
                onClick={() => onAddNode?.(nodeType.type)}
              >
                <span className={`mr-2 p-1 rounded text-white ${nodeColors[nodeType.type]}`}>
                  {nodeIcons[nodeType.type]}
                </span>
                {nodeType.label}
              </Button>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Canvas */}
      <Card className="flex-1 relative overflow-hidden">
        <CardContent className="p-0 h-full relative bg-muted/20">
          {/* Grid background */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none">
            <defs>
              <pattern
                id="grid"
                width="20"
                height="20"
                patternUnits="userSpaceOnUse"
              >
                <circle cx="1" cy="1" r="1" fill="currentColor" className="text-muted-foreground/20" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>

          {/* Connections */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none">
            {connections.map((conn) => {
              const fromNode = nodes.find((n) => n.id === conn.from);
              const toNode = nodes.find((n) => n.id === conn.to);

              if (!fromNode || !toNode) return null;

              return (
                <g key={conn.id}>
                  <path
                    d={getConnectionPath(fromNode, toNode)}
                    stroke="currentColor"
                    strokeWidth="2"
                    fill="none"
                    className="text-primary"
                    markerEnd="url(#arrowhead)"
                  />
                  {conn.label && (
                    <text
                      x={(fromNode.position.x + toNode.position.x + 100) / 2}
                      y={(fromNode.position.y + toNode.position.y + 80) / 2}
                      className="text-xs fill-current text-muted-foreground"
                      textAnchor="middle"
                    >
                      {conn.label}
                    </text>
                  )}
                </g>
              );
            })}

            {/* Arrow marker */}
            <defs>
              <marker
                id="arrowhead"
                markerWidth="10"
                markerHeight="10"
                refX="9"
                refY="3"
                orient="auto"
              >
                <polygon
                  points="0 0, 10 3, 0 6"
                  fill="currentColor"
                  className="text-primary"
                />
              </marker>
            </defs>
          </svg>

          {/* Nodes */}
          <div className="relative w-full h-full">
            {nodes.map((node) => (
              <div
                key={node.id}
                className={`absolute w-48 cursor-pointer transition-all ${
                  selectedNode === node.id ? 'ring-2 ring-primary' : ''
                } ${connectingFrom === node.id ? 'ring-2 ring-yellow-500' : ''}`}
                style={{
                  left: node.position.x,
                  top: node.position.y,
                }}
                onClick={() => handleNodeClick(node)}
              >
                <Card>
                  <CardContent className="p-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2 flex-1 min-w-0">
                        <div
                          className={`p-2 rounded text-white ${nodeColors[node.type]}`}
                        >
                          {nodeIcons[node.type]}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-sm truncate">
                            {node.label}
                          </div>
                          <Badge variant="secondary" className="text-xs mt-1">
                            {node.type}
                          </Badge>
                        </div>
                      </div>

                      {!readOnly && (
                        <div className="flex flex-col gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 w-6 p-0"
                            onClick={(e) => {
                              e.stopPropagation();
                              startConnection(node.id);
                            }}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 w-6 p-0 text-destructive"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteNode(node.id);
                            }}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      )}
                    </div>

                    {/* Config preview */}
                    {node.config && Object.keys(node.config).length > 0 && (
                      <div className="mt-2 pt-2 border-t text-xs text-muted-foreground">
                        {Object.entries(node.config).slice(0, 2).map(([key, value]) => (
                          <div key={key} className="truncate">
                            <span className="font-medium">{key}:</span> {String(value)}
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>

          {/* Empty state */}
          {nodes.length === 0 && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center text-muted-foreground">
                <p className="text-lg font-medium mb-2">No nodes yet</p>
                <p className="text-sm">
                  {readOnly
                    ? 'This workflow is empty'
                    : 'Click a node type in the toolbar to get started'}
                </p>
              </div>
            </div>
          )}

          {/* Connection mode indicator */}
          {connectingFrom && (
            <div className="absolute top-4 right-4 bg-yellow-500 text-white px-3 py-2 rounded-lg text-sm font-medium shadow-lg">
              Click another node to connect
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
