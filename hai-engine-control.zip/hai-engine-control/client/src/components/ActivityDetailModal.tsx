/**
 * ActivityDetailModal Component
 * 
 * Displays detailed information about a selected activity with options to undo or modify.
 */

import React, { useState } from 'react';
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Activity, 
  CheckCircle2, 
  Clock, 
  Mail, 
  Brain, 
  Calendar,
  AlertCircle,
  Undo2,
  Edit,
  ExternalLink,
} from "lucide-react";
import { Separator } from "@/components/ui/separator";

interface ActivityItem {
  id: number;
  engine: "communication" | "decision" | "task" | "system";
  action: string;
  title: string;
  description?: string | null;
  status: "completed" | "in_progress" | "failed";
  createdAt: Date;
}

interface ActivityDetailModalProps {
  activity: ActivityItem | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onActivityUpdated?: () => void;
}

const getEngineIcon = (engine: string) => {
  switch (engine) {
    case "communication":
      return <Mail className="h-5 w-5" />;
    case "decision":
      return <Brain className="h-5 w-5" />;
    case "task":
      return <Calendar className="h-5 w-5" />;
    default:
      return <Activity className="h-5 w-5" />;
  }
};

const getEngineColor = (engine: string) => {
  switch (engine) {
    case "communication":
      return "bg-blue-500/10 text-blue-600 border-blue-200";
    case "decision":
      return "bg-purple-500/10 text-purple-600 border-purple-200";
    case "task":
      return "bg-green-500/10 text-green-600 border-green-200";
    default:
      return "bg-gray-500/10 text-gray-600 border-gray-200";
  }
};

const getStatusBadge = (status: string) => {
  switch (status) {
    case "completed":
      return <Badge variant="default" className="bg-green-500/10 text-green-700 border-green-200"><CheckCircle2 className="h-3 w-3 mr-1" />Completed</Badge>;
    case "in_progress":
      return <Badge variant="default" className="bg-blue-500/10 text-blue-700 border-blue-200"><Clock className="h-3 w-3 mr-1" />In Progress</Badge>;
    case "failed":
      return <Badge variant="destructive" className="bg-red-500/10 text-red-700 border-red-200"><AlertCircle className="h-3 w-3 mr-1" />Failed</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

const formatFullDateTime = (date: Date) => {
  return new Date(date).toLocaleString('en-US', { 
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit', 
    minute: '2-digit',
    second: '2-digit'
  });
};

export function ActivityDetailModal({ activity, open, onOpenChange, onActivityUpdated }: ActivityDetailModalProps) {
  const [showModifyDialog, setShowModifyDialog] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newDescription, setNewDescription] = useState("");

  const undoMutation = trpc.activities.undo.useMutation({
    onSuccess: () => {
      toast.success("Activity undone successfully!");
      onOpenChange(false);
      onActivityUpdated?.();
    },
    onError: (error) => {
      toast.error(`Failed to undo: ${error.message}`);
    },
  });

  const modifyMutation = trpc.activities.modify.useMutation({
    onSuccess: () => {
      toast.success("Activity modified successfully!");
      setShowModifyDialog(false);
      onOpenChange(false);
      onActivityUpdated?.();
    },
    onError: (error) => {
      toast.error(`Failed to modify: ${error.message}`);
    },
  });

  const handleUndo = () => {
    if (confirm(`Are you sure you want to undo this activity?\n\n"${activity?.title}"`)) {
      undoMutation.mutate({ activityId: activity!.id });
    }
  };

  const handleModify = () => {
    if (!newTitle && !newDescription) {
      toast.error("Please provide a new title or description");
      return;
    }
    modifyMutation.mutate({
      activityId: activity!.id,
      newTitle: newTitle || undefined,
      newDescription: newDescription || undefined,
    });
  };

  if (!activity) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <div className="flex items-start gap-3 mb-2">
            <div className={`p-3 rounded-lg border ${getEngineColor(activity.engine)}`}>
              {getEngineIcon(activity.engine)}
            </div>
            <div className="flex-1">
              <DialogTitle className="text-xl mb-2">{activity.title}</DialogTitle>
              <div className="flex items-center gap-2">
                {getStatusBadge(activity.status)}
                <Badge variant="outline" className="capitalize">{activity.engine}</Badge>
              </div>
            </div>
          </div>
          <DialogDescription className="text-base">
            {activity.description || "No additional details provided."}
          </DialogDescription>
        </DialogHeader>

        <Separator />

        <div className="space-y-4">
          <div>
            <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Timeline
            </h4>
            <div className="text-sm text-muted-foreground space-y-1">
              <p><span className="font-medium">Created:</span> {formatFullDateTime(activity.createdAt)}</p>
              <p><span className="font-medium">Action:</span> {activity.action}</p>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
              <Activity className="h-4 w-4" />
              Activity Details
            </h4>
            <div className="text-sm text-muted-foreground space-y-1">
              <p><span className="font-medium">Activity ID:</span> #{activity.id}</p>
              <p><span className="font-medium">Engine:</span> {activity.engine}</p>
              <p><span className="font-medium">Status:</span> {activity.status}</p>
            </div>
          </div>
        </div>

        <DialogFooter className="flex-col sm:flex-row gap-2">
          <Button
            variant="outline"
            className="w-full sm:w-auto"
            onClick={handleUndo}
            disabled={undoMutation.isPending}
          >
            <Undo2 className="h-4 w-4 mr-2" />
            {undoMutation.isPending ? "Undoing..." : "Undo Action"}
          </Button>
          <Button
            variant="outline"
            className="w-full sm:w-auto"
            onClick={() => {
              setNewTitle(activity.title);
              setNewDescription(activity.description || "");
              setShowModifyDialog(true);
            }}
            disabled={modifyMutation.isPending}
          >
            <Edit className="h-4 w-4 mr-2" />
            Modify
          </Button>
          <Button
            variant="default"
            className="w-full sm:w-auto"
            onClick={() => onOpenChange(false)}
          >
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
