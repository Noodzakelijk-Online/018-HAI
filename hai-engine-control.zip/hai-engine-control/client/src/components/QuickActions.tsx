import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, MessageSquare, Play, Scale, ChevronDown, ChevronUp } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

export function QuickActions() {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [, setLocation] = useLocation();

  const actions = [
    {
      icon: FileText,
      label: "Create Task",
      description: "Add a new task",
      action: () => setLocation("/tasks"),
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
    },
    {
      icon: MessageSquare,
      label: "Send Message",
      description: "Compose a message",
      action: () => setLocation("/communication"),
      color: "text-purple-500",
      bgColor: "bg-purple-500/10",
    },
    {
      icon: Play,
      label: "Run Playbook",
      description: "Execute a workflow",
      action: () => setLocation("/playbooks"),
      color: "text-green-500",
      bgColor: "bg-green-500/10",
    },
    {
      icon: Scale,
      label: "Create Decision",
      description: "Make a decision",
      action: () => setLocation("/decisions"),
      color: "text-orange-500",
      bgColor: "bg-orange-500/10",
    },
  ];

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg">Quick Actions</CardTitle>
            <CardDescription>Common tasks and operations</CardDescription>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="h-8 w-8 p-0"
          >
            {isCollapsed ? (
              <ChevronDown className="h-4 w-4" />
            ) : (
              <ChevronUp className="h-4 w-4" />
            )}
          </Button>
        </div>
      </CardHeader>
      
      {!isCollapsed && (
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {actions.map((action, index) => (
              <button
                key={index}
                onClick={action.action}
                className="flex flex-col items-start gap-2 rounded-lg border p-4 text-left transition-all hover:bg-accent hover:shadow-md focus:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <div className={`p-2 rounded-lg ${action.bgColor}`}>
                  <action.icon className={`h-5 w-5 ${action.color}`} />
                </div>
                <div>
                  <p className="font-medium text-sm">{action.label}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {action.description}
                  </p>
                </div>
              </button>
            ))}
          </div>
        </CardContent>
      )}
    </Card>
  );
}
