import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { useEffect, useState } from "react";

interface EngineMetricsChartProps {
  engineId: string;
  engineName: string;
}

export default function EngineMetricsChart({ engineId, engineName }: EngineMetricsChartProps) {
  const { data: metrics } = trpc.engines.metrics.useQuery({ engineId, limit: 50 });
  const [chartData, setChartData] = useState<any[]>([]);

  useEffect(() => {
    if (metrics) {
      // Transform metrics data for the chart
      const transformed = metrics.map((metric) => ({
        time: new Date(metric.timestamp).toLocaleTimeString(),
        value: metric.value,
        timestamp: metric.timestamp,
      })).reverse(); // Reverse to show oldest first
      
      setChartData(transformed);
    }
  }, [metrics]);

  if (!metrics || metrics.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>{engineName} Metrics</CardTitle>
          <CardDescription>No metrics data available yet</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-64 flex items-center justify-center text-muted-foreground">
            Metrics will appear once the engine starts processing tasks
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{engineName} Performance</CardTitle>
        <CardDescription>Real-time metrics over the last 50 data points</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis 
              dataKey="time" 
              stroke="#9CA3AF"
              tick={{ fill: '#9CA3AF' }}
            />
            <YAxis 
              stroke="#9CA3AF"
              tick={{ fill: '#9CA3AF' }}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#1F2937', 
                border: '1px solid #374151',
                borderRadius: '6px'
              }}
              labelStyle={{ color: '#F3F4F6' }}
            />
            <Legend 
              wrapperStyle={{ color: '#9CA3AF' }}
            />
            <Line 
              type="monotone" 
              dataKey="value" 
              stroke="#3B82F6" 
              strokeWidth={2}
              dot={false}
              name="Performance"
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
