/**
 * DebugExporter
 * 
 * Utility for exporting debug data in various formats:
 * - JSON (structured data)
 * - CSV (tabular data)
 * - HTML (formatted report)
 * - Markdown (documentation-friendly)
 * - PDF (via HTML conversion)
 * 
 * Supports:
 * - Performance metrics
 * - Error logs
 * - Network requests
 * - Console logs
 * - Application state
 */

import debugService from '../services/DebugService';

class DebugExporter {
  constructor() {
    this.exportFormats = ['json', 'csv', 'html', 'markdown', 'txt'];
  }

  /**
   * Export all debug data
   */
  exportAll(format = 'json', options = {}) {
    const data = this.collectAllData();
    return this.export(data, format, options);
  }

  /**
   * Export specific data type
   */
  exportType(type, format = 'json', options = {}) {
    const data = this.collectDataByType(type);
    return this.export(data, format, options);
  }

  /**
   * Collect all debug data
   */
  collectAllData() {
    return {
      metadata: {
        exportDate: new Date().toISOString(),
        userAgent: navigator.userAgent,
        url: window.location.href,
        version: '1.0.0'
      },
      performance: debugService.getPerformanceMetrics(),
      errors: debugService.getErrors(),
      network: debugService.getNetworkRequests(),
      logs: debugService.getLogs(),
      state: this.collectStateData(),
      storage: debugService.getStats()
    };
  }

  /**
   * Collect data by type
   */
  collectDataByType(type) {
    switch (type) {
      case 'performance':
        return debugService.getPerformanceMetrics();
      case 'errors':
        return debugService.getErrors();
      case 'network':
        return debugService.getNetworkRequests();
      case 'logs':
        return debugService.getLogs();
      case 'state':
        return this.collectStateData();
      default:
        return null;
    }
  }

  /**
   * Collect state data
   */
  collectStateData() {
    const state = {};

    // Collect from various sources
    try {
      // Redux state
      if (window.__REDUX_STATE__) {
        state.redux = window.__REDUX_STATE__;
      }

      // Context state
      if (window.__CONTEXT_STATE__) {
        state.context = window.__CONTEXT_STATE__;
      }

      // Custom app state
      if (window.__HAI_STATE__) {
        state.custom = window.__HAI_STATE__;
      }

      // LocalStorage
      state.localStorage = {};
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        try {
          state.localStorage[key] = JSON.parse(localStorage.getItem(key));
        } catch {
          state.localStorage[key] = localStorage.getItem(key);
        }
      }
    } catch (error) {
      console.error('Failed to collect state data:', error);
    }

    return state;
  }

  /**
   * Export data in specified format
   */
  export(data, format, options = {}) {
    switch (format.toLowerCase()) {
      case 'json':
        return this.exportAsJSON(data, options);
      case 'csv':
        return this.exportAsCSV(data, options);
      case 'html':
        return this.exportAsHTML(data, options);
      case 'markdown':
        return this.exportAsMarkdown(data, options);
      case 'txt':
        return this.exportAsText(data, options);
      default:
        throw new Error(`Unsupported export format: ${format}`);
    }
  }

  /**
   * Export as JSON
   */
  exportAsJSON(data, options = {}) {
    const json = JSON.stringify(data, null, options.pretty ? 2 : 0);
    
    if (options.download !== false) {
      this.downloadFile(json, 'application/json', 'json', options.filename);
    }
    
    return json;
  }

  /**
   * Export as CSV
   */
  exportAsCSV(data, options = {}) {
    const rows = [];

    // Handle different data structures
    if (Array.isArray(data)) {
      // Array of objects
      if (data.length > 0 && typeof data[0] === 'object') {
        const headers = Object.keys(data[0]);
        rows.push(headers);
        
        data.forEach(item => {
          const row = headers.map(header => {
            const value = item[header];
            return typeof value === 'object' ? JSON.stringify(value) : String(value);
          });
          rows.push(row);
        });
      }
    } else if (typeof data === 'object') {
      // Object with nested data
      rows.push(['Category', 'Key', 'Value', 'Type']);
      
      Object.entries(data).forEach(([category, categoryData]) => {
        if (Array.isArray(categoryData)) {
          categoryData.forEach((item, index) => {
            if (typeof item === 'object') {
              Object.entries(item).forEach(([key, value]) => {
                rows.push([
                  category,
                  `${index}.${key}`,
                  typeof value === 'object' ? JSON.stringify(value) : String(value),
                  typeof value
                ]);
              });
            } else {
              rows.push([category, index, String(item), typeof item]);
            }
          });
        } else if (typeof categoryData === 'object') {
          Object.entries(categoryData).forEach(([key, value]) => {
            rows.push([
              category,
              key,
              typeof value === 'object' ? JSON.stringify(value) : String(value),
              typeof value
            ]);
          });
        } else {
          rows.push([category, '', String(categoryData), typeof categoryData]);
        }
      });
    }

    const csv = rows.map(row => 
      row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(',')
    ).join('\n');

    if (options.download !== false) {
      this.downloadFile(csv, 'text/csv', 'csv', options.filename);
    }

    return csv;
  }

  /**
   * Export as HTML
   */
  exportAsHTML(data, options = {}) {
    const html = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Debug Report - ${new Date().toLocaleString()}</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      line-height: 1.6;
      max-width: 1200px;
      margin: 0 auto;
      padding: 20px;
      background: #f5f5f5;
    }
    .header {
      background: #2c3e50;
      color: white;
      padding: 20px;
      border-radius: 8px;
      margin-bottom: 20px;
    }
    .section {
      background: white;
      padding: 20px;
      border-radius: 8px;
      margin-bottom: 20px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .section h2 {
      margin-top: 0;
      color: #2c3e50;
      border-bottom: 2px solid #3498db;
      padding-bottom: 10px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
    }
    th, td {
      padding: 10px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }
    th {
      background: #3498db;
      color: white;
      font-weight: 600;
    }
    tr:hover {
      background: #f5f5f5;
    }
    .error {
      color: #e74c3c;
    }
    .warning {
      color: #f39c12;
    }
    .success {
      color: #27ae60;
    }
    pre {
      background: #f8f9fa;
      padding: 15px;
      border-radius: 4px;
      overflow-x: auto;
      border-left: 4px solid #3498db;
    }
    .metric {
      display: inline-block;
      background: #ecf0f1;
      padding: 10px 20px;
      border-radius: 4px;
      margin: 5px;
    }
    .metric-label {
      font-size: 12px;
      color: #7f8c8d;
      text-transform: uppercase;
    }
    .metric-value {
      font-size: 24px;
      font-weight: bold;
      color: #2c3e50;
    }
  </style>
</head>
<body>
  <div class="header">
    <h1>🐛 Debug Report</h1>
    <p>Generated: ${new Date().toLocaleString()}</p>
    <p>URL: ${window.location.href}</p>
  </div>

  ${this.generateHTMLSections(data)}

  <div class="section">
    <h2>Export Information</h2>
    <p>This report was generated by the Household AI Debug Tool.</p>
    <p>For more information, visit the documentation.</p>
  </div>
</body>
</html>
    `.trim();

    if (options.download !== false) {
      this.downloadFile(html, 'text/html', 'html', options.filename);
    }

    return html;
  }

  /**
   * Generate HTML sections from data
   */
  generateHTMLSections(data) {
    let html = '';

    // Performance metrics
    if (data.performance && data.performance.length > 0) {
      html += `
        <div class="section">
          <h2>📊 Performance Metrics</h2>
          <div>
            ${this.generateMetricCards(data.performance)}
          </div>
          ${this.generateTable(data.performance, ['timestamp', 'fps', 'memory', 'cpu'])}
        </div>
      `;
    }

    // Errors
    if (data.errors && data.errors.length > 0) {
      html += `
        <div class="section">
          <h2>❌ Errors</h2>
          ${this.generateTable(data.errors, ['timestamp', 'message', 'level', 'stack'])}
        </div>
      `;
    }

    // Network requests
    if (data.network && data.network.length > 0) {
      html += `
        <div class="section">
          <h2>🌐 Network Requests</h2>
          ${this.generateTable(data.network, ['timestamp', 'method', 'url', 'status', 'duration'])}
        </div>
      `;
    }

    // Logs
    if (data.logs && data.logs.length > 0) {
      html += `
        <div class="section">
          <h2>📝 Console Logs</h2>
          ${this.generateTable(data.logs, ['timestamp', 'level', 'message'])}
        </div>
      `;
    }

    // Storage stats
    if (data.storage) {
      html += `
        <div class="section">
          <h2>💾 Storage Statistics</h2>
          <pre>${JSON.stringify(data.storage, null, 2)}</pre>
        </div>
      `;
    }

    return html;
  }

  /**
   * Generate metric cards for HTML
   */
  generateMetricCards(metrics) {
    if (!metrics || metrics.length === 0) return '';

    const latest = metrics[metrics.length - 1];
    return `
      <div>
        <div class="metric">
          <div class="metric-label">FPS</div>
          <div class="metric-value">${latest.fps || 'N/A'}</div>
        </div>
        <div class="metric">
          <div class="metric-label">Memory</div>
          <div class="metric-value">${latest.memory || 'N/A'} MB</div>
        </div>
        <div class="metric">
          <div class="metric-label">CPU</div>
          <div class="metric-value">${latest.cpu || 'N/A'}%</div>
        </div>
      </div>
    `;
  }

  /**
   * Generate HTML table
   */
  generateTable(data, columns) {
    if (!data || data.length === 0) return '<p>No data available</p>';

    const headers = columns || Object.keys(data[0]);
    
    let html = '<table><thead><tr>';
    headers.forEach(header => {
      html += `<th>${header}</th>`;
    });
    html += '</tr></thead><tbody>';

    data.forEach(row => {
      html += '<tr>';
      headers.forEach(header => {
        let value = row[header];
        if (header === 'timestamp') {
          value = new Date(value).toLocaleString();
        } else if (typeof value === 'object') {
          value = JSON.stringify(value);
        }
        html += `<td>${value || ''}</td>`;
      });
      html += '</tr>';
    });

    html += '</tbody></table>';
    return html;
  }

  /**
   * Export as Markdown
   */
  exportAsMarkdown(data, options = {}) {
    let md = `# Debug Report\n\n`;
    md += `**Generated:** ${new Date().toLocaleString()}\n\n`;
    md += `**URL:** ${window.location.href}\n\n`;
    md += `---\n\n`;

    // Add sections
    Object.entries(data).forEach(([key, value]) => {
      md += `## ${key.charAt(0).toUpperCase() + key.slice(1)}\n\n`;
      
      if (Array.isArray(value)) {
        md += this.arrayToMarkdownTable(value);
      } else if (typeof value === 'object') {
        md += '```json\n';
        md += JSON.stringify(value, null, 2);
        md += '\n```\n\n';
      } else {
        md += `${value}\n\n`;
      }
    });

    if (options.download !== false) {
      this.downloadFile(md, 'text/markdown', 'md', options.filename);
    }

    return md;
  }

  /**
   * Convert array to Markdown table
   */
  arrayToMarkdownTable(arr) {
    if (!arr || arr.length === 0) return 'No data\n\n';

    const headers = Object.keys(arr[0]);
    let table = '| ' + headers.join(' | ') + ' |\n';
    table += '| ' + headers.map(() => '---').join(' | ') + ' |\n';

    arr.forEach(row => {
      table += '| ' + headers.map(h => {
        const value = row[h];
        if (h === 'timestamp') {
          return new Date(value).toLocaleString();
        }
        return typeof value === 'object' ? JSON.stringify(value) : String(value);
      }).join(' | ') + ' |\n';
    });

    return table + '\n';
  }

  /**
   * Export as plain text
   */
  exportAsText(data, options = {}) {
    let text = '=== DEBUG REPORT ===\n\n';
    text += `Generated: ${new Date().toLocaleString()}\n`;
    text += `URL: ${window.location.href}\n\n`;
    text += '='.repeat(50) + '\n\n';

    Object.entries(data).forEach(([key, value]) => {
      text += `[${key.toUpperCase()}]\n`;
      text += '-'.repeat(50) + '\n';
      
      if (typeof value === 'object') {
        text += JSON.stringify(value, null, 2);
      } else {
        text += String(value);
      }
      
      text += '\n\n';
    });

    if (options.download !== false) {
      this.downloadFile(text, 'text/plain', 'txt', options.filename);
    }

    return text;
  }

  /**
   * Download file helper
   */
  downloadFile(content, mimeType, extension, filename = null) {
    const timestamp = Date.now();
    const defaultFilename = `debug-report-${timestamp}`;
    
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${filename || defaultFilename}.${extension}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}

// Create singleton instance
const debugExporter = new DebugExporter();

export default debugExporter;
