/**
 * DebugService
 * 
 * Centralized service for managing debug data across all debug components.
 * Provides:
 * - Data persistence to localStorage/IndexedDB
 * - Data export in multiple formats (JSON, CSV, TXT)
 * - Data import and validation
 * - Data retention and cleanup
 * - Cross-component data sharing
 * - Event-based communication
 */

class DebugService {
  constructor() {
    this.storagePrefix = 'debug_';
    this.maxStorageSize = 10 * 1024 * 1024; // 10MB
    this.eventListeners = new Map();
    this.dataRetentionDays = 7;
    
    // Initialize storage
    this.initializeStorage();
  }

  /**
   * Initialize storage and cleanup old data
   */
  initializeStorage() {
    try {
      // Check if localStorage is available
      if (!this.isLocalStorageAvailable()) {
        console.warn('localStorage is not available, using in-memory storage');
        this.useMemoryStorage = true;
        this.memoryStorage = new Map();
      }

      // Cleanup old data
      this.cleanupOldData();
    } catch (error) {
      console.error('Failed to initialize debug storage:', error);
    }
  }

  /**
   * Check if localStorage is available
   */
  isLocalStorageAvailable() {
    try {
      const test = '__localStorage_test__';
      localStorage.setItem(test, test);
      localStorage.removeItem(test);
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Store data with automatic cleanup
   */
  setItem(key, value, options = {}) {
    const fullKey = this.storagePrefix + key;
    const data = {
      value,
      timestamp: Date.now(),
      ttl: options.ttl || null,
      metadata: options.metadata || {}
    };

    try {
      const serialized = JSON.stringify(data);
      
      // Check storage size
      if (this.getStorageSize() + serialized.length > this.maxStorageSize) {
        this.cleanupOldData(true);
      }

      if (this.useMemoryStorage) {
        this.memoryStorage.set(fullKey, serialized);
      } else {
        localStorage.setItem(fullKey, serialized);
      }

      // Emit event
      this.emit('dataChanged', { key, value, action: 'set' });
      
      return true;
    } catch (error) {
      console.error('Failed to store debug data:', error);
      return false;
    }
  }

  /**
   * Retrieve data from storage
   */
  getItem(key, defaultValue = null) {
    const fullKey = this.storagePrefix + key;

    try {
      const serialized = this.useMemoryStorage
        ? this.memoryStorage.get(fullKey)
        : localStorage.getItem(fullKey);

      if (!serialized) {
        return defaultValue;
      }

      const data = JSON.parse(serialized);

      // Check TTL
      if (data.ttl && Date.now() - data.timestamp > data.ttl) {
        this.removeItem(key);
        return defaultValue;
      }

      return data.value;
    } catch (error) {
      console.error('Failed to retrieve debug data:', error);
      return defaultValue;
    }
  }

  /**
   * Remove data from storage
   */
  removeItem(key) {
    const fullKey = this.storagePrefix + key;

    try {
      if (this.useMemoryStorage) {
        this.memoryStorage.delete(fullKey);
      } else {
        localStorage.removeItem(fullKey);
      }

      this.emit('dataChanged', { key, action: 'remove' });
      return true;
    } catch (error) {
      console.error('Failed to remove debug data:', error);
      return false;
    }
  }

  /**
   * Get all debug keys
   */
  getAllKeys() {
    const keys = [];

    try {
      if (this.useMemoryStorage) {
        for (const key of this.memoryStorage.keys()) {
          if (key.startsWith(this.storagePrefix)) {
            keys.push(key.substring(this.storagePrefix.length));
          }
        }
      } else {
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key.startsWith(this.storagePrefix)) {
            keys.push(key.substring(this.storagePrefix.length));
          }
        }
      }
    } catch (error) {
      console.error('Failed to get debug keys:', error);
    }

    return keys;
  }

  /**
   * Get current storage size
   */
  getStorageSize() {
    let size = 0;

    try {
      const keys = this.getAllKeys();
      keys.forEach(key => {
        const fullKey = this.storagePrefix + key;
        const item = this.useMemoryStorage
          ? this.memoryStorage.get(fullKey)
          : localStorage.getItem(fullKey);
        if (item) {
          size += item.length;
        }
      });
    } catch (error) {
      console.error('Failed to calculate storage size:', error);
    }

    return size;
  }

  /**
   * Cleanup old data based on retention policy
   */
  cleanupOldData(force = false) {
    try {
      const keys = this.getAllKeys();
      const now = Date.now();
      const retentionMs = this.dataRetentionDays * 24 * 60 * 60 * 1000;

      keys.forEach(key => {
        const fullKey = this.storagePrefix + key;
        const serialized = this.useMemoryStorage
          ? this.memoryStorage.get(fullKey)
          : localStorage.getItem(fullKey);

        if (serialized) {
          try {
            const data = JSON.parse(serialized);
            
            // Remove if expired or force cleanup
            if (force || (now - data.timestamp > retentionMs)) {
              this.removeItem(key);
            }
          } catch {
            // Remove invalid data
            this.removeItem(key);
          }
        }
      });
    } catch (error) {
      console.error('Failed to cleanup debug data:', error);
    }
  }

  /**
   * Export all debug data as JSON
   */
  exportAsJSON() {
    const data = {};
    const keys = this.getAllKeys();

    keys.forEach(key => {
      data[key] = this.getItem(key);
    });

    return {
      version: '1.0.0',
      exportDate: new Date().toISOString(),
      data
    };
  }

  /**
   * Export debug data as downloadable file
   */
  exportToFile(format = 'json', filename = null) {
    const timestamp = Date.now();
    const defaultFilename = `debug-export-${timestamp}`;

    try {
      let content, mimeType, extension;

      switch (format.toLowerCase()) {
        case 'json':
          content = JSON.stringify(this.exportAsJSON(), null, 2);
          mimeType = 'application/json';
          extension = 'json';
          break;

        case 'csv':
          content = this.convertToCSV(this.exportAsJSON().data);
          mimeType = 'text/csv';
          extension = 'csv';
          break;

        case 'txt':
          content = this.convertToText(this.exportAsJSON().data);
          mimeType = 'text/plain';
          extension = 'txt';
          break;

        default:
          throw new Error(`Unsupported export format: ${format}`);
      }

      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${filename || defaultFilename}.${extension}`;
      link.click();
      URL.revokeObjectURL(url);

      this.emit('dataExported', { format, filename: link.download });
      return true;
    } catch (error) {
      console.error('Failed to export debug data:', error);
      return false;
    }
  }

  /**
   * Convert data to CSV format
   */
  convertToCSV(data) {
    const rows = [];
    rows.push(['Key', 'Value', 'Type']);

    Object.entries(data).forEach(([key, value]) => {
      const type = Array.isArray(value) ? 'array' : typeof value;
      const valueStr = typeof value === 'object'
        ? JSON.stringify(value)
        : String(value);
      rows.push([key, valueStr, type]);
    });

    return rows.map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
  }

  /**
   * Convert data to text format
   */
  convertToText(data) {
    const lines = [];
    lines.push('=== Debug Data Export ===');
    lines.push(`Export Date: ${new Date().toISOString()}`);
    lines.push('');

    Object.entries(data).forEach(([key, value]) => {
      lines.push(`[${key}]`);
      if (typeof value === 'object') {
        lines.push(JSON.stringify(value, null, 2));
      } else {
        lines.push(String(value));
      }
      lines.push('');
    });

    return lines.join('\n');
  }

  /**
   * Import debug data from JSON
   */
  importFromJSON(jsonData) {
    try {
      const parsed = typeof jsonData === 'string'
        ? JSON.parse(jsonData)
        : jsonData;

      if (!parsed.data) {
        throw new Error('Invalid import format: missing data property');
      }

      Object.entries(parsed.data).forEach(([key, value]) => {
        this.setItem(key, value, {
          metadata: { imported: true, importDate: Date.now() }
        });
      });

      this.emit('dataImported', { count: Object.keys(parsed.data).length });
      return true;
    } catch (error) {
      console.error('Failed to import debug data:', error);
      return false;
    }
  }

  /**
   * Clear all debug data
   */
  clearAll() {
    try {
      const keys = this.getAllKeys();
      keys.forEach(key => this.removeItem(key));
      
      this.emit('dataCleared', { count: keys.length });
      return true;
    } catch (error) {
      console.error('Failed to clear debug data:', error);
      return false;
    }
  }

  /**
   * Get storage statistics
   */
  getStats() {
    const keys = this.getAllKeys();
    const size = this.getStorageSize();

    return {
      totalKeys: keys.length,
      totalSize: size,
      totalSizeMB: (size / (1024 * 1024)).toFixed(2),
      maxSize: this.maxStorageSize,
      maxSizeMB: (this.maxStorageSize / (1024 * 1024)).toFixed(2),
      usagePercent: ((size / this.maxStorageSize) * 100).toFixed(2),
      retentionDays: this.dataRetentionDays
    };
  }

  /**
   * Event emitter functionality
   */
  on(event, callback) {
    if (!this.eventListeners.has(event)) {
      this.eventListeners.set(event, []);
    }
    this.eventListeners.get(event).push(callback);
  }

  off(event, callback) {
    if (!this.eventListeners.has(event)) return;
    const listeners = this.eventListeners.get(event);
    const index = listeners.indexOf(callback);
    if (index > -1) {
      listeners.splice(index, 1);
    }
  }

  emit(event, data) {
    if (!this.eventListeners.has(event)) return;
    this.eventListeners.get(event).forEach(callback => {
      try {
        callback(data);
      } catch (error) {
        console.error(`Error in event listener for ${event}:`, error);
      }
    });
  }

  /**
   * Performance monitoring data management
   */
  recordPerformanceMetric(metric) {
    const metrics = this.getItem('performance_metrics', []);
    metrics.push({
      ...metric,
      timestamp: Date.now()
    });

    // Keep only last 1000 metrics
    if (metrics.length > 1000) {
      metrics.shift();
    }

    this.setItem('performance_metrics', metrics);
  }

  getPerformanceMetrics(limit = 100) {
    const metrics = this.getItem('performance_metrics', []);
    return metrics.slice(-limit);
  }

  /**
   * Error tracking data management
   */
  recordError(error) {
    const errors = this.getItem('errors', []);
    errors.push({
      ...error,
      timestamp: Date.now()
    });

    // Keep only last 100 errors
    if (errors.length > 100) {
      errors.shift();
    }

    this.setItem('errors', errors);
  }

  getErrors(limit = 50) {
    const errors = this.getItem('errors', []);
    return errors.slice(-limit);
  }

  /**
   * Network request data management
   */
  recordNetworkRequest(request) {
    const requests = this.getItem('network_requests', []);
    requests.push({
      ...request,
      timestamp: Date.now()
    });

    // Keep only last 100 requests
    if (requests.length > 100) {
      requests.shift();
    }

    this.setItem('network_requests', requests);
  }

  getNetworkRequests(limit = 50) {
    const requests = this.getItem('network_requests', []);
    return requests.slice(-limit);
  }

  /**
   * Console log data management
   */
  recordLog(log) {
    const logs = this.getItem('console_logs', []);
    logs.push({
      ...log,
      timestamp: Date.now()
    });

    // Keep only last 1000 logs
    if (logs.length > 1000) {
      logs.shift();
    }

    this.setItem('console_logs', logs);
  }

  getLogs(limit = 100) {
    const logs = this.getItem('console_logs', []);
    return logs.slice(-limit);
  }
}

// Create singleton instance
const debugService = new DebugService();

export default debugService;
