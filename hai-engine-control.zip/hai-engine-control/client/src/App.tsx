import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { FloatingChatBubble } from "@/components/FloatingChatBubble";
import { BackgroundScreenMonitor } from "@/components/BackgroundScreenMonitor";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { useKeyboardShortcuts } from "./hooks/useKeyboardShortcuts";
import { lazy, Suspense } from "react";
import { Skeleton } from "@/components/ui/skeleton";

// Loading fallback component for lazy-loaded pages
function PageLoader() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-background">
      <div className="space-y-4 w-full max-w-md p-8">
        <Skeleton className="h-8 w-3/4" />
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-5/6" />
        <div className="flex gap-4 mt-6">
          <Skeleton className="h-10 w-24" />
          <Skeleton className="h-10 w-24" />
        </div>
      </div>
    </div>
  );
}

// OPTIMIZED: Lazy load all pages for code splitting
// Only the main dashboard is loaded immediately, all others are lazy-loaded
const HAIDashboard = lazy(() => import("./pages/HAIDashboard"));
const NotFound = lazy(() => import("@/pages/NotFound"));

// Core pages - lazy loaded
const Agents = lazy(() => import("./pages/Agents"));
const Household = lazy(() => import("./pages/Household"));
const Connectors = lazy(() => import("./pages/Connectors"));
const Profile = lazy(() => import("./pages/Profile"));
const SecuritySettings = lazy(() => import("./pages/SecuritySettings"));
const InviteAccept = lazy(() => import("./pages/InviteAccept"));

// Orchestrator pages - lazy loaded
const MasterOrchestrator = lazy(() => import("./pages/MasterOrchestrator"));
const ConnectorActivity = lazy(() => import("./pages/ConnectorActivity"));
const ConnectorLogs = lazy(() => import("./pages/ConnectorLogs"));

// Advanced features - lazy loaded (heavy components)
const LuxExecutor = lazy(() => import("./pages/LuxExecutor"));
const AutonomousDashboard = lazy(() => import("./pages/AutonomousDashboard"));
const Level5Dashboard = lazy(() => import("./pages/Level5Dashboard"));
const AutonomousServicesDashboard = lazy(() => import("./pages/AutonomousServicesDashboard"));
const AdminMonitoring = lazy(() => import("./pages/AdminMonitoring"));

// Communication pages - lazy loaded
const WhatsAppDashboard = lazy(() => import("./pages/WhatsAppDashboard"));
const ConversationThread = lazy(() => import("./pages/ConversationThread"));
const AutonomousCommunication = lazy(() => import("./pages/AutonomousCommunication"));
const EscalationQueue = lazy(() => import("./pages/EscalationQueue"));
const UnifiedCommunications = lazy(() => import("./pages/UnifiedCommunications"));
const CommunicationAnalytics = lazy(() => import("./pages/CommunicationAnalytics"));
const CommunicationCenter = lazy(() => import("./pages/CommunicationCenter"));

// Pillar dashboards - lazy loaded (rarely accessed)
const Pillar1Dashboard = lazy(() => import("./pages/Pillar1Dashboard"));
const Pillar2Dashboard = lazy(() => import("./pages/Pillar2Dashboard"));
const Pillar3Dashboard = lazy(() => import("./pages/Pillar3Dashboard"));
const Pillar4Dashboard = lazy(() => import("./pages/Pillar4Dashboard"));
const Pillar5Dashboard = lazy(() => import("./pages/Pillar5Dashboard"));

// Settings and misc - lazy loaded
const Onboarding = lazy(() => import("./pages/Onboarding"));
const DashboardSettings = lazy(() => import("./pages/DashboardSettings"));
const MemoryExplorer = lazy(() => import("./pages/MemoryExplorer"));
const KnowledgeExplorer = lazy(() => import("./pages/KnowledgeExplorer"));
const DiscoveryDashboard = lazy(() => import("./pages/DiscoveryDashboard"));
const ScreenViewer = lazy(() => import("./pages/ScreenViewer"));
const ThinkingStatus = lazy(() => import("./pages/ThinkingStatus"));
const SystemHealth = lazy(() => import("./pages/SystemHealth"));
const AIHealthDashboard = lazy(() => import("./pages/AIHealthDashboard"));

function Router() {
  return (
    <Suspense fallback={<PageLoader />}>
      <Switch>
        <Route path={"/"} component={HAIDashboard} />
        <Route path={"/orchestrator"} component={MasterOrchestrator} />
        <Route path={"/lux"} component={LuxExecutor} />
        <Route path={"/autonomous"} component={AutonomousDashboard} />
        <Route path={"/whatsapp"} component={WhatsAppDashboard} />
        <Route path={"/whatsapp/conversation/:contactId"} component={ConversationThread} />
        <Route path={"/autonomous-communication"} component={AutonomousCommunication} />
        <Route path={"/escalation-queue"} component={EscalationQueue} />
        <Route path={"/unified-communications"} component={UnifiedCommunications} />
        <Route path={"/communication-analytics"} component={CommunicationAnalytics} />
        <Route path={"/level5"} component={Level5Dashboard} />
        <Route path={"/autonomous-services"} component={AutonomousServicesDashboard} />
        <Route path={"/admin-monitoring"} component={AdminMonitoring} />
        <Route path={"/pillar1"} component={Pillar1Dashboard} />
        <Route path={"/pillar2"} component={Pillar2Dashboard} />
        <Route path={"/pillar3"} component={Pillar3Dashboard} />
        <Route path={"/pillar4"} component={Pillar4Dashboard} />
        <Route path={"/pillar5"} component={Pillar5Dashboard} />
        <Route path={"/settings"} component={DashboardSettings} />
        <Route path={"/communication-center"} component={CommunicationCenter} />
        <Route path={"/memory-explorer"} component={MemoryExplorer} />
        <Route path={"/onboarding"} component={Onboarding} />
        <Route path={"/agents"} component={Agents} />
        <Route path={"/household"} component={Household} />
        <Route path={"/invite/:token"} component={InviteAccept} />
        <Route path={"/connector-activity"} component={ConnectorActivity} />
        <Route path={"/connector-logs"} component={ConnectorLogs} />
        <Route path={"/connectors"} component={Connectors} />
        <Route path="/security" component={SecuritySettings} />
        <Route path="/profile" component={Profile} />
        <Route path="/knowledge" component={KnowledgeExplorer} />
        <Route path="/discovery" component={DiscoveryDashboard} />
        <Route path="/screen-viewer" component={ScreenViewer} />
        <Route path="/thinking" component={ThinkingStatus} />
        <Route path="/system-health" component={SystemHealth} />
        <Route path="/ai-health" component={AIHealthDashboard} />
        <Route path={"/404"} component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

function App() {
  useKeyboardShortcuts();
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark" switchable>
        <TooltipProvider>
          <Toaster />
          <Router />
          <FloatingChatBubble />
          <BackgroundScreenMonitor />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
