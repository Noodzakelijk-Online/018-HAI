/**
 * Optimized Query Options Hook
 * 
 * Provides standardized query options for tRPC queries to reduce
 * unnecessary refetches and improve performance.
 */

import { useMemo } from 'react';

export interface OptimizedQueryOptions {
  staleTime: number;
  cacheTime: number;
  refetchOnWindowFocus: boolean;
  refetchOnMount: boolean;
  refetchOnReconnect: boolean;
}

/**
 * Default optimized query options
 * - staleTime: 30s - Data stays fresh for 30 seconds
 * - cacheTime: 5min - Cache persists for 5 minutes
 * - No refetch on window focus (reduces unnecessary API calls)
 */
export const defaultQueryOptions: OptimizedQueryOptions = {
  staleTime: 30 * 1000, // 30 seconds
  cacheTime: 5 * 60 * 1000, // 5 minutes
  refetchOnWindowFocus: false,
  refetchOnMount: true,
  refetchOnReconnect: true,
};

/**
 * Aggressive caching for rarely changing data
 * - staleTime: 5min - Data stays fresh for 5 minutes
 * - cacheTime: 30min - Cache persists for 30 minutes
 */
export const aggressiveCacheOptions: OptimizedQueryOptions = {
  staleTime: 5 * 60 * 1000, // 5 minutes
  cacheTime: 30 * 60 * 1000, // 30 minutes
  refetchOnWindowFocus: false,
  refetchOnMount: false,
  refetchOnReconnect: false,
};

/**
 * Real-time options for frequently changing data
 * - staleTime: 5s - Data stays fresh for 5 seconds
 * - cacheTime: 1min - Cache persists for 1 minute
 */
export const realtimeQueryOptions: OptimizedQueryOptions = {
  staleTime: 5 * 1000, // 5 seconds
  cacheTime: 60 * 1000, // 1 minute
  refetchOnWindowFocus: true,
  refetchOnMount: true,
  refetchOnReconnect: true,
};

/**
 * Hook to get optimized query options
 * Memoized to prevent unnecessary re-renders
 */
export function useOptimizedQuery(
  type: 'default' | 'aggressive' | 'realtime' = 'default'
): OptimizedQueryOptions {
  return useMemo(() => {
    switch (type) {
      case 'aggressive':
        return aggressiveCacheOptions;
      case 'realtime':
        return realtimeQueryOptions;
      default:
        return defaultQueryOptions;
    }
  }, [type]);
}

/**
 * Merge custom options with optimized defaults
 */
export function mergeQueryOptions(
  customOptions: Partial<OptimizedQueryOptions> = {},
  baseType: 'default' | 'aggressive' | 'realtime' = 'default'
): OptimizedQueryOptions {
  const base = baseType === 'aggressive' 
    ? aggressiveCacheOptions 
    : baseType === 'realtime' 
      ? realtimeQueryOptions 
      : defaultQueryOptions;
  
  return { ...base, ...customOptions };
}
