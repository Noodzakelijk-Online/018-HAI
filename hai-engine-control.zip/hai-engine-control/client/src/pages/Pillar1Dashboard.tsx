/**
 * Pillar 1 Dashboard: Decision Authority
 * 
 * "AI Acts, Human Can Override"
 * 
 * This dashboard provides a unified view of:
 * - Autonomous Action Engine (action feed, execution, override)
 * - Financial Logic Engine (rules, bills, anomalies)
 * - Authority Level Matrix (levels, escalations, delegations)
 */

import { useState } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import DashboardLayout from '@/components/DashboardLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { trpc } from '@/lib/trpc';
import { ActionFeed } from '@/components/pillar1/ActionFeed';
import { FinancialRules } from '@/components/pillar1/FinancialRules';
import { AuthorityManagement } from '@/components/pillar1/AuthorityManagement';
import {
  Zap,
  DollarSign,
  Shield,
  TrendingUp,
  CheckCircle2,
  AlertCircle,
  Clock,
  Activity,
} from 'lucide-react';

// Default household ID - in production this would come from user context
const DEFAULT_HOUSEHOLD_ID = 1;

export default function Pillar1Dashboard() {
  const { user, loading } = useAuth();
  const [activeTab, setActiveTab] = useState('actions');

  // Fetch statistics for overview
  const { data: actionStats } = trpc.pillar1.action.statistics.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 10000 }
  );

  const { data: overrideStats } = trpc.pillar1.override.statistics.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 30000 }
  );

  const { data: financialStats } = trpc.pillar1.financial.statistics.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 30000 }
  );

  const { data: authorityStats } = trpc.pillar1.authority.statistics.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 30000 }
  );

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Decision Authority</h1>
            <p className="text-muted-foreground mt-1">
              Pillar 1: AI Acts, Human Can Override
            </p>
          </div>
          <Badge variant="outline" className="text-lg px-4 py-2">
            <Activity className="h-4 w-4 mr-2 animate-pulse text-green-500" />
            System Active
          </Badge>
        </div>

        {/* Overview Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
          <Card className="col-span-2">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Actions</p>
                  <p className="text-3xl font-bold">{actionStats?.total ?? 0}</p>
                </div>
                <div className="p-3 rounded-full bg-blue-500/10">
                  <Zap className="h-6 w-6 text-blue-500" />
                </div>
              </div>
              <div className="mt-4 flex items-center gap-4 text-sm">
                <span className="text-green-500">
                  <CheckCircle2 className="h-3 w-3 inline mr-1" />
                  {actionStats?.completed ?? 0} completed
                </span>
                <span className="text-yellow-500">
                  <Clock className="h-3 w-3 inline mr-1" />
                  {actionStats?.pending ?? 0} pending
                </span>
              </div>
            </CardContent>
          </Card>

          <Card className="col-span-2">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Success Rate</p>
                  <p className="text-3xl font-bold">
                    {actionStats?.successRate ? `${Math.round(actionStats.successRate * 100)}%` : '—'}
                  </p>
                </div>
                <div className="p-3 rounded-full bg-green-500/10">
                  <TrendingUp className="h-6 w-6 text-green-500" />
                </div>
              </div>
              <div className="mt-4 text-sm text-muted-foreground">
                Avg confidence: {actionStats?.avgConfidence ? `${Math.round(actionStats.avgConfidence * 100)}%` : '—'}
              </div>
            </CardContent>
          </Card>

          <Card className="col-span-2">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Overrides</p>
                  <p className="text-3xl font-bold">{overrideStats?.totalOverrides ?? 0}</p>
                </div>
                <div className="p-3 rounded-full bg-orange-500/10">
                  <AlertCircle className="h-6 w-6 text-orange-500" />
                </div>
              </div>
              <div className="mt-4 text-sm text-muted-foreground">
                {overrideStats?.activePatterns ?? 0} learned patterns
              </div>
            </CardContent>
          </Card>

          <Card className="col-span-2">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Financial Rules</p>
                  <p className="text-3xl font-bold">{financialStats?.activeRules ?? 0}</p>
                </div>
                <div className="p-3 rounded-full bg-emerald-500/10">
                  <DollarSign className="h-6 w-6 text-emerald-500" />
                </div>
              </div>
              <div className="mt-4 text-sm text-muted-foreground">
                {financialStats?.upcomingBills ?? 0} upcoming bills
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 lg:w-auto lg:inline-grid">
            <TabsTrigger value="actions" className="gap-2">
              <Zap className="h-4 w-4" />
              <span className="hidden sm:inline">Action Feed</span>
              <span className="sm:hidden">Actions</span>
              {(actionStats?.pending ?? 0) > 0 && (
                <Badge variant="secondary" className="ml-1">
                  {actionStats?.pending}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="financial" className="gap-2">
              <DollarSign className="h-4 w-4" />
              <span className="hidden sm:inline">Financial Logic</span>
              <span className="sm:hidden">Finance</span>
              {(financialStats?.detectedAnomalies ?? 0) > 0 && (
                <Badge variant="destructive" className="ml-1">
                  {financialStats?.detectedAnomalies}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="authority" className="gap-2">
              <Shield className="h-4 w-4" />
              <span className="hidden sm:inline">Authority Matrix</span>
              <span className="sm:hidden">Authority</span>
              {(authorityStats?.pendingEscalations ?? 0) > 0 && (
                <Badge variant="destructive" className="ml-1">
                  {authorityStats?.pendingEscalations}
                </Badge>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="actions" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <ActionFeed householdId={DEFAULT_HOUSEHOLD_ID} />
              </div>
              <div className="space-y-6">
                {/* Quick Stats */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Action Statistics</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Completed</span>
                      <span className="font-medium text-green-500">{actionStats?.completed ?? 0}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Failed</span>
                      <span className="font-medium text-red-500">{actionStats?.failed ?? 0}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Cancelled</span>
                      <span className="font-medium text-gray-500">{actionStats?.cancelled ?? 0}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Overridden</span>
                      <span className="font-medium text-orange-500">{actionStats?.overridden ?? 0}</span>
                    </div>
                  </CardContent>
                </Card>

                {/* Override Patterns */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Override Learning</CardTitle>
                    <CardDescription>
                      HAI learns from your overrides
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Active Patterns</span>
                        <Badge variant="outline">{overrideStats?.activePatterns ?? 0}</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Avg Confidence Adj</span>
                        <Badge variant="outline">
                          {overrideStats?.avgConfidenceAdjustment 
                            ? `${(overrideStats.avgConfidenceAdjustment * 100).toFixed(1)}%`
                            : '0%'}
                        </Badge>
                      </div>
                      {overrideStats?.byType && (
                        <div className="pt-2 border-t">
                          <p className="text-xs text-muted-foreground mb-2">By Type:</p>
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            <span>Cancel: {overrideStats.byType.cancel}</span>
                            <span>Modify: {overrideStats.byType.modify}</span>
                            <span>Rollback: {overrideStats.byType.rollback}</span>
                            <span>Emergency: {overrideStats.byType.emergency_stop}</span>
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="financial" className="mt-6">
            <FinancialRules householdId={DEFAULT_HOUSEHOLD_ID} />
          </TabsContent>

          <TabsContent value="authority" className="mt-6">
            <AuthorityManagement 
              householdId={DEFAULT_HOUSEHOLD_ID} 
              currentMemberId={user?.id ?? 1}
            />
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
