import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Loader2, Search, Plus, CheckCircle, XCircle, AlertCircle, Sparkles } from "lucide-react";

export default function Frontier() {
  const [discoverEndpoint, setDiscoverEndpoint] = useState("");
  const [searchRequirement, setSearchRequirement] = useState("");
  const [isDiscovering, setIsDiscovering] = useState(false);
  const [isSearching, setIsSearching] = useState(false);

  const utils = trpc.useUtils();
  const { data: capabilities, isLoading } = trpc.frontier.getAllCapabilities.useQuery();
  const { data: stats } = trpc.frontier.getStatistics.useQuery();

  const discoverMutation = trpc.frontier.discoverService.useMutation({
    onSuccess: (result) => {
      toast.success(`Discovered: ${result.name}`, {
        description: `Found ${result.capabilities.length} capabilities`,
      });
      setIsDiscovering(false);
      setDiscoverEndpoint("");
    },
    onError: (error) => {
      toast.error("Discovery failed", { description: error.message });
      setIsDiscovering(false);
    },
  });

  const updateStatusMutation = trpc.frontier.updateCapabilityStatus.useMutation({
    onSuccess: () => {
      utils.frontier.getAllCapabilities.invalidate();
      utils.frontier.getStatistics.invalidate();
      toast.success("Capability status updated");
    },
  });

  const handleDiscover = async () => {
    if (!discoverEndpoint) {
      toast.error("Please enter an API endpoint");
      return;
    }
    setIsDiscovering(true);
    discoverMutation.mutate({ endpoint: discoverEndpoint });
  };

  const handleSearch = async () => {
    if (!searchRequirement) {
      toast.error("Please enter a requirement");
      return;
    }
    setIsSearching(true);
    // TODO: Implement search
    setIsSearching(false);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500/10 text-green-500 border-green-500/20";
      case "testing":
        return "bg-yellow-500/10 text-yellow-500 border-yellow-500/20";
      case "discovered":
        return "bg-blue-500/10 text-blue-500 border-blue-500/20";
      case "deprecated":
        return "bg-gray-500/10 text-gray-500 border-gray-500/20";
      default:
        return "bg-gray-500/10 text-gray-500 border-gray-500/20";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "active":
        return <CheckCircle className="h-4 w-4" />;
      case "testing":
        return <AlertCircle className="h-4 w-4" />;
      case "discovered":
        return <Sparkles className="h-4 w-4" />;
      case "deprecated":
        return <XCircle className="h-4 w-4" />;
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Frontier Engine</h1>
        <p className="text-muted-foreground">
          Discover new capabilities, integrate services, and expand HAI's abilities
        </p>
      </div>

      {/* Statistics */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Total Capabilities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Active</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-500">{stats.byStatus.active || 0}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Testing</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-500">{stats.byStatus.testing || 0}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Categories</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{Object.keys(stats.byCategory).length}</div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Discovery & Search */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>Discover Service</CardTitle>
            <CardDescription>Enter an API endpoint to discover its capabilities</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2">
              <Input
                placeholder="https://api.example.com"
                value={discoverEndpoint}
                onChange={(e) => setDiscoverEndpoint(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleDiscover()}
              />
              <Button onClick={handleDiscover} disabled={isDiscovering}>
                {isDiscovering ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                Discover
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Match Capabilities</CardTitle>
            <CardDescription>Describe what you need and find matching capabilities</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2">
              <Input
                placeholder="I need to send emails..."
                value={searchRequirement}
                onChange={(e) => setSearchRequirement(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              />
              <Button onClick={handleSearch} disabled={isSearching}>
                {isSearching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                Search
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Capabilities List */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Capabilities</CardTitle>
              <CardDescription>All discovered and registered capabilities</CardDescription>
            </div>
            <Dialog>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Capability
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Capability</DialogTitle>
                  <DialogDescription>Manually register a new capability</DialogDescription>
                </DialogHeader>
                {/* TODO: Add form */}
                <p className="text-sm text-muted-foreground">Form coming soon...</p>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : capabilities && capabilities.length > 0 ? (
            <div className="space-y-4">
              {capabilities.map((cap) => (
                <div
                  key={cap.id}
                  className="flex items-start justify-between p-4 border rounded-lg hover:bg-accent/50 transition-colors"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold">{cap.name}</h3>
                      <Badge variant="outline" className={getStatusColor(cap.status)}>
                        {getStatusIcon(cap.status)}
                        <span className="ml-1">{cap.status}</span>
                      </Badge>
                      <Badge variant="secondary">{cap.category}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{cap.description}</p>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span>Provider: {cap.provider}</span>
                      {cap.confidence && <span>Confidence: {cap.confidence}%</span>}
                      {cap.reliability && <span>Reliability: {cap.reliability}%</span>}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Select
                      value={cap.status}
                      onValueChange={(value) =>
                        updateStatusMutation.mutate({
                          id: cap.id,
                          status: value as "discovered" | "testing" | "active" | "deprecated",
                        })
                      }
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="discovered">Discovered</SelectItem>
                        <SelectItem value="testing">Testing</SelectItem>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="deprecated">Deprecated</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <p>No capabilities discovered yet</p>
              <p className="text-sm mt-2">Use the discovery tool above to find new capabilities</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
