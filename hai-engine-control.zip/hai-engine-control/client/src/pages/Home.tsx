import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Link2, Shield, TrendingUp, Activity, Plus, ExternalLink } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const { user } = useAuth();
  const { data: households } = trpc.households.list.useQuery();
  const selectedHouseholdId = households?.[0]?.id;
  const { data: services } = trpc.connectors.list.useQuery(
    { householdId: selectedHouseholdId! },
    { enabled: !!selectedHouseholdId }
  );
  const { data: twoFactorStatus } = trpc.authentication.get2FAStatus.useQuery();

  const totalServices = services?.length || 0;
  const activeServices = services?.filter(s => s.status === "connected").length || 0;
  const servicesWithAlerts = services?.filter(s => s.alertsEnabled).length || 0;
  const servicesWithImages = services?.filter(s => s.imageUrl).length || 0;

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Welcome Section */}
        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            Welcome back{user?.name ? `, ${user.name}` : ""}
          </h1>
          <p className="text-muted-foreground mt-2">
            Manage your services and security settings from one central hub
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Services</CardTitle>
              <Link2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalServices}</div>
              <p className="text-xs text-muted-foreground">
                {activeServices} active
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Health Monitoring</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{servicesWithAlerts}</div>
              <p className="text-xs text-muted-foreground">
                Services with alerts enabled
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Customization</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{servicesWithImages}</div>
              <p className="text-xs text-muted-foreground">
                Services with custom images
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Security</CardTitle>
              <Shield className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {twoFactorStatus?.enabled ? "2FA On" : "2FA Off"}
              </div>
              <p className="text-xs text-muted-foreground">
                Two-factor authentication
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>ServiceHub</CardTitle>
              <CardDescription>
                Manage all your connected services in one place
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Services</p>
                  <p className="text-2xl font-bold">{totalServices}</p>
                </div>
                <Link href="/connectors">
                  <Button>
                    <Link2 className="mr-2 h-4 w-4" />
                    Manage Services
                  </Button>
                </Link>
              </div>
              {totalServices === 0 && (
                <div className="rounded-lg border border-dashed p-4 text-center">
                  <p className="text-sm text-muted-foreground mb-3">
                    No services yet. Add your first service to get started.
                  </p>
                  <Link href="/connectors">
                    <Button variant="outline" size="sm">
                      <Plus className="mr-2 h-4 w-4" />
                      Add Service
                    </Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
              <CardDescription>
                Protect your account with enhanced security features
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Two-Factor Auth</p>
                  <p className="text-2xl font-bold">
                    {twoFactorStatus?.enabled ? "Enabled" : "Disabled"}
                  </p>
                </div>
                <Link href="/security">
                  <Button variant={twoFactorStatus?.enabled ? "outline" : "default"}>
                    <Shield className="mr-2 h-4 w-4" />
                    Security Settings
                  </Button>
                </Link>
              </div>
              {!twoFactorStatus?.enabled && (
                <div className="rounded-lg border border-dashed border-yellow-500/50 bg-yellow-500/10 p-4">
                  <p className="text-sm text-yellow-600 dark:text-yellow-400">
                    <strong>Recommendation:</strong> Enable 2FA to add an extra layer of security to your account.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Recent Services */}
        {services && services.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Recent Services</CardTitle>
              <CardDescription>
                Your most recently added services
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {services.slice(0, 5).map((service) => (
                  <div
                    key={service.id}
                    className="flex items-center justify-between p-3 rounded-lg border"
                  >
                    <div className="flex items-center gap-3">
                      {service.imageUrl && (
                        <img
                          src={service.imageUrl}
                          alt={service.name}
                          className="h-10 w-10 rounded object-contain"
                        />
                      )}
                      <div>
                        <p className="font-medium">{service.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {service.status === "connected" ? "Active" : "Inactive"}
                          {service.alertsEnabled && " • Alerts enabled"}
                        </p>
                      </div>
                    </div>
                    {service.url && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => window.open(service.url!, "_blank")}
                      >
                        <ExternalLink className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
