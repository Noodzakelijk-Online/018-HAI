import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  MessageSquare, Mail, Phone, MessageCircle, CheckCircle, Clock, 
  AlertCircle, TrendingUp, BarChart3, Users, Calendar, Bell 
} from 'lucide-react';
import { toast } from 'sonner';

export default function UnifiedCommunications() {
  const [activeTab, setActiveTab] = useState('overview');
  
  // Mock data - in real implementation, this would come from tRPC
  const platformStats = {
    whatsapp: { connected: true, processed: 245, sent: 208, autonomy: 85 },
    email: { connected: true, processed: 156, sent: 142, autonomy: 91 },
    sms: { connected: false, processed: 0, sent: 0, autonomy: 0 },
    slack: { connected: true, processed: 89, sent: 76, autonomy: 85 },
  };
  
  const totalStats = {
    processed: Object.values(platformStats).reduce((sum, p) => sum + p.processed, 0),
    sent: Object.values(platformStats).reduce((sum, p) => sum + p.sent, 0),
    autonomy: 87,
    escalated: 62,
  };
  
  const learningMetrics = {
    approvalRate: 0.89,
    confidenceAccuracy: 0.92,
    trend: '+5.2%',
  };
  
  const proactiveMessages = [
    { id: 1, type: 'meeting_confirmation', contact: 'John Smith', time: '2 hours', platform: 'whatsapp' },
    { id: 2, type: 'status_update', contact: 'Sarah Johnson', time: '4 hours', platform: 'email' },
    { id: 3, type: 'check_in', contact: 'Mike Davis', time: '1 day', platform: 'slack' },
  ];
  
  const commitments = [
    { id: 1, type: 'meeting', description: 'Team standup', due: '2 hours', status: 'pending' },
    { id: 2, type: 'task', description: 'Send project update', due: '4 hours', status: 'in_progress' },
    { id: 3, type: 'deadline', description: 'Submit report', due: '1 day', status: 'pending' },
  ];
  
  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case 'whatsapp': return <MessageSquare className="h-4 w-4" />;
      case 'email': return <Mail className="h-4 w-4" />;
      case 'sms': return <Phone className="h-4 w-4" />;
      case 'slack': return <MessageCircle className="h-4 w-4" />;
      default: return <MessageSquare className="h-4 w-4" />;
    }
  };
  
  const getPlatformColor = (platform: string) => {
    switch (platform) {
      case 'whatsapp': return 'bg-green-500';
      case 'email': return 'bg-blue-500';
      case 'sms': return 'bg-purple-500';
      case 'slack': return 'bg-pink-500';
      default: return 'bg-gray-500';
    }
  };
  
  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold">Unified Communications</h1>
          <p className="text-muted-foreground mt-2">
            Manage all your autonomous communication across platforms
          </p>
        </div>
        
        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="platforms">Platforms</TabsTrigger>
            <TabsTrigger value="learning">Learning</TabsTrigger>
            <TabsTrigger value="proactive">Proactive</TabsTrigger>
            <TabsTrigger value="commitments">Commitments</TabsTrigger>
          </TabsList>
          
          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">Total Processed</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{totalStats.processed}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Across all platforms
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">Successfully Sent</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{totalStats.sent}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {((totalStats.sent / totalStats.processed) * 100).toFixed(1)}% success rate
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">Autonomy Rate</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{totalStats.autonomy}%</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {totalStats.escalated} escalated for review
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium">Learning Progress</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <div className="text-2xl font-bold">{(learningMetrics.approvalRate * 100).toFixed(0)}%</div>
                    <Badge variant="outline" className="text-green-600">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      {learningMetrics.trend}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Approval rate
                  </p>
                </CardContent>
              </Card>
            </div>
            
            {/* Platform Status */}
            <Card>
              <CardHeader>
                <CardTitle>Platform Status</CardTitle>
                <CardDescription>Connected platforms and their performance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(platformStats).map(([platform, stats]) => (
                    <div key={platform} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${getPlatformColor(platform)}`}>
                          {getPlatformIcon(platform)}
                        </div>
                        <div>
                          <div className="font-medium capitalize">{platform}</div>
                          <div className="text-sm text-muted-foreground">
                            {stats.processed} processed · {stats.sent} sent
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <div className="text-sm font-medium">{stats.autonomy}%</div>
                          <div className="text-xs text-muted-foreground">Autonomy</div>
                        </div>
                        {stats.connected ? (
                          <Badge variant="outline" className="text-green-600">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Connected
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="text-gray-600">
                            <AlertCircle className="h-3 w-3 mr-1" />
                            Disconnected
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Escalation Queue</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold mb-2">{totalStats.escalated}</div>
                  <Button variant="outline" className="w-full" onClick={() => window.location.href = '/escalation-queue'}>
                    Review Messages
                  </Button>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Proactive Messages</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold mb-2">{proactiveMessages.length}</div>
                  <Button variant="outline" className="w-full" onClick={() => setActiveTab('proactive')}>
                    View Scheduled
                  </Button>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Commitments</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold mb-2">{commitments.length}</div>
                  <Button variant="outline" className="w-full" onClick={() => setActiveTab('commitments')}>
                    Manage
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Platforms Tab */}
          <TabsContent value="platforms" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Platform Management</CardTitle>
                <CardDescription>Configure and manage platform connectors</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(platformStats).map(([platform, stats]) => (
                    <div key={platform} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className={`p-2 rounded-lg ${getPlatformColor(platform)}`}>
                            {getPlatformIcon(platform)}
                          </div>
                          <div>
                            <div className="font-medium capitalize">{platform}</div>
                            <div className="text-sm text-muted-foreground">
                              {stats.connected ? 'Connected and active' : 'Not connected'}
                            </div>
                          </div>
                        </div>
                        <Button variant="outline" size="sm">
                          Configure
                        </Button>
                      </div>
                      
                      {stats.connected && (
                        <div className="grid grid-cols-3 gap-4 pt-4 border-t">
                          <div>
                            <div className="text-sm text-muted-foreground">Processed</div>
                            <div className="text-xl font-bold">{stats.processed}</div>
                          </div>
                          <div>
                            <div className="text-sm text-muted-foreground">Sent</div>
                            <div className="text-xl font-bold">{stats.sent}</div>
                          </div>
                          <div>
                            <div className="text-sm text-muted-foreground">Autonomy</div>
                            <div className="text-xl font-bold">{stats.autonomy}%</div>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Learning Tab */}
          <TabsContent value="learning" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Approval Rate</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{(learningMetrics.approvalRate * 100).toFixed(0)}%</div>
                  <Badge variant="outline" className="text-green-600 mt-2">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    {learningMetrics.trend}
                  </Badge>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Confidence Accuracy</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{(learningMetrics.confidenceAccuracy * 100).toFixed(0)}%</div>
                  <p className="text-sm text-muted-foreground mt-2">
                    Confidence matches outcome
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Total Feedback</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{totalStats.processed}</div>
                  <p className="text-sm text-muted-foreground mt-2">
                    Learning samples collected
                  </p>
                </CardContent>
              </Card>
            </div>
            
            <Card>
              <CardHeader>
                <CardTitle>Learning Insights</CardTitle>
                <CardDescription>Automatic improvements and recommendations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                      <div>
                        <div className="font-medium">WhatsApp confidence threshold optimized</div>
                        <div className="text-sm text-muted-foreground mt-1">
                          Adjusted auto-send threshold from 90% to 92% based on 50 samples with 95% confidence
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                      <div>
                        <div className="font-medium">Email tone adaptation improved</div>
                        <div className="text-sm text-muted-foreground mt-1">
                          Updated formal tone patterns for colleague relationships based on feedback
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-4 border rounded-lg bg-blue-50 dark:bg-blue-950">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5" />
                      <div>
                        <div className="font-medium">Recommendation: Review Slack escalation triggers</div>
                        <div className="text-sm text-muted-foreground mt-1">
                          15% of Slack escalations were unnecessary. Consider lowering escalation threshold.
                        </div>
                        <Button variant="outline" size="sm" className="mt-2">
                          Apply Recommendation
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Proactive Tab */}
          <TabsContent value="proactive" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Scheduled Proactive Messages</CardTitle>
                <CardDescription>Messages that will be sent automatically</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {proactiveMessages.map((message) => (
                    <div key={message.id} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`p-2 rounded-lg ${getPlatformColor(message.platform)}`}>
                            {message.type === 'meeting_confirmation' && <Calendar className="h-4 w-4" />}
                            {message.type === 'status_update' && <Bell className="h-4 w-4" />}
                            {message.type === 'check_in' && <Users className="h-4 w-4" />}
                          </div>
                          <div>
                            <div className="font-medium capitalize">{message.type.replace('_', ' ')}</div>
                            <div className="text-sm text-muted-foreground">
                              To: {message.contact} · via {message.platform}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Badge variant="outline">
                            <Clock className="h-3 w-3 mr-1" />
                            In {message.time}
                          </Badge>
                          <Button variant="outline" size="sm">
                            Preview
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Suggested Check-Ins</CardTitle>
                <CardDescription>People you haven't contacted recently</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Emily Chen</div>
                        <div className="text-sm text-muted-foreground">
                          Last contact: 15 days ago · Relationship: Friend
                        </div>
                      </div>
                      <Button variant="outline" size="sm">
                        Send Check-In
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Commitments Tab */}
          <TabsContent value="commitments" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Active Commitments</CardTitle>
                <CardDescription>Tasks, meetings, and promises being tracked</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {commitments.map((commitment) => (
                    <div key={commitment.id} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`p-2 rounded-lg ${
                            commitment.status === 'pending' ? 'bg-yellow-500' :
                            commitment.status === 'in_progress' ? 'bg-blue-500' :
                            'bg-green-500'
                          }`}>
                            {commitment.type === 'meeting' && <Calendar className="h-4 w-4" />}
                            {commitment.type === 'task' && <CheckCircle className="h-4 w-4" />}
                            {commitment.type === 'deadline' && <Clock className="h-4 w-4" />}
                          </div>
                          <div>
                            <div className="font-medium">{commitment.description}</div>
                            <div className="text-sm text-muted-foreground">
                              Due in {commitment.due} · {commitment.status.replace('_', ' ')}
                            </div>
                          </div>
                        </div>
                        <Button variant="outline" size="sm">
                          Mark Complete
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
