/**
 * Conversation Thread Viewer
 * 
 * Displays full message history for a WhatsApp conversation with:
 * - Message timeline with timestamps
 * - Sentiment indicators
 * - Media attachments
 * - Conversation insights
 */

import { useState } from 'react';
import { useRoute } from 'wouter';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Loader2, ArrowLeft, TrendingUp, MessageCircle, Calendar, Download, Bot, FileJson } from 'lucide-react';
import { toast } from 'sonner';
import { Link } from 'wouter';

export default function ConversationThread() {
  const [, params] = useRoute('/whatsapp/conversation/:contactId');
  const contactId = params?.contactId ? parseInt(params.contactId) : null;
  
  const [messageLimit, setMessageLimit] = useState(100);
  const [autoResponseEnabled, setAutoResponseEnabled] = useState(false);
  
  // Mutations
  const exportPDF = trpc.whatsapp.exportConversation.useMutation({
    onSuccess: (result) => {
      toast.success(`Exported ${result.messageCount} messages to PDF`);
      // Download file
      window.open(`/api/download/${result.fileName}`, '_blank');
    },
    onError: (error) => {
      toast.error(`Export failed: ${error.message}`);
    }
  });
  
  const exportJSON = trpc.whatsapp.exportConversation.useMutation({
    onSuccess: (result) => {
      toast.success(`Exported ${result.messageCount} messages to JSON`);
      window.open(`/api/download/${result.fileName}`, '_blank');
    },
    onError: (error) => {
      toast.error(`Export failed: ${error.message}`);
    }
  });
  
  const configureAutoResponse = trpc.whatsapp.configureAutoResponse.useMutation({
    onSuccess: () => {
      toast.success('Auto-response settings updated');
    },
    onError: (error) => {
      toast.error(`Failed to update settings: ${error.message}`);
    }
  });
  
  const handleAutoResponseToggle = (enabled: boolean) => {
    setAutoResponseEnabled(enabled);
    if (contactId) {
      configureAutoResponse.mutate({
        contactId,
        enabled,
        minConfidence: 0.7,
        learningMode: false
      });
    }
  };
  
  const handleExportPDF = () => {
    if (contactId) {
      exportPDF.mutate({
        contactId,
        format: 'pdf',
        includeMedia: true,
        includeInsights: true
      });
    }
  };
  
  const handleExportJSON = () => {
    if (contactId) {
      exportJSON.mutate({
        contactId,
        format: 'json',
        includeMedia: true,
        includeInsights: true
      });
    }
  };
  
  // Queries
  const { data: contact, isLoading: contactLoading } = trpc.whatsapp.getContact.useQuery(
    { contactId: contactId! },
    { enabled: !!contactId }
  );
  
  const { data: messages, isLoading: messagesLoading, refetch } = trpc.whatsapp.getMessages.useQuery(
    { contactId: contactId!, limit: messageLimit },
    { enabled: !!contactId }
  );
  
  const { data: insights, isLoading: insightsLoading } = trpc.whatsapp.getInsights.useQuery(
    { contactId: contactId! },
    { enabled: !!contactId }
  );
  
  // Mutations
  const sendMessage = trpc.whatsapp.sendMessage.useMutation({
    onSuccess: () => {
      toast({ title: 'Message sent successfully' });
      refetch();
    },
    onError: (error) => {
      toast({ title: 'Failed to send message', description: error.message, variant: 'destructive' });
    },
  });
  
  if (!contactId) {
    return (
      <div className="container mx-auto py-8">
        <div className="text-center text-muted-foreground">
          Invalid conversation ID
        </div>
      </div>
    );
  }
  
  if (contactLoading || messagesLoading || insightsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }
  
  if (!contact) {
    return (
      <div className="container mx-auto py-8">
        <div className="text-center text-muted-foreground">
          Contact not found
        </div>
      </div>
    );
  }
  
  const latestInsight = insights && insights.length > 0 ? insights[0] : null;
  const sortedMessages = messages ? [...messages].reverse() : []; // Oldest first
  
  const getSentimentColor = (sentiment: string | null) => {
    switch (sentiment) {
      case 'positive':
        return 'text-green-500';
      case 'negative':
        return 'text-red-500';
      default:
        return 'text-gray-500';
    }
  };
  
  const getSentimentBadge = (sentiment: string | null) => {
    switch (sentiment) {
      case 'positive':
        return <Badge variant="default" className="bg-green-500">Positive</Badge>;
      case 'negative':
        return <Badge variant="destructive">Negative</Badge>;
      default:
        return <Badge variant="secondary">Neutral</Badge>;
    }
  };
  
  return (
    <div className="container mx-auto py-8 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Link href="/whatsapp">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <Avatar>
              <AvatarFallback>{contact.name?.[0] || '?'}</AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-2xl font-bold">{contact.name || contact.phone}</h1>
              <p className="text-sm text-muted-foreground">
                {contact.phone}
                {contact.isGroup && <Badge variant="secondary" className="ml-2">Group</Badge>}
              </p>
            </div>
          </div>
        </div>
        <div className="text-right">
          <div className="text-sm text-muted-foreground">Relationship Score</div>
          <div className="text-2xl font-bold">
            {contact.relationshipScore ? parseFloat(contact.relationshipScore).toFixed(2) : 'N/A'}
          </div>
        </div>
      </div>
      
      {/* Insights Summary */}
      {latestInsight && (
        <Card>
          <CardHeader>
            <CardTitle>Conversation Insights</CardTitle>
            <CardDescription>
              AI-generated analysis of your conversation
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  <MessageCircle className="w-4 h-4" />
                  Total Messages
                </div>
                <div className="text-2xl font-bold">{latestInsight.messageCount}</div>
              </div>
              <div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  <TrendingUp className="w-4 h-4" />
                  Avg Sentiment
                </div>
                <div className="text-2xl font-bold">
                  {parseFloat(latestInsight.avgSentiment).toFixed(2)}
                </div>
              </div>
              <div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  <Calendar className="w-4 h-4" />
                  Period
                </div>
                <div className="text-sm">
                  {new Date(latestInsight.periodStart).toLocaleDateString()}
                </div>
              </div>
            </div>
            
            {latestInsight.summary && (
              <div className="mb-4">
                <div className="text-sm font-medium mb-2">Summary</div>
                <p className="text-sm text-muted-foreground">{latestInsight.summary}</p>
              </div>
            )}
            
            {latestInsight.topTopics && latestInsight.topTopics.length > 0 && (
              <div className="mb-4">
                <div className="text-sm font-medium mb-2">Top Topics</div>
                <div className="flex flex-wrap gap-2">
                  {latestInsight.topTopics.map((topic, i) => (
                    <Badge key={i} variant="outline">{topic}</Badge>
                  ))}
                </div>
              </div>
            )}
            
            {latestInsight.actionItems && latestInsight.actionItems.length > 0 && (
              <div>
                <div className="text-sm font-medium mb-2">Action Items</div>
                <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                  {latestInsight.actionItems.map((item, i) => (
                    <li key={i}>{item}</li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}
      
      {/* Message Timeline */}
      <Card>
        <CardHeader>
          <CardTitle>Message History</CardTitle>
          <CardDescription>
            {messages?.length || 0} messages loaded
            {messages && messages.length >= messageLimit && (
              <Button
                variant="link"
                size="sm"
                onClick={() => setMessageLimit(prev => prev + 100)}
                className="ml-2"
              >
                Load more
              </Button>
            )}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!messages || messages.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">
              No messages found
            </div>
          ) : (
            <div className="space-y-4 max-h-[600px] overflow-y-auto">
              {sortedMessages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.isFromMe ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[70%] rounded-lg p-3 ${
                      message.isFromMe
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted'
                    }`}
                  >
                    {/* Message content */}
                    {message.content && (
                      <div className="text-sm whitespace-pre-wrap break-words">
                        {message.content}
                      </div>
                    )}
                    
                    {/* Media attachment */}
                    {message.mediaType !== 'text' && message.mediaUrl && (
                      <div className="mt-2">
                        {message.mediaType === 'image' ? (
                          <img
                            src={message.mediaUrl}
                            alt="Media attachment"
                            className="max-w-full rounded"
                          />
                        ) : message.mediaType === 'video' ? (
                          <video
                            src={message.mediaUrl}
                            controls
                            className="max-w-full rounded"
                          />
                        ) : message.mediaType === 'audio' ? (
                          <audio src={message.mediaUrl} controls className="w-full" />
                        ) : (
                          <div className="text-xs text-muted-foreground">
                            📎 {message.mediaType} attachment
                          </div>
                        )}
                      </div>
                    )}
                    
                    {/* Metadata */}
                    <div className="flex items-center gap-2 mt-2 text-xs opacity-70">
                      <span>
                        {new Date(message.timestamp).toLocaleString()}
                      </span>
                      {message.sentiment && (
                        <span className={getSentimentColor(message.sentiment)}>
                          • {message.sentiment}
                        </span>
                      )}
                    </div>
                    
                    {/* Topics */}
                    {message.topics && message.topics.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {message.topics.slice(0, 3).map((topic, i) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {topic}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
