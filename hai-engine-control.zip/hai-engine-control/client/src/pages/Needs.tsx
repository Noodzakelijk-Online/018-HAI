import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  Heart, Shield, Users, Award, Sparkles, 
  TrendingUp, TrendingDown, Minus,
  AlertTriangle, CheckCircle2, Info
} from "lucide-react";

interface NeedAssessment {
  categoryId: number;
  categoryName: string;
  level: number;
  fulfillmentLevel: number;
  trend: "improving" | "stable" | "declining";
  indicators: any[];
  insights: string;
  recommendations: string[];
  criticalGaps: string[];
  color?: string;
  icon?: string;
}

const LEVEL_ICONS: Record<number, any> = {
  1: Heart,
  2: Shield,
  3: Users,
  4: Award,
  5: Sparkles,
};

const TREND_ICONS = {
  improving: TrendingUp,
  stable: Minus,
  declining: TrendingDown,
};

export default function Needs() {
  const [selectedLevel, setSelectedLevel] = useState<number | null>(null);
  
  const { data: assessments, isLoading, refetch } = trpc.needs.getUserNeeds.useQuery();
  const runAssessment = trpc.needs.runAssessment.useMutation({
    onSuccess: () => {
      refetch();
    },
  });

  const handleRunAssessment = () => {
    runAssessment.mutate();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading need assessments...</p>
        </div>
      </div>
    );
  }

  const needsData: NeedAssessment[] = assessments || [];
  const selectedNeed = selectedLevel ? needsData.find(n => n.level === selectedLevel) : null;

  // Calculate overall well-being score
  const overallScore = needsData.length > 0
    ? needsData.reduce((sum, n) => sum + n.fulfillmentLevel, 0) / needsData.length
    : 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Maslow's Hierarchy of Needs</h1>
          <p className="text-muted-foreground mt-1">
            Understanding your well-being across all life dimensions
          </p>
        </div>
        <Button 
          onClick={handleRunAssessment}
          disabled={runAssessment.isPending}
        >
          {runAssessment.isPending ? "Assessing..." : "Run Assessment"}
        </Button>
      </div>

      {/* Overall Well-being Score */}
      <Card>
        <CardHeader>
          <CardTitle>Overall Well-being Score</CardTitle>
          <CardDescription>
            Composite score across all need categories
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-2xl font-bold">{overallScore.toFixed(1)}%</span>
              <Badge variant={overallScore >= 70 ? "default" : overallScore >= 50 ? "secondary" : "destructive"}>
                {overallScore >= 70 ? "Healthy" : overallScore >= 50 ? "Moderate" : "Needs Attention"}
              </Badge>
            </div>
            <Progress value={overallScore} className="h-3" />
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pyramid Visualization */}
        <Card>
          <CardHeader>
            <CardTitle>Hierarchy Pyramid</CardTitle>
            <CardDescription>
              Click on a level to see details
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {[...needsData].reverse().map((need) => {
                const Icon = LEVEL_ICONS[need.level];
                const width = 20 + (6 - need.level) * 16; // Wider at bottom
                const isSelected = selectedLevel === need.level;
                const color = need.color || "#3B82F6";
                
                return (
                  <button
                    key={need.level}
                    onClick={() => setSelectedLevel(need.level)}
                    className={`w-full transition-all ${isSelected ? "scale-105" : "hover:scale-102"}`}
                    style={{ maxWidth: `${width}%`, margin: "0 auto", display: "block" }}
                  >
                    <div
                      className={`p-4 rounded-lg border-2 ${
                        isSelected ? "border-primary shadow-lg" : "border-border"
                      }`}
                      style={{ 
                        backgroundColor: `${color}15`,
                        borderColor: isSelected ? color : undefined,
                      }}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Icon className="w-5 h-5" style={{ color }} />
                          <span className="font-semibold">{need.categoryName}</span>
                        </div>
                        <Badge variant={need.fulfillmentLevel >= 70 ? "default" : "secondary"}>
                          {need.fulfillmentLevel.toFixed(0)}%
                        </Badge>
                      </div>
                      <Progress 
                        value={need.fulfillmentLevel} 
                        className="h-2"
                        style={{
                          backgroundColor: `${color}30`,
                        }}
                      />
                    </div>
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Detailed View */}
        <Card>
          <CardHeader>
            <CardTitle>
              {selectedNeed ? selectedNeed.categoryName : "Select a Level"}
            </CardTitle>
            <CardDescription>
              {selectedNeed ? `Level ${selectedNeed.level} - ${selectedNeed.fulfillmentLevel.toFixed(0)}% fulfilled` : "Click on a pyramid level to see details"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {selectedNeed ? (
              <div className="space-y-4">
                {/* Trend */}
                <div className="flex items-center gap-2">
                  {(() => {
                    const TrendIcon = TREND_ICONS[selectedNeed.trend];
                    return (
                      <>
                        <TrendIcon className={`w-5 h-5 ${
                          selectedNeed.trend === "improving" ? "text-green-600" :
                          selectedNeed.trend === "declining" ? "text-red-600" :
                          "text-gray-600"
                        }`} />
                        <span className="text-sm font-medium capitalize">{selectedNeed.trend}</span>
                      </>
                    );
                  })()}
                </div>

                {/* Insights */}
                <div className="bg-blue-50 dark:bg-blue-950 p-3 rounded-lg">
                  <div className="flex items-start gap-2">
                    <Info className="w-5 h-5 text-blue-600 mt-0.5" />
                    <p className="text-sm">{selectedNeed.insights}</p>
                  </div>
                </div>

                {/* Critical Gaps */}
                {selectedNeed.criticalGaps && selectedNeed.criticalGaps.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="font-semibold text-sm flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-orange-600" />
                      Critical Gaps
                    </h4>
                    <ul className="space-y-1">
                      {selectedNeed.criticalGaps.map((gap: string, idx: number) => (
                        <li key={idx} className="text-sm text-muted-foreground pl-6">
                          • {gap}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Recommendations */}
                {selectedNeed.recommendations && selectedNeed.recommendations.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="font-semibold text-sm flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600" />
                      Recommendations
                    </h4>
                    <ul className="space-y-1">
                      {selectedNeed.recommendations.map((rec: string, idx: number) => (
                        <li key={idx} className="text-sm text-muted-foreground pl-6">
                          • {rec}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Indicators */}
                {selectedNeed.indicators && selectedNeed.indicators.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="font-semibold text-sm">Indicators</h4>
                    <div className="space-y-2">
                      {selectedNeed.indicators.map((indicator: any, idx: number) => (
                        <div key={idx} className="space-y-1">
                          <div className="flex items-center justify-between text-sm">
                            <span>{indicator.name}</span>
                            <span className="text-muted-foreground">
                              {indicator.current} / {indicator.target}
                            </span>
                          </div>
                          <Progress value={indicator.fulfillment} className="h-1.5" />
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center text-muted-foreground py-8">
                <Info className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>Select a pyramid level to view detailed insights</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* All Levels Summary */}
      <Card>
        <CardHeader>
          <CardTitle>All Levels Summary</CardTitle>
          <CardDescription>
            Complete overview of your need fulfillment
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {needsData.map((need) => {
              const Icon = LEVEL_ICONS[need.level];
              const TrendIcon = TREND_ICONS[need.trend];
              
              return (
                <div key={need.level} className="flex items-center gap-4 p-3 rounded-lg border">
                  <Icon className="w-6 h-6" style={{ color: need.color }} />
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold">{need.categoryName}</span>
                      <div className="flex items-center gap-2">
                        <TrendIcon className={`w-4 h-4 ${
                          need.trend === "improving" ? "text-green-600" :
                          need.trend === "declining" ? "text-red-600" :
                          "text-gray-600"
                        }`} />
                        <span className="text-sm font-medium">{need.fulfillmentLevel.toFixed(0)}%</span>
                      </div>
                    </div>
                    <Progress value={need.fulfillmentLevel} className="h-2" />
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
