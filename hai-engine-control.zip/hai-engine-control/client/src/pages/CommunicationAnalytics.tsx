import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { 
  TrendingUp, TrendingDown, BarChart3, LineChart, PieChart, 
  Clock, CheckCircle, AlertCircle, Users, MessageSquare 
} from 'lucide-react';

export default function CommunicationAnalytics() {
  const [timeRange, setTimeRange] = useState('7d');
  const [selectedPlatform, setSelectedPlatform] = useState('all');
  
  // Fetch communication analytics from backend
  const { data: analyticsData } = trpc.autonomousCommunication.getAnalytics.useQuery(
    { timeRange },
    { refetchInterval: 30000 }
  );
  
  // Use real data if available, fallback to defaults
  const overallMetrics = analyticsData?.overall || {
    totalProcessed: 0,
    successRate: 0,
    autonomyRate: 0,
    avgResponseTime: 0,
    trend: {
      processed: 0,
      successRate: 0,
      autonomyRate: 0,
      responseTime: 0,
    },
  };
  
  const platformData = [
    { name: 'WhatsApp', messages: 456, success: 96, autonomy: 89, avgTime: 2.8, color: 'bg-green-500' },
    { name: 'Email', messages: 342, success: 95, autonomy: 92, avgTime: 4.1, color: 'bg-blue-500' },
    { name: 'Slack', messages: 234, success: 91, autonomy: 84, avgTime: 2.5, color: 'bg-pink-500' },
    { name: 'SMS', messages: 156, success: 93, autonomy: 86, avgTime: 3.2, color: 'bg-purple-500' },
    { name: 'Twitter', messages: 59, success: 89, autonomy: 78, avgTime: 4.8, color: 'bg-sky-500' },
  ];
  
  const confidenceDistribution = [
    { range: '90-100%', count: 687, percentage: 55.1, color: 'bg-green-500' },
    { range: '80-90%', count: 312, percentage: 25.0, color: 'bg-blue-500' },
    { range: '70-80%', count: 187, percentage: 15.0, color: 'bg-yellow-500' },
    { range: '<70%', count: 61, percentage: 4.9, color: 'bg-red-500' },
  ];
  
  const learningProgress = [
    { week: 'Week 1', approvalRate: 78, confidenceAccuracy: 82 },
    { week: 'Week 2', approvalRate: 82, confidenceAccuracy: 85 },
    { week: 'Week 3', approvalRate: 85, confidenceAccuracy: 88 },
    { week: 'Week 4', approvalRate: 89, confidenceAccuracy: 92 },
  ];
  
  const relationshipMetrics = [
    { type: 'Family', messages: 234, approvalRate: 92, avgConfidence: 91 },
    { type: 'Friends', messages: 456, approvalRate: 89, avgConfidence: 88 },
    { type: 'Colleagues', messages: 342, approvalRate: 87, avgConfidence: 86 },
    { type: 'Clients', messages: 156, approvalRate: 85, avgConfidence: 84 },
    { type: 'Acquaintances', messages: 59, approvalRate: 78, avgConfidence: 79 },
  ];
  
  const hourlyActivity = [
    { hour: '00:00', messages: 12 },
    { hour: '03:00', messages: 5 },
    { hour: '06:00', messages: 34 },
    { hour: '09:00', messages: 156 },
    { hour: '12:00', messages: 234 },
    { hour: '15:00', messages: 198 },
    { hour: '18:00', messages: 267 },
    { hour: '21:00', messages: 145 },
  ];
  
  const getTrendIcon = (trend: number) => {
    if (trend > 0) {
      return <TrendingUp className="h-4 w-4 text-green-600" />;
    } else if (trend < 0) {
      return <TrendingDown className="h-4 w-4 text-red-600" />;
    }
    return null;
  };
  
  const getTrendColor = (trend: number) => {
    return trend > 0 ? 'text-green-600' : trend < 0 ? 'text-red-600' : 'text-gray-600';
  };
  
  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Communication Analytics</h1>
            <p className="text-muted-foreground mt-2">
              Comprehensive insights into autonomous communication performance
            </p>
          </div>
          
          <div className="flex items-center gap-4">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select time range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="24h">Last 24 hours</SelectItem>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
                <SelectItem value="90d">Last 90 days</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={selectedPlatform} onValueChange={setSelectedPlatform}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select platform" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Platforms</SelectItem>
                <SelectItem value="whatsapp">WhatsApp</SelectItem>
                <SelectItem value="email">Email</SelectItem>
                <SelectItem value="slack">Slack</SelectItem>
                <SelectItem value="sms">SMS</SelectItem>
                <SelectItem value="twitter">Twitter</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        {/* Overview Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center justify-between">
                Total Processed
                {getTrendIcon(overallMetrics.trend.processed)}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overallMetrics.totalProcessed.toLocaleString()}</div>
              <p className={`text-xs mt-1 ${getTrendColor(overallMetrics.trend.processed)}`}>
                {overallMetrics.trend.processed > 0 ? '+' : ''}{overallMetrics.trend.processed}% from last period
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center justify-between">
                Success Rate
                {getTrendIcon(overallMetrics.trend.successRate)}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overallMetrics.successRate}%</div>
              <p className={`text-xs mt-1 ${getTrendColor(overallMetrics.trend.successRate)}`}>
                {overallMetrics.trend.successRate > 0 ? '+' : ''}{overallMetrics.trend.successRate}% from last period
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center justify-between">
                Autonomy Rate
                {getTrendIcon(overallMetrics.trend.autonomyRate)}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overallMetrics.autonomyRate}%</div>
              <p className={`text-xs mt-1 ${getTrendColor(overallMetrics.trend.autonomyRate)}`}>
                {overallMetrics.trend.autonomyRate > 0 ? '+' : ''}{overallMetrics.trend.autonomyRate}% from last period
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center justify-between">
                Avg Response Time
                {getTrendIcon(-overallMetrics.trend.responseTime)} {/* Negative trend is good for response time */}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overallMetrics.avgResponseTime}m</div>
              <p className={`text-xs mt-1 ${getTrendColor(-overallMetrics.trend.responseTime)}`}>
                {overallMetrics.trend.responseTime > 0 ? '+' : ''}{overallMetrics.trend.responseTime}m from last period
              </p>
            </CardContent>
          </Card>
        </div>
        
        {/* Tabs */}
        <Tabs defaultValue="platforms" className="space-y-6">
          <TabsList>
            <TabsTrigger value="platforms">Platforms</TabsTrigger>
            <TabsTrigger value="confidence">Confidence</TabsTrigger>
            <TabsTrigger value="learning">Learning</TabsTrigger>
            <TabsTrigger value="relationships">Relationships</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
          </TabsList>
          
          {/* Platform Analytics */}
          <TabsContent value="platforms" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Platform Performance Comparison</CardTitle>
                <CardDescription>Message volume and success metrics by platform</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {platformData.map((platform) => (
                    <div key={platform.name} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`w-3 h-3 rounded-full ${platform.color}`} />
                          <span className="font-medium">{platform.name}</span>
                          <Badge variant="outline">{platform.messages} messages</Badge>
                        </div>
                        <div className="flex items-center gap-6 text-sm">
                          <div>
                            <span className="text-muted-foreground">Success:</span>
                            <span className="ml-2 font-medium">{platform.success}%</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Autonomy:</span>
                            <span className="ml-2 font-medium">{platform.autonomy}%</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Avg Time:</span>
                            <span className="ml-2 font-medium">{platform.avgTime}m</span>
                          </div>
                        </div>
                      </div>
                      
                      {/* Progress bars */}
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <div className="w-20 text-xs text-muted-foreground">Success</div>
                          <div className="flex-1 h-2 bg-gray-200 dark:bg-gray-800 rounded-full overflow-hidden">
                            <div 
                              className={`h-full ${platform.color}`}
                              style={{ width: `${platform.success}%` }}
                            />
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-20 text-xs text-muted-foreground">Autonomy</div>
                          <div className="flex-1 h-2 bg-gray-200 dark:bg-gray-800 rounded-full overflow-hidden">
                            <div 
                              className={`h-full ${platform.color} opacity-70`}
                              style={{ width: `${platform.autonomy}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Message Volume by Platform</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {platformData.map((platform) => (
                      <div key={platform.name} className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`w-3 h-3 rounded-full ${platform.color}`} />
                          <span>{platform.name}</span>
                        </div>
                        <span className="font-bold">{platform.messages}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Average Response Time</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {platformData.map((platform) => (
                      <div key={platform.name} className="space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <span>{platform.name}</span>
                          <span className="font-medium">{platform.avgTime}m</span>
                        </div>
                        <div className="h-2 bg-gray-200 dark:bg-gray-800 rounded-full overflow-hidden">
                          <div 
                            className={`h-full ${platform.color}`}
                            style={{ width: `${(platform.avgTime / 5) * 100}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Confidence Distribution */}
          <TabsContent value="confidence" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Confidence Score Distribution</CardTitle>
                <CardDescription>Distribution of confidence scores across all messages</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {confidenceDistribution.map((range) => (
                    <div key={range.range} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`w-3 h-3 rounded-full ${range.color}`} />
                          <span className="font-medium">{range.range}</span>
                        </div>
                        <div className="flex items-center gap-4">
                          <span className="text-sm text-muted-foreground">{range.count} messages</span>
                          <span className="font-bold">{range.percentage}%</span>
                        </div>
                      </div>
                      <div className="h-3 bg-gray-200 dark:bg-gray-800 rounded-full overflow-hidden">
                        <div 
                          className={`h-full ${range.color}`}
                          style={{ width: `${range.percentage}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Confidence vs Outcome</CardTitle>
                <CardDescription>How well confidence scores predict actual outcomes</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 border rounded-lg">
                      <div className="text-sm text-muted-foreground">High Confidence (≥90%)</div>
                      <div className="text-2xl font-bold mt-2">96.2%</div>
                      <div className="text-xs text-green-600 mt-1">Approved without changes</div>
                    </div>
                    <div className="p-4 border rounded-lg">
                        <div className="text-sm text-muted-foreground">Low Confidence (&lt;70%)</div>
                      <div className="text-2xl font-bold mt-2">78.4%</div>
                      <div className="text-xs text-yellow-600 mt-1">Required review or edits</div>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-blue-600 mt-0.5" />
                      <div>
                        <div className="font-medium">Confidence Accuracy: 92.3%</div>
                        <div className="text-sm text-muted-foreground mt-1">
                          Confidence scores accurately predict outcomes 92.3% of the time
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Learning Progress */}
          <TabsContent value="learning" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Learning Progress Over Time</CardTitle>
                <CardDescription>Improvement in approval rate and confidence accuracy</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {learningProgress.map((week, index) => (
                    <div key={week.week} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{week.week}</span>
                        <div className="flex items-center gap-6 text-sm">
                          <div>
                            <span className="text-muted-foreground">Approval:</span>
                            <span className="ml-2 font-medium">{week.approvalRate}%</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Accuracy:</span>
                            <span className="ml-2 font-medium">{week.confidenceAccuracy}%</span>
                          </div>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="h-2 bg-gray-200 dark:bg-gray-800 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-green-500"
                            style={{ width: `${week.approvalRate}%` }}
                          />
                        </div>
                        <div className="h-2 bg-gray-200 dark:bg-gray-800 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-blue-500"
                            style={{ width: `${week.confidenceAccuracy}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="mt-6 p-4 bg-green-50 dark:bg-green-950 rounded-lg">
                  <div className="flex items-start gap-3">
                    <TrendingUp className="h-5 w-5 text-green-600 mt-0.5" />
                    <div>
                      <div className="font-medium">Significant Improvement</div>
                      <div className="text-sm text-muted-foreground mt-1">
                        Approval rate improved by 11% and confidence accuracy by 10% over 4 weeks
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Relationship Analytics */}
          <TabsContent value="relationships" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Performance by Relationship Type</CardTitle>
                <CardDescription>Success metrics across different relationship categories</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {relationshipMetrics.map((rel) => (
                    <div key={rel.type} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <div className="font-medium">{rel.type}</div>
                          <div className="text-sm text-muted-foreground">{rel.messages} messages</div>
                        </div>
                        <div className="flex items-center gap-6 text-sm">
                          <div>
                            <span className="text-muted-foreground">Approval:</span>
                            <span className="ml-2 font-medium">{rel.approvalRate}%</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Avg Confidence:</span>
                            <span className="ml-2 font-medium">{rel.avgConfidence}%</span>
                          </div>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-1">
                          <div className="text-xs text-muted-foreground">Approval Rate</div>
                          <div className="h-2 bg-gray-200 dark:bg-gray-800 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-green-500"
                              style={{ width: `${rel.approvalRate}%` }}
                            />
                          </div>
                        </div>
                        <div className="space-y-1">
                          <div className="text-xs text-muted-foreground">Avg Confidence</div>
                          <div className="h-2 bg-gray-200 dark:bg-gray-800 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-blue-500"
                              style={{ width: `${rel.avgConfidence}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Activity Patterns */}
          <TabsContent value="activity" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Hourly Activity Pattern</CardTitle>
                <CardDescription>Message volume throughout the day</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {hourlyActivity.map((hour) => (
                    <div key={hour.hour} className="flex items-center gap-4">
                      <div className="w-16 text-sm text-muted-foreground">{hour.hour}</div>
                      <div className="flex-1 h-8 bg-gray-200 dark:bg-gray-800 rounded overflow-hidden">
                        <div 
                          className="h-full bg-blue-500 flex items-center justify-end pr-2"
                          style={{ width: `${(hour.messages / 267) * 100}%` }}
                        >
                          {hour.messages > 50 && (
                            <span className="text-xs font-medium text-white">{hour.messages}</span>
                          )}
                        </div>
                      </div>
                      {hour.messages <= 50 && (
                        <div className="w-12 text-sm font-medium">{hour.messages}</div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
