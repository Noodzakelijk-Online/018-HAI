import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { Shield, Lock, AlertTriangle, CheckCircle, Key } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { TwoFactorSetup } from "@/components/TwoFactorSetup";

export default function SecuritySettings() {
  const [isChangePasswordOpen, setIsChangePasswordOpen] = useState(false);
  const [isSetPasswordOpen, setIsSetPasswordOpen] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const utils = trpc.useUtils();
  const { data: securityStatus, isLoading: statusLoading } = trpc.authentication.getSecurityStatus.useQuery();
  const { data: hasPasswordData } = trpc.authentication.hasPassword.useQuery();

  const changePasswordMutation = trpc.authentication.changePassword.useMutation({
    onSuccess: () => {
      toast.success("Password changed successfully");
      setIsChangePasswordOpen(false);
      resetForm();
      utils.authentication.getSecurityStatus.invalidate();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const setPasswordMutation = trpc.authentication.setPassword.useMutation({
    onSuccess: () => {
      toast.success("Password set successfully");
      setIsSetPasswordOpen(false);
      resetForm();
      utils.authentication.hasPassword.invalidate();
      utils.authentication.getSecurityStatus.invalidate();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const resetForm = () => {
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
  };

  const handleChangePassword = () => {
    if (!currentPassword || !newPassword) {
      toast.error("Please fill in all fields");
      return;
    }

    if (newPassword !== confirmPassword) {
      toast.error("New passwords do not match");
      return;
    }

    if (newPassword.length < 8) {
      toast.error("Password must be at least 8 characters");
      return;
    }

    changePasswordMutation.mutate({
      currentPassword,
      newPassword,
    });
  };

  const handleSetPassword = () => {
    if (!newPassword) {
      toast.error("Please enter a password");
      return;
    }

    if (newPassword !== confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }

    if (newPassword.length < 8) {
      toast.error("Password must be at least 8 characters");
      return;
    }

    setPasswordMutation.mutate({
      newPassword,
    });
  };

  const getStatusBadge = () => {
    if (statusLoading || !securityStatus) return null;

    if (securityStatus.isLocked) {
      return (
        <Badge variant="destructive" className="gap-1">
          <AlertTriangle className="h-3 w-3" />
          Account Locked
        </Badge>
      );
    }

    if (securityStatus.failedAttempts > 0) {
      return (
        <Badge className="bg-yellow-600 gap-1">
          <AlertTriangle className="h-3 w-3" />
          {securityStatus.attemptsRemaining} Attempts Remaining
        </Badge>
      );
    }

    return (
      <Badge className="bg-green-600 gap-1">
        <CheckCircle className="h-3 w-3" />
        Secure
      </Badge>
    );
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Security Settings</h1>
          <p className="text-muted-foreground mt-2">
            Manage your account security and authentication
          </p>
        </div>

        {/* Account Status */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Shield className="h-6 w-6 text-primary" />
                <div>
                  <CardTitle>Account Security Status</CardTitle>
                  <CardDescription>Current security state of your account</CardDescription>
                </div>
              </div>
              {getStatusBadge()}
            </div>
          </CardHeader>
          <CardContent>
            {statusLoading ? (
              <p className="text-muted-foreground">Loading security status...</p>
            ) : securityStatus ? (
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Failed Login Attempts</p>
                  <p className="text-2xl font-bold">{securityStatus.failedAttempts}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Attempts Remaining</p>
                  <p className="text-2xl font-bold">{securityStatus.attemptsRemaining}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Account Status</p>
                  <p className="text-2xl font-bold">
                    {securityStatus.isLocked ? "Locked" : "Active"}
                  </p>
                </div>
              </div>
            ) : null}

            {securityStatus?.isLocked && securityStatus.lockedUntil && (
              <div className="mt-4 p-4 bg-destructive/10 border border-destructive rounded-lg">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-destructive mt-0.5" />
                  <div>
                    <p className="font-semibold text-destructive">Account Temporarily Locked</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Your account has been locked due to multiple failed login attempts.
                      It will be automatically unlocked at{" "}
                      {new Date(securityStatus.lockedUntil).toLocaleString()}.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Password Management */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <Lock className="h-6 w-6 text-primary" />
              <div>
                <CardTitle>Password Management</CardTitle>
                <CardDescription>
                  {hasPasswordData?.hasPassword
                    ? "Change your password or manage authentication methods"
                    : "Set up password authentication for your account"}
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {hasPasswordData?.hasPassword ? (
              <>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Key className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="font-medium">Password Authentication</p>
                      <p className="text-sm text-muted-foreground">Enabled</p>
                    </div>
                  </div>
                  <Dialog open={isChangePasswordOpen} onOpenChange={setIsChangePasswordOpen}>
                    <DialogTrigger asChild>
                      <Button variant="outline">Change Password</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Change Password</DialogTitle>
                        <DialogDescription>
                          Enter your current password and choose a new one
                        </DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid gap-2">
                          <Label htmlFor="current">Current Password</Label>
                          <Input
                            id="current"
                            type="password"
                            value={currentPassword}
                            onChange={(e) => setCurrentPassword(e.target.value)}
                          />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="new">New Password</Label>
                          <Input
                            id="new"
                            type="password"
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                          />
                          <p className="text-xs text-muted-foreground">
                            Minimum 8 characters
                          </p>
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="confirm">Confirm New Password</Label>
                          <Input
                            id="confirm"
                            type="password"
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                          />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button
                          variant="outline"
                          onClick={() => {
                            setIsChangePasswordOpen(false);
                            resetForm();
                          }}
                        >
                          Cancel
                        </Button>
                        <Button
                          onClick={handleChangePassword}
                          disabled={changePasswordMutation.isPending}
                        >
                          {changePasswordMutation.isPending ? "Changing..." : "Change Password"}
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </>
            ) : (
              <div className="space-y-4">
                <div className="p-4 bg-muted rounded-lg">
                  <p className="text-sm text-muted-foreground">
                    You're currently using OAuth authentication. Set up a password to enable
                    password-based login as a backup authentication method.
                  </p>
                </div>
                <Dialog open={isSetPasswordOpen} onOpenChange={setIsSetPasswordOpen}>
                  <DialogTrigger asChild>
                    <Button>
                      <Key className="mr-2 h-4 w-4" />
                      Set Up Password
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Set Up Password</DialogTitle>
                      <DialogDescription>
                        Create a password for your account
                      </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      <div className="grid gap-2">
                        <Label htmlFor="new-pass">New Password</Label>
                        <Input
                          id="new-pass"
                          type="password"
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                        />
                        <p className="text-xs text-muted-foreground">
                          Minimum 8 characters
                        </p>
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="confirm-pass">Confirm Password</Label>
                        <Input
                          id="confirm-pass"
                          type="password"
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button
                        variant="outline"
                        onClick={() => {
                          setIsSetPasswordOpen(false);
                          resetForm();
                        }}
                      >
                        Cancel
                      </Button>
                      <Button
                        onClick={handleSetPassword}
                        disabled={setPasswordMutation.isPending}
                      >
                        {setPasswordMutation.isPending ? "Setting..." : "Set Password"}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Two-Factor Authentication */}
        <TwoFactorSetup />

        {/* Security Best Practices */}
        <Card>
          <CardHeader>
            <CardTitle>Security Best Practices</CardTitle>
          </CardHeader> <CardContent>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span>Use a strong, unique password with at least 8 characters</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span>After 3 failed login attempts, your account will be locked for 30 minutes</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span>Change your password regularly and never share it with others</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span>Use OAuth authentication when possible for enhanced security</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span>Enable two-factor authentication (2FA) for maximum account protection</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
