import { useState, useEffect, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Network, GitBranch, Clock, Brain, Search, Sparkles } from "lucide-react";
import { GraphVisualization } from "@/components/GraphVisualization";
import { toast } from "sonner";

/**
 * Knowledge Graph Visualization Page
 * 
 * Features:
 * - Interactive graph visualization
 * - Entity clustering
 * - Temporal knowledge tracking
 * - Inference rules
 * - Path finding
 */
export default function KnowledgeGraph() {
  const [activeTab, setActiveTab] = useState("graph");
  const [selectedEntityId, setSelectedEntityId] = useState<number | undefined>();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedNodeId, setSelectedNodeId] = useState<string | undefined>();

  // Queries
  const { data: visualizationData, isLoading: loadingViz } = trpc.knowledgeGraph.getVisualizationData.useQuery({
    maxNodes: 100,
    centerEntityId: selectedEntityId,
    depth: 2,
  });

  const { data: entities, isLoading: loadingEntities } = trpc.knowledgeGraph.getEntities.useQuery({
    search: searchTerm,
    limit: 100,
  });

  const { data: clusters, isLoading: loadingClusters } = trpc.knowledgeGraph.detectClusters.useQuery({
    minClusterSize: 3,
    maxClusters: 10,
  });

  const { data: centrality, isLoading: loadingCentrality } = trpc.knowledgeGraph.calculateCentrality.useQuery({
    measure: 'degree',
  });

  const { data: entityTypes } = trpc.knowledgeGraph.getEntityTypes.useQuery();
  const { data: relationshipTypes } = trpc.knowledgeGraph.getRelationshipTypes.useQuery();

  // Mutations
  const applyInference = trpc.knowledgeGraph.applyInferenceRules.useMutation({
    onSuccess: (data) => {
      toast.success(`Applied inference rules: ${data.newRelationships} new relationships discovered`);
    },
    onError: (error) => {
      toast.error(`Failed to apply inference rules: ${error.message}`);
    },
  });

  // Graph visualization is now handled by GraphVisualization component

  const getNodeColor = (type: string): string => {
    const colors: Record<string, string> = {
      person: '#3b82f6',
      place: '#10b981',
      organization: '#f59e0b',
      event: '#ef4444',
      concept: '#8b5cf6',
      default: '#6b7280',
    };
    return colors[type] || colors.default;
  };

  const handleApplyInference = () => {
    applyInference.mutate({});
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Knowledge Graph</h1>
          <p className="text-muted-foreground mt-1">
            Visualize and explore entity relationships, patterns, and insights
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={handleApplyInference}
            disabled={applyInference.isPending}
            variant="outline"
          >
            {applyInference.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Applying...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" />
                Apply Inference Rules
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Total Entities</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{entities?.length || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Entity Types</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{entityTypes?.length || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Clusters</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{clusters?.length || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Relationships</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{visualizationData?.edges.length || 0}</div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="graph">
            <Network className="mr-2 h-4 w-4" />
            Graph View
          </TabsTrigger>
          <TabsTrigger value="clusters">
            <GitBranch className="mr-2 h-4 w-4" />
            Clusters
          </TabsTrigger>
          <TabsTrigger value="centrality">
            <Brain className="mr-2 h-4 w-4" />
            Centrality
          </TabsTrigger>
          <TabsTrigger value="temporal">
            <Clock className="mr-2 h-4 w-4" />
            Temporal
          </TabsTrigger>
        </TabsList>

        {/* Graph View */}
        <TabsContent value="graph" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Entity Relationship Graph</CardTitle>
              <CardDescription>
                Interactive visualization of entities and their relationships
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loadingViz ? (
                <div className="flex items-center justify-center h-[500px]">
                  <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              ) : visualizationData ? (
                <GraphVisualization
                  nodes={visualizationData.nodes.map(n => ({
                    id: n.id.toString(),
                    label: n.label,
                    type: n.type,
                  }))}
                  edges={visualizationData.edges.map((e, idx) => ({
                    id: `edge-${idx}`,
                    from: e.source.toString(),
                    to: e.target.toString(),
                    label: e.label,
                  }))}
                  onNodeClick={(node) => {
                    setSelectedNodeId(node.id);
                    setSelectedEntityId(parseInt(node.id));
                    toast.info(`Selected entity: ${node.label}`);
                  }}
                />
              ) : (
                <div className="flex items-center justify-center h-[500px] text-muted-foreground">
                  No visualization data available
                </div>
              )}
            </CardContent>
          </Card>

          {/* Entity List */}
          <Card>
            <CardHeader>
              <CardTitle>Entities</CardTitle>
              <CardDescription>
                <div className="flex items-center gap-2 mt-2">
                  <Search className="h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search entities..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="max-w-sm"
                  />
                </div>
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loadingEntities ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                </div>
              ) : entities && entities.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {entities.map((entity) => (
                    <div
                      key={entity.id}
                      className="p-3 border rounded-lg hover:bg-accent cursor-pointer transition-colors"
                      onClick={() => setSelectedEntityId(entity.id)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">{entity.name}</p>
                          <Badge variant="outline" className="mt-1">
                            {entity.entityType}
                          </Badge>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        Confidence: {entity.confidence}%
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center text-muted-foreground py-8">
                  No entities found
                </p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Clusters View */}
        <TabsContent value="clusters" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Entity Clusters</CardTitle>
              <CardDescription>
                Groups of related entities detected through connectivity analysis
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loadingClusters ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                </div>
              ) : clusters && clusters.length > 0 ? (
                <div className="space-y-4">
                  {clusters.map((cluster) => (
                    <div key={cluster.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="font-semibold">{cluster.id}</h3>
                        <Badge variant="secondary">
                          Cohesion: {cluster.cohesion.toFixed(0)}%
                        </Badge>
                      </div>
                      {cluster.centralEntity && (
                        <p className="text-sm text-muted-foreground mb-2">
                          Central Entity: <span className="font-medium">{cluster.centralEntity.name}</span>
                        </p>
                      )}
                      <div className="flex flex-wrap gap-2">
                        {cluster.entities.map((entity) => (
                          <Badge key={entity.id} variant="outline">
                            {entity.name}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center text-muted-foreground py-8">
                  No clusters detected (minimum 3 entities required)
                </p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Centrality View */}
        <TabsContent value="centrality" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Entity Centrality</CardTitle>
              <CardDescription>
                Most connected and influential entities in the knowledge graph
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loadingCentrality ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                </div>
              ) : centrality && centrality.length > 0 ? (
                <div className="space-y-2">
                  {centrality.slice(0, 20).map((item, index) => (
                    <div
                      key={item.entity.id}
                      className="flex items-center justify-between p-3 border rounded-lg"
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-sm font-medium text-muted-foreground w-6">
                          #{index + 1}
                        </span>
                        <div>
                          <p className="font-medium">{item.entity.name}</p>
                          <Badge variant="outline" className="mt-1">
                            {item.entity.entityType}
                          </Badge>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold">{item.centrality}</p>
                        <p className="text-xs text-muted-foreground">connections</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center text-muted-foreground py-8">
                  No centrality data available
                </p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Temporal View */}
        <TabsContent value="temporal" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Temporal Knowledge</CardTitle>
              <CardDescription>
                Track how knowledge evolves over time
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-center text-muted-foreground py-8">
                Temporal tracking coming soon - will show entity mentions over time
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
