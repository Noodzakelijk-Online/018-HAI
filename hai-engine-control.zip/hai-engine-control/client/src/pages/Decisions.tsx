import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { CheckCircle, XCircle, Clock, AlertTriangle, Info, TrendingUp } from "lucide-react";
import { toast } from "sonner";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";

export default function Decisions() {
  const { data: pending, isLoading, refetch } = trpc.decision.getPending.useQuery();
  const { data: history } = trpc.decision.getHistory.useQuery({ limit: 10 });
  const { data: autonomyLevels } = trpc.decision.getAutonomyLevels.useQuery();

  const approveMutation = trpc.decision.approve.useMutation();
  const rejectMutation = trpc.decision.reject.useMutation();

  const [selectedDecision, setSelectedDecision] = useState<any>(null);
  const [showApproveDialog, setShowApproveDialog] = useState(false);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [feedback, setFeedback] = useState("");
  const [reason, setReason] = useState("");

  const handleApprove = async (decisionId: number) => {
    try {
      await approveMutation.mutateAsync({
        decisionId,
        feedback: feedback || undefined,
      });
      toast.success('Decision approved and executed');
      refetch();
      setShowApproveDialog(false);
      setFeedback("");
      setSelectedDecision(null);
    } catch (error) {
      console.error('Error approving decision:', error);
      toast.error('Failed to approve decision');
    }
  };

  const handleReject = async (decisionId: number) => {
    try {
      await rejectMutation.mutateAsync({
        decisionId,
        reason: reason || undefined,
      });
      toast.success('Decision rejected');
      refetch();
      setShowRejectDialog(false);
      setReason("");
      setSelectedDecision(null);
    } catch (error) {
      console.error('Error rejecting decision:', error);
      toast.error('Failed to reject decision');
    }
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'critical': return 'text-red-500';
      case 'high': return 'text-orange-500';
      case 'medium': return 'text-yellow-500';
      default: return 'text-blue-500';
    }
  };

  const getUrgencyIcon = (urgency: string) => {
    switch (urgency) {
      case 'critical': return <AlertTriangle className="h-4 w-4" />;
      case 'high': return <TrendingUp className="h-4 w-4" />;
      case 'medium': return <Clock className="h-4 w-4" />;
      default: return <Info className="h-4 w-4" />;
    }
  };

  const getAutonomyLevelName = (level: number) => {
    const autonomyLevel = autonomyLevels?.find(al => al.level === level);
    return autonomyLevel?.name || `Level ${level}`;
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold">Decision Engine</h1>
        <p className="text-muted-foreground mt-1">
          Review and approve autonomous decisions made by HAI
        </p>
      </div>

      {/* Summary */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Approvals</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pending?.length || 0}</div>
            <p className="text-xs text-muted-foreground mt-2">
              Awaiting your decision
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Recent Decisions</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{history?.length || 0}</div>
            <p className="text-xs text-muted-foreground mt-2">
              In the last 24 hours
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Autonomy Level</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Level 3</div>
            <p className="text-xs text-muted-foreground mt-2">
              Ask before acting
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Pending Decisions */}
      {pending && pending.length > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle>Pending Approvals</CardTitle>
            <CardDescription>
              Decisions waiting for your review
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {pending.map((decision) => {
              const context = decision.context as any;
              const evaluation = decision.evaluation as any;

              return (
                <div
                  key={decision.id}
                  className="p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="outline" className={getUrgencyColor(context?.urgency || 'medium')}>
                          {getUrgencyIcon(context?.urgency || 'medium')}
                          <span className="ml-1">{context?.urgency || 'medium'}</span>
                        </Badge>
                        <Badge variant="secondary">
                          {decision.decisionType}
                        </Badge>
                        <Badge>
                          {getAutonomyLevelName(decision.autonomyLevel)}
                        </Badge>
                      </div>

                      <h3 className="font-semibold text-lg mb-2">
                        {decision.description}
                      </h3>

                      <div className="space-y-2 text-sm text-muted-foreground">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">Impact:</span>
                          <span>{context?.impact || 'unknown'}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">Reversibility:</span>
                          <span>{context?.reversibility || 'unknown'}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">Confidence:</span>
                          <span>{decision.confidence}%</span>
                        </div>
                      </div>

                      {decision.reasoning && (
                        <div className="mt-3 p-3 rounded bg-muted/50">
                          <p className="text-sm font-medium mb-1">HAI's Reasoning:</p>
                          <p className="text-sm text-muted-foreground">
                            {decision.reasoning}
                          </p>
                        </div>
                      )}

                      {evaluation?.risks && evaluation.risks.length > 0 && (
                        <div className="mt-3">
                          <p className="text-sm font-medium mb-1">Risks:</p>
                          <ul className="text-sm text-muted-foreground list-disc list-inside">
                            {evaluation.risks.map((risk: string, i: number) => (
                              <li key={i}>{risk}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {evaluation?.benefits && evaluation.benefits.length > 0 && (
                        <div className="mt-3">
                          <p className="text-sm font-medium mb-1">Benefits:</p>
                          <ul className="text-sm text-muted-foreground list-disc list-inside">
                            {evaluation.benefits.map((benefit: string, i: number) => (
                              <li key={i}>{benefit}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      <p className="text-xs text-muted-foreground mt-3">
                        Requested: {new Date(decision.createdAt).toLocaleString()}
                      </p>
                    </div>

                    <div className="flex flex-col gap-2 ml-4">
                      <Button
                        onClick={() => {
                          setSelectedDecision(decision);
                          setShowApproveDialog(true);
                        }}
                        size="sm"
                        className="min-w-[100px]"
                      >
                        <CheckCircle className="mr-2 h-4 w-4" />
                        Approve
                      </Button>
                      <Button
                        onClick={() => {
                          setSelectedDecision(decision);
                          setShowRejectDialog(true);
                        }}
                        variant="outline"
                        size="sm"
                        className="min-w-[100px]"
                      >
                        <XCircle className="mr-2 h-4 w-4" />
                        Reject
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <CheckCircle className="h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No pending approvals</h3>
            <p className="text-muted-foreground text-center max-w-md">
              All decisions have been reviewed. HAI will notify you when new decisions require your approval.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Recent History */}
      {history && history.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Recent Decisions</CardTitle>
            <CardDescription>
              Latest decision history
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {history.map((decision) => (
              <div
                key={decision.id}
                className="flex items-center justify-between p-3 rounded-lg border bg-card"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant={
                      decision.status === 'executed' ? 'default' :
                      decision.status === 'approved' ? 'default' :
                      decision.status === 'rejected' ? 'destructive' :
                      'secondary'
                    }>
                      {decision.status}
                    </Badge>
                    <span className="text-sm font-medium">{decision.description}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {new Date(decision.createdAt).toLocaleString()}
                  </p>
                </div>
                <Badge variant="outline">
                  {decision.confidence}% confident
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Approve Dialog */}
      <Dialog open={showApproveDialog} onOpenChange={setShowApproveDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Approve Decision</DialogTitle>
            <DialogDescription>
              This decision will be executed immediately after approval.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="feedback">Feedback (optional)</Label>
              <Textarea
                id="feedback"
                placeholder="Any feedback on this decision..."
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowApproveDialog(false)}>
              Cancel
            </Button>
            <Button onClick={() => selectedDecision && handleApprove(selectedDecision.id)}>
              Approve & Execute
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Decision</DialogTitle>
            <DialogDescription>
              This decision will not be executed.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="reason">Reason (optional)</Label>
              <Textarea
                id="reason"
                placeholder="Why are you rejecting this decision..."
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRejectDialog(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={() => selectedDecision && handleReject(selectedDecision.id)}>
              Reject
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
