import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area
} from 'recharts';
import {
  Brain, Zap, Shield, TrendingUp, Plug, RefreshCw, Play, Pause,
  CheckCircle2, AlertCircle, Clock, Activity, Server, Bell, GitBranch,
  BarChart3, ArrowRight, Check, X, Network
} from 'lucide-react';
import DependencyGraphVisualization from '@/components/DependencyGraphVisualization';

const categoryIcons: Record<string, React.ReactNode> = {
  Intelligence: <Brain className="h-4 w-4" />,
  Integration: <Plug className="h-4 w-4" />,
  Learning: <TrendingUp className="h-4 w-4" />,
  Security: <Shield className="h-4 w-4" />,
  Optimization: <Zap className="h-4 w-4" />,
};

const priorityColors: Record<string, string> = {
  P0: 'bg-red-500/10 text-red-500 border-red-500/20',
  P1: 'bg-orange-500/10 text-orange-500 border-orange-500/20',
  P2: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
  P3: 'bg-green-500/10 text-green-500 border-green-500/20',
};

const categoryColors: Record<string, string> = {
  Intelligence: 'bg-purple-500/10 text-purple-500',
  Integration: 'bg-blue-500/10 text-blue-500',
  Learning: 'bg-cyan-500/10 text-cyan-500',
  Security: 'bg-red-500/10 text-red-500',
  Optimization: 'bg-green-500/10 text-green-500',
};

const severityColors: Record<string, string> = {
  info: 'bg-blue-500/10 text-blue-500',
  warning: 'bg-yellow-500/10 text-yellow-500',
  error: 'bg-orange-500/10 text-orange-500',
  critical: 'bg-red-500/10 text-red-500',
};

export default function AutonomousServicesDashboard() {
  const [activeTab, setActiveTab] = useState('services');

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Autonomous Services</h1>
            <p className="text-muted-foreground">
              Monitor and control all 50 autonomous services
            </p>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="services" className="flex items-center gap-2">
              <Server className="h-4 w-4" /> Services
            </TabsTrigger>
            <TabsTrigger value="metrics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" /> Metrics
            </TabsTrigger>
            <TabsTrigger value="dependencies" className="flex items-center gap-2">
              <GitBranch className="h-4 w-4" /> Dependencies
            </TabsTrigger>
            <TabsTrigger value="alerts" className="flex items-center gap-2">
              <Bell className="h-4 w-4" /> Alerts
            </TabsTrigger>
          </TabsList>

          <TabsContent value="services">
            <ServicesTab />
          </TabsContent>
          <TabsContent value="metrics">
            <MetricsTab />
          </TabsContent>
          <TabsContent value="dependencies">
            <DependenciesTab />
          </TabsContent>
          <TabsContent value="alerts">
            <AlertsTab />
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}

function ServicesTab() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedPriority, setSelectedPriority] = useState<string>('all');

  const { data: serviceStatus, isLoading, refetch } = trpc.autonomousServices.getServiceStatus.useQuery(
    undefined,
    { refetchInterval: 10000 }
  );

  const filteredServices = serviceStatus?.services.filter(service => {
    const categoryMatch = selectedCategory === 'all' || service.category === selectedCategory;
    const priorityMatch = selectedPriority === 'all' || service.priority === selectedPriority;
    return categoryMatch && priorityMatch;
  }) || [];

  return (
    <div className="space-y-6 mt-6">
      {/* Summary Cards */}
      {serviceStatus && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total</p>
                  <p className="text-2xl font-bold">{serviceStatus.summary.total}</p>
                </div>
                <Server className="h-8 w-8 text-muted-foreground/50" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Active</p>
                  <p className="text-2xl font-bold text-green-500">{serviceStatus.summary.active}</p>
                </div>
                <CheckCircle2 className="h-8 w-8 text-green-500/50" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">P0</p>
                  <p className="text-2xl font-bold text-red-500">{serviceStatus.summary.byPriority.P0}</p>
                </div>
                <AlertCircle className="h-8 w-8 text-red-500/50" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">P1</p>
                  <p className="text-2xl font-bold text-orange-500">{serviceStatus.summary.byPriority.P1}</p>
                </div>
                <Clock className="h-8 w-8 text-orange-500/50" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">P2+P3</p>
                  <p className="text-2xl font-bold text-yellow-500">
                    {serviceStatus.summary.byPriority.P2 + serviceStatus.summary.byPriority.P3}
                  </p>
                </div>
                <Activity className="h-8 w-8 text-yellow-500/50" />
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-wrap gap-4">
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Category:</span>
          <div className="flex flex-wrap gap-1">
            <Button variant={selectedCategory === 'all' ? 'default' : 'outline'} size="sm" onClick={() => setSelectedCategory('all')}>All</Button>
            {['Intelligence', 'Integration', 'Learning', 'Security', 'Optimization'].map(cat => (
              <Button key={cat} variant={selectedCategory === cat ? 'default' : 'outline'} size="sm" onClick={() => setSelectedCategory(cat)}>
                {categoryIcons[cat]}<span className="ml-1 hidden sm:inline">{cat}</span>
              </Button>
            ))}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Priority:</span>
          <div className="flex gap-1">
            <Button variant={selectedPriority === 'all' ? 'default' : 'outline'} size="sm" onClick={() => setSelectedPriority('all')}>All</Button>
            {['P0', 'P1', 'P2', 'P3'].map(p => (
              <Button key={p} variant={selectedPriority === p ? 'default' : 'outline'} size="sm" onClick={() => setSelectedPriority(p)}>{p}</Button>
            ))}
          </div>
        </div>
        <Button variant="outline" size="sm" onClick={() => refetch()}>
          <RefreshCw className="h-4 w-4 mr-2" /> Refresh
        </Button>
      </div>

      {/* Service Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {isLoading ? (
          Array.from({ length: 12 }).map((_, i) => (
            <Card key={i} className="animate-pulse"><CardContent className="pt-6"><div className="h-20 bg-muted rounded" /></CardContent></Card>
          ))
        ) : (
          filteredServices.map(service => <ServiceCard key={service.id} service={service} />)
        )}
      </div>
    </div>
  );
}

function ServiceCard({ service }: { service: { id: string; name: string; priority: string; category: string; status: string } }) {
  const [isRunning, setIsRunning] = useState(service.status === 'active');
  const handleToggle = () => { setIsRunning(!isRunning); toast.success(`${service.name} ${isRunning ? 'paused' : 'started'}`); };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="pt-6">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className={`p-2 rounded-lg ${categoryColors[service.category]}`}>{categoryIcons[service.category]}</div>
            <div>
              <h3 className="font-medium text-sm leading-tight">{service.name}</h3>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="outline" className={priorityColors[service.priority]}>{service.priority}</Badge>
                <Badge variant="secondary" className="text-xs">{service.category}</Badge>
              </div>
            </div>
          </div>
        </div>
        <div className="flex items-center justify-between mt-4">
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${isRunning ? 'bg-green-500' : 'bg-gray-400'}`} />
            <span className="text-xs text-muted-foreground">{isRunning ? 'Running' : 'Paused'}</span>
          </div>
          <Button variant="ghost" size="sm" onClick={handleToggle} className="h-8 w-8 p-0">
            {isRunning ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function MetricsTab() {
  const [selectedService, setSelectedService] = useState('email-management');
  const { data: summaries } = trpc.autonomousServices.getAllMetricsSummaries.useQuery(undefined, { refetchInterval: 30000 });
  const { data: timeSeries } = trpc.autonomousServices.getMetricsTimeSeries.useQuery(
    { serviceId: selectedService, metricType: 'success', hours: 24 },
    { refetchInterval: 30000 }
  );
  const { data: perfSeries } = trpc.autonomousServices.getMetricsTimeSeries.useQuery(
    { serviceId: selectedService, metricType: 'performance', hours: 24 },
    { refetchInterval: 30000 }
  );

  const chartData = timeSeries?.map((m, i) => ({
    time: new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    success: m.value,
    performance: perfSeries?.[i]?.value || 0,
  })) || [];

  return (
    <div className="space-y-6 mt-6">
      {/* Service Summaries */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {summaries?.slice(0, 6).map(summary => (
          <Card key={summary.serviceId} className={`cursor-pointer transition-all ${selectedService === summary.serviceId ? 'ring-2 ring-primary' : ''}`}
            onClick={() => setSelectedService(summary.serviceId)}>
            <CardContent className="pt-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-medium text-sm">{summary.serviceName}</h3>
                  <Badge variant="outline" className={summary.trend === 'improving' ? 'text-green-500' : summary.trend === 'declining' ? 'text-red-500' : 'text-gray-500'}>
                    {summary.trend === 'improving' ? '↑' : summary.trend === 'declining' ? '↓' : '→'} {summary.trend}
                  </Badge>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div><p className="text-muted-foreground">Executions</p><p className="font-bold">{summary.totalExecutions}</p></div>
                <div><p className="text-muted-foreground">Success Rate</p><p className="font-bold">{summary.successRate.toFixed(1)}%</p></div>
                <div><p className="text-muted-foreground">Avg Time</p><p className="font-bold">{summary.avgExecutionTime.toFixed(0)}ms</p></div>
                <div><p className="text-muted-foreground">Errors</p><p className="font-bold text-red-500">{summary.totalErrors}</p></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle>Success Rate (24h)</CardTitle></CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="time" className="text-xs" tick={{ fill: 'currentColor' }} />
                  <YAxis domain={[0, 100]} className="text-xs" tick={{ fill: 'currentColor' }} />
                  <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }} />
                  <Area type="monotone" dataKey="success" stroke="hsl(var(--primary))" fill="hsl(var(--primary))" fillOpacity={0.2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Response Time (24h)</CardTitle></CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="time" className="text-xs" tick={{ fill: 'currentColor' }} />
                  <YAxis className="text-xs" tick={{ fill: 'currentColor' }} />
                  <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }} />
                  <Line type="monotone" dataKey="performance" stroke="hsl(var(--chart-2))" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function DependenciesTab() {
  const [viewMode, setViewMode] = useState<'graph' | 'list'>('graph');
  const { data: graph } = trpc.autonomousServices.getDependencyGraph.useQuery(undefined, { refetchInterval: 60000 });
  const { data: history } = trpc.autonomousServices.getTriggerHistory.useQuery({ limit: 20 }, { refetchInterval: 10000 });
  const { data: services } = trpc.autonomousServices.list.useQuery();

  // Transform services to nodes for the graph
  const graphNodes = services?.map(s => ({
    id: s.id,
    name: s.name,
    category: s.category,
    level: s.priority === 'P0' ? 0 : s.priority === 'P1' ? 1 : s.priority === 'P2' ? 2 : 3,
  })) || [];

  const handleNodeClick = (nodeId: string) => {
    toast.info(`Selected: ${nodeId}`);
  };

  const handleEdgeClick = (edge: any) => {
    toast.info(`${edge.sourceServiceId} → ${edge.targetServiceId} (${edge.triggerType})`);
  };

  return (
    <div className="space-y-6 mt-6">
      {/* View Toggle */}
      <div className="flex items-center gap-2">
        <Button
          variant={viewMode === 'graph' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setViewMode('graph')}
        >
          <Network className="h-4 w-4 mr-2" /> Graph View
        </Button>
        <Button
          variant={viewMode === 'list' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setViewMode('list')}
        >
          <GitBranch className="h-4 w-4 mr-2" /> List View
        </Button>
      </div>

      {/* Graph Visualization */}
      {viewMode === 'graph' && graph && (
        <DependencyGraphVisualization
          nodes={graphNodes}
          edges={graph.edges}
          onNodeClick={handleNodeClick}
          onEdgeClick={handleEdgeClick}
        />
      )}

      {/* List View */}
      {viewMode === 'list' && (
        <Card>
          <CardHeader>
            <CardTitle>Service Dependencies</CardTitle>
            <CardDescription>Automatic triggers between services</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {graph?.edges.map((edge, i) => (
                <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <Badge variant="outline">{edge.sourceServiceId}</Badge>
                  <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  <Badge variant="outline">{edge.targetServiceId}</Badge>
                  <Badge className={edge.triggerType === 'on_success' ? 'bg-green-500/10 text-green-500' : edge.triggerType === 'on_failure' ? 'bg-red-500/10 text-red-500' : 'bg-blue-500/10 text-blue-500'}>
                    {edge.triggerType}
                  </Badge>
                  <span className="text-xs text-muted-foreground ml-auto">Priority: {edge.priority}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Trigger History */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Triggers</CardTitle>
          <CardDescription>Last 20 dependency triggers</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {history?.map(event => (
              <div key={event.id} className="flex items-center gap-3 p-2 rounded border">
                {event.status === 'completed' ? <CheckCircle2 className="h-4 w-4 text-green-500" /> : event.status === 'failed' ? <X className="h-4 w-4 text-red-500" /> : <Clock className="h-4 w-4 text-yellow-500" />}
                <span className="text-sm">{event.sourceServiceId}</span>
                <ArrowRight className="h-3 w-3" />
                <span className="text-sm">{event.targetServiceId}</span>
                <Badge variant="secondary" className="text-xs">{event.triggerType}</Badge>
                <span className="text-xs text-muted-foreground ml-auto">{new Date(event.timestamp).toLocaleTimeString()}</span>
              </div>
            ))}
            {(!history || history.length === 0) && <p className="text-muted-foreground text-center py-4">No triggers yet</p>}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function AlertsTab() {
  const { data: alerts, refetch } = trpc.autonomousServices.getAlerts.useQuery({ limit: 50 }, { refetchInterval: 5000 });
  const { data: stats } = trpc.autonomousServices.getAlertStats.useQuery(undefined, { refetchInterval: 10000 });
  const { data: rules } = trpc.autonomousServices.getAlertRules.useQuery();
  const acknowledgeMutation = trpc.autonomousServices.acknowledgeAlert.useMutation({ onSuccess: () => { refetch(); toast.success('Alert acknowledged'); } });
  const acknowledgeAllMutation = trpc.autonomousServices.acknowledgeAllAlerts.useMutation({ onSuccess: () => { refetch(); toast.success('All alerts acknowledged'); } });

  return (
    <div className="space-y-6 mt-6">
      {/* Alert Stats */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <p className="text-sm text-muted-foreground">Total Alerts</p>
              <p className="text-2xl font-bold">{stats.total}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <p className="text-sm text-muted-foreground">Unacknowledged</p>
              <p className="text-2xl font-bold text-red-500">{stats.unacknowledged}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <p className="text-sm text-muted-foreground">Last 24h</p>
              <p className="text-2xl font-bold">{stats.last24Hours}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <p className="text-sm text-muted-foreground">Critical</p>
              <p className="text-2xl font-bold text-red-500">{stats.bySeverity.critical}</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Actions */}
      <div className="flex gap-2">
        <Button variant="outline" size="sm" onClick={() => acknowledgeAllMutation.mutate({})}>
          <Check className="h-4 w-4 mr-2" /> Acknowledge All
        </Button>
        <Button variant="outline" size="sm" onClick={() => refetch()}>
          <RefreshCw className="h-4 w-4 mr-2" /> Refresh
        </Button>
      </div>

      {/* Alert List */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Alerts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {alerts?.map(alert => (
              <div key={alert.id} className={`p-4 rounded-lg border ${alert.acknowledged ? 'opacity-50' : ''}`}>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <Badge className={severityColors[alert.severity]}>{alert.severity}</Badge>
                    <div>
                      <h4 className="font-medium">{alert.title}</h4>
                      <p className="text-sm text-muted-foreground">{alert.message}</p>
                    </div>
                  </div>
                  {!alert.acknowledged && (
                    <Button variant="ghost" size="sm" onClick={() => acknowledgeMutation.mutate({ alertId: alert.id })}>
                      <Check className="h-4 w-4" />
                    </Button>
                  )}
                </div>
                <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                  <span>{alert.serviceName}</span>
                  <span>{new Date(alert.timestamp).toLocaleString()}</span>
                  {alert.acknowledged && <Badge variant="secondary">Acknowledged</Badge>}
                </div>
              </div>
            ))}
            {(!alerts || alerts.length === 0) && <p className="text-muted-foreground text-center py-8">No alerts</p>}
          </div>
        </CardContent>
      </Card>

      {/* Alert Rules */}
      <Card>
        <CardHeader>
          <CardTitle>Alert Rules</CardTitle>
          <CardDescription>Configure when alerts are triggered</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {rules?.map(rule => (
              <div key={rule.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                <div>
                  <h4 className="font-medium text-sm">{rule.name}</h4>
                  <p className="text-xs text-muted-foreground">
                    {rule.condition} {rule.threshold} • {rule.serviceId === '*' ? 'All services' : rule.serviceId}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={severityColors[rule.severity]}>{rule.severity}</Badge>
                  <Badge variant={rule.enabled ? 'default' : 'secondary'}>{rule.enabled ? 'Enabled' : 'Disabled'}</Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
