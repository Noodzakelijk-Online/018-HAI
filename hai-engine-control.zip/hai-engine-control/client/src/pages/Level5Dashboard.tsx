/**
 * Level 5 AI Dashboard
 * 
 * Main dashboard for visualizing and interacting with HAI's Level 5 AI capabilities
 */

import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import KnowledgeGraphExplorer from "@/components/KnowledgeGraphExplorer";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import {
  Activity,
  Brain,
  Database,
  Lightbulb,
  Network,
  Target,
  TrendingUp,
  Users,
  AlertTriangle,
  CheckCircle,
  TrendingDown
} from "lucide-react";
import { LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function Level5Dashboard() {
  const { user, loading, isAuthenticated } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-[400px]">
          <CardHeader>
            <CardTitle>Authentication Required</CardTitle>
            <CardDescription>
              Please sign in to access the Level 5 AI Dashboard
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild className="w-full">
              <a href={getLoginUrl()}>Sign In</a>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold">HAI Level 5 AI Dashboard</h1>
              <p className="text-muted-foreground">
                Autonomous Organization Control Center
              </p>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm text-muted-foreground">
                Welcome, {user?.name}
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-8">
            <TabsTrigger value="overview">
              <Activity className="w-4 h-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="knowledge">
              <Network className="w-4 h-4 mr-2" />
              Knowledge
            </TabsTrigger>
            <TabsTrigger value="memory">
              <Database className="w-4 h-4 mr-2" />
              Memory
            </TabsTrigger>
            <TabsTrigger value="goals">
              <Target className="w-4 h-4 mr-2" />
              Goals
            </TabsTrigger>
            <TabsTrigger value="agents">
              <Users className="w-4 h-4 mr-2" />
              Agents
            </TabsTrigger>
            <TabsTrigger value="innovation">
              <Lightbulb className="w-4 h-4 mr-2" />
              Innovation
            </TabsTrigger>
            <TabsTrigger value="forecasting">
              <TrendingUp className="w-4 h-4 mr-2" />
              Forecasting
            </TabsTrigger>
            <TabsTrigger value="observability">
              <Brain className="w-4 h-4 mr-2" />
              Observability
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <OverviewTab />
          </TabsContent>

          <TabsContent value="knowledge" className="space-y-6">
            <KnowledgeGraphTab />
          </TabsContent>

          <TabsContent value="memory" className="space-y-6">
            <MemoryTab />
          </TabsContent>

          <TabsContent value="goals" className="space-y-6">
            <GoalsTab />
          </TabsContent>

          <TabsContent value="agents" className="space-y-6">
            <AgentsTab />
          </TabsContent>

          <TabsContent value="innovation" className="space-y-6">
            <InnovationTab />
          </TabsContent>

          <TabsContent value="forecasting" className="space-y-6">
            <ForecastingTab />
          </TabsContent>

          <TabsContent value="observability" className="space-y-6">
            <ObservabilityTab />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

// ============================================================================
// Overview Tab
// ============================================================================
function OverviewTab() {
  // Real-time updates for overview stats
  const goals = trpc.level5.goals.getAll.useQuery(undefined, {
    refetchInterval: 10000,
  });
  const agents = trpc.level5.agents.getAllAgents.useQuery(undefined, {
    refetchInterval: 5000,
  });
  const innovations = trpc.level5.innovation.getInnovations.useQuery(undefined, {
    refetchInterval: 10000,
  });
  const forecasts = trpc.level5.forecasting.getForecasts.useQuery(undefined, {
    refetchInterval: 15000,
  });

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">System Overview</h2>
        <p className="text-muted-foreground">
          Real-time status of all Level 5 AI capabilities
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Active Goals
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {goals.data?.filter(g => g.status === 'in_progress').length || 0}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {goals.data?.length || 0} total goals
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Active Agents
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {agents.data?.filter(a => a.status === 'active').length || 0}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {agents.data?.length || 0} total agents
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Innovations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {innovations.data?.filter(i => i.status === 'idea' || i.status === 'evaluating').length || 0}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {innovations.data?.length || 0} total ideas
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Forecasts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {forecasts.data?.length || 0}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Active predictions
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>
            Common tasks to interact with Level 5 AI
          </CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Button variant="outline" className="h-auto py-4 flex-col">
            <Target className="w-6 h-6 mb-2" />
            <span>Create Goal</span>
          </Button>
          <Button variant="outline" className="h-auto py-4 flex-col">
            <Users className="w-6 h-6 mb-2" />
            <span>Delegate Task</span>
          </Button>
          <Button variant="outline" className="h-auto py-4 flex-col">
            <Lightbulb className="w-6 h-6 mb-2" />
            <span>Brainstorm</span>
          </Button>
          <Button variant="outline" className="h-auto py-4 flex-col">
            <TrendingUp className="w-6 h-6 mb-2" />
            <span>Create Forecast</span>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

// ============================================================================
// Knowledge Graph Tab
// ============================================================================
function KnowledgeGraphTab() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Knowledge Graph</h2>
        <p className="text-muted-foreground">
          Explore relationships and entities in your knowledge base
        </p>
      </div>
      <KnowledgeGraphExplorer />
    </div>
  );
}

// ============================================================================
// Memory Tab
// ============================================================================
function MemoryTab() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Memory Systems</h2>
        <p className="text-muted-foreground">
          Browse procedural, semantic, episodic, and working memory
        </p>
      </div>
      
      <Tabs defaultValue="procedural" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="procedural">Procedural</TabsTrigger>
          <TabsTrigger value="semantic">Semantic</TabsTrigger>
          <TabsTrigger value="episodic">Episodic</TabsTrigger>
          <TabsTrigger value="working">Working</TabsTrigger>
        </TabsList>

        <TabsContent value="procedural">
          <ProceduralMemoryView />
        </TabsContent>

        <TabsContent value="semantic">
          <SemanticMemoryView />
        </TabsContent>

        <TabsContent value="episodic">
          <EpisodicMemoryView />
        </TabsContent>

        <TabsContent value="working">
          <WorkingMemoryView />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function ProceduralMemoryView() {
  const { data: memories, isLoading } = trpc.level5.memory.procedural.getAll.useQuery();

  if (isLoading) return <div className="text-center py-8">Loading procedural memories...</div>;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Procedural Memory</CardTitle>
        <CardDescription>Skills, procedures, and how-to knowledge</CardDescription>
      </CardHeader>
      <CardContent>
        {memories && memories.length > 0 ? (
          <div className="space-y-4">
            {memories.map((memory) => (
              <Card key={memory.id}>
                <CardHeader>
                  <CardTitle className="text-base">{memory.skill}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Proficiency</span>
                      <span className="font-medium">{(memory.proficiency * 100).toFixed(0)}%</span>
                    </div>
                    <div className="w-full bg-secondary rounded-full h-2">
                      <div
                        className="bg-primary h-2 rounded-full transition-all"
                        style={{ width: `${memory.proficiency * 100}%` }}
                      />
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Practice Count</span>
                      <span className="font-medium">{memory.practiceCount}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <p className="text-center text-muted-foreground py-8">
            No procedural memories yet
          </p>
        )}
      </CardContent>
    </Card>
  );
}

function SemanticMemoryView() {
  const { data: memories, isLoading } = trpc.level5.memory.semantic.getAll.useQuery();

  if (isLoading) return <div className="text-center py-8">Loading semantic memories...</div>;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Semantic Memory</CardTitle>
        <CardDescription>Facts, concepts, and general knowledge</CardDescription>
      </CardHeader>
      <CardContent>
        {memories && memories.length > 0 ? (
          <div className="space-y-4">
            {memories.map((memory) => (
              <Card key={memory.id}>
                <CardHeader>
                  <CardTitle className="text-base">{memory.concept}</CardTitle>
                  <CardDescription>{memory.category}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm">{memory.definition}</p>
                  <div className="mt-2 flex justify-between text-sm">
                    <span className="text-muted-foreground">Confidence</span>
                    <span className="font-medium">{(memory.confidence * 100).toFixed(0)}%</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <p className="text-center text-muted-foreground py-8">
            No semantic memories yet
          </p>
        )}
      </CardContent>
    </Card>
  );
}

function EpisodicMemoryView() {
  const { data: memories, isLoading } = trpc.level5.memory.episodic.getAll.useQuery();

  if (isLoading) return <div className="text-center py-8">Loading episodic memories...</div>;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Episodic Memory</CardTitle>
        <CardDescription>Personal experiences and events</CardDescription>
      </CardHeader>
      <CardContent>
        {memories && memories.length > 0 ? (
          <div className="space-y-4">
            {memories.map((memory) => (
              <Card key={memory.id}>
                <CardHeader>
                  <CardTitle className="text-base">{memory.event}</CardTitle>
                  <CardDescription>
                    {new Date(memory.timestamp).toLocaleString()}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm mb-2">{memory.description}</p>
                  {memory.emotion && (
                    <div className="flex items-center gap-2 text-sm">
                      <span className="text-muted-foreground">Emotion:</span>
                      <span className="font-medium capitalize">{memory.emotion}</span>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <p className="text-center text-muted-foreground py-8">
            No episodic memories yet
          </p>
        )}
      </CardContent>
    </Card>
  );
}

function WorkingMemoryView() {
  const { data: memories, isLoading } = trpc.level5.memory.working.getAll.useQuery();

  if (isLoading) return <div className="text-center py-8">Loading working memory...</div>;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Working Memory</CardTitle>
        <CardDescription>Active context (7±2 items capacity)</CardDescription>
      </CardHeader>
      <CardContent>
        {memories && memories.length > 0 ? (
          <div className="space-y-4">
            <div className="flex justify-between items-center mb-4">
              <span className="text-sm text-muted-foreground">
                Capacity: {memories.length} / 9 items
              </span>
              <div className="w-32 bg-secondary rounded-full h-2">
                <div
                  className="bg-primary h-2 rounded-full transition-all"
                  style={{ width: `${(memories.length / 9) * 100}%` }}
                />
              </div>
            </div>
            {memories.map((memory) => (
              <Card key={memory.id}>
                <CardHeader>
                  <CardTitle className="text-base">{memory.item}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Priority</span>
                    <span className="font-medium">{memory.priority}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <p className="text-center text-muted-foreground py-8">
            Working memory is empty
          </p>
        )}
      </CardContent>
    </Card>
  );
}

// ============================================================================
// Goals Tab
// ============================================================================
function GoalsTab() {
  const { data: goals, isLoading } = trpc.level5.goals.getAll.useQuery();

  if (isLoading) return <div className="text-center py-8">Loading goals...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold mb-2">Goals</h2>
          <p className="text-muted-foreground">
            Manage and track your goals
          </p>
        </div>
        <Button>
          <Target className="w-4 h-4 mr-2" />
          Create Goal
        </Button>
      </div>

      {goals && goals.length > 0 ? (
        <div className="grid gap-4">
          {goals.map((goal) => (
            <Card key={goal.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle>{goal.title}</CardTitle>
                    <CardDescription>{goal.description}</CardDescription>
                  </div>
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    goal.status === 'completed' ? 'bg-green-100 text-green-800' :
                    goal.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {goal.status}
                  </span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Progress</span>
                    <span className="font-medium">{goal.progress}%</span>
                  </div>
                  <div className="w-full bg-secondary rounded-full h-2">
                    <div
                      className="bg-primary h-2 rounded-full transition-all"
                      style={{ width: `${goal.progress}%` }}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">
              No goals yet. Create your first goal to get started!
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// ============================================================================
// Agents Tab
// ============================================================================
function AgentsTab() {
  const { data: agents, isLoading } = trpc.level5.agents.getAllAgents.useQuery();

  if (isLoading) return <div className="text-center py-8">Loading agents...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold mb-2">Multi-Agent System</h2>
          <p className="text-muted-foreground">
            Monitor and delegate tasks to specialist agents
          </p>
        </div>
        <Button>
          <Users className="w-4 h-4 mr-2" />
          Delegate Task
        </Button>
      </div>

      {agents && agents.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {agents.map((agent) => (
            <Card key={agent.id}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>{agent.name}</span>
                  <span className={`w-2 h-2 rounded-full ${
                    agent.status === 'active' ? 'bg-green-500' :
                    agent.status === 'busy' ? 'bg-yellow-500' :
                    'bg-gray-500'
                  }`} />
                </CardTitle>
                <CardDescription>{agent.role}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Status</span>
                    <span className="font-medium capitalize">{agent.status}</span>
                  </div>
                  {agent.currentTask && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Current Task</span>
                      <span className="font-medium truncate ml-2">{agent.currentTask}</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">
              No agents available
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// ============================================================================
// Innovation Tab
// ============================================================================
function InnovationTab() {
  const { data: innovations, isLoading } = trpc.level5.innovation.getInnovations.useQuery(undefined, {
    refetchInterval: 10000, // Refresh every 10 seconds
  });
  const { data: schedulerStatus } = trpc.level5.innovation.getAutonomousStatus.useQuery(undefined, {
    refetchInterval: 5000, // Refresh every 5 seconds
  });
  const startAutonomous = trpc.level5.innovation.startAutonomous.useMutation();
  const stopAutonomous = trpc.level5.innovation.stopAutonomous.useMutation();

  const handleToggleAutonomous = async () => {
    if (schedulerStatus?.isRunning) {
      await stopAutonomous.mutateAsync();
    } else {
      await startAutonomous.mutateAsync();
    }
  };

  if (isLoading) return <div className="text-center py-8">Loading innovations...</div>;

  return (
    <div className="space-y-6">
      {/* Autonomous Scheduler Status */}
      <Card>
        <CardHeader>
          <CardTitle>Autonomous Innovation Scheduler</CardTitle>
          <CardDescription>
            Self-directed AI that generates and evaluates innovations every 6 hours
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">Status:</span>
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  schedulerStatus?.isRunning ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                }`}>
                  {schedulerStatus?.isRunning ? 'Running' : 'Stopped'}
                </span>
              </div>
              <div className="text-sm text-muted-foreground">
                Interval: {schedulerStatus?.intervalMs ? `${schedulerStatus.intervalMs / 1000 / 60 / 60} hours` : 'N/A'}
              </div>
            </div>
            <Button 
              onClick={handleToggleAutonomous}
              variant={schedulerStatus?.isRunning ? 'destructive' : 'default'}
              disabled={startAutonomous.isLoading || stopAutonomous.isLoading}
            >
              {schedulerStatus?.isRunning ? 'Stop Autonomous Mode' : 'Start Autonomous Mode'}
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold mb-2">Innovation Pipeline</h2>
          <p className="text-muted-foreground">
            Ideas generated by the autonomous innovation engine
          </p>
        </div>
      </div>

      {innovations && innovations.length > 0 ? (
        <div className="grid gap-4">
          {innovations.map((innovation) => (
            <Card key={innovation.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle>{innovation.title}</CardTitle>
                    <CardDescription>{innovation.description}</CardDescription>
                  </div>
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    innovation.status === 'implemented' ? 'bg-green-100 text-green-800' :
                    innovation.status === 'implementing' ? 'bg-blue-100 text-blue-800' :
                    innovation.status === 'evaluating' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {innovation.status}
                  </span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Creativity Pattern</span>
                    <span className="font-medium">{innovation.creativityPattern}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Feasibility Score</span>
                    <span className="font-medium">{(innovation.feasibilityScore * 100).toFixed(0)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Impact Score</span>
                    <span className="font-medium">{(innovation.impactScore * 100).toFixed(0)}%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">
              No innovations yet. The autonomous engine will generate ideas automatically.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// ============================================================================
// Forecasting Tab
// ============================================================================
function ForecastingTab() {
  const { data: forecasts, isLoading } = trpc.level5.forecasting.getForecasts.useQuery();

  // Generate sample data for visualization
  const trendData = [
    { date: '2024-01', actual: 100, predicted: 98, confidence: 95 },
    { date: '2024-02', actual: 110, predicted: 108, confidence: 93 },
    { date: '2024-03', actual: 105, predicted: 112, confidence: 91 },
    { date: '2024-04', actual: 120, predicted: 118, confidence: 90 },
    { date: '2024-05', actual: 130, predicted: 128, confidence: 88 },
    { date: '2024-06', actual: null, predicted: 138, confidence: 85 },
    { date: '2024-07', actual: null, predicted: 145, confidence: 82 },
    { date: '2024-08', actual: null, predicted: 152, confidence: 80 },
  ];

  const scenarioData = [
    { scenario: 'Best Case', value: 180, probability: 15 },
    { scenario: 'Most Likely', value: 145, probability: 60 },
    { scenario: 'Worst Case', value: 110, probability: 25 },
  ];

  const riskData = [
    { category: 'Market Risk', level: 65, status: 'medium' },
    { category: 'Technical Risk', level: 35, status: 'low' },
    { category: 'Resource Risk', level: 80, status: 'high' },
    { category: 'Timeline Risk', level: 50, status: 'medium' },
  ];

  if (isLoading) return <div className="text-center py-8">Loading forecasts...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold mb-2">Forecasting System</h2>
          <p className="text-muted-foreground">
            AI-powered predictions with 30-day horizon
          </p>
        </div>
      </div>

      {/* Trend Analysis Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Trend Analysis</CardTitle>
          <CardDescription>
            Historical data vs. predicted values with confidence intervals
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="actual" stroke="#3b82f6" strokeWidth={2} name="Actual" />
              <Line type="monotone" dataKey="predicted" stroke="#10b981" strokeWidth={2} strokeDasharray="5 5" name="Predicted" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Scenario Comparison */}
      <Card>
        <CardHeader>
          <CardTitle>Scenario Planning</CardTitle>
          <CardDescription>
            Compare best case, most likely, and worst case scenarios
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={scenarioData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="scenario" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="value" fill="#8b5cf6" name="Predicted Value" />
              <Bar dataKey="probability" fill="#f59e0b" name="Probability (%)" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Risk Assessment */}
      <Card>
        <CardHeader>
          <CardTitle>Risk Assessment</CardTitle>
          <CardDescription>
            Identified risks and their severity levels
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {riskData.map((risk) => (
              <div key={risk.category} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {risk.status === 'high' && <AlertTriangle className="w-4 h-4 text-red-500" />}
                    {risk.status === 'medium' && <TrendingDown className="w-4 h-4 text-yellow-500" />}
                    {risk.status === 'low' && <CheckCircle className="w-4 h-4 text-green-500" />}
                    <span className="font-medium">{risk.category}</span>
                  </div>
                  <span className="text-sm text-muted-foreground">{risk.level}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full ${
                      risk.status === 'high' ? 'bg-red-500' :
                      risk.status === 'medium' ? 'bg-yellow-500' :
                      'bg-green-500'
                    }`}
                    style={{ width: `${risk.level}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Forecast List */}
      {forecasts && forecasts.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold mb-4">Active Forecasts</h3>
          <div className="grid gap-4">
            {forecasts.map((forecast) => (
              <Card key={forecast.id}>
                <CardHeader>
                  <CardTitle>{forecast.target}</CardTitle>
                  <CardDescription>
                    Horizon: {forecast.horizon} days | Method: {forecast.method}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Predicted Value</span>
                      <span className="font-medium">{forecast.predictedValue}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Confidence</span>
                      <span className="font-medium">{(forecast.confidence * 100).toFixed(0)}%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================================
// Observability Tab
// ============================================================================
function ObservabilityTab() {
  // Real-time updates every 5 seconds
  const { data: metrics } = trpc.level5.observability.getMetrics.useQuery({}, {
    refetchInterval: 5000,
  });
  const { data: errors } = trpc.level5.observability.getErrors.useQuery({}, {
    refetchInterval: 10000,
  });
  const { data: healthSnapshot } = trpc.level5.observability.getHealthSnapshot.useQuery(undefined, {
    refetchInterval: 3000,
  });
  const { data: feedbackInsights } = trpc.level5.observability.getInsights.useQuery(undefined, {
    refetchInterval: 30000,
  });

  // Sample performance data
  const performanceData = [
    { time: '00:00', cpu: 45, memory: 62, responseTime: 120 },
    { time: '04:00', cpu: 38, memory: 58, responseTime: 110 },
    { time: '08:00', cpu: 72, memory: 75, responseTime: 180 },
    { time: '12:00', cpu: 85, memory: 82, responseTime: 220 },
    { time: '16:00', cpu: 68, memory: 71, responseTime: 150 },
    { time: '20:00', cpu: 52, memory: 64, responseTime: 130 },
  ];

  const errorRateData = [
    { hour: '00:00', errors: 2, warnings: 5 },
    { hour: '04:00', errors: 1, warnings: 3 },
    { hour: '08:00', errors: 4, warnings: 8 },
    { hour: '12:00', errors: 3, warnings: 6 },
    { hour: '16:00', errors: 2, warnings: 4 },
    { hour: '20:00', errors: 1, warnings: 2 },
  ];

  const agentActivityData = [
    { agent: 'Research', tasks: 45, success: 42 },
    { agent: 'Communication', tasks: 38, success: 36 },
    { agent: 'Analysis', tasks: 52, success: 50 },
    { agent: 'Planning', tasks: 28, success: 27 },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">System Observability</h2>
        <p className="text-muted-foreground">
          Real-time monitoring of all Level 5 AI systems
        </p>
      </div>

      {/* Health Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              System Health
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-6 h-6 text-green-500" />
              <span className="text-2xl font-bold">Healthy</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              All systems operational
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Avg Response Time
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">152ms</div>
            <p className="text-xs text-muted-foreground mt-1">
              <span className="text-green-500">↓ 12%</span> from last hour
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Error Rate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">0.3%</div>
            <p className="text-xs text-muted-foreground mt-1">
              <span className="text-green-500">↓ 0.2%</span> from yesterday
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Active Agents
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">8/12</div>
            <p className="text-xs text-muted-foreground mt-1">
              67% utilization
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Performance Metrics Chart */}
      <Card>
        <CardHeader>
          <CardTitle>System Performance</CardTitle>
          <CardDescription>
            CPU, memory usage, and response times over the last 24 hours
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={performanceData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="time" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="cpu" stroke="#3b82f6" name="CPU (%)" />
              <Line type="monotone" dataKey="memory" stroke="#8b5cf6" name="Memory (%)" />
              <Line type="monotone" dataKey="responseTime" stroke="#10b981" name="Response Time (ms)" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Error Rate Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Error & Warning Trends</CardTitle>
          <CardDescription>
            System errors and warnings over time
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={errorRateData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="hour" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Area type="monotone" dataKey="errors" stackId="1" stroke="#ef4444" fill="#ef4444" name="Errors" />
              <Area type="monotone" dataKey="warnings" stackId="1" stroke="#f59e0b" fill="#f59e0b" name="Warnings" />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Agent Activity Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Agent Activity</CardTitle>
          <CardDescription>
            Task completion rates by agent type
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={agentActivityData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="agent" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="tasks" fill="#3b82f6" name="Total Tasks" />
              <Bar dataKey="success" fill="#10b981" name="Successful" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Feedback Loop Insights */}
      <Card>
        <CardHeader>
          <CardTitle>Feedback Loop Insights</CardTitle>
          <CardDescription>
            Continuous improvement recommendations from the system
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
              <Brain className="w-5 h-5 text-blue-500 mt-0.5" />
              <div>
                <p className="text-sm font-medium">Performance Optimization</p>
                <p className="text-xs text-muted-foreground">
                  Agent response times improved by 15% after implementing caching strategy
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
              <CheckCircle className="w-5 h-5 text-green-500 mt-0.5" />
              <div>
                <p className="text-sm font-medium">Goal Achievement</p>
                <p className="text-xs text-muted-foreground">
                  3 goals completed ahead of schedule this week
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-yellow-50 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-yellow-500 mt-0.5" />
              <div>
                <p className="text-sm font-medium">Resource Alert</p>
                <p className="text-xs text-muted-foreground">
                  Memory usage trending upward - consider scaling or optimization
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
