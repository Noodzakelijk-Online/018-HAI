import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Cpu,
  CheckCircle2,
  XCircle,
  Clock,
  HardDrive,
  Monitor,
  Smartphone,
  Activity
} from "lucide-react";

export default function Agents() {
  const [selectedHouseholdId, setSelectedHouseholdId] = useState<number | null>(null);

  // Fetch user's households
  const { data: households } = trpc.households.list.useQuery();
  
  // Auto-select first household
  useEffect(() => {
    if (households && households.length > 0 && !selectedHouseholdId) {
      setSelectedHouseholdId(households[0].id);
    }
  }, [households, selectedHouseholdId]);

  const { data: agents, isLoading } = trpc.agents.list.useQuery(
    { householdId: selectedHouseholdId! },
    { 
      enabled: !!selectedHouseholdId,
      refetchInterval: 5000, // Poll every 5 seconds for agent status
    }
  );
  
  const { data: connectedCount } = trpc.agents.getConnectedCount.useQuery(undefined, {
    refetchInterval: 5000,
  });

  const onlineAgents = agents?.filter(a => a.status === "online") || [];
  const offlineAgents = agents?.filter(a => a.status === "offline") || [];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Agent Fleet</h1>
          <p className="text-muted-foreground mt-2">
            Auto-detected HAI agents running on your devices
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Agents</CardTitle>
              <Cpu className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{agents?.length || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Devices running HAI
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Online Now</CardTitle>
              <Zap className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-500">
                {connectedCount || 0}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Active connections
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Offline</CardTitle>
              <XCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{offlineAgents.length}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Disconnected devices
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Agents List */}
        <Card>
          <CardHeader>
            <CardTitle>Registered Agents</CardTitle>
            <CardDescription>
              Agents are automatically detected when the Desktop Agent starts on your devices
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="flex items-center gap-4 p-4 border rounded-lg">
                    <Skeleton className="h-12 w-12 rounded-full" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-32" />
                      <Skeleton className="h-3 w-48" />
                    </div>
                  </div>
                ))}
              </div>
            ) : agents && agents.length > 0 ? (
              <div className="space-y-3">
                {agents.map((agent) => (
                  <div
                    key={agent.id}
                    className="flex items-center gap-4 p-4 border rounded-lg hover:bg-accent/50 transition-colors"
                  >
                    {/* Agent Icon */}
                    <div className={`h-12 w-12 rounded-full flex items-center justify-center ${
                      agent.status === "online" ? "bg-green-500/10" : "bg-muted"
                    }`}>
                      {agent.type === "windows" || agent.type === "linux" || agent.type === "macos" ? (
                        <Monitor className={`h-6 w-6 ${
                          agent.status === "online" ? "text-green-500" : "text-muted-foreground"
                        }`} />
                      ) : agent.type === "mobile" ? (
                        <Smartphone className={`h-6 w-6 ${
                          agent.status === "online" ? "text-green-500" : "text-muted-foreground"
                        }`} />
                      ) : (
                        <Cpu className={`h-6 w-6 ${
                          agent.status === "online" ? "text-green-500" : "text-muted-foreground"
                        }`} />
                      )}
                    </div>

                    {/* Agent Info */}
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold">{agent.name}</h3>
                        <Badge variant={agent.status === "online" ? "default" : "secondary"}>
                          {agent.status === "online" ? (
                            <><CheckCircle2 className="h-3 w-3 mr-1" /> Online</>
                          ) : (
                            <><XCircle className="h-3 w-3 mr-1" /> Offline</>
                          )}
                        </Badge>
                        <Badge variant="outline">{agent.type}</Badge>
                      </div>
                      <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {agent.lastSeen ? new Date(agent.lastSeen).toLocaleString() : "Never"}
                        </span>
                        {agent.status === "online" && (
                          <>
                            <span className="flex items-center gap-1">
                              <Activity className="h-3 w-3" />
                              Active
                            </span>
                            <span className="flex items-center gap-1">
                              <HardDrive className="h-3 w-3" />
                              Monitoring screens
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Cpu className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No agents detected</h3>
                <p className="text-sm text-muted-foreground max-w-md mx-auto">
                  Start the Desktop Agent on your Windows PC to automatically register it. 
                  Agents will appear here once they connect.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
