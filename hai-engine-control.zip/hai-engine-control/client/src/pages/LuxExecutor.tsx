import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Loader2, CheckCircle2, XCircle, Sparkles, Zap, Brain } from 'lucide-react';

/**
 * Lux Executor Page
 * 
 * Interface for testing OpenAGI Lux computer-use agent
 */

type LuxModel = 'lux-actor-1' | 'lux-tasker-1' | 'lux-thinker-1';

export default function LuxExecutor() {
  const [goal, setGoal] = useState('');
  const [model, setModel] = useState<LuxModel>('lux-actor-1');
  
  const executeMutation = trpc.lux.execute.useMutation();
  const { data: statusData } = trpc.lux.checkStatus.useQuery();
  const { data: models } = trpc.lux.getModels.useQuery();
  
  const handleExecute = async () => {
    if (!goal.trim()) return;
    
    try {
      await executeMutation.mutateAsync({ goal, model });
    } catch (error) {
      console.error('Lux execution failed:', error);
    }
  };

  const getModelIcon = (modelId: string) => {
    switch (modelId) {
      case 'lux-actor-1':
        return <Zap className="w-4 h-4" />;
      case 'lux-tasker-1':
        return <Sparkles className="w-4 h-4" />;
      case 'lux-thinker-1':
        return <Brain className="w-4 h-4" />;
      default:
        return null;
    }
  };

  const getModelColor = (modelId: string) => {
    switch (modelId) {
      case 'lux-actor-1':
        return 'text-yellow-600';
      case 'lux-tasker-1':
        return 'text-blue-600';
      case 'lux-thinker-1':
        return 'text-purple-600';
      default:
        return 'text-gray-600';
    }
  };

  return (
    <div className="container max-w-4xl py-8">
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold">Lux Executor</h1>
          <p className="text-muted-foreground mt-2">
            Execute computer-use tasks with OpenAGI Lux
          </p>
        </div>

        {/* Status Alert */}
        {statusData && (
          <Alert variant={statusData.available ? "default" : "destructive"}>
            <AlertDescription className="flex items-center gap-2">
              {statusData.available ? (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  Lux is available and ready
                </>
              ) : (
                <>
                  <XCircle className="w-4 h-4" />
                  {statusData.error || 'Lux is not available'}
                </>
              )}
            </AlertDescription>
          </Alert>
        )}

        {/* Model Selection Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {models?.map((modelInfo) => (
            <Card
              key={modelInfo.id}
              className={`cursor-pointer transition-all ${
                model === modelInfo.id
                  ? 'ring-2 ring-primary'
                  : 'hover:shadow-md'
              }`}
              onClick={() => setModel(modelInfo.id)}
            >
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <span className={getModelColor(modelInfo.id)}>
                    {getModelIcon(modelInfo.id)}
                  </span>
                  {modelInfo.name}
                </CardTitle>
                <CardDescription>{modelInfo.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Speed:</span>
                    <Badge variant="outline">{modelInfo.estimatedSpeed}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Cost:</span>
                    <Badge variant="outline">${modelInfo.costPerMinute}/min</Badge>
                  </div>
                  <div className="mt-3">
                    <p className="text-muted-foreground mb-1">Use cases:</p>
                    <ul className="text-xs space-y-1">
                      {modelInfo.useCases.map((useCase, i) => (
                        <li key={i} className="flex items-start gap-1">
                          <span className="text-primary">•</span>
                          <span>{useCase}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Task Input */}
        <Card>
          <CardHeader>
            <CardTitle>Task Goal</CardTitle>
            <CardDescription>
              Describe what you want Lux to do on your computer
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              placeholder="Example: Go to Google and search for OpenAGI Lux"
              value={goal}
              onChange={(e) => setGoal(e.target.value)}
              rows={4}
              className="resize-none"
            />
            
            <div className="flex items-center gap-4">
              <Select value={model} onValueChange={(value) => setModel(value as LuxModel)}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="lux-actor-1">
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-yellow-600" />
                      Actor (Fast)
                    </div>
                  </SelectItem>
                  <SelectItem value="lux-tasker-1">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-blue-600" />
                      Tasker (Stable)
                    </div>
                  </SelectItem>
                  <SelectItem value="lux-thinker-1">
                    <div className="flex items-center gap-2">
                      <Brain className="w-4 h-4 text-purple-600" />
                      Thinker (Complex)
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>

              <Button
                onClick={handleExecute}
                disabled={executeMutation.isPending || !goal.trim() || !statusData?.available}
                className="flex-1"
              >
                {executeMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Executing...
                  </>
                ) : (
                  'Execute with Lux'
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Execution Result */}
        {executeMutation.data && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {executeMutation.data.success ? (
                  <>
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                    Execution Successful
                  </>
                ) : (
                  <>
                    <XCircle className="w-5 h-5 text-red-600" />
                    Execution Failed
                  </>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Metrics */}
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Duration</p>
                  <p className="text-2xl font-bold">{executeMutation.data.duration.toFixed(2)}s</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Cost</p>
                  <p className="text-2xl font-bold">${executeMutation.data.cost.toFixed(4)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Actions</p>
                  <p className="text-2xl font-bold">{executeMutation.data.actions.length}</p>
                </div>
              </div>

              {/* Output */}
              {executeMutation.data.output && (
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Output:</p>
                  <div className="bg-muted p-4 rounded-md">
                    <pre className="text-sm whitespace-pre-wrap">{executeMutation.data.output}</pre>
                  </div>
                </div>
              )}

              {/* Error */}
              {executeMutation.data.error && (
                <Alert variant="destructive">
                  <AlertDescription>{executeMutation.data.error}</AlertDescription>
                </Alert>
              )}

              {/* Actions Log */}
              {executeMutation.data.actions.length > 0 && (
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Actions Taken:</p>
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {executeMutation.data.actions.map((action, i) => (
                      <div key={i} className="bg-muted p-3 rounded-md text-sm">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{action.type}</span>
                          <span className="text-xs text-muted-foreground">{action.timestamp}</span>
                        </div>
                        {action.target && (
                          <p className="text-muted-foreground mt-1">Target: {action.target}</p>
                        )}
                        {action.value && (
                          <p className="text-muted-foreground mt-1">Value: {action.value}</p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Screenshots */}
              {executeMutation.data.screenshots.length > 0 && (
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Screenshots:</p>
                  <div className="grid grid-cols-2 gap-4">
                    {executeMutation.data.screenshots.map((screenshot, i) => (
                      <img
                        key={i}
                        src={screenshot}
                        alt={`Screenshot ${i + 1}`}
                        className="rounded-md border"
                      />
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Example Tasks */}
        <Card>
          <CardHeader>
            <CardTitle>Example Tasks</CardTitle>
            <CardDescription>Click to try these examples</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {[
              { model: 'lux-actor-1' as LuxModel, goal: 'Go to https://agiopen.org' },
              { model: 'lux-actor-1' as LuxModel, goal: 'Search Google for "OpenAGI Lux model"' },
              { model: 'lux-tasker-1' as LuxModel, goal: 'Open Excel and create a new spreadsheet' },
              { model: 'lux-thinker-1' as LuxModel, goal: 'Research the top 3 AI agent frameworks and create a comparison' }
            ].map((example, i) => (
              <Button
                key={i}
                variant="outline"
                className="w-full justify-start text-left"
                onClick={() => {
                  setGoal(example.goal);
                  setModel(example.model);
                }}
              >
                <span className={`mr-2 ${getModelColor(example.model)}`}>
                  {getModelIcon(example.model)}
                </span>
                {example.goal}
              </Button>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
