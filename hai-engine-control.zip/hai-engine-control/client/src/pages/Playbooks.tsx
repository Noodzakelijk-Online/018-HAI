import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Play, Plus, BookOpen, Activity, CheckCircle, XCircle, Clock, Pause, Workflow } from "lucide-react";
import { WorkflowDesigner, WorkflowNode, WorkflowConnection } from "@/components/WorkflowDesigner";
import { toast } from "sonner";

/**
 * Playbooks Page
 * 
 * Features:
 * - Playbook library
 * - Workflow execution
 * - Execution monitoring
 * - Template management
 */
export default function Playbooks() {
  const [activeTab, setActiveTab] = useState("playbooks");
  const [workflowNodes, setWorkflowNodes] = useState<WorkflowNode[]>([]);
  const [workflowConnections, setWorkflowConnections] = useState<WorkflowConnection[]>([]);
  const [selectedPlaybookId, setSelectedPlaybookId] = useState<number | undefined>();
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [executeDialogOpen, setExecuteDialogOpen] = useState(false);

  // Queries
  const { data: playbooks, isLoading: loadingPlaybooks, refetch: refetchPlaybooks } = trpc.playbook.getAll.useQuery();
  const { data: selectedPlaybook } = trpc.playbook.getById.useQuery(
    { id: selectedPlaybookId! },
    { enabled: !!selectedPlaybookId }
  );
  const { data: executions, refetch: refetchExecutions } = trpc.playbook.getExecutions.useQuery(
    { playbookId: selectedPlaybookId! },
    { enabled: !!selectedPlaybookId }
  );
  const { data: categories } = trpc.playbook.getCategories.useQuery();

  // Mutations
  const createPlaybook = trpc.playbook.create.useMutation({
    onSuccess: () => {
      toast.success("Playbook created successfully");
      setCreateDialogOpen(false);
      refetchPlaybooks();
    },
    onError: (error) => {
      toast.error(`Failed to create playbook: ${error.message}`);
    },
  });

  const executePlaybook = trpc.playbook.execute.useMutation({
    onSuccess: () => {
      toast.success("Playbook execution started");
      setExecuteDialogOpen(false);
      refetchExecutions();
    },
    onError: (error) => {
      toast.error(`Failed to execute playbook: ${error.message}`);
    },
  });

  const cancelExecution = trpc.playbook.cancelExecution.useMutation({
    onSuccess: () => {
      toast.success("Execution cancelled");
      refetchExecutions();
    },
    onError: (error) => {
      toast.error(`Failed to cancel execution: ${error.message}`);
    },
  });

  const handleCreatePlaybook = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    // Simple example workflow
    const exampleWorkflow = {
      steps: [
        {
          id: "step1",
          name: "Initialize",
          type: "action" as const,
          action: "initialize",
          params: {},
          onSuccess: "step2",
        },
        {
          id: "step2",
          name: "Process",
          type: "action" as const,
          action: "process",
          params: {},
          onSuccess: "step3",
        },
        {
          id: "step3",
          name: "Complete",
          type: "action" as const,
          action: "complete",
          params: {},
        },
      ],
      variables: {},
      triggers: [],
    };

    createPlaybook.mutate({
      name: formData.get("name") as string,
      description: formData.get("description") as string,
      category: formData.get("category") as string,
      definition: exampleWorkflow,
      metadata: {},
    });
  };

  const handleExecutePlaybook = (playbookId: number) => {
    executePlaybook.mutate({
      playbookId,
      initialContext: {},
    });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "failed":
        return <XCircle className="h-4 w-4 text-red-500" />;
      case "running":
        return <Activity className="h-4 w-4 text-blue-500 animate-pulse" />;
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-500" />;
      case "cancelled":
        return <Pause className="h-4 w-4 text-gray-500" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500/10 text-green-500";
      case "draft":
        return "bg-yellow-500/10 text-yellow-500";
      case "archived":
        return "bg-gray-500/10 text-gray-500";
      case "deprecated":
        return "bg-red-500/10 text-red-500";
      default:
        return "bg-gray-500/10 text-gray-500";
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Playbook Engine</h1>
          <p className="text-muted-foreground mt-1">
            Predefined workflows with templates and execution monitoring
          </p>
        </div>
        <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Create Playbook
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Playbook</DialogTitle>
              <DialogDescription>
                Define a new workflow playbook with steps and actions
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreatePlaybook} className="space-y-4">
              <div>
                <Label htmlFor="name">Name</Label>
                <Input id="name" name="name" required />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea id="description" name="description" />
              </div>
              <div>
                <Label htmlFor="category">Category</Label>
                <Input id="category" name="category" placeholder="e.g., automation, communication" />
              </div>
              <Button type="submit" disabled={createPlaybook.isPending}>
                {createPlaybook.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating...
                  </>
                ) : (
                  "Create Playbook"
                )}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Total Playbooks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{playbooks?.length || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Active Playbooks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {playbooks?.filter(p => p.status === 'active').length || 0}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Categories</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{categories?.length || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Total Executions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {playbooks?.reduce((sum, p) => sum + (executions?.length || 0), 0) || 0}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="playbooks">
            <BookOpen className="mr-2 h-4 w-4" />
            Playbooks
          </TabsTrigger>
          <TabsTrigger value="designer">
            <Workflow className="mr-2 h-4 w-4" />
            Designer
          </TabsTrigger>
          <TabsTrigger value="executions">
            <Activity className="mr-2 h-4 w-4" />
            Executions
          </TabsTrigger>
        </TabsList>

        {/* Playbooks Tab */}
        <TabsContent value="playbooks" className="space-y-4">
          {loadingPlaybooks ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : playbooks && playbooks.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {playbooks.map((playbook) => {
                const definition = playbook.definition as any;
                return (
                  <Card
                    key={playbook.id}
                    className="cursor-pointer hover:bg-accent transition-colors"
                    onClick={() => setSelectedPlaybookId(playbook.id)}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <CardTitle className="text-lg">{playbook.name}</CardTitle>
                          {playbook.category && (
                            <Badge variant="outline" className="mt-2">
                              {playbook.category}
                            </Badge>
                          )}
                        </div>
                        <Badge className={getStatusColor(playbook.status)}>
                          {playbook.status}
                        </Badge>
                      </div>
                      <CardDescription className="mt-2">
                        {playbook.description || "No description"}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <span>{definition?.steps?.length || 0} steps</span>
                        <span>v{playbook.version}</span>
                      </div>
                      {playbook.status === 'active' && (
                        <Button
                          size="sm"
                          className="w-full mt-3"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleExecutePlaybook(playbook.id);
                          }}
                        >
                          <Play className="mr-2 h-4 w-4" />
                          Execute
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <BookOpen className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-center text-muted-foreground">
                  No playbooks yet. Create your first workflow playbook!
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Designer Tab */}
        <TabsContent value="designer" className="space-y-4">
          <WorkflowDesigner
            nodes={workflowNodes}
            connections={workflowConnections}
            onNodesChange={setWorkflowNodes}
            onConnectionsChange={setWorkflowConnections}
            onNodeClick={(node) => {
              toast.info(`Clicked node: ${node.label}`);
            }}
            onAddNode={(type) => {
              const newNode: WorkflowNode = {
                id: `node-${Date.now()}`,
                type,
                label: `New ${type}`,
                position: {
                  x: 100 + workflowNodes.length * 50,
                  y: 100 + workflowNodes.length * 30,
                },
              };
              setWorkflowNodes([...workflowNodes, newNode]);
              toast.success(`Added ${type} node`);
            }}
          />
          <div className="flex justify-end gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setWorkflowNodes([]);
                setWorkflowConnections([]);
                toast.success("Workflow cleared");
              }}
            >
              Clear
            </Button>
            <Button
              onClick={() => {
                toast.success("Workflow saved (not implemented)");
              }}
            >
              Save Workflow
            </Button>
          </div>
        </TabsContent>

        {/* Executions Tab */}
        <TabsContent value="executions" className="space-y-4">
          {selectedPlaybookId && executions ? (
            <div className="space-y-3">
              {executions.length > 0 ? (
                executions.map((execution) => (
                  <Card key={execution.id}>
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {getStatusIcon(execution.status)}
                          <div>
                            <p className="font-medium">Execution #{execution.id}</p>
                            <p className="text-sm text-muted-foreground">
                              Step {execution.currentStep} of {execution.totalSteps}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge>{execution.status}</Badge>
                          {execution.status === 'running' && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => cancelExecution.mutate({ executionId: execution.id })}
                            >
                              Cancel
                            </Button>
                          )}
                        </div>
                      </div>
                      {execution.errorMessage && (
                        <p className="text-sm text-red-500 mt-3">
                          Error: {execution.errorMessage}
                        </p>
                      )}
                      <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
                        {execution.startedAt && (
                          <span>Started: {new Date(execution.startedAt).toLocaleString()}</span>
                        )}
                        {execution.completedAt && (
                          <span>Completed: {new Date(execution.completedAt).toLocaleString()}</span>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center py-12">
                    <Activity className="h-12 w-12 text-muted-foreground mb-4" />
                    <p className="text-center text-muted-foreground">
                      No executions for this playbook yet
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Activity className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-center text-muted-foreground">
                  Select a playbook to view its executions
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
