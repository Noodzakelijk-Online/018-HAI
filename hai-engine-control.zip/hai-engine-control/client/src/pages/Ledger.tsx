import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BookOpen, Shield, Clock, Download, Search, CheckCircle2, XCircle } from "lucide-react";

export default function Ledger() {
  const [selectedEvent, setSelectedEvent] = useState<any>(null);
  const [eventTypeFilter, setEventTypeFilter] = useState("");
  const [actorFilter, setActorFilter] = useState("");
  const [replaySeq, setReplaySeq] = useState("");
  const [replayResult, setReplayResult] = useState<any>(null);

  // Query ledger events
  const { data: events, isLoading: eventsLoading } = trpc.ledger.query.useQuery({
    limit: 100,
    eventType: eventTypeFilter || undefined,
    actor: actorFilter || undefined,
  });

  // Get ledger statistics
  const { data: stats, isLoading: statsLoading } = trpc.ledger.statistics.useQuery();

  // Verify integrity
  const { data: integrity, refetch: refetchIntegrity } = trpc.ledger.verifyIntegrity.useQuery({});

  // Replay to sequence
  const replayMutation = trpc.ledger.replayToSequence.useQuery(
    { targetSeq: parseInt(replaySeq) },
    { enabled: false }
  );

  // Export ledger
  const exportMutation = trpc.ledger.export.useQuery({}, { enabled: false });

  const handleReplay = async () => {
    if (!replaySeq) {
      toast.error("Please enter a sequence number");
      return;
    }

    try {
      const result = await replayMutation.refetch();
      if (result.data) {
        setReplayResult(result.data);
        toast.success(`Replayed to sequence ${replaySeq}`);
      }
    } catch (error: any) {
      toast.error(`Replay failed: ${error.message}`);
    }
  };

  const handleExport = async () => {
    try {
      const result = await exportMutation.refetch();
      if (result.data) {
        const blob = new Blob([result.data], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `ledger-export-${new Date().toISOString()}.json`;
        a.click();
        toast.success("Ledger exported successfully");
      }
    } catch (error: any) {
      toast.error(`Export failed: ${error.message}`);
    }
  };

  const handleVerifyIntegrity = async () => {
    try {
      const result = await refetchIntegrity();
      if (result.data) {
        if (result.data.valid) {
          toast.success("Ledger integrity verified ✓");
        } else {
          toast.error(`Integrity check failed: ${result.data.errors.length} errors found`);
        }
      }
    } catch (error: any) {
      toast.error(`Verification failed: ${error.message}`);
    }
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Household Ledger</h1>
        <p className="text-muted-foreground">
          Immutable audit trail and event sourcing for all HAI operations
        </p>
      </div>

      {/* Statistics Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Events</CardTitle>
            <BookOpen className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalEvents || 0}</div>
            <p className="text-xs text-muted-foreground">
              Sequence: {stats?.currentSequence || 0}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Integrity</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {integrity?.valid ? (
                <span className="text-green-600">Valid</span>
              ) : (
                <span className="text-red-600">Invalid</span>
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              {integrity?.errors.length || 0} errors
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">First Event</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-sm font-mono">
              {stats?.firstEvent
                ? new Date(stats.firstEvent).toLocaleDateString()
                : "N/A"}
            </div>
            <p className="text-xs text-muted-foreground">
              {stats?.firstEvent
                ? new Date(stats.firstEvent).toLocaleTimeString()
                : ""}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Last Event</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-sm font-mono">
              {stats?.lastEvent
                ? new Date(stats.lastEvent).toLocaleDateString()
                : "N/A"}
            </div>
            <p className="text-xs text-muted-foreground">
              {stats?.lastEvent
                ? new Date(stats.lastEvent).toLocaleTimeString()
                : ""}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Actions */}
      <div className="flex gap-2">
        <Button onClick={handleVerifyIntegrity} variant="outline">
          <Shield className="h-4 w-4 mr-2" />
          Verify Integrity
        </Button>
        <Button onClick={handleExport} variant="outline">
          <Download className="h-4 w-4 mr-2" />
          Export Ledger
        </Button>
      </div>

      <Tabs defaultValue="events" className="w-full">
        <TabsList>
          <TabsTrigger value="events">Event Log</TabsTrigger>
          <TabsTrigger value="replay">Time Travel</TabsTrigger>
          <TabsTrigger value="stats">Statistics</TabsTrigger>
        </TabsList>

        <TabsContent value="events" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle>Filters</CardTitle>
            </CardHeader>
            <CardContent className="flex gap-4">
              <div className="flex-1">
                <Label htmlFor="eventType">Event Type</Label>
                <Input
                  id="eventType"
                  placeholder="e.g., task.created"
                  value={eventTypeFilter}
                  onChange={(e) => setEventTypeFilter(e.target.value)}
                />
              </div>
              <div className="flex-1">
                <Label htmlFor="actor">Actor</Label>
                <Input
                  id="actor"
                  placeholder="e.g., user_123"
                  value={actorFilter}
                  onChange={(e) => setActorFilter(e.target.value)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Events Table */}
          <Card>
            <CardHeader>
              <CardTitle>Event Log</CardTitle>
              <CardDescription>
                Showing last {events?.length || 0} events
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[500px]">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Seq</TableHead>
                      <TableHead>Timestamp</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Source</TableHead>
                      <TableHead>Actor</TableHead>
                      <TableHead>Hash</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {eventsLoading && (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center">
                          Loading...
                        </TableCell>
                      </TableRow>
                    )}
                    {events?.map((event: any) => (
                      <TableRow key={event.id}>
                        <TableCell className="font-mono">{event.sequenceNumber}</TableCell>
                        <TableCell className="text-sm">
                          {new Date(event.timestamp).toLocaleString()}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{event.eventType}</Badge>
                        </TableCell>
                        <TableCell className="text-sm">{event.eventSource}</TableCell>
                        <TableCell className="text-sm">{event.actor}</TableCell>
                        <TableCell className="font-mono text-xs">
                          {event.hash.substring(0, 8)}...
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setSelectedEvent(event)}
                          >
                            <Search className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="replay" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Time Travel Debugging</CardTitle>
              <CardDescription>
                Replay events to reconstruct system state at any point in time
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-4">
                <div className="flex-1">
                  <Label htmlFor="replaySeq">Sequence Number</Label>
                  <Input
                    id="replaySeq"
                    type="number"
                    placeholder="e.g., 100"
                    value={replaySeq}
                    onChange={(e) => setReplaySeq(e.target.value)}
                  />
                </div>
                <div className="flex items-end">
                  <Button onClick={handleReplay}>
                    <Clock className="h-4 w-4 mr-2" />
                    Replay
                  </Button>
                </div>
              </div>

              {replayResult && (
                <div className="mt-4">
                  <h3 className="font-semibold mb-2">Reconstructed State</h3>
                  <ScrollArea className="h-[400px] border rounded-md p-4">
                    <pre className="text-xs">
                      {JSON.stringify(replayResult, null, 2)}
                    </pre>
                  </ScrollArea>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="stats" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Events by Type</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[300px]">
                  <div className="space-y-2">
                    {stats?.eventsByType &&
                      Object.entries(stats.eventsByType).map(([type, count]) => (
                        <div key={type} className="flex justify-between items-center">
                          <span className="text-sm">{type}</span>
                          <Badge>{count}</Badge>
                        </div>
                      ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Events by Actor</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[300px]">
                  <div className="space-y-2">
                    {stats?.eventsByActor &&
                      Object.entries(stats.eventsByActor).map(([actor, count]) => (
                        <div key={actor} className="flex justify-between items-center">
                          <span className="text-sm">{actor}</span>
                          <Badge>{count}</Badge>
                        </div>
                      ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Event Detail Dialog */}
      <Dialog open={!!selectedEvent} onOpenChange={() => setSelectedEvent(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Event Details</DialogTitle>
            <DialogDescription>
              Sequence #{selectedEvent?.sequenceNumber}
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="h-[500px]">
            <div className="space-y-4">
              <div>
                <Label>Event Type</Label>
                <div className="mt-1">
                  <Badge>{selectedEvent?.eventType}</Badge>
                </div>
              </div>
              <div>
                <Label>Source</Label>
                <div className="mt-1 text-sm">{selectedEvent?.eventSource}</div>
              </div>
              <div>
                <Label>Actor</Label>
                <div className="mt-1 text-sm">{selectedEvent?.actor}</div>
              </div>
              <div>
                <Label>Timestamp</Label>
                <div className="mt-1 text-sm">
                  {selectedEvent && new Date(selectedEvent.timestamp).toLocaleString()}
                </div>
              </div>
              <div>
                <Label>Hash</Label>
                <div className="mt-1 font-mono text-xs break-all">
                  {selectedEvent?.hash}
                </div>
              </div>
              <div>
                <Label>Previous Hash</Label>
                <div className="mt-1 font-mono text-xs break-all">
                  {selectedEvent?.previousHash || "N/A"}
                </div>
              </div>
              <div>
                <Label>Payload</Label>
                <ScrollArea className="h-[200px] border rounded-md p-4 mt-1">
                  <pre className="text-xs">
                    {JSON.stringify(selectedEvent?.payload, null, 2)}
                  </pre>
                </ScrollArea>
              </div>
              <div>
                <Label>Metadata</Label>
                <ScrollArea className="h-[150px] border rounded-md p-4 mt-1">
                  <pre className="text-xs">
                    {JSON.stringify(selectedEvent?.metadata, null, 2)}
                  </pre>
                </ScrollArea>
              </div>
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}
