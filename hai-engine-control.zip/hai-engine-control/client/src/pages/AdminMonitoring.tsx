import { useState, useMemo } from 'react';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { trpc } from '@/lib/trpc';
import { 
  Activity, 
  AlertTriangle, 
  CheckCircle, 
  Database, 
  FileText, 
  Heart, 
  RefreshCw, 
  Search, 
  Server, 
  Shield, 
  XCircle,
  Zap,
  BarChart3,
  TrendingUp,
  TrendingDown,
  Minus
} from 'lucide-react';
import {
  LineChart as RechartsLineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

export default function AdminMonitoring() {
  const [searchQuery, setSearchQuery] = useState('');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Fetch health data
  const { data: healthData, refetch: refetchHealth } = trpc.health.system.useQuery(undefined, {
    refetchInterval: 30000,
  });

  // Fetch real-time metrics (5 second refresh)
  const { data: metricsData, refetch: refetchMetrics } = trpc.health.metrics.useQuery(undefined, {
    refetchInterval: 5000,
  });

  // Fetch metrics history for charts
  const { data: metricsHistory } = trpc.health.metricsHistory.useQuery(
    { limit: 50 },
    { refetchInterval: 10000 }
  );

  // Fetch aggregated stats
  const { data: aggregatedStats } = trpc.health.aggregatedStats.useQuery(
    { periodMs: 3600000 },
    { refetchInterval: 60000 }
  );

  // Fetch audit logs
  const { data: auditLogs, refetch: refetchAudit } = trpc.health.auditLogs.useQuery(
    { limit: 50 },
    { refetchInterval: 30000 }
  );

  // Fetch audit stats
  const { data: auditStats } = trpc.health.auditStats.useQuery(undefined, {
    refetchInterval: 30000,
  });

  // Fetch system logs
  const { data: systemLogs } = trpc.health.logs.useQuery(
    { count: 50 },
    { refetchInterval: 10000 }
  );

  // Fetch log stats
  const { data: logStats } = trpc.health.logStats.useQuery(undefined, {
    refetchInterval: 30000,
  });

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await Promise.all([
      refetchHealth(),
      refetchMetrics(),
      refetchAudit(),
    ]);
    setTimeout(() => setIsRefreshing(false), 1000);
  };

  // Transform metrics history for charts
  const performanceChartData = useMemo(() => {
    if (!metricsHistory) return [];
    return metricsHistory.map((m: any) => ({
      time: new Date(m.timestamp).toLocaleTimeString(),
      responseTime: m.requests.avgResponseTime,
      requests: m.requests.perSecond,
      errors: m.requests.errorRate,
    }));
  }, [metricsHistory]);

  const memoryChartData = useMemo(() => {
    if (!metricsHistory) return [];
    return metricsHistory.map((m: any) => ({
      time: new Date(m.timestamp).toLocaleTimeString(),
      heap: m.memory.heapUsed,
      rss: m.memory.rss,
    }));
  }, [metricsHistory]);

  // Transform log stats for pie chart
  const logLevelDistribution = useMemo(() => {
    if (!logStats) return [];
    return [
      { name: 'Info', value: logStats.info || 0, color: '#22c55e' },
      { name: 'Debug', value: logStats.debug || 0, color: '#06b6d4' },
      { name: 'Warning', value: logStats.warn || 0, color: '#eab308' },
      { name: 'Error', value: (logStats.error || 0) + (logStats.fatal || 0), color: '#ef4444' },
    ].filter(item => item.value > 0);
  }, [logStats]);

  // Filter audit logs
  const filteredAuditData = useMemo(() => {
    if (!auditLogs) return [];
    return auditLogs.filter((entry: any) => {
      const matchesSearch = entry.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        entry.action?.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesSeverity = severityFilter === 'all' || entry.severity === severityFilter;
      return matchesSearch && matchesSeverity;
    });
  }, [auditLogs, searchQuery, severityFilter]);

  // Current metrics
  const currentMetrics = metricsData?.current;

  return (
    <DashboardLayout>
      <div className="space-y-6 p-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Admin Monitoring</h1>
            <p className="text-muted-foreground mt-1">
              Real-time system health, performance metrics, and audit logs
            </p>
          </div>
          <Button onClick={handleRefresh} disabled={isRefreshing}>
            <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>

        {/* Health Status Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">System Status</p>
                  <p className={`text-2xl font-bold ${healthData?.status === 'healthy' ? 'text-green-500' : 'text-yellow-500'}`}>
                    {healthData?.status || 'Loading...'}
                  </p>
                </div>
                <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded-full">
                  <Heart className="h-6 w-6 text-green-500" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Avg Response Time</p>
                  <p className="text-2xl font-bold">
                    {currentMetrics?.requests.avgResponseTime || 0}ms
                  </p>
                </div>
                <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-full">
                  <Zap className="h-6 w-6 text-blue-500" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Error Rate</p>
                  <p className={`text-2xl font-bold ${(currentMetrics?.requests.errorRate || 0) > 5 ? 'text-red-500' : 'text-yellow-500'}`}>
                    {currentMetrics?.requests.errorRate?.toFixed(1) || 0}%
                  </p>
                </div>
                <div className="p-3 bg-yellow-100 dark:bg-yellow-900/30 rounded-full">
                  <AlertTriangle className="h-6 w-6 text-yellow-500" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Active Connections</p>
                  <p className="text-2xl font-bold">
                    {currentMetrics?.connections.active || 0}
                  </p>
                </div>
                <div className="p-3 bg-purple-100 dark:bg-purple-900/30 rounded-full">
                  <Activity className="h-6 w-6 text-purple-500" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="health" className="space-y-4">
          <TabsList>
            <TabsTrigger value="health" className="flex items-center gap-2">
              <Heart className="h-4 w-4" />
              Health
            </TabsTrigger>
            <TabsTrigger value="performance" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Performance
            </TabsTrigger>
            <TabsTrigger value="audit" className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Audit Logs
            </TabsTrigger>
            <TabsTrigger value="logs" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              System Logs
            </TabsTrigger>
          </TabsList>

          {/* Health Tab */}
          <TabsContent value="health" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Service Health */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Server className="h-5 w-5" />
                    Service Health
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {healthData?.components ? Object.entries(healthData.components).map(([name, component]: [string, any]) => (
                    <div key={name} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-3">
                        {component.status === 'healthy' ? (
                          <CheckCircle className="h-5 w-5 text-green-500" />
                        ) : component.status === 'degraded' ? (
                          <AlertTriangle className="h-5 w-5 text-yellow-500" />
                        ) : (
                          <XCircle className="h-5 w-5 text-red-500" />
                        )}
                        <span className="font-medium capitalize">{name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={component.status === 'healthy' ? 'default' : 'secondary'}>
                          {component.status}
                        </Badge>
                        {component.latency && (
                          <span className="text-sm text-muted-foreground">{component.latency}ms</span>
                        )}
                      </div>
                    </div>
                  )) : (
                    <p className="text-muted-foreground">Loading service health...</p>
                  )}
                </CardContent>
              </Card>

              {/* Memory Usage */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="h-5 w-5" />
                    Memory Usage
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <AreaChart data={memoryChartData}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                      <XAxis dataKey="time" className="text-xs" />
                      <YAxis className="text-xs" />
                      <Tooltip />
                      <Area type="monotone" dataKey="heap" stackId="1" stroke="#8884d8" fill="#8884d8" fillOpacity={0.6} name="Heap (MB)" />
                      <Area type="monotone" dataKey="rss" stackId="2" stroke="#82ca9d" fill="#82ca9d" fillOpacity={0.6} name="RSS (MB)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Database Stats */}
            <Card>
              <CardHeader>
                <CardTitle>System Statistics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { label: 'Total Requests', value: aggregatedStats?.totalRequests?.toLocaleString() || '0', trend: 'up' },
                    { label: 'Avg Response Time', value: `${aggregatedStats?.avgResponseTime || 0}ms`, trend: 'down' },
                    { label: 'Error Rate (1h)', value: `${aggregatedStats?.errorRate?.toFixed(2) || 0}%`, trend: 'neutral' },
                    { label: 'Peak Memory', value: `${aggregatedStats?.peakMemory || 0}MB`, trend: 'neutral' },
                  ].map((stat) => (
                    <div key={stat.label} className="p-4 bg-muted/50 rounded-lg">
                      <p className="text-sm text-muted-foreground">{stat.label}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <p className="text-xl font-bold">{stat.value}</p>
                        {stat.trend === 'up' && <TrendingUp className="h-4 w-4 text-green-500" />}
                        {stat.trend === 'down' && <TrendingDown className="h-4 w-4 text-red-500" />}
                        {stat.trend === 'neutral' && <Minus className="h-4 w-4 text-muted-foreground" />}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Performance Tab */}
          <TabsContent value="performance" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Response Time Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Response Time (Live)</CardTitle>
                  <CardDescription>Average API response time in milliseconds</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <RechartsLineChart data={performanceChartData}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                      <XAxis dataKey="time" className="text-xs" />
                      <YAxis className="text-xs" />
                      <Tooltip />
                      <Line type="monotone" dataKey="responseTime" stroke="#8884d8" strokeWidth={2} name="Response Time (ms)" />
                    </RechartsLineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Request Rate Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Request Rate (Live)</CardTitle>
                  <CardDescription>Requests per second</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={performanceChartData}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                      <XAxis dataKey="time" className="text-xs" />
                      <YAxis className="text-xs" />
                      <Tooltip />
                      <Bar dataKey="requests" fill="#82ca9d" name="Req/s" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Error Rate and Log Distribution */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle>Error Rate (Live)</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <AreaChart data={performanceChartData}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                      <XAxis dataKey="time" className="text-xs" />
                      <YAxis className="text-xs" />
                      <Tooltip />
                      <Area type="monotone" dataKey="errors" stroke="#ef4444" fill="#ef4444" fillOpacity={0.3} name="Error Rate %" />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Log Level Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie
                        data={logLevelDistribution}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {logLevelDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="flex justify-center gap-4 mt-4">
                    {logLevelDistribution.map((entry) => (
                      <div key={entry.name} className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }} />
                        <span className="text-sm">{entry.name}: {entry.value}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Audit Logs Tab */}
          <TabsContent value="audit" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Audit Log</CardTitle>
                <CardDescription>
                  Track all sensitive operations and access attempts
                  {auditStats && (
                    <span className="ml-2">
                      (Total: {auditStats.total} | Critical: {auditStats.bySeverity?.critical || 0})
                    </span>
                  )}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {/* Filters */}
                <div className="flex gap-4 mb-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search audit logs..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Select value={severityFilter} onValueChange={setSeverityFilter}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Severity" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Severities</SelectItem>
                      <SelectItem value="info">Info</SelectItem>
                      <SelectItem value="warning">Warning</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Audit Log Table */}
                <div className="space-y-2 max-h-[500px] overflow-auto">
                  {filteredAuditData.length > 0 ? filteredAuditData.map((entry: any, index: number) => (
                    <div
                      key={entry.id || index}
                      className="flex items-center justify-between p-4 bg-muted/50 rounded-lg hover:bg-muted transition-colors"
                    >
                      <div className="flex items-center gap-4">
                        <div className={`p-2 rounded-full ${
                          entry.severity === 'info' ? 'bg-blue-100 dark:bg-blue-900/30' :
                          entry.severity === 'warning' ? 'bg-yellow-100 dark:bg-yellow-900/30' :
                          'bg-red-100 dark:bg-red-900/30'
                        }`}>
                          {entry.success ? (
                            <CheckCircle className={`h-4 w-4 ${
                              entry.severity === 'info' ? 'text-blue-500' :
                              entry.severity === 'warning' ? 'text-yellow-500' :
                              'text-red-500'
                            }`} />
                          ) : (
                            <XCircle className="h-4 w-4 text-red-500" />
                          )}
                        </div>
                        <div>
                          <p className="font-medium">{entry.description}</p>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <span>User #{entry.userId}</span>
                            <span>•</span>
                            <span>{entry.targetType}</span>
                            <span>•</span>
                            <span>{entry.action}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge variant={
                          entry.severity === 'info' ? 'default' :
                          entry.severity === 'warning' ? 'secondary' :
                          'destructive'
                        }>
                          {entry.severity}
                        </Badge>
                        <span className="text-sm text-muted-foreground">
                          {new Date(entry.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                    </div>
                  )) : (
                    <p className="text-center text-muted-foreground py-8">No audit logs found</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* System Logs Tab */}
          <TabsContent value="logs" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Recent System Logs</CardTitle>
                <CardDescription>Real-time application logs (auto-refreshes every 10s)</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-zinc-950 text-zinc-100 p-4 rounded-lg font-mono text-sm space-y-1 max-h-[500px] overflow-auto">
                  {systemLogs && systemLogs.length > 0 ? systemLogs.map((log: any, i: number) => (
                    <div key={i} className="flex">
                      <span className="text-zinc-500 w-24 flex-shrink-0">
                        {new Date(log.timestamp).toLocaleTimeString()}
                      </span>
                      <span className={`w-16 flex-shrink-0 ${
                        log.level === 'info' ? 'text-green-400' :
                        log.level === 'debug' ? 'text-cyan-400' :
                        log.level === 'warn' ? 'text-yellow-400' :
                        'text-red-400'
                      }`}>[{log.level.toUpperCase()}]</span>
                      <span className="text-zinc-400 w-24 flex-shrink-0">[{log.service}]</span>
                      <span className="text-zinc-300">{log.message}</span>
                    </div>
                  )) : (
                    <p className="text-zinc-500">No logs available</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
