/**
 * Pillar 2 Dashboard: Learning Model
 * 
 * "Learns Like a New Employee"
 * 
 * This dashboard provides a unified view of:
 * - Rules Engine (explicit rules)
 * - Implicit Learning (behavior patterns)
 * - Communication Adaptation
 */

import { useState } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import DashboardLayout from '@/components/DashboardLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { trpc } from '@/lib/trpc';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  BookOpen,
  Brain,
  MessageSquare,
  Plus,
  Lightbulb,
  TrendingUp,
  CheckCircle2,
  AlertCircle,
  Clock,
  Activity,
  Trash2,
  Eye,
  Settings,
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

const DEFAULT_HOUSEHOLD_ID = 1;

const categoryColors: Record<string, string> = {
  communication: 'bg-blue-500/10 text-blue-500',
  scheduling: 'bg-purple-500/10 text-purple-500',
  financial: 'bg-green-500/10 text-green-500',
  household: 'bg-orange-500/10 text-orange-500',
  privacy: 'bg-red-500/10 text-red-500',
  notification: 'bg-yellow-500/10 text-yellow-500',
  automation: 'bg-cyan-500/10 text-cyan-500',
};

const priorityColors: Record<string, string> = {
  low: 'bg-gray-500/10 text-gray-500',
  medium: 'bg-blue-500/10 text-blue-500',
  high: 'bg-orange-500/10 text-orange-500',
  critical: 'bg-red-500/10 text-red-500',
};

const strengthColors: Record<string, string> = {
  weak: 'text-gray-500',
  moderate: 'text-blue-500',
  strong: 'text-green-500',
  very_strong: 'text-emerald-500',
};

export default function Pillar2Dashboard() {
  const { user, loading } = useAuth();
  const [activeTab, setActiveTab] = useState('rules');
  const [createRuleOpen, setCreateRuleOpen] = useState(false);

  // Fetch data
  const { data: rules, refetch: refetchRules } = trpc.pillar2.rules.list.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 30000 }
  );

  const { data: patterns, refetch: refetchPatterns } = trpc.pillar2.learning.patterns.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 30000 }
  );

  const { data: insights } = trpc.pillar2.learning.insights.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 60000 }
  );

  const { data: profiles } = trpc.pillar2.communication.profiles.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 30000 }
  );

  const { data: templates } = trpc.pillar2.communication.templates.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 60000 }
  );

  const { data: statistics } = trpc.pillar2.statistics.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 30000 }
  );

  const { data: ruleTemplates } = trpc.pillar2.rules.templates.useQuery();

  // Mutations
  const deleteRuleMutation = trpc.pillar2.rules.delete.useMutation({
    onSuccess: () => {
      toast.success('Rule deleted');
      refetchRules();
    },
    onError: (error) => {
      toast.error(`Failed to delete rule: ${error.message}`);
    },
  });

  const deactivatePatternMutation = trpc.pillar2.learning.deactivatePattern.useMutation({
    onSuccess: () => {
      toast.success('Pattern deactivated');
      refetchPatterns();
    },
    onError: (error) => {
      toast.error(`Failed to deactivate pattern: ${error.message}`);
    },
  });

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Learning Model</h1>
            <p className="text-muted-foreground mt-1">
              Pillar 2: Learns Like a New Employee
            </p>
          </div>
          <Badge variant="outline" className="text-lg px-4 py-2">
            <Brain className="h-4 w-4 mr-2 animate-pulse text-purple-500" />
            Learning Active
          </Badge>
        </div>

        {/* Overview Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Rules</p>
                  <p className="text-2xl font-bold">{statistics?.summary.totalRules ?? 0}</p>
                </div>
                <BookOpen className="h-8 w-8 text-blue-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Patterns</p>
                  <p className="text-2xl font-bold">{statistics?.summary.totalPatterns ?? 0}</p>
                </div>
                <Brain className="h-8 w-8 text-purple-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Profiles</p>
                  <p className="text-2xl font-bold">{statistics?.summary.totalProfiles ?? 0}</p>
                </div>
                <MessageSquare className="h-8 w-8 text-green-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Insights</p>
                  <p className="text-2xl font-bold">{insights?.length ?? 0}</p>
                </div>
                <Lightbulb className="h-8 w-8 text-yellow-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Learning Conf.</p>
                  <p className="text-2xl font-bold">
                    {statistics?.summary.avgLearningConfidence
                      ? `${Math.round(statistics.summary.avgLearningConfidence * 100)}%`
                      : '—'}
                  </p>
                </div>
                <TrendingUp className="h-8 w-8 text-emerald-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Observations</p>
                  <p className="text-2xl font-bold">{statistics?.learning.totalObservations ?? 0}</p>
                </div>
                <Eye className="h-8 w-8 text-cyan-500 opacity-50" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:inline-grid">
            <TabsTrigger value="rules" className="gap-2">
              <BookOpen className="h-4 w-4" />
              <span className="hidden sm:inline">Rules</span>
            </TabsTrigger>
            <TabsTrigger value="patterns" className="gap-2">
              <Brain className="h-4 w-4" />
              <span className="hidden sm:inline">Patterns</span>
            </TabsTrigger>
            <TabsTrigger value="insights" className="gap-2">
              <Lightbulb className="h-4 w-4" />
              <span className="hidden sm:inline">Insights</span>
              {(insights?.length ?? 0) > 0 && (
                <Badge variant="secondary" className="ml-1">
                  {insights?.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="communication" className="gap-2">
              <MessageSquare className="h-4 w-4" />
              <span className="hidden sm:inline">Communication</span>
            </TabsTrigger>
          </TabsList>

          {/* Rules Tab */}
          <TabsContent value="rules" className="mt-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="h-5 w-5" />
                    Explicit Rules
                  </CardTitle>
                  <CardDescription>
                    Define rules for HAI to follow
                  </CardDescription>
                </div>
                <Button onClick={() => setCreateRuleOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Rule
                </Button>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  {!rules || rules.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
                      <BookOpen className="h-12 w-12 mb-4 opacity-20" />
                      <p>No rules defined</p>
                      <p className="text-sm">Create rules to guide HAI's behavior</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {rules.map((rule: any) => (
                        <div
                          key={rule.id}
                          className="p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <span className="font-medium">{rule.name}</span>
                                <Badge variant={rule.isActive ? 'default' : 'secondary'}>
                                  {rule.isActive ? 'Active' : 'Inactive'}
                                </Badge>
                                <Badge className={categoryColors[rule.category]}>
                                  {rule.category}
                                </Badge>
                                <Badge className={priorityColors[rule.priority]}>
                                  {rule.priority}
                                </Badge>
                              </div>
                              {rule.description && (
                                <p className="text-sm text-muted-foreground mb-2">
                                  {rule.description}
                                </p>
                              )}
                              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                                <span>{rule.conditions?.length ?? 0} conditions</span>
                                <span>{rule.actions?.length ?? 0} actions</span>
                                <span>Executed {rule.executionCount} times</span>
                              </div>
                            </div>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => deleteRuleMutation.mutate({ ruleId: rule.id })}
                            >
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Rule Templates */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Rule Templates</CardTitle>
                <CardDescription>Quick-start with predefined rules</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {ruleTemplates?.map((template: any, index: number) => (
                    <div
                      key={index}
                      className="p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <span className="font-medium">{template.name}</span>
                        <Badge className={categoryColors[template.category]}>
                          {template.category}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{template.description}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Patterns Tab */}
          <TabsContent value="patterns" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5" />
                  Learned Patterns
                </CardTitle>
                <CardDescription>
                  Behaviors HAI has learned from observation
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  {!patterns || patterns.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
                      <Brain className="h-12 w-12 mb-4 opacity-20" />
                      <p>No patterns learned yet</p>
                      <p className="text-sm">HAI will learn from your interactions</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {patterns.map((pattern: any) => (
                        <div
                          key={pattern.id}
                          className="p-4 rounded-lg border bg-card"
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <span className="font-medium">{pattern.patternName}</span>
                                <Badge variant="outline">
                                  {pattern.patternType.replace('_', ' ')}
                                </Badge>
                                <span className={cn("text-sm font-medium", strengthColors[pattern.strength])}>
                                  {pattern.strength.replace('_', ' ')}
                                </span>
                              </div>
                              <p className="text-sm text-muted-foreground mb-2">
                                {pattern.patternDescription}
                              </p>
                              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                                <span>Confidence: {Math.round(pattern.confidence * 100)}%</span>
                                <span>Observations: {pattern.observationCount}</span>
                                <span>Applied: {pattern.appliedCount} times</span>
                                <span>Success: {Math.round(pattern.successRate * 100)}%</span>
                              </div>
                            </div>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => deactivatePatternMutation.mutate({ patternId: pattern.id })}
                              disabled={!pattern.isActive}
                            >
                              {pattern.isActive ? 'Deactivate' : 'Inactive'}
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Insights Tab */}
          <TabsContent value="insights" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="h-5 w-5 text-yellow-500" />
                  Learning Insights
                </CardTitle>
                <CardDescription>
                  Recommendations based on learned patterns
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  {!insights || insights.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
                      <Lightbulb className="h-12 w-12 mb-4 opacity-20" />
                      <p>No insights yet</p>
                      <p className="text-sm">Insights will appear as HAI learns more</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {insights.map((insight: any, index: number) => (
                        <div
                          key={index}
                          className={cn(
                            "p-4 rounded-lg border bg-card",
                            insight.impact === 'high' && "border-yellow-500/50",
                            insight.impact === 'medium' && "border-blue-500/50"
                          )}
                        >
                          <div className="flex items-start gap-3">
                            <Lightbulb className={cn(
                              "h-5 w-5 mt-0.5",
                              insight.impact === 'high' && "text-yellow-500",
                              insight.impact === 'medium' && "text-blue-500",
                              insight.impact === 'low' && "text-gray-500"
                            )} />
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-medium">{insight.patternName}</span>
                                <Badge variant="outline">
                                  {Math.round(insight.confidence * 100)}% confident
                                </Badge>
                                <Badge className={cn(
                                  insight.impact === 'high' && "bg-yellow-500/10 text-yellow-500",
                                  insight.impact === 'medium' && "bg-blue-500/10 text-blue-500",
                                  insight.impact === 'low' && "bg-gray-500/10 text-gray-500"
                                )}>
                                  {insight.impact} impact
                                </Badge>
                              </div>
                              <p className="text-sm mb-2">{insight.insight}</p>
                              <p className="text-sm text-muted-foreground">
                                <strong>Recommendation:</strong> {insight.recommendation}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Communication Tab */}
          <TabsContent value="communication" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageSquare className="h-5 w-5" />
                    Communication Profiles
                  </CardTitle>
                  <CardDescription>
                    Learned communication preferences
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[300px]">
                    {!profiles || profiles.length === 0 ? (
                      <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
                        <MessageSquare className="h-12 w-12 mb-4 opacity-20" />
                        <p>No profiles yet</p>
                        <p className="text-sm">Profiles are created as HAI communicates</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {profiles.map((profile: any) => (
                          <div
                            key={profile.id}
                            className="p-4 rounded-lg border bg-card"
                          >
                            <div className="flex items-center justify-between mb-2">
                              <span className="font-medium">
                                {profile.contactId || `Member ${profile.memberId}` || 'Household Default'}
                              </span>
                              <Badge>{profile.preferredTone}</Badge>
                            </div>
                            <div className="grid grid-cols-2 gap-2 text-sm text-muted-foreground">
                              <span>Formality: {profile.formalityLevel}/10</span>
                              <span>Confidence: {Math.round(profile.confidence * 100)}%</span>
                              <span>Emoji: {profile.usesEmoji ? 'Yes' : 'No'}</span>
                              <span>Observations: {profile.observationCount}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Message Templates
                  </CardTitle>
                  <CardDescription>
                    Tone-adaptive templates
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[300px]">
                    {!templates || templates.length === 0 ? (
                      <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
                        <Settings className="h-12 w-12 mb-4 opacity-20" />
                        <p>No templates available</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {templates.map((template: any) => (
                          <div
                            key={template.id}
                            className="p-4 rounded-lg border bg-card"
                          >
                            <div className="flex items-center justify-between mb-2">
                              <span className="font-medium">{template.templateName}</span>
                              <Badge variant="outline">{template.templateType}</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mb-2">
                              {template.baseTemplate}
                            </p>
                            <div className="text-xs text-muted-foreground">
                              Used {template.usageCount} times • {Object.keys(template.toneVariants).length} tone variants
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
