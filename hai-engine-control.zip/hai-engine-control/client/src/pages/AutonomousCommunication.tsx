/**
 * Autonomous Communication Settings Page
 * 
 * Configure and monitor autonomous communication system
 */

import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Loader2, Play, Square, Settings, BarChart3, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { useLocation } from 'wouter';

export default function AutonomousCommunication() {
  const [, setLocation] = useLocation();
  
  // State
  const [autoSendThreshold, setAutoSendThreshold] = useState(90);
  const [monitoredSendThreshold, setMonitoredSendThreshold] = useState(70);
  const [draftThreshold, setDraftThreshold] = useState(50);
  const [enableNaturalTiming, setEnableNaturalTiming] = useState(true);
  const [vipContacts, setVipContacts] = useState<string>('');
  
  // Queries
  const { data: status, isLoading: statusLoading, refetch } = trpc.autonomousCommunication.getStatus.useQuery();
  const { data: stats, refetch: refetchStats } = trpc.autonomousCommunication.getStatistics.useQuery();
  
  // Mutations
  const startMutation = trpc.autonomousCommunication.startWhatsApp.useMutation({
    onSuccess: () => {
      toast.success('Autonomous WhatsApp started');
      refetch();
      refetchStats();
    },
    onError: (error) => {
      toast.error(`Failed to start: ${error.message}`);
    },
  });
  
  const stopMutation = trpc.autonomousCommunication.stopWhatsApp.useMutation({
    onSuccess: () => {
      toast.success('Autonomous WhatsApp stopped');
      refetch();
      refetchStats();
    },
    onError: (error) => {
      toast.error(`Failed to stop: ${error.message}`);
    },
  });
  
  const updateConfigMutation = trpc.autonomousCommunication.updateConfig.useMutation({
    onSuccess: () => {
      toast.success('Configuration updated');
      refetch();
    },
    onError: (error) => {
      toast.error(`Failed to update: ${error.message}`);
    },
  });
  
  const handleStart = () => {
    startMutation.mutate({
      autoSendThreshold,
      monitoredSendThreshold,
      draftThreshold,
      enableNaturalTiming,
      vipContacts: vipContacts.split(',').map(c => c.trim()).filter(Boolean),
    });
  };
  
  const handleStop = () => {
    stopMutation.mutate();
  };
  
  const handleUpdateConfig = () => {
    updateConfigMutation.mutate({
      autoSendThreshold,
      monitoredSendThreshold,
      draftThreshold,
      enableNaturalTiming,
      vipContacts: vipContacts.split(',').map(c => c.trim()).filter(Boolean),
    });
  };
  
  if (statusLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }
  
  const isRunning = stats?.isRunning || false;
  const isConnected = stats?.isConnected || false;
  
  return (
    <div className="container mx-auto py-8 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Autonomous Communication</h1>
        <p className="text-muted-foreground">
          Configure and monitor your autonomous WhatsApp communication system
        </p>
      </div>
      
      {/* Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <div className={`w-3 h-3 rounded-full ${isRunning ? 'bg-green-500 animate-pulse' : 'bg-gray-300'}`} />
              <span className="font-semibold">{isRunning ? 'Running' : 'Stopped'}</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Connection</CardTitle>
          </CardHeader>
          <CardContent>
            <Badge variant={isConnected ? 'default' : 'secondary'}>
              {isConnected ? 'Connected' : 'Disconnected'}
            </Badge>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Processing</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.processing || 0}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Escalated</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <div className="text-2xl font-bold">{stats?.escalated || 0}</div>
              {(stats?.escalated || 0) > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setLocation('/escalation-queue')}
                >
                  Review
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Statistics */}
      <Card className="mb-8">
        <CardHeader>
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            <CardTitle>Statistics</CardTitle>
          </div>
          <CardDescription>Performance metrics for autonomous communication</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <div className="text-sm text-muted-foreground mb-1">Total Processed</div>
              <div className="text-3xl font-bold">{stats?.total || 0}</div>
            </div>
            <div>
              <div className="text-sm text-muted-foreground mb-1">Successfully Sent</div>
              <div className="text-3xl font-bold text-green-600">{stats?.sent || 0}</div>
            </div>
            <div>
              <div className="text-sm text-muted-foreground mb-1">Autonomy Rate</div>
              <div className="text-3xl font-bold">
                {stats?.total ? Math.round(((stats.sent || 0) / stats.total) * 100) : 0}%
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Configuration */}
      <Card className="mb-8">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            <CardTitle>Configuration</CardTitle>
          </div>
          <CardDescription>Adjust confidence thresholds and behavior</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Auto-send Threshold */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>Auto-send Threshold</Label>
              <span className="text-sm font-medium">{autoSendThreshold}%</span>
            </div>
            <Slider
              value={[autoSendThreshold]}
              onValueChange={([value]) => setAutoSendThreshold(value)}
              min={50}
              max={100}
              step={5}
              disabled={isRunning}
            />
            <p className="text-xs text-muted-foreground">
              Messages with confidence ≥ {autoSendThreshold}% will be sent automatically
            </p>
          </div>
          
          {/* Monitored Send Threshold */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>Monitored Send Threshold</Label>
              <span className="text-sm font-medium">{monitoredSendThreshold}%</span>
            </div>
            <Slider
              value={[monitoredSendThreshold]}
              onValueChange={([value]) => setMonitoredSendThreshold(value)}
              min={50}
              max={100}
              step={5}
              disabled={isRunning}
            />
            <p className="text-xs text-muted-foreground">
              Messages with confidence ≥ {monitoredSendThreshold}% will be sent with enhanced logging
            </p>
          </div>
          
          {/* Draft Threshold */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>Draft Threshold</Label>
              <span className="text-sm font-medium">{draftThreshold}%</span>
            </div>
            <Slider
              value={[draftThreshold]}
              onValueChange={([value]) => setDraftThreshold(value)}
              min={0}
              max={100}
              step={5}
              disabled={isRunning}
            />
            <p className="text-xs text-muted-foreground">
              Messages with confidence ≥ {draftThreshold}% will generate drafts for review
            </p>
          </div>
          
          {/* Natural Timing */}
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Natural Timing</Label>
              <p className="text-xs text-muted-foreground">
                Simulate human-like response delays (30s - 5min)
              </p>
            </div>
            <Switch
              checked={enableNaturalTiming}
              onCheckedChange={setEnableNaturalTiming}
              disabled={isRunning}
            />
          </div>
          
          {/* VIP Contacts */}
          <div className="space-y-2">
            <Label>VIP Contacts (always escalate)</Label>
            <Input
              value={vipContacts}
              onChange={(e) => setVipContacts(e.target.value)}
              placeholder="phone1, phone2, phone3"
              disabled={isRunning}
            />
            <p className="text-xs text-muted-foreground">
              Comma-separated list of phone numbers that should always be escalated
            </p>
          </div>
          
          {/* Update Config Button */}
          {isRunning && (
            <Button
              onClick={handleUpdateConfig}
              disabled={updateConfigMutation.isPending}
              className="w-full"
            >
              {updateConfigMutation.isPending && (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              )}
              Update Configuration
            </Button>
          )}
        </CardContent>
      </Card>
      
      {/* Warning */}
      {!isRunning && (
        <Card className="mb-8 border-yellow-500">
          <CardHeader>
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-yellow-500" />
              <CardTitle>Important Information</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <p>
              <strong>Autonomous communication is a powerful feature.</strong> Before starting:
            </p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Review and adjust confidence thresholds carefully</li>
              <li>Add important contacts to the VIP list to ensure human review</li>
              <li>Monitor the escalation queue regularly</li>
              <li>Test with a small group before enabling for all contacts</li>
            </ul>
            <p className="mt-4">
              The system uses triple-layer analysis (factual verification, intent understanding, outcome evaluation)
              to ensure high-quality responses. Messages below your thresholds will be escalated for review.
            </p>
          </CardContent>
        </Card>
      )}
      
      {/* Control Buttons */}
      <div className="flex gap-4">
        {!isRunning ? (
          <Button
            onClick={handleStart}
            disabled={startMutation.isPending}
            size="lg"
            className="flex-1"
          >
            {startMutation.isPending ? (
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
            ) : (
              <Play className="w-5 h-5 mr-2" />
            )}
            Start Autonomous WhatsApp
          </Button>
        ) : (
          <Button
            onClick={handleStop}
            disabled={stopMutation.isPending}
            variant="destructive"
            size="lg"
            className="flex-1"
          >
            {stopMutation.isPending ? (
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
            ) : (
              <Square className="w-5 h-5 mr-2" />
            )}
            Stop Autonomous WhatsApp
          </Button>
        )}
        
        <Button
          onClick={() => setLocation('/escalation-queue')}
          variant="outline"
          size="lg"
        >
          View Escalation Queue
        </Button>
      </div>
    </div>
  );
}
