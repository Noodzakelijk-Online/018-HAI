import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import ApprovalQueueWidget from "@/components/ApprovalQueueWidget";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Activity, 
  CheckCircle2, 
  Clock, 
  Mail, 
  Brain, 
  TrendingUp,
  Zap,
  AlertCircle,
  ArrowRight,
  Calendar,
  Sparkles
} from "lucide-react";
import React, { useState, useMemo } from "react";
import { useDebouncedState } from "@/hooks/useDebounce";
import { VirtualizedTimelineSection } from "@/components/VirtualizedActivityTimeline";
import { ActivityDetailModal } from "@/components/ActivityDetailModal";
import { DateRangePicker } from "@/components/DateRangePicker";
import { startOfDay } from 'date-fns';

export default function HAIDashboard() {
  const { user } = useAuth();
  const [selectedHouseholdId, setSelectedHouseholdId] = useState<number | null>(null);

  // Fetch user's households
  const { data: households } = trpc.households.list.useQuery();
  
  // Auto-select first household
  React.useEffect(() => {
    if (households && households.length > 0 && !selectedHouseholdId) {
      setSelectedHouseholdId(households[0].id);
    }
  }, [households, selectedHouseholdId]);

  // Date selection for timeline filtering
  const [selectedDate, setSelectedDate] = useState(() => startOfDay(new Date()));
  
  // Filter and search state with debouncing for performance
  const [engineFilter, setEngineFilter] = useState<string>("all");
  // Debounced search - immediate value for input, debounced for filtering
  const [searchQuery, debouncedSearchQuery, setSearchQuery] = useDebouncedState<string>("", 300);
  const [selectedActivity, setSelectedActivity] = useState<any | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [lastActivityCount, setLastActivityCount] = useState<number>(0);
  const [hasNewActivities, setHasNewActivities] = useState(false);

  const handleActivityClick = (activity: any) => {
    setSelectedActivity(activity);
    setIsModalOpen(true);
  };
  
  // OPTIMIZED: Add staleTime and cacheTime to reduce unnecessary refetches
  const queryOptions = {
    staleTime: 30 * 1000, // Data stays fresh for 30 seconds
    cacheTime: 5 * 60 * 1000, // Cache for 5 minutes
    refetchOnWindowFocus: false, // Don't refetch on tab focus
    refetchInterval: 30 * 1000, // Auto-refresh every 30 seconds
  };
  
  // Update dashboard visit timestamp on mount
  const updateVisitMutation = trpc.activities.updateDashboardVisit.useMutation();
  React.useEffect(() => {
    updateVisitMutation.mutate();
  }, []);

  const { data: sinceLastVisitActivities, isLoading: activitiesLoading } = trpc.activities.getSinceLastVisit.useQuery(
    undefined,
    queryOptions
  );
  const { data: stats, isLoading: statsLoading } = trpc.activities.getTodaysStats.useQuery(
    undefined,
    queryOptions
  );
  const { data: timeline, isLoading: timelineLoading } = trpc.activities.getTimeline.useQuery(
    { date: selectedDate },
    queryOptions
  );
  
  // Filter activities based on engine type and search query
  const filterActivities = (activities: typeof timeline) => {
    if (!activities) return activities;
    
    const filterArray = (arr: any[]) => {
      return arr.filter(activity => {
        // Engine filter
        if (engineFilter !== "all" && activity.engine !== engineFilter) {
          return false;
        }
        
        // Search filter (uses debounced value)
        if (debouncedSearchQuery) {
          const query = debouncedSearchQuery.toLowerCase();
          const matchesTitle = activity.title?.toLowerCase().includes(query);
          const matchesDescription = activity.description?.toLowerCase().includes(query);
          return matchesTitle || matchesDescription;
        }
        
        return true;
      });
    };
    
    return {
      morning: filterArray(activities.morning),
      afternoon: filterArray(activities.afternoon),
      evening: filterArray(activities.evening),
      night: filterArray(activities.night),
    };
  };
  
  const filteredTimeline = filterActivities(timeline) || { morning: [], afternoon: [], evening: [], night: [] };

  // Detect new activities and show notification
  React.useEffect(() => {
    if (!timeline) return;
    
    const currentCount = 
      timeline.morning.length + 
      timeline.afternoon.length + 
      timeline.evening.length + 
      timeline.night.length;
    
    if (lastActivityCount > 0 && currentCount > lastActivityCount) {
      setHasNewActivities(true);
      toast.success(`${currentCount - lastActivityCount} new ${currentCount - lastActivityCount === 1 ? 'activity' : 'activities'} detected!`);
      
      // Clear notification after 5 seconds
      setTimeout(() => setHasNewActivities(false), 5000);
    }
    
    setLastActivityCount(currentCount);
  }, [timeline]);
  const { data: agents } = trpc.agents.list.useQuery(
    { householdId: selectedHouseholdId! },
    { enabled: !!selectedHouseholdId, ...queryOptions }
  );
  const { data: connectors } = trpc.connectors.list.useQuery(
    { householdId: selectedHouseholdId! },
    { enabled: !!selectedHouseholdId, ...queryOptions }
  );

  const onlineAgents = agents?.filter(a => a.isConnected) || [];

  // Test engines mutation
  const testEnginesMutation = trpc.engineTest.createSampleActivities.useMutation({
    onSuccess: () => {
      toast.success("Sample activities created!");
      window.location.reload();
    },
    onError: (error) => {
      toast.error(`Failed: ${error.message}`);
    },
  });

  // Create test approval mutation
  const createTestApprovalMutation = trpc.approvalQueue.createTestItem.useMutation({
    onSuccess: () => {
      toast.success("Test approval created!");
      window.location.reload();
    },
    onError: (error) => {
      toast.error(`Failed: ${error.message}`);
    },
  });

  // Calculate impact metrics from timeline data
  const allTimelineActivities = [
    ...(timeline?.morning || []),
    ...(timeline?.afternoon || []),
    ...(timeline?.evening || []),
    ...(timeline?.night || [])
  ];
  const completedCount = allTimelineActivities.filter(a => a.status === "completed").length || 0;
  const inProgressCount = allTimelineActivities.filter(a => a.status === "in_progress").length || 0;

  const getEngineIcon = (engine: string) => {
    switch (engine) {
      case "communication":
        return <Mail className="h-4 w-4" />;
      case "decision":
        return <Brain className="h-4 w-4" />;
      case "task":
        return <Calendar className="h-4 w-4" />;
      default:
        return <Activity className="h-4 w-4" />;
    }
  };

  const getEngineColor = (engine: string) => {
    switch (engine) {
      case "communication":
        return "bg-blue-500/10 text-blue-600 border-blue-200";
      case "decision":
        return "bg-purple-500/10 text-purple-600 border-purple-200";
      case "task":
        return "bg-green-500/10 text-green-600 border-green-200";
      default:
        return "bg-gray-500/10 text-gray-600 border-gray-200";
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge variant="default" className="bg-green-500/10 text-green-700 border-green-200"><CheckCircle2 className="h-3 w-3 mr-1" />Completed</Badge>;
      case "in_progress":
        return <Badge variant="default" className="bg-blue-500/10 text-blue-700 border-blue-200"><Clock className="h-3 w-3 mr-1" />In Progress</Badge>;
      case "failed":
        return <Badge variant="destructive" className="bg-red-500/10 text-red-700 border-red-200"><AlertCircle className="h-3 w-3 mr-1" />Failed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header with improved spacing */}
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Sparkles className="h-6 w-6 text-primary" />
              <h1 className="text-3xl font-bold tracking-tight">HAI Dashboard</h1>
            </div>
            <p className="text-muted-foreground text-base">
              {user?.name ? `Welcome back, ${user.name.split(' ')[0]}! I've been working for you` : "Your autonomous AI assistant's daily accomplishments"}
            </p>
          </div>
          
          {/* Household Selector & Test Buttons */}
          {households && households.length > 0 && (
            <div className="flex items-center gap-3">
              <Select
                value={selectedHouseholdId?.toString()}
                onValueChange={(value) => setSelectedHouseholdId(parseInt(value))}
              >
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Select household" />
                </SelectTrigger>
                <SelectContent>
                  {households.map((household) => (
                    <SelectItem key={household.id} value={household.id.toString()}>
                      {household.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </div>

        {/* Statistics Cards - Improved design */}
        <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
          <Card className="border-l-4 border-l-primary">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Today's Activities
              </CardTitle>
              <Activity className="h-5 w-5 text-primary" />
            </CardHeader>
            <CardContent>
              {statsLoading ? (
                <Skeleton className="h-8 w-16" />
              ) : (
                <>
                  <div className="text-3xl font-bold">{stats?.totalActivities || 0}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {completedCount} completed · {inProgressCount} in progress
                  </p>
                </>
              )}
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-blue-500">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Communication
              </CardTitle>
              <Mail className="h-5 w-5 text-blue-500" />
            </CardHeader>
            <CardContent>
              {statsLoading ? (
                <Skeleton className="h-8 w-16" />
              ) : (
                <>
                  <div className="text-3xl font-bold">{stats?.byEngine?.communication || 0}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Emails & events managed
                  </p>
                </>
              )}
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-purple-500">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Decisions Made
              </CardTitle>
              <Brain className="h-5 w-5 text-purple-500" />
            </CardHeader>
            <CardContent>
              {statsLoading ? (
                <Skeleton className="h-8 w-16" />
              ) : (
                <>
                  <div className="text-3xl font-bold">{stats?.byEngine?.decision || 0}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Autonomous decisions
                  </p>
                </>
              )}
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-green-500">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Active Resources
              </CardTitle>
              <Zap className="h-5 w-5 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{(agents?.length || 0) + (connectors?.length || 0)}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {agents?.length || 0} agents · {connectors?.length || 0} services
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Approval Queue Widget */}
        {selectedHouseholdId && <ApprovalQueueWidget householdId={selectedHouseholdId} />}

        {/* Date Range Picker */}
        <div className="mb-4">
          <DateRangePicker
            selectedDate={selectedDate}
            onDateChange={setSelectedDate}
          />
        </div>

        {/* Activity Type Filter Chips */}
        <div className="mb-4 flex flex-wrap gap-2">
          <Button
            variant={engineFilter === "all" ? "default" : "outline"}
            size="sm"
            onClick={() => setEngineFilter("all")}
            className="rounded-full"
          >
            <Activity className="h-4 w-4 mr-2" />
            All Activities
          </Button>
          <Button
            variant={engineFilter === "communication" ? "default" : "outline"}
            size="sm"
            onClick={() => setEngineFilter("communication")}
            className="rounded-full"
          >
            <Mail className="h-4 w-4 mr-2" />
            Communication
          </Button>
          <Button
            variant={engineFilter === "decision" ? "default" : "outline"}
            size="sm"
            onClick={() => setEngineFilter("decision")}
            className="rounded-full"
          >
            <Brain className="h-4 w-4 mr-2" />
            Decisions
          </Button>
          <Button
            variant={engineFilter === "task" ? "default" : "outline"}
            size="sm"
            onClick={() => setEngineFilter("task")}
            className="rounded-full"
          >
            <Calendar className="h-4 w-4 mr-2" />
            Tasks
          </Button>
          <Button
            variant={engineFilter === "system" ? "default" : "outline"}
            size="sm"
            onClick={() => setEngineFilter("system")}
            className="rounded-full"
          >
            <Zap className="h-4 w-4 mr-2" />
            System
          </Button>
        </div>

        {/* Activity Timeline - Improved design */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div>
                  <CardTitle className="text-xl">Activity Timeline</CardTitle>
                  <CardDescription className="mt-1">
                    Autonomous actions grouped by time of day
                  </CardDescription>
                </div>
                {hasNewActivities && (
                  <Badge variant="default" className="animate-pulse bg-green-500">
                    New
                  </Badge>
                )}
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => testEnginesMutation.mutate()}
                  disabled={testEnginesMutation.isPending}
                >
                  {testEnginesMutation.isPending ? "Creating..." : "Add Test Data"}
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {timelineLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-20 w-full" />
              </div>
            ) : (
              <div className="space-y-4">
                {/* Morning - Virtualized for large lists */}
                <VirtualizedTimelineSection
                  title="Morning"
                  timeRange="6 AM - 12 PM"
                  activities={filteredTimeline.morning}
                  dotColor="bg-yellow-500"
                  onActivityClick={handleActivityClick}
                />

                {/* Afternoon - Virtualized for large lists */}
                <VirtualizedTimelineSection
                  title="Afternoon"
                  timeRange="12 PM - 5 PM"
                  activities={filteredTimeline.afternoon}
                  dotColor="bg-orange-500"
                  onActivityClick={handleActivityClick}
                />

                {/* Evening - Virtualized for large lists */}
                <VirtualizedTimelineSection
                  title="Evening"
                  timeRange="5 PM - 9 PM"
                  activities={filteredTimeline.evening}
                  dotColor="bg-blue-500"
                  onActivityClick={handleActivityClick}
                />

                {/* Night - Virtualized for large lists */}
                <VirtualizedTimelineSection
                  title="Night"
                  timeRange="9 PM - 6 AM"
                  activities={filteredTimeline.night}
                  dotColor="bg-indigo-500"
                  onActivityClick={handleActivityClick}
                />

                {/* Empty state with personalized greeting */}
                {(!filteredTimeline.morning.length && !filteredTimeline.afternoon.length && 
                  !filteredTimeline.evening.length && !filteredTimeline.night.length) && (
                  <div className="text-center py-8">
                    <Sparkles className="h-12 w-12 text-primary mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">
                      Welcome back! I've been working for you.
                    </h3>
                    <p className="text-muted-foreground mb-4">
                      {sinceLastVisitActivities && sinceLastVisitActivities.length > 0
                        ? `I took care of ${sinceLastVisitActivities.length} ${sinceLastVisitActivities.length === 1 ? 'task' : 'tasks'} since your last visit.`
                        : "I haven't performed any actions yet. Click 'Add Test Data' to see sample activities."}
                    </p>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Activity Detail Modal */}
      <ActivityDetailModal
        activity={selectedActivity}
        open={isModalOpen}
        onOpenChange={setIsModalOpen}
        onActivityUpdated={() => {
          // Refresh the timeline after activity is updated
          window.location.reload();
        }}
      />
    </DashboardLayout>
  );
}
