import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Brain, TrendingUp, Trash2, RefreshCw, Sparkles, Clock, Target } from "lucide-react";
import { toast } from "sonner";
import { useState } from "react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function Profile() {
  const { data: profile, isLoading, refetch } = trpc.sme.getProfile.useQuery();
  const { data: summary } = trpc.sme.getProfileSummary.useQuery();
  const { data: patterns } = trpc.sme.detectPatterns.useQuery();
  const { data: recommendations } = trpc.sme.getRecommendations.useQuery();

  const deleteTraitMutation = trpc.sme.deleteTrait.useMutation();
  const updateConfidenceMutation = trpc.sme.updateTraitConfidence.useMutation();

  const [traitToDelete, setTraitToDelete] = useState<number | null>(null);

  const handleDeleteTrait = async (traitId: number) => {
    try {
      await deleteTraitMutation.mutateAsync({ traitId });
      toast.success('Trait deleted');
      refetch();
      setTraitToDelete(null);
    } catch (error) {
      console.error('Error deleting trait:', error);
      toast.error('Failed to delete trait');
    }
  };

  const handleReinforce = async (traitId: number) => {
    try {
      await updateConfidenceMutation.mutateAsync({
        traitId,
        reinforcement: 10,
      });
      toast.success('Trait reinforced');
      refetch();
    } catch (error) {
      console.error('Error reinforcing trait:', error);
      toast.error('Failed to reinforce trait');
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 80) return "text-green-500";
    if (confidence >= 60) return "text-yellow-500";
    return "text-orange-500";
  };

  const getConfidenceBadge = (confidence: number) => {
    if (confidence >= 80) return "default";
    if (confidence >= 60) return "secondary";
    return "outline";
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Your AI Profile</h1>
          <p className="text-muted-foreground mt-1">
            What HAI has learned about you through conversations
          </p>
        </div>
        <Button onClick={() => refetch()} variant="outline">
          <RefreshCw className="mr-2 h-4 w-4" />
          Refresh
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Profile Completeness</CardTitle>
            <Brain className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summary?.completeness || 0}%</div>
            <Progress value={summary?.completeness || 0} className="mt-2" />
            <p className="text-xs text-muted-foreground mt-2">
              {summary?.traitCount || 0} traits learned
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overall Confidence</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summary?.confidence || 0}%</div>
            <Progress value={summary?.confidence || 0} className="mt-2" />
            <p className="text-xs text-muted-foreground mt-2">
              Average across all traits
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Patterns Detected</CardTitle>
            <Sparkles className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{patterns?.length || 0}</div>
            <p className="text-xs text-muted-foreground mt-2">
              Behavioral patterns found
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Learned Traits by Category */}
      {profile && profile.traits.length > 0 ? (
        <Card>
          <CardHeader>
            <CardTitle>Learned Traits</CardTitle>
            <CardDescription>
              Traits HAI has learned about you, organized by category
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {Object.entries(profile.traitsByCategory).map(([category, traits]) => (
              <div key={category} className="space-y-3">
                <h3 className="font-semibold text-lg capitalize">
                  {category.replace(/_/g, ' ')}
                </h3>
                <div className="space-y-2">
                  {traits.map((trait) => (
                    <div
                      key={trait.id}
                      className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{trait.traitValue}</span>
                          <Badge variant={getConfidenceBadge(trait.confidence)}>
                            {trait.confidence}% confident
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          Last updated: {new Date(trait.lastUpdated).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleReinforce(trait.id)}
                          title="This is correct"
                        >
                          ✓
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setTraitToDelete(trait.id)}
                          title="Delete this trait"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Brain className="h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No traits learned yet</h3>
            <p className="text-muted-foreground text-center max-w-md">
              Start chatting with HAI to build your profile. HAI will learn about your
              preferences, patterns, and behaviors through natural conversation.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Detected Patterns */}
      {patterns && patterns.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Behavioral Patterns</CardTitle>
            <CardDescription>
              Patterns HAI has detected in your behavior
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {patterns.map((pattern, index) => (
              <div
                key={index}
                className="p-4 rounded-lg border bg-card"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span className="font-medium">{pattern.description}</span>
                      <Badge variant="secondary">
                        {pattern.confidence}% confident
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Frequency: {pattern.frequency} occurrences
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      First observed: {new Date(pattern.firstObserved).toLocaleDateString()} •
                      Last observed: {new Date(pattern.lastObserved).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Recommendations */}
      {recommendations && recommendations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Learning Recommendations</CardTitle>
            <CardDescription>
              Areas where HAI could learn more about you
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {recommendations.map((rec, index) => (
              <div
                key={index}
                className="flex items-center gap-3 p-3 rounded-lg border bg-card"
              >
                <Target className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">{rec}</span>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={traitToDelete !== null} onOpenChange={() => setTraitToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this trait?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove the trait from your profile. HAI may re-learn it from future conversations.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => traitToDelete && handleDeleteTrait(traitToDelete)}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
