import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { 
  Search, 
  Plus, 
  Brain, 
  Lightbulb, 
  Heart, 
  Calendar, 
  Users, 
  Sparkles,
  Archive,
  Clock,
  Database,
  MessageSquare,
  Network
} from "lucide-react";
import { KnowledgeChat } from "@/components/KnowledgeChat";
import { KnowledgeGraph } from "@/components/KnowledgeGraph";

const KNOWLEDGE_TYPES = [
  { value: 'fact', label: 'Fact', icon: Database },
  { value: 'preference', label: 'Preference', icon: Heart },
  { value: 'routine', label: 'Routine', icon: Clock },
  { value: 'relationship', label: 'Relationship', icon: Users },
  { value: 'event', label: 'Event', icon: Calendar },
  { value: 'emotion', label: 'Emotion', icon: Heart },
  { value: 'skill', label: 'Skill', icon: Sparkles },
  { value: 'context', label: 'Context', icon: Brain },
  { value: 'insight', label: 'Insight', icon: Lightbulb },
] as const;

type KnowledgeType = typeof KNOWLEDGE_TYPES[number]['value'];

export default function KnowledgeExplorer() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedType, setSelectedType] = useState<KnowledgeType | "all">("all");
  const [newKnowledge, setNewKnowledge] = useState({
    type: "fact" as KnowledgeType,
    content: "",
    context: "",
    tags: "",
  });

  const householdId = 1;

  const { data: stats } = trpc.knowledgeBase.getStats.useQuery(
    { householdId },
    { enabled: !!user }
  );

  const { data: recentEntries, refetch: refetchRecent } = trpc.knowledgeBase.getRecent.useQuery(
    { householdId, limit: 20 },
    { enabled: !!user }
  );

  const { data: searchResults, refetch: refetchSearch } = trpc.knowledgeBase.search.useQuery(
    { 
      query: searchQuery, 
      householdId,
      types: selectedType !== "all" ? [selectedType] : undefined,
      limit: 30 
    },
    { enabled: !!user && searchQuery.length > 2 }
  );

  const addMutation = trpc.knowledgeBase.add.useMutation({
    onSuccess: () => {
      toast.success("Knowledge added successfully");
      setNewKnowledge({ type: "fact", content: "", context: "", tags: "" });
      refetchRecent();
    },
    onError: (error) => {
      toast.error("Failed to add knowledge: " + error.message);
    }
  });

  const archiveMutation = trpc.knowledgeBase.archive.useMutation({
    onSuccess: () => {
      toast.success("Knowledge archived");
      refetchRecent();
      if (searchQuery) refetchSearch();
    }
  });

  const handleAddKnowledge = () => {
    if (!newKnowledge.content.trim()) {
      toast.error("Please enter knowledge content");
      return;
    }

    addMutation.mutate({
      householdId,
      type: newKnowledge.type,
      content: newKnowledge.content,
      context: newKnowledge.context || undefined,
      source: "manual",
      tags: newKnowledge.tags ? newKnowledge.tags.split(",").map(t => t.trim()) : undefined,
    });
  };

  const getTypeIcon = (type: string) => {
    const typeConfig = KNOWLEDGE_TYPES.find(t => t.value === type);
    const Icon = typeConfig?.icon || Brain;
    return <Icon className="h-4 w-4" />;
  };

  const getTypeColor = (type: string) => {
    const colors: Record<string, string> = {
      fact: "bg-blue-500/10 text-blue-500",
      preference: "bg-pink-500/10 text-pink-500",
      routine: "bg-green-500/10 text-green-500",
      relationship: "bg-purple-500/10 text-purple-500",
      event: "bg-orange-500/10 text-orange-500",
      emotion: "bg-red-500/10 text-red-500",
      skill: "bg-yellow-500/10 text-yellow-500",
      context: "bg-cyan-500/10 text-cyan-500",
      insight: "bg-indigo-500/10 text-indigo-500",
    };
    return colors[type] || "bg-gray-500/10 text-gray-500";
  };

  const displayEntries = searchQuery.length > 2 ? searchResults : recentEntries;

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Brain className="h-6 w-6 text-primary" />
              Knowledge Base
            </h1>
            <p className="text-muted-foreground">
              Store and search HAI's accumulated knowledge
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-4">
              <div className="text-2xl font-bold">{stats?.totalEntries || 0}</div>
              <p className="text-sm text-muted-foreground">Total Entries</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="text-2xl font-bold">{stats?.recentlyAdded || 0}</div>
              <p className="text-sm text-muted-foreground">Added Today</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="text-2xl font-bold">{Object.keys(stats?.byType || {}).length}</div>
              <p className="text-sm text-muted-foreground">Knowledge Types</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="text-2xl font-bold">{Object.keys(stats?.bySource || {}).length}</div>
              <p className="text-sm text-muted-foreground">Sources</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="chat" className="space-y-4">
          <TabsList>
            <TabsTrigger value="chat" className="flex items-center gap-1.5">
              <MessageSquare className="h-4 w-4" />
              Chat
            </TabsTrigger>
            <TabsTrigger value="graph" className="flex items-center gap-1.5">
              <Network className="h-4 w-4" />
              Graph
            </TabsTrigger>
            <TabsTrigger value="search">Search</TabsTrigger>
            <TabsTrigger value="add">Add Knowledge</TabsTrigger>
            <TabsTrigger value="browse">Browse by Type</TabsTrigger>
          </TabsList>

          <TabsContent value="chat">
            <KnowledgeChat 
              householdId={householdId} 
              onKnowledgeAdded={() => {
                refetchRecent();
              }}
              height="calc(100vh - 320px)"
            />
          </TabsContent>

          <TabsContent value="graph">
            <KnowledgeGraph 
              householdId={householdId}
              height={500}
            />
          </TabsContent>

          <TabsContent value="search" className="space-y-4">
            <div className="flex gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search knowledge (semantic + keyword)..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={selectedType} onValueChange={(v) => setSelectedType(v as KnowledgeType | "all")}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="All types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  {KNOWLEDGE_TYPES.map(type => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-3">
              {searchQuery.length > 2 && searchResults?.length === 0 && (
                <Card>
                  <CardContent className="py-8 text-center text-muted-foreground">
                    No knowledge found matching "{searchQuery}"
                  </CardContent>
                </Card>
              )}

              {(displayEntries || []).map((item: any) => {
                const entry = 'entry' in item ? item.entry : item;
                const similarity = 'similarity' in item ? item.similarity : null;
                const matchType = 'matchType' in item ? item.matchType : null;

                return (
                  <Card key={entry.id} className="hover:bg-accent/50 transition-colors">
                    <CardContent className="py-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center gap-2">
                            <Badge className={getTypeColor(entry.type)}>
                              {getTypeIcon(entry.type)}
                              <span className="ml-1 capitalize">{entry.type}</span>
                            </Badge>
                            {similarity !== null && (
                              <Badge variant="outline" className="text-xs">
                                {matchType}: {(similarity * 100).toFixed(0)}%
                              </Badge>
                            )}
                            <span className="text-xs text-muted-foreground">
                              via {entry.source}
                            </span>
                          </div>
                          <p className="text-sm">{entry.content}</p>
                          {entry.context && (
                            <p className="text-xs text-muted-foreground">
                              Context: {entry.context}
                            </p>
                          )}
                          {entry.tags && entry.tags.length > 0 && (
                            <div className="flex gap-1 flex-wrap">
                              {entry.tags.map((tag: string, i: number) => (
                                <Badge key={i} variant="secondary" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => archiveMutation.mutate({ knowledgeId: entry.id })}
                        >
                          <Archive className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}

              {!searchQuery && (!recentEntries || recentEntries.length === 0) && (
                <Card>
                  <CardContent className="py-8 text-center text-muted-foreground">
                    No knowledge entries yet. Add some knowledge to get started!
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="add" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Plus className="h-5 w-5" />
                  Add New Knowledge
                </CardTitle>
                <CardDescription>
                  Manually add knowledge to HAI's memory
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Type</label>
                    <Select 
                      value={newKnowledge.type} 
                      onValueChange={(v) => setNewKnowledge(prev => ({ ...prev, type: v as KnowledgeType }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {KNOWLEDGE_TYPES.map(type => (
                          <SelectItem key={type.value} value={type.value}>
                            <div className="flex items-center gap-2">
                              <type.icon className="h-4 w-4" />
                              {type.label}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Tags (comma separated)</label>
                    <Input
                      placeholder="e.g., family, important, daily"
                      value={newKnowledge.tags}
                      onChange={(e) => setNewKnowledge(prev => ({ ...prev, tags: e.target.value }))}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Content *</label>
                  <Textarea
                    placeholder="Enter the knowledge content..."
                    value={newKnowledge.content}
                    onChange={(e) => setNewKnowledge(prev => ({ ...prev, content: e.target.value }))}
                    rows={4}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Context (optional)</label>
                  <Input
                    placeholder="Additional context or source information"
                    value={newKnowledge.context}
                    onChange={(e) => setNewKnowledge(prev => ({ ...prev, context: e.target.value }))}
                  />
                </div>

                <Button 
                  onClick={handleAddKnowledge} 
                  disabled={addMutation.isPending}
                  className="w-full"
                >
                  {addMutation.isPending ? "Adding..." : "Add Knowledge"}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="browse" className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              {KNOWLEDGE_TYPES.map(type => {
                const count = stats?.byType?.[type.value] || 0;
                return (
                  <Card 
                    key={type.value} 
                    className="cursor-pointer hover:bg-accent/50 transition-colors"
                    onClick={() => {
                      setSelectedType(type.value);
                      setSearchQuery("");
                    }}
                  >
                    <CardContent className="py-4 flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${getTypeColor(type.value)}`}>
                        <type.icon className="h-5 w-5" />
                      </div>
                      <div>
                        <div className="font-medium">{type.label}</div>
                        <div className="text-sm text-muted-foreground">{count} entries</div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
