import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { FileText, CheckCircle2, XCircle, Search, Filter, RefreshCw, ChevronDown, ChevronUp } from "lucide-react";
import { useState } from "react";
import { formatDistanceToNow } from "date-fns";

export default function ConnectorLogs() {
  const [selectedConnector, setSelectedConnector] = useState<string>("all");
  const [selectedAction, setSelectedAction] = useState<string>("all");
  const [selectedStatus, setSelectedStatus] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedLog, setExpandedLog] = useState<number | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(false);

  const { data: households } = trpc.households.list.useQuery();
  const selectedHouseholdId = households?.[0]?.id;
  const { data: connectors = [] } = trpc.connectors.list.useQuery(
    { householdId: selectedHouseholdId! },
    { enabled: !!selectedHouseholdId }
  );
  const { data: logsData, refetch } = trpc.connectors.getLogs.useQuery(
    {
      connectorId: selectedConnector !== "all" ? parseInt(selectedConnector) : undefined,
      action: selectedAction !== "all" ? selectedAction : undefined,
      status: selectedStatus !== "all" ? (selectedStatus as "success" | "failed") : undefined,
      searchQuery: searchQuery || undefined,
      limit: 50,
      offset: 0,
    },
    {
      refetchInterval: autoRefresh ? 5000 : false, // Auto-refresh every 5 seconds if enabled
    }
  );

  const logs = logsData?.logs || [];
  const totalLogs = logsData?.total || 0;

  const getConnectorName = (connectorId: number) => {
    const connector = connectors.find((c) => c.id === connectorId);
    return connector?.name || `Connector #${connectorId}`;
  };

  const getActionLabel = (action: string) => {
    return action.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase());
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Connector Logs</h1>
            <p className="text-muted-foreground mt-2">
              Detailed activity logs for all connector operations
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant={autoRefresh ? "default" : "outline"}
              size="sm"
              onClick={() => setAutoRefresh(!autoRefresh)}
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${autoRefresh ? "animate-spin" : ""}`} />
              {autoRefresh ? "Auto-Refresh On" : "Auto-Refresh Off"}
            </Button>
            <Button variant="outline" size="sm" onClick={() => refetch()}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>

        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="h-5 w-5" />
              Filters
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Connector</label>
                <Select value={selectedConnector} onValueChange={setSelectedConnector}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Connectors" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Connectors</SelectItem>
                    {connectors.map((connector) => (
                      <SelectItem key={connector.id} value={connector.id.toString()}>
                        {connector.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Action</label>
                <Select value={selectedAction} onValueChange={setSelectedAction}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Actions" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Actions</SelectItem>
                    <SelectItem value="send_email">Send Email</SelectItem>
                    <SelectItem value="create_event">Create Event</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Status</label>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Statuses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="success">Success</SelectItem>
                    <SelectItem value="failed">Failed</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Search Errors</label>
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search error messages..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-8"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Logs Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Activity Logs
            </CardTitle>
            <CardDescription>
              Showing {logs.length} of {totalLogs} log{totalLogs !== 1 ? "s" : ""}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {logs.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  No logs found matching your filters
                </div>
              ) : (
                logs.map((log) => (
                  <div key={log.id} className="border rounded-lg p-4 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        {log.status === "success" ? (
                          <CheckCircle2 className="h-5 w-5 text-green-600" />
                        ) : (
                          <XCircle className="h-5 w-5 text-red-600" />
                        )}
                        <div>
                          <div className="font-medium">{getConnectorName(log.connectorId)}</div>
                          <div className="text-sm text-muted-foreground">
                            {getActionLabel(log.action)} · {formatDistanceToNow(log.createdAt, { addSuffix: true })}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge variant={log.status === "success" ? "default" : "destructive"}>
                          {log.status}
                        </Badge>
                        <span className="text-sm text-muted-foreground">{log.duration}ms</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setExpandedLog(expandedLog === log.id ? null : log.id)}
                        >
                          {expandedLog === log.id ? (
                            <ChevronUp className="h-4 w-4" />
                          ) : (
                            <ChevronDown className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </div>

                    {log.errorMessage && (
                      <div className="text-sm text-red-600 bg-red-50 dark:bg-red-950 p-2 rounded">
                        Error: {log.errorMessage}
                      </div>
                    )}

                    {expandedLog === log.id && (
                      <div className="mt-4 space-y-3 border-t pt-3">
                        <div>
                          <div className="text-sm font-medium mb-1">Request Data</div>
                          <pre className="text-xs bg-muted p-3 rounded overflow-x-auto">
                            {JSON.stringify(log.requestData, null, 2)}
                          </pre>
                        </div>
                        {(log.responseData as any) && (
                          <div>
                            <div className="text-sm font-medium mb-1">Response Data</div>
                            <pre className="text-xs bg-muted p-3 rounded overflow-x-auto">
                              {JSON.stringify(log.responseData as any, null, 2)}
                            </pre>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
