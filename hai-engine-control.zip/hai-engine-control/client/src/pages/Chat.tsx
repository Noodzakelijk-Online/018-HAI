import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { AIChatBox, Message } from "@/components/AIChatBox";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Loader2, MessageSquare, Plus } from "lucide-react";
import { toast } from "sonner";

export default function Chat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [conversationId, setConversationId] = useState<string | undefined>();
  const [engineType, setEngineType] = useState<'general' | 'selfModel' | 'decision' | 'task' | 'knowledge'>('general');
  const [isLoading, setIsLoading] = useState(false);

  const { data: conversations, refetch: refetchConversations } = trpc.chat.listConversations.useQuery();
  const sendMessageMutation = trpc.chat.sendMessage.useMutation();
  const learnFromConversationMutation = trpc.sme.learnFromConversation.useMutation();
  const deleteConversationMutation = trpc.chat.deleteConversation.useMutation();

  const handleSendMessage = async (content: string) => {
    if (!content.trim()) return;

    // Add user message to UI immediately
    const userMessage: Message = {
      role: 'user',
      content,
    };
    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    try {
      const result = await sendMessageMutation.mutateAsync({
        message: content,
        conversationId,
        engineType,
      });

      // Update conversation ID if this is a new conversation
      if (!conversationId) {
        setConversationId(result.conversationId);
        refetchConversations();
      }

      // Add assistant response
      const assistantMessage: Message = {
        role: 'assistant',
        content: result.response,
      };
      setMessages(prev => [...prev, assistantMessage]);

      // Trigger learning after every 3 messages (in background)
      if (messages.length >= 3 && messages.length % 3 === 0) {
        learnFromConversationMutation.mutate(
          { conversationId: result.conversationId },
          {
            onSuccess: (data) => {
              if (data.traits.length > 0) {
                toast.success(`HAI learned ${data.traits.length} new things about you`);
              }
            },
            onError: () => {
              // Silent fail - learning is not critical
            },
          }
        );
      }
    } catch (error) {
      console.error('Error sending message:', error);
      toast.error('Failed to send message');
      // Remove the user message on error
      setMessages(prev => prev.slice(0, -1));
    } finally {
      setIsLoading(false);
    }
  };

  const handleNewConversation = () => {
    setMessages([]);
    setConversationId(undefined);
    toast.success('Started new conversation');
  };

  const handleDeleteConversation = async (id: string) => {
    try {
      await deleteConversationMutation.mutateAsync({ conversationId: id });
      if (conversationId === id) {
        handleNewConversation();
      }
      refetchConversations();
      toast.success('Conversation deleted');
    } catch (error) {
      console.error('Error deleting conversation:', error);
      toast.error('Failed to delete conversation');
    }
  };

  const engineDescriptions = {
    general: "General conversation with HAI - universal reasoning across all domains",
    selfModel: "Self-Model Engine - helps HAI learn about you and your patterns",
    decision: "Decision Engine - helps you make better decisions with clear reasoning",
    task: "Task Orchestration Engine - breaks down goals into actionable tasks",
    knowledge: "Knowledge Graph Engine - connects information and discovers patterns",
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Chat with HAI</h1>
          <p className="text-muted-foreground mt-1">
            Have a natural conversation with your AI assistant
          </p>
        </div>
        <Button onClick={handleNewConversation} variant="outline">
          <Plus className="mr-2 h-4 w-4" />
          New Conversation
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar - Conversation History */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Conversations</CardTitle>
              <CardDescription>Your chat history</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {conversations && conversations.length > 0 ? (
                conversations.map((conv) => (
                  <div
                    key={conv.id}
                    className={`p-3 rounded-lg border cursor-pointer hover:bg-accent transition-colors ${
                      conversationId === conv.id ? 'bg-accent border-primary' : ''
                    }`}
                    onClick={() => {
                      // TODO: Load conversation messages
                      setConversationId(conv.id);
                      toast.info('Loading conversation...');
                    }}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{conv.title}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(conv.updatedAt).toLocaleDateString()}
                        </p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteConversation(conv.id);
                        }}
                        className="ml-2"
                      >
                        ×
                      </Button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <MessageSquare className="mx-auto h-12 w-12 mb-2 opacity-50" />
                  <p className="text-sm">No conversations yet</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Main Chat Area */}
        <div className="lg:col-span-3 space-y-4">
          {/* Engine Type Selector */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Engine Mode</CardTitle>
              <CardDescription>
                Choose which HAI engine to interact with
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Select value={engineType} onValueChange={(value: any) => setEngineType(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="general">General - Universal Reasoning</SelectItem>
                  <SelectItem value="selfModel">Self-Model - Learning About You</SelectItem>
                  <SelectItem value="decision">Decision - Help with Choices</SelectItem>
                  <SelectItem value="task">Task - Break Down Goals</SelectItem>
                  <SelectItem value="knowledge">Knowledge - Connect Information</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-sm text-muted-foreground mt-2">
                {engineDescriptions[engineType]}
              </p>
            </CardContent>
          </Card>

          {/* Chat Interface */}
          <Card>
            <CardContent className="p-0">
              <AIChatBox
                messages={messages}
                onSendMessage={handleSendMessage}
                isLoading={isLoading}
                placeholder={`Chat with HAI (${engineType} mode)...`}
                height="600px"
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
