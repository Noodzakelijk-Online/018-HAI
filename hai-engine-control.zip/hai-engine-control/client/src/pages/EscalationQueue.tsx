/**
 * Escalation Queue Page
 * 
 * Review and approve/reject messages that require human oversight
 */

import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, CheckCircle, XCircle, AlertTriangle, Clock, User, MessageSquare } from 'lucide-react';
import { toast } from 'sonner';
import { Streamdown } from 'streamdown';

export default function EscalationQueue() {
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editedResponse, setEditedResponse] = useState<string>('');
  
  // Fetch escalation queue
  const { data: queue, isLoading, refetch } = trpc.autonomousCommunication.getEscalationQueue.useQuery();
  
  // Mutations
  const approveMutation = trpc.autonomousCommunication.approveEscalation.useMutation({
    onSuccess: () => {
      toast.success('Message approved and sent');
      refetch();
      setEditingMessageId(null);
      setEditedResponse('');
    },
    onError: (error) => {
      toast.error(`Failed to approve: ${error.message}`);
    },
  });
  
  const rejectMutation = trpc.autonomousCommunication.rejectEscalation.useMutation({
    onSuccess: () => {
      toast.success('Message rejected');
      refetch();
    },
    onError: (error) => {
      toast.error(`Failed to reject: ${error.message}`);
    },
  });
  
  const handleApprove = (messageId: string) => {
    const message = queue?.find(m => m.messageId === messageId);
    if (!message) return;
    
    const response = editingMessageId === messageId ? editedResponse : message.generatedResponse;
    
    approveMutation.mutate({
      messageId,
      editedResponse: editingMessageId === messageId ? response : undefined,
    });
  };
  
  const handleReject = (messageId: string) => {
    rejectMutation.mutate({ messageId });
  };
  
  const handleEdit = (messageId: string, currentResponse: string) => {
    setEditingMessageId(messageId);
    setEditedResponse(currentResponse);
  };
  
  const handleCancelEdit = () => {
    setEditingMessageId(null);
    setEditedResponse('');
  };
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }
  
  return (
    <div className="container mx-auto py-8 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Escalation Queue</h1>
        <p className="text-muted-foreground">
          Review and approve messages that require human oversight before sending
        </p>
      </div>
      
      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Pending Review</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{queue?.length || 0}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Average Confidence</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {queue && queue.length > 0
                ? Math.round(queue.reduce((sum, m) => sum + m.compositeConfidence, 0) / queue.length)
                : 0}%
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Oldest Message</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {queue && queue.length > 0
                ? Math.round((Date.now() - new Date(queue[0].timestamp).getTime()) / 60000) + 'm'
                : 'N/A'}
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Queue */}
      {!queue || queue.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <CheckCircle className="w-12 h-12 mx-auto mb-4 text-green-500" />
            <h3 className="text-lg font-semibold mb-2">All caught up!</h3>
            <p className="text-muted-foreground">
              No messages require your review at the moment.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {queue.map((message) => (
            <Card key={message.messageId} className="border-l-4 border-l-yellow-500">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <User className="w-4 h-4" />
                      <CardTitle className="text-lg">{message.senderName}</CardTitle>
                      <Badge variant="outline">{message.senderId}</Badge>
                    </div>
                    <CardDescription className="flex items-center gap-4">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(message.timestamp).toLocaleString()}
                      </span>
                      <span className="flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        {message.compositeConfidence}% confidence
                      </span>
                    </CardDescription>
                  </div>
                  
                  <div className="flex gap-2">
                    <Badge variant={message.decision === 'escalate' ? 'default' : 'secondary'}>
                      {message.decision}
                    </Badge>
                    <Badge variant="outline">{message.status}</Badge>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                {/* Original Message */}
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <MessageSquare className="w-4 h-4" />
                    <h4 className="font-semibold">Incoming Message</h4>
                  </div>
                  <div className="bg-muted p-4 rounded-lg">
                    <Streamdown>{message.textContent}</Streamdown>
                  </div>
                </div>
                
                {/* Escalation Reasons */}
                {message.escalationReasons && message.escalationReasons.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-2">Escalation Reasons</h4>
                    <div className="flex flex-wrap gap-2">
                      {message.escalationReasons.map((reason, idx) => (
                        <Badge key={idx} variant="destructive">{reason}</Badge>
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Generated Response */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold">Generated Response</h4>
                    {editingMessageId !== message.messageId && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(message.messageId, message.generatedResponse)}
                      >
                        Edit
                      </Button>
                    )}
                  </div>
                  
                  {editingMessageId === message.messageId ? (
                    <Textarea
                      value={editedResponse}
                      onChange={(e) => setEditedResponse(e.target.value)}
                      className="min-h-[100px]"
                      placeholder="Edit the response..."
                    />
                  ) : (
                    <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                      <Streamdown>{message.generatedResponse}</Streamdown>
                    </div>
                  )}
                </div>
                
                {/* Response Reasoning */}
                {message.responseReasoning && (
                  <div>
                    <h4 className="font-semibold mb-2">Analysis</h4>
                    <p className="text-sm text-muted-foreground">{message.responseReasoning}</p>
                  </div>
                )}
                
                {/* Alternative Responses */}
                {message.alternatives && message.alternatives.length > 0 && (
                  <div>
                    <h4 className="font-semibold mb-2">Alternative Responses</h4>
                    <div className="space-y-2">
                      {message.alternatives.map((alt, idx) => (
                        <div key={idx} className="bg-muted p-3 rounded text-sm">
                          <Streamdown>{alt}</Streamdown>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Validation Results */}
                {message.validationResults && (
                  <div>
                    <h4 className="font-semibold mb-2">Validation Results</h4>
                    <div className="grid grid-cols-5 gap-2">
                      {Object.entries(message.validationResults).map(([key, value]) => {
                        if (key === 'overallScore') return null;
                        const result = value as any;
                        return (
                          <div key={key} className="text-center">
                            <div className={`text-2xl mb-1 ${result.passed ? 'text-green-500' : 'text-red-500'}`}>
                              {result.passed ? '✓' : '✗'}
                            </div>
                            <div className="text-xs font-medium capitalize">{key}</div>
                            <div className="text-xs text-muted-foreground">{result.score}%</div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </CardContent>
              
              <CardFooter className="flex justify-between">
                <div className="flex gap-2">
                  {editingMessageId === message.messageId && (
                    <Button
                      variant="outline"
                      onClick={handleCancelEdit}
                    >
                      Cancel
                    </Button>
                  )}
                </div>
                
                <div className="flex gap-2">
                  <Button
                    variant="destructive"
                    onClick={() => handleReject(message.messageId)}
                    disabled={rejectMutation.isPending}
                  >
                    {rejectMutation.isPending ? (
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    ) : (
                      <XCircle className="w-4 h-4 mr-2" />
                    )}
                    Reject
                  </Button>
                  
                  <Button
                    onClick={() => handleApprove(message.messageId)}
                    disabled={approveMutation.isPending}
                  >
                    {approveMutation.isPending ? (
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    ) : (
                      <CheckCircle className="w-4 h-4 mr-2" />
                    )}
                    Approve & Send
                  </Button>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
