import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Activity, AlertTriangle, CheckCircle2, Clock, Cpu, Database, FileText, Link2, Pause, Play, MessageSquare, Network, Workflow, TrendingUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { QuickActions } from "@/components/QuickActions";

export default function Dashboard() {
  const { data: engines, isLoading } = trpc.engines.list.useQuery();
  const { data: tasks } = trpc.tasks.list.useQuery({});
  const { data: policies } = trpc.policies.list.useQuery();
  const { data: events } = trpc.events.list.useQuery({ limit: 10 });
  const { data: messages } = trpc.communication.getMessages.useQuery({ limit: 5 });
  // Note: getExecutions requires playbookId, so we'll skip it for now
  const playbookExecutions: any[] = [];

  // Calculate stats from engines data
  const stats = engines ? {
    totalEngines: engines.length,
    runningEngines: engines.filter(e => e.status === "running").length,
    stoppedEngines: engines.filter(e => e.status === "stopped").length,
    activeTasks: tasks?.filter(t => t.status === "in_progress").length || 0,
    completedTasks: tasks?.filter(t => t.status === "completed").length || 0,
    activePolicies: policies?.filter(p => p.isActive).length || 0,
    connectors: 0,
    recentMessages: messages?.length || 0,
    activePlaybooks: 0, // Would need to query all playbooks
  } : null;

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "running":
        return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case "stopped":
        return <Pause className="h-5 w-5 text-gray-500" />;
      case "error":
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case "initializing":
        return <Clock className="h-5 w-5 text-yellow-500" />;
      default:
        return <Activity className="h-5 w-5" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "critical":
        return "destructive";
      case "high":
        return "default";
      case "medium":
        return "secondary";
      case "low":
        return "outline";
      default:
        return "secondary";
    }
  };

  const getEventTypeIcon = (type: string) => {
    if (type.includes('communication')) return <MessageSquare className="h-4 w-4" />;
    if (type.includes('playbook')) return <Workflow className="h-4 w-4" />;
    if (type.includes('task')) return <FileText className="h-4 w-4" />;
    if (type.includes('knowledge')) return <Network className="h-4 w-4" />;
    return <Activity className="h-4 w-4" />;
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold tracking-tight">HAI Engine Control Center</h1>
          <p className="text-muted-foreground mt-2">
            Monitor and control all Household AI engines in real-time
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Engines</CardTitle>
              <Cpu className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.totalEngines || 0}</div>
              <p className="text-xs text-muted-foreground">
                {stats?.runningEngines || 0} running, {stats?.stoppedEngines || 0} stopped
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Tasks</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.activeTasks || 0}</div>
              <p className="text-xs text-muted-foreground">
                {stats?.activeTasks || 0} in progress, {stats?.completedTasks || 0} completed
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Policies</CardTitle>
              <Database className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.activePolicies || 0}</div>
              <p className="text-xs text-muted-foreground">
                {stats?.activePolicies || 0} active policies
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Connectors</CardTitle>
              <Link2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.connectors || 0}</div>
              <p className="text-xs text-muted-foreground">
                {stats?.connectors || 0} connected
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <QuickActions />

        {/* Main Content Grid */}
        <div className="grid gap-6 md:grid-cols-2">
          {/* Engine Status */}
          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>Engine Status</CardTitle>
              <CardDescription>Real-time status of all HAI engines</CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px] pr-4">
                <div className="space-y-3">
                  {engines && engines.length > 0 ? (
                    engines.map((engine) => (
                      <div
                        key={engine.id}
                        className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          {getStatusIcon(engine.status)}
                          <div>
                            <p className="font-medium">{engine.name}</p>
                            <p className="text-sm text-muted-foreground">{engine.description}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={engine.priority === "critical" ? "destructive" : "secondary"}>
                            {engine.priority}
                          </Badge>
                          <Badge variant="outline">
                            Level {engine.autonomyLevel}
                          </Badge>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-center text-muted-foreground py-8">No engines found</p>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Activity Feed */}
          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Latest system events and actions</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="events" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="events">Events</TabsTrigger>
                  <TabsTrigger value="messages">Messages</TabsTrigger>
                  <TabsTrigger value="playbooks">Playbooks</TabsTrigger>
                </TabsList>
                
                <TabsContent value="events" className="mt-4">
                  <ScrollArea className="h-[320px] pr-4">
                    <div className="space-y-3">
                      {events && events.length > 0 ? (
                        events.map((event: any) => (
                          <div key={event.id} className="flex items-start gap-3 p-3 rounded-lg border">
                            <div className="mt-0.5">
                              {getEventTypeIcon(event.type || 'unknown')}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium">{event.type || 'Unknown Event'}</p>
                              <p className="text-xs text-muted-foreground mt-1">
                                {event.source || 'unknown'} → {event.target || 'unknown'}
                              </p>
                              <p className="text-xs text-muted-foreground mt-1">
                                {event.timestamp ? new Date(event.timestamp).toLocaleString() : 'No timestamp'}
                              </p>
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-center text-muted-foreground py-8">No recent events</p>
                      )}
                    </div>
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="messages" className="mt-4">
                  <ScrollArea className="h-[320px] pr-4">
                    <div className="space-y-3">
                      {messages && messages.length > 0 ? (
                        messages.map((message: any) => (
                          <div key={message.id} className="flex items-start gap-3 p-3 rounded-lg border">
                            <MessageSquare className="h-4 w-4 mt-0.5" />
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                <Badge variant="outline">{message.channel}</Badge>
                                <Badge variant={message.status === 'sent' ? 'default' : 'secondary'}>
                                  {message.status}
                                </Badge>
                              </div>
                              {message.subject && (
                                <p className="text-sm font-medium">{message.subject}</p>
                              )}
                              <p className="text-xs text-muted-foreground mt-1">
                                To: {message.recipient}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {new Date(message.createdAt).toLocaleString()}
                              </p>
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-center text-muted-foreground py-8">No recent messages</p>
                      )}
                    </div>
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="playbooks" className="mt-4">
                  <ScrollArea className="h-[320px] pr-4">
                    <div className="space-y-3">
                      {playbookExecutions && playbookExecutions.length > 0 ? (
                        playbookExecutions.map((execution: any) => (
                          <div key={execution.id} className="flex items-start gap-3 p-3 rounded-lg border">
                            <Workflow className="h-4 w-4 mt-0.5" />
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                <p className="text-sm font-medium">Execution #{execution.id}</p>
                                <Badge variant={execution.status === 'completed' ? 'default' : execution.status === 'failed' ? 'destructive' : 'secondary'}>
                                  {execution.status}
                                </Badge>
                              </div>
                              <p className="text-xs text-muted-foreground">
                                Step {execution.currentStep} of {execution.totalSteps}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {new Date(execution.createdAt).toLocaleString()}
                              </p>
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-center text-muted-foreground py-8">No recent executions</p>
                      )}
                    </div>
                  </ScrollArea>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        {/* System Health */}
        <Card>
          <CardHeader>
            <CardTitle>System Health</CardTitle>
            <CardDescription>Overall system performance and metrics</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-green-500/10">
                  <TrendingUp className="h-5 w-5 text-green-500" />
                </div>
                <div>
                  <p className="text-sm font-medium">Uptime</p>
                  <p className="text-2xl font-bold">99.9%</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-500/10">
                  <Activity className="h-5 w-5 text-blue-500" />
                </div>
                <div>
                  <p className="text-sm font-medium">Events/min</p>
                  <p className="text-2xl font-bold">{events?.length || 0}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-purple-500/10">
                  <MessageSquare className="h-5 w-5 text-purple-500" />
                </div>
                <div>
                  <p className="text-sm font-medium">Messages</p>
                  <p className="text-2xl font-bold">{stats?.recentMessages || 0}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-orange-500/10">
                  <Workflow className="h-5 w-5 text-orange-500" />
                </div>
                <div>
                  <p className="text-sm font-medium">Active Workflows</p>
                  <p className="text-2xl font-bold">{stats?.activePlaybooks || 0}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
