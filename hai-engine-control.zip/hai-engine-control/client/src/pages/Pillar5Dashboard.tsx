/**
 * Pillar 5 Dashboard: Integration Depth
 * 
 * "Deeply Embedded, Not Surface-Level"
 * 
 * This dashboard provides a unified view of:
 * - Universal Connectors
 * - Integration Status
 * - Sync Management
 */

import { useState } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import DashboardLayout from '@/components/DashboardLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { trpc } from '@/lib/trpc';
import {
  Plug,
  Mail,
  Calendar,
  DollarSign,
  Home,
  MessageSquare,
  ShoppingCart,
  Heart,
  Car,
  Zap,
  RefreshCw,
  Plus,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Clock,
  Activity,
  Settings,
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

const DEFAULT_HOUSEHOLD_ID = 1;

const connectorTypeIcons: Record<string, React.ReactNode> = {
  email: <Mail className="h-4 w-4 text-blue-500" />,
  calendar: <Calendar className="h-4 w-4 text-green-500" />,
  financial: <DollarSign className="h-4 w-4 text-emerald-500" />,
  smart_home: <Home className="h-4 w-4 text-orange-500" />,
  communication: <MessageSquare className="h-4 w-4 text-purple-500" />,
  shopping: <ShoppingCart className="h-4 w-4 text-pink-500" />,
  health: <Heart className="h-4 w-4 text-red-500" />,
  transportation: <Car className="h-4 w-4 text-cyan-500" />,
  utilities: <Zap className="h-4 w-4 text-yellow-500" />,
  custom: <Settings className="h-4 w-4 text-gray-500" />,
};

const statusColors: Record<string, string> = {
  active: 'bg-green-500/10 text-green-600 border-green-500/30',
  inactive: 'bg-gray-500/10 text-gray-600 border-gray-500/30',
  error: 'bg-red-500/10 text-red-600 border-red-500/30',
  pending: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/30',
  expired: 'bg-orange-500/10 text-orange-600 border-orange-500/30',
};

const statusIcons: Record<string, React.ReactNode> = {
  active: <CheckCircle2 className="h-4 w-4 text-green-500" />,
  inactive: <XCircle className="h-4 w-4 text-gray-500" />,
  error: <AlertTriangle className="h-4 w-4 text-red-500" />,
  pending: <Clock className="h-4 w-4 text-yellow-500" />,
  expired: <XCircle className="h-4 w-4 text-orange-500" />,
};

export default function Pillar5Dashboard() {
  const { user, loading } = useAuth();
  const [activeTab, setActiveTab] = useState('connectors');
  const [syncingId, setSyncingId] = useState<number | null>(null);

  // Fetch data
  const { data: connectors, refetch: refetchConnectors } = trpc.pillar5.connectors.list.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 30000 }
  );

  const { data: templates } = trpc.pillar5.templates.list.useQuery(
    undefined,
    { refetchInterval: 60000 }
  );

  const { data: statistics } = trpc.pillar5.statistics.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 30000 }
  );

  // Mutations
  const syncMutation = trpc.pillar5.connectors.sync.useMutation({
    onSuccess: () => {
      toast.success('Sync completed');
      refetchConnectors();
      setSyncingId(null);
    },
    onError: (error) => {
      toast.error(`Sync failed: ${error.message}`);
      setSyncingId(null);
    },
  });

  const syncAllMutation = trpc.pillar5.connectors.syncAll.useMutation({
    onSuccess: (events) => {
      toast.success(`Synced ${events.length} connectors`);
      refetchConnectors();
    },
    onError: (error) => {
      toast.error(`Sync failed: ${error.message}`);
    },
  });

  const handleSync = (connectorId: number) => {
    setSyncingId(connectorId);
    syncMutation.mutate({ connectorId });
  };

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Integration Depth</h1>
            <p className="text-muted-foreground mt-1">
              Pillar 5: Deeply Embedded, Not Surface-Level
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => syncAllMutation.mutate({ householdId: DEFAULT_HOUSEHOLD_ID })}
              disabled={syncAllMutation.isPending}
            >
              <RefreshCw className={cn("h-4 w-4 mr-2", syncAllMutation.isPending && "animate-spin")} />
              Sync All
            </Button>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Connector
            </Button>
          </div>
        </div>

        {/* Overview Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total</p>
                  <p className="text-2xl font-bold">{statistics?.totalConnectors ?? 0}</p>
                </div>
                <Plug className="h-8 w-8 text-blue-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Active</p>
                  <p className="text-2xl font-bold text-green-500">{statistics?.activeConnectors ?? 0}</p>
                </div>
                <CheckCircle2 className="h-8 w-8 text-green-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Errors</p>
                  <p className="text-2xl font-bold text-red-500">{statistics?.errorConnectors ?? 0}</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-red-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Sync Rate</p>
                  <p className="text-2xl font-bold">
                    {statistics?.syncSuccessRate
                      ? `${Math.round(statistics.syncSuccessRate * 100)}%`
                      : '—'}
                  </p>
                </div>
                <RefreshCw className="h-8 w-8 text-purple-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Events (24h)</p>
                  <p className="text-2xl font-bold">{statistics?.recentEvents ?? 0}</p>
                </div>
                <Activity className="h-8 w-8 text-cyan-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Templates</p>
                  <p className="text-2xl font-bold">{templates?.length ?? 0}</p>
                </div>
                <Settings className="h-8 w-8 text-gray-500 opacity-50" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 lg:w-auto lg:inline-grid">
            <TabsTrigger value="connectors" className="gap-2">
              <Plug className="h-4 w-4" />
              <span className="hidden sm:inline">Connectors</span>
            </TabsTrigger>
            <TabsTrigger value="templates" className="gap-2">
              <Plus className="h-4 w-4" />
              <span className="hidden sm:inline">Templates</span>
            </TabsTrigger>
            <TabsTrigger value="byType" className="gap-2">
              <Activity className="h-4 w-4" />
              <span className="hidden sm:inline">By Type</span>
            </TabsTrigger>
          </TabsList>

          {/* Connectors Tab */}
          <TabsContent value="connectors" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Plug className="h-5 w-5" />
                  Active Connectors
                </CardTitle>
                <CardDescription>
                  Manage your integrations with external services
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  {!connectors || connectors.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
                      <Plug className="h-12 w-12 mb-4 opacity-20" />
                      <p>No connectors configured</p>
                      <p className="text-sm">Add a connector to start integrating</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {connectors.map((connector: any) => (
                        <div
                          key={connector.id}
                          className="p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                        >
                          <div className="flex items-center gap-4">
                            <div className="p-2 rounded-lg bg-muted">
                              {connectorTypeIcons[connector.type] || <Plug className="h-4 w-4" />}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-medium">{connector.name}</span>
                                <Badge className={cn("border", statusColors[connector.status])}>
                                  {statusIcons[connector.status]}
                                  <span className="ml-1 capitalize">{connector.status}</span>
                                </Badge>
                                {!connector.isEnabled && (
                                  <Badge variant="secondary">Disabled</Badge>
                                )}
                              </div>
                              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                                <span className="capitalize">{connector.type.replace('_', ' ')}</span>
                                <span>•</span>
                                <span>{connector.provider}</span>
                                {connector.lastSyncAt && (
                                  <>
                                    <span>•</span>
                                    <span>Last sync: {new Date(connector.lastSyncAt).toLocaleString()}</span>
                                  </>
                                )}
                              </div>
                              {connector.lastError && (
                                <p className="text-xs text-red-500 mt-1">{connector.lastError}</p>
                              )}
                            </div>
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleSync(connector.id)}
                                disabled={syncingId === connector.id}
                              >
                                <RefreshCw className={cn(
                                  "h-4 w-4",
                                  syncingId === connector.id && "animate-spin"
                                )} />
                              </Button>
                              <Button size="sm" variant="ghost">
                                <Settings className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Templates Tab */}
          <TabsContent value="templates" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Plus className="h-5 w-5" />
                  Available Templates
                </CardTitle>
                <CardDescription>
                  Pre-configured connector templates for quick setup
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  {!templates || templates.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
                      <Settings className="h-12 w-12 mb-4 opacity-20" />
                      <p>No templates available</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {templates.map((template: any, index: number) => (
                        <div
                          key={index}
                          className="p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors cursor-pointer"
                        >
                          <div className="flex items-start gap-3">
                            <div className="p-2 rounded-lg bg-muted">
                              {connectorTypeIcons[template.type] || <Plug className="h-4 w-4" />}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-medium">{template.name}</span>
                                <Badge variant="outline" className="capitalize">
                                  {template.type.replace('_', ' ')}
                                </Badge>
                              </div>
                              <p className="text-sm text-muted-foreground mb-2">
                                {template.description}
                              </p>
                              <div className="flex flex-wrap gap-1">
                                {template.capabilities.slice(0, 3).map((cap: string, i: number) => (
                                  <Badge key={i} variant="secondary" className="text-xs">
                                    {cap.replace('_', ' ')}
                                  </Badge>
                                ))}
                                {template.capabilities.length > 3 && (
                                  <Badge variant="secondary" className="text-xs">
                                    +{template.capabilities.length - 3} more
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* By Type Tab */}
          <TabsContent value="byType" className="mt-6">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {Object.entries(statistics?.byType || {}).map(([type, count]) => (
                <Card key={type}>
                  <CardContent className="pt-6">
                    <div className="flex flex-col items-center text-center">
                      <div className="p-3 rounded-full bg-muted mb-3">
                        {connectorTypeIcons[type] || <Plug className="h-6 w-6" />}
                      </div>
                      <p className="text-2xl font-bold">{count as number}</p>
                      <p className="text-sm text-muted-foreground capitalize">
                        {type.replace('_', ' ')}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Status Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                  {Object.entries(statistics?.byStatus || {}).map(([status, count]) => (
                    <div key={status} className="p-4 rounded-lg bg-muted/50 text-center">
                      <div className="flex justify-center mb-2">
                        {statusIcons[status]}
                      </div>
                      <p className="text-2xl font-bold">{count as number}</p>
                      <p className="text-sm text-muted-foreground capitalize">{status}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
