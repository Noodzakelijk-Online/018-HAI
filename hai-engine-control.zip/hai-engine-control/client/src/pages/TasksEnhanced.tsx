import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Plus, List, LayoutGrid, BarChart3 } from 'lucide-react';
import { GanttChart } from '@/components/GanttChart';
import { KanbanBoard } from '@/components/KanbanBoard';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

export default function TasksEnhanced() {
  const [activeView, setActiveView] = useState<'list' | 'kanban' | 'gantt'>('kanban');

  // Fetch tasks
  const { data: tasks, isLoading } = trpc.taskOrchestration.getAllTasks.useQuery({});

  // Convert tasks to Gantt format
  const ganttTasks = tasks?.map((task) => ({
    id: task.id.toString(),
    title: task.title,
    start: task.scheduledFor || task.createdAt,
    end: task.completedAt || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
    progress: task.status === 'completed' ? 100 : task.status === 'in_progress' ? 50 : 0,
    assignee: task.assignedEngine || undefined,
  })) || [];

  // Convert tasks to Kanban format
  const kanbanColumns = [
    {
      id: 'draft',
      title: 'Draft',
      color: '#6b7280',
      tasks: tasks?.filter((t) => t.status === 'draft').map((t) => ({
        id: t.id.toString(),
        title: t.title,
        description: t.description || '',
        priority: t.priority,
        status: t.status,
        assignee: t.assignedEngine || 'unassigned',
        dueDate: t.scheduledFor || undefined,
        tags: [],
      })) || [],
    },
    {
      id: 'pending_approval',
      title: 'Pending Approval',
      color: '#f59e0b',
      tasks: tasks?.filter((t) => t.status === 'pending_approval').map((t) => ({
        id: t.id.toString(),
        title: t.title,
        description: t.description || '',
        priority: t.priority,
        status: t.status,
        assignee: t.assignedEngine || 'unassigned',
        dueDate: t.scheduledFor || undefined,
        tags: [],
      })) || [],
    },
    {
      id: 'approved',
      title: 'Approved',
      color: '#3b82f6',
      tasks: tasks?.filter((t) => t.status === 'approved').map((t) => ({
        id: t.id.toString(),
        title: t.title,
        description: t.description || '',
        priority: t.priority,
        status: t.status,
        assignee: t.assignedEngine || 'unassigned',
        dueDate: t.scheduledFor || undefined,
        tags: [],
      })) || [],
    },
    {
      id: 'in_progress',
      title: 'In Progress',
      color: '#8b5cf6',
      tasks: tasks?.filter((t) => t.status === 'in_progress').map((t) => ({
        id: t.id.toString(),
        title: t.title,
        description: t.description || '',
        priority: t.priority,
        status: t.status,
        assignee: t.assignedEngine || 'unassigned',
        dueDate: t.scheduledFor || undefined,
        tags: [],
      })) || [],
    },
    {
      id: 'completed',
      title: 'Completed',
      color: '#10b981',
      tasks: tasks?.filter((t) => t.status === 'completed').map((t) => ({
        id: t.id.toString(),
        title: t.title,
        description: t.description || '',
        priority: t.priority,
        status: t.status,
        assignee: t.assignedEngine || 'unassigned',
        dueDate: t.scheduledFor || undefined,
        tags: [],
      })) || [],
    },
    {
      id: 'failed',
      title: 'Failed',
      color: '#ef4444',
      tasks: tasks?.filter((t) => t.status === 'failed').map((t) => ({
        id: t.id.toString(),
        title: t.title,
        description: t.description || '',
        priority: t.priority,
        status: t.status,
        assignee: t.assignedEngine || 'unassigned',
        dueDate: t.scheduledFor || undefined,
        tags: [],
      })) || [],
    },
  ];

  const handleTaskMove = (taskId: string, fromColumn: string, toColumn: string) => {
    toast.info(`Moving task ${taskId} from ${fromColumn} to ${toColumn}`);
    // TODO: Implement task status update
  };

  const handleTaskClick = (task: any) => {
    toast.info(`Clicked task: ${task.title}`);
    // TODO: Open task details dialog
  };

  const handleAddTask = (columnId: string) => {
    toast.info(`Adding task to ${columnId}`);
    // TODO: Open create task dialog
  };

  if (isLoading) {
    return (
      <div className="container py-8">
        <div className="flex items-center justify-center h-64">
          <div className="text-muted-foreground">Loading tasks...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Tasks</h1>
          <p className="text-muted-foreground">
            Manage your tasks with Gantt charts, Kanban boards, and list views
          </p>
        </div>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          New Task
        </Button>
      </div>

      {/* View selector */}
      <Tabs value={activeView} onValueChange={(v) => setActiveView(v as any)}>
        <TabsList>
          <TabsTrigger value="list">
            <List className="mr-2 h-4 w-4" />
            List
          </TabsTrigger>
          <TabsTrigger value="kanban">
            <LayoutGrid className="mr-2 h-4 w-4" />
            Kanban
          </TabsTrigger>
          <TabsTrigger value="gantt">
            <BarChart3 className="mr-2 h-4 w-4" />
            Gantt
          </TabsTrigger>
        </TabsList>

        <TabsContent value="list" className="mt-6">
          <div className="text-center py-12 text-muted-foreground">
            List view - Use existing Tasks page implementation
          </div>
        </TabsContent>

        <TabsContent value="kanban" className="mt-6">
          <KanbanBoard
            columns={kanbanColumns}
            onTaskMove={handleTaskMove}
            onTaskClick={handleTaskClick}
            onAddTask={handleAddTask}
          />
        </TabsContent>

        <TabsContent value="gantt" className="mt-6">
          <GanttChart
            tasks={ganttTasks}
            onTaskClick={handleTaskClick}
          />
        </TabsContent>
      </Tabs>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-card border rounded-lg p-4">
          <div className="text-2xl font-bold">{tasks?.length || 0}</div>
          <div className="text-sm text-muted-foreground">Total Tasks</div>
        </div>
        <div className="bg-card border rounded-lg p-4">
          <div className="text-2xl font-bold">
            {tasks?.filter((t) => t.status === 'in_progress').length || 0}
          </div>
          <div className="text-sm text-muted-foreground">In Progress</div>
        </div>
        <div className="bg-card border rounded-lg p-4">
          <div className="text-2xl font-bold">
            {tasks?.filter((t) => t.status === 'completed').length || 0}
          </div>
          <div className="text-sm text-muted-foreground">Completed</div>
        </div>
        <div className="bg-card border rounded-lg p-4">
          <div className="text-2xl font-bold">
            {tasks?.filter((t) => t.status === 'failed').length || 0}
          </div>
          <div className="text-sm text-muted-foreground">Failed</div>
        </div>
      </div>
    </div>
  );
}
