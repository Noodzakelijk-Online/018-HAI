/**
 * Pillar 3 Dashboard: Household Model
 * 
 * "Serves the Household, Not Just Users"
 * 
 * This dashboard provides a unified view of:
 * - Tier System (member management)
 * - Relationships (contacts, family dynamics)
 */

import { useState } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import DashboardLayout from '@/components/DashboardLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { trpc } from '@/lib/trpc';
import {
  Users,
  UserPlus,
  Network,
  Crown,
  Shield,
  User,
  UserCheck,
  Eye,
  Phone,
  Mail,
  Building2,
  Heart,
  Briefcase,
  Wrench,
  GraduationCap,
  Stethoscope,
  ChevronRight,
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

const DEFAULT_HOUSEHOLD_ID = 1;

const tierIcons: Record<string, React.ReactNode> = {
  owner: <Crown className="h-4 w-4 text-yellow-500" />,
  manager: <Shield className="h-4 w-4 text-blue-500" />,
  trusted_member: <UserCheck className="h-4 w-4 text-green-500" />,
  member: <User className="h-4 w-4 text-gray-500" />,
  guest: <Eye className="h-4 w-4 text-gray-400" />,
};

const tierColors: Record<string, string> = {
  owner: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/30',
  manager: 'bg-blue-500/10 text-blue-600 border-blue-500/30',
  trusted_member: 'bg-green-500/10 text-green-600 border-green-500/30',
  member: 'bg-gray-500/10 text-gray-600 border-gray-500/30',
  guest: 'bg-gray-400/10 text-gray-500 border-gray-400/30',
};

const relationshipIcons: Record<string, React.ReactNode> = {
  spouse: <Heart className="h-4 w-4 text-red-500" />,
  parent: <Users className="h-4 w-4 text-blue-500" />,
  child: <User className="h-4 w-4 text-green-500" />,
  sibling: <Users className="h-4 w-4 text-purple-500" />,
  friend: <Heart className="h-4 w-4 text-pink-500" />,
  colleague: <Briefcase className="h-4 w-4 text-indigo-500" />,
  service_provider: <Wrench className="h-4 w-4 text-orange-500" />,
  healthcare: <Stethoscope className="h-4 w-4 text-red-500" />,
  education: <GraduationCap className="h-4 w-4 text-blue-500" />,
  other: <User className="h-4 w-4 text-gray-500" />,
};

const strengthColors: Record<string, string> = {
  close: 'text-green-500',
  regular: 'text-blue-500',
  occasional: 'text-yellow-500',
  distant: 'text-gray-500',
};

export default function Pillar3Dashboard() {
  const { user, loading } = useAuth();
  const [activeTab, setActiveTab] = useState('members');

  // Fetch data
  const { data: members, refetch: refetchMembers } = trpc.pillar3.members.list.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 30000 }
  );

  const { data: tierDefinitions } = trpc.pillar3.tiers.definitions.useQuery();

  const { data: pendingRequests } = trpc.pillar3.members.pendingRequests.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 30000 }
  );

  const { data: contacts } = trpc.pillar3.contacts.list.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 30000 }
  );

  const { data: relationships } = trpc.pillar3.relationships.list.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 30000 }
  );

  const { data: relationshipGraph } = trpc.pillar3.relationships.graph.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 60000 }
  );

  const { data: statistics } = trpc.pillar3.statistics.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 30000 }
  );

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Household Model</h1>
            <p className="text-muted-foreground mt-1">
              Pillar 3: Serves the Household, Not Just Users
            </p>
          </div>
          <Badge variant="outline" className="text-lg px-4 py-2">
            <Users className="h-4 w-4 mr-2 text-blue-500" />
            {statistics?.summary.activeMembers ?? 0} Active Members
          </Badge>
        </div>

        {/* Overview Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Members</p>
                  <p className="text-2xl font-bold">{statistics?.summary.totalMembers ?? 0}</p>
                </div>
                <Users className="h-8 w-8 text-blue-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Contacts</p>
                  <p className="text-2xl font-bold">{statistics?.summary.totalContacts ?? 0}</p>
                </div>
                <Phone className="h-8 w-8 text-green-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Relationships</p>
                  <p className="text-2xl font-bold">{statistics?.summary.totalRelationships ?? 0}</p>
                </div>
                <Network className="h-8 w-8 text-purple-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Pending Requests</p>
                  <p className="text-2xl font-bold">{statistics?.summary.pendingRequests ?? 0}</p>
                </div>
                <UserPlus className="h-8 w-8 text-orange-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Owners</p>
                  <p className="text-2xl font-bold">{statistics?.tiers.byTier.owner ?? 0}</p>
                </div>
                <Crown className="h-8 w-8 text-yellow-500 opacity-50" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:inline-grid">
            <TabsTrigger value="members" className="gap-2">
              <Users className="h-4 w-4" />
              <span className="hidden sm:inline">Members</span>
            </TabsTrigger>
            <TabsTrigger value="tiers" className="gap-2">
              <Shield className="h-4 w-4" />
              <span className="hidden sm:inline">Tiers</span>
            </TabsTrigger>
            <TabsTrigger value="contacts" className="gap-2">
              <Phone className="h-4 w-4" />
              <span className="hidden sm:inline">Contacts</span>
            </TabsTrigger>
            <TabsTrigger value="relationships" className="gap-2">
              <Network className="h-4 w-4" />
              <span className="hidden sm:inline">Relationships</span>
            </TabsTrigger>
          </TabsList>

          {/* Members Tab */}
          <TabsContent value="members" className="mt-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Household Members
                  </CardTitle>
                  <CardDescription>
                    Manage household members and their access levels
                  </CardDescription>
                </div>
                <Button>
                  <UserPlus className="h-4 w-4 mr-2" />
                  Invite Member
                </Button>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  {!members || members.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
                      <Users className="h-12 w-12 mb-4 opacity-20" />
                      <p>No members yet</p>
                      <p className="text-sm">Invite members to your household</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {members.map((member: any) => (
                        <div
                          key={member.id}
                          className="p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                        >
                          <div className="flex items-center gap-4">
                            <Avatar className="h-12 w-12">
                              <AvatarImage src={member.avatar} />
                              <AvatarFallback>
                                {member.displayName.split(' ').map((n: string) => n[0]).join('').toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-medium">{member.displayName}</span>
                                <Badge className={cn("border", tierColors[member.tier])}>
                                  {tierIcons[member.tier]}
                                  <span className="ml-1 capitalize">{member.tier.replace('_', ' ')}</span>
                                </Badge>
                                {!member.isActive && (
                                  <Badge variant="secondary">Inactive</Badge>
                                )}
                              </div>
                              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                                {member.email && (
                                  <span className="flex items-center gap-1">
                                    <Mail className="h-3 w-3" />
                                    {member.email}
                                  </span>
                                )}
                                {member.phone && (
                                  <span className="flex items-center gap-1">
                                    <Phone className="h-3 w-3" />
                                    {member.phone}
                                  </span>
                                )}
                              </div>
                            </div>
                            <Button variant="ghost" size="sm">
                              <ChevronRight className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Pending Requests */}
            {(pendingRequests?.length ?? 0) > 0 && (
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <UserPlus className="h-5 w-5 text-orange-500" />
                    Pending Tier Change Requests
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {pendingRequests?.map((request: any) => (
                      <div
                        key={request.id}
                        className="p-4 rounded-lg border bg-card"
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">
                              Member #{request.memberId}: {request.fromTier} → {request.toTier}
                            </p>
                            <p className="text-sm text-muted-foreground">{request.reason}</p>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline">Reject</Button>
                            <Button size="sm">Approve</Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Tiers Tab */}
          <TabsContent value="tiers" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {tierDefinitions?.map((tier: any) => (
                <Card key={tier.tier} className={cn("border-2", tierColors[tier.tier])}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      {tierIcons[tier.tier]}
                      {tier.name}
                    </CardTitle>
                    <CardDescription>{tier.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <p className="text-sm font-medium mb-2">Key Permissions</p>
                        <div className="space-y-1 text-sm text-muted-foreground">
                          <p>• Payment limit: {tier.permissions.maxPaymentAmount ? `$${tier.permissions.maxPaymentAmount}` : 'Unlimited'}</p>
                          <p>• Can invite: {tier.permissions.canInviteMembers ? 'Yes' : 'No'}</p>
                          <p>• Can override: {tier.permissions.canOverrideActions ? 'Yes' : 'No'}</p>
                          <p>• Access logs: {tier.permissions.canAccessLogs ? 'Yes' : 'No'}</p>
                        </div>
                      </div>
                      <div>
                        <p className="text-sm font-medium mb-2">Limits</p>
                        <div className="space-y-1 text-sm text-muted-foreground">
                          <p>• Daily actions: {tier.limits.dailyActionLimit ?? 'Unlimited'}</p>
                          <p>• Monthly spend: {tier.limits.monthlySpendingLimit ? `$${tier.limits.monthlySpendingLimit}` : 'Unlimited'}</p>
                          <p>• Automations: {tier.limits.maxActiveAutomations ?? 'Unlimited'}</p>
                        </div>
                      </div>
                      <div className="pt-2">
                        <Badge variant="outline">
                          {statistics?.tiers.byTier[tier.tier] ?? 0} members
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Contacts Tab */}
          <TabsContent value="contacts" className="mt-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Phone className="h-5 w-5" />
                    External Contacts
                  </CardTitle>
                  <CardDescription>
                    People and services outside your household
                  </CardDescription>
                </div>
                <Button>
                  <UserPlus className="h-4 w-4 mr-2" />
                  Add Contact
                </Button>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  {!contacts || contacts.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
                      <Phone className="h-12 w-12 mb-4 opacity-20" />
                      <p>No contacts yet</p>
                      <p className="text-sm">Add contacts to track relationships</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {contacts.map((contact: any) => (
                        <div
                          key={contact.id}
                          className="p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                        >
                          <div className="flex items-center gap-4">
                            <Avatar className="h-10 w-10">
                              <AvatarFallback>
                                {contact.name.split(' ').map((n: string) => n[0]).join('').toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-medium">{contact.name}</span>
                                <Badge variant="outline" className="capitalize">
                                  {contact.category}
                                </Badge>
                                <Badge variant={
                                  contact.importance === 'high' ? 'destructive' :
                                  contact.importance === 'medium' ? 'default' : 'secondary'
                                }>
                                  {contact.importance}
                                </Badge>
                              </div>
                              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                                {contact.organization && (
                                  <span className="flex items-center gap-1">
                                    <Building2 className="h-3 w-3" />
                                    {contact.organization}
                                  </span>
                                )}
                                {contact.email && (
                                  <span className="flex items-center gap-1">
                                    <Mail className="h-3 w-3" />
                                    {contact.email}
                                  </span>
                                )}
                                <span>{contact.totalInteractions} interactions</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Relationships Tab */}
          <TabsContent value="relationships" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Network className="h-5 w-5" />
                    Relationship List
                  </CardTitle>
                  <CardDescription>
                    Connections between members and contacts
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[350px]">
                    {!relationships || relationships.length === 0 ? (
                      <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
                        <Network className="h-12 w-12 mb-4 opacity-20" />
                        <p>No relationships defined</p>
                        <p className="text-sm">Add relationships to map connections</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {relationships.map((rel: any) => (
                          <div
                            key={rel.id}
                            className="p-4 rounded-lg border bg-card"
                          >
                            <div className="flex items-center gap-3">
                              {relationshipIcons[rel.relationshipType] || relationshipIcons.other}
                              <div className="flex-1">
                                <div className="flex items-center gap-2">
                                  <span className="font-medium capitalize">
                                    {rel.relationshipType.replace('_', ' ')}
                                  </span>
                                  <span className={cn("text-sm", strengthColors[rel.strength])}>
                                    ({rel.strength})
                                  </span>
                                  {rel.inferredFromInteractions && (
                                    <Badge variant="outline" className="text-xs">Inferred</Badge>
                                  )}
                                </div>
                                <p className="text-sm text-muted-foreground">
                                  Member #{rel.member1Id} ↔ {rel.member2Id ? `Member #${rel.member2Id}` : rel.externalContactId}
                                </p>
                              </div>
                              <Badge variant="outline">
                                {Math.round(rel.confidenceScore * 100)}%
                              </Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Network className="h-5 w-5" />
                    Relationship Graph
                  </CardTitle>
                  <CardDescription>
                    Visual representation of connections
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[350px] flex items-center justify-center border rounded-lg bg-muted/50">
                    {relationshipGraph && relationshipGraph.nodes.length > 0 ? (
                      <div className="text-center">
                        <Network className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                        <p className="font-medium">{relationshipGraph.nodes.length} Nodes</p>
                        <p className="text-sm text-muted-foreground">{relationshipGraph.edges.length} Connections</p>
                        <p className="text-xs text-muted-foreground mt-2">
                          Interactive graph visualization coming soon
                        </p>
                      </div>
                    ) : (
                      <div className="text-center text-muted-foreground">
                        <Network className="h-16 w-16 mx-auto mb-4 opacity-20" />
                        <p>No graph data available</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Relationship Statistics */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Relationship Statistics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground">Close Relationships</p>
                    <p className="text-2xl font-bold text-green-500">
                      {statistics?.relationships.byStrength.close ?? 0}
                    </p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground">Regular</p>
                    <p className="text-2xl font-bold text-blue-500">
                      {statistics?.relationships.byStrength.regular ?? 0}
                    </p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground">Inferred</p>
                    <p className="text-2xl font-bold text-purple-500">
                      {statistics?.relationships.inferredCount ?? 0}
                    </p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground">Avg Confidence</p>
                    <p className="text-2xl font-bold">
                      {statistics?.relationships.avgConfidence
                        ? `${Math.round(statistics.relationships.avgConfidence * 100)}%`
                        : '—'}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
