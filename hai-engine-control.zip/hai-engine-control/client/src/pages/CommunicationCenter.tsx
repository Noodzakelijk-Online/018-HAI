/**
 * Communication Center
 * 
 * Unified interface for all external communications:
 * - Email drafting and sending
 * - Vendor communication templates
 * - Appointment scheduling
 * - Service provider interface
 */

import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useState } from "react";
import { toast } from "sonner";
import { 
  Mail, 
  MessageSquare, 
  Calendar, 
  Building2, 
  Send, 
  FileText,
  Clock,
  User,
  Phone,
  Plus,
  Search,
  Filter,
  ChevronRight,
  Sparkles
} from "lucide-react";

interface EmailDraft {
  id: string;
  to: string;
  subject: string;
  body: string;
  status: 'draft' | 'pending_approval' | 'sent';
  createdAt: Date;
  scheduledFor?: Date;
}

interface CommunicationTemplate {
  id: string;
  name: string;
  category: string;
  subject: string;
  body: string;
  variables: string[];
}

interface ServiceProvider {
  id: string;
  name: string;
  category: string;
  email: string;
  phone: string;
  lastContact?: Date;
  rating: number;
}

const templates: CommunicationTemplate[] = [
  {
    id: '1',
    name: 'Service Appointment Request',
    category: 'vendor',
    subject: 'Appointment Request - {{service_type}}',
    body: 'Dear {{vendor_name}},\n\nI would like to schedule an appointment for {{service_type}}.\n\nPreferred dates: {{preferred_dates}}\nPreferred time: {{preferred_time}}\n\nPlease let me know your availability.\n\nBest regards,\n{{user_name}}',
    variables: ['vendor_name', 'service_type', 'preferred_dates', 'preferred_time', 'user_name']
  },
  {
    id: '2',
    name: 'Service Cancellation',
    category: 'vendor',
    subject: 'Cancellation Request - {{service_type}}',
    body: 'Dear {{vendor_name}},\n\nI need to cancel my appointment scheduled for {{appointment_date}}.\n\nReason: {{reason}}\n\nPlease confirm the cancellation.\n\nBest regards,\n{{user_name}}',
    variables: ['vendor_name', 'service_type', 'appointment_date', 'reason', 'user_name']
  },
  {
    id: '3',
    name: 'Bill Inquiry',
    category: 'financial',
    subject: 'Inquiry Regarding Bill - Account #{{account_number}}',
    body: 'Dear {{company_name}},\n\nI have a question regarding my recent bill dated {{bill_date}}.\n\n{{inquiry_details}}\n\nPlease provide clarification at your earliest convenience.\n\nAccount Number: {{account_number}}\n\nBest regards,\n{{user_name}}',
    variables: ['company_name', 'bill_date', 'inquiry_details', 'account_number', 'user_name']
  },
  {
    id: '4',
    name: 'Maintenance Request',
    category: 'home',
    subject: 'Maintenance Request - {{issue_type}}',
    body: 'Dear {{property_manager}},\n\nI am writing to report a maintenance issue:\n\nIssue Type: {{issue_type}}\nLocation: {{location}}\nDescription: {{description}}\nUrgency: {{urgency}}\n\nPlease arrange for repairs at your earliest convenience.\n\nBest regards,\n{{user_name}}\n{{address}}',
    variables: ['property_manager', 'issue_type', 'location', 'description', 'urgency', 'user_name', 'address']
  }
];

const serviceProviders: ServiceProvider[] = [
  { id: '1', name: 'ABC Plumbing', category: 'plumbing', email: 'service@abcplumbing.com', phone: '555-0101', rating: 4.8 },
  { id: '2', name: 'Elite Electric', category: 'electrical', email: 'contact@eliteelectric.com', phone: '555-0102', rating: 4.5 },
  { id: '3', name: 'Green Lawn Care', category: 'landscaping', email: 'info@greenlawn.com', phone: '555-0103', rating: 4.9 },
  { id: '4', name: 'Cool Air HVAC', category: 'hvac', email: 'service@coolair.com', phone: '555-0104', rating: 4.7 },
  { id: '5', name: 'CleanPro Services', category: 'cleaning', email: 'book@cleanpro.com', phone: '555-0105', rating: 4.6 },
];

export default function CommunicationCenter() {
  const [drafts, setDrafts] = useState<EmailDraft[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<CommunicationTemplate | null>(null);
  const [newEmail, setNewEmail] = useState({ to: '', subject: '', body: '' });
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  const handleSendEmail = () => {
    if (!newEmail.to || !newEmail.subject || !newEmail.body) {
      toast.error('Please fill in all fields');
      return;
    }

    const draft: EmailDraft = {
      id: Date.now().toString(),
      ...newEmail,
      status: 'pending_approval',
      createdAt: new Date()
    };

    setDrafts(prev => [...prev, draft]);
    setNewEmail({ to: '', subject: '', body: '' });
    toast.success('Email queued for approval');
  };

  const handleUseTemplate = (template: CommunicationTemplate) => {
    setSelectedTemplate(template);
    setNewEmail({
      to: '',
      subject: template.subject,
      body: template.body
    });
    toast.info('Template loaded. Fill in the variables.');
  };

  const handleAIDraft = () => {
    toast.info('HAI is drafting a response based on context...');
    setTimeout(() => {
      setNewEmail(prev => ({
        ...prev,
        body: prev.body + '\n\n[AI-generated content would appear here based on conversation context and household preferences]'
      }));
      toast.success('AI draft added');
    }, 1500);
  };

  const filteredProviders = serviceProviders.filter(provider => {
    const matchesSearch = provider.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         provider.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || provider.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  return (
    <DashboardLayout>
      <div className="p-4 md:p-6 space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">Communication Center</h1>
            <p className="text-muted-foreground mt-1">
              Manage all external communications from one place
            </p>
          </div>
          <div className="flex gap-2">
            <Badge variant="outline" className="px-3 py-1">
              <Mail className="h-3 w-3 mr-1" />
              {drafts.filter(d => d.status === 'draft').length} Drafts
            </Badge>
            <Badge variant="outline" className="px-3 py-1">
              <Clock className="h-3 w-3 mr-1" />
              {drafts.filter(d => d.status === 'pending_approval').length} Pending
            </Badge>
          </div>
        </div>

        <Tabs defaultValue="compose" className="space-y-4">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 h-auto">
            <TabsTrigger value="compose" className="flex items-center gap-2 py-2">
              <Mail className="h-4 w-4" />
              <span className="hidden sm:inline">Compose</span>
            </TabsTrigger>
            <TabsTrigger value="templates" className="flex items-center gap-2 py-2">
              <FileText className="h-4 w-4" />
              <span className="hidden sm:inline">Templates</span>
            </TabsTrigger>
            <TabsTrigger value="providers" className="flex items-center gap-2 py-2">
              <Building2 className="h-4 w-4" />
              <span className="hidden sm:inline">Providers</span>
            </TabsTrigger>
            <TabsTrigger value="schedule" className="flex items-center gap-2 py-2">
              <Calendar className="h-4 w-4" />
              <span className="hidden sm:inline">Schedule</span>
            </TabsTrigger>
          </TabsList>

          {/* Compose Tab */}
          <TabsContent value="compose" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* Email Composer */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Mail className="h-5 w-5" />
                    New Message
                  </CardTitle>
                  <CardDescription>
                    Compose and send emails on behalf of your household
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="to">To</Label>
                    <Input
                      id="to"
                      placeholder="recipient@example.com"
                      value={newEmail.to}
                      onChange={(e) => setNewEmail(prev => ({ ...prev, to: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="subject">Subject</Label>
                    <Input
                      id="subject"
                      placeholder="Email subject"
                      value={newEmail.subject}
                      onChange={(e) => setNewEmail(prev => ({ ...prev, subject: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="body">Message</Label>
                    <Textarea
                      id="body"
                      placeholder="Write your message..."
                      className="min-h-[200px]"
                      value={newEmail.body}
                      onChange={(e) => setNewEmail(prev => ({ ...prev, body: e.target.value }))}
                    />
                  </div>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <Button onClick={handleSendEmail} className="flex-1">
                      <Send className="h-4 w-4 mr-2" />
                      Queue for Approval
                    </Button>
                    <Button variant="outline" onClick={handleAIDraft}>
                      <Sparkles className="h-4 w-4 mr-2" />
                      AI Draft
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Recent Drafts */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Drafts</CardTitle>
                </CardHeader>
                <CardContent>
                  {drafts.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-8">
                      No drafts yet
                    </p>
                  ) : (
                    <div className="space-y-2">
                      {drafts.slice(-5).reverse().map(draft => (
                        <div 
                          key={draft.id}
                          className="p-3 border rounded-lg hover:bg-accent/50 cursor-pointer"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-sm truncate">
                              {draft.subject || 'No subject'}
                            </span>
                            <Badge variant={
                              draft.status === 'sent' ? 'default' :
                              draft.status === 'pending_approval' ? 'secondary' : 'outline'
                            }>
                              {draft.status}
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            To: {draft.to}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Templates Tab */}
          <TabsContent value="templates" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Communication Templates</CardTitle>
                <CardDescription>
                  Pre-built templates for common communications
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {templates.map(template => (
                    <Card key={template.id} className="hover:border-primary/50 transition-colors">
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-base">{template.name}</CardTitle>
                          <Badge variant="outline">{template.category}</Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                          {template.body.substring(0, 100)}...
                        </p>
                        <div className="flex flex-wrap gap-1 mb-4">
                          {template.variables.slice(0, 3).map(v => (
                            <Badge key={v} variant="secondary" className="text-xs">
                              {`{{${v}}}`}
                            </Badge>
                          ))}
                          {template.variables.length > 3 && (
                            <Badge variant="secondary" className="text-xs">
                              +{template.variables.length - 3} more
                            </Badge>
                          )}
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full"
                          onClick={() => handleUseTemplate(template)}
                        >
                          Use Template
                          <ChevronRight className="h-4 w-4 ml-1" />
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Service Providers Tab */}
          <TabsContent value="providers" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row justify-between gap-4">
                  <div>
                    <CardTitle>Service Providers</CardTitle>
                    <CardDescription>
                      Your trusted service providers directory
                    </CardDescription>
                  </div>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="h-4 w-4 mr-2" />
                        Add Provider
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Add Service Provider</DialogTitle>
                        <DialogDescription>
                          Add a new service provider to your directory
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        <div className="space-y-2">
                          <Label>Provider Name</Label>
                          <Input placeholder="Company name" />
                        </div>
                        <div className="space-y-2">
                          <Label>Category</Label>
                          <Select>
                            <SelectTrigger>
                              <SelectValue placeholder="Select category" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="plumbing">Plumbing</SelectItem>
                              <SelectItem value="electrical">Electrical</SelectItem>
                              <SelectItem value="hvac">HVAC</SelectItem>
                              <SelectItem value="landscaping">Landscaping</SelectItem>
                              <SelectItem value="cleaning">Cleaning</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label>Email</Label>
                          <Input type="email" placeholder="contact@provider.com" />
                        </div>
                        <div className="space-y-2">
                          <Label>Phone</Label>
                          <Input type="tel" placeholder="555-0100" />
                        </div>
                        <Button className="w-full">Add Provider</Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                {/* Search and Filter */}
                <div className="flex flex-col sm:flex-row gap-4 mb-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search providers..."
                      className="pl-9"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                    <SelectTrigger className="w-full sm:w-40">
                      <Filter className="h-4 w-4 mr-2" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      <SelectItem value="plumbing">Plumbing</SelectItem>
                      <SelectItem value="electrical">Electrical</SelectItem>
                      <SelectItem value="hvac">HVAC</SelectItem>
                      <SelectItem value="landscaping">Landscaping</SelectItem>
                      <SelectItem value="cleaning">Cleaning</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Provider List */}
                <div className="space-y-2">
                  {filteredProviders.map(provider => (
                    <div 
                      key={provider.id}
                      className="flex flex-col sm:flex-row sm:items-center justify-between p-4 border rounded-lg gap-4"
                    >
                      <div className="flex items-center gap-4">
                        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                          <Building2 className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-medium">{provider.name}</h4>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Badge variant="outline" className="text-xs">
                              {provider.category}
                            </Badge>
                            <span>★ {provider.rating}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 ml-14 sm:ml-0">
                        <Button variant="outline" size="sm">
                          <Mail className="h-4 w-4 mr-1" />
                          Email
                        </Button>
                        <Button variant="outline" size="sm">
                          <Phone className="h-4 w-4 mr-1" />
                          Call
                        </Button>
                        <Button variant="outline" size="sm">
                          <Calendar className="h-4 w-4 mr-1" />
                          Book
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Schedule Tab */}
          <TabsContent value="schedule" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Appointment Scheduling</CardTitle>
                <CardDescription>
                  Schedule and manage service appointments
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Calendar className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No Upcoming Appointments</h3>
                  <p className="text-muted-foreground mb-4">
                    Schedule appointments with your service providers
                  </p>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Schedule Appointment
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
