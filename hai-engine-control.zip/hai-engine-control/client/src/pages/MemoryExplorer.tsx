/**
 * Memory Explorer
 * 
 * Browse and manage HAI's household memory:
 * - Search memories by keyword, date, or category
 * - View memory details and context
 * - Memory consolidation and cleanup
 * - Memory importance scoring
 */

import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useState } from "react";
import { toast } from "sonner";
import { 
  Brain, 
  Search, 
  Calendar, 
  Tag, 
  Star,
  Trash2,
  RefreshCw,
  Filter,
  Clock,
  User,
  MapPin,
  FileText,
  Lightbulb,
  Heart,
  AlertTriangle,
  ChevronRight,
  Sparkles
} from "lucide-react";

interface Memory {
  id: string;
  type: 'event' | 'preference' | 'relationship' | 'routine' | 'fact' | 'emotion';
  content: string;
  context: string;
  importance: number;
  createdAt: Date;
  lastAccessed: Date;
  accessCount: number;
  relatedMembers: string[];
  tags: string[];
  source: string;
}

const sampleMemories: Memory[] = [
  {
    id: '1',
    type: 'preference',
    content: 'Sarah prefers her coffee with oat milk, no sugar',
    context: 'Observed during morning routine discussions',
    importance: 0.7,
    createdAt: new Date('2024-01-15'),
    lastAccessed: new Date('2024-03-10'),
    accessCount: 23,
    relatedMembers: ['Sarah'],
    tags: ['food', 'morning', 'coffee'],
    source: 'conversation'
  },
  {
    id: '2',
    type: 'routine',
    content: 'Family dinner every Sunday at 6 PM',
    context: 'Recurring calendar event and meal planning patterns',
    importance: 0.9,
    createdAt: new Date('2024-01-01'),
    lastAccessed: new Date('2024-03-17'),
    accessCount: 45,
    relatedMembers: ['All'],
    tags: ['family', 'dinner', 'weekly'],
    source: 'calendar'
  },
  {
    id: '3',
    type: 'relationship',
    content: 'John and Mike are college roommates, close friends',
    context: 'Mentioned in multiple conversations about social events',
    importance: 0.6,
    createdAt: new Date('2024-02-10'),
    lastAccessed: new Date('2024-03-05'),
    accessCount: 8,
    relatedMembers: ['John', 'Mike'],
    tags: ['friendship', 'social'],
    source: 'conversation'
  },
  {
    id: '4',
    type: 'fact',
    content: 'Home insurance renews on March 15th annually',
    context: 'Extracted from insurance documents',
    importance: 0.85,
    createdAt: new Date('2024-01-20'),
    lastAccessed: new Date('2024-03-01'),
    accessCount: 5,
    relatedMembers: [],
    tags: ['insurance', 'annual', 'financial'],
    source: 'document'
  },
  {
    id: '5',
    type: 'emotion',
    content: 'Sarah feels stressed about work deadlines in Q1',
    context: 'Pattern detected from communication tone analysis',
    importance: 0.75,
    createdAt: new Date('2024-02-28'),
    lastAccessed: new Date('2024-03-15'),
    accessCount: 12,
    relatedMembers: ['Sarah'],
    tags: ['stress', 'work', 'wellbeing'],
    source: 'analysis'
  },
  {
    id: '6',
    type: 'event',
    content: 'Kids school play on April 15th at 7 PM',
    context: 'School newsletter and calendar sync',
    importance: 0.95,
    createdAt: new Date('2024-03-01'),
    lastAccessed: new Date('2024-03-18'),
    accessCount: 15,
    relatedMembers: ['Emma', 'Jake'],
    tags: ['school', 'event', 'kids'],
    source: 'email'
  }
];

const typeIcons = {
  event: Calendar,
  preference: Heart,
  relationship: User,
  routine: Clock,
  fact: FileText,
  emotion: Lightbulb
};

const typeColors = {
  event: 'bg-blue-500/10 text-blue-500',
  preference: 'bg-pink-500/10 text-pink-500',
  relationship: 'bg-green-500/10 text-green-500',
  routine: 'bg-purple-500/10 text-purple-500',
  fact: 'bg-orange-500/10 text-orange-500',
  emotion: 'bg-yellow-500/10 text-yellow-500'
};

export default function MemoryExplorer() {
  const [memories, setMemories] = useState<Memory[]>(sampleMemories);
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('importance');
  const [selectedMemory, setSelectedMemory] = useState<Memory | null>(null);

  const filteredMemories = memories
    .filter(m => {
      const matchesSearch = m.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           m.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesType = typeFilter === 'all' || m.type === typeFilter;
      return matchesSearch && matchesType;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'importance': return b.importance - a.importance;
        case 'recent': return b.lastAccessed.getTime() - a.lastAccessed.getTime();
        case 'accessed': return b.accessCount - a.accessCount;
        default: return 0;
      }
    });

  const handleConsolidate = () => {
    toast.info('Consolidating related memories...');
    setTimeout(() => {
      toast.success('Memory consolidation complete');
    }, 2000);
  };

  const handleCleanup = () => {
    toast.info('Analyzing memories for cleanup...');
    setTimeout(() => {
      const lowImportance = memories.filter(m => m.importance < 0.3);
      toast.success(`Found ${lowImportance.length} memories eligible for cleanup`);
    }, 1500);
  };

  const handleDeleteMemory = (id: string) => {
    setMemories(prev => prev.filter(m => m.id !== id));
    setSelectedMemory(null);
    toast.success('Memory deleted');
  };

  const stats = {
    total: memories.length,
    byType: Object.entries(
      memories.reduce((acc, m) => {
        acc[m.type] = (acc[m.type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    ),
    avgImportance: memories.reduce((sum, m) => sum + m.importance, 0) / memories.length
  };

  return (
    <DashboardLayout>
      <div className="p-4 md:p-6 space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold flex items-center gap-2">
              <Brain className="h-8 w-8" />
              Memory Explorer
            </h1>
            <p className="text-muted-foreground mt-1">
              Browse and manage HAI's household knowledge
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleConsolidate}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Consolidate
            </Button>
            <Button variant="outline" onClick={handleCleanup}>
              <Trash2 className="h-4 w-4 mr-2" />
              Cleanup
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-4">
              <div className="text-2xl font-bold">{stats.total}</div>
              <p className="text-sm text-muted-foreground">Total Memories</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="text-2xl font-bold">{(stats.avgImportance * 100).toFixed(0)}%</div>
              <p className="text-sm text-muted-foreground">Avg Importance</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="text-2xl font-bold">
                {memories.filter(m => m.lastAccessed > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)).length}
              </div>
              <p className="text-sm text-muted-foreground">Active This Week</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4">
              <div className="text-2xl font-bold">
                {new Set(memories.flatMap(m => m.relatedMembers)).size}
              </div>
              <p className="text-sm text-muted-foreground">Members Referenced</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Memory List */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search memories..."
                    className="pl-9"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="w-full sm:w-40">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="event">Events</SelectItem>
                    <SelectItem value="preference">Preferences</SelectItem>
                    <SelectItem value="relationship">Relationships</SelectItem>
                    <SelectItem value="routine">Routines</SelectItem>
                    <SelectItem value="fact">Facts</SelectItem>
                    <SelectItem value="emotion">Emotions</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-full sm:w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="importance">By Importance</SelectItem>
                    <SelectItem value="recent">Recently Accessed</SelectItem>
                    <SelectItem value="accessed">Most Accessed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[500px]">
                <div className="space-y-2">
                  {filteredMemories.map(memory => {
                    const Icon = typeIcons[memory.type];
                    return (
                      <div
                        key={memory.id}
                        className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                          selectedMemory?.id === memory.id 
                            ? 'border-primary bg-accent/50' 
                            : 'hover:bg-accent/30'
                        }`}
                        onClick={() => setSelectedMemory(memory)}
                      >
                        <div className="flex items-start gap-3">
                          <div className={`p-2 rounded-lg ${typeColors[memory.type]}`}>
                            <Icon className="h-4 w-4" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-2">
                              <p className="font-medium truncate">{memory.content}</p>
                              <div className="flex items-center gap-1 shrink-0">
                                <Star className="h-3 w-3 text-yellow-500" />
                                <span className="text-xs">{(memory.importance * 100).toFixed(0)}%</span>
                              </div>
                            </div>
                            <div className="flex flex-wrap gap-1 mt-2">
                              {memory.tags.slice(0, 3).map(tag => (
                                <Badge key={tag} variant="secondary" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                              {memory.relatedMembers.length > 0 && (
                                <Badge variant="outline" className="text-xs">
                                  <User className="h-3 w-3 mr-1" />
                                  {memory.relatedMembers.join(', ')}
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground mt-2">
                              Accessed {memory.accessCount} times · Last: {memory.lastAccessed.toLocaleDateString()}
                            </p>
                          </div>
                          <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Memory Details */}
          <Card>
            <CardHeader>
              <CardTitle>Memory Details</CardTitle>
            </CardHeader>
            <CardContent>
              {selectedMemory ? (
                <div className="space-y-4">
                  <div className={`p-3 rounded-lg ${typeColors[selectedMemory.type]}`}>
                    <div className="flex items-center gap-2">
                      {(() => {
                        const Icon = typeIcons[selectedMemory.type];
                        return <Icon className="h-5 w-5" />;
                      })()}
                      <span className="font-medium capitalize">{selectedMemory.type}</span>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground mb-1">Content</h4>
                    <p className="text-sm">{selectedMemory.content}</p>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground mb-1">Context</h4>
                    <p className="text-sm">{selectedMemory.context}</p>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground mb-1">Source</h4>
                    <Badge variant="outline">{selectedMemory.source}</Badge>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground mb-1">Importance</h4>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-primary"
                          style={{ width: `${selectedMemory.importance * 100}%` }}
                        />
                      </div>
                      <span className="text-sm">{(selectedMemory.importance * 100).toFixed(0)}%</span>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground mb-1">Tags</h4>
                    <div className="flex flex-wrap gap-1">
                      {selectedMemory.tags.map(tag => (
                        <Badge key={tag} variant="secondary">{tag}</Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground mb-1">Related Members</h4>
                    <div className="flex flex-wrap gap-1">
                      {selectedMemory.relatedMembers.length > 0 ? (
                        selectedMemory.relatedMembers.map(member => (
                          <Badge key={member} variant="outline">
                            <User className="h-3 w-3 mr-1" />
                            {member}
                          </Badge>
                        ))
                      ) : (
                        <span className="text-sm text-muted-foreground">No members linked</span>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Created</span>
                      <p>{selectedMemory.createdAt.toLocaleDateString()}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Last Accessed</span>
                      <p>{selectedMemory.lastAccessed.toLocaleDateString()}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Access Count</span>
                      <p>{selectedMemory.accessCount}</p>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-4">
                    <Button 
                      variant="destructive" 
                      size="sm"
                      onClick={() => handleDeleteMemory(selectedMemory.id)}
                    >
                      <Trash2 className="h-4 w-4 mr-1" />
                      Delete
                    </Button>
                    <Button variant="outline" size="sm">
                      <Sparkles className="h-4 w-4 mr-1" />
                      Find Related
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12">
                  <Brain className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">
                    Select a memory to view details
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
