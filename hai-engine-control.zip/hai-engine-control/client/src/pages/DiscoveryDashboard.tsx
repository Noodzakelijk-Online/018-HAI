/**
 * HAI Discovery Dashboard
 * 
 * Shows the progress of HAI's Discovery Phase - scanning and synthesizing
 * all user data to build the Digital DNA.
 */

import { useState, useEffect } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { 
  Brain, 
  Users, 
  Mail, 
  Calendar, 
  FileText, 
  Globe, 
  MessageSquare,
  Shield,
  Clock,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Play,
  Pause,
  RefreshCw,
  Eye,
  Network,
  Target,
  Zap,
  TrendingUp,
  Activity,
} from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

interface DiscoverySource {
  id: string;
  name: string;
  icon: React.ReactNode;
  status: 'pending' | 'scanning' | 'processing' | 'completed' | 'error';
  progress: number;
  itemsFound: number;
  itemsProcessed: number;
  lastUpdate?: string;
  error?: string;
}

interface DigitalDNASummary {
  peopleCount: number;
  relationshipsCount: number;
  commitmentsOpen: number;
  commitmentsOverdue: number;
  projectsActive: number;
  accountsCount: number;
  interestsCount: number;
  valuesCount: number;
  emailsAnalyzed: number;
  messagesAnalyzed: number;
  documentsAnalyzed: number;
  eventsAnalyzed: number;
  confidenceScore: number;
}

interface DiscoveryStatus {
  phase: 'idle' | 'scanning' | 'processing' | 'synthesizing' | 'completed';
  overallProgress: number;
  startedAt?: string;
  estimatedCompletion?: string;
  sources: DiscoverySource[];
  dna?: DigitalDNASummary;
  qualityGates: {
    gate1: boolean; // Communication patterns understood
    gate2: boolean; // Commitments and projects mapped
    gate3: boolean; // Complete model ready
  };
}

export default function DiscoveryDashboard() {
  const { user, isAuthenticated } = useAuth();
  const [status, setStatus] = useState<DiscoveryStatus>({
    phase: 'idle',
    overallProgress: 0,
    sources: [],
    qualityGates: { gate1: false, gate2: false, gate3: false },
  });
  const [isPolling, setIsPolling] = useState(false);

  // Fetch discovery status from backend
  const { data: discoveryData, refetch } = trpc.discovery.getStatus.useQuery(
    undefined,
    { refetchInterval: isPolling ? 2000 : false }
  );
  
  const startMutation = trpc.discovery.start.useMutation({
    onSuccess: () => {
      setIsPolling(true);
      refetch();
      toast.success('Discovery started');
    },
    onError: (err) => toast.error(err.message)
  });
  
  const pauseMutation = trpc.discovery.pause.useMutation({
    onSuccess: () => {
      setIsPolling(false);
      refetch();
      toast.info('Discovery paused');
    }
  });
  
  // Update local status when data changes
  useEffect(() => {
    if (discoveryData) {
      const iconMap: Record<string, React.ReactNode> = {
        email: <Mail className="h-4 w-4" />,
        calendar: <Calendar className="h-4 w-4" />,
        documents: <FileText className="h-4 w-4" />,
        messages: <MessageSquare className="h-4 w-4" />,
        social: <Globe className="h-4 w-4" />,
        financial: <Shield className="h-4 w-4" />,
      };
      
      setStatus({
        phase: discoveryData.phase,
        overallProgress: discoveryData.overallProgress,
        startedAt: discoveryData.startedAt,
        estimatedCompletion: discoveryData.estimatedCompletion,
        sources: discoveryData.sources.map(s => ({
          ...s,
          icon: iconMap[s.id] || <FileText className="h-4 w-4" />
        })),
        dna: discoveryData.dna,
        qualityGates: {
          gate1: discoveryData.qualityGates.gate1,
          gate2: discoveryData.qualityGates.gate2,
          gate3: discoveryData.qualityGates.gate3
        }
      });
      
      if (discoveryData.phase === 'completed') {
        setIsPolling(false);
      }
    }
  }, [discoveryData]);

  const startDiscovery = async () => {
    startMutation.mutate();
  };

  const pauseDiscovery = async () => {
    pauseMutation.mutate();
  };

  const getPhaseLabel = (phase: string) => {
    switch (phase) {
      case 'idle': return 'Ready to Start';
      case 'scanning': return 'Scanning Data Sources';
      case 'processing': return 'Processing Data';
      case 'synthesizing': return 'Building Digital DNA';
      case 'completed': return 'Discovery Complete';
      default: return phase;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-500';
      case 'scanning':
      case 'processing': return 'text-blue-500';
      case 'error': return 'text-red-500';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'scanning':
      case 'processing': return <Loader2 className="h-4 w-4 text-blue-500 animate-spin" />;
      case 'error': return <AlertCircle className="h-4 w-4 text-red-500" />;
      default: return <Clock className="h-4 w-4 text-muted-foreground" />;
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Discovery Phase</h1>
            <p className="text-muted-foreground">
              HAI is learning everything about you to become your digital twin
            </p>
          </div>
          <div className="flex items-center gap-2">
            {status.phase === 'idle' ? (
              <Button onClick={startDiscovery} className="gap-2">
                <Play className="h-4 w-4" />
                Start Discovery
              </Button>
            ) : status.phase === 'completed' ? (
              <Button variant="outline" onClick={startDiscovery} className="gap-2">
                <RefreshCw className="h-4 w-4" />
                Re-scan
              </Button>
            ) : (
              <Button variant="outline" onClick={pauseDiscovery} className="gap-2">
                <Pause className="h-4 w-4" />
                Pause
              </Button>
            )}
          </div>
        </div>

        {/* Overall Progress */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Brain className="h-5 w-5 text-primary" />
                <CardTitle>Discovery Progress</CardTitle>
              </div>
              <Badge variant={status.phase === 'completed' ? 'default' : 'secondary'}>
                {getPhaseLabel(status.phase)}
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Overall Progress</span>
                  <span>{status.overallProgress}%</span>
                </div>
                <Progress value={status.overallProgress} className="h-3" />
              </div>
              
              {status.startedAt && (
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>Started: {new Date(status.startedAt).toLocaleString()}</span>
                  {status.estimatedCompletion && (
                    <span>Est. completion: {status.estimatedCompletion}</span>
                  )}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Quality Gates */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Quality Gates
            </CardTitle>
            <CardDescription>
              Milestones that indicate HAI's understanding level
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-3">
              <div className={`p-4 rounded-lg border ${status.qualityGates.gate1 ? 'border-green-500 bg-green-500/10' : 'border-border'}`}>
                <div className="flex items-center gap-2 mb-2">
                  {status.qualityGates.gate1 ? (
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                  ) : (
                    <Clock className="h-5 w-5 text-muted-foreground" />
                  )}
                  <span className="font-medium">Gate 1</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Communication patterns and key relationships understood
                </p>
                <p className="text-xs text-muted-foreground mt-2">~4-6 hours</p>
              </div>
              
              <div className={`p-4 rounded-lg border ${status.qualityGates.gate2 ? 'border-green-500 bg-green-500/10' : 'border-border'}`}>
                <div className="flex items-center gap-2 mb-2">
                  {status.qualityGates.gate2 ? (
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                  ) : (
                    <Clock className="h-5 w-5 text-muted-foreground" />
                  )}
                  <span className="font-medium">Gate 2</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Commitments and projects fully mapped
                </p>
                <p className="text-xs text-muted-foreground mt-2">~8-12 hours</p>
              </div>
              
              <div className={`p-4 rounded-lg border ${status.qualityGates.gate3 ? 'border-green-500 bg-green-500/10' : 'border-border'}`}>
                <div className="flex items-center gap-2 mb-2">
                  {status.qualityGates.gate3 ? (
                    <CheckCircle2 className="h-5 w-5 text-green-500" />
                  ) : (
                    <Clock className="h-5 w-5 text-muted-foreground" />
                  )}
                  <span className="font-medium">Gate 3</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Complete Digital DNA model ready for review
                </p>
                <p className="text-xs text-muted-foreground mt-2">~18-24 hours</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-6 md:grid-cols-2">
          {/* Data Sources */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Data Sources
              </CardTitle>
              <CardDescription>
                Status of each data source being scanned
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[300px]">
                <div className="space-y-4">
                  {status.sources.map((source) => (
                    <div key={source.id} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {source.icon}
                          <span className="font-medium">{source.name}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {getStatusIcon(source.status)}
                          <span className={`text-sm ${getStatusColor(source.status)}`}>
                            {source.status === 'pending' ? 'Waiting' : 
                             source.status === 'scanning' ? 'Scanning...' :
                             source.status === 'processing' ? 'Processing...' :
                             source.status === 'completed' ? 'Done' : 'Error'}
                          </span>
                        </div>
                      </div>
                      <Progress value={source.progress} className="h-2" />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{source.itemsFound.toLocaleString()} items found</span>
                        <span>{source.itemsProcessed.toLocaleString()} processed</span>
                      </div>
                      {source.error && (
                        <p className="text-xs text-red-500">{source.error}</p>
                      )}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Digital DNA Preview */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                Digital DNA Preview
              </CardTitle>
              <CardDescription>
                What HAI has learned about you so far
              </CardDescription>
            </CardHeader>
            <CardContent>
              {status.dna ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 rounded-lg bg-muted/50">
                      <div className="flex items-center gap-2 mb-1">
                        <Users className="h-4 w-4 text-blue-500" />
                        <span className="text-sm font-medium">People</span>
                      </div>
                      <p className="text-2xl font-bold">{status.dna.peopleCount}</p>
                      <p className="text-xs text-muted-foreground">
                        {status.dna.relationshipsCount} relationships mapped
                      </p>
                    </div>
                    
                    <div className="p-3 rounded-lg bg-muted/50">
                      <div className="flex items-center gap-2 mb-1">
                        <Target className="h-4 w-4 text-orange-500" />
                        <span className="text-sm font-medium">Commitments</span>
                      </div>
                      <p className="text-2xl font-bold">{status.dna.commitmentsOpen}</p>
                      <p className="text-xs text-muted-foreground">
                        {status.dna.commitmentsOverdue} overdue
                      </p>
                    </div>
                    
                    <div className="p-3 rounded-lg bg-muted/50">
                      <div className="flex items-center gap-2 mb-1">
                        <Network className="h-4 w-4 text-purple-500" />
                        <span className="text-sm font-medium">Accounts</span>
                      </div>
                      <p className="text-2xl font-bold">{status.dna.accountsCount}</p>
                      <p className="text-xs text-muted-foreground">
                        Digital services discovered
                      </p>
                    </div>
                    
                    <div className="p-3 rounded-lg bg-muted/50">
                      <div className="flex items-center gap-2 mb-1">
                        <Zap className="h-4 w-4 text-yellow-500" />
                        <span className="text-sm font-medium">Interests</span>
                      </div>
                      <p className="text-2xl font-bold">{status.dna.interestsCount}</p>
                      <p className="text-xs text-muted-foreground">
                        Topics identified
                      </p>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Confidence Score</span>
                      <span className="font-medium">{(status.dna.confidenceScore * 100).toFixed(1)}%</span>
                    </div>
                    <Progress value={status.dna.confidenceScore * 100} className="h-2" />
                    <p className="text-xs text-muted-foreground">
                      Based on {status.dna.emailsAnalyzed.toLocaleString()} emails, {' '}
                      {status.dna.messagesAnalyzed.toLocaleString()} messages, {' '}
                      {status.dna.documentsAnalyzed.toLocaleString()} documents analyzed
                    </p>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-[250px] text-center">
                  <Brain className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">
                    Start the Discovery Phase to begin building your Digital DNA
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Desktop Agent Connection */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Desktop Agent Connection
            </CardTitle>
            <CardDescription>
              HAI Desktop Agent must be installed on your Windows PC
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between p-4 rounded-lg border border-dashed">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-full bg-muted">
                  <AlertCircle className="h-6 w-6 text-muted-foreground" />
                </div>
                <div>
                  <p className="font-medium">Desktop Agent Not Connected</p>
                  <p className="text-sm text-muted-foreground">
                    Download and install the HAI Desktop Agent to enable Discovery Phase
                  </p>
                </div>
              </div>
              <Button variant="outline" className="gap-2">
                <Eye className="h-4 w-4" />
                Download Agent
              </Button>
            </div>
            
            <div className="mt-4 p-4 rounded-lg bg-muted/50">
              <h4 className="font-medium mb-2">What the Desktop Agent does:</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Securely scans your local files, emails, and browser data</li>
                <li>• Detects when you're at the computer (Boss Detection)</li>
                <li>• Enables HAI to operate your computer when you're away</li>
                <li>• All data stays encrypted and under your control</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Activate HAI Button - Only shown when discovery is complete */}
        {status.phase === 'completed' && status.qualityGates.gate3 && (
          <Card className="border-primary">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-bold">Discovery Complete!</h3>
                  <p className="text-muted-foreground">
                    HAI has built your Digital DNA and is ready to start acting on your behalf
                  </p>
                </div>
                <Button size="lg" className="gap-2">
                  <Zap className="h-5 w-5" />
                  Activate Autonomous Mode
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
