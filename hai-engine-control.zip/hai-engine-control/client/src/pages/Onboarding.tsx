import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { CheckCircle2 } from 'lucide-react';

const STEPS = [
  { id: 1, title: 'Welcome to HAI', description: 'Your autonomous AI assistant' },
  { id: 2, title: 'Connect Accounts', description: 'Link Gmail, Calendar, and more' },
  { id: 3, title: 'Set Preferences', description: 'Configure autonomy levels' },
  { id: 4, title: 'Create First Task', description: 'Try HAI with a simple task' },
  { id: 5, title: 'Tour Complete', description: 'You\'re all set!' }
];

export default function Onboarding() {
  const [currentStep, setCurrentStep] = useState(1);
  const progress = (currentStep / STEPS.length) * 100;

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <Progress value={progress} className="mb-4" />
          <CardTitle>{STEPS[currentStep - 1].title}</CardTitle>
          <CardDescription>{STEPS[currentStep - 1].description}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {currentStep === 5 && (
              <div className="text-center py-8">
                <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <p className="text-lg">Welcome to HAI! Let's get started.</p>
              </div>
            )}
            <div className="flex justify-between">
              <Button variant="outline" onClick={() => setCurrentStep(Math.max(1, currentStep - 1))} disabled={currentStep === 1}>
                Previous
              </Button>
              <Button onClick={() => setCurrentStep(Math.min(STEPS.length, currentStep + 1))} disabled={currentStep === STEPS.length}>
                {currentStep === STEPS.length ? 'Get Started' : 'Next'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
