import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Home, Users, Plus, Trash2, UserPlus, Settings, Copy, Link2, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";

/**
 * Household Management Page
 * 
 * Manage household entities, members, and settings.
 * Households are the primary resource container in HAI - all agents,
 * connectors, and resources belong to the household, not individual users.
 */

export default function Household() {
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [inviteDialogOpen, setInviteDialogOpen] = useState(false);
  const [householdName, setHouseholdName] = useState("");
  const [invitedEmail, setInvitedEmail] = useState("");
  const [selectedHouseholdId, setSelectedHouseholdId] = useState<number | null>(null);
  const [invitationLink, setInvitationLink] = useState<string | null>(null);

  // Queries
  const { data: households, isLoading, refetch } = trpc.households.list.useQuery();
  const { data: selectedHousehold } = trpc.households.getById.useQuery(
    { id: selectedHouseholdId! },
    { enabled: selectedHouseholdId !== null }
  );
  const { data: pendingInvitations, refetch: refetchInvitations } = trpc.households.listInvitations.useQuery(
    { householdId: selectedHouseholdId! },
    { enabled: selectedHouseholdId !== null }
  );

  // Mutations
  const createMutation = trpc.households.create.useMutation({
    onSuccess: () => {
      toast.success("Household created successfully!");
      setCreateDialogOpen(false);
      setHouseholdName("");
      refetch();
    },
    onError: (error) => {
      toast.error(`Failed to create household: ${error.message}`);
    },
  });

  const deleteMutation = trpc.households.delete.useMutation({
    onSuccess: () => {
      toast.success("Household deleted successfully!");
      setSelectedHouseholdId(null);
      refetch();
    },
    onError: (error) => {
      toast.error(`Failed to delete household: ${error.message}`);
    },
  });

  const createInvitationMutation = trpc.households.createInvitation.useMutation({
    onSuccess: (data) => {
      const baseUrl = window.location.origin;
      const link = `${baseUrl}/invite/${data.invitation.token}`;
      setInvitationLink(link);
      toast.success("Invitation created! Copy the link to share.");
      setInvitedEmail("");
      refetchInvitations();
    },
    onError: (error) => {
      toast.error(`Failed to create invitation: ${error.message}`);
    },
  });

  const revokeInvitationMutation = trpc.households.revokeInvitation.useMutation({
    onSuccess: () => {
      toast.success("Invitation revoked successfully!");
      refetchInvitations();
    },
    onError: (error) => {
      toast.error(`Failed to revoke invitation: ${error.message}`);
    },
  });

  const handleCreateHousehold = () => {
    if (!householdName.trim()) {
      toast.error("Please enter a household name");
      return;
    }

    createMutation.mutate({
      name: householdName,
    });
  };

  const handleDeleteHousehold = (id: number) => {
    if (confirm("Are you sure you want to delete this household? This will remove all members and cannot be undone.")) {
      deleteMutation.mutate({ id });
    }
  };

  const handleCreateInvitation = () => {
    if (!selectedHouseholdId) {
      toast.error("Please select a household first");
      return;
    }

    createInvitationMutation.mutate({
      householdId: selectedHouseholdId,
      invitedEmail: invitedEmail || undefined,
    });
  };

  const handleCopyInvitationLink = () => {
    if (invitationLink) {
      navigator.clipboard.writeText(invitationLink);
      toast.success("Invitation link copied to clipboard!");
    }
  };

  const handleCloseInviteDialog = () => {
    setInviteDialogOpen(false);
    setInvitationLink(null);
    setInvitedEmail("");
  };

  const handleRevokeInvitation = (invitationId: number) => {
    if (!selectedHouseholdId) return;
    
    if (confirm("Are you sure you want to revoke this invitation? The link will no longer work.")) {
      revokeInvitationMutation.mutate({
        invitationId,
        householdId: selectedHouseholdId,
      });
    }
  };

  const handleCopyInvitationToken = (token: string) => {
    const baseUrl = window.location.origin;
    const link = `${baseUrl}/invite/${token}`;
    navigator.clipboard.writeText(link);
    toast.success("Invitation link copied to clipboard!");
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-muted-foreground">Loading households...</div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <Home className="h-8 w-8" />
              Household Management
            </h1>
            <p className="text-muted-foreground mt-1">
              Manage your household and family members. All resources (agents, connectors) are pooled at the household level.
            </p>
          </div>
          <Button onClick={() => setCreateDialogOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Create Household
          </Button>
        </div>

        {/* Households List */}
        {households && households.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <Home className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Households Yet</h3>
              <p className="text-muted-foreground mb-4">
                Create your first household to start pooling resources and managing your family's digital life.
              </p>
              <Button onClick={() => setCreateDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Create Your First Household
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {households?.map((household) => (
              <Card
                key={household.id}
                className={`cursor-pointer transition-all hover:shadow-md ${
                  selectedHouseholdId === household.id ? "ring-2 ring-primary" : ""
                }`}
                onClick={() => setSelectedHouseholdId(household.id)}
              >
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <Home className="h-5 w-5" />
                      {household.name}
                    </span>
                  </CardTitle>
                  <CardDescription>
                    Created {new Date(household.createdAt).toLocaleDateString()}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Users className="h-4 w-4" />
                      <span>Click to view members</span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteHousehold(household.id);
                      }}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Selected Household Details */}
        {selectedHousehold && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                {selectedHousehold.name} - Members ({selectedHousehold.memberCount})
              </CardTitle>
              <CardDescription>
                Manage household members. All members have equal permissions.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {selectedHousehold.members.map((member) => (
                  <div
                    key={member.id}
                    className="flex items-center justify-between p-3 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <Users className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <div className="font-medium">{member.user.name || "Unknown"}</div>
                        <div className="text-sm text-muted-foreground">
                          {member.user.email || "No email"}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={member.role === "owner" ? "default" : "secondary"}>
                        {member.role}
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        Joined {new Date(member.joinedAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-4 pt-4 border-t">
                <Button variant="outline" onClick={() => setInviteDialogOpen(true)}>
                  <UserPlus className="h-4 w-4 mr-2" />
                  Invite Member
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Pending Invitations Section */}
        {selectedHousehold && pendingInvitations && pendingInvitations.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Link2 className="h-5 w-5" />
                Pending Invitations ({pendingInvitations.length})
              </CardTitle>
              <CardDescription>
                Active invitation links that haven't been accepted yet.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {pendingInvitations.map((invitation) => (
                  <div
                    key={invitation.id}
                    className="flex items-center justify-between p-3 border rounded-lg"
                  >
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-mono text-muted-foreground">
                          {invitation.token.substring(0, 8)}...
                        </span>
                        {invitation.invitedEmail && (
                          <Badge variant="outline">{invitation.invitedEmail}</Badge>
                        )}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Created {new Date(invitation.createdAt).toLocaleDateString()} • 
                        Expires {new Date(invitation.expiresAt).toLocaleDateString()}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleCopyInvitationToken(invitation.token)}
                      >
                        <Copy className="h-4 w-4 mr-1" />
                        Copy Link
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleRevokeInvitation(invitation.id)}
                        disabled={revokeInvitationMutation.isPending}
                      >
                        <X className="h-4 w-4 mr-1" />
                        Revoke
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Create Household Dialog */}
        <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Household</DialogTitle>
              <DialogDescription>
                Create a household to pool resources across family members. You will be the owner.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Household Name</Label>
                <Input
                  id="name"
                  placeholder="e.g., Smith Family, Johnson Household"
                  value={householdName}
                  onChange={(e) => setHouseholdName(e.target.value)}
                />
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
                Cancel
              </Button>
              <Button
                onClick={handleCreateHousehold}
                disabled={createMutation.isPending}
              >
                {createMutation.isPending ? "Creating..." : "Create Household"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Invite Member Dialog */}
        <Dialog open={inviteDialogOpen} onOpenChange={handleCloseInviteDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Invite Member to Household</DialogTitle>
              <DialogDescription>
                Create an invitation link to share with family members. The link will be valid for 7 days.
              </DialogDescription>
            </DialogHeader>

            {!invitationLink ? (
              <>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email (Optional)</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="member@example.com"
                      value={invitedEmail}
                      onChange={(e) => setInvitedEmail(e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">
                      Email is optional. You can share the invitation link directly.
                    </p>
                  </div>
                </div>

                <DialogFooter>
                  <Button variant="outline" onClick={handleCloseInviteDialog}>
                    Cancel
                  </Button>
                  <Button
                    onClick={handleCreateInvitation}
                    disabled={createInvitationMutation.isPending}
                  >
                    {createInvitationMutation.isPending ? "Creating..." : "Create Invitation"}
                  </Button>
                </DialogFooter>
              </>
            ) : (
              <>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label>Invitation Link</Label>
                    <div className="flex gap-2">
                      <Input
                        value={invitationLink}
                        readOnly
                        className="font-mono text-sm"
                      />
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={handleCopyInvitationLink}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Share this link with the person you want to invite. The link will expire in 7 days.
                    </p>
                  </div>
                </div>

                <DialogFooter>
                  <Button onClick={handleCloseInviteDialog}>
                    Done
                  </Button>
                </DialogFooter>
              </>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
