import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Activity, Brain, TrendingUp, Zap } from "lucide-react";

/**
 * Autonomous Framework Dashboard
 * 
 * Displays real-time metrics from the autonomous system:
 * - Decision-making performance
 * - Learning insights
 * - Optimization progress
 */
export default function AutonomousDashboard() {
  const { data: dashboard, isLoading } = trpc.autonomous.getDashboard.useQuery(undefined, {
    refetchInterval: 5000 // Refresh every 5 seconds
  });
  
  if (isLoading || !dashboard) {
    return (
      <div className="container py-8">
        <h1 className="text-3xl font-bold mb-6">Autonomous System</h1>
        <p>Loading autonomous metrics...</p>
      </div>
    );
  }
  
  const { metrics, learning, optimization } = dashboard;
  
  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Autonomous System Dashboard</h1>
        <p className="text-muted-foreground">
          Real-time metrics from the self-improving AI framework
        </p>
      </div>
      
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {(metrics.overallSuccessRate * 100).toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground">
              {metrics.improvementRate > 0 ? '+' : ''}
              {metrics.improvementRate.toFixed(1)}% from last period
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Decision Time</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {metrics.avgDecisionTime.toFixed(1)}s
            </div>
            <p className="text-xs text-muted-foreground">
              Average time per decision
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Cost</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${metrics.avgCost.toFixed(3)}
            </div>
            <p className="text-xs text-muted-foreground">
              Per decision
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Strategies</CardTitle>
            <Brain className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {metrics.strategiesCount}
            </div>
            <p className="text-xs text-muted-foreground">
              A/B testing in progress
            </p>
          </CardContent>
        </Card>
      </div>
      
      {/* Learning Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>Learning Pipeline</CardTitle>
            <CardDescription>
              Continuous learning from all system events
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Total Events Processed</span>
                <span className="text-2xl font-bold">{learning.totalEvents.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Patterns Detected</span>
                <span className="text-2xl font-bold">{learning.patternsDetected}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Actionable Patterns</span>
                <span className="text-2xl font-bold text-green-600">{learning.actionablePatterns}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Learning Rate</span>
                <span className="text-2xl font-bold">{(learning.learningRate * 100).toFixed(0)}%</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Auto-Optimization</CardTitle>
            <CardDescription>
              Multi-dimensional performance optimization
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Overall Progress</span>
                <span className="text-2xl font-bold">
                  {(optimization.overallProgress * 100).toFixed(1)}%
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Optimization Targets</span>
                <span className="text-2xl font-bold">{optimization.targets.length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Recent Actions</span>
                <span className="text-2xl font-bold">{optimization.recentActions.length}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Optimization Targets */}
      <Card>
        <CardHeader>
          <CardTitle>Optimization Targets</CardTitle>
          <CardDescription>
            Current optimization goals and progress
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {optimization.targets.map((target) => {
              const progress = 1 - Math.abs(target.currentValue - target.targetValue) / target.targetValue;
              const progressPercent = Math.max(0, Math.min(100, progress * 100));
              
              return (
                <div key={target.id} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">{target.name}</span>
                    <span className="text-sm text-muted-foreground">
                      {target.currentValue.toFixed(3)} {target.unit} → {target.targetValue.toFixed(3)} {target.unit}
                    </span>
                  </div>
                  <div className="w-full bg-secondary rounded-full h-2">
                    <div 
                      className="bg-primary h-2 rounded-full transition-all"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
      
      {/* System Info */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>System Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <p className="text-muted-foreground">Total Decisions</p>
              <p className="text-lg font-semibold">{metrics.decisionsCount.toLocaleString()}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Framework Status</p>
              <p className="text-lg font-semibold text-green-600">Active</p>
            </div>
            <div>
              <p className="text-muted-foreground">Last Updated</p>
              <p className="text-lg font-semibold">
                {new Date(dashboard.timestamp).toLocaleTimeString()}
              </p>
            </div>
            <div>
              <p className="text-muted-foreground">Mode</p>
              <p className="text-lg font-semibold">Fully Autonomous</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
