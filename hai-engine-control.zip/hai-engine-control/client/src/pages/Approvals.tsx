import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { CheckCircle2, XCircle, Clock, AlertTriangle, Eye, FileText, Calendar, User } from "lucide-react";
import { toast } from "sonner";

export default function Approvals() {
  const [selectedTask, setSelectedTask] = useState<any>(null);
  const [showApproveDialog, setShowApproveDialog] = useState(false);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [reasoning, setReasoning] = useState("");

  const { data: pendingTasks, isLoading, refetch } = trpc.tasks.list.useQuery({
    status: "pending_approval",
  });

  const approveTask = trpc.tasks.approve.useMutation({
    onSuccess: () => {
      toast.success("Task approved successfully");
      setShowApproveDialog(false);
      setSelectedTask(null);
      setReasoning("");
      refetch();
    },
    onError: (error) => {
      toast.error(`Failed to approve task: ${error.message}`);
    },
  });

  const rejectTask = trpc.tasks.reject.useMutation({
    onSuccess: () => {
      toast.success("Task rejected");
      setShowRejectDialog(false);
      setSelectedTask(null);
      setReasoning("");
      refetch();
    },
    onError: (error) => {
      toast.error(`Failed to reject task: ${error.message}`);
    },
  });

  const handleApprove = () => {
    if (!selectedTask) return;
    approveTask.mutate({ taskId: selectedTask.id });
  };

  const handleReject = () => {
    if (!selectedTask) return;
    if (!reasoning.trim()) {
      toast.error("Please provide a reason for rejection");
      return;
    }
    rejectTask.mutate({ taskId: selectedTask.id });
  };

  const getTaskTypeIcon = (taskType: string) => {
    switch (taskType) {
      case "email":
        return <FileText className="h-4 w-4" />;
      case "calendar":
        return <Calendar className="h-4 w-4" />;
      case "finance":
        return <AlertTriangle className="h-4 w-4" />;
      default:
        return <FileText className="h-4 w-4" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent":
        return "destructive";
      case "high":
        return "default";
      case "medium":
        return "secondary";
      case "low":
        return "outline";
      default:
        return "secondary";
    }
  };

  const getAutonomyLevelColor = (level: number) => {
    if (level === 0) return "outline";
    if (level === 1) return "secondary";
    if (level === 2) return "default";
    return "destructive";
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Approval Queue</h1>
          <p className="text-muted-foreground mt-2">
            Review and approve tasks before execution
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Approval</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{pendingTasks?.length || 0}</div>
              <p className="text-xs text-muted-foreground">
                Tasks awaiting your review
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">High Priority</CardTitle>
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {pendingTasks?.filter(t => t.priority === "high" || t.priority === "urgent").length || 0}
              </div>
              <p className="text-xs text-muted-foreground">
                Urgent tasks requiring attention
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Level 2+ Tasks</CardTitle>
              <User className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {pendingTasks?.filter(t => t.autonomyLevel >= 2).length || 0}
              </div>
              <p className="text-xs text-muted-foreground">
                Tasks requiring higher autonomy
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Pending Tasks List */}
        <Card>
          <CardHeader>
            <CardTitle>Tasks Pending Approval</CardTitle>
            <CardDescription>
              Review task details and approve or reject execution
            </CardDescription>
          </CardHeader>
          <CardContent>
            {!pendingTasks || pendingTasks.length === 0 ? (
              <div className="text-center py-12">
                <CheckCircle2 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-lg font-medium">No tasks pending approval</p>
                <p className="text-sm text-muted-foreground mt-2">
                  All tasks have been reviewed
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {pendingTasks.map((task) => (
                  <Card key={task.id} className="border-l-4 border-l-yellow-500">
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1 space-y-3">
                          <div className="flex items-center gap-3">
                            {getTaskTypeIcon(task.taskType)}
                            <h3 className="font-semibold text-lg">{task.title}</h3>
                            <Badge variant={getPriorityColor(task.priority)}>
                              {task.priority}
                            </Badge>
                            <Badge variant={getAutonomyLevelColor(task.autonomyLevel)}>
                              Level {task.autonomyLevel}
                            </Badge>
                          </div>

                          {task.description && (
                            <p className="text-sm text-muted-foreground">
                              {task.description}
                            </p>
                          )}

                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              {new Date(task.createdAt).toLocaleDateString()}
                            </span>
                            {task.assignedEngine && (
                              <span className="flex items-center gap-1">
                                <FileText className="h-3 w-3" />
                                {task.assignedEngine}
                              </span>
                            )}
                          </div>

                          {task.autonomyLevel >= 2 && (
                            <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-md p-3">
                              <p className="text-sm text-yellow-600 dark:text-yellow-400">
                                ⚠️ This task requires Level {task.autonomyLevel} autonomy. Review carefully before approving.
                              </p>
                            </div>
                          )}
                        </div>

                        <div className="flex gap-2 ml-4">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setSelectedTask(task);
                              // Preview dialog could be added here
                            }}
                          >
                            <Eye className="h-4 w-4 mr-2" />
                            Preview
                          </Button>
                          <Button
                            variant="default"
                            size="sm"
                            onClick={() => {
                              setSelectedTask(task);
                              setShowApproveDialog(true);
                            }}
                          >
                            <CheckCircle2 className="h-4 w-4 mr-2" />
                            Approve
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => {
                              setSelectedTask(task);
                              setShowRejectDialog(true);
                            }}
                          >
                            <XCircle className="h-4 w-4 mr-2" />
                            Reject
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Approve Dialog */}
      <Dialog open={showApproveDialog} onOpenChange={setShowApproveDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Approve Task</DialogTitle>
            <DialogDescription>
              Are you sure you want to approve this task for execution?
            </DialogDescription>
          </DialogHeader>
          {selectedTask && (
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold">{selectedTask.title}</h4>
                <p className="text-sm text-muted-foreground mt-1">
                  {selectedTask.description}
                </p>
              </div>
              <div className="bg-muted p-3 rounded-md">
                <p className="text-sm">
                  <strong>Task Type:</strong> {selectedTask.taskType}
                </p>
                <p className="text-sm">
                  <strong>Priority:</strong> {selectedTask.priority}
                </p>
                <p className="text-sm">
                  <strong>Autonomy Level:</strong> {selectedTask.autonomyLevel}
                </p>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowApproveDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleApprove} disabled={approveTask.isPending}>
              {approveTask.isPending ? "Approving..." : "Approve Task"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Task</DialogTitle>
            <DialogDescription>
              Please provide a reason for rejecting this task.
            </DialogDescription>
          </DialogHeader>
          {selectedTask && (
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold">{selectedTask.title}</h4>
                <p className="text-sm text-muted-foreground mt-1">
                  {selectedTask.description}
                </p>
              </div>
              <div>
                <label className="text-sm font-medium">Reason for Rejection</label>
                <Textarea
                  placeholder="Explain why this task should not be executed..."
                  value={reasoning}
                  onChange={(e) => setReasoning(e.target.value)}
                  className="mt-2"
                  rows={4}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRejectDialog(false)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleReject}
              disabled={rejectTask.isPending || !reasoning.trim()}
            >
              {rejectTask.isPending ? "Rejecting..." : "Reject Task"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
