import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { Link2, Plus, Trash2, Edit, Upload, GripVertical, ExternalLink, Bell, BellOff, Link, Unlink } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { HealthStatusBadge } from "@/components/HealthStatusBadge";
import { ServiceTemplateSelector } from "@/components/ServiceTemplateSelector";
import { TagManager } from "@/components/TagManager";
import type { ServiceTemplate } from "@shared/serviceTemplates";
import { getConnectorTypeInfo, getConnectorStatusColor, isOAuthConnector } from "@shared/connectorTypes";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import React, { useState, useRef } from "react";
import { toast } from "sonner";
import { EmailComposerDialog, type EmailData } from "@/components/EmailComposerDialog";
import { EventComposerDialog, type EventData } from "@/components/EventComposerDialog";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

interface ServiceCardProps {
  service: {
    id: number;
    name: string;
    url: string | null;
    imageUrl: string | null;
    status: string;
    connectorType: string;
    errorMessage?: string | null;
  };
  onEdit: (service: any) => void;
  onDelete: (id: number) => void;
  onNavigate: (url: string) => void;
  onOAuthConnect?: (id: number) => void;
  onOAuthDisconnect?: (id: number) => void;
  onSendEmail?: (id: number) => void;
  onCreateEvent?: (id: number) => void;
}

function ServiceTags({ serviceId }: { serviceId: number }) {
  const { data: tags = [] } = trpc.tags.getServiceTags.useQuery({ serviceId });

  if (tags.length === 0) return null;

  return (
    <div className="flex flex-wrap gap-1 mb-2">
      {tags.map((tag) => (
        <Badge
          key={tag.id}
          variant="secondary"
          className="text-xs"
          style={{ backgroundColor: tag.color + "20", borderColor: tag.color, color: tag.color }}
        >
          {tag.name}
        </Badge>
      ))}
    </div>
  );
}

function SortableServiceCard({ service, onEdit, onDelete, onNavigate, onOAuthConnect, onOAuthDisconnect, onSendEmail, onCreateEvent }: ServiceCardProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: service.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "connected":
        return "bg-green-500";
      case "disconnected":
        return "bg-gray-500";
      case "error":
        return "bg-red-500";
      default:
        return "bg-gray-500";
    }
  };

  return (
    <div ref={setNodeRef} style={style} className="group">
      <Card className="hover:shadow-lg transition-shadow">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3 flex-1">
              <div
                {...attributes}
                {...listeners}
                className="cursor-grab active:cursor-grabbing text-muted-foreground hover:text-foreground"
              >
                <GripVertical className="h-5 w-5" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <CardTitle className="text-lg">{service.name}</CardTitle>
                  {(() => {
                    const typeInfo = getConnectorTypeInfo(service.connectorType);
                    return (
                      <Badge variant="outline" className="text-xs">
                        {typeInfo.icon} {typeInfo.displayName}
                      </Badge>
                    );
                  })()}
                  <Badge className={getConnectorStatusColor(service.status)}>
                    {service.status.replace('_', ' ')}
                  </Badge>
                  <HealthStatusBadge serviceId={service.id} hasUrl={!!service.url} />
                  {service.status === 'error' && service.errorMessage && (
                    <Badge variant="destructive" className="text-xs max-w-[200px] truncate" title={service.errorMessage}>
                      {service.errorMessage}
                    </Badge>
                  )}
                </div>
                <CardDescription className="mt-1">
                  {service.url || "No URL configured"}
                </CardDescription>
              </div>
            </div>
            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              {/* Show OAuth Connect/Disconnect for OAuth connectors */}
              {service.connectorType !== 'custom' && (
                service.status === 'pending_auth' || service.status === 'error' ? (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onOAuthConnect?.(service.id)}
                  >
                    <Link className="h-4 w-4 mr-1" />
                    Connect
                  </Button>
                ) : service.status === 'connected' ? (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onOAuthDisconnect?.(service.id)}
                  >
                    <Unlink className="h-4 w-4 mr-1" />
                    Disconnect
                  </Button>
                ) : null
              )}
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onEdit(service)}
              >
                <Edit className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onDelete(service.id)}
              >
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ServiceTags serviceId={service.id} />
          <div className="flex items-center justify-between mt-3">
            {service.imageUrl && (
              <img
                src={service.imageUrl}
                alt={service.name}
                className="h-12 w-12 object-contain rounded"
              />
            )}
            <div className="flex items-center gap-2 ml-auto">
              {/* Action buttons for connected OAuth services */}
              {service.connectorType === 'gmail' && service.status === 'connected' && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onSendEmail?.(service.id)}
                >
                  Send Email
                </Button>
              )}
              {service.connectorType === 'calendar' && service.status === 'connected' && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onCreateEvent?.(service.id)}
                >
                  Create Event
                </Button>
              )}
              {service.url && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onNavigate(service.url!)}
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Open
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function Connectors() {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [newService, setNewService] = useState({ name: "", url: "", imageUrl: "" });
  const [editingService, setEditingService] = useState<any>(null);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [selectedTagIds, setSelectedTagIds] = useState<number[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [emailDialogOpen, setEmailDialogOpen] = useState(false);
  const [selectedEmailConnector, setSelectedEmailConnector] = useState<number | null>(null);
  const [eventDialogOpen, setEventDialogOpen] = useState(false);
  const [selectedEventConnector, setSelectedEventConnector] = useState<number | null>(null);
  const [selectedHouseholdId, setSelectedHouseholdId] = useState<number | null>(null);

  // Fetch user's households
  const { data: households } = trpc.households.list.useQuery();
  
  // Auto-select first household
  React.useEffect(() => {
    if (households && households.length > 0 && !selectedHouseholdId) {
      setSelectedHouseholdId(households[0].id);
    }
  }, [households, selectedHouseholdId]);

  const utils = trpc.useUtils();
  const { data: services = [], isLoading } = trpc.connectors.list.useQuery(
    { householdId: selectedHouseholdId! },
    { enabled: !!selectedHouseholdId }
  );
  const { data: allTags = [] } = trpc.tags.list.useQuery();

  // OAuth mutations
  const initiateOAuth = trpc.connectors.initiateOAuth.useMutation();
  const completeOAuth = trpc.connectors.completeOAuth.useMutation();
  const disconnectOAuth = trpc.connectors.disconnectOAuth.useMutation();
  
  // Action mutations
  const sendEmailMutation = trpc.connectors.sendEmail.useMutation({
    onSuccess: () => {
      toast.success("Test email sent successfully!");
    },
    onError: (error) => {
      toast.error(`Failed to send email: ${error.message}`);
    },
  });

  const createEventMutation = trpc.connectors.createCalendarEvent.useMutation({
    onSuccess: () => {
      toast.success("Test event created successfully!");
    },
    onError: (error) => {
      toast.error(`Failed to create event: ${error.message}`);
    },
  });

  // Filter services based on selected tags
  // Note: Tag filtering is handled by ServiceTags component per service
  const filteredServices = React.useMemo(() => {
    // For now, just return all services
    // TODO: Implement server-side tag filtering via tRPC endpoint
    return services;
  }, [services]);

  const createMutation = trpc.connectors.create.useMutation({
    onSuccess: () => {
      toast.success("Service added successfully");
      utils.connectors.list.invalidate();
      setIsAddDialogOpen(false);
      resetForm();
    },
    onError: (error) => {
      toast.error(`Failed to add service: ${error.message}`);
    },
  });

  const updateMutation = trpc.connectors.update.useMutation({
    onSuccess: () => {
      toast.success("Service updated successfully");
      utils.connectors.list.invalidate();
      setIsEditDialogOpen(false);
      setEditingService(null);
    },
    onError: (error) => {
      toast.error(`Failed to update service: ${error.message}`);
    },
  });

  const deleteMutation = trpc.connectors.delete.useMutation({
    onSuccess: () => {
      toast.success("Service deleted successfully");
      utils.connectors.list.invalidate();
    },
    onError: (error) => {
      toast.error(`Failed to delete service: ${error.message}`);
    },
  });

  const updateOrderMutation = trpc.connectors.updateOrder.useMutation({
    onError: (error) => {
      toast.error(`Failed to update order: ${error.message}`);
      utils.connectors.list.invalidate(); // Revert on error
    },
  });

  const uploadImageMutation = trpc.connectors.uploadImage.useMutation({
    onSuccess: (data) => {
      toast.success("Image uploaded successfully");
      if (editingService) {
        setEditingService({ ...editingService, imageUrl: data.url });
      } else {
        setNewService({ ...newService, imageUrl: data.url });
      }
      setUploadingImage(false);
    },
    onError: (error) => {
      toast.error(`Failed to upload image: ${error.message}`);
      setUploadingImage(false);
    },
  });

  // OAuth handler functions
  const handleOAuthConnect = async (connectorId: number) => {
    try {
      const result = await initiateOAuth.mutateAsync({ connectorId });
      
      // Simulate OAuth flow (in real implementation, this would redirect to OAuth provider)
      toast.info("Simulating OAuth flow...");
      
      // Auto-complete OAuth with mock code after 2 seconds
      setTimeout(async () => {
        try {
          await completeOAuth.mutateAsync({
            connectorId,
            code: `mock_code_${Date.now()}`,
            state: result.state,
          });
          toast.success("OAuth connection successful!");
          utils.connectors.list.invalidate();
        } catch (error: any) {
          toast.error(`OAuth failed: ${error.message}`);
        }
      }, 2000);
    } catch (error: any) {
      toast.error(`Failed to initiate OAuth: ${error.message}`);
    }
  };

  const handleOAuthDisconnect = async (connectorId: number) => {
    try {
      await disconnectOAuth.mutateAsync({ connectorId });
      toast.success("Connector disconnected");
      utils.connectors.list.invalidate();
    } catch (error: any) {
      toast.error(`Failed to disconnect: ${error.message}`);
    }
  };

  const handleSendEmail = async (connectorId: number) => {
    setSelectedEmailConnector(connectorId);
    setEmailDialogOpen(true);
  };

  const handleEmailSend = async (emailData: EmailData) => {
    if (!selectedEmailConnector) return;
    
    await sendEmailMutation.mutateAsync({
      connectorId: selectedEmailConnector,
      ...emailData,
    });
  };

  const handleCreateEvent = async (connectorId: number) => {
    setSelectedEventConnector(connectorId);
    setEventDialogOpen(true);
  };

  const handleEventCreate = async (eventData: EventData) => {
    if (!selectedEventConnector) return;
    
    await createEventMutation.mutateAsync({
      connectorId: selectedEventConnector,
      ...eventData,
    });
  };

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const resetForm = () => {
    setNewService({
      name: "",
      url: "",
      imageUrl: "",
    });
  };

  const handleCreate = () => {
    if (!newService.name || !newService.url) {
      toast.error("Please fill in name and URL");
      return;
    }
    
    if (!selectedHouseholdId) {
      toast.error("Please select a household first");
      return;
    }

    createMutation.mutate({
      name: newService.name,
      connectorType: "custom",
      householdId: selectedHouseholdId,
      url: newService.url,
      imageUrl: newService.imageUrl || undefined,
      status: "connected",
    });
  };

  const handleUpdate = () => {
    if (!editingService) return;

    updateMutation.mutate({
      id: editingService.id,
      name: editingService.name,
      url: editingService.url,
      imageUrl: editingService.imageUrl || undefined,
      alertsEnabled: editingService.alertsEnabled || false,
      uptimeThreshold: editingService.uptimeThreshold || 99,
    });
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this service?")) {
      deleteMutation.mutate({ id });
    }
  };

  const handleEdit = (service: any) => {
    setEditingService(service);
    setIsEditDialogOpen(true);
  };

  const handleNavigate = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const oldIndex = services.findIndex((s) => s.id === active.id);
      const newIndex = services.findIndex((s) => s.id === over.id);

      const newOrder = arrayMove(services, oldIndex, newIndex);
      const orderedIds = newOrder.map(s => s.id);

      // Optimistic update
      utils.connectors.list.setData({ householdId: selectedHouseholdId! }, newOrder);

      // Persist to backend
      updateOrderMutation.mutate({ orderedIds });
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, serviceId?: number) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast.error("Please select an image file");
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error("Image must be smaller than 5MB");
      return;
    }

    setUploadingImage(true);

    // Convert to base64
    const reader = new FileReader();
    reader.onload = () => {
      const base64 = reader.result as string;
      const base64Data = base64.split(',')[1]; // Remove data:image/...;base64, prefix

      uploadImageMutation.mutate({
        connectorId: serviceId || editingService?.id || 0,
        imageData: base64Data,
        mimeType: file.type,
      });
    };
    reader.onerror = () => {
      toast.error("Failed to read image file");
      setUploadingImage(false);
    };
    reader.readAsDataURL(file);
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <h1 className="text-3xl font-bold tracking-tight">ServiceHub</h1>
            <p className="text-muted-foreground mt-2">
              Manage your services with drag-and-drop ordering
            </p>
          </div>
          <div className="flex flex-col items-end gap-2">
            {/* Household Selector */}
            {households && households.length > 0 && (
              <div className="flex items-center gap-2">
                <Label className="text-sm text-muted-foreground">Household:</Label>
                <Select
                  value={selectedHouseholdId?.toString()}
                  onValueChange={(value) => setSelectedHouseholdId(parseInt(value))}
                >
                  <SelectTrigger className="w-[200px]">
                    <SelectValue placeholder="Select household" />
                  </SelectTrigger>
                  <SelectContent>
                    {households.map((household) => (
                      <SelectItem key={household.id} value={household.id.toString()}>
                        {household.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            {allTags.length > 0 && (
              <div className="flex items-center gap-2">
                <Label className="text-sm text-muted-foreground">Filter by tags:</Label>
                <div className="flex flex-wrap gap-1">
                  {allTags.map((tag) => (
                    <Badge
                      key={tag.id}
                      variant={selectedTagIds.includes(tag.id) ? "default" : "outline"}
                      className="cursor-pointer"
                      style={
                        selectedTagIds.includes(tag.id)
                          ? { backgroundColor: tag.color, borderColor: tag.color }
                          : { borderColor: tag.color, color: tag.color }
                      }
                      onClick={() => {
                        setSelectedTagIds((prev) =>
                          prev.includes(tag.id)
                            ? prev.filter((id) => id !== tag.id)
                            : [...prev, tag.id]
                        );
                      }}
                    >
                      {tag.name}
                    </Badge>
                  ))}
                  {selectedTagIds.length > 0 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 px-2 text-xs"
                      onClick={() => setSelectedTagIds([])}
                    >
                      Clear
                    </Button>
                  )}
                </div>
              </div>
            )}
            {selectedTagIds.length > 0 && (
              <p className="text-xs text-muted-foreground">
                Showing {filteredServices.length} of {services.length} services
              </p>
            )}
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Service
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px] max-h-[90vh]">
              <DialogHeader>
                <DialogTitle>Add New Service</DialogTitle>
                <DialogDescription>
                  Choose from templates or create a custom service
                </DialogDescription>
              </DialogHeader>
              <Tabs defaultValue="templates" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="templates">Templates</TabsTrigger>
                  <TabsTrigger value="custom">Custom</TabsTrigger>
                </TabsList>
                <TabsContent value="templates" className="mt-4">
                  <ServiceTemplateSelector
                    onSelect={(template: ServiceTemplate) => {
                      setNewService({
                        name: template.name,
                        url: template.url,
                        imageUrl: "",
                      });
                      // Switch to custom tab to allow editing
                      const customTab = document.querySelector('[value="custom"]') as HTMLButtonElement;
                      customTab?.click();
                      toast.success(`Template "${template.name}" loaded. Customize as needed.`);
                    }}
                  />
                </TabsContent>
                <TabsContent value="custom" className="mt-4">
              <div className="grid gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="name">Service Name</Label>
                  <Input
                    id="name"
                    placeholder="My Service"
                    value={newService.name}
                    onChange={(e) =>
                      setNewService({ ...newService, name: e.target.value })
                    }
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="url">Service URL</Label>
                  <Input
                    id="url"
                    type="url"
                    placeholder="https://example.com"
                    value={newService.url}
                    onChange={(e) =>
                      setNewService({ ...newService, url: e.target.value })
                    }
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="image">Custom Image (optional)</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      id="image"
                      type="file"
                      accept="image/*"

                      onChange={(e) => handleImageUpload(e)}
                      disabled={uploadingImage}
                    />
                    {newService.imageUrl && (
                      <img
                        src={newService.imageUrl}
                        alt="Preview"
                        className="h-10 w-10 object-contain rounded border"
                      />
                    )}
                  </div>
                  {uploadingImage && (
                    <p className="text-sm text-muted-foreground">Uploading...</p>
                  )}
                </div>
              </div>
                </TabsContent>
              </Tabs>
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsAddDialogOpen(false);
                    resetForm();
                  }}
                >
                  Cancel
                </Button>
                <Button onClick={handleCreate} disabled={createMutation.isPending}>
                  {createMutation.isPending ? "Adding..." : "Add Service"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Statistics */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Total Services</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{services.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Active</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {services.filter(s => s.status === 'connected').length}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">With Custom Images</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">
                {services.filter(s => s.imageUrl).length}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Services Grid with Drag-and-Drop */}
        {isLoading ? (
          <div className="text-center py-12 text-muted-foreground">
            Loading services...
          </div>
        ) : services.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <Link2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No services yet</h3>
              <p className="text-muted-foreground mb-4">
                Add your first service to get started
              </p>
              <Button onClick={() => setIsAddDialogOpen(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Add Service
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            <DndContext
              sensors={sensors}
              collisionDetection={closestCenter}
              onDragEnd={handleDragEnd}
            >
              <SortableContext
                items={filteredServices.map(s => s.id)}
                strategy={verticalListSortingStrategy}
              >
                {filteredServices.map((service) => (
                  <SortableServiceCard
                    key={service.id}
                    service={service}
                    onEdit={handleEdit}
                    onDelete={handleDelete}
                    onNavigate={handleNavigate}
                    onOAuthConnect={handleOAuthConnect}
                    onOAuthDisconnect={handleOAuthDisconnect}
                    onSendEmail={handleSendEmail}
                    onCreateEvent={handleCreateEvent}
                  />
                ))}
              </SortableContext>
            </DndContext>
          </div>
        )}

        {/* Edit Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Edit Service</DialogTitle>
              <DialogDescription>
                Update service details
              </DialogDescription>
            </DialogHeader>
            {editingService && (
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="edit-name">Service Name</Label>
                  <Input
                    id="edit-name"
                    value={editingService.name}
                    onChange={(e) =>
                      setEditingService({ ...editingService, name: e.target.value })
                    }
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="edit-url">Service URL</Label>
                  <Input
                    id="edit-url"
                    type="url"
                    value={editingService.url || ""}
                    onChange={(e) =>
                      setEditingService({ ...editingService, url: e.target.value })
                    }
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="edit-image">Custom Image</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      id="edit-image"
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleImageUpload(e, editingService.id)}
                      disabled={uploadingImage}
                    />
                    {editingService.imageUrl && (
                      <img
                        src={editingService.imageUrl}
                        alt="Preview"
                        className="h-10 w-10 object-contain rounded border"
                      />
                    )}
                  </div>
                  {uploadingImage && (
                    <p className="text-sm text-muted-foreground">Uploading...</p>
                  )}
                </div>
                <div className="border rounded-lg p-4">
                  <TagManager
                    serviceId={editingService.id}
                    onTagsChange={() => {
                      // Refresh service list to show updated tags
                      utils.connectors.list.invalidate();
                    }}
                  />
                </div>
                <div className="grid gap-4 p-4 border rounded-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {editingService.alertsEnabled ? (
                        <Bell className="h-4 w-4 text-primary" />
                      ) : (
                        <BellOff className="h-4 w-4 text-muted-foreground" />
                      )}
                      <div>
                        <Label htmlFor="alerts-enabled">Downtime Alerts</Label>
                        <p className="text-xs text-muted-foreground">
                          Get notified when uptime drops below threshold
                        </p>
                      </div>
                    </div>
                    <Switch
                      id="alerts-enabled"
                      checked={editingService.alertsEnabled || false}
                      onCheckedChange={(checked) =>
                        setEditingService({ ...editingService, alertsEnabled: checked })
                      }
                    />
                  </div>
                  {editingService.alertsEnabled && (
                    <div className="grid gap-2">
                      <Label htmlFor="uptime-threshold">Uptime Threshold (%)</Label>
                      <Input
                        id="uptime-threshold"
                        type="number"
                        min="0"
                        max="100"
                        value={editingService.uptimeThreshold || 99}
                        onChange={(e) =>
                          setEditingService({
                            ...editingService,
                            uptimeThreshold: parseInt(e.target.value) || 99,
                          })
                        }
                      />
                      <p className="text-xs text-muted-foreground">
                        Alert when uptime drops below this percentage (default: 99%)
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => {
                  setIsEditDialogOpen(false);
                  setEditingService(null);
                }}
              >
                Cancel
              </Button>
              <Button onClick={handleUpdate} disabled={updateMutation.isPending}>
                {updateMutation.isPending ? "Updating..." : "Update Service"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Email Composer Dialog */}
        <EmailComposerDialog
          open={emailDialogOpen}
          onOpenChange={setEmailDialogOpen}
          onSend={handleEmailSend}
          connectorName={services.find(s => s.id === selectedEmailConnector)?.name || "Gmail"}
        />

        {/* Event Composer Dialog */}
        <EventComposerDialog
          open={eventDialogOpen}
          onOpenChange={setEventDialogOpen}
          onSend={handleEventCreate}
          connectorName={services.find(s => s.id === selectedEventConnector)?.name || "Calendar"}
        />
      </div>
    </DashboardLayout>
  );
}
