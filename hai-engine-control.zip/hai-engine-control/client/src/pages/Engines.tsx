import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Play, Pause, RefreshCw, AlertTriangle, CheckCircle2, Clock, RotateCw, TrendingUp } from "lucide-react";
import { toast } from "sonner";
import { useState } from "react";
import EngineMetricsChart from "@/components/EngineMetricsChart";

export default function Engines() {
  const { data: engines, isLoading, refetch } = trpc.engines.list.useQuery();
  const [confirmDialog, setConfirmDialog] = useState<{ open: boolean; engineId: string; action: string; engineName: string }>({
    open: false,
    engineId: "",
    action: "",
    engineName: "",
  });
  const [selectedEngine, setSelectedEngine] = useState<string | null>(null);

  const updateStatus = trpc.engines.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("Engine status updated");
      refetch();
      setConfirmDialog({ open: false, engineId: "", action: "", engineName: "" });
    },
    onError: (error) => {
      toast.error(`Failed to update engine: ${error.message}`);
    },
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "running":
        return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case "stopped":
        return <Pause className="h-5 w-5 text-gray-500" />;
      case "error":
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case "initializing":
        return <Clock className="h-5 w-5 text-yellow-500" />;
      default:
        return null;
    }
  };

  const handleEngineAction = (engineId: string, action: string, engineName: string) => {
    setConfirmDialog({ open: true, engineId, action, engineName });
  };

  const confirmAction = () => {
    const { engineId, action } = confirmDialog;
    let newStatus: "running" | "stopped" | "error" | "initializing";
    
    switch (action) {
      case "start":
        newStatus = "running";
        break;
      case "stop":
        newStatus = "stopped";
        break;
      case "restart":
        newStatus = "initializing";
        // After a brief moment, set to running
        setTimeout(() => {
          updateStatus.mutate({ engineId, status: "running" });
        }, 2000);
        break;
      default:
        return;
    }
    
    updateStatus.mutate({ engineId, status: newStatus });
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Engine Management</h1>
            <p className="text-muted-foreground mt-2">
              Control and monitor all HAI engines with real-time metrics
            </p>
          </div>
          <Button onClick={() => refetch()} variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>

        {/* Metrics Chart for Selected Engine */}
        {selectedEngine && (
          <EngineMetricsChart 
            engineId={selectedEngine} 
            engineName={engines?.find(e => e.engineId === selectedEngine)?.name || ""}
          />
        )}

        <div className="grid gap-4">
          {engines?.map((engine) => (
            <Card key={engine.id} className="hover:border-primary/50 transition-colors">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(engine.status)}
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        {engine.name}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setSelectedEngine(
                            selectedEngine === engine.engineId ? null : engine.engineId
                          )}
                        >
                          <TrendingUp className="h-4 w-4" />
                        </Button>
                      </CardTitle>
                      <CardDescription>{engine.description}</CardDescription>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={engine.priority === "critical" ? "destructive" : "default"}>
                      {engine.priority}
                    </Badge>
                    <Badge variant="outline">Level {engine.autonomyLevel}</Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="text-sm">
                      <span className="text-muted-foreground">Status:</span>{" "}
                      <span className="font-medium capitalize">{engine.status}</span>
                    </div>
                    {engine.dependencies && Array.isArray(engine.dependencies) && engine.dependencies.length > 0 && (
                      <div className="text-sm">
                        <span className="text-muted-foreground">Dependencies:</span>{" "}
                        <span className="font-medium">{engine.dependencies.join(", ")}</span>
                      </div>
                    )}
                    {engine.lastHealthCheck && (
                      <div className="text-sm text-muted-foreground">
                        Last check: {new Date(engine.lastHealthCheck).toLocaleString()}
                      </div>
                    )}
                    {engine.errorMessage && (
                      <div className="text-sm text-red-500">
                        Error: {engine.errorMessage}
                      </div>
                    )}
                  </div>
                  <div className="flex gap-2">
                    {engine.status === "running" ? (
                      <>
                        <Button
                          onClick={() => handleEngineAction(engine.engineId, "restart", engine.name)}
                          variant="outline"
                          size="sm"
                          disabled={updateStatus.isPending}
                        >
                          <RotateCw className="h-4 w-4 mr-2" />
                          Restart
                        </Button>
                        <Button
                          onClick={() => handleEngineAction(engine.engineId, "stop", engine.name)}
                          variant="destructive"
                          size="sm"
                          disabled={updateStatus.isPending}
                        >
                          <Pause className="h-4 w-4 mr-2" />
                          Stop
                        </Button>
                      </>
                    ) : (
                      <Button
                        onClick={() => handleEngineAction(engine.engineId, "start", engine.name)}
                        variant="default"
                        size="sm"
                        disabled={updateStatus.isPending || engine.status === "initializing"}
                      >
                        <Play className="h-4 w-4 mr-2" />
                        Start
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Confirmation Dialog */}
        <Dialog open={confirmDialog.open} onOpenChange={(open) => setConfirmDialog({ ...confirmDialog, open })}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirm Engine Action</DialogTitle>
              <DialogDescription>
                Are you sure you want to {confirmDialog.action} the <strong>{confirmDialog.engineName}</strong>?
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setConfirmDialog({ open: false, engineId: "", action: "", engineName: "" })}
              >
                Cancel
              </Button>
              <Button onClick={confirmAction} disabled={updateStatus.isPending}>
                Confirm
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  );
}
