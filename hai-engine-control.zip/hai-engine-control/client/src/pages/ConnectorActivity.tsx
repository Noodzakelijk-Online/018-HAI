import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Activity, CheckCircle2, XCircle, Clock, TrendingUp, AlertTriangle, BarChart3, LineChart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function ConnectorActivity() {
  const { data: households } = trpc.households.list.useQuery();
  const selectedHouseholdId = households?.[0]?.id;
  const { data: connectors = [], isLoading: connectorsLoading } = trpc.connectors.list.useQuery(
    { householdId: selectedHouseholdId! },
    { enabled: !!selectedHouseholdId }
  );
  const { data: healthStats, isLoading: healthLoading } = trpc.connectors.getHealthStatistics.useQuery();
  const { data: analyticsData } = trpc.connectors.getAllAnalytics.useQuery({ days: 30 });
  const checkAllHealth = trpc.connectors.checkAllConnectorsHealth.useMutation({
    onSuccess: () => {
      toast.success("Health check completed for all connectors");
      utils.connectors.getHealthStatistics.invalidate();
      utils.connectors.list.invalidate();
    },
    onError: (error) => {
      toast.error(`Health check failed: ${error.message}`);
    },
  });

  const utils = trpc.useUtils();

  const isLoading = connectorsLoading || healthLoading;

  // Calculate statistics
  const totalConnectors = connectors.length;
  const connectedCount = connectors.filter(c => c.status === 'connected').length;
  const oauthConnectors = connectors.filter(c => ['gmail', 'calendar'].includes(c.connectorType));
  const customConnectors = connectors.filter(c => c.connectorType === 'custom');

  // Group connectors by type
  const connectorsByType = connectors.reduce((acc, connector) => {
    const type = connector.connectorType;
    if (!acc[type]) {
      acc[type] = [];
    }
    acc[type].push(connector);
    return acc;
  }, {} as Record<string, typeof connectors>);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Connector Activity</h1>
          <p className="text-muted-foreground mt-2">
            Monitor connector health, usage statistics, and performance
          </p>
        </div>

        {/* Health Statistics */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Connectors</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{healthStats?.total || 0}</div>
              <p className="text-xs text-muted-foreground">
                {connectedCount} connected
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Healthy</CardTitle>
              <CheckCircle2 className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{healthStats?.healthy || 0}</div>
              <p className="text-xs text-muted-foreground">
                Tokens valid
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Expired</CardTitle>
              <Clock className="h-4 w-4 text-yellow-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-600">{healthStats?.expired || 0}</div>
              <p className="text-xs text-muted-foreground">
                Need reconnection
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Errors</CardTitle>
              <XCircle className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{healthStats?.error || 0}</div>
              <p className="text-xs text-muted-foreground">
                Failed connectors
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending</CardTitle>
              <AlertTriangle className="h-4 w-4 text-orange-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">{healthStats?.pending || 0}</div>
              <p className="text-xs text-muted-foreground">
                Awaiting auth
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Analytics Overview */}
        {analyticsData && analyticsData.totalCalls > 0 && (
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              <h2 className="text-2xl font-bold">Usage Analytics (Last 30 Days)</h2>
            </div>

            <div className="grid gap-4 md:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total API Calls</CardTitle>
                  <Activity className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{analyticsData.totalCalls.toLocaleString()}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Successful</CardTitle>
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{analyticsData.successfulCalls.toLocaleString()}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {analyticsData.successRate.toFixed(1)}% success rate
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Failed</CardTitle>
                  <XCircle className="h-4 w-4 text-red-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-600">{analyticsData.failedCalls.toLocaleString()}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {((analyticsData.failedCalls / analyticsData.totalCalls) * 100).toFixed(1)}% failure rate
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Connectors</CardTitle>
                  <TrendingUp className="h-4 w-4 text-blue-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{Object.keys(analyticsData.connectorStats).length}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    With API activity
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Top Performing Connectors */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LineChart className="h-5 w-5" />
                  Top Performing Connectors
                </CardTitle>
                <CardDescription>
                  Connectors ranked by total API calls
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(analyticsData.connectorStats)
                    .sort(([, a], [, b]) => b.total - a.total)
                    .slice(0, 5)
                    .map(([connectorId, stats]) => {
                      const connector = connectors?.find(c => c.id === parseInt(connectorId));
                      const successRate = (stats.success / stats.total) * 100;
                      
                      return (
                        <div key={connectorId} className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="flex flex-col">
                              <span className="font-medium">{connector?.name || `Connector #${connectorId}`}</span>
                              <span className="text-sm text-muted-foreground">
                                {stats.total} calls · {successRate.toFixed(1)}% success
                              </span>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant={successRate >= 95 ? "default" : successRate >= 80 ? "secondary" : "destructive"}>
                              {stats.success} / {stats.total}
                            </Badge>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Health Check Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Health Monitoring</CardTitle>
            <CardDescription>
              Automatic health checks run every hour. You can also trigger a manual check.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={() => checkAllHealth.mutate()}
              disabled={checkAllHealth.isPending}
            >
              {checkAllHealth.isPending ? "Checking..." : "Run Health Check Now"}
            </Button>
          </CardContent>
        </Card>

        {/* Connectors by Type */}
        <Card>
          <CardHeader>
            <CardTitle>Connectors by Type</CardTitle>
            <CardDescription>
              Distribution of connectors across different types
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(connectorsByType).map(([type, typeConnectors]) => (
                <div key={type} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Badge variant="outline" className="capitalize">
                      {type}
                    </Badge>
                    <span className="text-sm text-muted-foreground">
                      {typeConnectors.length} connector{typeConnectors.length !== 1 ? 's' : ''}
                    </span>
                  </div>
                  <div className="flex gap-2">
                    {typeConnectors.map(connector => (
                      <Badge
                        key={connector.id}
                        variant={connector.status === 'connected' ? 'default' : 'secondary'}
                        className="text-xs"
                      >
                        {connector.name}
                      </Badge>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* OAuth Connectors Status */}
        <Card>
          <CardHeader>
            <CardTitle>OAuth Connectors</CardTitle>
            <CardDescription>
              Status of connectors requiring OAuth authentication
            </CardDescription>
          </CardHeader>
          <CardContent>
            {oauthConnectors.length === 0 ? (
              <p className="text-sm text-muted-foreground">No OAuth connectors configured</p>
            ) : (
              <div className="space-y-3">
                {oauthConnectors.map((connector) => (
                  <div key={connector.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div>
                        <p className="font-medium">{connector.name}</p>
                        <p className="text-sm text-muted-foreground capitalize">{connector.connectorType}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge
                        variant={connector.status === 'connected' ? 'default' : 'secondary'}
                      >
                        {connector.status.replace('_', ' ')}
                      </Badge>
                      {connector.lastSync && (
                        <span className="text-xs text-muted-foreground">
                          Last sync: {new Date(connector.lastSync).toLocaleString()}
                        </span>
                      )}
                      {connector.errorMessage && (
                        <Badge variant="destructive" className="text-xs">
                          {connector.errorMessage.substring(0, 30)}
                        </Badge>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Custom Services */}
        <Card>
          <CardHeader>
            <CardTitle>Custom Services</CardTitle>
            <CardDescription>
              Non-OAuth services and custom integrations
            </CardDescription>
          </CardHeader>
          <CardContent>
            {customConnectors.length === 0 ? (
              <p className="text-sm text-muted-foreground">No custom services configured</p>
            ) : (
              <div className="space-y-3">
                {customConnectors.map((connector) => (
                  <div key={connector.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      {connector.imageUrl && (
                        <img
                          src={connector.imageUrl}
                          alt={connector.name}
                          className="h-8 w-8 object-contain rounded"
                        />
                      )}
                      <div>
                        <p className="font-medium">{connector.name}</p>
                        {connector.url && (
                          <p className="text-sm text-muted-foreground">{connector.url}</p>
                        )}
                      </div>
                    </div>
                    <Badge variant="outline">{connector.status}</Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Usage Tips */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Usage Tips
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm text-muted-foreground">
            <p>• Health checks run automatically every hour to detect expired tokens</p>
            <p>• Expired tokens are automatically refreshed when possible</p>
            <p>• You'll receive notifications when connectors need reconnection</p>
            <p>• Use the "Run Health Check Now" button to manually verify all connectors</p>
            <p>• Check the Connectors page to reconnect any expired OAuth services</p>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
