import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Activity,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Clock,
  Cpu,
  HardDrive,
  Monitor,
  Smartphone,
  Link2,
  Brain,
  Eye,
  Zap,
  RefreshCw
} from "lucide-react";
import { toast } from "sonner";

export default function SystemHealth() {
  const [selectedHouseholdId, setSelectedHouseholdId] = useState<number | null>(null);

  // Fetch user's households
  const { data: households } = trpc.households.list.useQuery();
  
  // Auto-select first household
  useEffect(() => {
    if (households && households.length > 0 && !selectedHouseholdId) {
      setSelectedHouseholdId(households[0].id);
    }
  }, [households, selectedHouseholdId]);

  // Fetch all health data
  const { data: connectors, isLoading: connectorsLoading, refetch: refetchConnectors } = trpc.connectors.list.useQuery(
    { householdId: selectedHouseholdId! },
    { enabled: !!selectedHouseholdId, refetchInterval: 10000 }
  );

  const { data: agents, isLoading: agentsLoading } = trpc.agents.list.useQuery(
    { householdId: selectedHouseholdId! },
    { enabled: !!selectedHouseholdId, refetchInterval: 5000 }
  );

  const { data: thinkingStatus } = trpc.thinking.getStatus.useQuery(undefined, {
    refetchInterval: 5000,
  });

  const { data: pendingDecisions } = trpc.thinking.getPendingDecisions.useQuery(undefined, {
    refetchInterval: 5000,
  });

  // Calculate connector health stats
  const healthyConnectors = connectors?.filter(c => c.status === "active") || [];
  const expiredConnectors = connectors?.filter(c => c.status === "expired") || [];
  const errorConnectors = connectors?.filter(c => c.status === "error") || [];
  const pendingConnectors = connectors?.filter(c => c.status === "pending") || [];

  // Calculate agent stats
  const onlineAgents = agents?.filter(a => a.status === "online") || [];
  const offlineAgents = agents?.filter(a => a.status === "offline") || [];

  const runHealthCheck = () => {
    toast.promise(
      Promise.all([refetchConnectors()]),
      {
        loading: "Running health check...",
        success: "Health check completed",
        error: "Health check failed",
      }
    );
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">System Health</h1>
            <p className="text-muted-foreground mt-2">
              Monitor HAI's connectors, agents, and cognitive services
            </p>
          </div>
          <Button onClick={runHealthCheck} variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            Run Health Check
          </Button>
        </div>

        {/* Overview Stats */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Connectors</CardTitle>
              <Link2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{connectors?.length || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {healthyConnectors.length} healthy
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Agents</CardTitle>
              <Cpu className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{agents?.length || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {onlineAgents.length} online
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Thinking Engine</CardTitle>
              <Brain className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {thinkingStatus?.isActive ? "Active" : "Idle"}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {pendingDecisions?.length || 0} pending decisions
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Issues</CardTitle>
              <AlertTriangle className="h-4 w-4 text-destructive" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-destructive">
                {errorConnectors.length + expiredConnectors.length}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Requires attention
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Tabs */}
        <Tabs defaultValue="connectors" className="space-y-4">
          <TabsList>
            <TabsTrigger value="connectors">
              <Link2 className="h-4 w-4 mr-2" />
              Connectors
            </TabsTrigger>
            <TabsTrigger value="agents">
              <Cpu className="h-4 w-4 mr-2" />
              Agents
            </TabsTrigger>
            <TabsTrigger value="thinking">
              <Brain className="h-4 w-4 mr-2" />
              Thinking Engine
            </TabsTrigger>
            <TabsTrigger value="services">
              <Activity className="h-4 w-4 mr-2" />
              Background Services
            </TabsTrigger>
          </TabsList>

          {/* Connectors Tab */}
          <TabsContent value="connectors" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Healthy</CardTitle>
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-500">
                    {healthyConnectors.length}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Tokens valid</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Expired</CardTitle>
                  <Clock className="h-4 w-4 text-orange-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-orange-500">
                    {expiredConnectors.length}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Need reconnection</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Errors</CardTitle>
                  <XCircle className="h-4 w-4 text-destructive" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-destructive">
                    {errorConnectors.length}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Failed connectors</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Pending</CardTitle>
                  <AlertTriangle className="h-4 w-4 text-yellow-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-yellow-500">
                    {pendingConnectors.length}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Awaiting auth</p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Connected Services</CardTitle>
                <CardDescription>External services integrated with HAI</CardDescription>
              </CardHeader>
              <CardContent>
                {connectorsLoading ? (
                  <div className="space-y-3">
                    {[1, 2, 3].map((i) => (
                      <Skeleton key={i} className="h-16 w-full" />
                    ))}
                  </div>
                ) : connectors && connectors.length > 0 ? (
                  <div className="space-y-3">
                    {connectors.map((connector) => (
                      <div
                        key={connector.id}
                        className="flex items-center justify-between p-4 border rounded-lg"
                      >
                        <div className="flex items-center gap-3">
                          <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                            connector.status === "active" ? "bg-green-500/10" : "bg-muted"
                          }`}>
                            <Link2 className={`h-5 w-5 ${
                              connector.status === "active" ? "text-green-500" : "text-muted-foreground"
                            }`} />
                          </div>
                          <div>
                            <h4 className="font-semibold">{connector.name}</h4>
                            <p className="text-sm text-muted-foreground">{connector.type}</p>
                          </div>
                        </div>
                        <Badge variant={
                          connector.status === "active" ? "default" :
                          connector.status === "expired" ? "secondary" :
                          connector.status === "error" ? "destructive" : "outline"
                        }>
                          {connector.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground py-8">
                    No connectors configured
                  </p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Agents Tab */}
          <TabsContent value="agents" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-3">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Agents</CardTitle>
                  <Cpu className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{agents?.length || 0}</div>
                  <p className="text-xs text-muted-foreground mt-1">Registered devices</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Online</CardTitle>
                  <Zap className="h-4 w-4 text-green-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-500">
                    {onlineAgents.length}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Active now</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Offline</CardTitle>
                  <XCircle className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{offlineAgents.length}</div>
                  <p className="text-xs text-muted-foreground mt-1">Disconnected</p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Agent Fleet</CardTitle>
                <CardDescription>Devices running HAI Desktop Agent</CardDescription>
              </CardHeader>
              <CardContent>
                {agentsLoading ? (
                  <div className="space-y-3">
                    {[1, 2].map((i) => (
                      <Skeleton key={i} className="h-20 w-full" />
                    ))}
                  </div>
                ) : agents && agents.length > 0 ? (
                  <div className="space-y-3">
                    {agents.map((agent) => (
                      <div
                        key={agent.id}
                        className="flex items-center gap-4 p-4 border rounded-lg"
                      >
                        <div className={`h-12 w-12 rounded-full flex items-center justify-center ${
                          agent.status === "online" ? "bg-green-500/10" : "bg-muted"
                        }`}>
                          {agent.type === "mobile" ? (
                            <Smartphone className={`h-6 w-6 ${
                              agent.status === "online" ? "text-green-500" : "text-muted-foreground"
                            }`} />
                          ) : (
                            <Monitor className={`h-6 w-6 ${
                              agent.status === "online" ? "text-green-500" : "text-muted-foreground"
                            }`} />
                          )}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h4 className="font-semibold">{agent.name}</h4>
                            <Badge variant={agent.status === "online" ? "default" : "secondary"}>
                              {agent.status}
                            </Badge>
                            <Badge variant="outline">{agent.type}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">
                            Last seen: {agent.lastSeen ? new Date(agent.lastSeen).toLocaleString() : "Never"}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground py-8">
                    No agents detected. Start the Desktop Agent to register automatically.
                  </p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Thinking Engine Tab */}
          <TabsContent value="thinking" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Cognitive Status</CardTitle>
                <CardDescription>HAI's thinking and decision-making state</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Brain className="h-8 w-8 text-primary" />
                    <div>
                      <h4 className="font-semibold">Thinking Engine</h4>
                      <p className="text-sm text-muted-foreground">
                        {thinkingStatus?.isActive ? "Processing context" : "Idle"}
                      </p>
                    </div>
                  </div>
                  <Badge variant={thinkingStatus?.isActive ? "default" : "secondary"}>
                    {thinkingStatus?.isActive ? "Active" : "Idle"}
                  </Badge>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="p-4 border rounded-lg">
                    <h5 className="font-medium mb-2">Pending Decisions</h5>
                    <p className="text-3xl font-bold">{pendingDecisions?.length || 0}</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Awaiting user input
                    </p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h5 className="font-medium mb-2">Active Observations</h5>
                    <p className="text-3xl font-bold">
                      {thinkingStatus?.observations?.length || 0}
                    </p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Current context items
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Background Services Tab */}
          <TabsContent value="services" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Background Services</CardTitle>
                <CardDescription>Always-on HAI services running in the background</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Eye className="h-6 w-6 text-primary" />
                    <div>
                      <h4 className="font-semibold">Screen Monitoring</h4>
                      <p className="text-sm text-muted-foreground">
                        Real-time PC and phone screen capture
                      </p>
                    </div>
                  </div>
                  <Badge variant={onlineAgents.length > 0 ? "default" : "secondary"}>
                    {onlineAgents.length > 0 ? "Active" : "Offline"}
                  </Badge>
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Activity className="h-6 w-6 text-primary" />
                    <div>
                      <h4 className="font-semibold">OCR Processing</h4>
                      <p className="text-sm text-muted-foreground">
                        Text extraction from screen captures
                      </p>
                    </div>
                  </div>
                  <Badge variant={onlineAgents.length > 0 ? "default" : "secondary"}>
                    {onlineAgents.length > 0 ? "Active" : "Offline"}
                  </Badge>
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Brain className="h-6 w-6 text-primary" />
                    <div>
                      <h4 className="font-semibold">Context Awareness</h4>
                      <p className="text-sm text-muted-foreground">
                        Continuous context building from all sources
                      </p>
                    </div>
                  </div>
                  <Badge variant={thinkingStatus?.isActive ? "default" : "secondary"}>
                    {thinkingStatus?.isActive ? "Active" : "Idle"}
                  </Badge>
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="h-6 w-6 text-primary" />
                    <div>
                      <h4 className="font-semibold">Decision Queue</h4>
                      <p className="text-sm text-muted-foreground">
                        WhatsApp escalation for low-confidence decisions
                      </p>
                    </div>
                  </div>
                  <Badge variant={pendingDecisions && pendingDecisions.length > 0 ? "default" : "secondary"}>
                    {pendingDecisions && pendingDecisions.length > 0 ? `${pendingDecisions.length} pending` : "Empty"}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
