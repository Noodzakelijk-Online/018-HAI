/**
 * Screen Viewer Page
 * 
 * Unified view for real-time PC and smartphone screen monitoring
 * with interactive control capabilities.
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { trpc } from '@/lib/trpc';
import { 
  Monitor, 
  Smartphone, 
  Play, 
  Pause, 
  Camera, 
  Video, 
  VideoOff,
  MousePointer,
  Keyboard,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Home,
  RotateCcw,
  Maximize2,
  Minimize2,
  Settings,
  Wifi,
  WifiOff,
  Battery,
  RefreshCw,
  Send
} from 'lucide-react';
import { io, Socket } from 'socket.io-client';

interface ScreenFrame {
  device: 'pc' | 'phone';
  frame: string;
  metadata: {
    timestamp: number;
    frame_number: number;
    width: number;
    height: number;
    size_bytes: number;
    current_fps?: number;
    activity_level?: number;
  };
}

interface StreamStatus {
  pc: { connected: boolean };
  phone: { connected: boolean };
  viewers: { pc: number; phone: number };
}

export default function ScreenViewer() {
  // State
  const [activeTab, setActiveTab] = useState<'pc' | 'phone' | 'both'>('both');
  const [pcFrame, setPcFrame] = useState<string | null>(null);
  const [phoneFrame, setPhoneFrame] = useState<string | null>(null);
  const [pcMetadata, setPcMetadata] = useState<ScreenFrame['metadata'] | null>(null);
  const [phoneMetadata, setPhoneMetadata] = useState<ScreenFrame['metadata'] | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [controlMode, setControlMode] = useState(false);
  const [textInput, setTextInput] = useState('');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  
  // Refs
  const socketRef = useRef<Socket | null>(null);
  const pcCanvasRef = useRef<HTMLCanvasElement>(null);
  const phoneCanvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  // tRPC queries
  const { data: streamStatus, refetch: refetchStatus } = trpc.screenStream.getStatus.useQuery(
    undefined,
    { refetchInterval: 5000 }
  );
  
  // tRPC mutations for control
  const pcClick = trpc.screenStream.pcControl.click.useMutation();
  const pcType = trpc.screenStream.pcControl.type.useMutation();
  const pcPressKey = trpc.screenStream.pcControl.pressKey.useMutation();
  const pcScroll = trpc.screenStream.pcControl.scroll.useMutation();
  const pcScreenshot = trpc.screenStream.pcControl.screenshot.useMutation();
  
  const phoneTap = trpc.screenStream.phoneControl.tap.useMutation();
  const phoneSwipe = trpc.screenStream.phoneControl.swipeDirection.useMutation();
  const phoneType = trpc.screenStream.phoneControl.type.useMutation();
  const phonePressButton = trpc.screenStream.phoneControl.pressButton.useMutation();
  const phoneScreenshot = trpc.screenStream.phoneControl.screenshot.useMutation();
  
  // Connect to WebSocket
  useEffect(() => {
    const wsUrl = window.location.origin.replace('http', 'ws');
    const socket = io(wsUrl, {
      path: '/screen-stream',
      transports: ['websocket']
    });
    
    socketRef.current = socket;
    
    socket.on('connect', () => {
      console.log('[ScreenViewer] Connected to stream server');
      setIsConnected(true);
      
      // Subscribe to both streams
      socket.emit('subscribe_stream', { device: 'pc' });
      socket.emit('subscribe_stream', { device: 'phone' });
    });
    
    socket.on('disconnect', () => {
      console.log('[ScreenViewer] Disconnected from stream server');
      setIsConnected(false);
    });
    
    socket.on('screen_frame', (data: ScreenFrame) => {
      if (data.device === 'pc') {
        setPcFrame(data.frame);
        setPcMetadata(data.metadata);
      } else if (data.device === 'phone') {
        setPhoneFrame(data.frame);
        setPhoneMetadata(data.metadata);
      }
    });
    
    socket.on('stream_status', (status: StreamStatus) => {
      console.log('[ScreenViewer] Stream status:', status);
    });
    
    socket.on('stream_available', (data: { device: string }) => {
      toast.success(`${data.device.toUpperCase()} stream available`);
      refetchStatus();
    });
    
    socket.on('stream_ended', (data: { device: string }) => {
      toast.info(`${data.device.toUpperCase()} stream ended`);
      if (data.device === 'pc') {
        setPcFrame(null);
        setPcMetadata(null);
      } else {
        setPhoneFrame(null);
        setPhoneMetadata(null);
      }
      refetchStatus();
    });
    
    return () => {
      socket.disconnect();
    };
  }, [refetchStatus]);
  
  // Handle PC canvas click for control
  const handlePcCanvasClick = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!controlMode || !pcCanvasRef.current || !pcMetadata) return;
    
    const rect = pcCanvasRef.current.getBoundingClientRect();
    const scaleX = pcMetadata.width / rect.width;
    const scaleY = pcMetadata.height / rect.height;
    
    const x = Math.round((e.clientX - rect.left) * scaleX);
    const y = Math.round((e.clientY - rect.top) * scaleY);
    
    pcClick.mutate({ x, y });
    toast.info(`Clicked at (${x}, ${y})`);
  }, [controlMode, pcMetadata, pcClick]);
  
  // Handle phone canvas click for control
  const handlePhoneCanvasClick = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!controlMode || !phoneCanvasRef.current || !phoneMetadata) return;
    
    const rect = phoneCanvasRef.current.getBoundingClientRect();
    const scaleX = phoneMetadata.width / rect.width;
    const scaleY = phoneMetadata.height / rect.height;
    
    const x = Math.round((e.clientX - rect.left) * scaleX);
    const y = Math.round((e.clientY - rect.top) * scaleY);
    
    phoneTap.mutate({ x, y });
    toast.info(`Tapped at (${x}, ${y})`);
  }, [controlMode, phoneMetadata, phoneTap]);
  
  // Send text input
  const handleSendText = (device: 'pc' | 'phone') => {
    if (!textInput.trim()) return;
    
    if (device === 'pc') {
      pcType.mutate({ text: textInput });
    } else {
      phoneType.mutate({ text: textInput });
    }
    
    toast.success(`Sent text to ${device.toUpperCase()}`);
    setTextInput('');
  };
  
  // Toggle fullscreen
  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };
  
  // Render screen display
  const renderScreenDisplay = (
    device: 'pc' | 'phone',
    frame: string | null,
    metadata: ScreenFrame['metadata'] | null,
    canvasRef: React.RefObject<HTMLCanvasElement>,
    onClick: (e: React.MouseEvent<HTMLCanvasElement>) => void
  ) => {
    const isConnectedDevice = device === 'pc' ? streamStatus?.pc.connected : streamStatus?.phone.connected;
    
    return (
      <Card className="h-full flex flex-col">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {device === 'pc' ? <Monitor className="h-5 w-5" /> : <Smartphone className="h-5 w-5" />}
              <CardTitle className="text-lg">{device === 'pc' ? 'PC Screen' : 'Phone Screen'}</CardTitle>
              <Badge variant={isConnectedDevice ? 'default' : 'secondary'}>
                {isConnectedDevice ? 'Live' : 'Offline'}
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              {metadata && (
                <span className="text-xs text-muted-foreground">
                  {metadata.width}x{metadata.height} @ {metadata.current_fps || 0} fps
                </span>
              )}
              <Button
                variant="ghost"
                size="icon"
                onClick={() => device === 'pc' ? pcScreenshot.mutate() : phoneScreenshot.mutate()}
              >
                <Camera className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="flex-1 flex items-center justify-center p-2">
          {frame ? (
            <div className="relative w-full h-full flex items-center justify-center">
              <img
                src={`data:image/webp;base64,${frame}`}
                alt={`${device} screen`}
                className={`max-w-full max-h-full object-contain rounded-lg ${
                  controlMode ? 'cursor-crosshair' : 'cursor-default'
                }`}
                onClick={onClick as unknown as React.MouseEventHandler<HTMLImageElement>}
              />
              {controlMode && (
                <div className="absolute top-2 left-2 bg-red-500 text-white text-xs px-2 py-1 rounded">
                  Control Mode Active
                </div>
              )}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center text-muted-foreground gap-4 p-8">
              {device === 'pc' ? (
                <Monitor className="h-16 w-16 opacity-30" />
              ) : (
                <Smartphone className="h-16 w-16 opacity-30" />
              )}
              <p className="text-center">
                {isConnectedDevice 
                  ? 'Waiting for frames...'
                  : `No ${device === 'pc' ? 'Desktop Agent' : 'phone'} connected`
                }
              </p>
              <p className="text-xs text-center max-w-xs">
                {device === 'pc' 
                  ? 'Start the Desktop Agent on your Windows PC to begin streaming'
                  : 'Connect your Android phone via USB or WiFi to begin streaming'
                }
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    );
  };
  
  // Render control panel
  const renderControlPanel = (device: 'pc' | 'phone') => (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm flex items-center gap-2">
          <Settings className="h-4 w-4" />
          {device === 'pc' ? 'PC Controls' : 'Phone Controls'}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Control Mode Toggle */}
        <div className="flex items-center justify-between">
          <Label htmlFor={`control-${device}`} className="text-sm">
            Interactive Control
          </Label>
          <Switch
            id={`control-${device}`}
            checked={controlMode}
            onCheckedChange={setControlMode}
          />
        </div>
        
        {/* Text Input */}
        <div className="flex gap-2">
          <Input
            placeholder="Type text..."
            value={textInput}
            onChange={(e) => setTextInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendText(device)}
          />
          <Button size="icon" onClick={() => handleSendText(device)}>
            <Send className="h-4 w-4" />
          </Button>
        </div>
        
        {/* Device-specific controls */}
        {device === 'pc' ? (
          <div className="grid grid-cols-4 gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => pcScroll.mutate({ direction: 'up' })}
            >
              <ArrowUp className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => pcScroll.mutate({ direction: 'down' })}
            >
              <ArrowDown className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => pcPressKey.mutate({ key: 'escape' })}
            >
              Esc
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => pcPressKey.mutate({ key: 'enter' })}
            >
              Enter
            </Button>
          </div>
        ) : (
          <div className="space-y-2">
            {/* Navigation buttons */}
            <div className="grid grid-cols-3 gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => phonePressButton.mutate({ button: 'back' })}
              >
                <RotateCcw className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => phonePressButton.mutate({ button: 'home' })}
              >
                <Home className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => phonePressButton.mutate({ button: 'recent' })}
              >
                <Maximize2 className="h-4 w-4" />
              </Button>
            </div>
            
            {/* Swipe controls */}
            <div className="grid grid-cols-4 gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => phoneSwipe.mutate({ direction: 'up' })}
              >
                <ArrowUp className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => phoneSwipe.mutate({ direction: 'down' })}
              >
                <ArrowDown className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => phoneSwipe.mutate({ direction: 'left' })}
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => phoneSwipe.mutate({ direction: 'right' })}
              >
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
  
  return (
    <DashboardLayout>
      <div ref={containerRef} className="h-full flex flex-col gap-4 p-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Monitor className="h-6 w-6" />
              Screen Viewer
            </h1>
            <p className="text-muted-foreground">
              Real-time view of your PC and smartphone screens
            </p>
          </div>
          
          <div className="flex items-center gap-2">
            <Badge variant={isConnected ? 'default' : 'destructive'}>
              {isConnected ? (
                <><Wifi className="h-3 w-3 mr-1" /> Connected</>
              ) : (
                <><WifiOff className="h-3 w-3 mr-1" /> Disconnected</>
              )}
            </Badge>
            
            <Button variant="outline" size="icon" onClick={() => refetchStatus()}>
              <RefreshCw className="h-4 w-4" />
            </Button>
            
            <Button variant="outline" size="icon" onClick={toggleFullscreen}>
              {isFullscreen ? (
                <Minimize2 className="h-4 w-4" />
              ) : (
                <Maximize2 className="h-4 w-4" />
              )}
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowControls(!showControls)}
            >
              {showControls ? 'Hide Controls' : 'Show Controls'}
            </Button>
          </div>
        </div>
        
        {/* View Tabs */}
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as typeof activeTab)}>
          <TabsList>
            <TabsTrigger value="both" className="flex items-center gap-1">
              <Monitor className="h-4 w-4" />
              <Smartphone className="h-4 w-4" />
              Both
            </TabsTrigger>
            <TabsTrigger value="pc" className="flex items-center gap-1">
              <Monitor className="h-4 w-4" />
              PC Only
            </TabsTrigger>
            <TabsTrigger value="phone" className="flex items-center gap-1">
              <Smartphone className="h-4 w-4" />
              Phone Only
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="both" className="flex-1 mt-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-[calc(100vh-280px)]">
              {/* PC Screen */}
              <div className="flex flex-col gap-4">
                {renderScreenDisplay('pc', pcFrame, pcMetadata, pcCanvasRef, handlePcCanvasClick)}
                {showControls && renderControlPanel('pc')}
              </div>
              
              {/* Phone Screen */}
              <div className="flex flex-col gap-4">
                {renderScreenDisplay('phone', phoneFrame, phoneMetadata, phoneCanvasRef, handlePhoneCanvasClick)}
                {showControls && renderControlPanel('phone')}
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="pc" className="flex-1 mt-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 h-[calc(100vh-280px)]">
              <div className="lg:col-span-2">
                {renderScreenDisplay('pc', pcFrame, pcMetadata, pcCanvasRef, handlePcCanvasClick)}
              </div>
              {showControls && (
                <div>
                  {renderControlPanel('pc')}
                </div>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="phone" className="flex-1 mt-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 h-[calc(100vh-280px)]">
              <div className="lg:col-span-2 flex justify-center">
                <div className="max-w-sm w-full">
                  {renderScreenDisplay('phone', phoneFrame, phoneMetadata, phoneCanvasRef, handlePhoneCanvasClick)}
                </div>
              </div>
              {showControls && (
                <div>
                  {renderControlPanel('phone')}
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
        
        {/* Status Bar */}
        <div className="flex items-center justify-between text-xs text-muted-foreground border-t pt-2">
          <div className="flex items-center gap-4">
            <span>
              PC: {streamStatus?.pc.connected ? '🟢 Connected' : '⚪ Offline'}
              {streamStatus?.viewers.pc ? ` (${streamStatus.viewers.pc} viewers)` : ''}
            </span>
            <span>
              Phone: {streamStatus?.phone.connected ? '🟢 Connected' : '⚪ Offline'}
              {streamStatus?.viewers.phone ? ` (${streamStatus.viewers.phone} viewers)` : ''}
            </span>
          </div>
          <div className="flex items-center gap-4">
            {pcMetadata && (
              <span>PC: {pcMetadata.current_fps || 0} fps, {Math.round(pcMetadata.size_bytes / 1024)} KB/frame</span>
            )}
            {phoneMetadata && (
              <span>Phone: {phoneMetadata.current_fps || 0} fps, {Math.round(phoneMetadata.size_bytes / 1024)} KB/frame</span>
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
