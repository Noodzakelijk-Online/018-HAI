import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  CheckCircle,
  Clock,
  XCircle,
  AlertTriangle,
  Play,
  Pause,
  Target,
  Network,
  TrendingUp,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function TasksNew() {
  const [showDecomposeDialog, setShowDecomposeDialog] = useState(false);
  const [goal, setGoal] = useState("");
  const [context, setContext] = useState("");
  const [decomposing, setDecomposing] = useState(false);
  const [decomposition, setDecomposition] = useState<any>(null);

  const { data: tasks, refetch } = trpc.taskOrchestration.getAllTasks.useQuery({ limit: 50 });
  const { data: stats } = trpc.taskOrchestration.getTaskStats.useQuery();
  const { data: readyTasks } = trpc.taskOrchestration.getReadyTasks.useQuery();

  const decomposeMutation = trpc.taskOrchestration.decomposeGoal.useMutation();
  const createTasksMutation = trpc.taskOrchestration.createTasksFromDecomposition.useMutation();
  const startTaskMutation = trpc.taskOrchestration.startTask.useMutation();
  const completeTaskMutation = trpc.taskOrchestration.completeTask.useMutation();
  const approveTaskMutation = trpc.taskOrchestration.approveTask.useMutation();

  const handleDecomposeGoal = async () => {
    if (!goal.trim()) {
      toast.error('Goal is required');
      return;
    }

    setDecomposing(true);
    try {
      const result = await decomposeMutation.mutateAsync({
        goal,
        context: context || undefined,
      });
      setDecomposition(result);
      toast.success(`Goal broken down into ${result.subtasks.length} tasks`);
    } catch (error) {
      console.error('Error decomposing goal:', error);
      toast.error('Failed to decompose goal');
    } finally {
      setDecomposing(false);
    }
  };

  const handleCreateTasks = async () => {
    if (!decomposition) return;

    try {
      await createTasksMutation.mutateAsync({
        decomposition,
        requireApproval: true,
      });
      toast.success('Tasks created successfully');
      setShowDecomposeDialog(false);
      setGoal("");
      setContext("");
      setDecomposition(null);
      refetch();
    } catch (error) {
      console.error('Error creating tasks:', error);
      toast.error('Failed to create tasks');
    }
  };

  const handleStartTask = async (taskId: number) => {
    try {
      await startTaskMutation.mutateAsync({ taskId });
      toast.success('Task started');
      refetch();
    } catch (error) {
      console.error('Error starting task:', error);
      toast.error('Failed to start task');
    }
  };

  const handleCompleteTask = async (taskId: number) => {
    try {
      await completeTaskMutation.mutateAsync({ taskId });
      toast.success('Task completed');
      refetch();
    } catch (error) {
      console.error('Error completing task:', error);
      toast.error('Failed to complete task');
    }
  };

  const handleApproveTask = async (taskId: number) => {
    try {
      await approveTaskMutation.mutateAsync({ taskId });
      toast.success('Task approved');
      refetch();
    } catch (error) {
      console.error('Error approving task:', error);
      toast.error('Failed to approve task');
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'in_progress':
        return <Clock className="h-4 w-4 text-blue-500 animate-spin" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'pending_approval':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      default:
        return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return 'destructive';
      case 'high':
        return 'default';
      case 'medium':
        return 'secondary';
      default:
        return 'outline';
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Task Orchestration</h1>
          <p className="text-muted-foreground mt-1">
            Break down goals and manage complex workflows
          </p>
        </div>
        <Button onClick={() => setShowDecomposeDialog(true)}>
          <Target className="mr-2 h-4 w-4" />
          Decompose Goal
        </Button>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Tasks</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.total || 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">In Progress</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.inProgress || 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.completed || 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ready to Execute</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{readyTasks?.length || 0}</div>
          </CardContent>
        </Card>
      </div>

      {/* Ready Tasks */}
      {readyTasks && readyTasks.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Ready to Execute</CardTitle>
            <CardDescription>
              Tasks with no pending dependencies
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {readyTasks.map((task: any) => (
              <div
                key={task.id}
                className="flex items-center justify-between p-3 rounded-lg border bg-card"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    {getStatusIcon(task.status)}
                    <span className="font-medium">{task.title}</span>
                    <Badge variant={getPriorityColor(task.priority)}>
                      {task.priority}
                    </Badge>
                  </div>
                  {task.description && (
                    <p className="text-sm text-muted-foreground">
                      {task.description}
                    </p>
                  )}
                </div>
                <Button
                  size="sm"
                  onClick={() => handleStartTask(task.id)}
                  disabled={startTaskMutation.isPending}
                >
                  <Play className="mr-2 h-4 w-4" />
                  Start
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* All Tasks */}
      <Card>
        <CardHeader>
          <CardTitle>All Tasks</CardTitle>
          <CardDescription>
            View and manage all tasks
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {tasks && tasks.length > 0 ? (
            tasks.map((task: any) => {
              const metadata = task.metadata as any;
              const hasDependencies = metadata?.dependencies && metadata.dependencies.length > 0;

              return (
                <div
                  key={task.id}
                  className="p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        {getStatusIcon(task.status)}
                        <span className="font-semibold">{task.title}</span>
                        <Badge variant={getPriorityColor(task.priority)}>
                          {task.priority}
                        </Badge>
                        <Badge variant="outline">{task.taskType}</Badge>
                        {hasDependencies && (
                          <Badge variant="secondary">
                            <Network className="mr-1 h-3 w-3" />
                            {metadata.dependencies.length} deps
                          </Badge>
                        )}
                      </div>

                      {task.description && (
                        <p className="text-sm text-muted-foreground mb-2">
                          {task.description}
                        </p>
                      )}

                      {metadata?.goal && (
                        <div className="text-xs text-muted-foreground">
                          <span className="font-medium">Goal:</span> {metadata.goal}
                        </div>
                      )}

                      {metadata?.estimatedTime && (
                        <div className="text-xs text-muted-foreground mt-1">
                          <span className="font-medium">Est. time:</span> {metadata.estimatedTime} min
                        </div>
                      )}

                      <div className="text-xs text-muted-foreground mt-2">
                        Created: {new Date(task.createdAt).toLocaleString()}
                      </div>
                    </div>

                    <div className="flex flex-col gap-2 ml-4">
                      {task.status === 'pending_approval' && (
                        <Button
                          size="sm"
                          onClick={() => handleApproveTask(task.id)}
                          disabled={approveTaskMutation.isPending}
                        >
                          Approve
                        </Button>
                      )}
                      {task.status === 'approved' && (
                        <Button
                          size="sm"
                          onClick={() => handleStartTask(task.id)}
                          disabled={startTaskMutation.isPending}
                        >
                          <Play className="mr-2 h-4 w-4" />
                          Start
                        </Button>
                      )}
                      {task.status === 'in_progress' && (
                        <Button
                          size="sm"
                          onClick={() => handleCompleteTask(task.id)}
                          disabled={completeTaskMutation.isPending}
                        >
                          <CheckCircle className="mr-2 h-4 w-4" />
                          Complete
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-12">
              <Target className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No tasks yet</h3>
              <p className="text-muted-foreground mb-4">
                Start by decomposing a goal into executable tasks
              </p>
              <Button onClick={() => setShowDecomposeDialog(true)}>
                <Target className="mr-2 h-4 w-4" />
                Decompose Goal
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Decompose Goal Dialog */}
      <Dialog open={showDecomposeDialog} onOpenChange={setShowDecomposeDialog}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Decompose Goal into Tasks</DialogTitle>
            <DialogDescription>
              HAI will break down your goal into executable subtasks with dependencies
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="goal">Goal</Label>
              <Input
                id="goal"
                placeholder="e.g., Plan and execute a family vacation to Japan"
                value={goal}
                onChange={(e) => setGoal(e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="context">Context (optional)</Label>
              <Textarea
                id="context"
                placeholder="Any additional context or constraints..."
                value={context}
                onChange={(e) => setContext(e.target.value)}
                rows={3}
              />
            </div>

            {!decomposition && (
              <Button
                onClick={handleDecomposeGoal}
                disabled={decomposing || !goal.trim()}
                className="w-full"
              >
                {decomposing ? 'Analyzing...' : 'Decompose Goal'}
              </Button>
            )}

            {decomposition && (
              <div className="space-y-4">
                <div className="p-4 rounded-lg bg-muted">
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <span className="font-medium">Subtasks:</span> {decomposition.subtasks.length}
                    </div>
                    <div>
                      <span className="font-medium">Complexity:</span> {decomposition.complexity}
                    </div>
                    <div>
                      <span className="font-medium">Est. Time:</span> {decomposition.estimatedTotalTime} min
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-semibold">Subtasks:</h4>
                  {decomposition.subtasks.map((subtask: any, index: number) => (
                    <div key={index} className="p-3 rounded-lg border bg-card">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-sm">
                          {index + 1}. {subtask.title}
                        </span>
                        <Badge variant={getPriorityColor(subtask.priority)} className="text-xs">
                          {subtask.priority}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {subtask.description}
                      </p>
                      {subtask.dependencies && subtask.dependencies.length > 0 && (
                        <div className="text-xs text-muted-foreground mt-1">
                          <Network className="inline h-3 w-3 mr-1" />
                          Depends on: {subtask.dependencies.map((d: number) => `#${d + 1}`).join(', ')}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowDecomposeDialog(false);
                setDecomposition(null);
                setGoal("");
                setContext("");
              }}
            >
              Cancel
            </Button>
            {decomposition && (
              <Button
                onClick={handleCreateTasks}
                disabled={createTasksMutation.isPending}
              >
                Create Tasks
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
