import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Send, Mail, Bell, MessageSquare, Phone, CheckCircle, XCircle, Clock, AlertCircle } from "lucide-react";
import { toast } from "sonner";

/**
 * Communication Page
 * 
 * Features:
 * - Multi-channel message composer
 * - Template library
 * - Message history
 * - Delivery tracking
 */
export default function Communication() {
  const [activeTab, setActiveTab] = useState("compose");
  const [sendDialogOpen, setSendDialogOpen] = useState(false);
  const [selectedChannel, setSelectedChannel] = useState<"email" | "notification" | "sms" | "chat">("notification");
  const [selectedTemplateId, setSelectedTemplateId] = useState<number | undefined>();

  // Queries
  const { data: messages, isLoading: loadingMessages, refetch: refetchMessages } = trpc.communication.getMessages.useQuery();
  const { data: templates, isLoading: loadingTemplates } = trpc.communication.getTemplates.useQuery();
  const { data: stats } = trpc.communication.getStats.useQuery();

  // Mutations
  const sendMessage = trpc.communication.sendMessage.useMutation({
    onSuccess: () => {
      toast.success("Message sent successfully");
      setSendDialogOpen(false);
      refetchMessages();
    },
    onError: (error) => {
      toast.error(`Failed to send message: ${error.message}`);
    },
  });

  const createTemplate = trpc.communication.createTemplate.useMutation({
    onSuccess: () => {
      toast.success("Template created successfully");
    },
    onError: (error) => {
      toast.error(`Failed to create template: ${error.message}`);
    },
  });

  const handleSendMessage = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    sendMessage.mutate({
      channel: selectedChannel,
      recipient: formData.get("recipient") as string,
      subject: formData.get("subject") as string || undefined,
      body: formData.get("body") as string,
      templateId: selectedTemplateId,
    });
  };

  const getChannelIcon = (channel: string) => {
    switch (channel) {
      case "email":
        return <Mail className="h-4 w-4" />;
      case "notification":
        return <Bell className="h-4 w-4" />;
      case "sms":
        return <Phone className="h-4 w-4" />;
      case "chat":
        return <MessageSquare className="h-4 w-4" />;
      default:
        return <MessageSquare className="h-4 w-4" />;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "sent":
      case "delivered":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "failed":
      case "bounced":
        return <XCircle className="h-4 w-4 text-red-500" />;
      case "queued":
        return <Clock className="h-4 w-4 text-yellow-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const getChannelColor = (channel: string) => {
    switch (channel) {
      case "email":
        return "bg-blue-500/10 text-blue-500";
      case "notification":
        return "bg-purple-500/10 text-purple-500";
      case "sms":
        return "bg-green-500/10 text-green-500";
      case "chat":
        return "bg-orange-500/10 text-orange-500";
      default:
        return "bg-gray-500/10 text-gray-500";
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Communication Engine</h1>
          <p className="text-muted-foreground mt-1">
            Multi-channel messaging with templates and delivery tracking
          </p>
        </div>
        <Dialog open={sendDialogOpen} onOpenChange={setSendDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Send className="mr-2 h-4 w-4" />
              Send Message
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Send Message</DialogTitle>
              <DialogDescription>
                Compose and send a message through your preferred channel
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSendMessage} className="space-y-4">
              <div>
                <Label htmlFor="channel">Channel</Label>
                <Select value={selectedChannel} onValueChange={(v: any) => setSelectedChannel(v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="notification">
                      <div className="flex items-center gap-2">
                        <Bell className="h-4 w-4" />
                        Notification
                      </div>
                    </SelectItem>
                    <SelectItem value="email">
                      <div className="flex items-center gap-2">
                        <Mail className="h-4 w-4" />
                        Email
                      </div>
                    </SelectItem>
                    <SelectItem value="sms">
                      <div className="flex items-center gap-2">
                        <Phone className="h-4 w-4" />
                        SMS
                      </div>
                    </SelectItem>
                    <SelectItem value="chat">
                      <div className="flex items-center gap-2">
                        <MessageSquare className="h-4 w-4" />
                        Chat
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="recipient">Recipient</Label>
                <Input 
                  id="recipient" 
                  name="recipient" 
                  placeholder={selectedChannel === "email" ? "email@example.com" : selectedChannel === "sms" ? "+1234567890" : "user_id"}
                  required 
                />
              </div>
              {(selectedChannel === "email" || selectedChannel === "notification") && (
                <div>
                  <Label htmlFor="subject">Subject</Label>
                  <Input id="subject" name="subject" />
                </div>
              )}
              <div>
                <Label htmlFor="body">Message</Label>
                <Textarea 
                  id="body" 
                  name="body" 
                  rows={6}
                  placeholder="Type your message here..."
                  required 
                />
              </div>
              <Button type="submit" disabled={sendMessage.isPending}>
                {sendMessage.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4" />
                    Send Message
                  </>
                )}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Total Messages</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.total || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Sent</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500">{stats?.sent || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Queued</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-500">{stats?.queued || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Failed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-500">{stats?.failed || 0}</div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="compose">
            <Send className="mr-2 h-4 w-4" />
            Messages
          </TabsTrigger>
          <TabsTrigger value="templates">
            <Mail className="mr-2 h-4 w-4" />
            Templates
          </TabsTrigger>
        </TabsList>

        {/* Messages Tab */}
        <TabsContent value="compose" className="space-y-4">
          {loadingMessages ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : messages && messages.length > 0 ? (
            <div className="space-y-3">
              {messages.map((message) => (
                <Card key={message.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3 flex-1 min-w-0">
                        <div className="mt-1">
                          {getChannelIcon(message.channel)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge className={getChannelColor(message.channel)}>
                              {message.channel}
                            </Badge>
                            <span className="text-sm text-muted-foreground">to {message.recipient}</span>
                          </div>
                          {message.subject && (
                            <p className="font-medium mb-1">{message.subject}</p>
                          )}
                          <p className="text-sm text-muted-foreground line-clamp-2">
                            {message.body}
                          </p>
                          <p className="text-xs text-muted-foreground mt-2">
                            {new Date(message.createdAt).toLocaleString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 ml-4">
                        {getStatusIcon(message.status)}
                        <Badge variant="outline">{message.status}</Badge>
                      </div>
                    </div>
                    {message.errorMessage && (
                      <p className="text-sm text-red-500 mt-3">
                        Error: {message.errorMessage}
                      </p>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Send className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-center text-muted-foreground">
                  No messages yet. Send your first message!
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Templates Tab */}
        <TabsContent value="templates" className="space-y-4">
          {loadingTemplates ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : templates && templates.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {templates.map((template) => (
                <Card key={template.id} className="hover:bg-accent transition-colors">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <CardTitle className="text-lg">{template.name}</CardTitle>
                        <CardDescription className="mt-2">
                          {template.description || "No description"}
                        </CardDescription>
                      </div>
                      <Badge className={getChannelColor(template.channel)}>
                        {template.channel}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-sm text-muted-foreground mb-3 line-clamp-3">
                      {template.body}
                    </div>
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>Used {template.usageCount} times</span>
                      {template.variables && template.variables.length > 0 && (
                        <span>{template.variables.length} variables</span>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Mail className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-center text-muted-foreground">
                  No templates yet. Create your first message template!
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
