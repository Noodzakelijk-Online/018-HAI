/**
 * Thinking Status Page
 * 
 * Shows HAI's cognitive state including:
 * - Current context awareness
 * - Active observations
 * - Pending decisions
 * - Thought log
 * - Decision history
 */

import { useState, useEffect } from 'react';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  Brain, 
  Eye, 
  MessageSquare, 
  Clock, 
  AlertTriangle,
  CheckCircle,
  XCircle,
  Loader2,
  Activity,
  Lightbulb,
  History,
  Settings,
  RefreshCw
} from 'lucide-react';
import { trpc } from '@/lib/trpc';

// Types matching the backend
interface Observation {
  id: string;
  type: 'opportunity' | 'problem' | 'information' | 'reminder';
  title: string;
  description: string;
  confidence: number;
  source: string;
  timestamp: string;
}

interface Decision {
  id: string;
  title: string;
  description: string;
  category: string;
  confidence: number;
  confidenceLevel: 'high' | 'medium' | 'low';
  status: string;
  options: Array<{ id: string; label: string }>;
  createdAt: string;
  reasoning: string[];
}

interface ThinkingStatus {
  isRunning: boolean;
  contextSources: {
    screen: boolean;
    calendar: boolean;
    email: boolean;
  };
  observationCount: number;
  thoughtCount: number;
  decisionStats: {
    pending: number;
    awaitingUser: number;
    executed: number;
    failed: number;
    undone: number;
  };
}

interface Thought {
  timestamp: string;
  thought: string;
}

export default function ThinkingStatus() {
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  // Fetch thinking status
  const { data: status, refetch: refetchStatus } = trpc.thinking.getStatus.useQuery(undefined, {
    refetchInterval: 3000
  });
  
  // Fetch observations
  const { data: observations } = trpc.thinking.getObservations.useQuery({ limit: 20 }, {
    refetchInterval: 5000
  });
  
  // Fetch pending decisions
  const { data: pendingDecisions } = trpc.thinking.getPendingDecisions.useQuery(undefined, {
    refetchInterval: 3000
  });
  
  // Fetch thought log
  const { data: thoughtLog } = trpc.thinking.getThoughtLog.useQuery({ limit: 50 }, {
    refetchInterval: 5000
  });
  
  // Fetch decision history
  const { data: decisionHistory } = trpc.thinking.getDecisionHistory.useQuery({ limit: 20 }, {
    refetchInterval: 10000
  });
  
  const handleRefresh = async () => {
    setIsRefreshing(true);
    await refetchStatus();
    setIsRefreshing(false);
  };
  
  const getObservationIcon = (type: string) => {
    switch (type) {
      case 'problem': return <AlertTriangle className="h-4 w-4 text-red-500" />;
      case 'opportunity': return <Lightbulb className="h-4 w-4 text-yellow-500" />;
      case 'reminder': return <Clock className="h-4 w-4 text-blue-500" />;
      default: return <Eye className="h-4 w-4 text-gray-500" />;
    }
  };
  
  const getConfidenceBadge = (level: string) => {
    switch (level) {
      case 'high':
        return <Badge className="bg-green-500/20 text-green-400 border-green-500/30">High Confidence</Badge>;
      case 'medium':
        return <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">Medium Confidence</Badge>;
      case 'low':
        return <Badge className="bg-red-500/20 text-red-400 border-red-500/30">Low Confidence</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'executed':
        return <Badge className="bg-green-500/20 text-green-400"><CheckCircle className="h-3 w-3 mr-1" />Executed</Badge>;
      case 'awaiting_user':
        return <Badge className="bg-blue-500/20 text-blue-400"><MessageSquare className="h-3 w-3 mr-1" />Awaiting Response</Badge>;
      case 'failed':
        return <Badge className="bg-red-500/20 text-red-400"><XCircle className="h-3 w-3 mr-1" />Failed</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-500/20 text-yellow-400"><Loader2 className="h-3 w-3 mr-1 animate-spin" />Pending</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Brain className="h-7 w-7 text-purple-500" />
              HAI Thinking Status
            </h1>
            <p className="text-muted-foreground mt-1">
              Real-time view of HAI's cognitive processes and decision-making
            </p>
          </div>
          <Button 
            variant="outline" 
            onClick={handleRefresh}
            disabled={isRefreshing}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
        
        {/* Status Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-br from-purple-500/10 to-purple-500/5 border-purple-500/20">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Thinking Engine</p>
                  <p className="text-2xl font-bold">
                    {status?.isRunning ? 'Active' : 'Inactive'}
                  </p>
                </div>
                <Brain className={`h-8 w-8 ${status?.isRunning ? 'text-purple-500 animate-pulse' : 'text-gray-500'}`} />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-blue-500/10 to-blue-500/5 border-blue-500/20">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Observations</p>
                  <p className="text-2xl font-bold">{status?.observationCount || 0}</p>
                </div>
                <Eye className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-yellow-500/10 to-yellow-500/5 border-yellow-500/20">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Pending Decisions</p>
                  <p className="text-2xl font-bold">{status?.decisionStats?.pending || 0}</p>
                </div>
                <Activity className="h-8 w-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-green-500/10 to-green-500/5 border-green-500/20">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Executed Today</p>
                  <p className="text-2xl font-bold">{status?.decisionStats?.executed || 0}</p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Context Sources */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">Context Sources</CardTitle>
            <CardDescription>What HAI can currently see and access</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <div className={`flex items-center gap-2 px-4 py-2 rounded-lg ${
                status?.contextSources?.screen ? 'bg-green-500/10 text-green-500' : 'bg-gray-500/10 text-gray-500'
              }`}>
                <Eye className="h-5 w-5" />
                <span>Screen OCR</span>
                {status?.contextSources?.screen && <CheckCircle className="h-4 w-4" />}
              </div>
              <div className={`flex items-center gap-2 px-4 py-2 rounded-lg ${
                status?.contextSources?.calendar ? 'bg-green-500/10 text-green-500' : 'bg-gray-500/10 text-gray-500'
              }`}>
                <Clock className="h-5 w-5" />
                <span>Calendar</span>
                {status?.contextSources?.calendar && <CheckCircle className="h-4 w-4" />}
              </div>
              <div className={`flex items-center gap-2 px-4 py-2 rounded-lg ${
                status?.contextSources?.email ? 'bg-green-500/10 text-green-500' : 'bg-gray-500/10 text-gray-500'
              }`}>
                <MessageSquare className="h-5 w-5" />
                <span>Email</span>
                {status?.contextSources?.email && <CheckCircle className="h-4 w-4" />}
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Main Content Tabs */}
        <Tabs defaultValue="decisions" className="space-y-4">
          <TabsList>
            <TabsTrigger value="decisions">
              <Activity className="h-4 w-4 mr-2" />
              Pending Decisions
            </TabsTrigger>
            <TabsTrigger value="observations">
              <Eye className="h-4 w-4 mr-2" />
              Observations
            </TabsTrigger>
            <TabsTrigger value="thoughts">
              <Brain className="h-4 w-4 mr-2" />
              Thought Log
            </TabsTrigger>
            <TabsTrigger value="history">
              <History className="h-4 w-4 mr-2" />
              Decision History
            </TabsTrigger>
          </TabsList>
          
          {/* Pending Decisions */}
          <TabsContent value="decisions">
            <Card>
              <CardHeader>
                <CardTitle>Pending Decisions</CardTitle>
                <CardDescription>Decisions waiting for action or user response</CardDescription>
              </CardHeader>
              <CardContent>
                {pendingDecisions && pendingDecisions.length > 0 ? (
                  <div className="space-y-4">
                    {pendingDecisions.map((decision: Decision) => (
                      <div 
                        key={decision.id}
                        className="p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                      >
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <h4 className="font-medium">{decision.title}</h4>
                              {getConfidenceBadge(decision.confidenceLevel)}
                              {getStatusBadge(decision.status)}
                            </div>
                            <p className="text-sm text-muted-foreground">{decision.description}</p>
                          </div>
                          <div className="text-right text-sm text-muted-foreground">
                            <div>Confidence: {Math.round(decision.confidence * 100)}%</div>
                            <Progress value={decision.confidence * 100} className="w-24 h-2 mt-1" />
                          </div>
                        </div>
                        
                        {decision.options.length > 0 && (
                          <div className="mt-3 flex gap-2">
                            {decision.options.map((option) => (
                              <Badge key={option.id} variant="outline">
                                {option.label}
                              </Badge>
                            ))}
                          </div>
                        )}
                        
                        {decision.reasoning.length > 0 && (
                          <div className="mt-3 text-sm text-muted-foreground">
                            <p className="font-medium">Reasoning:</p>
                            <ul className="list-disc list-inside">
                              {decision.reasoning.map((reason, i) => (
                                <li key={i}>{reason}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <CheckCircle className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p>No pending decisions</p>
                    <p className="text-sm">HAI is handling everything autonomously</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Observations */}
          <TabsContent value="observations">
            <Card>
              <CardHeader>
                <CardTitle>Recent Observations</CardTitle>
                <CardDescription>What HAI has noticed from context analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  {observations && observations.length > 0 ? (
                    <div className="space-y-3">
                      {observations.map((obs: Observation) => (
                        <div 
                          key={obs.id}
                          className="flex items-start gap-3 p-3 rounded-lg border bg-card"
                        >
                          {getObservationIcon(obs.type)}
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <span className="font-medium">{obs.title}</span>
                              <Badge variant="outline" className="text-xs">
                                {obs.source}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mt-1">
                              {obs.description}
                            </p>
                            <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                              <span>Confidence: {Math.round(obs.confidence * 100)}%</span>
                              <span>{new Date(obs.timestamp).toLocaleTimeString()}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <Eye className="h-12 w-12 mx-auto mb-3 opacity-50" />
                      <p>No observations yet</p>
                      <p className="text-sm">HAI is gathering context...</p>
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Thought Log */}
          <TabsContent value="thoughts">
            <Card>
              <CardHeader>
                <CardTitle>Thought Log</CardTitle>
                <CardDescription>HAI's internal reasoning and notes</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  {thoughtLog && thoughtLog.length > 0 ? (
                    <div className="space-y-2 font-mono text-sm">
                      {thoughtLog.map((thought: Thought, i: number) => (
                        <div key={i} className="flex gap-3 text-muted-foreground">
                          <span className="text-xs opacity-50">
                            {new Date(thought.timestamp).toLocaleTimeString()}
                          </span>
                          <span>💭 {thought.thought}</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <Brain className="h-12 w-12 mx-auto mb-3 opacity-50" />
                      <p>No thoughts recorded yet</p>
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Decision History */}
          <TabsContent value="history">
            <Card>
              <CardHeader>
                <CardTitle>Decision History</CardTitle>
                <CardDescription>Past decisions and their outcomes</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  {decisionHistory && decisionHistory.length > 0 ? (
                    <div className="space-y-3">
                      {decisionHistory.map((decision: Decision) => (
                        <div 
                          key={decision.id}
                          className="flex items-center justify-between p-3 rounded-lg border bg-card"
                        >
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-medium">{decision.title}</span>
                              {getStatusBadge(decision.status)}
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {decision.description}
                            </p>
                          </div>
                          <div className="text-right text-sm text-muted-foreground">
                            {new Date(decision.createdAt).toLocaleString()}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <History className="h-12 w-12 mx-auto mb-3 opacity-50" />
                      <p>No decision history yet</p>
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
