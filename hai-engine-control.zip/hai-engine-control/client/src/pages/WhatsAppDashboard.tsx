/**
 * WhatsApp Dashboard
 * 
 * Main interface for WhatsApp integration:
 * - View sync status
 * - Browse conversations
 * - View relationship insights
 * - Search messages
 */

import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Loader2, MessageCircle, Users, TrendingUp, Search, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import { Link } from 'wouter';

export default function WhatsAppDashboard() {
  const [searchQuery, setSearchQuery] = useState('');
  
  // Queries
  const { data: syncStatus, isLoading: syncLoading, refetch: refetchStatus } = trpc.whatsapp.getSyncStatus.useQuery();
  const { data: contacts, isLoading: contactsLoading } = trpc.whatsapp.getContacts.useQuery();
  const { data: relationships, isLoading: relationshipsLoading } = trpc.whatsapp.getRelationshipInsights.useQuery();
  
  // Mutations
  const startSync = trpc.whatsapp.startSync.useMutation({
    onSuccess: () => {
      toast({
        title: 'Sync Started',
        description: 'WhatsApp message sync has been initiated. This may take several minutes.',
      });
      refetchStatus();
    },
    onError: (error) => {
      toast({
        title: 'Sync Failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const handleStartSync = () => {
    if (syncStatus?.isConnected) {
      toast({
        title: 'Sync Already Running',
        description: 'A sync is already in progress.',
        variant: 'destructive',
      });
      return;
    }
    
    startSync.mutate();
  };
  
  if (syncLoading || contactsLoading || relationshipsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }
  
  const topRelationships = relationships?.slice(0, 5) || [];
  
  return (
    <div className="container mx-auto py-8 space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">WhatsApp Integration</h1>
          <p className="text-muted-foreground mt-2">
            Analyze and synthesize all your WhatsApp conversations
          </p>
        </div>
        <Button
          onClick={handleStartSync}
          disabled={startSync.isPending || syncStatus?.isConnected}
        >
          {startSync.isPending ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Starting...
            </>
          ) : (
            <>
              <RefreshCw className="w-4 h-4 mr-2" />
              {syncStatus?.isConnected ? 'Syncing...' : 'Start Sync'}
            </>
          )}
        </Button>
      </div>
      
      {/* Sync Status */}
      {syncStatus && (
        <Card>
          <CardHeader>
            <CardTitle>Sync Status</CardTitle>
            <CardDescription>
              Current status of WhatsApp message synchronization
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <div className="text-sm text-muted-foreground">Status</div>
                <div className="text-2xl font-bold">
                  {syncStatus.isConnected ? (
                    <Badge variant="default">Syncing</Badge>
                  ) : (
                    <Badge variant="secondary">Idle</Badge>
                  )}
                </div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Total Chats</div>
                <div className="text-2xl font-bold">{syncStatus.totalChats}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Total Messages</div>
                <div className="text-2xl font-bold">{syncStatus.totalMessages.toLocaleString()}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Progress</div>
                <div className="text-2xl font-bold">{parseFloat(syncStatus.syncProgress).toFixed(1)}%</div>
              </div>
            </div>
            {syncStatus.lastSyncAt && (
              <div className="mt-4 text-sm text-muted-foreground">
                Last synced: {new Date(syncStatus.lastSyncAt).toLocaleString()}
              </div>
            )}
            {syncStatus.errorMessage && (
              <div className="mt-4 text-sm text-destructive">
                Error: {syncStatus.errorMessage}
              </div>
            )}
          </CardContent>
        </Card>
      )}
      
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Contacts</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{contacts?.length || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {contacts?.filter(c => c.isGroup).length || 0} groups
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Messages</CardTitle>
            <MessageCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {contacts?.reduce((sum, c) => sum + (c.messageCount || 0), 0).toLocaleString() || 0}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Across all conversations
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Relationship Score</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {relationships && relationships.length > 0
                ? (relationships.reduce((sum, r) => sum + r.relationshipScore, 0) / relationships.length).toFixed(2)
                : '0.00'}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Out of 1.00
            </p>
          </CardContent>
        </Card>
      </div>
      
      {/* Top Relationships */}
      <Card>
        <CardHeader>
          <CardTitle>Top Relationships</CardTitle>
          <CardDescription>
            Contacts with the strongest relationship scores
          </CardDescription>
        </CardHeader>
        <CardContent>
          {topRelationships.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">
              No relationship data available. Start a sync to analyze your conversations.
            </div>
          ) : (
            <div className="space-y-4">
              {topRelationships.map((rel) => (
                <Link key={rel.id} href={`/whatsapp/conversation/${rel.id}`}>
                  <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-accent cursor-pointer transition-colors">
                  <div className="flex-1">
                    <div className="font-medium">{rel.name || rel.phone}</div>
                    <div className="text-sm text-muted-foreground">
                      {rel.messageCount} messages
                      {rel.lastMessageAt && ` • Last: ${new Date(rel.lastMessageAt).toLocaleDateString()}`}
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    {rel.isGroup && (
                      <Badge variant="secondary">Group</Badge>
                    )}
                    <div className="text-right">
                      <div className="text-2xl font-bold">{rel.relationshipScore.toFixed(2)}</div>
                      <div className="text-xs text-muted-foreground">Score</div>
                    </div>
                  </div>
                </div>
                </Link>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Search */}
      <Card>
        <CardHeader>
          <CardTitle>Search Messages</CardTitle>
          <CardDescription>
            Search across all your WhatsApp conversations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Input
              placeholder="Search messages..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Button>
              <Search className="w-4 h-4 mr-2" />
              Search
            </Button>
          </div>
        </CardContent>
      </Card>
      
      {/* Recent Conversations */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Conversations</CardTitle>
          <CardDescription>
            Your most recent WhatsApp chats
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!contacts || contacts.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">
              No conversations available. Start a sync to import your WhatsApp messages.
            </div>
          ) : (
            <div className="space-y-2">
              {contacts.slice(0, 10).map((contact) => (
                <div
                  key={contact.id}
                  className="flex items-center justify-between p-3 border rounded-lg hover:bg-accent cursor-pointer transition-colors"
                >
                  <div className="flex-1">
                    <div className="font-medium">{contact.name || contact.phone}</div>
                    <div className="text-sm text-muted-foreground">
                      {contact.messageCount} messages
                    </div>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {contact.lastMessageAt
                      ? new Date(contact.lastMessageAt).toLocaleDateString()
                      : 'No messages'}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
