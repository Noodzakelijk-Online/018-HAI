/**
 * Pillar 4 Dashboard: Proactive Behavior
 * 
 * "Anticipates, Doesn't Just React"
 * 
 * This dashboard provides a unified view of:
 * - Confidence Scoring
 * - Anticipatory Actions
 * - Trust Building
 */

import { useState } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import DashboardLayout from '@/components/DashboardLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { trpc } from '@/lib/trpc';
import {
  Zap,
  Target,
  TrendingUp,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Calendar,
  DollarSign,
  Cloud,
  Heart,
  Lightbulb,
  Activity,
  ThumbsUp,
  ThumbsDown,
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

const DEFAULT_HOUSEHOLD_ID = 1;

const confidenceLevelColors: Record<string, string> = {
  very_high: 'text-green-500',
  high: 'text-emerald-500',
  medium: 'text-yellow-500',
  low: 'text-orange-500',
  very_low: 'text-red-500',
};

const recommendationColors: Record<string, string> = {
  execute: 'bg-green-500/10 text-green-600 border-green-500/30',
  suggest: 'bg-blue-500/10 text-blue-600 border-blue-500/30',
  ask: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/30',
  decline: 'bg-red-500/10 text-red-600 border-red-500/30',
};

const priorityColors: Record<string, string> = {
  critical: 'bg-red-500/10 text-red-600',
  high: 'bg-orange-500/10 text-orange-600',
  medium: 'bg-blue-500/10 text-blue-600',
  low: 'bg-gray-500/10 text-gray-600',
};

const anticipationIcons: Record<string, React.ReactNode> = {
  schedule_conflict: <Calendar className="h-4 w-4 text-purple-500" />,
  bill_due: <DollarSign className="h-4 w-4 text-green-500" />,
  maintenance_needed: <Activity className="h-4 w-4 text-orange-500" />,
  supply_low: <AlertTriangle className="h-4 w-4 text-yellow-500" />,
  appointment_reminder: <Clock className="h-4 w-4 text-blue-500" />,
  travel_preparation: <Zap className="h-4 w-4 text-indigo-500" />,
  weather_alert: <Cloud className="h-4 w-4 text-cyan-500" />,
  health_reminder: <Heart className="h-4 w-4 text-red-500" />,
  social_event: <Calendar className="h-4 w-4 text-pink-500" />,
  opportunity: <Lightbulb className="h-4 w-4 text-yellow-500" />,
};

export default function Pillar4Dashboard() {
  const { user, loading } = useAuth();
  const [activeTab, setActiveTab] = useState('confidence');

  // Fetch data
  const { data: recentScores } = trpc.pillar4.confidence.recent.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID, limit: 20 },
    { refetchInterval: 30000 }
  );

  const { data: confidenceStats } = trpc.pillar4.confidence.statistics.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 30000 }
  );

  const { data: pendingAnticipations, refetch: refetchAnticipations } = trpc.pillar4.anticipation.pending.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 30000 }
  );

  const { data: anticipationStats } = trpc.pillar4.anticipation.statistics.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 30000 }
  );

  const { data: patterns } = trpc.pillar4.anticipation.patterns.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 60000 }
  );

  const { data: combinedStats } = trpc.pillar4.statistics.useQuery(
    { householdId: DEFAULT_HOUSEHOLD_ID },
    { refetchInterval: 30000 }
  );

  // Mutations
  const updateStatusMutation = trpc.pillar4.anticipation.updateStatus.useMutation({
    onSuccess: () => {
      toast.success('Status updated');
      refetchAnticipations();
    },
    onError: (error) => {
      toast.error(`Failed to update: ${error.message}`);
    },
  });

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Proactive Behavior</h1>
            <p className="text-muted-foreground mt-1">
              Pillar 4: Anticipates, Doesn't Just React
            </p>
          </div>
          <Badge variant="outline" className="text-lg px-4 py-2">
            <Zap className="h-4 w-4 mr-2 text-yellow-500" />
            {pendingAnticipations?.length ?? 0} Pending Actions
          </Badge>
        </div>

        {/* Overview Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Avg Confidence</p>
                  <p className="text-2xl font-bold">
                    {combinedStats?.summary.avgConfidence
                      ? `${Math.round(combinedStats.summary.avgConfidence * 100)}%`
                      : '—'}
                  </p>
                </div>
                <Target className="h-8 w-8 text-blue-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Success Rate</p>
                  <p className="text-2xl font-bold">
                    {combinedStats?.summary.successRate
                      ? `${Math.round(combinedStats.summary.successRate * 100)}%`
                      : '—'}
                  </p>
                </div>
                <CheckCircle2 className="h-8 w-8 text-green-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Pending</p>
                  <p className="text-2xl font-bold">{combinedStats?.summary.pendingAnticipations ?? 0}</p>
                </div>
                <Clock className="h-8 w-8 text-orange-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Helpful Rate</p>
                  <p className="text-2xl font-bold">
                    {combinedStats?.summary.helpfulRate
                      ? `${Math.round(combinedStats.summary.helpfulRate * 100)}%`
                      : '—'}
                  </p>
                </div>
                <ThumbsUp className="h-8 w-8 text-emerald-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Pattern Accuracy</p>
                  <p className="text-2xl font-bold">
                    {combinedStats?.summary.patternAccuracy
                      ? `${Math.round(combinedStats.summary.patternAccuracy * 100)}%`
                      : '—'}
                  </p>
                </div>
                <TrendingUp className="h-8 w-8 text-purple-500 opacity-50" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Scores</p>
                  <p className="text-2xl font-bold">{combinedStats?.summary.totalScores ?? 0}</p>
                </div>
                <Activity className="h-8 w-8 text-cyan-500 opacity-50" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 lg:w-auto lg:inline-grid">
            <TabsTrigger value="confidence" className="gap-2">
              <Target className="h-4 w-4" />
              <span className="hidden sm:inline">Confidence</span>
            </TabsTrigger>
            <TabsTrigger value="anticipations" className="gap-2">
              <Zap className="h-4 w-4" />
              <span className="hidden sm:inline">Anticipations</span>
              {(pendingAnticipations?.length ?? 0) > 0 && (
                <Badge variant="secondary" className="ml-1">
                  {pendingAnticipations?.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="patterns" className="gap-2">
              <TrendingUp className="h-4 w-4" />
              <span className="hidden sm:inline">Patterns</span>
            </TabsTrigger>
          </TabsList>

          {/* Confidence Tab */}
          <TabsContent value="confidence" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5" />
                    Recent Confidence Scores
                  </CardTitle>
                  <CardDescription>
                    How confident HAI is about recent decisions
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[350px]">
                    {!recentScores || recentScores.length === 0 ? (
                      <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
                        <Target className="h-12 w-12 mb-4 opacity-20" />
                        <p>No scores yet</p>
                        <p className="text-sm">Scores appear as HAI makes decisions</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {recentScores.map((score: any) => (
                          <div
                            key={score.id}
                            className="p-4 rounded-lg border bg-card"
                          >
                            <div className="flex items-center justify-between mb-2">
                              <span className="font-medium">{score.actionType}</span>
                              <Badge className={cn("border", recommendationColors[score.recommendation])}>
                                {score.recommendation}
                              </Badge>
                            </div>
                            <div className="space-y-2">
                              <div className="flex items-center justify-between text-sm">
                                <span className="text-muted-foreground">Confidence</span>
                                <span className={cn("font-medium", confidenceLevelColors[score.level])}>
                                  {Math.round(score.overallScore * 100)}% ({score.level.replace('_', ' ')})
                                </span>
                              </div>
                              <Progress value={score.overallScore * 100} className="h-2" />
                              {score.reasoning && score.reasoning.length > 0 && (
                                <p className="text-xs text-muted-foreground mt-2">
                                  {score.reasoning[0]}
                                </p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Confidence Distribution</CardTitle>
                  <CardDescription>Breakdown by level and recommendation</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <p className="text-sm font-medium mb-3">By Level</p>
                      <div className="space-y-2">
                        {Object.entries(confidenceStats?.byLevel || {}).map(([level, count]) => (
                          <div key={level} className="flex items-center justify-between">
                            <span className={cn("text-sm capitalize", confidenceLevelColors[level])}>
                              {level.replace('_', ' ')}
                            </span>
                            <span className="text-sm font-medium">{count as number}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <p className="text-sm font-medium mb-3">By Recommendation</p>
                      <div className="space-y-2">
                        {Object.entries(confidenceStats?.byRecommendation || {}).map(([rec, count]) => (
                          <div key={rec} className="flex items-center justify-between">
                            <Badge className={cn("border", recommendationColors[rec])}>
                              {rec}
                            </Badge>
                            <span className="text-sm font-medium">{count as number}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="pt-4 border-t">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="text-center p-3 rounded-lg bg-muted/50">
                          <p className="text-2xl font-bold text-green-500">
                            {confidenceStats?.successRate
                              ? `${Math.round(confidenceStats.successRate * 100)}%`
                              : '—'}
                          </p>
                          <p className="text-xs text-muted-foreground">Success Rate</p>
                        </div>
                        <div className="text-center p-3 rounded-lg bg-muted/50">
                          <p className="text-2xl font-bold text-orange-500">
                            {confidenceStats?.overrideRate
                              ? `${Math.round(confidenceStats.overrideRate * 100)}%`
                              : '—'}
                          </p>
                          <p className="text-xs text-muted-foreground">Override Rate</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Anticipations Tab */}
          <TabsContent value="anticipations" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-yellow-500" />
                  Pending Anticipations
                </CardTitle>
                <CardDescription>
                  Actions HAI is preparing to take
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  {!pendingAnticipations || pendingAnticipations.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
                      <Zap className="h-12 w-12 mb-4 opacity-20" />
                      <p>No pending anticipations</p>
                      <p className="text-sm">HAI will predict actions as patterns emerge</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {pendingAnticipations.map((action: any) => (
                        <div
                          key={action.id}
                          className="p-4 rounded-lg border bg-card"
                        >
                          <div className="flex items-start gap-3">
                            {anticipationIcons[action.type] || <Zap className="h-4 w-4" />}
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-medium">{action.title}</span>
                                <Badge className={priorityColors[action.priority]}>
                                  {action.priority}
                                </Badge>
                                <Badge variant="outline">
                                  {Math.round(action.confidenceScore * 100)}% confident
                                </Badge>
                              </div>
                              <p className="text-sm text-muted-foreground mb-2">
                                {action.description}
                              </p>
                              <div className="flex items-center gap-4 text-xs text-muted-foreground mb-3">
                                <span>Due: {new Date(action.anticipatedAt).toLocaleDateString()}</span>
                                <span>Lead time: {action.leadTime}h</span>
                              </div>
                              <div className="p-3 rounded bg-muted/50 mb-3">
                                <p className="text-sm font-medium mb-1">Suggested Action</p>
                                <p className="text-sm text-muted-foreground">
                                  {action.suggestedAction.description}
                                </p>
                                <p className="text-xs text-muted-foreground mt-1">
                                  Est. {action.suggestedAction.estimatedDuration} min
                                  {action.suggestedAction.estimatedCost && ` • $${action.suggestedAction.estimatedCost}`}
                                </p>
                              </div>
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  onClick={() => updateStatusMutation.mutate({
                                    actionId: action.id,
                                    status: 'acted',
                                    outcome: 'helpful',
                                  })}
                                >
                                  <ThumbsUp className="h-3 w-3 mr-1" />
                                  Act Now
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => updateStatusMutation.mutate({
                                    actionId: action.id,
                                    status: 'dismissed',
                                    outcome: 'unnecessary',
                                  })}
                                >
                                  <ThumbsDown className="h-3 w-3 mr-1" />
                                  Dismiss
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Patterns Tab */}
          <TabsContent value="patterns" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Prediction Patterns
                </CardTitle>
                <CardDescription>
                  Patterns HAI uses to anticipate needs
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  {!patterns || patterns.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
                      <TrendingUp className="h-12 w-12 mb-4 opacity-20" />
                      <p>No patterns yet</p>
                      <p className="text-sm">Patterns develop as HAI learns</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {patterns.map((pattern: any) => (
                        <div
                          key={pattern.id}
                          className="p-4 rounded-lg border bg-card"
                        >
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              {anticipationIcons[pattern.patternType] || <Activity className="h-4 w-4" />}
                              <span className="font-medium">{pattern.patternName}</span>
                            </div>
                            <Badge variant={pattern.isActive ? 'default' : 'secondary'}>
                              {pattern.isActive ? 'Active' : 'Inactive'}
                            </Badge>
                          </div>
                          <div className="grid grid-cols-3 gap-4 text-sm">
                            <div>
                              <p className="text-muted-foreground">Predictions</p>
                              <p className="font-medium">{pattern.predictionCount}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Accurate</p>
                              <p className="font-medium">{pattern.accurateCount}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Accuracy</p>
                              <p className={cn(
                                "font-medium",
                                pattern.accuracy >= 0.8 ? "text-green-500" :
                                pattern.accuracy >= 0.6 ? "text-yellow-500" : "text-red-500"
                              )}>
                                {Math.round(pattern.accuracy * 100)}%
                              </p>
                            </div>
                          </div>
                          <div className="mt-3">
                            <p className="text-xs text-muted-foreground">
                              {pattern.triggers.length} triggers configured
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
