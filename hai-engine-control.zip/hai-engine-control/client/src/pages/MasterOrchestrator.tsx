import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import DashboardLayout from "@/components/DashboardLayout";
import { 
  Zap, 
  Mail, 
  Calendar, 
  DollarSign, 
  FileText, 
  CheckCircle2, 
  Clock, 
  AlertCircle,
  TrendingUp,
  Activity,
  Brain,
  Sparkles,
  ArrowRight,
  Plus
} from "lucide-react";
import React, { useState } from "react";
import { toast } from "sonner";

export default function MasterOrchestrator() {
  const [selectedHouseholdId, setSelectedHouseholdId] = useState<number | null>(null);

  // Fetch user's households
  const { data: households } = trpc.households.list.useQuery();
  
  // Auto-select first household
  React.useEffect(() => {
    if (households && households.length > 0 && !selectedHouseholdId) {
      setSelectedHouseholdId(households[0].id);
    }
  }, [households, selectedHouseholdId]);

  const { data: connectors } = trpc.connectors.list.useQuery(
    { householdId: selectedHouseholdId! },
    { enabled: !!selectedHouseholdId }
  );

  const { data: agents } = trpc.agents.list.useQuery(
    { householdId: selectedHouseholdId! },
    { enabled: !!selectedHouseholdId }
  );

  // Get real analysis data from orchestrator engine
  const { data: analysisData, isLoading: analysisLoading, refetch: refetchAnalysis } = trpc.orchestrator.analyzeAccounts.useQuery(
    { householdId: selectedHouseholdId! },
    { enabled: !!selectedHouseholdId, refetchInterval: 60000 } // Refresh every minute
  );

  const { data: orchestratorStatus } = trpc.orchestrator.getStatus.useQuery(
    { householdId: selectedHouseholdId! },
    { enabled: !!selectedHouseholdId }
  );

  // Calculate orchestrator metrics
  const connectedAccounts = connectors?.length || 0;
  const activeAgents = agents?.filter(a => a.isConnected).length || 0;
  const totalCapabilities = agents?.reduce((sum, agent) => {
    const caps = agent.capabilities as any;
    return sum + (caps?.models?.length || 0);
  }, 0) || 0;

  // Account types
  const accountTypes = [
    {
      icon: Mail,
      name: "Email",
      description: "Gmail accounts for email monitoring and automation",
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
      borderColor: "border-blue-200",
      connected: connectors?.filter(c => c.connectorType === "gmail").length || 0,
      path: "/connectors"
    },
    {
      icon: Calendar,
      name: "Calendar",
      description: "Google Calendar for event management",
      color: "text-green-500",
      bgColor: "bg-green-500/10",
      borderColor: "border-green-200",
      connected: connectors?.filter(c => c.connectorType === "google_calendar").length || 0,
      path: "/connectors"
    },
    {
      icon: DollarSign,
      name: "Financial",
      description: "Bank accounts and payment services",
      color: "text-yellow-500",
      bgColor: "bg-yellow-500/10",
      borderColor: "border-yellow-200",
      connected: 0,
      path: "/connectors",
      comingSoon: true
    },
    {
      icon: FileText,
      name: "Documents",
      description: "Google Drive, Dropbox, and file storage",
      color: "text-purple-500",
      bgColor: "bg-purple-500/10",
      borderColor: "border-purple-200",
      connected: 0,
      path: "/connectors",
      comingSoon: true
    },
  ];

  // Use real insights from analysis engine
  const insights = React.useMemo(() => {
    if (!analysisData?.insights) return [];

    return analysisData.insights.map(insight => {
      const iconMap: Record<string, any> = {
        email: Mail,
        calendar: Calendar,
        financial: DollarSign,
        document: FileText,
        system: Activity,
      };

      const colorMap: Record<string, string> = {
        urgent: "text-red-600",
        high: "text-red-500",
        medium: "text-yellow-500",
        low: "text-green-500",
      };

      return {
        icon: iconMap[insight.type] || Activity,
        title: insight.title,
        description: insight.description,
        priority: insight.priority,
        action: insight.suggestedAction || "View",
        color: colorMap[insight.priority] || "text-gray-500",
        insightId: insight.id,
        metadata: insight.metadata,
      };
    });
  }, [analysisData]);

  // Add "all clear" insight if no issues
  const displayInsights = insights.length > 0 ? insights : [
    {
      icon: CheckCircle2,
      title: "All systems operational",
      description: "No issues detected across your connected accounts",
      priority: "low" as const,
      action: "View Details",
      color: "text-green-500",
      insightId: "all-clear",
      metadata: {},
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Zap className="h-6 w-6 text-primary" />
              <h1 className="text-3xl font-bold tracking-tight">Master Orchestrator</h1>
            </div>
            <p className="text-muted-foreground text-base">
              Central control hub for all your connected accounts and autonomous operations
            </p>
          </div>
        </div>

        {/* System Status Cards */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Card className="border-l-4 border-l-primary">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Connected Accounts
              </CardTitle>
              <Activity className="h-5 w-5 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{connectedAccounts}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Across {accountTypes.length} service types
              </p>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-green-500">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Active Agents
              </CardTitle>
              <Brain className="h-5 w-5 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{activeAgents}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {totalCapabilities} AI models available
              </p>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-blue-500">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                System Health
              </CardTitle>
              <TrendingUp className="h-5 w-5 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">100%</div>
              <p className="text-xs text-muted-foreground mt-1">
                All services operational
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Insights & Actions */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-xl flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-primary" />
                  Intelligent Insights
                </CardTitle>
                <CardDescription className="mt-1">
                  AI-powered analysis of your connected accounts
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {analysisLoading && (
              <div className="flex items-center justify-center p-8">
                <Clock className="h-6 w-6 animate-spin text-muted-foreground" />
                <span className="ml-2 text-muted-foreground">Analyzing accounts...</span>
              </div>
            )}
            {!analysisLoading && displayInsights.map((insight, index) => (
              <div
                key={index}
                className="flex items-start gap-4 p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
              >
                <div className={`p-2 rounded-md ${insight.color}`}>
                  <insight.icon className="h-5 w-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <p className="font-medium text-sm">{insight.title}</p>
                    <Badge variant={insight.priority === "high" ? "destructive" : insight.priority === "medium" ? "default" : "secondary"} className="text-xs">
                      {insight.priority}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{insight.description}</p>
                </div>
                <Button variant="outline" size="sm">
                  {insight.action}
                  <ArrowRight className="h-3 w-3 ml-1" />
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Account Types */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-xl">Connected Account Types</CardTitle>
                <CardDescription className="mt-1">
                  Manage your connected services and accounts
                </CardDescription>
              </div>
              <Button onClick={() => window.location.href = "/connectors"}>
                <Plus className="h-4 w-4 mr-2" />
                Connect Account
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-1 md:grid-cols-2">
              {accountTypes.map((type, index) => (
                <div
                  key={index}
                  className={`relative flex items-start gap-4 p-4 rounded-lg border ${type.bgColor} ${type.borderColor} hover:shadow-md transition-all cursor-pointer`}
                  onClick={() => !type.comingSoon && (window.location.href = type.path)}
                >
                  <div className={`p-3 rounded-md border ${type.bgColor} ${type.borderColor}`}>
                    <type.icon className={`h-6 w-6 ${type.color}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold">{type.name}</h3>
                      {type.comingSoon && (
                        <Badge variant="secondary" className="text-xs">Coming Soon</Badge>
                      )}
                      {type.connected > 0 && (
                        <Badge variant="default" className="text-xs bg-green-500/10 text-green-700 border-green-200">
                          {type.connected} connected
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">{type.description}</p>
                  </div>
                  {!type.comingSoon && (
                    <ArrowRight className="h-5 w-5 text-muted-foreground" />
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl">Quick Actions</CardTitle>
            <CardDescription>
              Common orchestrator operations
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 grid-cols-2 lg:grid-cols-4">
              <Button variant="outline" className="h-auto py-4 flex-col gap-2">
                <Mail className="h-5 w-5" />
                <span className="text-sm">Scan Emails</span>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2">
                <Calendar className="h-5 w-5" />
                <span className="text-sm">Optimize Calendar</span>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2">
                <Brain className="h-5 w-5" />
                <span className="text-sm">Run Analysis</span>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2">
                <Activity className="h-5 w-5" />
                <span className="text-sm">View Activity</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
