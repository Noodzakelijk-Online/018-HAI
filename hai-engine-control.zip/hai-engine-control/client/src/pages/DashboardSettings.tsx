/**
 * Dashboard Settings Page
 * 
 * Allows users to customize their HAI dashboard experience:
 * - Widget layout and visibility
 * - Theme preferences
 * - Notification settings
 * - Data refresh intervals
 * - Accessibility options
 */

import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";
import { toast } from "sonner";
import { 
  LayoutDashboard, 
  Bell, 
  Palette, 
  RefreshCw, 
  Accessibility,
  Monitor,
  Smartphone,
  Tablet,
  Save,
  RotateCcw
} from "lucide-react";

interface WidgetConfig {
  id: string;
  name: string;
  enabled: boolean;
  size: 'small' | 'medium' | 'large';
}

interface DashboardConfig {
  widgets: WidgetConfig[];
  refreshInterval: number;
  theme: 'light' | 'dark' | 'system';
  compactMode: boolean;
  showAnimations: boolean;
  notifications: {
    desktop: boolean;
    sound: boolean;
    email: boolean;
    urgentOnly: boolean;
  };
  accessibility: {
    highContrast: boolean;
    largeText: boolean;
    reduceMotion: boolean;
    screenReaderOptimized: boolean;
  };
}

const defaultConfig: DashboardConfig = {
  widgets: [
    { id: 'action-feed', name: 'Action Feed', enabled: true, size: 'large' },
    { id: 'quick-actions', name: 'Quick Actions', enabled: true, size: 'medium' },
    { id: 'calendar', name: 'Calendar Overview', enabled: true, size: 'medium' },
    { id: 'financial', name: 'Financial Summary', enabled: true, size: 'medium' },
    { id: 'household', name: 'Household Status', enabled: true, size: 'small' },
    { id: 'notifications', name: 'Recent Notifications', enabled: true, size: 'small' },
    { id: 'agents', name: 'Active Agents', enabled: false, size: 'medium' },
    { id: 'analytics', name: 'Analytics', enabled: false, size: 'large' },
  ],
  refreshInterval: 30,
  theme: 'dark',
  compactMode: false,
  showAnimations: true,
  notifications: {
    desktop: true,
    sound: false,
    email: true,
    urgentOnly: false,
  },
  accessibility: {
    highContrast: false,
    largeText: false,
    reduceMotion: false,
    screenReaderOptimized: false,
  },
};

export default function DashboardSettings() {
  const [config, setConfig] = useState<DashboardConfig>(defaultConfig);
  const [hasChanges, setHasChanges] = useState(false);

  const updateConfig = <K extends keyof DashboardConfig>(
    key: K,
    value: DashboardConfig[K]
  ) => {
    setConfig(prev => ({ ...prev, [key]: value }));
    setHasChanges(true);
  };

  const updateWidget = (widgetId: string, updates: Partial<WidgetConfig>) => {
    setConfig(prev => ({
      ...prev,
      widgets: prev.widgets.map(w => 
        w.id === widgetId ? { ...w, ...updates } : w
      ),
    }));
    setHasChanges(true);
  };

  const updateNotifications = (key: keyof DashboardConfig['notifications'], value: boolean) => {
    setConfig(prev => ({
      ...prev,
      notifications: { ...prev.notifications, [key]: value },
    }));
    setHasChanges(true);
  };

  const updateAccessibility = (key: keyof DashboardConfig['accessibility'], value: boolean) => {
    setConfig(prev => ({
      ...prev,
      accessibility: { ...prev.accessibility, [key]: value },
    }));
    setHasChanges(true);
  };

  const saveSettings = () => {
    // In real implementation, save to backend
    localStorage.setItem('hai-dashboard-config', JSON.stringify(config));
    setHasChanges(false);
    toast.success('Dashboard settings saved');
  };

  const resetSettings = () => {
    setConfig(defaultConfig);
    setHasChanges(true);
    toast.info('Settings reset to defaults');
  };

  return (
    <DashboardLayout>
      <div className="p-4 md:p-6 space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">Dashboard Settings</h1>
            <p className="text-muted-foreground mt-1">
              Customize your HAI dashboard experience
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={resetSettings}>
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset
            </Button>
            <Button onClick={saveSettings} disabled={!hasChanges}>
              <Save className="h-4 w-4 mr-2" />
              Save Changes
            </Button>
          </div>
        </div>

        {/* Settings Tabs */}
        <Tabs defaultValue="layout" className="space-y-4">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 h-auto">
            <TabsTrigger value="layout" className="flex items-center gap-2 py-2">
              <LayoutDashboard className="h-4 w-4" />
              <span className="hidden sm:inline">Layout</span>
            </TabsTrigger>
            <TabsTrigger value="appearance" className="flex items-center gap-2 py-2">
              <Palette className="h-4 w-4" />
              <span className="hidden sm:inline">Appearance</span>
            </TabsTrigger>
            <TabsTrigger value="notifications" className="flex items-center gap-2 py-2">
              <Bell className="h-4 w-4" />
              <span className="hidden sm:inline">Notifications</span>
            </TabsTrigger>
            <TabsTrigger value="performance" className="flex items-center gap-2 py-2">
              <RefreshCw className="h-4 w-4" />
              <span className="hidden sm:inline">Performance</span>
            </TabsTrigger>
            <TabsTrigger value="accessibility" className="flex items-center gap-2 py-2">
              <Accessibility className="h-4 w-4" />
              <span className="hidden sm:inline">Accessibility</span>
            </TabsTrigger>
          </TabsList>

          {/* Layout Tab */}
          <TabsContent value="layout" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Widget Configuration</CardTitle>
                <CardDescription>
                  Choose which widgets to display and their sizes
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {config.widgets.map(widget => (
                  <div 
                    key={widget.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 border rounded-lg"
                  >
                    <div className="flex items-center gap-4">
                      <Switch
                        checked={widget.enabled}
                        onCheckedChange={(checked) => updateWidget(widget.id, { enabled: checked })}
                      />
                      <Label className="font-medium">{widget.name}</Label>
                    </div>
                    <Select
                      value={widget.size}
                      onValueChange={(value: 'small' | 'medium' | 'large') => 
                        updateWidget(widget.id, { size: value })
                      }
                      disabled={!widget.enabled}
                    >
                      <SelectTrigger className="w-full sm:w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="small">Small</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="large">Large</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Responsive Preview</CardTitle>
                <CardDescription>
                  See how your dashboard looks on different devices
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4 justify-center">
                  <Button variant="outline" size="sm">
                    <Smartphone className="h-4 w-4 mr-2" />
                    Mobile
                  </Button>
                  <Button variant="outline" size="sm">
                    <Tablet className="h-4 w-4 mr-2" />
                    Tablet
                  </Button>
                  <Button variant="outline" size="sm">
                    <Monitor className="h-4 w-4 mr-2" />
                    Desktop
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Appearance Tab */}
          <TabsContent value="appearance" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Theme Settings</CardTitle>
                <CardDescription>
                  Customize the look and feel of your dashboard
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label>Color Theme</Label>
                  <Select
                    value={config.theme}
                    onValueChange={(value: 'light' | 'dark' | 'system') => 
                      updateConfig('theme', value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">Light</SelectItem>
                      <SelectItem value="dark">Dark</SelectItem>
                      <SelectItem value="system">System</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Compact Mode</Label>
                    <p className="text-sm text-muted-foreground">
                      Reduce spacing for more content
                    </p>
                  </div>
                  <Switch
                    checked={config.compactMode}
                    onCheckedChange={(checked) => updateConfig('compactMode', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Show Animations</Label>
                    <p className="text-sm text-muted-foreground">
                      Enable smooth transitions and effects
                    </p>
                  </div>
                  <Switch
                    checked={config.showAnimations}
                    onCheckedChange={(checked) => updateConfig('showAnimations', checked)}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notifications Tab */}
          <TabsContent value="notifications" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Notification Preferences</CardTitle>
                <CardDescription>
                  Control how and when you receive notifications
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Desktop Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      Show browser notifications
                    </p>
                  </div>
                  <Switch
                    checked={config.notifications.desktop}
                    onCheckedChange={(checked) => updateNotifications('desktop', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Sound Alerts</Label>
                    <p className="text-sm text-muted-foreground">
                      Play sound for new notifications
                    </p>
                  </div>
                  <Switch
                    checked={config.notifications.sound}
                    onCheckedChange={(checked) => updateNotifications('sound', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Email Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      Receive important updates via email
                    </p>
                  </div>
                  <Switch
                    checked={config.notifications.email}
                    onCheckedChange={(checked) => updateNotifications('email', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Urgent Only</Label>
                    <p className="text-sm text-muted-foreground">
                      Only notify for urgent matters
                    </p>
                  </div>
                  <Switch
                    checked={config.notifications.urgentOnly}
                    onCheckedChange={(checked) => updateNotifications('urgentOnly', checked)}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Performance Tab */}
          <TabsContent value="performance" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Data Refresh Settings</CardTitle>
                <CardDescription>
                  Control how often data is refreshed
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <Label>Auto-refresh Interval</Label>
                    <span className="text-sm text-muted-foreground">
                      {config.refreshInterval} seconds
                    </span>
                  </div>
                  <Slider
                    value={[config.refreshInterval]}
                    onValueChange={([value]) => updateConfig('refreshInterval', value)}
                    min={5}
                    max={120}
                    step={5}
                  />
                  <p className="text-xs text-muted-foreground">
                    Lower values mean more up-to-date data but higher battery usage
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Accessibility Tab */}
          <TabsContent value="accessibility" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Accessibility Options</CardTitle>
                <CardDescription>
                  Make HAI easier to use for everyone
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>High Contrast</Label>
                    <p className="text-sm text-muted-foreground">
                      Increase color contrast for better visibility
                    </p>
                  </div>
                  <Switch
                    checked={config.accessibility.highContrast}
                    onCheckedChange={(checked) => updateAccessibility('highContrast', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Large Text</Label>
                    <p className="text-sm text-muted-foreground">
                      Increase text size throughout the app
                    </p>
                  </div>
                  <Switch
                    checked={config.accessibility.largeText}
                    onCheckedChange={(checked) => updateAccessibility('largeText', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Reduce Motion</Label>
                    <p className="text-sm text-muted-foreground">
                      Minimize animations and transitions
                    </p>
                  </div>
                  <Switch
                    checked={config.accessibility.reduceMotion}
                    onCheckedChange={(checked) => updateAccessibility('reduceMotion', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Screen Reader Optimized</Label>
                    <p className="text-sm text-muted-foreground">
                      Enhance compatibility with screen readers
                    </p>
                  </div>
                  <Switch
                    checked={config.accessibility.screenReaderOptimized}
                    onCheckedChange={(checked) => updateAccessibility('screenReaderOptimized', checked)}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
