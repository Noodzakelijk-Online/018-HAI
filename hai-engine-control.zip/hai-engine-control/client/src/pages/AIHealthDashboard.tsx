import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Activity,
  AlertCircle,
  AlertTriangle,
  Bell,
  BellRing,
  Brain,
  CheckCircle,
  CheckCircle2,
  Clock,
  Cpu,
  FileText,
  GitBranch,
  History,
  Layers,
  Network,
  RefreshCw,
  Settings,
  Shield,
  Target,
  TrendingDown,
  TrendingUp,
  Zap,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

// Service icon mapping
const serviceIcons: Record<string, React.ReactNode> = {
  'activity-intelligence': <Activity className="h-5 w-5" />,
  'engine-orchestration': <Layers className="h-5 w-5" />,
  'temporal-intelligence': <Clock className="h-5 w-5" />,
  'context-awareness': <Brain className="h-5 w-5" />,
  'meta-learning': <GitBranch className="h-5 w-5" />,
  'multi-agent': <Network className="h-5 w-5" />,
  'causal-reasoning': <Target className="h-5 w-5" />,
  'uncertainty': <AlertTriangle className="h-5 w-5" />,
  'explainability': <FileText className="h-5 w-5" />,
  'continual-learning': <Zap className="h-5 w-5" />,
};

// Status colors
const statusColors: Record<string, string> = {
  healthy: 'bg-green-500',
  degraded: 'bg-yellow-500',
  unhealthy: 'bg-red-500',
  unknown: 'bg-gray-500',
};

const statusBadgeVariants: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
  healthy: 'default',
  degraded: 'secondary',
  unhealthy: 'destructive',
  unknown: 'outline',
};

// Trend icons
const TrendIcon = ({ trend }: { trend: 'improving' | 'stable' | 'declining' }) => {
  if (trend === 'improving') return <TrendingUp className="h-4 w-4 text-green-500" />;
  if (trend === 'declining') return <TrendingDown className="h-4 w-4 text-red-500" />;
  return <span className="h-4 w-4 text-gray-400">—</span>;
};

// Chart colors
const COLORS = ['#22c55e', '#eab308', '#ef4444', '#6b7280'];

export default function AIHealthDashboard() {
  const [activeTab, setActiveTab] = useState('overview');
  
  // Fetch dashboard data with auto-refresh
  const { data: dashboardData, isLoading, refetch } = trpc.aiMonitor.getDashboard.useQuery(
    undefined,
    { refetchInterval: 5000 } // Refresh every 5 seconds
  );

  // Fetch real-time activity
  const { data: realtimeActivity } = trpc.aiMonitor.getRealtimeActivity.useQuery(
    { limit: 20 },
    { refetchInterval: 3000 }
  );

  // Fetch alert data
  const { data: alertRules } = trpc.aiMonitor.getAlertRules.useQuery();
  const { data: recentAlerts, refetch: refetchAlerts } = trpc.aiMonitor.getRecentAlerts.useQuery(
    { limit: 50, includeAcknowledged: true },
    { refetchInterval: 10000 }
  );
  const { data: unacknowledgedCount } = trpc.aiMonitor.getUnacknowledgedAlertCount.useQuery(
    undefined,
    { refetchInterval: 5000 }
  );
  const { data: alertStats } = trpc.aiMonitor.getAlertStats.useQuery();

  // Fetch historical data
  const { data: systemHealthTrend } = trpc.aiMonitor.getSystemHealthTrend.useQuery(
    { hours: 24 },
    { refetchInterval: 60000 }
  );
  const { data: metricsSummary } = trpc.aiMonitor.getMetricsSummary.useQuery();

  // Mutations
  const acknowledgeAlertMutation = trpc.aiMonitor.acknowledgeAlert.useMutation({
    onSuccess: () => refetchAlerts(),
  });
  const acknowledgeAllMutation = trpc.aiMonitor.acknowledgeAllAlerts.useMutation({
    onSuccess: () => refetchAlerts(),
  });
  const updateAlertRuleMutation = trpc.aiMonitor.updateAlertRule.useMutation();

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="space-y-6 p-6">
          <Skeleton className="h-8 w-64" />
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map(i => (
              <Skeleton key={i} className="h-32" />
            ))}
          </div>
          <Skeleton className="h-96" />
        </div>
      </DashboardLayout>
    );
  }

  const { summary, services, performance, reliability, compliance } = dashboardData || {};

  // Prepare chart data
  const serviceStatusData = [
    { name: 'Healthy', value: summary?.healthyServices || 0 },
    { name: 'Degraded', value: summary?.degradedServices || 0 },
    { name: 'Unhealthy', value: summary?.unhealthyServices || 0 },
  ].filter(d => d.value > 0);

  const performanceData = services?.map(s => ({
    name: s.name.split(' ')[0],
    responseTime: s.responseTime,
    successRate: s.metrics.successRate,
    requests: s.metrics.requestsPerMinute,
  })) || [];

  return (
    <DashboardLayout>
      <div className="space-y-6 p-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Cpu className="h-7 w-7 text-primary" />
              AI Health Monitor
            </h1>
            <p className="text-muted-foreground">
              Real-time monitoring of all 10 AI intelligence services
            </p>
          </div>
          <Button variant="outline" size="sm" onClick={() => refetch()}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Overall Health */}
          <Card className={`border-l-4 ${
            summary?.overallHealth === 'healthy' ? 'border-l-green-500' :
            summary?.overallHealth === 'degraded' ? 'border-l-yellow-500' : 'border-l-red-500'
          }`}>
            <CardHeader className="pb-2">
              <CardDescription>Overall Health</CardDescription>
              <CardTitle className="text-2xl flex items-center gap-2">
                {summary?.overallHealth === 'healthy' ? (
                  <CheckCircle className="h-6 w-6 text-green-500" />
                ) : summary?.overallHealth === 'degraded' ? (
                  <AlertTriangle className="h-6 w-6 text-yellow-500" />
                ) : (
                  <AlertCircle className="h-6 w-6 text-red-500" />
                )}
                <span className="capitalize">{summary?.overallHealth || 'Unknown'}</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                {summary?.healthyServices}/{summary?.totalServices} services healthy
              </p>
            </CardContent>
          </Card>

          {/* Uptime */}
          <Card className="border-l-4 border-l-blue-500">
            <CardHeader className="pb-2">
              <CardDescription>System Uptime</CardDescription>
              <CardTitle className="text-2xl">
                {summary?.uptime?.toFixed(2)}%
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Progress value={summary?.uptime || 0} className="h-2" />
            </CardContent>
          </Card>

          {/* Decision Accuracy */}
          <Card className="border-l-4 border-l-purple-500">
            <CardHeader className="pb-2">
              <CardDescription>Decision Accuracy</CardDescription>
              <CardTitle className="text-2xl flex items-center gap-2">
                {summary?.decisionAccuracy?.toFixed(1)}%
                <TrendIcon trend={performance?.trends.accuracy || 'stable'} />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Based on outcome validation
              </p>
            </CardContent>
          </Card>

          {/* Compliance Score */}
          <Card className="border-l-4 border-l-green-500">
            <CardHeader className="pb-2">
              <CardDescription>Compliance Score</CardDescription>
              <CardTitle className="text-2xl flex items-center gap-2">
                <Shield className="h-5 w-5 text-green-500" />
                {summary?.complianceScore?.toFixed(1)}%
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                {compliance?.explainedDecisions}/{compliance?.totalDecisions} decisions explained
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="services">Services</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="reliability">Reliability</TabsTrigger>
            <TabsTrigger value="compliance">Compliance</TabsTrigger>
            <TabsTrigger value="alerts" className="relative">
              Alerts
              {(unacknowledgedCount ?? 0) > 0 && (
                <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center">
                  {unacknowledgedCount}
                </span>
              )}
            </TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* Service Status Distribution */}
              <Card>
                <CardHeader>
                  <CardTitle>Service Status Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={serviceStatusData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={5}
                          dataKey="value"
                          label={({ name, value }) => `${name}: ${value}`}
                        >
                          {serviceStatusData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Response Time by Service */}
              <Card>
                <CardHeader>
                  <CardTitle>Response Time by Service</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={performanceData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="responseTime" fill="#8884d8" name="Response Time (ms)" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Real-time Activity Feed */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  Real-time Activity Feed
                </CardTitle>
                <CardDescription>Live AI decisions and actions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-80 overflow-y-auto">
                  {realtimeActivity?.map((activity, i) => (
                    <div
                      key={activity.id || i}
                      className="flex items-center justify-between p-3 bg-muted/50 rounded-lg"
                    >
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-full ${
                          activity.status === 'success' ? 'bg-green-100 text-green-600' :
                          activity.status === 'failure' ? 'bg-red-100 text-red-600' :
                          'bg-yellow-100 text-yellow-600'
                        }`}>
                          {serviceIcons[activity.service] || <Activity className="h-4 w-4" />}
                        </div>
                        <div>
                          <p className="font-medium text-sm">{activity.action}</p>
                          <p className="text-xs text-muted-foreground">{activity.details}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant={
                          activity.status === 'success' ? 'default' :
                          activity.status === 'failure' ? 'destructive' : 'secondary'
                        }>
                          {activity.status}
                        </Badge>
                        <p className="text-xs text-muted-foreground mt-1">
                          {activity.duration}ms
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Services Tab */}
          <TabsContent value="services" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {services?.map(service => (
                <Card key={service.id} className="relative overflow-hidden">
                  <div className={`absolute top-0 left-0 w-1 h-full ${statusColors[service.status]}`} />
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {serviceIcons[service.id] || <Cpu className="h-5 w-5" />}
                        <CardTitle className="text-base">{service.name}</CardTitle>
                      </div>
                      <Badge variant={statusBadgeVariants[service.status]}>
                        {service.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <p className="text-muted-foreground">Response Time</p>
                        <p className="font-medium">{service.responseTime.toFixed(1)}ms</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Success Rate</p>
                        <p className="font-medium">{service.metrics.successRate.toFixed(1)}%</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Requests/min</p>
                        <p className="font-medium">{service.metrics.requestsPerMinute}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Error Rate</p>
                        <p className="font-medium">{service.errorRate.toFixed(2)}%</p>
                      </div>
                    </div>
                    <Progress value={service.uptime} className="h-1" />
                    <p className="text-xs text-muted-foreground">
                      Uptime: {service.uptime.toFixed(2)}%
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Performance Tab */}
          <TabsContent value="performance" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Decision Accuracy</CardDescription>
                  <CardTitle className="text-3xl flex items-center gap-2">
                    {performance?.decisionAccuracy.toFixed(1)}%
                    <TrendIcon trend={performance?.trends.accuracy || 'stable'} />
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Progress value={performance?.decisionAccuracy || 0} className="h-2" />
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Avg Response Time</CardDescription>
                  <CardTitle className="text-3xl flex items-center gap-2">
                    {performance?.avgResponseTime.toFixed(1)}ms
                    <TrendIcon trend={performance?.trends.latency || 'stable'} />
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Target: &lt;100ms
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Throughput</CardDescription>
                  <CardTitle className="text-3xl flex items-center gap-2">
                    {performance?.throughput.toFixed(0)}/min
                    <TrendIcon trend={performance?.trends.throughput || 'stable'} />
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Peak: {performance?.peakLoad.toFixed(0)}/min
                  </p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Success Rate by Service</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={performanceData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                      <YAxis domain={[90, 100]} />
                      <Tooltip />
                      <Area
                        type="monotone"
                        dataKey="successRate"
                        stroke="#22c55e"
                        fill="#22c55e"
                        fillOpacity={0.3}
                        name="Success Rate (%)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Reliability Tab */}
          <TabsContent value="reliability" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Overall Availability</CardDescription>
                  <CardTitle className="text-3xl">
                    {reliability?.overallAvailability.toFixed(2)}%
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Progress value={reliability?.overallAvailability || 0} className="h-2" />
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Mean Time Between Failures</CardDescription>
                  <CardTitle className="text-3xl">
                    {reliability?.meanTimeBetweenFailures.toFixed(1)}h
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">Target: &gt;168h</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Mean Time to Recovery</CardDescription>
                  <CardTitle className="text-3xl">
                    {reliability?.meanTimeToRecovery.toFixed(1)}min
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">Target: &lt;5min</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Retry Success Rate</CardDescription>
                  <CardTitle className="text-3xl">
                    {reliability?.retrySuccessRate.toFixed(1)}%
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Progress value={reliability?.retrySuccessRate || 0} className="h-2" />
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Reliability Events</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 bg-muted/50 rounded-lg text-center">
                    <p className="text-3xl font-bold">{reliability?.fallbackActivations}</p>
                    <p className="text-sm text-muted-foreground">Fallback Activations</p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg text-center">
                    <p className="text-3xl font-bold">{reliability?.circuitBreakerTrips}</p>
                    <p className="text-sm text-muted-foreground">Circuit Breaker Trips</p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg text-center">
                    <p className="text-3xl font-bold">{reliability?.degradedModeActivations}</p>
                    <p className="text-sm text-muted-foreground">Degraded Mode Activations</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Compliance Tab */}
          <TabsContent value="compliance" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Compliance Score</CardDescription>
                  <CardTitle className="text-3xl text-green-500">
                    {compliance?.complianceScore.toFixed(1)}%
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Progress value={compliance?.complianceScore || 0} className="h-2" />
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Explained Decisions</CardDescription>
                  <CardTitle className="text-3xl">
                    {compliance?.explainedDecisions}/{compliance?.totalDecisions}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    {((compliance?.explainedDecisions || 0) / (compliance?.totalDecisions || 1) * 100).toFixed(1)}% coverage
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Overridden Decisions</CardDescription>
                  <CardTitle className="text-3xl">
                    {compliance?.overriddenDecisions}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Human corrections applied
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Pending Reviews</CardDescription>
                  <CardTitle className="text-3xl">
                    {compliance?.pendingReviews}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Awaiting human review
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Audit Log */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Recent Audit Events
                </CardTitle>
                <CardDescription>
                  Decision audit trail for compliance tracking
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {compliance?.recentAuditEvents.map((event, i) => (
                    <div
                      key={event.id || i}
                      className="p-4 border rounded-lg space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {serviceIcons[event.service] || <Activity className="h-4 w-4" />}
                          <span className="font-medium">{event.action}</span>
                          {event.overridden && (
                            <Badge variant="secondary">Overridden</Badge>
                          )}
                        </div>
                        <span className="text-sm text-muted-foreground">
                          {new Date(event.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      <p className="text-sm">{event.decision}</p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span>Confidence: {(event.confidence * 100).toFixed(0)}%</span>
                        <span>Service: {event.service}</span>
                      </div>
                      <p className="text-xs text-muted-foreground italic">
                        Explanation: {event.explanation}
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Alerts Tab */}
          <TabsContent value="alerts" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* Alert Stats */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Bell className="h-5 w-5" />
                    Alert Summary
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Total Alerts</span>
                      <span className="font-semibold">{alertStats?.total || 0}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Unacknowledged</span>
                      <span className="font-semibold text-red-500">{alertStats?.unacknowledged || 0}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Last 24 Hours</span>
                      <span className="font-semibold">{alertStats?.last24Hours || 0}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Alerts by Severity */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">By Severity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {['critical', 'error', 'warning', 'info'].map(severity => (
                      <div key={severity} className="flex justify-between items-center">
                        <Badge variant={severity === 'critical' || severity === 'error' ? 'destructive' : severity === 'warning' ? 'secondary' : 'outline'}>
                          {severity}
                        </Badge>
                        <span className="font-semibold">{alertStats?.bySeverity?.[severity] || 0}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => acknowledgeAllMutation.mutate()}
                    disabled={!unacknowledgedCount || acknowledgeAllMutation.isPending}
                  >
                    <CheckCircle2 className="h-4 w-4 mr-2" />
                    Acknowledge All ({unacknowledgedCount || 0})
                  </Button>
                  <Button variant="outline" className="w-full justify-start" onClick={() => refetchAlerts()}>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Refresh Alerts
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Alert Rules */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Alert Rules
                </CardTitle>
                <CardDescription>Configure thresholds and notification channels</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {alertRules?.map(rule => (
                    <div
                      key={rule.ruleId}
                      className={`p-4 border rounded-lg flex items-center justify-between ${!rule.enabled ? 'opacity-50' : ''}`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{rule.name}</span>
                          <Badge variant={rule.severity === 'critical' || rule.severity === 'error' ? 'destructive' : rule.severity === 'warning' ? 'secondary' : 'outline'}>
                            {rule.severity}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {rule.condition.replace(/_/g, ' ')} {rule.threshold}
                          {rule.serviceId === '*' ? ' (All Services)' : ` (${rule.serviceId})`}
                        </p>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <span>Channels: {rule.channels?.join(', ') || 'None'}</span>
                          <span>•</span>
                          <span>Cooldown: {rule.cooldownMinutes}min</span>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => updateAlertRuleMutation.mutate({
                          ruleId: rule.ruleId,
                          updates: { enabled: !rule.enabled }
                        })}
                      >
                        {rule.enabled ? 'Disable' : 'Enable'}
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recent Alerts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BellRing className="h-5 w-5" />
                  Recent Alerts
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {recentAlerts?.length === 0 ? (
                    <p className="text-center text-muted-foreground py-8">No alerts yet</p>
                  ) : (
                    recentAlerts?.map(alert => (
                      <div
                        key={alert.id}
                        className={`p-4 border rounded-lg space-y-2 ${!alert.acknowledged ? 'border-l-4 border-l-red-500' : ''}`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Badge variant={alert.severity === 'critical' || alert.severity === 'error' ? 'destructive' : alert.severity === 'warning' ? 'secondary' : 'outline'}>
                              {alert.severity}
                            </Badge>
                            <span className="font-medium">{alert.title}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm text-muted-foreground">
                              {new Date(alert.createdAt).toLocaleString()}
                            </span>
                            {!alert.acknowledged && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => acknowledgeAlertMutation.mutate({ alertId: alert.id })}
                                disabled={acknowledgeAlertMutation.isPending}
                              >
                                <CheckCircle2 className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground whitespace-pre-line">{alert.message}</p>
                        {alert.acknowledged && (
                          <p className="text-xs text-muted-foreground">
                            Acknowledged by {alert.acknowledgedBy} at {new Date(alert.acknowledgedAt!).toLocaleString()}
                          </p>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* Metrics Summary */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <History className="h-5 w-5" />
                    Data Summary
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Total Data Points</span>
                      <span className="font-semibold">{metricsSummary?.totalDataPoints?.toLocaleString() || 0}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Services Tracked</span>
                      <span className="font-semibold">{metricsSummary?.servicesTracked || 0}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Oldest Record</span>
                      <span className="font-semibold text-sm">
                        {metricsSummary?.oldestRecord ? new Date(metricsSummary.oldestRecord).toLocaleDateString() : 'N/A'}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Data by Aggregation */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Data by Type</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {['raw', 'hour', 'day'].map(type => (
                      <div key={type} className="flex justify-between items-center">
                        <span className="text-muted-foreground capitalize">{type}</span>
                        <span className="font-semibold">
                          {metricsSummary?.dataByAggregation?.[type]?.toLocaleString() || 0}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* System Trend */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">24h Trend</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-center py-4">
                    <div className="text-center">
                      <TrendIcon trend={systemHealthTrend?.overallTrend || 'stable'} />
                      <p className="text-2xl font-bold capitalize mt-2">
                        {systemHealthTrend?.overallTrend || 'Stable'}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {systemHealthTrend?.dataPoints?.length || 0} data points
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* System Health Trend Chart */}
            <Card>
              <CardHeader>
                <CardTitle>System Health Over Time (24h)</CardTitle>
                <CardDescription>Average uptime, response time, and error rate across all services</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  {systemHealthTrend?.dataPoints && systemHealthTrend.dataPoints.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={systemHealthTrend.dataPoints.map(p => ({
                        ...p,
                        time: new Date(p.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                      }))}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                        <XAxis dataKey="time" className="text-xs" />
                        <YAxis yAxisId="left" className="text-xs" />
                        <YAxis yAxisId="right" orientation="right" className="text-xs" />
                        <Tooltip
                          contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}
                        />
                        <Line
                          yAxisId="left"
                          type="monotone"
                          dataKey="avgUptime"
                          stroke="#22c55e"
                          strokeWidth={2}
                          dot={false}
                          name="Uptime %"
                        />
                        <Line
                          yAxisId="right"
                          type="monotone"
                          dataKey="avgResponseTime"
                          stroke="#3b82f6"
                          strokeWidth={2}
                          dot={false}
                          name="Response Time (ms)"
                        />
                        <Line
                          yAxisId="left"
                          type="monotone"
                          dataKey="avgErrorRate"
                          stroke="#ef4444"
                          strokeWidth={2}
                          dot={false}
                          name="Error Rate %"
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="flex items-center justify-center h-full text-muted-foreground">
                      <div className="text-center">
                        <History className="h-12 w-12 mx-auto mb-4 opacity-50" />
                        <p>No historical data available yet</p>
                        <p className="text-sm">Data will appear as metrics are collected</p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Retention Policy Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Data Retention Policy</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                  <div className="p-4 border rounded-lg">
                    <p className="text-2xl font-bold">7 Days</p>
                    <p className="text-sm text-muted-foreground">Raw data (per minute)</p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <p className="text-2xl font-bold">30 Days</p>
                    <p className="text-sm text-muted-foreground">Hourly aggregates</p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <p className="text-2xl font-bold">1 Year</p>
                    <p className="text-sm text-muted-foreground">Daily aggregates</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
