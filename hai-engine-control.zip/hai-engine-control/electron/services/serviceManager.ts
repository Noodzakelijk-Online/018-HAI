import { ChildProcess, fork, spawn } from 'child_process';
import * as path from 'path';
import { app } from 'electron';
import fetch from 'node-fetch';

interface ServiceStatus {
  backend: boolean;
  fara: boolean;
  database: boolean;
}

export class ServiceManager {
  private services: Map<string, ChildProcess> = new Map();
  private status: ServiceStatus = {
    backend: false,
    fara: false,
    database: false
  };

  async startAll() {
    console.log('[ServiceManager] Starting all services...');
    
    // Start services in order
    await this.startDatabase();
    await this.startBackend();
    // Fara-7B will be started on-demand when first task is submitted
    
    console.log('[ServiceManager] All services started');
  }

  async startDatabase() {
    console.log('[ServiceManager] Initializing database...');
    
    // Database is SQLite - just check if file exists
    const dbPath = path.join(app.getPath('userData'), 'data', 'database.sqlite');
    
    try {
      const fs = require('fs');
      const dir = path.dirname(dbPath);
      
      // Create data directory if it doesn't exist
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      
      // Database will be created automatically by Drizzle on first use
      this.status.database = true;
      console.log('[ServiceManager] Database initialized at:', dbPath);
    } catch (error) {
      console.error('[ServiceManager] Database initialization failed:', error);
      throw error;
    }
  }

  async startBackend() {
    console.log('[ServiceManager] Starting backend server...');
    
    try {
      // Get the backend entry point
      const isDev = process.env.NODE_ENV === 'development';
      const backendPath = isDev
        ? path.join(__dirname, '../../server/_core/index.ts')
        : path.join(process.resourcesPath, 'app', 'server', '_core', 'index.js');
      
      // Set environment variables for desktop mode
      const env = {
        ...process.env,
        NODE_ENV: isDev ? 'development' : 'production',
        DATABASE_URL: `sqlite:${path.join(app.getPath('userData'), 'data', 'database.sqlite')}`,
        PORT: '3000',
        DESKTOP_MODE: 'true'
      };
      
      // Start backend process
      const backendProcess = isDev
        ? spawn('tsx', ['watch', backendPath], { env, cwd: path.join(__dirname, '../..') })
        : fork(backendPath, [], { env });
      
      backendProcess.stdout?.on('data', (data) => {
        console.log(`[Backend] ${data.toString().trim()}`);
      });
      
      backendProcess.stderr?.on('data', (data) => {
        console.error(`[Backend Error] ${data.toString().trim()}`);
      });
      
      backendProcess.on('error', (error) => {
        console.error('[Backend] Process error:', error);
        this.status.backend = false;
      });
      
      backendProcess.on('exit', (code) => {
        console.log(`[Backend] Process exited with code ${code}`);
        this.status.backend = false;
      });
      
      this.services.set('backend', backendProcess);
      
      // Wait for backend to be ready
      await this.waitForService('http://localhost:3000/api/health', 30000);
      
      this.status.backend = true;
      console.log('[ServiceManager] Backend server started successfully');
    } catch (error) {
      console.error('[ServiceManager] Failed to start backend:', error);
      throw error;
    }
  }

  async startFara() {
    console.log('[ServiceManager] Starting Fara-7B service...');
    
    try {
      // Check if Python and Fara-7B are installed
      const pythonPath = path.join(app.getPath('userData'), 'python', 'python.exe');
      const modelPath = path.join(app.getPath('userData'), 'models', 'Fara-7B');
      
      const fs = require('fs');
      if (!fs.existsSync(pythonPath)) {
        console.log('[ServiceManager] Python not installed yet. Fara-7B will be available after setup.');
        return;
      }
      
      if (!fs.existsSync(modelPath)) {
        console.log('[ServiceManager] Fara-7B model not downloaded yet. Will download on first use.');
        return;
      }
      
      // Start vLLM server
      const faraProcess = spawn(pythonPath, [
        '-m', 'vllm.entrypoints.openai.api_server',
        '--model', modelPath,
        '--port', '5000',
        '--dtype', 'auto',
        '--max-model-len', '4096'
      ]);
      
      faraProcess.stdout?.on('data', (data) => {
        console.log(`[Fara-7B] ${data.toString().trim()}`);
      });
      
      faraProcess.stderr?.on('data', (data) => {
        console.error(`[Fara-7B Error] ${data.toString().trim()}`);
      });
      
      faraProcess.on('error', (error) => {
        console.error('[Fara-7B] Process error:', error);
        this.status.fara = false;
      });
      
      faraProcess.on('exit', (code) => {
        console.log(`[Fara-7B] Process exited with code ${code}`);
        this.status.fara = false;
      });
      
      this.services.set('fara', faraProcess);
      
      // Wait for Fara-7B to be ready
      await this.waitForService('http://localhost:5000/health', 60000);
      
      this.status.fara = true;
      console.log('[ServiceManager] Fara-7B service started successfully');
    } catch (error) {
      console.error('[ServiceManager] Failed to start Fara-7B:', error);
      // Don't throw - Fara-7B is optional
    }
  }

  async stopAll() {
    console.log('[ServiceManager] Stopping all services...');
    
    for (const [name, process] of this.services) {
      console.log(`[ServiceManager] Stopping ${name}...`);
      process.kill();
    }
    
    this.services.clear();
    this.status = {
      backend: false,
      fara: false,
      database: false
    };
    
    console.log('[ServiceManager] All services stopped');
  }

  async restart(serviceName: string) {
    console.log(`[ServiceManager] Restarting ${serviceName}...`);
    
    const process = this.services.get(serviceName);
    if (process) {
      process.kill();
      this.services.delete(serviceName);
    }
    
    switch (serviceName) {
      case 'backend':
        await this.startBackend();
        break;
      case 'fara':
        await this.startFara();
        break;
      case 'database':
        await this.startDatabase();
        break;
    }
    
    console.log(`[ServiceManager] ${serviceName} restarted`);
  }

  async restartAll() {
    await this.stopAll();
    await this.startAll();
  }

  getStatus(): ServiceStatus {
    return { ...this.status };
  }

  private async waitForService(url: string, timeout: number = 30000): Promise<void> {
    const startTime = Date.now();
    
    while (Date.now() - startTime < timeout) {
      try {
        const response = await fetch(url);
        if (response.ok) {
          return;
        }
      } catch (error) {
        // Service not ready yet, continue waiting
      }
      
      // Wait 1 second before trying again
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
    
    throw new Error(`Service at ${url} did not become ready within ${timeout}ms`);
  }
}
