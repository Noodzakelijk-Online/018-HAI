import { contextBridge, ipcRenderer } from 'electron';

// Expose protected methods that allow the renderer process to use
// the ipcRenderer without exposing the entire object
contextBridge.exposeInMainWorld('electronAPI', {
  // Service management
  getServiceStatus: () => ipcRenderer.invoke('get-service-status'),
  restartService: (serviceName: string) => ipcRenderer.invoke('restart-service', serviceName),
  
  // App info
  getVersion: () => process.versions.electron,
  getPlatform: () => process.platform,
  
  // Desktop mode flag
  isDesktopMode: () => true
});

// Type definitions for TypeScript
declare global {
  interface Window {
    electronAPI: {
      getServiceStatus: () => Promise<Record<string, boolean>>;
      restartService: (serviceName: string) => Promise<void>;
      getVersion: () => string;
      getPlatform: () => string;
      isDesktopMode: () => boolean;
    };
  }
}
