import { app, BrowserWindow, Tray, Menu, nativeImage, ipcMain } from 'electron';
import * as path from 'path';
import { ServiceManager } from './services/serviceManager';
import { createTrayMenu } from './tray';

let mainWindow: BrowserWindow | null = null;
let tray: Tray | null = null;
let serviceManager: ServiceManager | null = null;

const isDev = process.env.NODE_ENV === 'development';
const BACKEND_PORT = 3000;

async function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1200,
    minHeight: 700,
    title: 'HAI Engine Control Center',
    icon: path.join(__dirname, '../resources/icon.png'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    show: false // Don't show until ready
  });

  // Load the HAI dashboard
  const startUrl = `http://localhost:${BACKEND_PORT}`;
  await mainWindow.loadURL(startUrl);

  // Show window when ready
  mainWindow.once('ready-to-show', () => {
    mainWindow?.show();
  });

  // Handle window close - minimize to tray instead
  mainWindow.on('close', (event) => {
    if (!app.isQuitting) {
      event.preventDefault();
      mainWindow?.hide();
    }
  });

  // Open DevTools in development
  if (isDev) {
    mainWindow.webContents.openDevTools();
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

function createTray() {
  const iconPath = path.join(__dirname, '../resources/tray-icon.png');
  const icon = nativeImage.createFromPath(iconPath);
  
  tray = new Tray(icon.resize({ width: 16, height: 16 }));
  tray.setToolTip('HAI Engine Control Center');
  
  // Create tray menu
  const menu = createTrayMenu({
    onShowDashboard: () => {
      if (mainWindow) {
        mainWindow.show();
        mainWindow.focus();
      } else {
        createWindow();
      }
    },
    onRestartServices: async () => {
      if (serviceManager) {
        await serviceManager.restartAll();
      }
    },
    onQuit: () => {
      app.isQuitting = true;
      app.quit();
    },
    getServiceStatus: () => serviceManager?.getStatus() || {}
  });
  
  tray.setContextMenu(menu);
  
  // Double-click to show window
  tray.on('double-click', () => {
    if (mainWindow) {
      mainWindow.show();
      mainWindow.focus();
    } else {
      createWindow();
    }
  });
}

async function startServices() {
  serviceManager = new ServiceManager();
  
  try {
    console.log('[HAI] Starting services...');
    await serviceManager.startAll();
    console.log('[HAI] All services started successfully');
  } catch (error) {
    console.error('[HAI] Failed to start services:', error);
    // Show error dialog
    const { dialog } = require('electron');
    dialog.showErrorBox(
      'Service Start Failed',
      `Failed to start HAI services: ${error.message}\n\nPlease check the logs for more information.`
    );
  }
}

// App lifecycle
app.whenReady().then(async () => {
  console.log('[HAI] Application starting...');
  console.log('[HAI] User data path:', app.getPath('userData'));
  
  // Start backend services
  await startServices();
  
  // Wait a moment for services to be ready
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  // Create main window
  await createWindow();
  
  // Create system tray
  createTray();
  
  console.log('[HAI] Application ready');
});

// Quit when all windows are closed (except on macOS)
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    // Don't quit - keep running in tray
    // app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// Handle app quit
app.on('before-quit', async () => {
  console.log('[HAI] Application shutting down...');
  
  if (serviceManager) {
    await serviceManager.stopAll();
  }
});

// IPC handlers
ipcMain.handle('get-service-status', async () => {
  return serviceManager?.getStatus() || {};
});

ipcMain.handle('restart-service', async (event, serviceName: string) => {
  if (serviceManager) {
    await serviceManager.restart(serviceName);
  }
});

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  console.error('[HAI] Uncaught exception:', error);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('[HAI] Unhandled rejection at:', promise, 'reason:', reason);
});
