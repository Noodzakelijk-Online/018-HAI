import { Menu, app } from 'electron';

interface TrayMenuOptions {
  onShowDashboard: () => void;
  onRestartServices: () => Promise<void>;
  onQuit: () => void;
  getServiceStatus: () => Record<string, boolean>;
}

export function createTrayMenu(options: TrayMenuOptions): Menu {
  const { onShowDashboard, onRestartServices, onQuit, getServiceStatus } = options;
  
  const serviceStatus = getServiceStatus();
  
  const template: Electron.MenuItemConstructorOptions[] = [
    {
      label: 'Open HAI Dashboard',
      click: onShowDashboard,
      accelerator: 'CommandOrControl+Shift+H'
    },
    { type: 'separator' },
    {
      label: 'Services',
      submenu: [
        {
          label: `● Backend: ${serviceStatus.backend ? 'Running' : 'Stopped'}`,
          enabled: false
        },
        {
          label: `● Fara-7B: ${serviceStatus.fara ? 'Running' : 'Not Started'}`,
          enabled: false
        },
        {
          label: `● Database: ${serviceStatus.database ? 'Connected' : 'Disconnected'}`,
          enabled: false
        },
        { type: 'separator' },
        {
          label: 'Restart All Services',
          click: async () => {
            try {
              await onRestartServices();
            } catch (error) {
              console.error('[Tray] Failed to restart services:', error);
            }
          }
        }
      ]
    },
    { type: 'separator' },
    {
      label: 'Settings',
      submenu: [
        {
          label: 'Launch on Startup',
          type: 'checkbox',
          checked: app.getLoginItemSettings().openAtLogin,
          click: (menuItem) => {
            app.setLoginItemSettings({
              openAtLogin: menuItem.checked
            });
          }
        },
        {
          label: 'Show Notifications',
          type: 'checkbox',
          checked: true,
          click: (menuItem) => {
            // TODO: Save notification preference
            console.log('[Tray] Notifications:', menuItem.checked);
          }
        }
      ]
    },
    { type: 'separator' },
    {
      label: 'About HAI',
      click: () => {
        const { dialog } = require('electron');
        dialog.showMessageBox({
          type: 'info',
          title: 'About HAI',
          message: 'HAI Engine Control Center',
          detail: `Version: ${app.getVersion()}\n\nYour autonomous AI assistant for managing emails, calendar, and more.`
        });
      }
    },
    { type: 'separator' },
    {
      label: 'Quit HAI',
      click: onQuit,
      accelerator: 'CommandOrControl+Q'
    }
  ];
  
  return Menu.buildFromTemplate(template);
}
