# OAuth Setup Guide for HAI Engine Control Center

This guide explains how to replace the mock OAuth implementation with real Google OAuth2 for Gmail and Calendar connectors.

## Overview

The HAI Engine Control Center currently uses a **mock OAuth service** for development. This allows you to test the OAuth flow without setting up real credentials. When you're ready for production, follow this guide to integrate real Google OAuth2.

## Prerequisites

- Google Cloud Platform account
- Access to Google Cloud Console
- Domain or localhost for testing

## Step 1: Create Google Cloud Project

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Click "Select a project" → "New Project"
3. Enter project name: "HAI Engine Control"
4. Click "Create"

## Step 2: Enable APIs

1. In the Google Cloud Console, go to "APIs & Services" → "Library"
2. Search and enable the following APIs:
   - **Gmail API** - For sending emails
   - **Google Calendar API** - For creating events
3. Click "Enable" for each API

## Step 3: Configure OAuth Consent Screen

1. Go to "APIs & Services" → "OAuth consent screen"
2. Choose "External" (for testing) or "Internal" (for organization use)
3. Fill in the required fields:
   - **App name**: HAI Engine Control Center
   - **User support email**: Your email
   - **Developer contact**: Your email
4. Click "Save and Continue"
5. Add scopes:
   - `https://www.googleapis.com/auth/gmail.send` - Send emails
   - `https://www.googleapis.com/auth/calendar.events` - Create calendar events
6. Click "Save and Continue"
7. Add test users (for testing phase):
   - Add your email address
8. Click "Save and Continue"

## Step 4: Create OAuth 2.0 Credentials

1. Go to "APIs & Services" → "Credentials"
2. Click "Create Credentials" → "OAuth client ID"
3. Select "Web application"
4. Configure:
   - **Name**: HAI OAuth Client
   - **Authorized JavaScript origins**:
     - `http://localhost:3000` (for local development)
     - `https://yourdomain.com` (for production)
   - **Authorized redirect URIs**:
     - `http://localhost:3000/api/oauth/callback` (for local)
     - `https://yourdomain.com/api/oauth/callback` (for production)
5. Click "Create"
6. **Save the credentials**:
   - Copy the **Client ID**
   - Copy the **Client Secret**

## Step 5: Add Environment Variables

Add the following environment variables to your project:

```bash
# Google OAuth Credentials
GOOGLE_CLIENT_ID=your_client_id_here
GOOGLE_CLIENT_SECRET=your_client_secret_here
GOOGLE_REDIRECT_URI=http://localhost:3000/api/oauth/callback

# OAuth Scopes (space-separated)
GOOGLE_SCOPES="https://www.googleapis.com/auth/gmail.send https://www.googleapis.com/auth/calendar.events"
```

**For Manus deployment**: Add these as secrets in the Manus dashboard under Settings → Secrets.

## Step 6: Install googleapis Package

```bash
pnpm add googleapis
```

## Step 7: Replace Mock OAuth Service

### 7.1 Create Real OAuth Service

Create `/home/ubuntu/hai-engine-control/server/services/realOAuthService.ts`:

```typescript
import { google } from 'googleapis';

const oauth2Client = new google.auth.OAuth2(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  process.env.GOOGLE_REDIRECT_URI
);

const SCOPES = (process.env.GOOGLE_SCOPES || '').split(' ');

/**
 * Generate OAuth authorization URL
 */
export function generateAuthUrl(state: string): string {
  return oauth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: SCOPES,
    state,
  });
}

/**
 * Exchange authorization code for tokens
 */
export async function exchangeCodeForTokens(code: string) {
  const { tokens } = await oauth2Client.getToken(code);
  return {
    accessToken: tokens.access_token!,
    refreshToken: tokens.refresh_token,
    expiresAt: new Date(tokens.expiry_date!),
    scope: tokens.scope,
  };
}

/**
 * Refresh access token
 */
export async function refreshAccessToken(refreshToken: string) {
  oauth2Client.setCredentials({ refresh_token: refreshToken });
  const { credentials } = await oauth2Client.refreshAccessToken();
  return {
    accessToken: credentials.access_token!,
    expiresAt: new Date(credentials.expiry_date!),
  };
}

/**
 * Send email via Gmail API
 */
export async function gmailSendEmail(
  accessToken: string,
  to: string[],
  subject: string,
  body: string,
  html?: string
) {
  oauth2Client.setCredentials({ access_token: accessToken });
  const gmail = google.gmail({ version: 'v1', auth: oauth2Client });

  const message = [
    `To: ${to.join(', ')}`,
    `Subject: ${subject}`,
    'Content-Type: text/html; charset=utf-8',
    '',
    html || body,
  ].join('\n');

  const encodedMessage = Buffer.from(message)
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');

  const result = await gmail.users.messages.send({
    userId: 'me',
    requestBody: {
      raw: encodedMessage,
    },
  });

  return {
    success: true,
    messageId: result.data.id!,
  };
}

/**
 * Create calendar event via Calendar API
 */
export async function calendarCreateEvent(
  accessToken: string,
  title: string,
  start: Date,
  end: Date,
  description?: string,
  location?: string
) {
  oauth2Client.setCredentials({ access_token: accessToken });
  const calendar = google.calendar({ version: 'v3', auth: oauth2Client });

  const event = {
    summary: title,
    description,
    location,
    start: {
      dateTime: start.toISOString(),
      timeZone: 'UTC',
    },
    end: {
      dateTime: end.toISOString(),
      timeZone: 'UTC',
    },
  };

  const result = await calendar.events.insert({
    calendarId: 'primary',
    requestBody: event,
  });

  return {
    success: true,
    eventId: result.data.id!,
    eventUrl: result.data.htmlLink!,
  };
}

/**
 * Encrypt credentials for storage
 */
export function encryptCredentials(credentials: any): string {
  // In production, use proper encryption (e.g., crypto.createCipheriv)
  // For now, use base64 encoding (NOT SECURE for production)
  return Buffer.from(JSON.stringify(credentials)).toString('base64');
}

/**
 * Decrypt credentials from storage
 */
export function decryptCredentials(encrypted: string): any {
  // In production, use proper decryption
  return JSON.parse(Buffer.from(encrypted, 'base64').toString('utf-8'));
}

/**
 * Check if token is expired
 */
export function isTokenExpired(expiresAt: Date): boolean {
  return new Date() >= expiresAt;
}
```

### 7.2 Update Connectors Router

In `/home/ubuntu/hai-engine-control/server/api/routers/connectors.ts`, replace the mock OAuth imports:

```typescript
// OLD (mock):
const { mockGmailSendEmail, decryptCredentials, isTokenExpired } = await import('../../services/mockOAuthService');

// NEW (real):
const { gmailSendEmail, decryptCredentials, isTokenExpired, refreshAccessToken } = await import('../../services/realOAuthService');
```

Update the `initiateOAuth` endpoint:

```typescript
initiateOAuth: protectedProcedure
  .input(z.object({ connectorId: z.number() }))
  .mutation(async ({ input, ctx }) => {
    const { generateAuthUrl } = await import('../../services/realOAuthService');
    const connector = await getConnectorById(input.connectorId);
    
    if (!connector || connector.userId !== ctx.user.id) {
      throw new Error('Connector not found or access denied');
    }

    // Generate state for CSRF protection
    const state = `${connector.id}-${Date.now()}-${Math.random().toString(36)}`;
    
    // Store state temporarily (in production, use Redis or database)
    // For now, we'll validate it in completeOAuth
    
    // Generate real OAuth URL
    const authUrl = generateAuthUrl(state);

    return {
      authUrl,
      state,
    };
  }),
```

Update the `completeOAuth` endpoint:

```typescript
completeOAuth: protectedProcedure
  .input(z.object({
    connectorId: z.number(),
    code: z.string(),
    state: z.string(),
  }))
  .mutation(async ({ input, ctx }) => {
    const { exchangeCodeForTokens, encryptCredentials } = await import('../../services/realOAuthService');
    const connector = await getConnectorById(input.connectorId);
    
    if (!connector || connector.userId !== ctx.user.id) {
      throw new Error('Connector not found or access denied');
    }

    // Validate state (CSRF protection)
    if (!input.state.startsWith(`${connector.id}-`)) {
      throw new Error('Invalid state parameter');
    }

    // Exchange code for tokens
    const tokens = await exchangeCodeForTokens(input.code);

    // Encrypt and store credentials
    const encrypted = encryptCredentials(tokens);

    await updateConnector(input.connectorId, {
      credentials: encrypted,
      status: 'connected',
      lastSync: new Date(),
    });

    return { success: true };
  }),
```

### 7.3 Add Token Refresh Logic

Add automatic token refresh when tokens expire:

```typescript
// In sendEmail and createCalendarEvent endpoints, add:
if (isTokenExpired(new Date(token.expiresAt))) {
  if (!token.refreshToken) {
    throw new Error('Token expired and no refresh token available. Please reconnect.');
  }
  
  // Refresh token
  const { refreshAccessToken, encryptCredentials } = await import('../../services/realOAuthService');
  const newToken = await refreshAccessToken(token.refreshToken);
  
  // Update stored credentials
  const updatedToken = { ...token, ...newToken };
  await updateConnector(input.connectorId, {
    credentials: encryptCredentials(updatedToken),
  });
  
  // Use new token
  token.accessToken = newToken.accessToken;
}
```

## Step 8: Update Frontend OAuth Flow

In `/home/ubuntu/hai-engine-control/client/src/pages/Connectors.tsx`, update the OAuth handler:

```typescript
const handleOAuthConnect = async (connectorId: number) => {
  try {
    const result = await initiateOAuth.mutateAsync({ connectorId });
    
    // Redirect to real Google OAuth page
    window.location.href = result.authUrl;
  } catch (error: any) {
    toast.error(`Failed to initiate OAuth: ${error.message}`);
  }
};
```

### 7.4 Create OAuth Callback Handler

Create `/home/ubuntu/hai-engine-control/server/api/routes/oauth-callback.ts`:

```typescript
import { Request, Response } from 'express';
import { getConnectorById, updateConnector } from '../../db';
import { exchangeCodeForTokens, encryptCredentials } from '../../services/realOAuthService';

export async function handleOAuthCallback(req: Request, res: Response) {
  const { code, state, error } = req.query;

  if (error) {
    return res.redirect(`/connectors?error=${error}`);
  }

  if (!code || !state) {
    return res.redirect('/connectors?error=missing_parameters');
  }

  try {
    // Extract connector ID from state
    const connectorId = parseInt(state.toString().split('-')[0]);
    const connector = await getConnectorById(connectorId);

    if (!connector) {
      return res.redirect('/connectors?error=invalid_connector');
    }

    // Exchange code for tokens
    const tokens = await exchangeCodeForTokens(code.toString());

    // Encrypt and store credentials
    const encrypted = encryptCredentials(tokens);

    await updateConnector(connectorId, {
      credentials: encrypted,
      status: 'connected',
      lastSync: new Date(),
    });

    // Redirect back to connectors page
    res.redirect('/connectors?success=connected');
  } catch (error: any) {
    console.error('[OAuth] Callback error:', error);
    res.redirect(`/connectors?error=${encodeURIComponent(error.message)}`);
  }
}
```

Register the route in `/home/ubuntu/hai-engine-control/server/_core/index.ts`:

```typescript
import { handleOAuthCallback } from '../api/routes/oauth-callback';

// Add before tRPC handler
app.get('/api/oauth/callback', handleOAuthCallback);
```

## Step 9: Test the Integration

1. **Start the server**:
   ```bash
   pnpm dev
   ```

2. **Navigate to Connectors page**:
   - Go to http://localhost:3000/connectors

3. **Connect Gmail**:
   - Find a Gmail connector card
   - Click "Connect"
   - You'll be redirected to Google's OAuth consent screen
   - Grant permissions
   - You'll be redirected back to the app

4. **Test sending email**:
   - Click "Send Email" on the connected Gmail card
   - Check if the email was sent successfully

5. **Connect Calendar**:
   - Find a Calendar connector card
   - Click "Connect"
   - Grant permissions

6. **Test creating event**:
   - Click "Create Event" on the connected Calendar card
   - Check your Google Calendar for the new event

## Security Best Practices

### 1. Encrypt Credentials Properly

Replace the base64 encoding with proper encryption:

```typescript
import crypto from 'crypto';

const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY!; // 32 bytes
const IV_LENGTH = 16;

export function encryptCredentials(credentials: any): string {
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY, 'hex'), iv);
  
  let encrypted = cipher.update(JSON.stringify(credentials), 'utf8', 'hex');
  encrypted += cipher.final('hex');
  
  return iv.toString('hex') + ':' + encrypted;
}

export function decryptCredentials(encrypted: string): any {
  const parts = encrypted.split(':');
  const iv = Buffer.from(parts[0], 'hex');
  const encryptedText = parts[1];
  
  const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY, 'hex'), iv);
  
  let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  
  return JSON.parse(decrypted);
}
```

Generate encryption key:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Add to environment variables:
```bash
ENCRYPTION_KEY=your_generated_key_here
```

### 2. Store State in Database

Instead of encoding state in the URL, store it in a database table:

```typescript
// Create state table
export const oauthStates = mysqlTable("oauth_states", {
  id: int("id").autoincrement().primaryKey(),
  state: varchar("state", { length: 255 }).notNull().unique(),
  connectorId: int("connectorId").notNull(),
  userId: int("userId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
});

// Store state when initiating OAuth
await db.insert(oauthStates).values({
  state,
  connectorId: connector.id,
  userId: ctx.user.id,
  expiresAt: new Date(Date.now() + 10 * 60 * 1000), // 10 minutes
});

// Validate state in callback
const stateRecord = await db
  .select()
  .from(oauthStates)
  .where(eq(oauthStates.state, state))
  .limit(1);

if (!stateRecord.length || new Date() > stateRecord[0].expiresAt) {
  throw new Error('Invalid or expired state');
}

// Delete used state
await db.delete(oauthStates).where(eq(oauthStates.state, state));
```

### 3. Implement Rate Limiting

Add rate limiting to OAuth endpoints:

```typescript
import rateLimit from 'express-rate-limit';

const oauthLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // 10 requests per window
  message: 'Too many OAuth requests, please try again later',
});

app.get('/api/oauth/callback', oauthLimiter, handleOAuthCallback);
```

### 4. Add Logging and Monitoring

Log all OAuth events:

```typescript
console.log('[OAuth] Initiated:', {
  connectorId: connector.id,
  userId: ctx.user.id,
  connectorType: connector.connectorType,
  timestamp: new Date().toISOString(),
});

console.log('[OAuth] Completed:', {
  connectorId: connector.id,
  userId: ctx.user.id,
  success: true,
  timestamp: new Date().toISOString(),
});
```

## Troubleshooting

### Error: "redirect_uri_mismatch"

**Cause**: The redirect URI in your request doesn't match the one configured in Google Cloud Console.

**Solution**:
1. Go to Google Cloud Console → Credentials
2. Edit your OAuth client
3. Add the exact redirect URI: `http://localhost:3000/api/oauth/callback`
4. Make sure there are no trailing slashes

### Error: "invalid_grant"

**Cause**: The authorization code has expired or been used already.

**Solution**:
- Authorization codes expire after 10 minutes
- Each code can only be used once
- Start the OAuth flow again

### Error: "Token expired and no refresh token"

**Cause**: The refresh token is missing or invalid.

**Solution**:
- Make sure `access_type: 'offline'` is set in `generateAuthUrl`
- Disconnect and reconnect the connector to get a new refresh token

### Emails not sending

**Cause**: Gmail API might be disabled or permissions not granted.

**Solution**:
1. Check that Gmail API is enabled in Google Cloud Console
2. Verify the scope `https://www.googleapis.com/auth/gmail.send` is included
3. Check the OAuth consent screen for granted permissions
4. Try disconnecting and reconnecting

## Migration Checklist

- [ ] Create Google Cloud project
- [ ] Enable Gmail and Calendar APIs
- [ ] Configure OAuth consent screen
- [ ] Create OAuth 2.0 credentials
- [ ] Add environment variables
- [ ] Install googleapis package
- [ ] Create realOAuthService.ts
- [ ] Update connectors router
- [ ] Create OAuth callback handler
- [ ] Update frontend OAuth flow
- [ ] Implement proper encryption
- [ ] Add state validation
- [ ] Test Gmail integration
- [ ] Test Calendar integration
- [ ] Add rate limiting
- [ ] Add logging and monitoring
- [ ] Deploy to production

## Additional Resources

- [Google OAuth 2.0 Documentation](https://developers.google.com/identity/protocols/oauth2)
- [Gmail API Documentation](https://developers.google.com/gmail/api)
- [Google Calendar API Documentation](https://developers.google.com/calendar/api)
- [googleapis npm package](https://www.npmjs.com/package/googleapis)

---

**Note**: The mock OAuth service is perfect for development and testing. Only switch to real OAuth when you're ready to deploy to production or need to test with real Google services.
