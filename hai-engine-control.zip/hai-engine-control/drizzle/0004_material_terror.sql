-- Custom SQL migration file, put your code below! --

-- Create connectorAnalytics table
CREATE TABLE IF NOT EXISTS `connectorAnalytics` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `connectorId` int NOT NULL,
  `action` varchar(64) NOT NULL,
  `status` enum('success', 'failed') NOT NULL,
  `duration` int,
  `errorMessage` text,
  `createdAt` timestamp NOT NULL DEFAULT (now())
);
