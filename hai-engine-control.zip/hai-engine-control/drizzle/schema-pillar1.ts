/**
 * PILLAR 1: Decision Authority Database Schema
 * "AI Acts, Human Can Override"
 * 
 * This schema supports the autonomous action engine, override mechanism,
 * financial logic engine, and authority level matrix.
 */

import { int, mysqlTable, text, timestamp, varchar, json, boolean, decimal, mysqlEnum } from "drizzle-orm/mysql-core";

// ============================================================================
// 1.1 AUTONOMOUS ACTION ENGINE
// ============================================================================

/**
 * Core action queue - all autonomous actions flow through here
 */
export const autonomousActions = mysqlTable("autonomous_actions", {
  id: int("id").autoincrement().primaryKey(),
  
  // Action identification
  actionType: varchar("action_type", { length: 100 }).notNull(), // email_send, calendar_create, payment_execute, etc.
  actionCategory: varchar("action_category", { length: 50 }).notNull(), // communication, financial, scheduling, etc.
  
  // Target information
  targetService: varchar("target_service", { length: 100 }).notNull(), // gmail, calendar, bank, etc.
  targetResourceId: varchar("target_resource_id", { length: 255 }), // specific email/event/transaction ID
  
  // Action details
  actionPayload: json("action_payload").notNull(), // full action parameters
  actionDescription: text("action_description").notNull(), // human-readable description
  
  // Confidence and priority
  confidenceScore: decimal("confidence_score", { precision: 5, scale: 4 }).notNull(), // 0.0000 to 1.0000
  priorityScore: int("priority_score").notNull().default(50), // 0-100, higher = more urgent
  
  // Status tracking
  status: mysqlEnum("status", [
    "pending",      // waiting to execute
    "executing",    // currently running
    "completed",    // successfully done
    "failed",       // execution failed
    "cancelled",    // user cancelled
    "overridden",   // user overrode
    "rolled_back"   // action was undone
  ]).notNull().default("pending"),
  
  // Execution details
  scheduledAt: timestamp("scheduled_at"), // when to execute (null = immediate)
  executedAt: timestamp("executed_at"),
  completedAt: timestamp("completed_at"),
  
  // Result tracking
  resultPayload: json("result_payload"), // execution result
  errorMessage: text("error_message"),
  
  // Relationships
  householdId: int("household_id").notNull(),
  triggeredByMemberId: int("triggered_by_member_id"), // which member's context triggered this
  parentActionId: int("parent_action_id"), // for batched/dependent actions
  
  // Audit
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

/**
 * Action dependencies - for complex multi-step operations
 */
export const actionDependencies = mysqlTable("action_dependencies", {
  id: int("id").autoincrement().primaryKey(),
  actionId: int("action_id").notNull(),
  dependsOnActionId: int("depends_on_action_id").notNull(),
  dependencyType: mysqlEnum("dependency_type", [
    "must_complete",    // dependent must complete first
    "must_succeed",     // dependent must succeed
    "can_parallel",     // can run in parallel
    "blocks"            // this action blocks the dependent
  ]).notNull().default("must_complete"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/**
 * Action batches - group related actions together
 */
export const actionBatches = mysqlTable("action_batches", {
  id: int("id").autoincrement().primaryKey(),
  batchName: varchar("batch_name", { length: 255 }).notNull(),
  batchDescription: text("batch_description"),
  householdId: int("household_id").notNull(),
  status: mysqlEnum("status", ["pending", "executing", "completed", "failed", "cancelled"]).notNull().default("pending"),
  totalActions: int("total_actions").notNull().default(0),
  completedActions: int("completed_actions").notNull().default(0),
  failedActions: int("failed_actions").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
});

/**
 * Action logs - complete audit trail
 */
export const actionLogs = mysqlTable("action_logs", {
  id: int("id").autoincrement().primaryKey(),
  actionId: int("action_id").notNull(),
  logType: mysqlEnum("log_type", [
    "created",
    "scheduled",
    "started",
    "progress",
    "completed",
    "failed",
    "cancelled",
    "overridden",
    "rolled_back",
    "retried"
  ]).notNull(),
  logMessage: text("log_message").notNull(),
  logData: json("log_data"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ============================================================================
// 1.2 OVERRIDE MECHANISM
// ============================================================================

/**
 * Override records - track all user overrides
 */
export const actionOverrides = mysqlTable("action_overrides", {
  id: int("id").autoincrement().primaryKey(),
  actionId: int("action_id").notNull(),
  
  // Who overrode
  overriddenByUserId: int("overridden_by_user_id").notNull(),
  overriddenByMemberId: int("overridden_by_member_id"),
  
  // Override details
  overrideType: mysqlEnum("override_type", [
    "cancel",           // stop action before execution
    "modify",           // change action parameters
    "rollback",         // undo completed action
    "emergency_stop",   // emergency halt
    "redirect"          // change action target
  ]).notNull(),
  
  overrideReason: text("override_reason"),
  originalPayload: json("original_payload"),
  modifiedPayload: json("modified_payload"),
  
  // Learning signal
  shouldLearnFrom: boolean("should_learn_from").notNull().default(true),
  learningApplied: boolean("learning_applied").notNull().default(false),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/**
 * Override patterns - learned from user overrides
 */
export const overridePatterns = mysqlTable("override_patterns", {
  id: int("id").autoincrement().primaryKey(),
  householdId: int("household_id").notNull(),
  memberId: int("member_id"), // null = household-wide pattern
  
  // Pattern definition
  patternName: varchar("pattern_name", { length: 255 }).notNull(),
  patternDescription: text("pattern_description"),
  
  // Matching criteria
  actionTypeMatch: varchar("action_type_match", { length: 100 }),
  actionCategoryMatch: varchar("action_category_match", { length: 50 }),
  conditionsJson: json("conditions_json"), // complex matching rules
  
  // Pattern behavior
  suggestedBehavior: mysqlEnum("suggested_behavior", [
    "always_ask",       // always require approval
    "lower_confidence", // reduce confidence threshold
    "add_delay",        // add delay before execution
    "notify_first",     // notify before executing
    "skip"              // skip this type of action
  ]).notNull(),
  
  // Pattern strength
  occurrenceCount: int("occurrence_count").notNull().default(1),
  confidenceAdjustment: decimal("confidence_adjustment", { precision: 5, scale: 4 }).default("0.0000"),
  
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

// ============================================================================
// 1.3 FINANCIAL LOGIC ENGINE
// ============================================================================

/**
 * Financial rules - auto-approval thresholds and vendor trust
 */
export const financialRules = mysqlTable("financial_rules", {
  id: int("id").autoincrement().primaryKey(),
  householdId: int("household_id").notNull(),
  
  // Rule identification
  ruleName: varchar("rule_name", { length: 255 }).notNull(),
  ruleDescription: text("rule_description"),
  ruleType: mysqlEnum("rule_type", [
    "auto_approve_threshold",
    "vendor_trust",
    "category_limit",
    "recurring_bill",
    "anomaly_threshold",
    "time_based"
  ]).notNull(),
  
  // Rule parameters
  vendorName: varchar("vendor_name", { length: 255 }),
  category: varchar("category", { length: 100 }),
  maxAmount: decimal("max_amount", { precision: 12, scale: 2 }),
  minAmount: decimal("min_amount", { precision: 12, scale: 2 }),
  
  // Trust and confidence
  vendorTrustScore: decimal("vendor_trust_score", { precision: 5, scale: 4 }),
  autoApproveConfidence: decimal("auto_approve_confidence", { precision: 5, scale: 4 }),
  
  // Time constraints
  validFromTime: varchar("valid_from_time", { length: 10 }), // HH:MM format
  validToTime: varchar("valid_to_time", { length: 10 }),
  validDays: json("valid_days"), // [0,1,2,3,4,5,6] for days of week
  
  // Rule behavior
  requiresApproval: boolean("requires_approval").notNull().default(false),
  notifyOnExecution: boolean("notify_on_execution").notNull().default(true),
  
  isActive: boolean("is_active").notNull().default(true),
  priority: int("priority").notNull().default(50), // higher = checked first
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

/**
 * Recurring bills - detected and tracked bills
 */
export const recurringBills = mysqlTable("recurring_bills", {
  id: int("id").autoincrement().primaryKey(),
  householdId: int("household_id").notNull(),
  
  // Bill identification
  vendorName: varchar("vendor_name", { length: 255 }).notNull(),
  vendorId: varchar("vendor_id", { length: 255 }),
  category: varchar("category", { length: 100 }),
  
  // Amount tracking
  expectedAmount: decimal("expected_amount", { precision: 12, scale: 2 }).notNull(),
  amountVarianceThreshold: decimal("amount_variance_threshold", { precision: 5, scale: 2 }).default("5.00"), // percentage
  lastAmount: decimal("last_amount", { precision: 12, scale: 2 }),
  
  // Timing
  frequency: mysqlEnum("frequency", ["weekly", "biweekly", "monthly", "quarterly", "annually"]).notNull(),
  expectedDay: int("expected_day"), // day of month/week
  nextExpectedDate: timestamp("next_expected_date"),
  lastPaidDate: timestamp("last_paid_date"),
  
  // Auto-pay settings
  autoPayEnabled: boolean("auto_pay_enabled").notNull().default(false),
  paymentMethodId: varchar("payment_method_id", { length: 255 }),
  
  // Anomaly detection
  anomalyDetected: boolean("anomaly_detected").notNull().default(false),
  anomalyDescription: text("anomaly_description"),
  
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

/**
 * Financial anomalies - detected unusual transactions
 */
export const financialAnomalies = mysqlTable("financial_anomalies", {
  id: int("id").autoincrement().primaryKey(),
  householdId: int("household_id").notNull(),
  
  // Anomaly details
  anomalyType: mysqlEnum("anomaly_type", [
    "amount_spike",       // unusual amount
    "frequency_change",   // payment timing changed
    "new_vendor",         // first time vendor
    "duplicate",          // possible duplicate charge
    "category_unusual",   // unusual for category
    "time_unusual",       // unusual time of day
    "location_unusual"    // unusual location
  ]).notNull(),
  
  // Transaction reference
  transactionId: varchar("transaction_id", { length: 255 }),
  vendorName: varchar("vendor_name", { length: 255 }),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  
  // Anomaly scoring
  anomalyScore: decimal("anomaly_score", { precision: 5, scale: 4 }).notNull(), // 0-1, higher = more anomalous
  anomalyDescription: text("anomaly_description").notNull(),
  
  // Resolution
  status: mysqlEnum("status", ["detected", "reviewing", "confirmed_fraud", "false_positive", "resolved"]).notNull().default("detected"),
  resolvedByUserId: int("resolved_by_user_id"),
  resolutionNotes: text("resolution_notes"),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  resolvedAt: timestamp("resolved_at"),
});

// ============================================================================
// 1.4 AUTHORITY LEVEL MATRIX
// ============================================================================

/**
 * Authority levels - define what actions require what authority
 */
export const authorityLevels = mysqlTable("authority_levels", {
  id: int("id").autoincrement().primaryKey(),
  
  // Level definition
  levelName: varchar("level_name", { length: 100 }).notNull(),
  levelDescription: text("level_description"),
  levelNumber: int("level_number").notNull(), // 0 = lowest, higher = more authority
  
  // Default thresholds
  maxFinancialAmount: decimal("max_financial_amount", { precision: 12, scale: 2 }),
  canAccessSensitiveData: boolean("can_access_sensitive_data").notNull().default(false),
  canModifySettings: boolean("can_modify_settings").notNull().default(false),
  canInviteMembers: boolean("can_invite_members").notNull().default(false),
  canRemoveMembers: boolean("can_remove_members").notNull().default(false),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/**
 * Action authority requirements - what authority level each action type needs
 */
export const actionAuthorityRequirements = mysqlTable("action_authority_requirements", {
  id: int("id").autoincrement().primaryKey(),
  
  // Action matching
  actionType: varchar("action_type", { length: 100 }).notNull(),
  actionCategory: varchar("action_category", { length: 50 }),
  
  // Authority requirement
  requiredAuthorityLevel: int("required_authority_level").notNull(),
  
  // Context modifiers
  contextConditions: json("context_conditions"), // conditions that modify requirement
  emergencyOverride: boolean("emergency_override").notNull().default(false), // can be overridden in emergency
  
  // Time-based modifiers
  businessHoursOnly: boolean("business_hours_only").notNull().default(false),
  authorityBoostDuringBusinessHours: int("authority_boost_during_business_hours").default(0),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

/**
 * Member authority assignments - what authority level each member has
 */
export const memberAuthorityAssignments = mysqlTable("member_authority_assignments", {
  id: int("id").autoincrement().primaryKey(),
  householdId: int("household_id").notNull(),
  memberId: int("member_id").notNull(),
  
  // Authority assignment
  authorityLevelId: int("authority_level_id").notNull(),
  
  // Delegation
  delegatedByMemberId: int("delegated_by_member_id"),
  delegationExpires: timestamp("delegation_expires"),
  
  // Overrides
  customMaxFinancialAmount: decimal("custom_max_financial_amount", { precision: 12, scale: 2 }),
  customPermissions: json("custom_permissions"),
  
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

/**
 * Authority escalations - when actions need higher authority
 */
export const authorityEscalations = mysqlTable("authority_escalations", {
  id: int("id").autoincrement().primaryKey(),
  actionId: int("action_id").notNull(),
  
  // Escalation details
  fromAuthorityLevel: int("from_authority_level").notNull(),
  toAuthorityLevel: int("to_authority_level").notNull(),
  escalationReason: text("escalation_reason").notNull(),
  
  // Resolution
  status: mysqlEnum("status", ["pending", "approved", "denied", "expired"]).notNull().default("pending"),
  resolvedByMemberId: int("resolved_by_member_id"),
  resolutionNotes: text("resolution_notes"),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  resolvedAt: timestamp("resolved_at"),
  expiresAt: timestamp("expires_at"),
});

// ============================================================================
// TYPE EXPORTS
// ============================================================================

export type AutonomousAction = typeof autonomousActions.$inferSelect;
export type InsertAutonomousAction = typeof autonomousActions.$inferInsert;

export type ActionDependency = typeof actionDependencies.$inferSelect;
export type InsertActionDependency = typeof actionDependencies.$inferInsert;

export type ActionBatch = typeof actionBatches.$inferSelect;
export type InsertActionBatch = typeof actionBatches.$inferInsert;

export type ActionLog = typeof actionLogs.$inferSelect;
export type InsertActionLog = typeof actionLogs.$inferInsert;

export type ActionOverride = typeof actionOverrides.$inferSelect;
export type InsertActionOverride = typeof actionOverrides.$inferInsert;

export type OverridePattern = typeof overridePatterns.$inferSelect;
export type InsertOverridePattern = typeof overridePatterns.$inferInsert;

export type FinancialRule = typeof financialRules.$inferSelect;
export type InsertFinancialRule = typeof financialRules.$inferInsert;

export type RecurringBill = typeof recurringBills.$inferSelect;
export type InsertRecurringBill = typeof recurringBills.$inferInsert;

export type FinancialAnomaly = typeof financialAnomalies.$inferSelect;
export type InsertFinancialAnomaly = typeof financialAnomalies.$inferInsert;

export type AuthorityLevel = typeof authorityLevels.$inferSelect;
export type InsertAuthorityLevel = typeof authorityLevels.$inferInsert;

export type ActionAuthorityRequirement = typeof actionAuthorityRequirements.$inferSelect;
export type InsertActionAuthorityRequirement = typeof actionAuthorityRequirements.$inferInsert;

export type MemberAuthorityAssignment = typeof memberAuthorityAssignments.$inferSelect;
export type InsertMemberAuthorityAssignment = typeof memberAuthorityAssignments.$inferInsert;

export type AuthorityEscalation = typeof authorityEscalations.$inferSelect;
export type InsertAuthorityEscalation = typeof authorityEscalations.$inferInsert;
