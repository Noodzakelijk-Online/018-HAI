/**
 * WhatsApp Integration Database Schema
 * 
 * Add these tables to your main schema.ts file
 */

import { int, mysqlTable, text, timestamp, varchar, boolean, decimal, mysqlEnum, json, index } from "drizzle-orm/mysql-core";

// WhatsApp Contacts
export const whatsappContacts = mysqlTable("whatsapp_contacts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  name: varchar("name", { length: 255 }),
  pushname: varchar("pushname", { length: 255 }),
  profilePicUrl: text("profilePicUrl"),
  isGroup: boolean("isGroup").default(false).notNull(),
  groupMembers: json("groupMembers"), // Array of member phone numbers
  lastMessageAt: timestamp("lastMessageAt"),
  messageCount: int("messageCount").default(0).notNull(),
  relationshipScore: decimal("relationshipScore", { precision: 3, scale: 2 }), // 0.00 to 1.00
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userPhoneIdx: index("user_phone_idx").on(table.userId, table.phone),
  userIdIdx: index("user_id_idx").on(table.userId),
}));

// WhatsApp Messages
export const whatsappMessages = mysqlTable("whatsapp_messages", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  contactId: int("contactId").notNull(),
  messageId: varchar("messageId", { length: 255 }).notNull(), // WhatsApp message ID
  chatId: varchar("chatId", { length: 255 }).notNull(), // WhatsApp chat ID
  sender: varchar("sender", { length: 255 }).notNull(),
  content: text("content"),
  mediaType: mysqlEnum("mediaType", ["text", "image", "video", "audio", "document"]).default("text").notNull(),
  mediaUrl: text("mediaUrl"),
  timestamp: timestamp("timestamp").notNull(),
  isFromMe: boolean("isFromMe").default(false).notNull(),
  sentiment: mysqlEnum("sentiment", ["positive", "neutral", "negative"]),
  sentimentScore: decimal("sentimentScore", { precision: 4, scale: 3 }), // -1.000 to 1.000
  topics: json("topics"), // Array of extracted topics
  hasActionItem: boolean("hasActionItem").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userContactTimestampIdx: index("user_contact_timestamp_idx").on(table.userId, table.contactId, table.timestamp),
  userTimestampIdx: index("user_timestamp_idx").on(table.userId, table.timestamp),
  messageIdIdx: index("message_id_idx").on(table.messageId),
}));

// WhatsApp Conversation Insights
export const whatsappInsights = mysqlTable("whatsapp_insights", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  contactId: int("contactId").notNull(),
  period: mysqlEnum("period", ["daily", "weekly", "monthly"]).notNull(),
  periodStart: timestamp("periodStart").notNull(),
  messageCount: int("messageCount").default(0).notNull(),
  avgSentiment: decimal("avgSentiment", { precision: 3, scale: 2 }), // -1.00 to 1.00
  topTopics: json("topTopics"), // Array of {topic: string, count: number}
  actionItems: json("actionItems"), // Array of detected action items
  summary: text("summary"), // LLM-generated summary
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userContactPeriodIdx: index("user_contact_period_idx").on(table.userId, table.contactId, table.period, table.periodStart),
}));

// WhatsApp Sync Status
export const whatsappSyncStatus = mysqlTable("whatsapp_sync_status", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  isConnected: boolean("isConnected").default(false).notNull(),
  lastSyncAt: timestamp("lastSyncAt"),
  totalChats: int("totalChats").default(0).notNull(),
  totalMessages: int("totalMessages").default(0).notNull(),
  syncProgress: decimal("syncProgress", { precision: 5, scale: 2 }).default("0.00").notNull(), // 0.00 to 100.00
  errorMessage: text("errorMessage"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// TypeScript types
export type WhatsAppContact = typeof whatsappContacts.$inferSelect;
export type InsertWhatsAppContact = typeof whatsappContacts.$inferInsert;

export type WhatsAppMessage = typeof whatsappMessages.$inferSelect;
export type InsertWhatsAppMessage = typeof whatsappMessages.$inferInsert;

export type WhatsAppInsight = typeof whatsappInsights.$inferSelect;
export type InsertWhatsAppInsight = typeof whatsappInsights.$inferInsert;

export type WhatsAppSyncStatus = typeof whatsappSyncStatus.$inferSelect;
export type InsertWhatsAppSyncStatus = typeof whatsappSyncStatus.$inferInsert;
