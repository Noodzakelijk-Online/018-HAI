-- Performance optimization indexes for HAI Engine Control Center
-- Add indexes to frequently queried columns

-- Tasks table indexes
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_priority ON tasks(priority);
CREATE INDEX IF NOT EXISTS idx_tasks_assignedTo ON tasks(assignedTo);
CREATE INDEX IF NOT EXISTS idx_tasks_createdAt ON tasks(createdAt);
CREATE INDEX IF NOT EXISTS idx_tasks_deadline ON tasks(deadline);
CREATE INDEX IF NOT EXISTS idx_tasks_status_priority ON tasks(status, priority);

-- Events table indexes  
CREATE INDEX IF NOT EXISTS idx_events_eventType ON events(eventType);
CREATE INDEX IF NOT EXISTS idx_events_sourceEngine ON events(sourceEngine);
CREATE INDEX IF NOT EXISTS idx_events_targetEngine ON events(targetEngine);
CREATE INDEX IF NOT EXISTS idx_events_timestamp ON events(timestamp);
CREATE INDEX IF NOT EXISTS idx_events_userId ON events(userId);
CREATE INDEX IF NOT EXISTS idx_events_type_timestamp ON events(eventType, timestamp);

-- Policies table indexes
CREATE INDEX IF NOT EXISTS idx_policies_isActive ON policies(isActive);
CREATE INDEX IF NOT EXISTS idx_policies_priority ON policies(priority);
CREATE INDEX IF NOT EXISTS idx_policies_type ON policies(type);

-- Engines table indexes
CREATE INDEX IF NOT EXISTS idx_engines_status ON engines(status);
CREATE INDEX IF NOT EXISTS idx_engines_priority ON engines(priority);
CREATE INDEX IF NOT EXISTS idx_engines_autonomyLevel ON engines(autonomyLevel);

-- Decisions table indexes
CREATE INDEX IF NOT EXISTS idx_decisions_status ON decisions(status);
CREATE INDEX IF NOT EXISTS idx_decisions_userId ON decisions(userId);
CREATE INDEX IF NOT EXISTS idx_decisions_createdAt ON decisions(createdAt);

-- Knowledge Graph indexes
CREATE INDEX IF NOT EXISTS idx_kg_entities_type ON kgEntities(type);
CREATE INDEX IF NOT EXISTS idx_kg_entities_name ON kgEntities(name);
CREATE INDEX IF NOT EXISTS idx_kg_relationships_fromId ON kgRelationships(fromId);
CREATE INDEX IF NOT EXISTS idx_kg_relationships_toId ON kgRelationships(toId);
CREATE INDEX IF NOT EXISTS idx_kg_relationships_type ON kgRelationships(type);
CREATE INDEX IF NOT EXISTS idx_kg_relationships_from_to ON kgRelationships(fromId, toId);

-- Playbook indexes
CREATE INDEX IF NOT EXISTS idx_playbooks_category ON playbooks(category);
CREATE INDEX IF NOT EXISTS idx_playbooks_isActive ON playbooks(isActive);
CREATE INDEX IF NOT EXISTS idx_playbook_executions_playbookId ON playbookExecutions(playbookId);
CREATE INDEX IF NOT EXISTS idx_playbook_executions_status ON playbookExecutions(status);
CREATE INDEX IF NOT EXISTS idx_playbook_executions_createdAt ON playbookExecutions(createdAt);

-- Communication indexes
CREATE INDEX IF NOT EXISTS idx_comm_messages_channel ON communicationMessages(channel);
CREATE INDEX IF NOT EXISTS idx_comm_messages_status ON communicationMessages(status);
CREATE INDEX IF NOT EXISTS idx_comm_messages_recipient ON communicationMessages(recipient);
CREATE INDEX IF NOT EXISTS idx_comm_messages_createdAt ON communicationMessages(createdAt);

-- Composite indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_tasks_user_status ON tasks(assignedTo, status);
CREATE INDEX IF NOT EXISTS idx_events_source_time ON events(sourceEngine, timestamp);
CREATE INDEX IF NOT EXISTS idx_decisions_user_status ON decisions(userId, status);

-- Full-text search indexes (if supported by MySQL version)
-- ALTER TABLE tasks ADD FULLTEXT INDEX ft_tasks_title_desc (title, description);
-- ALTER TABLE engines ADD FULLTEXT INDEX ft_engines_name_desc (name, description);
-- ALTER TABLE events ADD FULLTEXT INDEX ft_events_type (eventType);

-- Show index creation results
SELECT 
  TABLE_NAME,
  INDEX_NAME,
  COLUMN_NAME,
  SEQ_IN_INDEX
FROM INFORMATION_SCHEMA.STATISTICS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME IN ('tasks', 'events', 'policies', 'engines', 'decisions', 'kgEntities', 'kgRelationships', 'playbooks', 'playbookExecutions', 'communicationMessages')
ORDER BY TABLE_NAME, INDEX_NAME, SEQ_IN_INDEX;
