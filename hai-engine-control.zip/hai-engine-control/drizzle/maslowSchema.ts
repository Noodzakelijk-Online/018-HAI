/**
 * Maslow's Hierarchy of Needs - Database Schema
 * 
 * Tracks user need fulfillment across 5 levels of Maslow's pyramid
 */

import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, json } from "drizzle-orm/mysql-core";

/**
 * Need Categories - Maslow's 5 levels
 */
export const needCategories = mysqlTable("needCategories", {
  id: int("id").autoincrement().primaryKey(),
  level: int("level").notNull(), // 1-5 (bottom to top of pyramid)
  name: varchar("name", { length: 64 }).notNull(), // e.g., "Physiological"
  description: text("description"),
  color: varchar("color", { length: 16 }), // For visualization
  icon: varchar("icon", { length: 64 }), // Icon name
  weight: decimal("weight", { precision: 3, scale: 2 }).default("1.00"), // Priority weight
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type NeedCategory = typeof needCategories.$inferSelect;
export type InsertNeedCategory = typeof needCategories.$inferInsert;

/**
 * Need Indicators - Specific measurable indicators for each category
 */
export const needIndicators = mysqlTable("needIndicators", {
  id: int("id").autoincrement().primaryKey(),
  categoryId: int("categoryId").notNull(), // Foreign key to needCategories
  name: varchar("name", { length: 128 }).notNull(),
  description: text("description"),
  measurementType: mysqlEnum("measurementType", ["boolean", "count", "percentage", "frequency", "duration"]).notNull(),
  targetValue: decimal("targetValue", { precision: 10, scale: 2 }), // Target for fulfillment
  weight: decimal("weight", { precision: 3, scale: 2 }).default("1.00"), // Importance within category
  dataSource: varchar("dataSource", { length: 64 }), // Where to get data (tasks, events, calendar, etc.)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type NeedIndicator = typeof needIndicators.$inferSelect;
export type InsertNeedIndicator = typeof needIndicators.$inferInsert;

/**
 * User Need Assessments - Current fulfillment levels for each user
 */
export const userNeedAssessments = mysqlTable("userNeedAssessments", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  categoryId: int("categoryId").notNull(),
  fulfillmentLevel: decimal("fulfillmentLevel", { precision: 5, scale: 2 }).notNull(), // 0-100%
  trend: mysqlEnum("trend", ["improving", "stable", "declining"]).default("stable"),
  lastAssessedAt: timestamp("lastAssessedAt").defaultNow().notNull(),
  assessmentData: json("assessmentData"), // Detailed breakdown
  insights: text("insights"), // AI-generated insights
  recommendations: text("recommendations"), // Suggested actions
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserNeedAssessment = typeof userNeedAssessments.$inferSelect;
export type InsertUserNeedAssessment = typeof userNeedAssessments.$inferInsert;

/**
 * Need Indicator Measurements - Historical data points
 */
export const needIndicatorMeasurements = mysqlTable("needIndicatorMeasurements", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  indicatorId: int("indicatorId").notNull(),
  value: decimal("value", { precision: 10, scale: 2 }).notNull(),
  source: varchar("source", { length: 64 }), // What triggered this measurement
  sourceId: int("sourceId"), // ID of the source entity (task, event, etc.)
  metadata: json("metadata"),
  measuredAt: timestamp("measuredAt").defaultNow().notNull(),
});

export type NeedIndicatorMeasurement = typeof needIndicatorMeasurements.$inferSelect;
export type InsertNeedIndicatorMeasurement = typeof needIndicatorMeasurements.$inferInsert;

/**
 * Need-Based Task Adjustments - Track how needs affect task priority
 */
export const needBasedAdjustments = mysqlTable("needBasedAdjustments", {
  id: int("id").autoincrement().primaryKey(),
  taskId: int("taskId").notNull(),
  categoryId: int("categoryId").notNull(),
  originalPriority: mysqlEnum("originalPriority", ["low", "medium", "high", "urgent"]).notNull(),
  adjustedPriority: mysqlEnum("adjustedPriority", ["low", "medium", "high", "urgent"]).notNull(),
  reason: text("reason"), // Why priority was adjusted
  fulfillmentGap: decimal("fulfillmentGap", { precision: 5, scale: 2 }), // How much need is unfulfilled
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type NeedBasedAdjustment = typeof needBasedAdjustments.$inferSelect;
export type InsertNeedBasedAdjustment = typeof needBasedAdjustments.$inferInsert;
