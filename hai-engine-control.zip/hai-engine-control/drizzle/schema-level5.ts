import { int, mysqlTable, text, timestamp, varchar, json, float, boolean, mysqlEnum } from "drizzle-orm/mysql-core";

/**
 * Level 5 AI Schema Extensions
 * 
 * This file contains all database tables for Level 5 AI capabilities:
 * - Training loops
 * - Knowledge graph metadata
 * - Memory systems
 * - Goal management
 * - Agent coordination
 * - Innovation tracking
 * - Forecasting
 */

// ============================================================================
// Training Loop & Continuous Improvement
// ============================================================================

export const trainingTasks = mysqlTable("training_tasks", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  instructions: text("instructions").notNull(),
  scoringFunction: text("scoring_function").notNull(), // JSON or code
  startingSolution: text("starting_solution"), // Optional initial code
  status: mysqlEnum("status", ["pending", "running", "completed", "failed"]).default("pending").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
});

export const trainingRuns = mysqlTable("training_runs", {
  id: int("id").autoincrement().primaryKey(),
  taskId: int("task_id").notNull(),
  agentType: mysqlEnum("agent_type", ["llm", "human"]).notNull(),
  agentId: varchar("agent_id", { length: 255 }), // For human agents
  status: mysqlEnum("status", ["running", "completed", "failed"]).default("running").notNull(),
  startedAt: timestamp("started_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
  iterations: int("iterations").default(0).notNull(),
  bestScore: float("best_score"),
  finalSolution: text("final_solution"),
});

export const trainingScores = mysqlTable("training_scores", {
  id: int("id").autoincrement().primaryKey(),
  runId: int("run_id").notNull(),
  iteration: int("iteration").notNull(),
  valAccuracy: float("val_accuracy"),
  testAccuracy: float("test_accuracy"),
  overallScore: float("overall_score").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  metadata: json("metadata"), // Additional metrics
});

// ============================================================================
// Knowledge Graph
// ============================================================================

export const knowledgeEntities = mysqlTable("knowledge_entities", {
  id: int("id").autoincrement().primaryKey(),
  entityId: varchar("entity_id", { length: 255 }).notNull().unique(), // UUID for Neo4j sync
  entityType: varchar("entity_type", { length: 100 }).notNull(), // person, organization, event, concept, etc.
  name: varchar("name", { length: 500 }).notNull(),
  properties: json("properties"), // Flexible properties
  source: varchar("source", { length: 255 }), // Where this entity came from
  confidence: float("confidence").default(1.0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export const knowledgeRelationships = mysqlTable("knowledge_relationships", {
  id: int("id").autoincrement().primaryKey(),
  relationshipId: varchar("relationship_id", { length: 255 }).notNull().unique(), // UUID for Neo4j sync
  sourceEntityId: varchar("source_entity_id", { length: 255 }).notNull(),
  targetEntityId: varchar("target_entity_id", { length: 255 }).notNull(),
  relationshipType: varchar("relationship_type", { length: 100 }).notNull(), // knows, works_at, manages, etc.
  properties: json("properties"), // Flexible properties
  confidence: float("confidence").default(1.0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

// ============================================================================
// Memory Systems
// ============================================================================

// Procedural Memory - Skills and procedures
export const proceduralMemory = mysqlTable("procedural_memory", {
  id: int("id").autoincrement().primaryKey(),
  skillName: varchar("skill_name", { length: 255 }).notNull(),
  skillType: varchar("skill_type", { length: 100 }).notNull(), // coding, writing, analysis, etc.
  procedure: json("procedure").notNull(), // Step-by-step instructions
  successRate: float("success_rate").default(0.0).notNull(),
  timesExecuted: int("times_executed").default(0).notNull(),
  lastExecuted: timestamp("last_executed"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

// Semantic Memory - Facts and concepts
export const semanticMemory = mysqlTable("semantic_memory", {
  id: int("id").autoincrement().primaryKey(),
  concept: varchar("concept", { length: 500 }).notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  definition: text("definition").notNull(),
  relatedConcepts: json("related_concepts"), // Array of concept IDs
  facts: json("facts"), // Array of facts about this concept
  confidence: float("confidence").default(1.0).notNull(),
  source: varchar("source", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

// Episodic Memory - Personal experiences and events
export const episodicMemory = mysqlTable("episodic_memory", {
  id: int("id").autoincrement().primaryKey(),
  eventId: varchar("event_id", { length: 255 }).notNull().unique(),
  eventType: varchar("event_type", { length: 100 }).notNull(), // conversation, task, meeting, etc.
  description: text("description").notNull(),
  participants: json("participants"), // Array of entity IDs
  location: varchar("location", { length: 255 }),
  emotionalTone: varchar("emotional_tone", { length: 50 }), // positive, negative, neutral
  importance: float("importance").default(0.5).notNull(), // 0-1 scale
  context: json("context"), // Additional context
  occurredAt: timestamp("occurred_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Working Memory - Temporary processing (7±2 items)
export const workingMemory = mysqlTable("working_memory", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: varchar("session_id", { length: 255 }).notNull(),
  itemType: varchar("item_type", { length: 100 }).notNull(),
  content: json("content").notNull(),
  priority: int("priority").default(5).notNull(), // 1-10 scale
  expiresAt: timestamp("expires_at").notNull(), // Auto-cleanup
  consolidatedToLongTerm: boolean("consolidated_to_long_term").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ============================================================================
// Goal Management
// ============================================================================

export const goals = mysqlTable("goals", {
  id: int("id").autoincrement().primaryKey(),
  goalId: varchar("goal_id", { length: 255 }).notNull().unique(),
  parentGoalId: varchar("parent_goal_id", { length: 255 }), // For sub-goals
  name: varchar("name", { length: 500 }).notNull(),
  description: text("description").notNull(),
  goalType: varchar("goal_type", { length: 100 }).notNull(), // strategic, tactical, operational
  priority: int("priority").default(5).notNull(), // 1-10 scale
  status: mysqlEnum("status", ["pending", "in_progress", "completed", "failed", "cancelled"]).default("pending").notNull(),
  successCriteria: json("success_criteria").notNull(),
  deadline: timestamp("deadline"),
  progress: float("progress").default(0.0).notNull(), // 0-1 scale
  assignedTo: varchar("assigned_to", { length: 255 }), // Agent ID
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
  completedAt: timestamp("completed_at"),
});

export const goalDependencies = mysqlTable("goal_dependencies", {
  id: int("id").autoincrement().primaryKey(),
  goalId: varchar("goal_id", { length: 255 }).notNull(),
  dependsOnGoalId: varchar("depends_on_goal_id", { length: 255 }).notNull(),
  dependencyType: mysqlEnum("dependency_type", ["blocks", "enables", "related"]).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ============================================================================
// Multi-Agent System
// ============================================================================

export const level5Agents = mysqlTable("level5_agents", {
  id: int("id").autoincrement().primaryKey(),
  agentId: varchar("agent_id", { length: 255 }).notNull().unique(),
  agentType: mysqlEnum("agent_type", ["manager", "specialist"]).notNull(),
  specialization: varchar("specialization", { length: 100 }), // email, calendar, research, writing, analysis
  status: mysqlEnum("status", ["idle", "busy", "offline"]).default("idle").notNull(),
  capabilities: json("capabilities").notNull(), // Array of capabilities
  performance: json("performance"), // Performance metrics
  createdAt: timestamp("created_at").defaultNow().notNull(),
  lastActiveAt: timestamp("last_active_at").defaultNow().notNull(),
});

export const agentTasks = mysqlTable("agent_tasks", {
  id: int("id").autoincrement().primaryKey(),
  taskId: varchar("task_id", { length: 255 }).notNull().unique(),
  assignedToAgentId: varchar("assigned_to_agent_id", { length: 255 }).notNull(),
  delegatedByAgentId: varchar("delegated_by_agent_id", { length: 255 }), // For manager delegation
  taskType: varchar("task_type", { length: 100 }).notNull(),
  description: text("description").notNull(),
  priority: int("priority").default(5).notNull(),
  status: mysqlEnum("status", ["pending", "in_progress", "completed", "failed"]).default("pending").notNull(),
  input: json("input"),
  output: json("output"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
});

export const agentCommunications = mysqlTable("agent_communications", {
  id: int("id").autoincrement().primaryKey(),
  fromAgentId: varchar("from_agent_id", { length: 255 }).notNull(),
  toAgentId: varchar("to_agent_id", { length: 255 }).notNull(),
  messageType: varchar("message_type", { length: 100 }).notNull(), // request, response, notification
  content: json("content").notNull(),
  relatedTaskId: varchar("related_task_id", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ============================================================================
// Innovation & Creativity
// ============================================================================

export const innovations = mysqlTable("innovations", {
  id: int("id").autoincrement().primaryKey(),
  innovationId: varchar("innovation_id", { length: 255 }).notNull().unique(),
  title: varchar("title", { length: 500 }).notNull(),
  description: text("description").notNull(),
  category: varchar("category", { length: 100 }).notNull(), // process, product, strategy, etc.
  noveltyScore: float("novelty_score").notNull(), // 0-1 scale
  feasibilityScore: float("feasibility_score").notNull(), // 0-1 scale
  impactScore: float("impact_score").notNull(), // 0-1 scale
  overallScore: float("overall_score").notNull(), // Composite score
  status: mysqlEnum("status", ["proposed", "evaluating", "approved", "rejected", "implemented"]).default("proposed").notNull(),
  proposedBy: varchar("proposed_by", { length: 255 }), // Agent ID
  relatedGoalId: varchar("related_goal_id", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export const brainstormingSessions = mysqlTable("brainstorming_sessions", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: varchar("session_id", { length: 255 }).notNull().unique(),
  topic: varchar("topic", { length: 500 }).notNull(),
  participants: json("participants"), // Array of agent IDs
  ideas: json("ideas"), // Array of idea objects
  status: mysqlEnum("status", ["active", "completed"]).default("active").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
});

// ============================================================================
// Forecasting & Prediction
// ============================================================================

export const forecasts = mysqlTable("forecasts", {
  id: int("id").autoincrement().primaryKey(),
  forecastId: varchar("forecast_id", { length: 255 }).notNull().unique(),
  forecastType: varchar("forecast_type", { length: 100 }).notNull(), // trend, outcome, scenario
  subject: varchar("subject", { length: 500 }).notNull(),
  prediction: json("prediction").notNull(),
  confidence: float("confidence").notNull(), // 0-1 scale
  timeHorizon: varchar("time_horizon", { length: 50 }).notNull(), // short, medium, long
  basedOn: json("based_on"), // Data sources and reasoning
  actualOutcome: json("actual_outcome"), // For accuracy tracking
  accuracy: float("accuracy"), // Calculated after outcome known
  createdAt: timestamp("created_at").defaultNow().notNull(),
  targetDate: timestamp("target_date").notNull(),
  resolvedAt: timestamp("resolved_at"),
});

export const scenarios = mysqlTable("scenarios", {
  id: int("id").autoincrement().primaryKey(),
  scenarioId: varchar("scenario_id", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 500 }).notNull(),
  description: text("description").notNull(),
  probability: float("probability").notNull(), // 0-1 scale
  impact: float("impact").notNull(), // 0-1 scale
  assumptions: json("assumptions").notNull(),
  implications: json("implications").notNull(),
  relatedGoalId: varchar("related_goal_id", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

// ============================================================================
// Reasoning Engines Metadata
// ============================================================================

export const reasoningCases = mysqlTable("reasoning_cases", {
  id: int("id").autoincrement().primaryKey(),
  caseId: varchar("case_id", { length: 255 }).notNull().unique(),
  reasoningType: mysqlEnum("reasoning_type", [
    "deductive",
    "inductive",
    "abductive",
    "analogical",
    "common_sense",
    "fuzzy",
    "non_monotonic"
  ]).notNull(),
  input: json("input").notNull(),
  output: json("output").notNull(),
  confidence: float("confidence").notNull(),
  executionTime: int("execution_time"), // milliseconds
  success: boolean("success").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ============================================================================
// User Maturity & Adaptation
// ============================================================================

export const userMaturity = mysqlTable("user_maturity", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull().unique(),
  maturityLevel: mysqlEnum("maturity_level", [
    "spark",
    "ignition",
    "integration",
    "amplification",
    "transformation"
  ]).notNull(),
  indicators: json("indicators").notNull(), // Data quality, tech stack, AI usage, etc.
  adaptedFeatures: json("adapted_features"), // Features enabled for this user
  lastAssessed: timestamp("last_assessed").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

// ============================================================================
// Observability & Metrics
// ============================================================================

export const systemMetrics = mysqlTable("system_metrics", {
  id: int("id").autoincrement().primaryKey(),
  metricType: varchar("metric_type", { length: 100 }).notNull(),
  metricName: varchar("metric_name", { length: 255 }).notNull(),
  value: float("value").notNull(),
  unit: varchar("unit", { length: 50 }),
  tags: json("tags"), // Additional metadata
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const errorLogs = mysqlTable("error_logs", {
  id: int("id").autoincrement().primaryKey(),
  component: varchar("component", { length: 255 }).notNull(),
  errorType: varchar("error_type", { length: 100 }).notNull(),
  errorMessage: text("error_message").notNull(),
  stackTrace: text("stack_trace"),
  context: json("context"),
  severity: mysqlEnum("severity", ["low", "medium", "high", "critical"]).notNull(),
  resolved: boolean("resolved").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  resolvedAt: timestamp("resolved_at"),
});

// ============================================================================
// Autonomous Service Metrics & Alerts
// ============================================================================

export const serviceMetrics = mysqlTable("service_metrics", {
  id: int("id").autoincrement().primaryKey(),
  serviceId: varchar("service_id", { length: 100 }).notNull(),
  serviceName: varchar("service_name", { length: 255 }).notNull(),
  metricType: mysqlEnum("metric_type", ["execution", "performance", "error", "success", "cost_savings"]).notNull(),
  value: float("value").notNull(),
  unit: varchar("unit", { length: 50 }).notNull(),
  metadata: json("metadata"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const serviceDependencies = mysqlTable("service_dependencies", {
  id: int("id").autoincrement().primaryKey(),
  sourceServiceId: varchar("source_service_id", { length: 100 }).notNull(),
  targetServiceId: varchar("target_service_id", { length: 100 }).notNull(),
  triggerType: mysqlEnum("trigger_type", ["on_success", "on_failure", "on_complete", "scheduled"]).notNull(),
  priority: int("priority").default(1).notNull(),
  enabled: boolean("enabled").default(true).notNull(),
  metadata: json("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export const serviceAlerts = mysqlTable("service_alerts", {
  id: int("id").autoincrement().primaryKey(),
  ruleId: varchar("rule_id", { length: 100 }).notNull(),
  ruleName: varchar("rule_name", { length: 255 }).notNull(),
  serviceId: varchar("service_id", { length: 100 }).notNull(),
  serviceName: varchar("service_name", { length: 255 }).notNull(),
  severity: mysqlEnum("severity", ["info", "warning", "error", "critical"]).notNull(),
  title: varchar("title", { length: 500 }).notNull(),
  message: text("message").notNull(),
  acknowledged: boolean("acknowledged").default(false).notNull(),
  acknowledgedBy: varchar("acknowledged_by", { length: 100 }),
  acknowledgedAt: timestamp("acknowledged_at"),
  channels: json("channels"), // Array of notification channels
  metadata: json("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// AI Health Metrics History - stores historical metrics for trend analysis
export const aiMetricsHistory = mysqlTable("ai_metrics_history", {
  id: int("id").autoincrement().primaryKey(),
  serviceId: varchar("service_id", { length: 100 }).notNull(),
  serviceName: varchar("service_name", { length: 255 }).notNull(),
  
  // Health metrics
  status: mysqlEnum("status", ["healthy", "degraded", "unhealthy", "unknown"]).notNull(),
  uptime: float("uptime").notNull(), // percentage
  responseTime: float("response_time").notNull(), // ms
  errorRate: float("error_rate").notNull(), // percentage
  successRate: float("success_rate").notNull(), // percentage
  requestsPerMinute: int("requests_per_minute").notNull(),
  
  // Performance metrics
  decisionAccuracy: float("decision_accuracy"),
  confidenceCalibration: float("confidence_calibration"),
  throughput: float("throughput"),
  
  // Aggregation info
  aggregationType: mysqlEnum("aggregation_type", ["raw", "minute", "hour", "day"]).default("raw").notNull(),
  
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const alertRules = mysqlTable("alert_rules", {
  id: int("id").autoincrement().primaryKey(),
  ruleId: varchar("rule_id", { length: 100 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  serviceId: varchar("service_id", { length: 100 }).notNull(), // "*" for all services
  condition: varchar("condition", { length: 100 }).notNull(),
  threshold: float("threshold").notNull(),
  severity: mysqlEnum("severity", ["info", "warning", "error", "critical"]).notNull(),
  channels: json("channels").notNull(), // Array of notification channels
  enabled: boolean("enabled").default(true).notNull(),
  cooldownMinutes: int("cooldown_minutes").default(15).notNull(),
  metadata: json("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

// Export all types
export type TrainingTask = typeof trainingTasks.$inferSelect;
export type TrainingRun = typeof trainingRuns.$inferSelect;
export type TrainingScore = typeof trainingScores.$inferSelect;
export type KnowledgeEntity = typeof knowledgeEntities.$inferSelect;
export type KnowledgeRelationship = typeof knowledgeRelationships.$inferSelect;
export type ProceduralMemory = typeof proceduralMemory.$inferSelect;
export type SemanticMemory = typeof semanticMemory.$inferSelect;
export type EpisodicMemory = typeof episodicMemory.$inferSelect;
export type WorkingMemory = typeof workingMemory.$inferSelect;
export type Goal = typeof goals.$inferSelect;
export type GoalDependency = typeof goalDependencies.$inferSelect;
export type Agent = typeof agents.$inferSelect;
export type AgentTask = typeof agentTasks.$inferSelect;
export type AgentCommunication = typeof agentCommunications.$inferSelect;
export type Innovation = typeof innovations.$inferSelect;
export type BrainstormingSession = typeof brainstormingSessions.$inferSelect;
export type Forecast = typeof forecasts.$inferSelect;
export type Scenario = typeof scenarios.$inferSelect;
export type ReasoningCase = typeof reasoningCases.$inferSelect;
export type UserMaturity = typeof userMaturity.$inferSelect;
export type SystemMetric = typeof systemMetrics.$inferSelect;
export type ErrorLog = typeof errorLogs.$inferSelect;
export type ServiceMetric = typeof serviceMetrics.$inferSelect;
export type InsertServiceMetric = typeof serviceMetrics.$inferInsert;
export type ServiceDependency = typeof serviceDependencies.$inferSelect;
export type InsertServiceDependency = typeof serviceDependencies.$inferInsert;
export type ServiceAlert = typeof serviceAlerts.$inferSelect;
export type InsertServiceAlert = typeof serviceAlerts.$inferInsert;
export type AlertRule = typeof alertRules.$inferSelect;
export type InsertAlertRule = typeof alertRules.$inferInsert;
export type AIMetricsHistory = typeof aiMetricsHistory.$inferSelect;
export type InsertAIMetricsHistory = typeof aiMetricsHistory.$inferInsert;
