CREATE TABLE `approvalHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`taskId` int NOT NULL,
	`userId` int NOT NULL,
	`action` enum('approved','rejected') NOT NULL,
	`reason` text,
	`previousStatus` varchar(64) NOT NULL,
	`newStatus` varchar(64) NOT NULL,
	`metadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `approvalHistory_id` PRIMARY KEY(`id`)
);
