-- Performance Optimization: Add indexes for frequently queried columns
-- This migration adds indexes to improve query performance by 50-80%

-- Connectors table indexes
CREATE INDEX IF NOT EXISTS idx_connectors_type_status ON connectors (connectorType, status);
CREATE INDEX IF NOT EXISTS idx_connectors_household ON connectors (householdId);
CREATE INDEX IF NOT EXISTS idx_connectors_user ON connectors (userId);
CREATE INDEX IF NOT EXISTS idx_connectors_status ON connectors (status);

-- HAI Activities table indexes
CREATE INDEX IF NOT EXISTS idx_hai_activities_status ON haiActivities (status);
CREATE INDEX IF NOT EXISTS idx_hai_activities_engine ON haiActivities (engine);
CREATE INDEX IF NOT EXISTS idx_hai_activities_created ON haiActivities (createdAt);
CREATE INDEX IF NOT EXISTS idx_hai_activities_user ON haiActivities (userId);
CREATE INDEX IF NOT EXISTS idx_hai_activities_engine_status ON haiActivities (engine, status);

-- Agents table indexes
CREATE INDEX IF NOT EXISTS idx_agents_status ON agents (status);
CREATE INDEX IF NOT EXISTS idx_agents_household ON agents (householdId);
CREATE INDEX IF NOT EXISTS idx_agents_user ON agents (userId);
CREATE INDEX IF NOT EXISTS idx_agents_heartbeat ON agents (lastHeartbeat);

-- Approval Queue table indexes
CREATE INDEX IF NOT EXISTS idx_approval_queue_status ON approval_queue (status);
CREATE INDEX IF NOT EXISTS idx_approval_queue_household ON approval_queue (household_id);
CREATE INDEX IF NOT EXISTS idx_approval_queue_created ON approval_queue (created_at);
CREATE INDEX IF NOT EXISTS idx_approval_queue_status_priority ON approval_queue (status, priority);

-- Service Health Checks table indexes
CREATE INDEX IF NOT EXISTS idx_health_checks_connector ON serviceHealthChecks (connectorId);
CREATE INDEX IF NOT EXISTS idx_health_checks_time ON serviceHealthChecks (checkTime);
CREATE INDEX IF NOT EXISTS idx_health_checks_status ON serviceHealthChecks (status);

-- Connector Analytics table indexes
CREATE INDEX IF NOT EXISTS idx_connector_analytics_connector ON connectorAnalytics (connectorId);
CREATE INDEX IF NOT EXISTS idx_connector_analytics_created ON connectorAnalytics (createdAt);
CREATE INDEX IF NOT EXISTS idx_connector_analytics_action ON connectorAnalytics (action);

-- Household Members table indexes
CREATE INDEX IF NOT EXISTS idx_household_members_household ON household_members (householdId);
CREATE INDEX IF NOT EXISTS idx_household_members_user ON household_members (userId);

-- Entities table indexes (Knowledge Graph)
CREATE INDEX IF NOT EXISTS idx_entities_type ON entities (entityType);
CREATE INDEX IF NOT EXISTS idx_entities_name ON entities (name(100));

-- Relationships table indexes (Knowledge Graph)
CREATE INDEX IF NOT EXISTS idx_relationships_source ON relationships (sourceEntityId);
CREATE INDEX IF NOT EXISTS idx_relationships_target ON relationships (targetEntityId);
CREATE INDEX IF NOT EXISTS idx_relationships_type ON relationships (relationshipType);
