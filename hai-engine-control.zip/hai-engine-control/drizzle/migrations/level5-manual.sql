-- Level 5 AI Manual Migration
-- Created: 2024-12-11
-- This migration creates all Level 5 AI tables

-- Training Loop & Continuous Improvement
CREATE TABLE IF NOT EXISTS `training_tasks` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `name` varchar(255) NOT NULL,
  `instructions` text NOT NULL,
  `scoring_function` text NOT NULL,
  `starting_solution` text,
  `status` enum('pending', 'running', 'completed', 'failed') DEFAULT 'pending' NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `completed_at` timestamp
);

CREATE TABLE IF NOT EXISTS `training_runs` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `task_id` int NOT NULL,
  `agent_type` enum('llm', 'human') NOT NULL,
  `agent_id` varchar(255),
  `status` enum('running', 'completed', 'failed') DEFAULT 'running' NOT NULL,
  `started_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `completed_at` timestamp,
  `iterations` int DEFAULT 0 NOT NULL,
  `best_score` float,
  `final_solution` text
);

CREATE TABLE IF NOT EXISTS `training_scores` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `run_id` int NOT NULL,
  `iteration` int NOT NULL,
  `val_accuracy` float,
  `test_accuracy` float,
  `overall_score` float NOT NULL,
  `timestamp` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `metadata` json
);

-- Knowledge Graph
CREATE TABLE IF NOT EXISTS `knowledge_entities` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `entity_id` varchar(255) NOT NULL UNIQUE,
  `entity_type` varchar(100) NOT NULL,
  `name` varchar(500) NOT NULL,
  `properties` json,
  `source` varchar(255),
  `confidence` float DEFAULT 1.0 NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS `knowledge_relationships` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `relationship_id` varchar(255) NOT NULL UNIQUE,
  `source_entity_id` varchar(255) NOT NULL,
  `target_entity_id` varchar(255) NOT NULL,
  `relationship_type` varchar(100) NOT NULL,
  `properties` json,
  `confidence` float DEFAULT 1.0 NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL
);

-- Memory Systems
CREATE TABLE IF NOT EXISTS `procedural_memory` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `skill_name` varchar(255) NOT NULL,
  `skill_type` varchar(100) NOT NULL,
  `procedure` json NOT NULL,
  `success_rate` float DEFAULT 0.0 NOT NULL,
  `times_executed` int DEFAULT 0 NOT NULL,
  `last_executed` timestamp,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS `semantic_memory` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `concept_id` varchar(255) NOT NULL UNIQUE,
  `concept_type` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `related_concepts` json,
  `confidence` float DEFAULT 1.0 NOT NULL,
  `source` varchar(255),
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS `episodic_memory` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `episode_id` varchar(255) NOT NULL UNIQUE,
  `event_type` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `participants` json,
  `location` varchar(255),
  `emotional_context` json,
  `outcome` text,
  `occurred_at` timestamp NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS `working_memory` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `item_id` varchar(255) NOT NULL UNIQUE,
  `item_type` varchar(100) NOT NULL,
  `content` json NOT NULL,
  `priority` int DEFAULT 5 NOT NULL,
  `ttl_seconds` int DEFAULT 300 NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `expires_at` timestamp NOT NULL
);

-- Goal Management
CREATE TABLE IF NOT EXISTS `goals` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `goal_id` varchar(255) NOT NULL UNIQUE,
  `title` varchar(500) NOT NULL,
  `description` text,
  `goal_type` varchar(100) NOT NULL,
  `priority` int DEFAULT 5 NOT NULL,
  `status` enum('pending', 'in_progress', 'completed', 'failed', 'cancelled') DEFAULT 'pending' NOT NULL,
  `success_criteria` json NOT NULL,
  `deadline` timestamp,
  `progress` float DEFAULT 0.0 NOT NULL,
  `assigned_to` varchar(255),
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  `completed_at` timestamp
);

CREATE TABLE IF NOT EXISTS `goal_dependencies` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `goal_id` varchar(255) NOT NULL,
  `depends_on_goal_id` varchar(255) NOT NULL,
  `dependency_type` enum('blocks', 'enables', 'related') NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Multi-Agent System
CREATE TABLE IF NOT EXISTS `level5_agents` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `agent_id` varchar(255) NOT NULL UNIQUE,
  `agent_type` enum('manager', 'specialist') NOT NULL,
  `specialization` varchar(100),
  `status` enum('idle', 'busy', 'offline') DEFAULT 'idle' NOT NULL,
  `capabilities` json NOT NULL,
  `performance` json,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `last_active_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS `agent_tasks` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `task_id` varchar(255) NOT NULL UNIQUE,
  `assigned_to_agent_id` varchar(255) NOT NULL,
  `delegated_by_agent_id` varchar(255),
  `task_type` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `priority` int DEFAULT 5 NOT NULL,
  `status` enum('pending', 'in_progress', 'completed', 'failed') DEFAULT 'pending' NOT NULL,
  `input` json,
  `output` json,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `started_at` timestamp,
  `completed_at` timestamp
);

CREATE TABLE IF NOT EXISTS `agent_communications` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `from_agent_id` varchar(255) NOT NULL,
  `to_agent_id` varchar(255) NOT NULL,
  `message_type` varchar(100) NOT NULL,
  `content` json NOT NULL,
  `related_task_id` varchar(255),
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Innovation & Creativity
CREATE TABLE IF NOT EXISTS `innovations` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `innovation_id` varchar(255) NOT NULL UNIQUE,
  `title` varchar(500) NOT NULL,
  `description` text NOT NULL,
  `category` varchar(100) NOT NULL,
  `novelty_score` float NOT NULL,
  `feasibility_score` float NOT NULL,
  `impact_score` float NOT NULL,
  `overall_score` float NOT NULL,
  `status` enum('proposed', 'evaluating', 'approved', 'rejected', 'implemented') DEFAULT 'proposed' NOT NULL,
  `proposed_by` varchar(255),
  `related_goal_id` varchar(255),
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS `brainstorming_sessions` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `session_id` varchar(255) NOT NULL UNIQUE,
  `topic` varchar(500) NOT NULL,
  `participants` json,
  `ideas` json,
  `status` enum('active', 'completed') DEFAULT 'active' NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `completed_at` timestamp
);

-- Forecasting & Prediction
CREATE TABLE IF NOT EXISTS `forecasts` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `forecast_id` varchar(255) NOT NULL UNIQUE,
  `forecast_type` varchar(100) NOT NULL,
  `target_metric` varchar(255) NOT NULL,
  `prediction` json NOT NULL,
  `confidence_interval` json,
  `methodology` varchar(255),
  `forecast_horizon_days` int NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `target_date` timestamp NOT NULL,
  `actual_value` float,
  `accuracy_score` float
);

CREATE TABLE IF NOT EXISTS `scenarios` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `scenario_id` varchar(255) NOT NULL UNIQUE,
  `name` varchar(500) NOT NULL,
  `description` text,
  `probability` float NOT NULL,
  `impact_score` float NOT NULL,
  `assumptions` json,
  `outcomes` json,
  `related_forecast_id` varchar(255),
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Reasoning Engines
CREATE TABLE IF NOT EXISTS `reasoning_cases` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `case_id` varchar(255) NOT NULL UNIQUE,
  `reasoning_type` enum('deductive', 'inductive', 'abductive', 'analogical', 'common_sense', 'fuzzy', 'non_monotonic') NOT NULL,
  `input` json NOT NULL,
  `reasoning_steps` json NOT NULL,
  `conclusion` json NOT NULL,
  `confidence` float NOT NULL,
  `success` boolean NOT NULL,
  `execution_time_ms` int,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- User Maturity
CREATE TABLE IF NOT EXISTS `user_maturity` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `user_id` int NOT NULL UNIQUE,
  `maturity_level` enum('spark', 'adoption', 'integration', 'amplification', 'transformation') NOT NULL,
  `ai_literacy_score` float DEFAULT 0.0 NOT NULL,
  `usage_frequency` varchar(50),
  `feature_adoption` json,
  `last_assessed` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `progression_history` json,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL
);

-- Observability
CREATE TABLE IF NOT EXISTS `system_metrics` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `metric_name` varchar(255) NOT NULL,
  `metric_value` float NOT NULL,
  `metric_unit` varchar(50),
  `component` varchar(255),
  `tags` json,
  `timestamp` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS `error_logs` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `error_type` varchar(255) NOT NULL,
  `error_message` text NOT NULL,
  `stack_trace` text,
  `component` varchar(255),
  `severity` enum('low', 'medium', 'high', 'critical') NOT NULL,
  `context` json,
  `resolved` boolean DEFAULT FALSE NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `resolved_at` timestamp
);

-- Create indexes for performance
CREATE INDEX idx_training_tasks_status ON training_tasks(status);
CREATE INDEX idx_training_runs_task_id ON training_runs(task_id);
CREATE INDEX idx_knowledge_entities_type ON knowledge_entities(entity_type);
CREATE INDEX idx_knowledge_relationships_source ON knowledge_relationships(source_entity_id);
CREATE INDEX idx_knowledge_relationships_target ON knowledge_relationships(target_entity_id);
CREATE INDEX idx_goals_status ON goals(status);
CREATE INDEX idx_goals_assigned_to ON goals(assigned_to);
CREATE INDEX idx_agent_tasks_status ON agent_tasks(status);
CREATE INDEX idx_agent_tasks_assigned_to ON agent_tasks(assigned_to_agent_id);
CREATE INDEX idx_forecasts_target_date ON forecasts(target_date);
CREATE INDEX idx_reasoning_cases_type ON reasoning_cases(reasoning_type);
CREATE INDEX idx_system_metrics_timestamp ON system_metrics(timestamp);
CREATE INDEX idx_error_logs_severity ON error_logs(severity);
CREATE INDEX idx_error_logs_resolved ON error_logs(resolved);
