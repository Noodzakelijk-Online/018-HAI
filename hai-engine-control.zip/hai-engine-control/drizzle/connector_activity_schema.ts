import { int, mysqlTable, text, timestamp, varchar, mysqlEnum } from "drizzle-orm/mysql-core";

/**
 * Connector Activity Log
 * Tracks all connector actions for analytics and debugging
 */
export const connectorActivityLog = mysqlTable("connector_activity_log", {
  id: int("id").autoincrement().primaryKey(),
  connectorId: int("connectorId").notNull(),
  userId: int("userId").notNull(),
  action: varchar("action", { length: 64 }).notNull(), // e.g., "send_email", "create_event", "health_check"
  status: mysqlEnum("status", ["success", "failed", "pending"]).notNull(),
  requestData: text("requestData"), // JSON of request parameters
  responseData: text("responseData"), // JSON of response data
  errorMessage: text("errorMessage"),
  duration: int("duration"), // Duration in milliseconds
  apiCallCount: int("apiCallCount").default(1).notNull(), // Number of API calls made
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ConnectorActivityLog = typeof connectorActivityLog.$inferSelect;
export type InsertConnectorActivityLog = typeof connectorActivityLog.$inferInsert;
