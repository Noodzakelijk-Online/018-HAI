-- Playbook Engine Schema
-- Predefined workflows with templates and versioning

-- Playbooks table
CREATE TABLE IF NOT EXISTS playbooks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  category VARCHAR(100),
  version VARCHAR(50) NOT NULL DEFAULT '1.0.0',
  status ENUM('draft', 'active', 'archived', 'deprecated') DEFAULT 'draft',
  definition JSON NOT NULL, -- Workflow steps, conditions, actions
  metadata JSON, -- Tags, author, created date, etc.
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_category (category),
  INDEX idx_status (status)
);

-- Playbook executions table
CREATE TABLE IF NOT EXISTS playbook_executions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  playbook_id INT NOT NULL,
  task_id INT, -- Link to task if triggered by task
  status ENUM('pending', 'running', 'completed', 'failed', 'cancelled') DEFAULT 'pending',
  current_step INT DEFAULT 0,
  total_steps INT NOT NULL,
  started_at TIMESTAMP,
  completed_at TIMESTAMP,
  error_message TEXT,
  execution_log JSON, -- Step-by-step execution log
  context JSON, -- Runtime variables and state
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (playbook_id) REFERENCES playbooks(id) ON DELETE CASCADE,
  INDEX idx_status (status),
  INDEX idx_playbook_id (playbook_id)
);

-- Playbook templates table
CREATE TABLE IF NOT EXISTS playbook_templates (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  category VARCHAR(100),
  template JSON NOT NULL, -- Template structure with placeholders
  example JSON, -- Example filled template
  is_public BOOLEAN DEFAULT false,
  usage_count INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_category (category),
  INDEX idx_public (is_public)
);
