import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, json, boolean, decimal } from "drizzle-orm/mysql-core";

/**
 * Communication Management System Database Schema
 * 
 * This schema supports the autonomous communication management system,
 * enabling HAI to handle all personal and professional communications
 * across multiple platforms with intelligent prioritization and response.
 */

// ============================================================================
// UNIFIED MESSAGES
// ============================================================================

/**
 * Unified message storage across all platforms
 * Transforms platform-specific messages into standardized format
 */
export const unifiedMessages = mysqlTable("unified_messages", {
  id: int("id").autoincrement().primaryKey(),
  
  // Platform Information
  platform: mysqlEnum("platform", [
    "email", "sms", "whatsapp", "telegram", "slack", "discord",
    "twitter", "linkedin", "facebook", "messenger", "teams"
  ]).notNull(),
  platformMessageId: varchar("platform_message_id", { length: 255 }).notNull(),
  
  // Participants
  senderId: int("sender_id").notNull(), // References contacts table
  conversationId: varchar("conversation_id", { length: 255 }).notNull(),
  
  // Content
  textContent: text("text_content"),
  htmlContent: text("html_content"),
  mediaAttachments: json("media_attachments").$type<Array<{
    type: 'image' | 'video' | 'audio' | 'document';
    url: string;
    filename?: string;
    mimeType?: string;
    size?: number;
  }>>(),
  mentions: json("mentions").$type<number[]>(), // Array of contact IDs
  links: json("links").$type<string[]>(), // Extracted URLs
  
  // Metadata
  timestamp: timestamp("timestamp").notNull(),
  timezone: varchar("timezone", { length: 50 }),
  language: varchar("language", { length: 10 }).default("en"),
  
  // Analysis Results
  urgencyScore: int("urgency_score").default(50), // 0-100
  sentimentScore: decimal("sentiment_score", { precision: 3, scale: 2 }).default("0.00"), // -1.0 to 1.0
  sentimentLabel: mysqlEnum("sentiment_label", ["positive", "neutral", "negative"]).default("neutral"),
  topics: json("topics").$type<Array<{
    name: string;
    confidence: number;
  }>>(),
  entities: json("entities").$type<Array<{
    type: string;
    value: string;
    confidence: number;
  }>>(),
  detectedIntent: varchar("detected_intent", { length: 100 }),
  
  // Priority
  priorityScore: int("priority_score").default(50), // 0-100 composite score
  relationshipScore: int("relationship_score").default(50), // 0-100
  topicImportanceScore: int("topic_importance_score").default(50), // 0-100
  deadlineProximityScore: int("deadline_proximity_score").default(0), // 0-100
  
  // Status
  status: mysqlEnum("status", [
    "unread", "analyzing", "queued", "generating_response",
    "scheduled", "sent", "escalated", "archived"
  ]).default("unread").notNull(),
  
  // Response Tracking
  responseId: int("response_id"), // References this table for sent responses
  responseGeneratedAt: timestamp("response_generated_at"),
  responseScheduledFor: timestamp("response_scheduled_for"),
  responseSentAt: timestamp("response_sent_at"),
  
  // Escalation
  escalated: boolean("escalated").default(false),
  escalationReason: varchar("escalation_reason", { length: 255 }),
  escalatedAt: timestamp("escalated_at"),
  assignedTo: int("assigned_to"), // User ID for human review
  reviewedAt: timestamp("reviewed_at"),
  
  // Household Context
  householdId: int("household_id").notNull(),
  
  // Platform-Specific Metadata
  platformMetadata: json("platform_metadata").$type<Record<string, any>>(),
  
  // Timestamps
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type UnifiedMessage = typeof unifiedMessages.$inferSelect;
export type InsertUnifiedMessage = typeof unifiedMessages.$inferInsert;

// ============================================================================
// CONTACTS
// ============================================================================

/**
 * Contact information and relationship scoring
 * Tracks all communication participants with relationship metrics
 */
export const communicationContacts = mysqlTable("communication_contacts", {
  id: int("id").autoincrement().primaryKey(),
  
  // Identity
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  phoneNumber: varchar("phone_number", { length: 50 }),
  
  // Platform Identifiers
  whatsappId: varchar("whatsapp_id", { length: 255 }),
  telegramId: varchar("telegram_id", { length: 255 }),
  slackId: varchar("slack_id", { length: 255 }),
  twitterHandle: varchar("twitter_handle", { length: 100 }),
  linkedinUrl: varchar("linkedin_url", { length: 255 }),
  facebookId: varchar("facebook_id", { length: 255 }),
  
  // Relationship Metrics
  relationshipScore: int("relationship_score").default(50), // 0-100
  relationshipType: mysqlEnum("relationship_type", [
    "family", "close_friend", "friend", "colleague", 
    "manager", "direct_report", "client", "vendor",
    "acquaintance", "unknown"
  ]).default("unknown"),
  
  // Communication Patterns
  totalMessagesReceived: int("total_messages_received").default(0),
  totalMessagesSent: int("total_messages_sent").default(0),
  averageResponseTime: int("average_response_time").default(0), // Minutes
  lastContactedAt: timestamp("last_contacted_at"),
  communicationFrequency: mysqlEnum("communication_frequency", [
    "daily", "weekly", "monthly", "yearly", "rare"
  ]).default("rare"),
  
  // Preferences
  preferredPlatform: varchar("preferred_platform", { length: 50 }),
  preferredTone: mysqlEnum("preferred_tone", [
    "formal", "professional", "casual", "intimate"
  ]).default("professional"),
  vipStatus: boolean("vip_status").default(false),
  
  // Household Context
  householdId: int("household_id").notNull(),
  
  // Timestamps
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type CommunicationContact = typeof communicationContacts.$inferSelect;
export type InsertCommunicationContact = typeof communicationContacts.$inferInsert;

// ============================================================================
// CONVERSATION CONTEXTS
// ============================================================================

/**
 * Conversation context and history tracking
 * Maintains rolling window of recent interactions for context-aware responses
 */
export const conversationContexts = mysqlTable("conversation_contexts", {
  id: int("id").autoincrement().primaryKey(),
  
  // Identification
  conversationId: varchar("conversation_id", { length: 255 }).notNull().unique(),
  platform: varchar("platform", { length: 50 }).notNull(),
  
  // Participants
  contactId: int("contact_id").notNull(),
  
  // Context
  recentMessages: json("recent_messages").$type<Array<{
    messageId: number;
    role: 'user' | 'assistant';
    content: string;
    timestamp: string;
  }>>(), // Last 10 messages
  
  // Topics and Entities
  activeTopics: json("active_topics").$type<string[]>(),
  mentionedEntities: json("mentioned_entities").$type<Record<string, string[]>>(),
  
  // Open Items
  openQuestions: json("open_questions").$type<string[]>(),
  pendingCommitments: json("pending_commitments").$type<Array<{
    commitment: string;
    deadline?: string;
    completed: boolean;
  }>>(),
  
  // Conversation State
  conversationStage: mysqlEnum("conversation_stage", [
    "initial", "ongoing", "closing", "closed"
  ]).default("initial"),
  lastInteractionAt: timestamp("last_interaction_at").notNull(),
  
  // Household Context
  householdId: int("household_id").notNull(),
  
  // Timestamps
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type ConversationContext = typeof conversationContexts.$inferSelect;
export type InsertConversationContext = typeof conversationContexts.$inferInsert;

// ============================================================================
// RESPONSE TEMPLATES
// ============================================================================

/**
 * Reusable response templates for common scenarios
 * Provides structure and consistency for frequent communication patterns
 */
export const responseTemplates = mysqlTable("response_templates", {
  id: int("id").autoincrement().primaryKey(),
  
  // Identification
  name: varchar("name", { length: 255 }).notNull(),
  category: mysqlEnum("category", [
    "meeting_confirmation", "status_update", "thank_you",
    "apology", "information_request", "follow_up",
    "introduction", "decline", "acceptance", "custom"
  ]).notNull(),
  
  // Template Content
  template: text("template").notNull(), // Template with placeholders like {{NAME}}, {{DATE}}, etc.
  variables: json("variables").$type<Array<{
    name: string;
    type: 'string' | 'date' | 'number';
    required: boolean;
    description: string;
  }>>(),
  
  // Tone and Style
  tone: mysqlEnum("tone", ["formal", "professional", "casual", "intimate"]).notNull(),
  platforms: json("platforms").$type<string[]>(), // Applicable platforms
  
  // Usage Tracking
  usageCount: int("usage_count").default(0),
  successRate: decimal("success_rate", { precision: 5, scale: 2 }).default("0.00"), // Percentage
  
  // Household Context
  householdId: int("household_id").notNull(),
  isGlobal: boolean("is_global").default(false), // Available to all households
  
  // Timestamps
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type ResponseTemplate = typeof responseTemplates.$inferSelect;
export type InsertResponseTemplate = typeof responseTemplates.$inferInsert;

// ============================================================================
// ESCALATION QUEUE
// ============================================================================

/**
 * Human review queue for escalated messages
 * Tracks messages requiring human intervention with draft responses
 */
export const communicationEscalations = mysqlTable("communication_escalations", {
  id: int("id").autoincrement().primaryKey(),
  
  // Message Reference
  messageId: int("message_id").notNull().unique(), // References unified_messages
  
  // Escalation Details
  reason: mysqlEnum("reason", [
    "low_confidence", "vip_sender", "sensitive_topic",
    "legal_matter", "financial_commitment", "conflict_detected",
    "novel_situation", "explicit_request", "high_negative_sentiment"
  ]).notNull(),
  confidenceScore: int("confidence_score"), // 0-100
  
  // Draft Response
  draftResponse: text("draft_response"),
  draftConfidence: int("draft_confidence"), // 0-100
  
  // Priority
  priority: mysqlEnum("priority", ["critical", "high", "medium", "low"]).notNull(),
  
  // Review Status
  status: mysqlEnum("status", [
    "pending", "in_review", "approved", "edited", "rejected", "deferred"
  ]).default("pending").notNull(),
  
  // Human Actions
  assignedTo: int("assigned_to"), // User ID
  reviewedBy: int("reviewed_by"), // User ID
  reviewedAt: timestamp("reviewed_at"),
  finalResponse: text("final_response"),
  reviewNotes: text("review_notes"),
  
  // Learning
  humanAction: mysqlEnum("human_action", [
    "approved_draft", "edited_draft", "wrote_new", "deferred"
  ]),
  editDistance: int("edit_distance"), // Levenshtein distance between draft and final
  
  // Household Context
  householdId: int("household_id").notNull(),
  
  // Timestamps
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type CommunicationEscalation = typeof communicationEscalations.$inferSelect;
export type InsertCommunicationEscalation = typeof communicationEscalations.$inferInsert;

// ============================================================================
// COMMUNICATION ANALYTICS
// ============================================================================

/**
 * Analytics and metrics for communication management
 * Tracks performance, learning progress, and system effectiveness
 */
export const communicationAnalytics = mysqlTable("communication_analytics", {
  id: int("id").autoincrement().primaryKey(),
  
  // Time Period
  date: timestamp("date").notNull(),
  period: mysqlEnum("period", ["hourly", "daily", "weekly", "monthly"]).notNull(),
  
  // Message Volume
  totalMessages: int("total_messages").default(0),
  messagesPerPlatform: json("messages_per_platform").$type<Record<string, number>>(),
  
  // Response Metrics
  autonomousResponses: int("autonomous_responses").default(0),
  escalatedMessages: int("escalated_messages").default(0),
  averageResponseTime: int("average_response_time").default(0), // Minutes
  averageConfidenceScore: decimal("average_confidence_score", { precision: 5, scale: 2 }),
  
  // Priority Distribution
  urgentMessages: int("urgent_messages").default(0),
  highPriorityMessages: int("high_priority_messages").default(0),
  mediumPriorityMessages: int("medium_priority_messages").default(0),
  lowPriorityMessages: int("low_priority_messages").default(0),
  
  // Quality Metrics
  successfulResponses: int("successful_responses").default(0), // No negative follow-up
  responseAccuracy: decimal("response_accuracy", { precision: 5, scale: 2 }),
  toneAppropriatenessScore: decimal("tone_appropriateness_score", { precision: 5, scale: 2 }),
  
  // Learning Metrics
  draftApprovalRate: decimal("draft_approval_rate", { precision: 5, scale: 2 }),
  averageEditDistance: int("average_edit_distance"),
  newPatternsLearned: int("new_patterns_learned").default(0),
  
  // Household Context
  householdId: int("household_id").notNull(),
  
  // Timestamps
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type CommunicationAnalytics = typeof communicationAnalytics.$inferSelect;
export type InsertCommunicationAnalytics = typeof communicationAnalytics.$inferInsert;

// ============================================================================
// TONE PROFILES
// ============================================================================

/**
 * Learned tone profiles for each contact
 * Captures appropriate communication style based on relationship and history
 */
export const toneProfiles = mysqlTable("tone_profiles", {
  id: int("id").autoincrement().primaryKey(),
  
  // Contact Reference
  contactId: int("contact_id").notNull().unique(),
  
  // Tone Dimensions
  formalityLevel: int("formality_level").default(50), // 0=very casual, 100=very formal
  emotionalWarmth: int("emotional_warmth").default(50), // 0=distant, 100=intimate
  linguisticComplexity: int("linguistic_complexity").default(50), // 0=simple, 100=sophisticated
  
  // Style Characteristics
  useContractions: boolean("use_contractions").default(true),
  useEmoji: boolean("use_emoji").default(false),
  useExclamations: boolean("use_exclamations").default(false),
  greetingStyle: varchar("greeting_style", { length: 100 }).default("Hi"),
  closingStyle: varchar("closing_style", { length: 100 }).default("Thanks"),
  
  // Learned Patterns
  characteristicPhrases: json("characteristic_phrases").$type<string[]>(),
  avoidedPhrases: json("avoided_phrases").$type<string[]>(),
  typicalResponseLength: int("typical_response_length").default(100), // Words
  
  // Confidence
  profileConfidence: int("profile_confidence").default(50), // 0-100
  sampleSize: int("sample_size").default(0), // Number of messages analyzed
  
  // Household Context
  householdId: int("household_id").notNull(),
  
  // Timestamps
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type ToneProfile = typeof toneProfiles.$inferSelect;
export type InsertToneProfile = typeof toneProfiles.$inferInsert;
