/**
 * Approval Queue Schema
 * 
 * Stores pending decisions that require human approval before execution
 */

import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, json } from "drizzle-orm/mysql-core";

export const approvalQueue = mysqlTable("approval_queue", {
  id: int("id").autoincrement().primaryKey(),
  
  // What needs approval
  type: mysqlEnum("type", ["email_response", "calendar_event", "task_execution", "decision"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  
  // Context
  metadata: json("metadata"), // Stores email details, calendar event, etc.
  
  // Decision info
  suggestedAction: text("suggested_action"), // What HAI suggests doing
  reasoning: text("reasoning"), // Why HAI suggests this action
  confidence: int("confidence"), // 0-100
  
  // Status
  status: mysqlEnum("status", ["pending", "approved", "rejected", "expired"]).default("pending").notNull(),
  priority: mysqlEnum("priority", ["low", "medium", "high", "urgent"]).default("medium").notNull(),
  
  // Ownership
  householdId: int("household_id").notNull(),
  createdBy: int("created_by"), // Agent/engine that created it (0 for autonomous)
  reviewedBy: int("reviewed_by"), // User who approved/rejected
  
  // Timestamps
  createdAt: timestamp("created_at").defaultNow().notNull(),
  reviewedAt: timestamp("reviewed_at"),
  expiresAt: timestamp("expires_at"), // Auto-reject if not reviewed by this time
});

export type ApprovalQueueItem = typeof approvalQueue.$inferSelect;
export type InsertApprovalQueueItem = typeof approvalQueue.$inferInsert;
