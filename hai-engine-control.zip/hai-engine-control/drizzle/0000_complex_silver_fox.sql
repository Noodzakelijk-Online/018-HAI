CREATE TABLE `connectors` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`connectorType` varchar(64) NOT NULL,
	`name` varchar(255) NOT NULL,
	`status` enum('connected','disconnected','error','pending_auth') NOT NULL DEFAULT 'pending_auth',
	`credentials` text,
	`lastSync` timestamp,
	`syncFrequency` int DEFAULT 3600,
	`errorMessage` text,
	`metadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `connectors_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `decisions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`taskId` int,
	`decisionType` varchar(64) NOT NULL,
	`context` json NOT NULL,
	`options` json NOT NULL,
	`selectedOption` text NOT NULL,
	`confidence` int NOT NULL,
	`reasoning` text,
	`policyViolations` json,
	`approvedBy` int,
	`approvedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `decisions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `engineMetrics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`engineId` varchar(64) NOT NULL,
	`metricType` varchar(64) NOT NULL,
	`value` text NOT NULL,
	`unit` varchar(32),
	`timestamp` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `engineMetrics_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `engines` (
	`id` int AUTO_INCREMENT NOT NULL,
	`engineId` varchar(64) NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`status` enum('running','stopped','error','initializing') NOT NULL DEFAULT 'stopped',
	`autonomyLevel` int NOT NULL DEFAULT 0,
	`priority` enum('critical','high','medium','low') NOT NULL DEFAULT 'medium',
	`dependencies` json,
	`lastHealthCheck` timestamp,
	`errorMessage` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `engines_id` PRIMARY KEY(`id`),
	CONSTRAINT `engines_engineId_unique` UNIQUE(`engineId`)
);
--> statement-breakpoint
CREATE TABLE `entities` (
	`id` int AUTO_INCREMENT NOT NULL,
	`entityType` varchar(64) NOT NULL,
	`name` varchar(255) NOT NULL,
	`properties` json,
	`confidence` int NOT NULL DEFAULT 100,
	`sourceEventId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `entities_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventType` varchar(64) NOT NULL,
	`direction` enum('incoming','outgoing','system') NOT NULL,
	`sourceEngine` varchar(64),
	`targetEngine` varchar(64),
	`userId` int,
	`entityType` varchar(64),
	`entityId` int,
	`payload` json,
	`metadata` json,
	`timestamp` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `policies` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`policyType` varchar(64) NOT NULL,
	`rules` json NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`priority` int NOT NULL DEFAULT 0,
	`version` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `policies_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `relationships` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sourceEntityId` int NOT NULL,
	`targetEntityId` int NOT NULL,
	`relationshipType` varchar(64) NOT NULL,
	`properties` json,
	`confidence` int NOT NULL DEFAULT 100,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `relationships_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `services` (
	`id` int AUTO_INCREMENT NOT NULL,
	`serviceId` varchar(64) NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`category` varchar(64),
	`apiEndpoint` text,
	`authType` varchar(32),
	`capabilities` json,
	`tosUrl` text,
	`privacyPolicyUrl` text,
	`legalFlags` json,
	`freeTier` boolean DEFAULT false,
	`status` enum('available','deprecated','beta') NOT NULL DEFAULT 'available',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `services_id` PRIMARY KEY(`id`),
	CONSTRAINT `services_serviceId_unique` UNIQUE(`serviceId`)
);
--> statement-breakpoint
CREATE TABLE `tasks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`status` enum('draft','pending_approval','approved','in_progress','completed','failed','cancelled') NOT NULL DEFAULT 'draft',
	`priority` enum('low','medium','high','urgent') NOT NULL DEFAULT 'medium',
	`autonomyLevel` int NOT NULL DEFAULT 0,
	`assignedEngine` varchar(64),
	`scheduledFor` timestamp,
	`startedAt` timestamp,
	`completedAt` timestamp,
	`result` json,
	`errorMessage` text,
	`metadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `tasks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userTraits` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`traitType` varchar(64) NOT NULL,
	`traitValue` text NOT NULL,
	`confidence` int NOT NULL DEFAULT 50,
	`evidence` json,
	`lastUpdated` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `userTraits_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
