import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, json, decimal } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  // Authentication security fields
  passwordHash: text("passwordHash"), // For local auth (optional, OAuth users won't have this)
  failedLoginAttempts: int("failedLoginAttempts").default(0).notNull(),
  accountLockedUntil: timestamp("accountLockedUntil"),
  passwordResetToken: varchar("passwordResetToken", { length: 255 }),
  passwordResetExpiry: timestamp("passwordResetExpiry"),
  lastPasswordChange: timestamp("lastPasswordChange"),
  // Two-factor authentication fields
  twoFactorSecret: text("twoFactorSecret"), // TOTP secret for 2FA
  twoFactorEnabled: int("twoFactorEnabled").default(0).notNull(), // 0=disabled, 1=enabled (using int for MySQL compatibility)
  twoFactorBackupCodes: text("twoFactorBackupCodes"), // JSON array of backup codes
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
  lastDashboardVisit: timestamp("lastDashboardVisit"), // Track when user last viewed dashboard
});
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Approval Queue
export const approvalQueue = mysqlTable("approval_queue", {
  id: int("id").autoincrement().primaryKey(),
  
  // What needs approval
  type: mysqlEnum("type", ["email_response", "calendar_event", "task_execution", "decision"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  
  // Context
  metadata: json("metadata"), // Stores email details, calendar event, etc.
  
  // Decision info
  suggestedAction: text("suggested_action"), // What HAI suggests doing
  reasoning: text("reasoning"), // Why HAI suggests this action
  confidence: int("confidence"), // 0-100
  
  // Status
  status: mysqlEnum("status", ["pending", "approved", "rejected", "expired"]).default("pending").notNull(),
  priority: mysqlEnum("priority", ["low", "medium", "high", "urgent"]).default("medium").notNull(),
  
  // Ownership
  householdId: int("household_id").notNull(),
  createdBy: int("created_by"), // Agent/engine that created it (0 for autonomous)
  reviewedBy: int("reviewed_by"), // User who approved/rejected
  
  // Timestamps
  createdAt: timestamp("created_at").defaultNow().notNull(),
  reviewedAt: timestamp("reviewed_at"),
  expiresAt: timestamp("expires_at"), // Auto-reject if not reviewed by this time
});

export type ApprovalQueueItem = typeof approvalQueue.$inferSelect;
export type InsertApprovalQueueItem = typeof approvalQueue.$inferInsert;

/**
 * Households table - primary container for family/group resources
 */
export const households = mysqlTable("households", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  settings: text("settings"), // JSON: preferences, configurations
});

export type Household = typeof households.$inferSelect;
export type InsertHousehold = typeof households.$inferInsert;

/**
 * Household members - links users to households
 */
export const householdMembers = mysqlTable("household_members", {
  id: int("id").autoincrement().primaryKey(),
  householdId: int("householdId").notNull(),
  userId: int("userId").notNull(),
  role: mysqlEnum("role", ["owner", "member"]).default("member").notNull(),
  joinedAt: timestamp("joinedAt").defaultNow().notNull(),
});

export type HouseholdMember = typeof householdMembers.$inferSelect;
export type InsertHouseholdMember = typeof householdMembers.$inferInsert;

/**
 * Household invitations - pending invitations to join households
 */
export const householdInvitations = mysqlTable("household_invitations", {
  id: int("id").autoincrement().primaryKey(),
  householdId: int("householdId").notNull(),
  invitedBy: int("invitedBy").notNull(), // userId who created the invitation
  invitedEmail: varchar("invitedEmail", { length: 320 }), // Optional: email of invitee
  token: varchar("token", { length: 64 }).notNull().unique(), // Unique invitation token
  status: mysqlEnum("status", ["pending", "accepted", "revoked", "expired"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  expiresAt: timestamp("expiresAt").notNull(), // Invitation expiration (7 days default)
  acceptedAt: timestamp("acceptedAt"),
  acceptedBy: int("acceptedBy"), // userId who accepted the invitation
});

export type HouseholdInvitation = typeof householdInvitations.$inferSelect;
export type InsertHouseholdInvitation = typeof householdInvitations.$inferInsert;

export const tags = mysqlTable("tags", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 50 }).notNull(),
  color: varchar("color", { length: 7 }).notNull().default("#3b82f6"), // hex color
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Tag = typeof tags.$inferSelect;
export type InsertTag = typeof tags.$inferInsert;

export const serviceTags = mysqlTable("service_tags", {
  id: int("id").autoincrement().primaryKey(),
  serviceId: int("serviceId").notNull(),
  tagId: int("tagId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ServiceTag = typeof serviceTags.$inferSelect;
export type InsertServiceTag = typeof serviceTags.$inferInsert;

// TODO: Add your tables here

/**
 * Engines table - tracks all HAI engines and their status
 */
export const engines = mysqlTable("engines", {
  id: int("id").autoincrement().primaryKey(),
  engineId: varchar("engineId", { length: 64 }).notNull().unique(), // e.g., "hle", "frontier", "sme"
  name: varchar("name", { length: 255 }).notNull(), // Human-readable name
  description: text("description"),
  status: mysqlEnum("status", ["running", "stopped", "error", "initializing"]).default("stopped").notNull(),
  autonomyLevel: int("autonomyLevel").default(0).notNull(), // 0-5
  priority: mysqlEnum("priority", ["critical", "high", "medium", "low"]).default("medium").notNull(),
  dependencies: json("dependencies").$type<string[]>(), // Array of engine IDs this depends on
  lastHealthCheck: timestamp("lastHealthCheck"),
  errorMessage: text("errorMessage"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Engine = typeof engines.$inferSelect;
export type InsertEngine = typeof engines.$inferInsert;

/**
 * Engine metrics - performance and health metrics for each engine
 */
export const engineMetrics = mysqlTable("engineMetrics", {
  id: int("id").autoincrement().primaryKey(),
  engineId: varchar("engineId", { length: 64 }).notNull(),
  metricType: varchar("metricType", { length: 64 }).notNull(), // e.g., "cpu", "memory", "requests_per_sec"
  value: text("value").notNull(), // Stored as string to handle different types
  unit: varchar("unit", { length: 32 }), // e.g., "percent", "mb", "count"
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export type EngineMetric = typeof engineMetrics.$inferSelect;
export type InsertEngineMetric = typeof engineMetrics.$inferInsert;

/**
 * Tasks - represents work items managed by the Task Orchestration Engine
 */
export const tasks = mysqlTable("tasks", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  taskType: mysqlEnum("taskType", ["email", "calendar", "finance", "research", "automation", "communication"]).notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["draft", "pending_approval", "approved", "in_progress", "completed", "failed", "cancelled"]).default("draft").notNull(),
  priority: mysqlEnum("priority", ["low", "medium", "high", "urgent"]).default("medium").notNull(),
  autonomyLevel: int("autonomyLevel").default(0).notNull(), // Level at which this task can execute
  assignedEngine: varchar("assignedEngine", { length: 64 }), // Which engine is handling this
  assignedAgentId: int("assignedAgentId"), // Which agent is executing this (for distributed tasks)
  agentType: mysqlEnum("agentType", ["fara", "lux-actor", "lux-tasker", "lux-thinker"]), // Which AI agent to use
  privacyLevel: mysqlEnum("privacyLevel", ["sensitive", "normal", "public"]).default("normal"), // Privacy classification
  estimatedCost: decimal("estimatedCost", { precision: 10, scale: 4 }), // Estimated cost in USD
  actualCost: decimal("actualCost", { precision: 10, scale: 4 }), // Actual cost after execution
  scheduledFor: timestamp("scheduledFor"),
  startedAt: timestamp("startedAt"),
  completedAt: timestamp("completedAt"),
  result: json("result"), // Task execution result
  errorMessage: text("errorMessage"),
  metadata: json("metadata"), // Additional task-specific data
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Task = typeof tasks.$inferSelect;
export type InsertTask = typeof tasks.$inferInsert;

/**
 * Policies - user-defined rules and constraints
 */
export const policies = mysqlTable("policies", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  policyType: varchar("policyType", { length: 64 }).notNull(), // e.g., "autonomy", "privacy", "security"
  rules: json("rules").notNull(), // YAML-like policy rules
  isActive: boolean("isActive").default(true).notNull(),
  priority: int("priority").default(0).notNull(), // Higher number = higher priority
  version: int("version").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Policy = typeof policies.$inferSelect;
export type InsertPolicy = typeof policies.$inferInsert;

/**
 * Events - audit trail of all system actions (Household Ledger Engine)
 */
export const events = mysqlTable("events", {
  id: int("id").autoincrement().primaryKey(),
  eventType: varchar("eventType", { length: 64 }).notNull(), // e.g., "task_created", "engine_started"
  direction: mysqlEnum("direction", ["incoming", "outgoing", "system"]).notNull(),
  sourceEngine: varchar("sourceEngine", { length: 64 }),
  targetEngine: varchar("targetEngine", { length: 64 }),
  userId: int("userId"),
  entityType: varchar("entityType", { length: 64 }), // e.g., "task", "policy", "engine"
  entityId: int("entityId"),
  payload: json("payload"), // Event data
  metadata: json("metadata"), // Additional context
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export type Event = typeof events.$inferSelect;
export type InsertEvent = typeof events.$inferInsert;

/**
 * Decisions - records of autonomous decisions made by the Decision Engine
 */
export const decisions = mysqlTable("decisions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  taskId: int("taskId"),
  decisionType: varchar("decisionType", { length: 64 }).notNull(),
  description: text("description").notNull(),
  autonomyLevel: int("autonomyLevel").notNull(), // 1-5
  confidence: int("confidence").notNull(), // 0-100
  reasoning: text("reasoning"), // Explanation of decision
  status: mysqlEnum("status", ["pending_approval", "approved", "rejected", "executing", "executed", "failed"]).default("pending_approval").notNull(),
  context: json("context"), // Input data for decision
  evaluation: json("evaluation"), // DecisionEvaluation result
  feedback: text("feedback"), // User feedback on decision
  executedAt: timestamp("executedAt"),
  approvedAt: timestamp("approvedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Decision = typeof decisions.$inferSelect;
export type InsertDecision = typeof decisions.$inferInsert;

/**
 * Connectors - external service integrations
 */
export const connectors = mysqlTable("connectors", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  householdId: int("householdId"), // Nullable for backward compatibility
  connectorType: varchar("connectorType", { length: 64 }).notNull(), // e.g., "gmail", "calendar", "trello", "custom_service"
  name: varchar("name", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["connected", "disconnected", "error", "pending_auth"]).default("pending_auth").notNull(),
  credentials: text("credentials"), // Encrypted credentials reference
  accessToken: text("accessToken"), // OAuth access token
  refreshToken: text("refreshToken"), // OAuth refresh token
  tokenExpiresAt: timestamp("tokenExpiresAt"), // When access token expires
  lastSync: timestamp("lastSync"),
  syncFrequency: int("syncFrequency").default(3600), // Seconds between syncs
  errorMessage: text("errorMessage"),
  metadata: json("metadata"), // Connector-specific config
  // Privacy & Sync Controls (Phase 24)
  syncSettings: json("syncSettings").$type<{
    dataTypes?: string[]; // ['emails', 'calendar', 'contacts']
    syncFrequency?: 'realtime' | 'hourly' | 'daily' | 'manual';
    dataRetentionDays?: number;
    shareWithHousehold?: boolean;
  }>(), // User privacy preferences
  lastSyncedData: json("lastSyncedData"), // Last sync state for incremental sync
  // ServiceHub fields
  url: text("url"), // Service URL for custom services
  imageUrl: text("imageUrl"), // Custom image for service card
  orderPosition: int("orderPosition").default(0).notNull(), // Drag-drop ordering
  // Alert configuration
  alertsEnabled: boolean("alertsEnabled").default(false).notNull(),
  uptimeThreshold: int("uptimeThreshold").default(99).notNull(), // Alert when uptime drops below this %
  lastAlertTime: timestamp("lastAlertTime"), // Last time alert was sent (prevent spam)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Connector = typeof connectors.$inferSelect;
export type InsertConnector = typeof connectors.$inferInsert;

/**
 * Service Health Checks - track uptime and response times for services
 */
export const serviceHealthChecks = mysqlTable("serviceHealthChecks", {
  id: int("id").autoincrement().primaryKey(),
  connectorId: int("connectorId").notNull(), // References connectors.id
  checkTime: timestamp("checkTime").defaultNow().notNull(),
  status: mysqlEnum("status", ["success", "failure", "timeout"]).notNull(),
  responseTime: int("responseTime"), // Response time in milliseconds
  statusCode: int("statusCode"), // HTTP status code (if applicable)
  errorMessage: text("errorMessage"), // Error details if check failed
});

export type ServiceHealthCheck = typeof serviceHealthChecks.$inferSelect;
export type InsertServiceHealthCheck = typeof serviceHealthChecks.$inferInsert;

/**
 * Connector Analytics - track connector usage and performance
 */
export const connectorAnalytics = mysqlTable("connectorAnalytics", {
  id: int("id").autoincrement().primaryKey(),
  connectorId: int("connectorId").notNull(),
  action: varchar("action", { length: 64 }).notNull(),
  status: mysqlEnum("status", ["success", "failed"]).notNull(),
  duration: int("duration"),
  errorMessage: text("errorMessage"),
  requestData: json("requestData"),
  responseData: json("responseData"),
  metadata: json("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ConnectorAnalytics = typeof connectorAnalytics.$inferSelect;
export type InsertConnectorAnalytics = typeof connectorAnalytics.$inferInsert;

/**
 * HAI Activities - track autonomous actions across all engines
 */
export const haiActivities = mysqlTable("haiActivities", {
  id: int("id").autoincrement().primaryKey(),
  engine: mysqlEnum("engine", ["communication", "decision", "task", "system"]).notNull(),
  action: varchar("action", { length: 64 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  metadata: json("metadata"),
  impact: varchar("impact", { length: 64 }), // e.g., "high", "medium", "low"
  status: mysqlEnum("status", ["completed", "in_progress", "failed"]).notNull(),
  userId: int("userId").notNull().default(0), // 0 = autonomous HAI actions
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type HaiActivity = typeof haiActivities.$inferSelect;
export type InsertHaiActivity = typeof haiActivities.$inferInsert;

/**
 * HAI Agents - distributed worker nodes
 */
export const agents = mysqlTable("agents", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  type: varchar("type", { length: 64 }).notNull(), // "windows", "linux", "macos", "docker"
  apiKey: varchar("apiKey", { length: 255 }).notNull().unique(),
  status: mysqlEnum("status", ["online", "offline", "busy", "idle"]).default("offline").notNull(),
  capabilities: json("capabilities"), // { cpu, gpu, ram, storage, models: [] }
  lastHeartbeat: timestamp("lastHeartbeat"),
  userId: int("userId").notNull(),
  householdId: int("householdId"), // Nullable for backward compatibility
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Agent = typeof agents.$inferSelect;
export type InsertAgent = typeof agents.$inferInsert;

// Note: tasks table already defined above for Task Orchestration Engine
// We'll extend it with assignedAgentId for distributed execution

/**
 * Knowledge Graph Entities - extracted from events and interactions
 */
export const entities = mysqlTable("entities", {
  id: int("id").autoincrement().primaryKey(),
  entityType: varchar("entityType", { length: 64 }).notNull(), // e.g., "person", "organization", "task"
  name: varchar("name", { length: 255 }).notNull(),
  properties: json("properties"), // Entity attributes
  confidence: int("confidence").default(100).notNull(), // 0-100
  sourceEventId: int("sourceEventId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Entity = typeof entities.$inferSelect;
export type InsertEntity = typeof entities.$inferInsert;

/**
 * Knowledge Graph Relationships - connections between entities
 */
export const relationships = mysqlTable("relationships", {
  id: int("id").autoincrement().primaryKey(),
  sourceEntityId: int("sourceEntityId").notNull(),
  targetEntityId: int("targetEntityId").notNull(),
  relationshipType: varchar("relationshipType", { length: 64 }).notNull(), // e.g., "works_for", "manages", "depends_on"
  properties: json("properties"),
  confidence: int("confidence").default(100).notNull(), // 0-100
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Relationship = typeof relationships.$inferSelect;
export type InsertRelationship = typeof relationships.$inferInsert;

/**
 * Self-Model Traits - learned user preferences and patterns
 */
export const userTraits = mysqlTable("userTraits", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  traitType: varchar("traitType", { length: 64 }).notNull(), // e.g., "communication_tone", "escalation_threshold"
  traitValue: text("traitValue").notNull(),
  confidence: int("confidence").default(50).notNull(), // 0-100
  evidence: json("evidence").$type<number[]>(), // Array of event IDs supporting this trait
  lastUpdated: timestamp("lastUpdated").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type UserTrait = typeof userTraits.$inferSelect;
export type InsertUserTrait = typeof userTraits.$inferInsert;

/**
 * Approval History - track all task approval/rejection decisions
 */
export const approvalHistory = mysqlTable("approvalHistory", {
  id: int("id").autoincrement().primaryKey(),
  taskId: int("taskId").notNull(),
  userId: int("userId").notNull(), // Who made the decision
  action: mysqlEnum("action", ["approved", "rejected"]).notNull(),
  reason: text("reason"), // Reason for rejection
  previousStatus: varchar("previousStatus", { length: 64 }).notNull(),
  newStatus: varchar("newStatus", { length: 64 }).notNull(),
  metadata: json("metadata"), // Additional context
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ApprovalHistory = typeof approvalHistory.$inferSelect;
export type InsertApprovalHistory = typeof approvalHistory.$inferInsert;

/**
 * Service Directory - catalog of available services for Frontier Engine
 */
export const services = mysqlTable("services", {
  id: int("id").autoincrement().primaryKey(),
  serviceId: varchar("serviceId", { length: 64 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  category: varchar("category", { length: 64 }), // e.g., "communication", "productivity", "finance"
  apiEndpoint: text("apiEndpoint"),
  authType: varchar("authType", { length: 32 }), // e.g., "oauth", "api_key", "basic"
  capabilities: json("capabilities").$type<string[]>(),
  tosUrl: text("tosUrl"),
  privacyPolicyUrl: text("privacyPolicyUrl"),
  legalFlags: json("legalFlags").$type<string[]>(), // e.g., ["gdpr_compliant", "requires_2fa"]
  freeTier: boolean("freeTier").default(false),
  status: mysqlEnum("status", ["available", "deprecated", "beta"]).default("available").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Service = typeof services.$inferSelect;
export type InsertService = typeof services.$inferInsert;

/**
 * Conversations - chat conversations with HAI
 */
export const conversations = mysqlTable("conversations", {
  id: varchar("id", { length: 64 }).primaryKey(), // Generated conversation ID
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  engineType: mysqlEnum("engineType", ["general", "selfModel", "decision", "task", "knowledge"]).default("general").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = typeof conversations.$inferInsert;

/**
 * Messages - individual messages within conversations
 */
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: varchar("conversationId", { length: 64 }).notNull(),
  role: mysqlEnum("role", ["system", "user", "assistant"]).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;


/**
 * Household Ledger - Immutable event sourcing ledger for audit trail
 */
export const ledgerEvents = mysqlTable("ledgerEvents", {
  id: int("id").autoincrement().primaryKey(),
  sequenceNumber: int("sequenceNumber").notNull().unique(), // Monotonically increasing sequence
  eventType: varchar("eventType", { length: 128 }).notNull(), // e.g., "task.created", "decision.approved"
  eventSource: varchar("eventSource", { length: 128 }).notNull(), // Engine that generated the event
  actor: varchar("actor", { length: 128 }).notNull(), // User or system that triggered the event
  target: varchar("target", { length: 255 }), // Target of the event (optional)
  payload: json("payload").notNull(), // Event data
  metadata: json("metadata").notNull(), // Event metadata
  hash: varchar("hash", { length: 64 }).notNull(), // SHA-256 hash for integrity
  previousHash: varchar("previousHash", { length: 64 }), // Hash of previous event (for chain verification)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type LedgerEvent = typeof ledgerEvents.$inferSelect;
export type InsertLedgerEvent = typeof ledgerEvents.$inferInsert;


/**
 * Capabilities - discovered services and skills
 */
export const capabilities = mysqlTable("capabilities", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  category: varchar("category", { length: 64 }).notNull(),
  provider: varchar("provider", { length: 255 }).notNull(),
  apiEndpoint: text("apiEndpoint"),
  authType: mysqlEnum("authType", ["none", "api_key", "oauth2", "bearer"]).default("none"),
  schema: json("schema"),
  cost: int("cost"), // Cost in credits or cents
  reliability: int("reliability"), // 0-100
  confidence: int("confidence"), // 0-100
  dependencies: json("dependencies").$type<string[]>(),
  examples: json("examples"),
  status: mysqlEnum("status", ["discovered", "testing", "active", "deprecated"]).default("discovered").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Capability = typeof capabilities.$inferSelect;
export type InsertCapability = typeof capabilities.$inferInsert;

/**
 * Playbooks - predefined workflows with templates and versioning
 */
export const playbooks = mysqlTable("playbooks", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  category: varchar("category", { length: 100 }),
  version: varchar("version", { length: 50 }).notNull().default("1.0.0"),
  status: mysqlEnum("status", ["draft", "active", "archived", "deprecated"]).default("draft").notNull(),
  definition: json("definition").notNull(), // Workflow steps, conditions, actions
  metadata: json("metadata"), // Tags, author, created date, etc.
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Playbook = typeof playbooks.$inferSelect;
export type InsertPlaybook = typeof playbooks.$inferInsert;

/**
 * Playbook executions - runtime instances of playbook workflows
 */
export const playbookExecutions = mysqlTable("playbookExecutions", {
  id: int("id").autoincrement().primaryKey(),
  playbookId: int("playbookId").notNull(),
  taskId: int("taskId"), // Link to task if triggered by task
  status: mysqlEnum("status", ["pending", "running", "completed", "failed", "cancelled"]).default("pending").notNull(),
  currentStep: int("currentStep").default(0).notNull(),
  totalSteps: int("totalSteps").notNull(),
  startedAt: timestamp("startedAt"),
  completedAt: timestamp("completedAt"),
  errorMessage: text("errorMessage"),
  executionLog: json("executionLog"), // Step-by-step execution log
  context: json("context"), // Runtime variables and state
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PlaybookExecution = typeof playbookExecutions.$inferSelect;
export type InsertPlaybookExecution = typeof playbookExecutions.$inferInsert;

/**
 * Playbook templates - reusable workflow templates
 */
export const playbookTemplates = mysqlTable("playbookTemplates", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  category: varchar("category", { length: 100 }),
  template: json("template").notNull(), // Template structure with placeholders
  example: json("example"), // Example filled template
  isPublic: int("isPublic").default(0).notNull(), // 0 = false, 1 = true
  usageCount: int("usageCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PlaybookTemplate = typeof playbookTemplates.$inferSelect;
export type InsertPlaybookTemplate = typeof playbookTemplates.$inferInsert;

/**
 * Communication messages - multi-channel communication records
 */
export const communicationMessages = mysqlTable("communicationMessages", {
  id: int("id").autoincrement().primaryKey(),
  channel: mysqlEnum("channel", ["email", "notification", "sms", "chat"]).notNull(),
  recipient: varchar("recipient", { length: 255 }).notNull(), // Email, user ID, phone number, etc.
  subject: varchar("subject", { length: 500 }),
  body: text("body").notNull(),
  templateId: int("templateId"),
  status: mysqlEnum("status", ["draft", "queued", "sent", "delivered", "failed", "bounced"]).default("draft").notNull(),
  sentAt: timestamp("sentAt"),
  deliveredAt: timestamp("deliveredAt"),
  errorMessage: text("errorMessage"),
  metadata: json("metadata"), // Additional channel-specific data
  retryCount: int("retryCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CommunicationMessage = typeof communicationMessages.$inferSelect;
export type InsertCommunicationMessage = typeof communicationMessages.$inferInsert;

/**
 * Message templates - reusable message templates
 */
export const communicationTemplates = mysqlTable("communicationTemplates", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  channel: mysqlEnum("channel", ["email", "notification", "sms", "chat"]).notNull(),
  subject: varchar("subject", { length: 500 }),
  body: text("body").notNull(),
  variables: json("variables").$type<string[]>(), // List of variable names used in template
  category: varchar("category", { length: 100 }),
  isActive: int("isActive").default(1).notNull(),
  usageCount: int("usageCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CommunicationTemplate = typeof communicationTemplates.$inferSelect;
export type InsertCommunicationTemplate = typeof communicationTemplates.$inferInsert;

// ============================================================================
// AUTONOMOUS COMMUNICATION MANAGEMENT SYSTEM
// ============================================================================

/**
 * Unified message storage across all platforms
 * Transforms platform-specific messages into standardized format
 */
export const unifiedMessages = mysqlTable("unified_messages", {
  id: int("id").autoincrement().primaryKey(),
  
  // Platform Information
  platform: mysqlEnum("platform", [
    "email", "sms", "whatsapp", "telegram", "slack", "discord",
    "twitter", "linkedin", "facebook", "messenger", "teams"
  ]).notNull(),
  platformMessageId: varchar("platformMessageId", { length: 255 }).notNull(),
  
  // Participants
  senderId: int("senderId").notNull(), // References communication_contacts table
  conversationId: varchar("conversationId", { length: 255 }).notNull(),
  
  // Content
  textContent: text("textContent"),
  htmlContent: text("htmlContent"),
  mediaAttachments: json("mediaAttachments").$type<Array<{
    type: 'image' | 'video' | 'audio' | 'document';
    url: string;
    filename?: string;
    mimeType?: string;
    size?: number;
  }>>(),
  mentions: json("mentions").$type<number[]>(), // Array of contact IDs
  links: json("links").$type<string[]>(), // Extracted URLs
  
  // Metadata
  timestamp: timestamp("timestamp").notNull(),
  timezone: varchar("timezone", { length: 50 }),
  language: varchar("language", { length: 10 }).default("en"),
  
  // Analysis Results
  urgencyScore: int("urgencyScore").default(50), // 0-100
  sentimentScore: decimal("sentimentScore", { precision: 3, scale: 2 }).default("0.00"), // -1.0 to 1.0
  sentimentLabel: mysqlEnum("sentimentLabel", ["positive", "neutral", "negative"]).default("neutral"),
  topics: json("topics").$type<Array<{
    name: string;
    confidence: number;
  }>>(),
  entities: json("entities").$type<Array<{
    type: string;
    value: string;
    confidence: number;
  }>>(),
  detectedIntent: varchar("detectedIntent", { length: 100 }),
  
  // Priority
  priorityScore: int("priorityScore").default(50), // 0-100 composite score
  relationshipScore: int("relationshipScore").default(50), // 0-100
  topicImportanceScore: int("topicImportanceScore").default(50), // 0-100
  deadlineProximityScore: int("deadlineProximityScore").default(0), // 0-100
  
  // Status
  status: mysqlEnum("status", [
    "unread", "analyzing", "queued", "generating_response",
    "scheduled", "sent", "escalated", "archived"
  ]).default("unread").notNull(),
  
  // Response Tracking
  responseId: int("responseId"), // References this table for sent responses
  responseGeneratedAt: timestamp("responseGeneratedAt"),
  responseScheduledFor: timestamp("responseScheduledFor"),
  responseSentAt: timestamp("responseSentAt"),
  
  // Escalation
  escalated: boolean("escalated").default(false),
  escalationReason: varchar("escalationReason", { length: 255 }),
  escalatedAt: timestamp("escalatedAt"),
  assignedTo: int("assignedTo"), // User ID for human review
  reviewedAt: timestamp("reviewedAt"),
  
  // Household Context
  householdId: int("householdId"),
  
  // Platform-Specific Metadata
  platformMetadata: json("platformMetadata").$type<Record<string, any>>(),
  
  // Timestamps
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UnifiedMessage = typeof unifiedMessages.$inferSelect;
export type InsertUnifiedMessage = typeof unifiedMessages.$inferInsert;

/**
 * Contact information and relationship scoring
 * Tracks all communication participants with relationship metrics
 */
export const communicationContacts = mysqlTable("communication_contacts", {
  id: int("id").autoincrement().primaryKey(),
  
  // Identity
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  phoneNumber: varchar("phoneNumber", { length: 50 }),
  
  // Platform Identifiers
  whatsappId: varchar("whatsappId", { length: 255 }),
  telegramId: varchar("telegramId", { length: 255 }),
  slackId: varchar("slackId", { length: 255 }),
  twitterHandle: varchar("twitterHandle", { length: 100 }),
  linkedinUrl: varchar("linkedinUrl", { length: 255 }),
  facebookId: varchar("facebookId", { length: 255 }),
  
  // Relationship Metrics
  relationshipScore: int("relationshipScore").default(50), // 0-100
  relationshipType: mysqlEnum("relationshipType", [
    "family", "close_friend", "friend", "colleague", 
    "manager", "direct_report", "client", "vendor",
    "acquaintance", "unknown"
  ]).default("unknown"),
  
  // Communication Patterns
  totalMessagesReceived: int("totalMessagesReceived").default(0),
  totalMessagesSent: int("totalMessagesSent").default(0),
  averageResponseTime: int("averageResponseTime").default(0), // Minutes
  lastContactedAt: timestamp("lastContactedAt"),
  communicationFrequency: mysqlEnum("communicationFrequency", [
    "daily", "weekly", "monthly", "yearly", "rare"
  ]).default("rare"),
  
  // Preferences
  preferredPlatform: varchar("preferredPlatform", { length: 50 }),
  preferredTone: mysqlEnum("preferredTone", [
    "formal", "professional", "casual", "intimate"
  ]).default("professional"),
  vipStatus: boolean("vipStatus").default(false),
  
  // Household Context
  householdId: int("householdId"),
  
  // Timestamps
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CommunicationContact = typeof communicationContacts.$inferSelect;
export type InsertCommunicationContact = typeof communicationContacts.$inferInsert;

/**
 * Conversation context and history tracking
 * Maintains rolling window of recent interactions for context-aware responses
 */
export const conversationContexts = mysqlTable("conversation_contexts", {
  id: int("id").autoincrement().primaryKey(),
  
  // Identification
  conversationId: varchar("conversationId", { length: 255 }).notNull().unique(),
  platform: varchar("platform", { length: 50 }).notNull(),
  
  // Participants
  contactId: int("contactId").notNull(),
  
  // Context
  recentMessages: json("recentMessages").$type<Array<{
    messageId: number;
    role: 'user' | 'assistant';
    content: string;
    timestamp: string;
  }>>(), // Last 10 messages
  
  // Topics and Entities
  activeTopics: json("activeTopics").$type<string[]>(),
  mentionedEntities: json("mentionedEntities").$type<Record<string, string[]>>(),
  
  // Open Items
  openQuestions: json("openQuestions").$type<string[]>(),
  pendingCommitments: json("pendingCommitments").$type<Array<{
    commitment: string;
    deadline?: string;
    completed: boolean;
  }>>(),
  
  // Conversation State
  conversationStage: mysqlEnum("conversationStage", [
    "initial", "ongoing", "closing", "closed"
  ]).default("initial"),
  lastInteractionAt: timestamp("lastInteractionAt").notNull(),
  
  // Household Context
  householdId: int("householdId"),
  
  // Timestamps
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ConversationContext = typeof conversationContexts.$inferSelect;
export type InsertConversationContext = typeof conversationContexts.$inferInsert;

/**
 * Reusable response templates for common scenarios
 * Provides structure and consistency for frequent communication patterns
 */
export const responseTemplates = mysqlTable("response_templates", {
  id: int("id").autoincrement().primaryKey(),
  
  // Identification
  name: varchar("name", { length: 255 }).notNull(),
  category: mysqlEnum("category", [
    "meeting_confirmation", "status_update", "thank_you",
    "apology", "information_request", "follow_up",
    "introduction", "decline", "acceptance", "custom"
  ]).notNull(),
  
  // Template Content
  template: text("template").notNull(), // Template with placeholders like {{NAME}}, {{DATE}}, etc.
  variables: json("variables").$type<Array<{
    name: string;
    type: 'string' | 'date' | 'number';
    required: boolean;
    description: string;
  }>>(),
  
  // Tone and Style
  tone: mysqlEnum("tone", ["formal", "professional", "casual", "intimate"]).notNull(),
  platforms: json("platforms").$type<string[]>(), // Applicable platforms
  
  // Usage Tracking
  usageCount: int("usageCount").default(0),
  successRate: decimal("successRate", { precision: 5, scale: 2 }).default("0.00"), // Percentage
  
  // Household Context
  householdId: int("householdId"),
  isGlobal: boolean("isGlobal").default(false), // Available to all households
  
  // Timestamps
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ResponseTemplate = typeof responseTemplates.$inferSelect;
export type InsertResponseTemplate = typeof responseTemplates.$inferInsert;

/**
 * Human review queue for escalated messages
 * Tracks messages requiring human intervention with draft responses
 */
export const communicationEscalations = mysqlTable("communication_escalations", {
  id: int("id").autoincrement().primaryKey(),
  
  // Message Reference
  messageId: int("messageId").notNull().unique(), // References unified_messages
  
  // Escalation Details
  reason: mysqlEnum("reason", [
    "low_confidence", "vip_sender", "sensitive_topic",
    "legal_matter", "financial_commitment", "conflict_detected",
    "novel_situation", "explicit_request", "high_negative_sentiment"
  ]).notNull(),
  confidenceScore: int("confidenceScore"), // 0-100
  
  // Draft Response
  draftResponse: text("draftResponse"),
  draftConfidence: int("draftConfidence"), // 0-100
  
  // Priority
  priority: mysqlEnum("priority", ["critical", "high", "medium", "low"]).notNull(),
  
  // Review Status
  status: mysqlEnum("status", [
    "pending", "in_review", "approved", "edited", "rejected", "deferred"
  ]).default("pending").notNull(),
  
  // Human Actions
  assignedTo: int("assignedTo"), // User ID
  reviewedBy: int("reviewedBy"), // User ID
  reviewedAt: timestamp("reviewedAt"),
  finalResponse: text("finalResponse"),
  reviewNotes: text("reviewNotes"),
  
  // Learning
  humanAction: mysqlEnum("humanAction", [
    "approved_draft", "edited_draft", "wrote_new", "deferred"
  ]),
  editDistance: int("editDistance"), // Levenshtein distance between draft and final
  
  // Household Context
  householdId: int("householdId"),
  
  // Timestamps
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CommunicationEscalation = typeof communicationEscalations.$inferSelect;
export type InsertCommunicationEscalation = typeof communicationEscalations.$inferInsert;

/**
 * Analytics and metrics for communication management
 * Tracks performance, learning progress, and system effectiveness
 */
export const communicationAnalytics = mysqlTable("communication_analytics", {
  id: int("id").autoincrement().primaryKey(),
  
  // Time Period
  date: timestamp("date").notNull(),
  period: mysqlEnum("period", ["hourly", "daily", "weekly", "monthly"]).notNull(),
  
  // Message Volume
  totalMessages: int("totalMessages").default(0),
  messagesPerPlatform: json("messagesPerPlatform").$type<Record<string, number>>(),
  
  // Response Metrics
  autonomousResponses: int("autonomousResponses").default(0),
  escalatedMessages: int("escalatedMessages").default(0),
  averageResponseTime: int("averageResponseTime").default(0), // Minutes
  averageConfidenceScore: decimal("averageConfidenceScore", { precision: 5, scale: 2 }),
  
  // Priority Distribution
  urgentMessages: int("urgentMessages").default(0),
  highPriorityMessages: int("highPriorityMessages").default(0),
  mediumPriorityMessages: int("mediumPriorityMessages").default(0),
  lowPriorityMessages: int("lowPriorityMessages").default(0),
  
  // Quality Metrics
  successfulResponses: int("successfulResponses").default(0), // No negative follow-up
  responseAccuracy: decimal("responseAccuracy", { precision: 5, scale: 2 }),
  toneAppropriatenessScore: decimal("toneAppropriatenessScore", { precision: 5, scale: 2 }),
  
  // Learning Metrics
  draftApprovalRate: decimal("draftApprovalRate", { precision: 5, scale: 2 }),
  averageEditDistance: int("averageEditDistance"),
  newPatternsLearned: int("newPatternsLearned").default(0),
  
  // Household Context
  householdId: int("householdId"),
  
  // Timestamps
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CommunicationAnalytic = typeof communicationAnalytics.$inferSelect;
export type InsertCommunicationAnalytic = typeof communicationAnalytics.$inferInsert;

/**
 * Learned tone profiles for each contact
 * Captures appropriate communication style based on relationship and history
 */
export const toneProfiles = mysqlTable("tone_profiles", {
  id: int("id").autoincrement().primaryKey(),
  
  // Contact Reference
  contactId: int("contactId").notNull().unique(),
  
  // Tone Dimensions
  formalityLevel: int("formalityLevel").default(50), // 0=very casual, 100=very formal
  emotionalWarmth: int("emotionalWarmth").default(50), // 0=distant, 100=intimate
  linguisticComplexity: int("linguisticComplexity").default(50), // 0=simple, 100=sophisticated
  
  // Style Characteristics
  useContractions: boolean("useContractions").default(true),
  useEmoji: boolean("useEmoji").default(false),
  useExclamations: boolean("useExclamations").default(false),
  greetingStyle: varchar("greetingStyle", { length: 100 }).default("Hi"),
  closingStyle: varchar("closingStyle", { length: 100 }).default("Thanks"),
  
  // Learned Patterns
  characteristicPhrases: json("characteristicPhrases").$type<string[]>(),
  avoidedPhrases: json("avoidedPhrases").$type<string[]>(),
  typicalResponseLength: int("typicalResponseLength").default(100), // Words
  
  // Confidence
  profileConfidence: int("profileConfidence").default(50), // 0-100
  sampleSize: int("sampleSize").default(0), // Number of messages analyzed
  
  // Household Context
  householdId: int("householdId"),
  
  // Timestamps
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ToneProfile = typeof toneProfiles.$inferSelect;
export type InsertToneProfile = typeof toneProfiles.$inferInsert;

// ============================================================================
// Level 5 AI Schema Extensions
// ============================================================================
export * from './schema-level5';
