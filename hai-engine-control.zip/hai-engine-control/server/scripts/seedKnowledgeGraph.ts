import { getDb } from "../db";
import { entities, relationships } from "../../drizzle/schema";

/**
 * Seed Knowledge Graph with test data
 */
async function seedKnowledgeGraph() {
  const db = await getDb();
  if (!db) {
    console.error('Database not available');
    return;
  }

  console.log('[Seed] Seeding Knowledge Graph...');

  // Create entities
  const entityData = [
    { entityType: 'person', name: 'Alice Johnson', properties: { role: 'User', age: 32 }, confidence: 95 },
    { entityType: 'person', name: 'Bob Smith', properties: { role: 'User', age: 28 }, confidence: 90 },
    { entityType: 'person', name: 'Carol Davis', properties: { role: 'Admin', age: 35 }, confidence: 92 },
    { entityType: 'organization', name: 'TechCorp', properties: { industry: 'Technology', size: 'Large' }, confidence: 98 },
    { entityType: 'organization', name: 'DataSystems Inc', properties: { industry: 'Software', size: 'Medium' }, confidence: 95 },
    { entityType: 'place', name: 'San Francisco', properties: { country: 'USA', type: 'City' }, confidence: 100 },
    { entityType: 'place', name: 'New York', properties: { country: 'USA', type: 'City' }, confidence: 100 },
    { entityType: 'concept', name: 'Machine Learning', properties: { field: 'AI', complexity: 'High' }, confidence: 88 },
    { entityType: 'concept', name: 'Data Science', properties: { field: 'Analytics', complexity: 'Medium' }, confidence: 85 },
    { entityType: 'event', name: 'Tech Conference 2024', properties: { date: '2024-06-15', type: 'Conference' }, confidence: 90 },
    { entityType: 'person', name: 'David Lee', properties: { role: 'Developer', age: 30 }, confidence: 88 },
    { entityType: 'person', name: 'Emma Wilson', properties: { role: 'Designer', age: 27 }, confidence: 87 },
    { entityType: 'organization', name: 'AI Research Lab', properties: { industry: 'Research', size: 'Small' }, confidence: 93 },
    { entityType: 'concept', name: 'Neural Networks', properties: { field: 'AI', complexity: 'High' }, confidence: 90 },
    { entityType: 'concept', name: 'Cloud Computing', properties: { field: 'Infrastructure', complexity: 'Medium' }, confidence: 86 },
  ];

  const createdEntities: number[] = [];
  
  for (const entity of entityData) {
    await db.insert(entities).values(entity);
    const result = await db.select().from(entities);
    const found = result.find(e => e.name === entity.name);
    if (found) {
      createdEntities.push(found.id);
    }
  }

  console.log(`[Seed] Created ${createdEntities.length} entities`);

  // Create relationships
  if (createdEntities.length >= 15) {
    const relationshipData = [
      { sourceEntityId: createdEntities[0], targetEntityId: createdEntities[3], relationshipType: 'works_at', confidence: 95 },
      { sourceEntityId: createdEntities[1], targetEntityId: createdEntities[3], relationshipType: 'works_at', confidence: 90 },
      { sourceEntityId: createdEntities[2], targetEntityId: createdEntities[4], relationshipType: 'works_at', confidence: 92 },
      { sourceEntityId: createdEntities[0], targetEntityId: createdEntities[1], relationshipType: 'knows', confidence: 88 },
      { sourceEntityId: createdEntities[1], targetEntityId: createdEntities[2], relationshipType: 'knows', confidence: 85 },
      { sourceEntityId: createdEntities[3], targetEntityId: createdEntities[5], relationshipType: 'located_in', confidence: 100 },
      { sourceEntityId: createdEntities[4], targetEntityId: createdEntities[6], relationshipType: 'located_in', confidence: 100 },
      { sourceEntityId: createdEntities[0], targetEntityId: createdEntities[7], relationshipType: 'interested_in', confidence: 80 },
      { sourceEntityId: createdEntities[1], targetEntityId: createdEntities[8], relationshipType: 'interested_in', confidence: 82 },
      { sourceEntityId: createdEntities[0], targetEntityId: createdEntities[9], relationshipType: 'attended', confidence: 90 },
      { sourceEntityId: createdEntities[1], targetEntityId: createdEntities[9], relationshipType: 'attended', confidence: 88 },
      { sourceEntityId: createdEntities[2], targetEntityId: createdEntities[9], relationshipType: 'attended', confidence: 92 },
      { sourceEntityId: createdEntities[10], targetEntityId: createdEntities[3], relationshipType: 'works_at', confidence: 87 },
      { sourceEntityId: createdEntities[11], targetEntityId: createdEntities[4], relationshipType: 'works_at', confidence: 89 },
      { sourceEntityId: createdEntities[10], targetEntityId: createdEntities[13], relationshipType: 'interested_in', confidence: 85 },
      { sourceEntityId: createdEntities[11], targetEntityId: createdEntities[14], relationshipType: 'interested_in', confidence: 83 },
      { sourceEntityId: createdEntities[12], targetEntityId: createdEntities[5], relationshipType: 'located_in', confidence: 95 },
      { sourceEntityId: createdEntities[7], targetEntityId: createdEntities[13], relationshipType: 'related_to', confidence: 90 },
      { sourceEntityId: createdEntities[8], targetEntityId: createdEntities[7], relationshipType: 'related_to', confidence: 88 },
      { sourceEntityId: createdEntities[0], targetEntityId: createdEntities[10], relationshipType: 'knows', confidence: 75 },
    ];

    for (const rel of relationshipData) {
      await db.insert(relationships).values({
        ...rel,
        properties: {},
      });
    }

    console.log(`[Seed] Created ${relationshipData.length} relationships`);
  }

  console.log('[Seed] Knowledge Graph seeding complete!');
}

// Run if executed directly
seedKnowledgeGraph()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error('[Seed] Error:', error);
    process.exit(1);
  });

export { seedKnowledgeGraph };
