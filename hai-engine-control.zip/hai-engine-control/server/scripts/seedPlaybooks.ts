import { getDb } from "../db";
import { playbooks, playbookTemplates } from "../../drizzle/schema";

/**
 * Seed Playbook Engine with example playbooks and templates
 */
async function seedPlaybooks() {
  const db = await getDb();
  if (!db) {
    console.error('Database not available');
    return;
  }

  console.log('[Seed] Seeding Playbook Engine...');

  // Example playbooks
  const playbookData = [
    {
      name: "Morning Routine Automation",
      description: "Automated morning routine workflow",
      category: "automation",
      version: "1.0.0",
      status: "active" as const,
      definition: {
        steps: [
          {
            id: "step1",
            name: "Check Weather",
            type: "action",
            action: "check_weather",
            params: { location: "current" },
            onSuccess: "step2",
          },
          {
            id: "step2",
            name: "Check Calendar",
            type: "action",
            action: "check_calendar",
            params: { timeframe: "today" },
            onSuccess: "step3",
          },
          {
            id: "step3",
            name: "Send Morning Summary",
            type: "action",
            action: "send_notification",
            params: { type: "morning_summary" },
          },
        ],
        variables: {},
        triggers: ["time:08:00"],
      },
      metadata: { author: "system", tags: ["morning", "automation", "routine"] },
    },
    {
      name: "Email Triage Workflow",
      description: "Automatically categorize and prioritize incoming emails",
      category: "communication",
      version: "1.0.0",
      status: "active" as const,
      definition: {
        steps: [
          {
            id: "step1",
            name: "Fetch New Emails",
            type: "action",
            action: "fetch_emails",
            params: { folder: "inbox", unread: true },
            onSuccess: "step2",
          },
          {
            id: "step2",
            name: "Analyze Email Content",
            type: "action",
            action: "analyze_email",
            params: { use_llm: true },
            onSuccess: "step3",
          },
          {
            id: "step3",
            name: "Categorize Email",
            type: "condition",
            condition: "$priority === 'high'",
            onSuccess: "step4",
            onFailure: "step5",
          },
          {
            id: "step4",
            name: "Flag as Important",
            type: "action",
            action: "flag_email",
            params: { importance: "high" },
          },
          {
            id: "step5",
            name: "Move to Category",
            type: "action",
            action: "move_email",
            params: { folder: "$category" },
          },
        ],
        variables: { priority: "normal", category: "general" },
        triggers: ["email:received"],
      },
      metadata: { author: "system", tags: ["email", "triage", "automation"] },
    },
    {
      name: "Task Completion Workflow",
      description: "Execute task with approval and logging",
      category: "task_management",
      version: "1.0.0",
      status: "active" as const,
      definition: {
        steps: [
          {
            id: "step1",
            name: "Check Autonomy Level",
            type: "condition",
            condition: "$autonomyLevel >= 2",
            onSuccess: "step3",
            onFailure: "step2",
          },
          {
            id: "step2",
            name: "Request Approval",
            type: "action",
            action: "request_approval",
            params: { reason: "autonomy_level_insufficient" },
            onSuccess: "step3",
          },
          {
            id: "step3",
            name: "Execute Task",
            type: "action",
            action: "execute_task",
            params: {},
            onSuccess: "step4",
            onFailure: "step5",
          },
          {
            id: "step4",
            name: "Log Success",
            type: "action",
            action: "log_event",
            params: { type: "task_completed", status: "success" },
          },
          {
            id: "step5",
            name: "Log Failure",
            type: "action",
            action: "log_event",
            params: { type: "task_failed", status: "error" },
          },
        ],
        variables: { autonomyLevel: 1 },
        triggers: ["task:ready"],
      },
      metadata: { author: "system", tags: ["task", "approval", "execution"] },
    },
    {
      name: "Data Backup Routine",
      description: "Automated data backup and verification",
      category: "maintenance",
      version: "1.0.0",
      status: "draft" as const,
      definition: {
        steps: [
          {
            id: "step1",
            name: "Create Backup",
            type: "action",
            action: "create_backup",
            params: { type: "full" },
            onSuccess: "step2",
            onFailure: "step4",
          },
          {
            id: "step2",
            name: "Verify Backup",
            type: "action",
            action: "verify_backup",
            params: {},
            onSuccess: "step3",
            onFailure: "step4",
          },
          {
            id: "step3",
            name: "Notify Success",
            type: "action",
            action: "send_notification",
            params: { type: "backup_success" },
          },
          {
            id: "step4",
            name: "Notify Failure",
            type: "action",
            action: "send_notification",
            params: { type: "backup_failure", priority: "high" },
          },
        ],
        variables: {},
        triggers: ["schedule:daily:02:00"],
      },
      metadata: { author: "system", tags: ["backup", "maintenance", "data"] },
    },
    {
      name: "Meeting Preparation",
      description: "Prepare materials and agenda for upcoming meetings",
      category: "productivity",
      version: "1.0.0",
      status: "active" as const,
      definition: {
        steps: [
          {
            id: "step1",
            name: "Fetch Meeting Details",
            type: "action",
            action: "fetch_meeting",
            params: { timeframe: "next_2_hours" },
            onSuccess: "step2",
          },
          {
            id: "step2",
            name: "Gather Related Documents",
            type: "action",
            action: "search_documents",
            params: { keywords: "$meeting_topics" },
            onSuccess: "step3",
          },
          {
            id: "step3",
            name: "Generate Agenda",
            type: "action",
            action: "generate_agenda",
            params: { use_llm: true },
            onSuccess: "step4",
          },
          {
            id: "step4",
            name: "Send Preparation Summary",
            type: "action",
            action: "send_notification",
            params: { type: "meeting_prep", include_documents: true },
          },
        ],
        variables: { meeting_topics: [] },
        triggers: ["meeting:upcoming"],
      },
      metadata: { author: "system", tags: ["meeting", "preparation", "productivity"] },
    },
  ];

  for (const playbook of playbookData) {
    await db.insert(playbooks).values(playbook as any);
  }

  console.log(`[Seed] Created ${playbookData.length} playbooks`);

  // Example templates
  const templateData = [
    {
      name: "Simple Sequential Workflow",
      description: "Template for basic sequential task execution",
      category: "basic",
      template: {
        steps: [
          {
            id: "step1",
            name: "{{step1_name}}",
            type: "action",
            action: "{{step1_action}}",
            params: {},
            onSuccess: "step2",
          },
          {
            id: "step2",
            name: "{{step2_name}}",
            type: "action",
            action: "{{step2_action}}",
            params: {},
          },
        ],
        variables: {},
      },
      example: {
        step1_name: "Initialize Process",
        step1_action: "initialize",
        step2_name: "Complete Process",
        step2_action: "complete",
      },
      isPublic: 1,
      usageCount: 0,
    },
    {
      name: "Conditional Branch Workflow",
      description: "Template with conditional logic",
      category: "advanced",
      template: {
        steps: [
          {
            id: "step1",
            name: "{{check_name}}",
            type: "condition",
            condition: "{{condition}}",
            onSuccess: "step2",
            onFailure: "step3",
          },
          {
            id: "step2",
            name: "{{success_action_name}}",
            type: "action",
            action: "{{success_action}}",
            params: {},
          },
          {
            id: "step3",
            name: "{{failure_action_name}}",
            type: "action",
            action: "{{failure_action}}",
            params: {},
          },
        ],
        variables: {},
      },
      example: {
        check_name: "Check Status",
        condition: "$status === 'ready'",
        success_action_name: "Process Item",
        success_action: "process",
        failure_action_name: "Skip Item",
        failure_action: "skip",
      },
      isPublic: 1,
      usageCount: 0,
    },
  ];

  for (const template of templateData) {
    await db.insert(playbookTemplates).values(template as any);
  }

  console.log(`[Seed] Created ${templateData.length} templates`);
  console.log('[Seed] Playbook Engine seeding complete!');
}

// Run if executed directly
seedPlaybooks()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error('[Seed] Error:', error);
    process.exit(1);
  });

export { seedPlaybooks };
