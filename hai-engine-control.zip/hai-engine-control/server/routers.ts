import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { connectorsRouter } from "./api/routers/connectors";
import { ledgerRouter } from './api/routers/ledger';
import { frontierRouter } from './api/routers/frontier';
import { enforceAutonomyRules, validateAutonomyLevel, requiresApproval, getAutonomyDescription } from "./services/autonomyLadder";
import { notifyTaskApproved, notifyTaskRejected, notifyTaskPendingApproval } from "./services/notificationService";
import { z } from "zod";
import * as db from "./db";
import { chatRouter } from "./api/routers/chat";
import { smeRouter } from "./api/routers/sme";
import { decisionRouter } from "./api/routers/decision";
import { taskOrchestrationRouter } from "./api/routers/taskOrchestration";
import { knowledgeGraphRouter } from "./api/routers/knowledgeGraph";
import { playbookRouter } from "./api/routers/playbook";
import { communicationRouter } from "./api/routers/communication";
import { analyticsRouter } from "./api/routers/analytics";
// servicehub merged into connectors
import { authenticationRouter } from "./api/routers/authentication";
import { tagsRouter } from "./api/routers/tags";
import { agentsRouter } from "./api/routers/agents";
import { householdsRouter } from "./api/routers/households";
import { activitiesRouter } from "./api/routers/activities";
import { engineTestRouter } from "./api/routers/engineTest";
import { approvalQueueRouter } from "./api/routers/approvalQueue";
import { orchestratorRouter } from "./api/routers/orchestrator";
import { luxRouter } from "./api/routers/lux";
import { autonomousRouter } from "./api/routers/autonomous";
import { whatsappRouter } from "./api/routers/whatsapp";
import { autonomousCommunicationRouter } from "./api/routers/autonomousCommunication";
import { level5Router } from "./api/routers/level5";
import { autonomousServicesRouter } from "./api/routers/autonomousServices";
import { healthRouter } from "./api/routers/health";
import { pillar1Router } from "./api/routers/pillar1";
import { pillar2Router } from "./api/routers/pillar2";
import { pillar3Router } from "./api/routers/pillar3";
import { pillar4Router } from "./api/routers/pillar4";
import { pillar5Router } from "./api/routers/pillar5";
import { interactionRouter } from "./api/routers/interaction";
import { emergencyRouter } from "./api/routers/emergency";
import { ethicsRouter } from "./api/routers/ethics";
import { memoryRouter } from "./api/routers/memory";
import { inputRouter } from "./api/routers/input";
import { oauthRouter } from "./api/routers/oauth";
import { notificationsRouter } from "./api/routers/notifications";
import { knowledgeBaseRouter } from "./api/routers/knowledgeBase";
import { screenStreamRouter } from "./api/routers/screenStream";
import { thinkingRouter } from "./api/routers/thinking";
import { discoveryRouter } from "./api/routers/discovery";
import { activityIntelligenceRouter } from "./api/routers/activityIntelligence";
import { crossEngineOrchestrationRouter } from "./api/routers/crossEngineOrchestration";
import { temporalIntelligenceRouter } from "./api/routers/temporalIntelligence";
import { advancedContextAwarenessRouter } from "./api/routers/advancedContextAwareness";
import { metaLearningRouter } from "./api/routers/metaLearning";
import { distributedIntelligenceRouter } from "./api/routers/distributedIntelligence";
import { causalReasoningRouter } from "./api/routers/causalReasoning";
import { uncertaintyQuantificationRouter } from "./api/routers/uncertaintyQuantification";
import { explainabilityRouter } from "./api/routers/explainability";
import { continualLearningRouter } from "./api/routers/continualLearning";
import { aiMonitorRouter } from "./api/routers/aiMonitor";

export const appRouter = router({
  system: systemRouter,
  agents: agentsRouter,
  households: householdsRouter,
  activities: activitiesRouter,
  engineTest: engineTestRouter,
  approvalQueue: approvalQueueRouter,
  orchestrator: orchestratorRouter,
  lux: luxRouter,
  autonomous: autonomousRouter,
  whatsapp: whatsappRouter,
  autonomousCommunication: autonomousCommunicationRouter,
  level5: level5Router,
  autonomousServices: autonomousServicesRouter,
  health: healthRouter,
  pillar1: pillar1Router,
  pillar2: pillar2Router,
  pillar3: pillar3Router,
  pillar4: pillar4Router,
  pillar5: pillar5Router,
  interaction: interactionRouter,
  emergency: emergencyRouter,
  ethics: ethicsRouter,
  memory: memoryRouter,
  input: inputRouter,
  oauth: oauthRouter,
  notifications: notificationsRouter,
  chat: chatRouter,
  sme: smeRouter,
  decision: decisionRouter,
  taskOrchestration: taskOrchestrationRouter,
  connectors: connectorsRouter,
  ledger: ledgerRouter,
  frontier: frontierRouter,
  knowledgeGraph: knowledgeGraphRouter,
  playbook: playbookRouter,
  communication: communicationRouter,
  analytics: analyticsRouter,
  // servicehub: merged into connectors router
  authentication: authenticationRouter,
  tags: tagsRouter,
  knowledgeBase: knowledgeBaseRouter,
  screenStream: screenStreamRouter,
  thinking: thinkingRouter,
  discovery: discoveryRouter,
  activityIntelligence: activityIntelligenceRouter,
  crossEngineOrchestration: crossEngineOrchestrationRouter,
  temporalIntelligence: temporalIntelligenceRouter,
  advancedContextAwareness: advancedContextAwarenessRouter,
  metaLearning: metaLearningRouter,
  distributedIntelligence: distributedIntelligenceRouter,
  causalReasoning: causalReasoningRouter,
  uncertaintyQuantification: uncertaintyQuantificationRouter,
  explainability: explainabilityRouter,
  continualLearning: continualLearningRouter,
  aiMonitor: aiMonitorRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  engines: router({
    list: protectedProcedure.query(async () => {
      return await db.getAllEngines();
    }),
    get: protectedProcedure
      .input(z.object({ engineId: z.string() }))
      .query(async ({ input }) => {
        return await db.getEngineById(input.engineId);
      }),
    updateStatus: protectedProcedure
      .input(z.object({
        engineId: z.string(),
        status: z.enum(["running", "stopped", "error", "initializing"]),
      }))
      .mutation(async ({ input }) => {
        await db.updateEngineStatus(input.engineId, input.status);
        return { success: true };
      }),
    metrics: protectedProcedure
      .input(z.object({
        engineId: z.string(),
        limit: z.number().optional().default(50),
      }))
      .query(async ({ input }) => {
        // Generate mock metrics for now - in real implementation, this would query actual metrics
        const metrics = [];
        const now = Date.now();
        for (let i = 0; i < input.limit; i++) {
          metrics.push({
            timestamp: new Date(now - (input.limit - i) * 60000), // 1 minute intervals
            value: Math.random() * 100, // Random value between 0-100
          });
        }
        return metrics;
      }),
  }),

  tasks: router({
    list: protectedProcedure
      .input(z.object({
        status: z.enum(["draft", "pending_approval", "approved", "in_progress", "completed", "failed", "cancelled"]).optional(),
      }))
      .query(async ({ input }) => {
        return await db.getAllTasks();
      }),
    create: protectedProcedure
      .input(z.object({
        title: z.string(),
        description: z.string().optional(),
        taskType: z.enum(["email", "calendar", "finance", "research", "automation", "communication"]),
        priority: z.enum(["low", "medium", "high", "urgent"]),
        autonomyLevel: z.number().min(0).max(5),
        assignedEngine: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        // Enforce autonomy ladder rules
        const rules = enforceAutonomyRules({
          autonomyLevel: input.autonomyLevel,
          taskType: input.taskType,
          status: "draft",
        });

        if (!rules.valid) {
          throw new Error(rules.reason || "Invalid autonomy level");
        }

        // Determine initial status based on autonomy level
        const initialStatus = rules.suggestedStatus || "draft";

        const task = await db.createTask({
          ...input,
          userId: ctx.user.id,
          status: initialStatus as any,
        });

        // Log event to HLE
        await db.logEvent({
          eventType: "task_created",
          direction: "system",
          sourceEngine: "Task Orchestration Engine",
          userId: ctx.user.id,
          entityType: "task",
          entityId: task.id,
          payload: {
            title: task.title,
            taskType: task.taskType,
            autonomyLevel: task.autonomyLevel,
            status: task.status,
          },
          metadata: {
            autonomyDescription: getAutonomyDescription(task.autonomyLevel),
            requiresApproval: requiresApproval(task.autonomyLevel),
          },
        });

        return task;
      }),
    approve: protectedProcedure
      .input(z.object({ taskId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const task = await db.getTaskById(input.taskId);
        if (!task) throw new Error("Task not found");
        
        const previousStatus = task.status;
        await db.updateTaskStatus(input.taskId, "approved");
        
        // Record approval history
        await db.createApprovalHistory({
          taskId: input.taskId,
          userId: ctx.user.id,
          action: "approved",
          previousStatus: previousStatus,
          newStatus: "approved",
          metadata: {
            taskTitle: task.title,
            autonomyLevel: task.autonomyLevel,
          },
        });
        
        // Send notification
        await notifyTaskApproved(input.taskId, task.userId, ctx.user.id);
        
        return { success: true };
      }),
    reject: protectedProcedure
      .input(z.object({ taskId: z.number(), reason: z.string().optional() }))
      .mutation(async ({ input, ctx }) => {
        const task = await db.getTaskById(input.taskId);
        if (!task) throw new Error("Task not found");
        
        const previousStatus = task.status;
        await db.updateTaskStatus(input.taskId, "cancelled");
        
        // Record rejection history
        await db.createApprovalHistory({
          taskId: input.taskId,
          userId: ctx.user.id,
          action: "rejected",
          reason: input.reason,
          previousStatus: previousStatus,
          newStatus: "cancelled",
          metadata: {
            taskTitle: task.title,
            autonomyLevel: task.autonomyLevel,
          },
        });
        
        // Send notification
        await notifyTaskRejected(input.taskId, task.userId, ctx.user.id, input.reason);
        
        return { success: true };
      }),
  }),

  policies: router({
    list: protectedProcedure.query(async () => {
      return await db.getAllPolicies();
    }),
    create: protectedProcedure
      .input(z.object({
        name: z.string(),
        description: z.string().optional(),
        policyType: z.enum(["privacy", "security", "autonomy", "compliance", "operational"]),
        rules: z.any(),
        priority: z.number(),
      }))
      .mutation(async ({ input, ctx }) => {
        const policy = await db.createPolicy({
          ...input,
          userId: ctx.user.id,
          isActive: true,
        });
        return policy;
      }),
    toggle: protectedProcedure
      .input(z.object({ policyId: z.number() }))
      .mutation(async ({ input }) => {
        await db.togglePolicy(input.policyId);
        return { success: true };
      }),
  }),

  events: router({
    list: protectedProcedure
      .input(z.object({
        eventType: z.string().optional(),
        direction: z.enum(["incoming", "outgoing", "system"]).optional(),
        limit: z.number().optional().default(50),
      }))
      .query(async ({ input }) => {
        return await db.getEvents(input);
      }),
  }),

  services: router({
    list: protectedProcedure.query(async () => {
      return await db.getAllServices();
    }),
  }),

  needs: router({
    getUserNeeds: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserNeedAssessments(ctx.user.id);
    }),
    runAssessment: protectedProcedure.mutation(async ({ ctx }) => {
      const { runFullAssessment } = await import("./services/needAssessmentEngine");
      return await runFullAssessment(ctx.user.id);
    }),
  }),
});

export type AppRouter = typeof appRouter;
