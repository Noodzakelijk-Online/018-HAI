import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  approvalHistory,
  InsertApprovalHistory,
  engines,
  InsertEngine,
  Engine,
  engineMetrics,
  InsertEngineMetric,
  tasks,
  InsertTask,
  Task,
  policies,
  InsertPolicy,
  Policy,
  events,
  InsertEvent,
  Event,
  decisions,
  InsertDecision,
  connectors,
  InsertConnector,
  entities,
  InsertEntity,
  relationships,
  InsertRelationship,
  userTraits,
  InsertUserTrait,
  services,
  InsertService,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function updateUserDashboardVisit(userId: number): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update dashboard visit: database not available");
    return;
  }

  await db
    .update(users)
    .set({ lastDashboardVisit: new Date() })
    .where(eq(users.id, userId));
}

// ===== Engine Management =====

export async function getAllEngines() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(engines).orderBy(desc(engines.priority));
}

export async function getEngineById(engineId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(engines).where(eq(engines.engineId, engineId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function upsertEngine(engine: InsertEngine) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(engines).values(engine).onDuplicateKeyUpdate({
    set: {
      name: engine.name,
      description: engine.description,
      status: engine.status,
      autonomyLevel: engine.autonomyLevel,
      priority: engine.priority,
      dependencies: engine.dependencies,
      lastHealthCheck: engine.lastHealthCheck,
      errorMessage: engine.errorMessage,
      updatedAt: new Date(),
    },
  });
}

export async function updateEngineStatus(engineId: string, status: Engine["status"], errorMessage?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(engines)
    .set({ 
      status, 
      errorMessage: errorMessage || null,
      lastHealthCheck: new Date(),
      updatedAt: new Date()
    })
    .where(eq(engines.engineId, engineId));
}

// ===== Engine Metrics =====

export async function insertEngineMetric(metric: InsertEngineMetric) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(engineMetrics).values(metric);
}

export async function getEngineMetrics(engineId: string, limit: number = 100) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select()
    .from(engineMetrics)
    .where(eq(engineMetrics.engineId, engineId))
    .orderBy(desc(engineMetrics.timestamp))
    .limit(limit);
}

// ===== Task Management =====

export async function getAllTasks(userId?: number) {
  const db = await getDb();
  if (!db) return [];
  
  if (userId) {
    return await db.select().from(tasks).where(eq(tasks.userId, userId)).orderBy(desc(tasks.createdAt));
  }
  return await db.select().from(tasks).orderBy(desc(tasks.createdAt));
}

export async function getTaskById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(tasks).where(eq(tasks.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createTask(task: InsertTask) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(tasks).values(task);
  const taskId = result[0].insertId;
  
  // Fetch and return the created task
  const createdTask = await db.select().from(tasks).where(eq(tasks.id, taskId)).limit(1);
  return createdTask[0];
}

export async function updateTask(id: number, updates: Partial<Task>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(tasks)
    .set({ ...updates, updatedAt: new Date() })
    .where(eq(tasks.id, id));
}

// ===== Policy Management =====

export async function getAllPolicies(userId?: number) {
  const db = await getDb();
  if (!db) return [];
  
  if (userId) {
    return await db.select().from(policies).where(eq(policies.userId, userId)).orderBy(desc(policies.priority));
  }
  return await db.select().from(policies).orderBy(desc(policies.priority));
}

export async function getPolicyById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(policies).where(eq(policies.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createPolicy(policy: InsertPolicy) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(policies).values(policy);
  return result[0].insertId;
}

export async function updatePolicy(id: number, updates: Partial<Policy>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(policies)
    .set({ ...updates, updatedAt: new Date() })
    .where(eq(policies.id, id));
}

// ===== Event Logging (HLE) =====

export async function logEvent(event: InsertEvent) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(events).values(event);
}

export async function getEvents(filters?: {
  eventType?: string;
  direction?: Event["direction"];
  sourceEngine?: string;
  userId?: number;
  limit?: number;
}) {
  const db = await getDb();
  if (!db) return [];
  
  let query = db.select().from(events);
  
  const conditions = [];
  if (filters?.eventType) conditions.push(eq(events.eventType, filters.eventType));
  if (filters?.direction) conditions.push(eq(events.direction, filters.direction));
  if (filters?.sourceEngine) conditions.push(eq(events.sourceEngine, filters.sourceEngine));
  if (filters?.userId) conditions.push(eq(events.userId, filters.userId));
  
  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }
  
  return await query.orderBy(desc(events.timestamp)).limit(filters?.limit || 100);
}

// ===== Decision Management =====

export async function createDecision(decision: InsertDecision) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(decisions).values(decision);
  return result[0].insertId;
}

export async function getDecisionsByTask(taskId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(decisions).where(eq(decisions.taskId, taskId)).orderBy(desc(decisions.createdAt));
}

// ===== Connector Management =====

export async function getAllConnectors(userId?: number) {
  const db = await getDb();
  if (!db) return [];
  
  if (userId) {
    return await db.select().from(connectors).where(eq(connectors.userId, userId)).orderBy(desc(connectors.createdAt));
  }
  return await db.select().from(connectors).orderBy(desc(connectors.createdAt));
}

export async function createConnector(connector: InsertConnector) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(connectors).values(connector);
  return result[0].insertId;
}

export async function getConnectorsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db
    .select()
    .from(connectors)
    .where(eq(connectors.userId, userId))
    .orderBy(connectors.orderPosition);
}

export async function getConnectorsByHouseholdId(householdId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db
    .select()
    .from(connectors)
    .where(eq(connectors.householdId, householdId))
    .orderBy(connectors.orderPosition);
}

export async function getConnectorById(id: number) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db
    .select()
    .from(connectors)
    .where(eq(connectors.id, id))
    .limit(1);
  
  return result[0] || null;
}

export async function updateConnector(id: number, updates: Partial<InsertConnector>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db
    .update(connectors)
    .set(updates)
    .where(eq(connectors.id, id));
}

export async function deleteConnector(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db
    .delete(connectors)
    .where(eq(connectors.id, id));
}

export async function updateConnectorOrder(userId: number, orderedIds: number[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Update order positions based on array index
  for (let i = 0; i < orderedIds.length; i++) {
    await db
      .update(connectors)
      .set({ orderPosition: i })
      .where(eq(connectors.id, orderedIds[i]));
  }
}

// ===== Knowledge Graph =====

export async function createEntity(entity: InsertEntity) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(entities).values(entity);
  return result[0].insertId;
}

export async function createRelationship(relationship: InsertRelationship) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(relationships).values(relationship);
  return result[0].insertId;
}

export async function getEntities(limit: number = 100) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(entities).orderBy(desc(entities.createdAt)).limit(limit);
}

// ===== Self-Model Engine =====

export async function getUserTraits(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(userTraits).where(eq(userTraits.userId, userId)).orderBy(desc(userTraits.confidence));
}

export async function upsertUserTrait(trait: InsertUserTrait) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Check if trait exists
  const existing = await db.select()
    .from(userTraits)
    .where(and(
      eq(userTraits.userId, trait.userId),
      eq(userTraits.traitType, trait.traitType)
    ))
    .limit(1);
  
  if (existing.length > 0) {
    await db.update(userTraits)
      .set({
        traitValue: trait.traitValue,
        confidence: trait.confidence,
        evidence: trait.evidence,
        lastUpdated: new Date(),
      })
      .where(eq(userTraits.id, existing[0].id));
  } else {
    await db.insert(userTraits).values(trait);
  }
}

// ===== Service Directory (Frontier Engine) =====

export async function getAllServices() {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(services).where(eq(services.status, "available")).orderBy(services.name);
}

export async function getServiceById(serviceId: string) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(services).where(eq(services.serviceId, serviceId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createService(service: InsertService) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(services).values(service);
}


// ===== Additional Task Functions =====

export async function updateTaskStatus(taskId: number, status: Task["status"]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(tasks)
    .set({ status, updatedAt: new Date() })
    .where(eq(tasks.id, taskId));
}

// ===== Additional Policy Functions =====

export async function togglePolicy(policyId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const existing = await db.select().from(policies).where(eq(policies.id, policyId)).limit(1);
  if (existing.length === 0) throw new Error("Policy not found");
  
  await db.update(policies)
    .set({ isActive: !existing[0].isActive, updatedAt: new Date() })
    .where(eq(policies.id, policyId));
}



// Approval History functions
export async function createApprovalHistory(history: InsertApprovalHistory) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(approvalHistory).values(history);
}

export async function getApprovalHistoryByTask(taskId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.select().from(approvalHistory).where(eq(approvalHistory.taskId, taskId));
  return result;
}

export async function getApprovalHistoryByUser(userId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.select().from(approvalHistory)
    .where(eq(approvalHistory.userId, userId))
    .limit(limit);
  return result;
}

// Maslow's Hierarchy functions
export async function getNeedCategories() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await (db as any).execute("SELECT * FROM needCategories ORDER BY level ASC");
  return result[0] as any[];
}

export async function getNeedCategoryById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await (db as any).execute("SELECT * FROM needCategories WHERE id = ?", [id]);
  return (result[0] as any[])[0];
}

export async function getNeedIndicatorsByCategory(categoryId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await (db as any).execute("SELECT * FROM needIndicators WHERE categoryId = ?", [categoryId]);
  return result[0] as any[];
}

export async function getNeedIndicatorMeasurements(userId: number, indicatorId: number, days: number = 30) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await (db as any).execute(
    "SELECT * FROM needIndicatorMeasurements WHERE userId = ? AND indicatorId = ? AND measuredAt >= DATE_SUB(NOW(), INTERVAL ? DAY) ORDER BY measuredAt DESC",
    [userId, indicatorId, days]
  );
  return result[0] as any[];
}

export async function createNeedIndicatorMeasurement(measurement: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await (db as any).execute(
    "INSERT INTO needIndicatorMeasurements (userId, indicatorId, value, source, sourceId, metadata) VALUES (?, ?, ?, ?, ?, ?)",
    [measurement.userId, measurement.indicatorId, measurement.value, measurement.source, measurement.sourceId, JSON.stringify(measurement.metadata || {})]
  );
}

export async function getPreviousNeedAssessment(userId: number, categoryId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await (db as any).execute(
    "SELECT * FROM userNeedAssessments WHERE userId = ? AND categoryId = ? ORDER BY lastAssessedAt DESC LIMIT 1",
    [userId, categoryId]
  );
  return (result[0] as any[])[0];
}

export async function upsertUserNeedAssessment(assessment: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await (db as any).execute(
    `INSERT INTO userNeedAssessments (userId, categoryId, fulfillmentLevel, trend, lastAssessedAt, assessmentData, insights, recommendations)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE
       fulfillmentLevel = VALUES(fulfillmentLevel),
       trend = VALUES(trend),
       lastAssessedAt = VALUES(lastAssessedAt),
       assessmentData = VALUES(assessmentData),
       insights = VALUES(insights),
       recommendations = VALUES(recommendations),
       updatedAt = CURRENT_TIMESTAMP`,
    [
      assessment.userId,
      assessment.categoryId,
      assessment.fulfillmentLevel,
      assessment.trend,
      assessment.lastAssessedAt,
      JSON.stringify(assessment.assessmentData || {}),
      assessment.insights,
      assessment.recommendations,
    ]
  );
}

export async function getUserNeedAssessments(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await (db as any).execute(
    `SELECT una.*, nc.name as categoryName, nc.level, nc.color, nc.icon
     FROM userNeedAssessments una
     JOIN needCategories nc ON una.categoryId = nc.id
     WHERE una.userId = ?
     ORDER BY nc.level ASC`,
    [userId]
  );
  return result[0] as any[];
}

export async function createNeedBasedAdjustment(adjustment: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await (db as any).execute(
    "INSERT INTO needBasedAdjustments (taskId, categoryId, originalPriority, adjustedPriority, reason, fulfillmentGap) VALUES (?, ?, ?, ?, ?, ?)",
    [adjustment.taskId, adjustment.categoryId, adjustment.originalPriority, adjustment.adjustedPriority, adjustment.reason, adjustment.fulfillmentGap]
  );
}
