/**
 * Production Configuration
 * Environment-specific settings for production deployment
 */

export interface ProductionConfig {
  // Rate limiting
  rateLimit: {
    windowMs: number;
    maxRequests: number;
    skipFailedRequests: boolean;
    keyPrefix: string;
  };
  
  // Cache settings
  cache: {
    defaultTTL: number;
    maxSize: number;
    checkPeriod: number;
  };
  
  // Database
  database: {
    connectionPoolSize: number;
    idleTimeoutMs: number;
    connectionTimeoutMs: number;
    queryTimeoutMs: number;
  };
  
  // Security
  security: {
    sessionMaxAge: number;
    csrfEnabled: boolean;
    corsOrigins: string[];
    rateLimitBypass: string[];
  };
  
  // Logging
  logging: {
    level: 'debug' | 'info' | 'warn' | 'error';
    includeTimestamp: boolean;
    prettyPrint: boolean;
    maxLogSize: number;
  };
  
  // Background jobs
  jobs: {
    concurrency: number;
    retryAttempts: number;
    retryDelayMs: number;
    cleanupIntervalMs: number;
  };
  
  // Backup
  backup: {
    enabled: boolean;
    intervalMs: number;
    retentionDays: number;
    compressionEnabled: boolean;
  };
  
  // Monitoring
  monitoring: {
    healthCheckIntervalMs: number;
    metricsRetentionMs: number;
    alertThresholds: {
      errorRatePercent: number;
      responseTimeMs: number;
      memoryUsagePercent: number;
    };
  };
}

const isProduction = process.env.NODE_ENV === 'production';

export const productionConfig: ProductionConfig = {
  // Rate limiting - stricter in production
  rateLimit: {
    windowMs: isProduction ? 60000 : 60000, // 1 minute
    maxRequests: isProduction ? 100 : 1000, // 100 req/min in prod, 1000 in dev
    skipFailedRequests: false,
    keyPrefix: 'rl:',
  },
  
  // Cache settings
  cache: {
    defaultTTL: isProduction ? 300 : 60, // 5 min in prod, 1 min in dev
    maxSize: isProduction ? 10000 : 1000,
    checkPeriod: 60, // Check for expired keys every 60 seconds
  },
  
  // Database
  database: {
    connectionPoolSize: isProduction ? 20 : 5,
    idleTimeoutMs: isProduction ? 30000 : 60000,
    connectionTimeoutMs: 10000,
    queryTimeoutMs: isProduction ? 30000 : 60000,
  },
  
  // Security
  security: {
    sessionMaxAge: isProduction ? 86400000 : 604800000, // 1 day prod, 7 days dev
    csrfEnabled: isProduction,
    corsOrigins: isProduction 
      ? ['https://hai-engine-control.manus.space'] 
      : ['http://localhost:3000', 'http://localhost:5173'],
    rateLimitBypass: [], // IPs that bypass rate limiting (e.g., monitoring services)
  },
  
  // Logging
  logging: {
    level: isProduction ? 'info' : 'debug',
    includeTimestamp: true,
    prettyPrint: !isProduction,
    maxLogSize: isProduction ? 10000 : 1000,
  },
  
  // Background jobs
  jobs: {
    concurrency: isProduction ? 5 : 2,
    retryAttempts: isProduction ? 3 : 1,
    retryDelayMs: 5000,
    cleanupIntervalMs: isProduction ? 3600000 : 60000, // 1 hour prod, 1 min dev
  },
  
  // Backup
  backup: {
    enabled: isProduction,
    intervalMs: 86400000, // Daily backups
    retentionDays: 30,
    compressionEnabled: true,
  },
  
  // Monitoring
  monitoring: {
    healthCheckIntervalMs: isProduction ? 30000 : 60000, // 30s prod, 1 min dev
    metricsRetentionMs: isProduction ? 86400000 : 3600000, // 24h prod, 1h dev
    alertThresholds: {
      errorRatePercent: 5, // Alert if error rate exceeds 5%
      responseTimeMs: 1000, // Alert if avg response time > 1s
      memoryUsagePercent: 85, // Alert if memory usage > 85%
    },
  },
};

/**
 * Get configuration value with environment override
 */
export function getConfig<K extends keyof ProductionConfig>(
  key: K
): ProductionConfig[K] {
  return productionConfig[key];
}

/**
 * Get rate limit configuration
 */
export function getRateLimitConfig() {
  return productionConfig.rateLimit;
}

/**
 * Get cache configuration
 */
export function getCacheConfig() {
  return productionConfig.cache;
}

/**
 * Get database configuration
 */
export function getDatabaseConfig() {
  return productionConfig.database;
}

/**
 * Get security configuration
 */
export function getSecurityConfig() {
  return productionConfig.security;
}

/**
 * Get logging configuration
 */
export function getLoggingConfig() {
  return productionConfig.logging;
}

/**
 * Get job configuration
 */
export function getJobConfig() {
  return productionConfig.jobs;
}

/**
 * Get backup configuration
 */
export function getBackupConfig() {
  return productionConfig.backup;
}

/**
 * Get monitoring configuration
 */
export function getMonitoringConfig() {
  return productionConfig.monitoring;
}

export default productionConfig;
