import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';

// Mock dependencies
vi.mock('../services/logger', () => ({
  createLogger: vi.fn().mockReturnValue({
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
    debug: vi.fn(),
  }),
}));

vi.mock('../config/production', () => ({
  getMonitoringConfig: vi.fn().mockReturnValue({
    healthCheckIntervalMs: 30000,
    metricsRetentionMs: 86400000,
    alertThresholds: {
      errorRatePercent: 5,
      responseTimeMs: 1000,
      memoryUsagePercent: 85,
    },
  }),
  getBackupConfig: vi.fn().mockReturnValue({
    enabled: false,
    intervalMs: 86400000,
    retentionDays: 30,
    compressionEnabled: true,
  }),
}));

vi.mock('../storage', () => ({
  storagePut: vi.fn().mockResolvedValue({ key: 'test-key', url: 'https://test.com/backup.json' }),
  storageGet: vi.fn().mockResolvedValue({ key: 'test-key', url: 'https://test.com/backup.json' }),
}));

vi.mock('../db', () => ({
  getDb: vi.fn().mockResolvedValue(null),
}));

vi.mock('../_core/notification', () => ({
  notifyOwner: vi.fn().mockResolvedValue(true),
}));

describe('MetricsStreamingService', () => {
  let metricsStreaming: any;

  beforeEach(async () => {
    vi.clearAllMocks();
    // Reset module cache to get fresh instance
    vi.resetModules();
    const module = await import('../services/metricsStreaming');
    metricsStreaming = module.metricsStreaming;
    metricsStreaming.reset();
  });

  afterEach(() => {
    metricsStreaming.stop();
  });

  it('should collect metrics', () => {
    const snapshot = metricsStreaming.getSnapshot();
    
    expect(snapshot).toHaveProperty('current');
    expect(snapshot).toHaveProperty('history');
    expect(snapshot.current).toHaveProperty('timestamp');
    expect(snapshot.current).toHaveProperty('cpu');
    expect(snapshot.current).toHaveProperty('memory');
    expect(snapshot.current).toHaveProperty('requests');
    expect(snapshot.current).toHaveProperty('connections');
    expect(snapshot.current).toHaveProperty('uptime');
  });

  it('should record requests', () => {
    metricsStreaming.recordRequest(100, false);
    metricsStreaming.recordRequest(200, true);
    
    const snapshot = metricsStreaming.getSnapshot();
    expect(snapshot.current.requests.total).toBeGreaterThanOrEqual(0);
  });

  it('should track connections', () => {
    metricsStreaming.connectionOpened();
    metricsStreaming.connectionOpened();
    
    let snapshot = metricsStreaming.getSnapshot();
    expect(snapshot.current.connections.active).toBe(2);
    
    metricsStreaming.connectionClosed();
    snapshot = metricsStreaming.getSnapshot();
    expect(snapshot.current.connections.active).toBe(1);
  });

  it('should get metrics history', () => {
    const history = metricsStreaming.getHistory(10);
    expect(Array.isArray(history)).toBe(true);
  });

  it('should get aggregated stats', () => {
    const stats = metricsStreaming.getAggregatedStats(3600000);
    
    expect(stats).toHaveProperty('avgResponseTime');
    expect(stats).toHaveProperty('totalRequests');
    expect(stats).toHaveProperty('errorRate');
    expect(stats).toHaveProperty('peakMemory');
    expect(stats).toHaveProperty('avgCpu');
  });
});

describe('AlertNotificationService', () => {
  let alertNotifications: any;

  beforeEach(async () => {
    vi.clearAllMocks();
    vi.resetModules();
    const module = await import('../services/alertNotifications');
    alertNotifications = module.alertNotifications;
  });

  afterEach(() => {
    alertNotifications.stopMonitoring();
  });

  it('should have default alert rules', () => {
    const rules = alertNotifications.getRules();
    
    expect(Array.isArray(rules)).toBe(true);
    expect(rules.length).toBeGreaterThan(0);
    
    const ruleIds = rules.map((r: any) => r.id);
    expect(ruleIds).toContain('high-error-rate');
    expect(ruleIds).toContain('slow-response-time');
    expect(ruleIds).toContain('high-memory-usage');
  });

  it('should add custom rules', () => {
    const initialCount = alertNotifications.getRules().length;
    
    alertNotifications.addRule({
      id: 'test-rule',
      name: 'Test Rule',
      description: 'Test description',
      condition: () => false,
      severity: 'info',
      channels: ['in_app'],
      cooldownMs: 60000,
      enabled: true,
    });
    
    const rules = alertNotifications.getRules();
    expect(rules.length).toBe(initialCount + 1);
  });

  it('should remove rules', () => {
    alertNotifications.addRule({
      id: 'temp-rule',
      name: 'Temp Rule',
      description: 'Temporary',
      condition: () => false,
      severity: 'info',
      channels: ['in_app'],
      cooldownMs: 60000,
      enabled: true,
    });
    
    const removed = alertNotifications.removeRule('temp-rule');
    expect(removed).toBe(true);
    
    const rules = alertNotifications.getRules();
    expect(rules.find((r: any) => r.id === 'temp-rule')).toBeUndefined();
  });

  it('should enable/disable rules', () => {
    alertNotifications.setRuleEnabled('high-error-rate', false);
    
    const rules = alertNotifications.getRules();
    const rule = rules.find((r: any) => r.id === 'high-error-rate');
    expect(rule.enabled).toBe(false);
    
    alertNotifications.setRuleEnabled('high-error-rate', true);
  });

  it('should get alerts with filters', () => {
    const alerts = alertNotifications.getAlerts({ severity: 'critical', limit: 10 });
    expect(Array.isArray(alerts)).toBe(true);
  });

  it('should get alert statistics', () => {
    const stats = alertNotifications.getStats();
    
    expect(stats).toHaveProperty('total');
    expect(stats).toHaveProperty('bySeverity');
    expect(stats).toHaveProperty('unacknowledged');
    expect(stats).toHaveProperty('last24h');
    expect(stats.bySeverity).toHaveProperty('info');
    expect(stats.bySeverity).toHaveProperty('warning');
    expect(stats.bySeverity).toHaveProperty('critical');
  });
});

describe('DatabaseBackupService', () => {
  let databaseBackup: any;

  beforeEach(async () => {
    vi.clearAllMocks();
    vi.resetModules();
    const module = await import('../services/databaseBackup');
    databaseBackup = module.databaseBackup;
  });

  afterEach(() => {
    databaseBackup.stopScheduledBackups();
  });

  it('should get backup schedule', () => {
    const schedule = databaseBackup.getSchedule();
    
    expect(schedule).toHaveProperty('enabled');
    expect(schedule).toHaveProperty('intervalMs');
    expect(schedule).toHaveProperty('retentionDays');
  });

  it('should update backup schedule', () => {
    databaseBackup.updateSchedule({ retentionDays: 60 });
    
    const schedule = databaseBackup.getSchedule();
    expect(schedule.retentionDays).toBe(60);
  });

  it('should get backup history', () => {
    const backups = databaseBackup.getBackups({ limit: 10 });
    expect(Array.isArray(backups)).toBe(true);
  });

  it('should get backup statistics', () => {
    const stats = databaseBackup.getStats();
    
    expect(stats).toHaveProperty('totalBackups');
    expect(stats).toHaveProperty('completedBackups');
    expect(stats).toHaveProperty('failedBackups');
    expect(stats).toHaveProperty('totalSize');
  });

  it('should filter backups by status', () => {
    const completedBackups = databaseBackup.getBackups({ status: 'completed' });
    const failedBackups = databaseBackup.getBackups({ status: 'failed' });
    
    expect(Array.isArray(completedBackups)).toBe(true);
    expect(Array.isArray(failedBackups)).toBe(true);
  });
});

describe('Production Configuration', () => {
  it('should have valid monitoring thresholds', async () => {
    const { getMonitoringConfig } = await import('../config/production');
    const config = getMonitoringConfig();
    
    expect(config.alertThresholds.errorRatePercent).toBeGreaterThan(0);
    expect(config.alertThresholds.responseTimeMs).toBeGreaterThan(0);
    expect(config.alertThresholds.memoryUsagePercent).toBeGreaterThan(0);
    expect(config.alertThresholds.memoryUsagePercent).toBeLessThanOrEqual(100);
  });

  it('should have valid backup configuration', async () => {
    const { getBackupConfig } = await import('../config/production');
    const config = getBackupConfig();
    
    expect(config).toHaveProperty('enabled');
    expect(config).toHaveProperty('intervalMs');
    expect(config).toHaveProperty('retentionDays');
    expect(config).toHaveProperty('compressionEnabled');
    expect(config.intervalMs).toBeGreaterThan(0);
    expect(config.retentionDays).toBeGreaterThan(0);
  });
});
