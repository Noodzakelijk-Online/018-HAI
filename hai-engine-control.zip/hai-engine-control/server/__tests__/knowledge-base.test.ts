/**
 * Knowledge Base Service Tests
 * 
 * Tests the comprehensive knowledge base system including:
 * - Multi-tier memory architecture
 * - Chat interface for knowledge entry
 * - Automatic ingestion
 * - Knowledge graph visualization
 */

import { describe, it, expect, vi } from 'vitest';

// Mock the database
vi.mock('../db', () => ({
  getDb: vi.fn().mockResolvedValue({
    select: vi.fn().mockReturnThis(),
    from: vi.fn().mockReturnThis(),
    where: vi.fn().mockReturnThis(),
    orderBy: vi.fn().mockReturnThis(),
    limit: vi.fn().mockResolvedValue([]),
    insert: vi.fn().mockReturnThis(),
    values: vi.fn().mockResolvedValue({ insertId: 1 }),
    execute: vi.fn().mockResolvedValue([[]]),
  }),
}));

// Mock the LLM
vi.mock('../_core/llm', () => ({
  invokeLLM: vi.fn().mockResolvedValue({
    choices: [{
      message: {
        content: JSON.stringify({
          message: "I understood that you prefer coffee in the morning.",
          extractedKnowledge: [{
            type: 'preference',
            content: 'User prefers coffee in the morning',
            confidence: 0.9,
            entities: ['coffee', 'morning']
          }]
        }),
      },
    }],
  }),
}));

describe('Knowledge Base Service', () => {
  describe('Memory Types', () => {
    it('should define all knowledge types', () => {
      const knowledgeTypes = [
        'fact', 'preference', 'routine', 'relationship', 
        'event', 'emotion', 'skill', 'context', 'insight'
      ];
      
      expect(knowledgeTypes).toHaveLength(9);
      expect(knowledgeTypes).toContain('fact');
      expect(knowledgeTypes).toContain('preference');
      expect(knowledgeTypes).toContain('routine');
    });
  });

  describe('Chat Interface', () => {
    it('should accept chat message input', () => {
      const chatInput = {
        message: "I prefer my coffee black in the morning",
        householdId: 1,
        conversationHistory: [],
      };
      
      expect(chatInput.message).toBeDefined();
      expect(chatInput.householdId).toBeGreaterThan(0);
    });

    it('should return extracted knowledge from chat', () => {
      const expectedResponse = {
        message: "I understood that you prefer coffee in the morning.",
        extractedKnowledge: [{
          type: 'preference',
          content: 'User prefers coffee in the morning',
          confidence: 0.9,
          entities: ['coffee', 'morning']
        }]
      };
      
      expect(expectedResponse.message).toBeDefined();
      expect(expectedResponse.extractedKnowledge).toHaveLength(1);
      expect(expectedResponse.extractedKnowledge[0].type).toBe('preference');
      expect(expectedResponse.extractedKnowledge[0].confidence).toBeGreaterThan(0);
    });
  });

  describe('Knowledge Entry Structure', () => {
    it('should have required fields for knowledge entries', () => {
      const requiredFields = [
        'householdId',
        'type',
        'content',
        'source',
      ];
      
      requiredFields.forEach(field => {
        expect(typeof field).toBe('string');
        expect(field.length).toBeGreaterThan(0);
      });
    });

    it('should support optional metadata fields', () => {
      const optionalFields = [
        'context',
        'summary',
        'sourceId',
        'importance',
        'tags',
        'relatedMembers',
        'metadata',
      ];
      
      expect(optionalFields.length).toBeGreaterThan(0);
    });
  });

  describe('Ingestion Sources', () => {
    it('should support all ingestion source types', () => {
      const sourceTypes = [
        'activities',
        'decisions',
        'conversations',
        'emails',
        'calendar',
        'whatsapp',
        'documents',
      ];
      
      expect(sourceTypes).toHaveLength(7);
      expect(sourceTypes).toContain('activities');
      expect(sourceTypes).toContain('emails');
      expect(sourceTypes).toContain('calendar');
    });
  });

  describe('Ingestion Configuration', () => {
    it('should accept valid ingestion config', () => {
      const config = {
        householdId: 1,
        sources: {
          activities: true,
          decisions: true,
          conversations: true,
          emails: false,
          calendar: false,
          whatsapp: false,
          documents: false,
        },
        autoIngest: true,
        intervalMinutes: 30,
      };
      
      expect(config.householdId).toBeGreaterThan(0);
      expect(config.intervalMinutes).toBeGreaterThanOrEqual(5);
      expect(config.intervalMinutes).toBeLessThanOrEqual(1440);
    });
  });

  describe('Knowledge Graph', () => {
    it('should define entity types', () => {
      const entityTypes = [
        'person', 'organization', 'place', 'event', 'concept',
        'object', 'document', 'service', 'task', 'goal',
        'skill', 'preference', 'topic'
      ];
      
      expect(entityTypes.length).toBeGreaterThan(0);
      expect(entityTypes).toContain('person');
      expect(entityTypes).toContain('concept');
    });

    it('should define relationship types', () => {
      const relationshipTypes = [
        'related_to', 'part_of', 'causes', 'depends_on',
        'similar_to', 'opposite_of', 'precedes', 'follows'
      ];
      
      expect(relationshipTypes.length).toBeGreaterThan(0);
      expect(relationshipTypes).toContain('related_to');
    });

    it('should have valid graph node structure', () => {
      const node = {
        id: "1",
        label: "Test Entity",
        type: "concept",
        size: 20,
      };
      
      expect(node.id).toBeDefined();
      expect(node.label).toBeDefined();
      expect(node.type).toBeDefined();
      expect(node.size).toBeGreaterThan(0);
    });

    it('should have valid graph link structure', () => {
      const link = {
        source: "1",
        target: "2",
        type: "related_to",
        strength: 0.8,
      };
      
      expect(link.source).toBeDefined();
      expect(link.target).toBeDefined();
      expect(link.strength).toBeGreaterThanOrEqual(0);
      expect(link.strength).toBeLessThanOrEqual(1);
    });
  });

  describe('Confidence and Importance Scores', () => {
    it('should have valid range for confidence scores', () => {
      const minConfidence = 0;
      const maxConfidence = 1;
      
      expect(minConfidence).toBeGreaterThanOrEqual(0);
      expect(maxConfidence).toBeLessThanOrEqual(1);
    });

    it('should have valid range for importance scores', () => {
      const minImportance = 0;
      const maxImportance = 1;
      
      expect(minImportance).toBeGreaterThanOrEqual(0);
      expect(maxImportance).toBeLessThanOrEqual(1);
    });
  });

  describe('Search Functionality', () => {
    it('should accept search parameters', () => {
      const searchParams = {
        query: 'coffee preferences',
        householdId: 1,
        types: ['preference', 'fact'],
        limit: 20,
      };
      
      expect(searchParams.query).toBeDefined();
      expect(searchParams.limit).toBeGreaterThan(0);
      expect(searchParams.limit).toBeLessThanOrEqual(100);
    });
  });

  describe('Statistics Endpoint', () => {
    it('should return expected statistics structure', () => {
      const expectedStats = {
        totalEntries: 0,
        recentlyAdded: 0,
        byType: {},
        bySource: {},
      };
      
      expect(expectedStats).toHaveProperty('totalEntries');
      expect(expectedStats).toHaveProperty('byType');
      expect(expectedStats).toHaveProperty('bySource');
    });
  });
});

describe('Knowledge Chat API', () => {
  describe('Chat Endpoint', () => {
    it('should accept message input', () => {
      const input = {
        message: "I love hiking on weekends",
        householdId: 1,
      };
      
      expect(input.message.length).toBeGreaterThan(0);
      expect(input.householdId).toBeGreaterThan(0);
    });

    it('should support conversation history', () => {
      const input = {
        message: "Also, I prefer morning hikes",
        householdId: 1,
        conversationHistory: [
          { role: 'user' as const, content: 'I love hiking on weekends' },
          { role: 'assistant' as const, content: 'Great! I noted that you enjoy hiking on weekends.' },
        ],
      };
      
      expect(input.conversationHistory).toHaveLength(2);
      expect(input.conversationHistory[0].role).toBe('user');
    });
  });
});

describe('Knowledge Ingestion API', () => {
  describe('Enable Auto Ingestion', () => {
    it('should accept valid configuration', () => {
      const config = {
        householdId: 1,
        sources: {
          activities: true,
          decisions: true,
          conversations: true,
          emails: true,
          calendar: true,
          whatsapp: false,
          documents: false,
        },
        autoIngest: true,
        intervalMinutes: 60,
      };
      
      expect(config.intervalMinutes).toBeGreaterThanOrEqual(5);
      expect(Object.values(config.sources).some(v => v)).toBe(true);
    });
  });

  describe('Trigger Ingestion', () => {
    it('should accept valid source types', () => {
      const validSources = ['all', 'activities', 'decisions', 'conversations', 'emails', 'calendar', 'whatsapp', 'documents'];
      
      validSources.forEach(source => {
        expect(typeof source).toBe('string');
      });
    });
  });
});
