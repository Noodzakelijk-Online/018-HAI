/**
 * Tests for OAuth Connectors and WebSocket Notification Service
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';

// Mock the WebSocket notification service
const mockNotificationService = {
  notify: vi.fn().mockReturnValue('notif_123'),
  sendToUser: vi.fn(),
  broadcast: vi.fn(),
  getPendingNotifications: vi.fn().mockReturnValue([]),
  getNotificationHistory: vi.fn().mockReturnValue([]),
  markAsRead: vi.fn().mockReturnValue(true),
  markAllAsRead: vi.fn().mockReturnValue(5),
  isUserOnline: vi.fn().mockReturnValue(true),
  getOnlineUsers: vi.fn().mockReturnValue([1, 2, 3]),
  getConnectedClientCount: vi.fn().mockReturnValue(10),
  getConnectedUserCount: vi.fn().mockReturnValue(5),
};

// Mock Gmail OAuth connector
const mockGmailConnector = {
  getAuthUrl: vi.fn().mockReturnValue('https://accounts.google.com/oauth/authorize?...'),
  exchangeCode: vi.fn().mockResolvedValue({
    accessToken: 'access_token',
    refreshToken: 'refresh_token',
    expiresAt: new Date(Date.now() + 3600000),
    scope: 'https://www.googleapis.com/auth/gmail.readonly',
  }),
  setTokens: vi.fn().mockResolvedValue(undefined),
  refreshTokenIfNeeded: vi.fn().mockResolvedValue(false),
  getProfile: vi.fn().mockResolvedValue({
    email: 'test@example.com',
    messagesTotal: 1000,
    threadsTotal: 500,
  }),
  listMessages: vi.fn().mockResolvedValue({
    messages: [
      { id: '1', from: 'sender@example.com', subject: 'Test', date: new Date(), isUnread: true },
    ],
    nextPageToken: undefined,
  }),
  isConnected: vi.fn().mockReturnValue(true),
};

// Mock Calendar OAuth connector
const mockCalendarConnector = {
  getAuthUrl: vi.fn().mockReturnValue('https://accounts.google.com/oauth/authorize?...'),
  exchangeCode: vi.fn().mockResolvedValue({
    accessToken: 'access_token',
    refreshToken: 'refresh_token',
    expiresAt: new Date(Date.now() + 3600000),
    scope: 'https://www.googleapis.com/auth/calendar',
  }),
  setTokens: vi.fn().mockResolvedValue(undefined),
  refreshTokenIfNeeded: vi.fn().mockResolvedValue(false),
  listCalendars: vi.fn().mockResolvedValue([
    { id: 'primary', summary: 'Primary Calendar', primary: true, timeZone: 'America/New_York' },
  ]),
  listEvents: vi.fn().mockResolvedValue({
    events: [
      { id: '1', summary: 'Meeting', start: new Date(), end: new Date(), isAllDay: false },
    ],
    nextPageToken: undefined,
  }),
  isConnected: vi.fn().mockReturnValue(true),
};

describe('OAuth Connectors', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('Gmail OAuth Connector', () => {
    it('should generate auth URL', () => {
      const authUrl = mockGmailConnector.getAuthUrl();
      expect(authUrl).toContain('accounts.google.com');
    });

    it('should exchange code for tokens', async () => {
      const tokens = await mockGmailConnector.exchangeCode('auth_code');
      expect(tokens).toHaveProperty('accessToken');
      expect(tokens).toHaveProperty('refreshToken');
      expect(tokens).toHaveProperty('expiresAt');
    });

    it('should get user profile', async () => {
      const profile = await mockGmailConnector.getProfile();
      expect(profile).toHaveProperty('email');
      expect(profile).toHaveProperty('messagesTotal');
    });

    it('should list messages', async () => {
      const result = await mockGmailConnector.listMessages();
      expect(result.messages).toBeInstanceOf(Array);
      expect(result.messages.length).toBeGreaterThan(0);
    });

    it('should check connection status', () => {
      expect(mockGmailConnector.isConnected()).toBe(true);
    });
  });

  describe('Plaid Financial Connector', () => {
    const mockPlaidConnector = {
      initialize: vi.fn(),
      isConfigured: vi.fn().mockReturnValue(true),
      createLinkToken: vi.fn().mockResolvedValue({
        linkToken: 'link-sandbox-xxx',
        expiration: new Date(Date.now() + 3600000),
        requestId: 'req_123',
      }),
      exchangePublicToken: vi.fn().mockResolvedValue({
        accessToken: 'access-sandbox-xxx',
        itemId: 'item_123',
      }),
      getAccounts: vi.fn().mockResolvedValue([
        { accountId: 'acc_1', name: 'Checking', type: 'depository', subtype: 'checking', mask: '1234', balances: { available: 1000, current: 1000 } },
        { accountId: 'acc_2', name: 'Savings', type: 'depository', subtype: 'savings', mask: '5678', balances: { available: 5000, current: 5000 } },
      ]),
      getBalances: vi.fn().mockResolvedValue([
        { accountId: 'acc_1', name: 'Checking', balances: { available: 1000, current: 1000 } },
      ]),
      getTransactions: vi.fn().mockResolvedValue({
        transactions: [
          { transactionId: 'tx_1', accountId: 'acc_1', amount: -50, date: '2024-01-15', name: 'Coffee Shop', category: ['Food and Drink', 'Coffee'] },
        ],
        totalTransactions: 1,
      }),
      searchInstitutions: vi.fn().mockResolvedValue([
        { institutionId: 'ins_1', name: 'Chase', logo: null, primaryColor: '#0060A9' },
      ]),
    };

    it('should initialize with credentials', () => {
      mockPlaidConnector.initialize({ clientId: 'client_id', secret: 'secret', environment: 'sandbox' });
      expect(mockPlaidConnector.initialize).toHaveBeenCalled();
    });

    it('should check configuration status', () => {
      expect(mockPlaidConnector.isConfigured()).toBe(true);
    });

    it('should create link token', async () => {
      const result = await mockPlaidConnector.createLinkToken({
        userId: '1',
        clientName: 'HAI Engine',
        products: ['transactions'],
      });
      expect(result).toHaveProperty('linkToken');
      expect(result).toHaveProperty('expiration');
    });

    it('should exchange public token', async () => {
      const result = await mockPlaidConnector.exchangePublicToken('public-sandbox-xxx');
      expect(result).toHaveProperty('accessToken');
      expect(result).toHaveProperty('itemId');
    });

    it('should get accounts', async () => {
      const accounts = await mockPlaidConnector.getAccounts('access_token');
      expect(accounts).toBeInstanceOf(Array);
      expect(accounts.length).toBe(2);
      expect(accounts[0]).toHaveProperty('accountId');
      expect(accounts[0]).toHaveProperty('name');
      expect(accounts[0]).toHaveProperty('type');
    });

    it('should get balances', async () => {
      const balances = await mockPlaidConnector.getBalances('access_token');
      expect(balances).toBeInstanceOf(Array);
      expect(balances[0]).toHaveProperty('balances');
    });

    it('should get transactions', async () => {
      const result = await mockPlaidConnector.getTransactions('access_token', '2024-01-01', '2024-01-31');
      expect(result.transactions).toBeInstanceOf(Array);
      expect(result.transactions[0]).toHaveProperty('transactionId');
      expect(result.transactions[0]).toHaveProperty('amount');
      expect(result.transactions[0]).toHaveProperty('category');
    });

    it('should search institutions', async () => {
      const institutions = await mockPlaidConnector.searchInstitutions('Chase');
      expect(institutions).toBeInstanceOf(Array);
      expect(institutions[0]).toHaveProperty('institutionId');
      expect(institutions[0]).toHaveProperty('name');
    });
  });

  describe('Google Calendar OAuth Connector', () => {
    it('should generate auth URL', () => {
      const authUrl = mockCalendarConnector.getAuthUrl();
      expect(authUrl).toContain('accounts.google.com');
    });

    it('should exchange code for tokens', async () => {
      const tokens = await mockCalendarConnector.exchangeCode('auth_code');
      expect(tokens).toHaveProperty('accessToken');
      expect(tokens).toHaveProperty('refreshToken');
    });

    it('should list calendars', async () => {
      const calendars = await mockCalendarConnector.listCalendars();
      expect(calendars).toBeInstanceOf(Array);
      expect(calendars.length).toBeGreaterThan(0);
      expect(calendars[0]).toHaveProperty('id');
      expect(calendars[0]).toHaveProperty('summary');
    });

    it('should list events', async () => {
      const result = await mockCalendarConnector.listEvents();
      expect(result.events).toBeInstanceOf(Array);
      expect(result.events[0]).toHaveProperty('id');
      expect(result.events[0]).toHaveProperty('summary');
    });

    it('should check connection status', () => {
      expect(mockCalendarConnector.isConnected()).toBe(true);
    });
  });
});

describe('WebSocket Notification Service', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('Notification Sending', () => {
    it('should send notification to user', () => {
      const notificationId = mockNotificationService.notify({
        userId: 1,
        type: 'info',
        title: 'Test',
        message: 'Test message',
      });
      expect(notificationId).toBe('notif_123');
      expect(mockNotificationService.notify).toHaveBeenCalled();
    });

    it('should broadcast notification to all users', () => {
      mockNotificationService.broadcast({
        type: 'system_alert',
        title: 'System Update',
        message: 'System will restart',
      });
      expect(mockNotificationService.broadcast).toHaveBeenCalled();
    });

    it('should send to specific user', () => {
      mockNotificationService.sendToUser(1, {
        id: 'notif_1',
        type: 'info',
        title: 'Personal',
        message: 'For you only',
        priority: 'normal',
        timestamp: new Date(),
      });
      expect(mockNotificationService.sendToUser).toHaveBeenCalledWith(1, expect.any(Object));
    });
  });

  describe('Notification Management', () => {
    it('should get pending notifications', () => {
      const pending = mockNotificationService.getPendingNotifications(1);
      expect(pending).toBeInstanceOf(Array);
    });

    it('should get notification history', () => {
      const history = mockNotificationService.getNotificationHistory(1, 50);
      expect(history).toBeInstanceOf(Array);
    });

    it('should mark notification as read', () => {
      const success = mockNotificationService.markAsRead(1, 'notif_1');
      expect(success).toBe(true);
    });

    it('should mark all notifications as read', () => {
      const count = mockNotificationService.markAllAsRead(1);
      expect(count).toBe(5);
    });
  });

  describe('Connection Status', () => {
    it('should check if user is online', () => {
      const isOnline = mockNotificationService.isUserOnline(1);
      expect(isOnline).toBe(true);
    });

    it('should get online users', () => {
      const onlineUsers = mockNotificationService.getOnlineUsers();
      expect(onlineUsers).toContain(1);
      expect(onlineUsers).toContain(2);
      expect(onlineUsers).toContain(3);
    });

    it('should get connected client count', () => {
      const count = mockNotificationService.getConnectedClientCount();
      expect(count).toBe(10);
    });

    it('should get connected user count', () => {
      const count = mockNotificationService.getConnectedUserCount();
      expect(count).toBe(5);
    });
  });

  describe('Notification Types', () => {
    it('should support info notifications', () => {
      mockNotificationService.notify({ type: 'info', title: 'Info', message: 'Info message' });
      expect(mockNotificationService.notify).toHaveBeenCalled();
    });

    it('should support success notifications', () => {
      mockNotificationService.notify({ type: 'success', title: 'Success', message: 'Success message' });
      expect(mockNotificationService.notify).toHaveBeenCalled();
    });

    it('should support warning notifications', () => {
      mockNotificationService.notify({ type: 'warning', title: 'Warning', message: 'Warning message' });
      expect(mockNotificationService.notify).toHaveBeenCalled();
    });

    it('should support error notifications', () => {
      mockNotificationService.notify({ type: 'error', title: 'Error', message: 'Error message' });
      expect(mockNotificationService.notify).toHaveBeenCalled();
    });

    it('should support emergency notifications', () => {
      mockNotificationService.notify({ type: 'emergency', title: 'Emergency', message: 'Emergency!', priority: 'critical' });
      expect(mockNotificationService.notify).toHaveBeenCalled();
    });

    it('should support approval_required notifications', () => {
      mockNotificationService.notify({ 
        type: 'approval_required', 
        title: 'Approval Needed', 
        message: 'Please approve',
        actions: [
          { id: 'approve', label: 'Approve', type: 'primary', action: 'approve' },
          { id: 'reject', label: 'Reject', type: 'danger', action: 'reject' },
        ],
      });
      expect(mockNotificationService.notify).toHaveBeenCalled();
    });
  });

  describe('Priority Levels', () => {
    it('should support low priority', () => {
      mockNotificationService.notify({ type: 'info', title: 'Low', message: 'Low priority', priority: 'low' });
      expect(mockNotificationService.notify).toHaveBeenCalled();
    });

    it('should support normal priority', () => {
      mockNotificationService.notify({ type: 'info', title: 'Normal', message: 'Normal priority', priority: 'normal' });
      expect(mockNotificationService.notify).toHaveBeenCalled();
    });

    it('should support high priority', () => {
      mockNotificationService.notify({ type: 'warning', title: 'High', message: 'High priority', priority: 'high' });
      expect(mockNotificationService.notify).toHaveBeenCalled();
    });

    it('should support critical priority', () => {
      mockNotificationService.notify({ type: 'emergency', title: 'Critical', message: 'Critical!', priority: 'critical' });
      expect(mockNotificationService.notify).toHaveBeenCalled();
    });
  });
});
