import { describe, it, expect, beforeEach } from 'vitest';
import { getServiceMetricsStore } from '../services/autonomous/ServiceMetricsStore';
import { getServiceDependencyGraph } from '../services/autonomous/ServiceDependencyGraph';
import { getAlertManager } from '../services/autonomous/AlertManager';

describe('ServiceMetricsStore', () => {
  it('should return metrics store instance', () => {
    const store = getServiceMetricsStore();
    expect(store).toBeDefined();
  });

  it('should add and retrieve metrics', () => {
    const store = getServiceMetricsStore();
    const metric = store.addMetric({
      serviceId: 'test-service',
      serviceName: 'Test Service',
      metricType: 'execution',
      value: 1,
      unit: 'count',
    });
    
    expect(metric.id).toBeDefined();
    expect(metric.serviceId).toBe('test-service');
  });

  it('should get metrics with filters', () => {
    const store = getServiceMetricsStore();
    const metrics = store.getMetrics({ serviceId: 'email-management', limit: 10 });
    expect(Array.isArray(metrics)).toBe(true);
  });

  it('should get service summary', () => {
    const store = getServiceMetricsStore();
    const summary = store.getServiceSummary('email-management');
    expect(summary).toBeDefined();
    if (summary) {
      expect(summary.serviceId).toBe('email-management');
      expect(typeof summary.totalExecutions).toBe('number');
      expect(typeof summary.successRate).toBe('number');
    }
  });

  it('should get all summaries', () => {
    const store = getServiceMetricsStore();
    const summaries = store.getAllSummaries();
    expect(Array.isArray(summaries)).toBe(true);
    expect(summaries.length).toBeGreaterThan(0);
  });

  it('should get time series data', () => {
    const store = getServiceMetricsStore();
    const series = store.getMetricsTimeSeries('email-management', 'success', 24);
    expect(Array.isArray(series)).toBe(true);
  });

  it('should export metrics as JSON', () => {
    const store = getServiceMetricsStore();
    const exported = store.exportMetrics({ serviceId: 'email-management' });
    expect(typeof exported).toBe('string');
    const parsed = JSON.parse(exported);
    expect(Array.isArray(parsed)).toBe(true);
  });
});

describe('ServiceDependencyGraph', () => {
  it('should return dependency graph instance', () => {
    const graph = getServiceDependencyGraph();
    expect(graph).toBeDefined();
  });

  it('should have default dependencies', () => {
    const graph = getServiceDependencyGraph();
    const allDeps = graph.getAllDependencies();
    expect(Array.isArray(allDeps)).toBe(true);
    expect(allDeps.length).toBeGreaterThan(0);
  });

  it('should get dependencies for a service', () => {
    const graph = getServiceDependencyGraph();
    const deps = graph.getDependencies('threat-detection');
    expect(Array.isArray(deps)).toBe(true);
  });

  it('should get dependents for a service', () => {
    const graph = getServiceDependencyGraph();
    const dependents = graph.getDependents('security-hardening');
    expect(Array.isArray(dependents)).toBe(true);
  });

  it('should detect circular dependencies', () => {
    const graph = getServiceDependencyGraph();
    // Try to add a dependency that would create a cycle
    // threat-detection -> security-hardening already exists
    // Adding security-hardening -> threat-detection should be prevented
    const initialCount = graph.getAllDependencies().length;
    graph.addDependency({
      sourceServiceId: 'security-hardening',
      targetServiceId: 'threat-detection',
      triggerType: 'on_success',
      priority: 1,
      enabled: true,
    });
    // The count should not increase if cycle was detected
    // (depends on existing graph state)
    expect(graph.getAllDependencies().length).toBeLessThanOrEqual(initialCount + 1);
  });

  it('should get full graph', () => {
    const graph = getServiceDependencyGraph();
    const fullGraph = graph.getGraph();
    expect(fullGraph.nodes).toBeDefined();
    expect(fullGraph.edges).toBeDefined();
    expect(Array.isArray(fullGraph.nodes)).toBe(true);
    expect(Array.isArray(fullGraph.edges)).toBe(true);
  });

  it('should get trigger history', () => {
    const graph = getServiceDependencyGraph();
    const history = graph.getTriggerHistory(10);
    expect(Array.isArray(history)).toBe(true);
  });
});

describe('AlertManager', () => {
  it('should return alert manager instance', () => {
    const manager = getAlertManager();
    expect(manager).toBeDefined();
  });

  it('should have default alert rules', () => {
    const manager = getAlertManager();
    const rules = manager.getAllRules();
    expect(Array.isArray(rules)).toBe(true);
    expect(rules.length).toBeGreaterThan(0);
  });

  it('should get alert rule by id', () => {
    const manager = getAlertManager();
    const rule = manager.getRule('rule_critical_failure');
    expect(rule).toBeDefined();
    if (rule) {
      expect(rule.name).toBe('Critical Service Failure');
    }
  });

  it('should enable and disable rules', () => {
    const manager = getAlertManager();
    const ruleId = 'rule_cost_savings_100';
    
    manager.disableRule(ruleId);
    let rule = manager.getRule(ruleId);
    expect(rule?.enabled).toBe(false);
    
    manager.enableRule(ruleId);
    rule = manager.getRule(ruleId);
    expect(rule?.enabled).toBe(true);
  });

  it('should get alerts with filters', () => {
    const manager = getAlertManager();
    const alerts = manager.getAlerts({ limit: 10 });
    expect(Array.isArray(alerts)).toBe(true);
  });

  it('should get alert stats', () => {
    const manager = getAlertManager();
    const stats = manager.getStats();
    expect(stats).toBeDefined();
    expect(typeof stats.total).toBe('number');
    expect(typeof stats.unacknowledged).toBe('number');
    expect(stats.bySeverity).toBeDefined();
  });

  it('should trigger alerts based on conditions', async () => {
    const manager = getAlertManager();
    const initialAlerts = manager.getAlerts().length;
    
    // This may or may not trigger based on cooldown
    await manager.checkAndTrigger('test-service', 'Test Service', {
      failureCount: 5,
      successRate: 70,
    });
    
    // Just verify it doesn't throw
    expect(true).toBe(true);
  });

  it('should acknowledge alerts', () => {
    const manager = getAlertManager();
    const alerts = manager.getAlerts({ acknowledged: false });
    
    if (alerts.length > 0) {
      const result = manager.acknowledgeAlert(alerts[0].id, 'test-user');
      // May be true or false depending on state
      expect(typeof result).toBe('boolean');
    }
  });

  it('should acknowledge all alerts', () => {
    const manager = getAlertManager();
    const count = manager.acknowledgeAll();
    expect(typeof count).toBe('number');
  });
});
