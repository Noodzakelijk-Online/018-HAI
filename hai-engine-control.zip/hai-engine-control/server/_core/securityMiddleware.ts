/**
 * Comprehensive Security Middleware
 * Addresses P0 items: #56 (rate limiting), #57 (CSRF), #58 (input sanitization),
 * #60 (body size limits), #64 (session security), #67 (OAuth state validation)
 */

import { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';

// ============================================================================
// #56: Rate Limiting for Public Endpoints
// ============================================================================

interface RateLimitConfig {
  windowMs: number;      // Time window in milliseconds
  maxRequests: number;   // Max requests per window
  keyGenerator?: (req: Request) => string;
}

interface RateLimitEntry {
  count: number;
  resetTime: number;
}

const rateLimitStore = new Map<string, RateLimitEntry>();

// Clean up expired entries every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [key, entry] of rateLimitStore.entries()) {
    if (entry.resetTime < now) {
      rateLimitStore.delete(key);
    }
  }
}, 5 * 60 * 1000);

export function createRateLimiter(config: RateLimitConfig) {
  const { windowMs, maxRequests, keyGenerator } = config;
  
  return (req: Request, res: Response, next: NextFunction) => {
    const key = keyGenerator ? keyGenerator(req) : getClientIdentifier(req);
    const now = Date.now();
    
    let entry = rateLimitStore.get(key);
    
    if (!entry || entry.resetTime < now) {
      entry = { count: 1, resetTime: now + windowMs };
      rateLimitStore.set(key, entry);
    } else {
      entry.count++;
    }
    
    // Set rate limit headers
    res.setHeader('X-RateLimit-Limit', maxRequests);
    res.setHeader('X-RateLimit-Remaining', Math.max(0, maxRequests - entry.count));
    res.setHeader('X-RateLimit-Reset', Math.ceil(entry.resetTime / 1000));
    
    if (entry.count > maxRequests) {
      res.status(429).json({
        error: 'Too Many Requests',
        message: 'Rate limit exceeded. Please try again later.',
        retryAfter: Math.ceil((entry.resetTime - now) / 1000)
      });
      return;
    }
    
    next();
  };
}

function getClientIdentifier(req: Request): string {
  // Use user ID if authenticated, otherwise use IP
  const userId = (req as any).user?.id;
  if (userId) return `user:${userId}`;
  
  const ip = req.ip || 
    req.headers['x-forwarded-for']?.toString().split(',')[0] || 
    req.socket.remoteAddress || 
    'unknown';
  return `ip:${ip}`;
}

// Pre-configured rate limiters for different endpoint types
export const rateLimiters = {
  // Strict limit for auth endpoints (5 requests per minute)
  auth: createRateLimiter({ windowMs: 60 * 1000, maxRequests: 5 }),
  
  // Standard limit for API endpoints (100 requests per minute)
  api: createRateLimiter({ windowMs: 60 * 1000, maxRequests: 100 }),
  
  // Relaxed limit for read operations (300 requests per minute)
  read: createRateLimiter({ windowMs: 60 * 1000, maxRequests: 300 }),
  
  // Very strict limit for sensitive operations (3 requests per minute)
  sensitive: createRateLimiter({ windowMs: 60 * 1000, maxRequests: 3 }),
  
  // Limit for file uploads (10 per minute)
  upload: createRateLimiter({ windowMs: 60 * 1000, maxRequests: 10 }),
};

// ============================================================================
// #57: CSRF Protection
// ============================================================================

const csrfTokens = new Map<string, { token: string; expires: number }>();

// Clean up expired CSRF tokens every 10 minutes
setInterval(() => {
  const now = Date.now();
  for (const [key, entry] of csrfTokens.entries()) {
    if (entry.expires < now) {
      csrfTokens.delete(key);
    }
  }
}, 10 * 60 * 1000);

export function generateCsrfToken(sessionId: string): string {
  const token = crypto.randomBytes(32).toString('hex');
  csrfTokens.set(sessionId, {
    token,
    expires: Date.now() + 24 * 60 * 60 * 1000 // 24 hours
  });
  return token;
}

export function csrfProtection(req: Request, res: Response, next: NextFunction) {
  // Skip CSRF for safe methods
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
    return next();
  }
  
  // Skip for API key authenticated requests
  if (req.headers['x-api-key']) {
    return next();
  }
  
  const sessionId = (req as any).sessionId || (req as any).user?.id?.toString();
  if (!sessionId) {
    return next(); // No session, skip CSRF (will be caught by auth)
  }
  
  const csrfToken = req.headers['x-csrf-token'] as string || req.body?._csrf;
  const storedEntry = csrfTokens.get(sessionId);
  
  if (!storedEntry || storedEntry.token !== csrfToken || storedEntry.expires < Date.now()) {
    res.status(403).json({
      error: 'CSRF Validation Failed',
      message: 'Invalid or expired CSRF token'
    });
    return;
  }
  
  next();
}

// ============================================================================
// #58: Input Sanitization
// ============================================================================

const DANGEROUS_PATTERNS = [
  /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,  // Script tags
  /javascript:/gi,                                         // JavaScript protocol
  /on\w+\s*=/gi,                                          // Event handlers
  /data:/gi,                                               // Data URLs (potential XSS)
  /vbscript:/gi,                                          // VBScript protocol
];

const SQL_INJECTION_PATTERNS = [
  /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|UNION|ALTER|CREATE|TRUNCATE)\b)/gi,
  /(--)|(\/\*)|(\*\/)/g,                                  // SQL comments
  /(\bOR\b|\bAND\b)\s*\d+\s*=\s*\d+/gi,                  // OR 1=1 patterns
];

export function sanitizeInput(input: unknown): unknown {
  if (typeof input === 'string') {
    return sanitizeString(input);
  }
  
  if (Array.isArray(input)) {
    return input.map(sanitizeInput);
  }
  
  if (input && typeof input === 'object') {
    const sanitized: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(input)) {
      // Sanitize keys too
      const sanitizedKey = sanitizeString(key);
      sanitized[sanitizedKey] = sanitizeInput(value);
    }
    return sanitized;
  }
  
  return input;
}

function sanitizeString(str: string): string {
  let sanitized = str;
  
  // Remove dangerous HTML/JS patterns
  for (const pattern of DANGEROUS_PATTERNS) {
    sanitized = sanitized.replace(pattern, '');
  }
  
  // Escape HTML entities
  sanitized = sanitized
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;');
  
  return sanitized;
}

export function detectSqlInjection(input: string): boolean {
  for (const pattern of SQL_INJECTION_PATTERNS) {
    if (pattern.test(input)) {
      return true;
    }
  }
  return false;
}

export function inputSanitizationMiddleware(req: Request, res: Response, next: NextFunction) {
  // Check for SQL injection in query params
  for (const [key, value] of Object.entries(req.query)) {
    if (typeof value === 'string' && detectSqlInjection(value)) {
      console.warn(`[Security] Potential SQL injection detected in query param: ${key}`);
      res.status(400).json({
        error: 'Invalid Input',
        message: 'Request contains potentially malicious content'
      });
      return;
    }
  }
  
  // Sanitize body for non-file uploads
  if (req.body && !req.is('multipart/form-data')) {
    req.body = sanitizeInput(req.body);
  }
  
  next();
}

// ============================================================================
// #64: Secure Session Management
// ============================================================================

interface SessionConfig {
  maxAge: number;           // Session max age in ms
  renewalThreshold: number; // Renew if less than this time remaining
  absoluteTimeout: number;  // Absolute session timeout
}

const DEFAULT_SESSION_CONFIG: SessionConfig = {
  maxAge: 24 * 60 * 60 * 1000,        // 24 hours
  renewalThreshold: 60 * 60 * 1000,    // 1 hour
  absoluteTimeout: 7 * 24 * 60 * 60 * 1000, // 7 days
};

interface SessionData {
  userId: number;
  createdAt: number;
  lastActivity: number;
  ipAddress: string;
  userAgent: string;
}

const activeSessions = new Map<string, SessionData>();

export function createSession(userId: number, req: Request): string {
  const sessionId = crypto.randomBytes(32).toString('hex');
  const now = Date.now();
  
  activeSessions.set(sessionId, {
    userId,
    createdAt: now,
    lastActivity: now,
    ipAddress: getClientIdentifier(req),
    userAgent: req.headers['user-agent'] || 'unknown',
  });
  
  return sessionId;
}

export function validateSession(
  sessionId: string, 
  req: Request, 
  config: SessionConfig = DEFAULT_SESSION_CONFIG
): { valid: boolean; shouldRenew: boolean; reason?: string } {
  const session = activeSessions.get(sessionId);
  
  if (!session) {
    return { valid: false, shouldRenew: false, reason: 'Session not found' };
  }
  
  const now = Date.now();
  
  // Check absolute timeout
  if (now - session.createdAt > config.absoluteTimeout) {
    activeSessions.delete(sessionId);
    return { valid: false, shouldRenew: false, reason: 'Session expired (absolute timeout)' };
  }
  
  // Check inactivity timeout
  if (now - session.lastActivity > config.maxAge) {
    activeSessions.delete(sessionId);
    return { valid: false, shouldRenew: false, reason: 'Session expired (inactivity)' };
  }
  
  // Check for session hijacking (IP/UA change)
  const currentIp = getClientIdentifier(req);
  const currentUa = req.headers['user-agent'] || 'unknown';
  
  if (session.ipAddress !== currentIp || session.userAgent !== currentUa) {
    console.warn(`[Security] Potential session hijacking detected for session ${sessionId.slice(0, 8)}...`);
    // Don't invalidate immediately, but flag for review
  }
  
  // Update last activity
  session.lastActivity = now;
  
  // Check if session should be renewed
  const timeRemaining = config.maxAge - (now - session.lastActivity);
  const shouldRenew = timeRemaining < config.renewalThreshold;
  
  return { valid: true, shouldRenew };
}

export function terminateSession(sessionId: string): boolean {
  return activeSessions.delete(sessionId);
}

export function terminateAllUserSessions(userId: number): number {
  let count = 0;
  for (const [sessionId, session] of activeSessions.entries()) {
    if (session.userId === userId) {
      activeSessions.delete(sessionId);
      count++;
    }
  }
  return count;
}

export function getActiveSessions(userId: number): SessionData[] {
  const sessions: SessionData[] = [];
  for (const session of activeSessions.values()) {
    if (session.userId === userId) {
      sessions.push(session);
    }
  }
  return sessions;
}

// ============================================================================
// #67: OAuth State Parameter Validation
// ============================================================================

const oauthStates = new Map<string, { redirectUri: string; expires: number; nonce: string }>();

// Clean up expired OAuth states every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [key, entry] of oauthStates.entries()) {
    if (entry.expires < now) {
      oauthStates.delete(key);
    }
  }
}, 5 * 60 * 1000);

export function generateOAuthState(redirectUri: string): { state: string; nonce: string } {
  const state = crypto.randomBytes(32).toString('hex');
  const nonce = crypto.randomBytes(16).toString('hex');
  
  oauthStates.set(state, {
    redirectUri,
    nonce,
    expires: Date.now() + 10 * 60 * 1000 // 10 minutes
  });
  
  return { state, nonce };
}

export function validateOAuthState(state: string): { valid: boolean; redirectUri?: string; nonce?: string; reason?: string } {
  const entry = oauthStates.get(state);
  
  if (!entry) {
    return { valid: false, reason: 'Invalid state parameter' };
  }
  
  if (entry.expires < Date.now()) {
    oauthStates.delete(state);
    return { valid: false, reason: 'State parameter expired' };
  }
  
  // Delete after use (one-time use)
  oauthStates.delete(state);
  
  return { valid: true, redirectUri: entry.redirectUri, nonce: entry.nonce };
}

// ============================================================================
// #60: Request Body Size Limits
// ============================================================================

export const bodySizeLimits = {
  json: '1mb',
  urlencoded: '1mb',
  text: '1mb',
  raw: '5mb',
  multipart: '50mb', // For file uploads
};

// ============================================================================
// Combined Security Middleware
// ============================================================================

export function securityMiddleware(req: Request, res: Response, next: NextFunction) {
  // Add security headers
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  
  // Remove server identification
  res.removeHeader('X-Powered-By');
  
  next();
}

// Export all for use in routes
export default {
  rateLimiters,
  csrfProtection,
  generateCsrfToken,
  inputSanitizationMiddleware,
  sanitizeInput,
  detectSqlInjection,
  createSession,
  validateSession,
  terminateSession,
  terminateAllUserSessions,
  getActiveSessions,
  generateOAuthState,
  validateOAuthState,
  bodySizeLimits,
  securityMiddleware,
};
