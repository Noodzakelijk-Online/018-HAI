import { NOT_ADMIN_ERR_MSG, UNAUTHED_ERR_MSG } from '@shared/const';
import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context";
import { logAudit, AuditAction, audit } from '../services/auditLog';
import { generateCorrelationId, withCorrelationId, getCorrelationId } from '../services/correlationId';
import { hasPermission, Permission, Role } from '../services/rbac';
import { createLogger } from '../services/logger';
import { getRateLimitConfig } from '../config/production';

const t = initTRPC.context<TrpcContext>().create({
  transformer: superjson,
});

// Initialize logger
const logger = createLogger('tRPC');

// Simple in-memory rate limiter with production config
const rateLimitConfig = getRateLimitConfig();
const rateLimitBuckets = new Map<string, { tokens: number; lastRefill: number }>();
const MAX_TOKENS = rateLimitConfig.maxRequests;
const REFILL_RATE = rateLimitConfig.maxRequests / (rateLimitConfig.windowMs / 1000); // tokens per second

function checkRateLimit(identifier: string): boolean {
  const now = Date.now();
  let bucket = rateLimitBuckets.get(identifier);
  
  if (!bucket) {
    bucket = { tokens: MAX_TOKENS, lastRefill: now };
    rateLimitBuckets.set(identifier, bucket);
  }
  
  const timePassed = (now - bucket.lastRefill) / 1000;
  bucket.tokens = Math.min(MAX_TOKENS, bucket.tokens + timePassed * REFILL_RATE);
  bucket.lastRefill = now;
  
  if (bucket.tokens >= 1) {
    bucket.tokens -= 1;
    return true;
  }
  return false;
}

export const router = t.router;

// Base middleware that adds correlation ID and logging
const baseMiddleware = t.middleware(async opts => {
  const { ctx, next, path, type } = opts;
  
  // Generate correlation ID
  const correlationId = generateCorrelationId();
  const startTime = Date.now();
  
  return withCorrelationId(correlationId, async () => {
    try {
      const result = await next({
        ctx: {
          ...ctx,
          correlationId,
        },
      });
      
      const duration = Date.now() - startTime;
      logger.info(`${type} ${path} completed`, { 
        correlationId, 
        duration,
        userId: ctx.user?.id 
      });
      
      return result;
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`${type} ${path} failed`, error instanceof Error ? error : undefined, { 
        correlationId, 
        duration,
        userId: ctx.user?.id,
      });
      throw error;
    }
  });
});

// Rate limiting middleware
const rateLimitMiddleware = t.middleware(async opts => {
  const { ctx, next, path } = opts;
  
  // Use IP or user ID as identifier
  const identifier = ctx.user?.id?.toString() || 
    ctx.req.ip || 
    ctx.req.headers['x-forwarded-for']?.toString() || 
    'anonymous';
  
  const allowed = checkRateLimit(identifier);
  
  if (!allowed) {
    logger.warn('Rate limit exceeded', { identifier, path });
    throw new TRPCError({ 
      code: "TOO_MANY_REQUESTS", 
      message: "Rate limit exceeded. Please try again later." 
    });
  }
  
  return next();
});

// Require user middleware
const requireUser = t.middleware(async opts => {
  const { ctx, next } = opts;

  if (!ctx.user) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  }

  return next({
    ctx: {
      ...ctx,
      user: ctx.user,
    },
  });
});

// Require admin middleware
const requireAdmin = t.middleware(async opts => {
  const { ctx, next } = opts;

  if (!ctx.user || ctx.user.role !== 'admin') {
    throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
  }

  return next({
    ctx: {
      ...ctx,
      user: ctx.user,
    },
  });
});

// Audit logging middleware factory
const createAuditMiddleware = (action: AuditAction, resourceType: string) => {
  return t.middleware(async opts => {
    const { ctx, next, path, rawInput } = opts;
    
    const result = await next();
    
    // Log after successful operation
    if (ctx.user) {
      await logAudit({
        action,
        severity: action === 'delete' ? 'warning' : 'info',
        userId: ctx.user.id,
        targetType: resourceType,
        targetId: (rawInput as any)?.id?.toString() || 'unknown',
        description: `${action} on ${resourceType} via ${path}`,
        metadata: { path, input: rawInput },
        ipAddress: ctx.req.ip || 'unknown',
        userAgent: ctx.req.headers['user-agent'] || 'unknown',
        success: true,
      });
    }
    
    return result;
  });
};

// RBAC middleware factory
const createRBACMiddleware = (permission: Permission) => {
  return t.middleware(async opts => {
    const { ctx, next } = opts;
    
    if (!ctx.user) {
      throw new TRPCError({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
    }
    
    const userRole = (ctx.user.role || 'user') as Role;
    const allowed = hasPermission(userRole, permission);
    
    if (!allowed) {
      logger.warn('Permission denied', { 
        userId: ctx.user.id, 
        role: userRole, 
        permission 
      });
      
      // Log permission denial
      await logAudit({
        action: 'permission_denied',
        severity: 'warning',
        userId: ctx.user.id,
        targetType: 'permission',
        targetId: permission,
        description: `Permission denied: ${permission}`,
        ipAddress: ctx.req.ip || 'unknown',
        success: false,
      });
      
      throw new TRPCError({ 
        code: "FORBIDDEN", 
        message: `Permission denied: ${permission}` 
      });
    }
    
    return next();
  });
};

// Export procedures with middleware chains
export const publicProcedure = t.procedure
  .use(baseMiddleware)
  .use(rateLimitMiddleware);

export const protectedProcedure = t.procedure
  .use(baseMiddleware)
  .use(rateLimitMiddleware)
  .use(requireUser);

export const adminProcedure = t.procedure
  .use(baseMiddleware)
  .use(rateLimitMiddleware)
  .use(requireAdmin);

// Audited procedures for sensitive operations
export const auditedProcedure = (action: AuditAction, resourceType: string) => 
  protectedProcedure.use(createAuditMiddleware(action, resourceType));

// RBAC-protected procedures
export const rbacProcedure = (permission: Permission) =>
  protectedProcedure.use(createRBACMiddleware(permission));

// Combined audited + RBAC procedure
export const securedProcedure = (permission: Permission, action: AuditAction, resourceType: string) =>
  protectedProcedure
    .use(createRBACMiddleware(permission))
    .use(createAuditMiddleware(action, resourceType));

// Export utilities for use in routers
export { audit, logAudit, hasPermission, getCorrelationId };
export type { AuditAction, Permission };
