import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";

// Lazy imports for non-critical services - defer loading until needed
let eventBusInitialized = false;
let workersInitialized = false;

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

/**
 * Initialize non-critical services in the background after server is ready
 * This reduces initial startup time significantly
 */
async function initializeBackgroundServices(): Promise<void> {
  // Small delay to ensure server is fully ready for requests
  await new Promise(resolve => setTimeout(resolve, 100));
  
  try {
    // Initialize EventBus (non-blocking, with fallback to in-memory)
    if (!eventBusInitialized) {
      const { initEventBus } = await import("../services/initEventBus");
      initEventBus().catch(err => {
        console.warn('[HAI] EventBus initialization failed (non-critical):', err.message);
      });
      eventBusInitialized = true;
    }
    
    // Initialize Household Ledger (deferred)
    const { householdLedger } = await import("../services/HouseholdLedgerEngine");
    householdLedger.initialize().catch(err => {
      console.warn('[HAI] Household Ledger initialization failed (non-critical):', err.message);
    });
    
    // Start health check scheduler (deferred, runs every hour anyway)
    const { startHealthCheckScheduler } = await import("../services/healthCheckService");
    startHealthCheckScheduler();
    
    // Initialize background workers (deferred - they run on intervals)
    if (!workersInitialized) {
      const { initializeWorkers } = await import("../services/workers");
      initializeWorkers().catch(err => {
        console.warn('[HAI] Workers initialization failed (non-critical):', err.message);
      });
      workersInitialized = true;
    }
    
    console.log('[HAI] Background services initialized');
  } catch (error) {
    console.warn('[HAI] Background services initialization error:', error);
    // Don't throw - server should continue running
  }
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  
  // Initialize Socket.IO for agent communication (lightweight, keep synchronous)
  const { initializeAgentSocket } = await import("../services/agentSocket");
  initializeAgentSocket(server);
  
  // Initialize Screen Stream WebSocket handler for real-time screen viewing
  const { screenStreamHandler } = await import("../services/screenStreamHandler");
  screenStreamHandler.initialize(server);
  
  // Allow iframe embedding and CORS
  app.use((req, res, next) => {
    res.removeHeader('X-Frame-Options');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    next();
  });
  
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  
  // OAuth callback under /api/oauth/callback
  registerOAuthRoutes(app);
  
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${port}/`);
    
    // Initialize background services AFTER server is ready
    // This makes the server respond to requests immediately
    initializeBackgroundServices();
  });
  
  // Cleanup on shutdown
  const cleanup = async () => {
    try {
      const { stopWorkers } = await import("../services/workers");
      const { stopHealthCheckScheduler } = await import("../services/healthCheckService");
      const { cleanupEventBus } = await import("../services/initEventBus");
      
      stopWorkers();
      stopHealthCheckScheduler();
      await cleanupEventBus();
    } catch (error) {
      console.error('[HAI] Cleanup error:', error);
    }
    process.exit(0);
  };
  
  process.on('SIGTERM', cleanup);
  process.on('SIGINT', cleanup);
}

startServer().catch(console.error);
