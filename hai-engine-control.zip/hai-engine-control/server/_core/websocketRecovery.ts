export class ReconnectingWebSocket {
  private reconnectAttempts = 0;
  private maxReconnectDelay = 30000;
  
  getReconnectDelay(): number {
    const delay = Math.min(1000 * Math.pow(2, this.reconnectAttempts), this.maxReconnectDelay);
    this.reconnectAttempts++;
    return delay;
  }
  
  resetReconnectAttempts() {
    this.reconnectAttempts = 0;
  }
}
