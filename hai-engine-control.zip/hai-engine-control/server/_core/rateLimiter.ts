interface RateLimitBucket {
  tokens: number;
  lastRefill: number;
}

const buckets = new Map<string, RateLimitBucket>();

export function rateLimitMiddleware(maxTokens: number = 100, refillRate: number = 1) {
  return (req: any, res: any, next: any) => {
    const userId = req.user?.id || req.ip;
    const now = Date.now();
    
    let bucket = buckets.get(userId);
    if (!bucket) {
      bucket = { tokens: maxTokens, lastRefill: now };
      buckets.set(userId, bucket);
    }
    
    const timePassed = (now - bucket.lastRefill) / 1000;
    bucket.tokens = Math.min(maxTokens, bucket.tokens + timePassed * refillRate);
    bucket.lastRefill = now;
    
    if (bucket.tokens >= 1) {
      bucket.tokens -= 1;
      res.setHeader('X-RateLimit-Remaining', Math.floor(bucket.tokens));
      next();
    } else {
      res.status(429).json({ error: 'Rate limit exceeded' });
    }
  };
}
