/**
 * Database Index Management
 * Implements P1 #81: Add database indexes for common queries
 */

import { sql } from 'drizzle-orm';

export interface IndexDefinition {
  name: string;
  table: string;
  columns: string[];
  unique?: boolean;
  type?: 'btree' | 'hash' | 'fulltext';
  condition?: string;
}

/**
 * Common indexes for the application
 */
export const RECOMMENDED_INDEXES: IndexDefinition[] = [
  // Users table
  { name: 'idx_users_openid', table: 'users', columns: ['openId'], unique: true },
  { name: 'idx_users_email', table: 'users', columns: ['email'] },
  { name: 'idx_users_role', table: 'users', columns: ['role'] },
  { name: 'idx_users_created', table: 'users', columns: ['createdAt'] },
  
  // Tasks table
  { name: 'idx_tasks_user', table: 'tasks', columns: ['userId'] },
  { name: 'idx_tasks_status', table: 'tasks', columns: ['status'] },
  { name: 'idx_tasks_priority', table: 'tasks', columns: ['priority'] },
  { name: 'idx_tasks_due', table: 'tasks', columns: ['dueDate'] },
  { name: 'idx_tasks_user_status', table: 'tasks', columns: ['userId', 'status'] },
  
  // Connectors table
  { name: 'idx_connectors_user', table: 'connectors', columns: ['userId'] },
  { name: 'idx_connectors_type', table: 'connectors', columns: ['type'] },
  { name: 'idx_connectors_status', table: 'connectors', columns: ['status'] },
  
  // Events table
  { name: 'idx_events_type', table: 'events', columns: ['type'] },
  { name: 'idx_events_source', table: 'events', columns: ['source'] },
  { name: 'idx_events_created', table: 'events', columns: ['createdAt'] },
  { name: 'idx_events_type_created', table: 'events', columns: ['type', 'createdAt'] },
  
  // Audit logs
  { name: 'idx_audit_user', table: 'audit_logs', columns: ['userId'] },
  { name: 'idx_audit_action', table: 'audit_logs', columns: ['action'] },
  { name: 'idx_audit_created', table: 'audit_logs', columns: ['createdAt'] },
  
  // Service metrics
  { name: 'idx_metrics_service', table: 'service_metrics', columns: ['serviceName'] },
  { name: 'idx_metrics_timestamp', table: 'service_metrics', columns: ['timestamp'] },
  { name: 'idx_metrics_service_time', table: 'service_metrics', columns: ['serviceName', 'timestamp'] },
];

/**
 * Generate CREATE INDEX SQL
 */
export function generateCreateIndexSQL(index: IndexDefinition): string {
  const unique = index.unique ? 'UNIQUE ' : '';
  const type = index.type ? `USING ${index.type} ` : '';
  const columns = index.columns.join(', ');
  const condition = index.condition ? ` WHERE ${index.condition}` : '';
  
  return `CREATE ${unique}INDEX IF NOT EXISTS ${index.name} ON ${index.table} ${type}(${columns})${condition}`;
}

/**
 * Generate DROP INDEX SQL
 */
export function generateDropIndexSQL(indexName: string, tableName: string): string {
  return `DROP INDEX IF EXISTS ${indexName} ON ${tableName}`;
}

/**
 * Create indexes
 */
export async function createIndexes(
  db: any,
  indexes: IndexDefinition[] = RECOMMENDED_INDEXES
): Promise<{ created: string[]; errors: string[] }> {
  const created: string[] = [];
  const errors: string[] = [];
  
  for (const index of indexes) {
    try {
      const sqlStatement = generateCreateIndexSQL(index);
      await db.execute(sql.raw(sqlStatement));
      created.push(index.name);
      console.log(`[DB] Created index: ${index.name}`);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      // Ignore "already exists" errors
      if (!message.includes('already exists') && !message.includes('Duplicate')) {
        errors.push(`${index.name}: ${message}`);
      }
    }
  }
  
  return { created, errors };
}

/**
 * Drop indexes
 */
export async function dropIndexes(
  db: any,
  indexes: IndexDefinition[]
): Promise<{ dropped: string[]; errors: string[] }> {
  const dropped: string[] = [];
  const errors: string[] = [];
  
  for (const index of indexes) {
    try {
      const sqlStatement = generateDropIndexSQL(index.name, index.table);
      await db.execute(sql.raw(sqlStatement));
      dropped.push(index.name);
      console.log(`[DB] Dropped index: ${index.name}`);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      errors.push(`${index.name}: ${message}`);
    }
  }
  
  return { dropped, errors };
}

/**
 * Analyze query and suggest indexes
 */
export function suggestIndexes(
  query: string,
  tableName: string
): IndexDefinition[] {
  const suggestions: IndexDefinition[] = [];
  
  // Extract WHERE clause columns
  const whereMatch = query.match(/WHERE\s+(.+?)(?:ORDER|GROUP|LIMIT|$)/i);
  if (whereMatch) {
    const whereClause = whereMatch[1];
    const columns = whereClause.match(/(\w+)\s*[=<>]/g)?.map(m => m.replace(/\s*[=<>]/, ''));
    
    if (columns && columns.length > 0) {
      suggestions.push({
        name: `idx_${tableName}_${columns.join('_')}`,
        table: tableName,
        columns: [...new Set(columns)],
      });
    }
  }
  
  // Extract ORDER BY columns
  const orderMatch = query.match(/ORDER\s+BY\s+(\w+)/i);
  if (orderMatch) {
    suggestions.push({
      name: `idx_${tableName}_${orderMatch[1]}`,
      table: tableName,
      columns: [orderMatch[1]],
    });
  }
  
  // Extract GROUP BY columns
  const groupMatch = query.match(/GROUP\s+BY\s+(\w+)/i);
  if (groupMatch) {
    suggestions.push({
      name: `idx_${tableName}_${groupMatch[1]}`,
      table: tableName,
      columns: [groupMatch[1]],
    });
  }
  
  return suggestions;
}

/**
 * Get index statistics (MySQL specific)
 */
export async function getIndexStats(db: any, tableName: string): Promise<any[]> {
  try {
    const result = await db.execute(sql.raw(`
      SELECT 
        INDEX_NAME,
        COLUMN_NAME,
        SEQ_IN_INDEX,
        NON_UNIQUE,
        CARDINALITY
      FROM information_schema.STATISTICS
      WHERE TABLE_NAME = '${tableName}'
      ORDER BY INDEX_NAME, SEQ_IN_INDEX
    `));
    return result.rows || result;
  } catch {
    return [];
  }
}

/**
 * Check for missing indexes on foreign keys
 */
export function checkForeignKeyIndexes(
  schema: Record<string, { columns: Record<string, any> }>
): IndexDefinition[] {
  const missing: IndexDefinition[] = [];
  
  for (const [tableName, table] of Object.entries(schema)) {
    for (const [columnName, column] of Object.entries(table.columns)) {
      // Check if column looks like a foreign key
      if (columnName.endsWith('Id') || columnName.endsWith('_id')) {
        missing.push({
          name: `idx_${tableName}_${columnName}`,
          table: tableName,
          columns: [columnName],
        });
      }
    }
  }
  
  return missing;
}

/**
 * Index maintenance recommendations
 */
export function getMaintenanceRecommendations(): string[] {
  return [
    'Run ANALYZE TABLE periodically to update index statistics',
    'Monitor slow query log to identify queries needing indexes',
    'Remove unused indexes to improve write performance',
    'Consider composite indexes for frequently combined WHERE clauses',
    'Use covering indexes for read-heavy queries',
    'Rebuild fragmented indexes periodically',
  ];
}

export default {
  RECOMMENDED_INDEXES,
  generateCreateIndexSQL,
  generateDropIndexSQL,
  createIndexes,
  dropIndexes,
  suggestIndexes,
  getIndexStats,
  checkForeignKeyIndexes,
  getMaintenanceRecommendations,
};
