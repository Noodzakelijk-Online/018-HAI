/**
 * Circuit Breaker Pattern
 * Implements P1 #42: Implement circuit breaker for external APIs
 */

export type CircuitState = 'closed' | 'open' | 'half-open';

export interface CircuitBreakerOptions {
  failureThreshold: number;     // Number of failures before opening
  successThreshold: number;     // Number of successes to close from half-open
  timeout: number;              // Time in ms before trying again (half-open)
  monitorInterval?: number;     // Interval to check circuit state
  onStateChange?: (from: CircuitState, to: CircuitState) => void;
  onFailure?: (error: Error) => void;
  onSuccess?: () => void;
}

const DEFAULT_OPTIONS: CircuitBreakerOptions = {
  failureThreshold: 5,
  successThreshold: 2,
  timeout: 30000,
};

export class CircuitBreaker {
  private state: CircuitState = 'closed';
  private failures = 0;
  private successes = 0;
  private lastFailureTime = 0;
  private options: CircuitBreakerOptions;
  private name: string;

  constructor(name: string, options: Partial<CircuitBreakerOptions> = {}) {
    this.name = name;
    this.options = { ...DEFAULT_OPTIONS, ...options };
  }

  /**
   * Execute a function with circuit breaker protection
   */
  async execute<T>(fn: () => Promise<T>): Promise<T> {
    if (this.state === 'open') {
      // Check if timeout has passed
      if (Date.now() - this.lastFailureTime >= this.options.timeout) {
        this.transitionTo('half-open');
      } else {
        throw new CircuitOpenError(this.name, this.options.timeout - (Date.now() - this.lastFailureTime));
      }
    }

    try {
      const result = await fn();
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure(error instanceof Error ? error : new Error(String(error)));
      throw error;
    }
  }

  /**
   * Handle successful execution
   */
  private onSuccess(): void {
    this.failures = 0;
    
    if (this.state === 'half-open') {
      this.successes++;
      if (this.successes >= this.options.successThreshold) {
        this.transitionTo('closed');
        this.successes = 0;
      }
    }
    
    this.options.onSuccess?.();
  }

  /**
   * Handle failed execution
   */
  private onFailure(error: Error): void {
    this.failures++;
    this.lastFailureTime = Date.now();
    this.successes = 0;
    
    if (this.state === 'half-open') {
      this.transitionTo('open');
    } else if (this.failures >= this.options.failureThreshold) {
      this.transitionTo('open');
    }
    
    this.options.onFailure?.(error);
  }

  /**
   * Transition to a new state
   */
  private transitionTo(newState: CircuitState): void {
    if (this.state !== newState) {
      const oldState = this.state;
      this.state = newState;
      console.log(`[CircuitBreaker:${this.name}] State changed: ${oldState} -> ${newState}`);
      this.options.onStateChange?.(oldState, newState);
    }
  }

  /**
   * Get current state
   */
  getState(): CircuitState {
    return this.state;
  }

  /**
   * Get circuit statistics
   */
  getStats(): {
    name: string;
    state: CircuitState;
    failures: number;
    successes: number;
    lastFailureTime: number;
  } {
    return {
      name: this.name,
      state: this.state,
      failures: this.failures,
      successes: this.successes,
      lastFailureTime: this.lastFailureTime,
    };
  }

  /**
   * Manually reset the circuit
   */
  reset(): void {
    this.transitionTo('closed');
    this.failures = 0;
    this.successes = 0;
    this.lastFailureTime = 0;
  }

  /**
   * Manually trip the circuit
   */
  trip(): void {
    this.transitionTo('open');
    this.lastFailureTime = Date.now();
  }
}

/**
 * Error thrown when circuit is open
 */
export class CircuitOpenError extends Error {
  constructor(
    public circuitName: string,
    public retryAfterMs: number
  ) {
    super(`Circuit breaker '${circuitName}' is open. Retry after ${Math.ceil(retryAfterMs / 1000)}s`);
    this.name = 'CircuitOpenError';
  }
}

/**
 * Circuit breaker registry for managing multiple circuits
 */
class CircuitBreakerRegistry {
  private circuits: Map<string, CircuitBreaker> = new Map();

  /**
   * Get or create a circuit breaker
   */
  get(name: string, options?: Partial<CircuitBreakerOptions>): CircuitBreaker {
    if (!this.circuits.has(name)) {
      this.circuits.set(name, new CircuitBreaker(name, options));
    }
    return this.circuits.get(name)!;
  }

  /**
   * Get all circuit breakers
   */
  getAll(): CircuitBreaker[] {
    return Array.from(this.circuits.values());
  }

  /**
   * Get all circuit statistics
   */
  getAllStats(): ReturnType<CircuitBreaker['getStats']>[] {
    return this.getAll().map(cb => cb.getStats());
  }

  /**
   * Reset all circuits
   */
  resetAll(): void {
    for (const circuit of this.circuits.values()) {
      circuit.reset();
    }
  }

  /**
   * Remove a circuit
   */
  remove(name: string): boolean {
    return this.circuits.delete(name);
  }
}

export const circuitRegistry = new CircuitBreakerRegistry();

/**
 * Decorator for methods with circuit breaker
 */
export function WithCircuitBreaker(circuitName: string, options?: Partial<CircuitBreakerOptions>) {
  return function (
    target: any,
    propertyKey: string,
    descriptor: PropertyDescriptor
  ) {
    const originalMethod = descriptor.value;
    const circuit = circuitRegistry.get(circuitName, options);

    descriptor.value = async function (...args: any[]) {
      return circuit.execute(() => originalMethod.apply(this, args));
    };

    return descriptor;
  };
}

/**
 * Create a circuit-protected function
 */
export function withCircuitBreaker<T extends (...args: any[]) => Promise<any>>(
  fn: T,
  circuitName: string,
  options?: Partial<CircuitBreakerOptions>
): T {
  const circuit = circuitRegistry.get(circuitName, options);
  
  return (async (...args: Parameters<T>): Promise<ReturnType<T>> => {
    return circuit.execute(() => fn(...args));
  }) as T;
}

/**
 * Pre-configured circuit breakers for common services
 */
export const circuits = {
  llm: circuitRegistry.get('llm', {
    failureThreshold: 3,
    timeout: 60000,
    successThreshold: 1,
  }),
  
  email: circuitRegistry.get('email', {
    failureThreshold: 5,
    timeout: 30000,
    successThreshold: 2,
  }),
  
  calendar: circuitRegistry.get('calendar', {
    failureThreshold: 5,
    timeout: 30000,
    successThreshold: 2,
  }),
  
  database: circuitRegistry.get('database', {
    failureThreshold: 3,
    timeout: 10000,
    successThreshold: 1,
  }),
  
  externalApi: circuitRegistry.get('external-api', {
    failureThreshold: 5,
    timeout: 45000,
    successThreshold: 2,
  }),
};

export default {
  CircuitBreaker,
  CircuitOpenError,
  circuitRegistry,
  WithCircuitBreaker,
  withCircuitBreaker,
  circuits,
};
