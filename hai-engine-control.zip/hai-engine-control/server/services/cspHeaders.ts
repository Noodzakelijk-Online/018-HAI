/**
 * Content Security Policy Headers
 * Implements P1 #65: Add Content Security Policy headers
 */

export interface CSPDirectives {
  'default-src'?: string[];
  'script-src'?: string[];
  'style-src'?: string[];
  'img-src'?: string[];
  'font-src'?: string[];
  'connect-src'?: string[];
  'media-src'?: string[];
  'object-src'?: string[];
  'frame-src'?: string[];
  'frame-ancestors'?: string[];
  'form-action'?: string[];
  'base-uri'?: string[];
  'worker-src'?: string[];
  'manifest-src'?: string[];
  'upgrade-insecure-requests'?: boolean;
  'block-all-mixed-content'?: boolean;
}

export interface SecurityHeadersOptions {
  csp?: CSPDirectives;
  reportOnly?: boolean;
  reportUri?: string;
  enableHSTS?: boolean;
  hstsMaxAge?: number;
  enableXFrameOptions?: boolean;
  xFrameOptions?: 'DENY' | 'SAMEORIGIN';
  enableXContentTypeOptions?: boolean;
  enableXXSSProtection?: boolean;
  enableReferrerPolicy?: boolean;
  referrerPolicy?: string;
  enablePermissionsPolicy?: boolean;
  permissionsPolicy?: Record<string, string[]>;
}

const DEFAULT_CSP: CSPDirectives = {
  'default-src': ["'self'"],
  'script-src': ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
  'style-src': ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
  'img-src': ["'self'", 'data:', 'https:', 'blob:'],
  'font-src': ["'self'", 'https://fonts.gstatic.com'],
  'connect-src': ["'self'", 'https:', 'wss:'],
  'media-src': ["'self'"],
  'object-src': ["'none'"],
  'frame-ancestors': ["'self'"],
  'form-action': ["'self'"],
  'base-uri': ["'self'"],
  'upgrade-insecure-requests': true,
};

const DEFAULT_OPTIONS: SecurityHeadersOptions = {
  csp: DEFAULT_CSP,
  reportOnly: false,
  enableHSTS: true,
  hstsMaxAge: 31536000, // 1 year
  enableXFrameOptions: true,
  xFrameOptions: 'SAMEORIGIN',
  enableXContentTypeOptions: true,
  enableXXSSProtection: true,
  enableReferrerPolicy: true,
  referrerPolicy: 'strict-origin-when-cross-origin',
  enablePermissionsPolicy: true,
  permissionsPolicy: {
    camera: [],
    microphone: [],
    geolocation: [],
    'payment': ["'self'"],
  },
};

/**
 * Build CSP header string
 */
export function buildCSPHeader(directives: CSPDirectives): string {
  const parts: string[] = [];
  
  for (const [key, value] of Object.entries(directives)) {
    if (value === true) {
      parts.push(key);
    } else if (value === false) {
      // Skip false values
    } else if (Array.isArray(value) && value.length > 0) {
      parts.push(`${key} ${value.join(' ')}`);
    }
  }
  
  return parts.join('; ');
}

/**
 * Build Permissions-Policy header string
 */
export function buildPermissionsPolicy(policy: Record<string, string[]>): string {
  const parts: string[] = [];
  
  for (const [feature, allowlist] of Object.entries(policy)) {
    if (allowlist.length === 0) {
      parts.push(`${feature}=()`);
    } else {
      parts.push(`${feature}=(${allowlist.join(' ')})`);
    }
  }
  
  return parts.join(', ');
}

/**
 * Security headers middleware
 */
export function securityHeadersMiddleware(options: SecurityHeadersOptions = {}) {
  const opts = { ...DEFAULT_OPTIONS, ...options };
  const csp = { ...DEFAULT_CSP, ...opts.csp };
  
  return (req: any, res: any, next: any) => {
    // Content Security Policy
    const cspHeader = buildCSPHeader(csp);
    const cspHeaderName = opts.reportOnly 
      ? 'Content-Security-Policy-Report-Only' 
      : 'Content-Security-Policy';
    res.setHeader(cspHeaderName, cspHeader);
    
    if (opts.reportUri) {
      res.setHeader('Report-To', JSON.stringify({
        group: 'csp-endpoint',
        max_age: 10886400,
        endpoints: [{ url: opts.reportUri }],
      }));
    }
    
    // HSTS
    if (opts.enableHSTS) {
      res.setHeader(
        'Strict-Transport-Security',
        `max-age=${opts.hstsMaxAge}; includeSubDomains; preload`
      );
    }
    
    // X-Frame-Options
    if (opts.enableXFrameOptions) {
      res.setHeader('X-Frame-Options', opts.xFrameOptions || 'SAMEORIGIN');
    }
    
    // X-Content-Type-Options
    if (opts.enableXContentTypeOptions) {
      res.setHeader('X-Content-Type-Options', 'nosniff');
    }
    
    // X-XSS-Protection
    if (opts.enableXXSSProtection) {
      res.setHeader('X-XSS-Protection', '1; mode=block');
    }
    
    // Referrer-Policy
    if (opts.enableReferrerPolicy) {
      res.setHeader('Referrer-Policy', opts.referrerPolicy || 'strict-origin-when-cross-origin');
    }
    
    // Permissions-Policy
    if (opts.enablePermissionsPolicy && opts.permissionsPolicy) {
      res.setHeader('Permissions-Policy', buildPermissionsPolicy(opts.permissionsPolicy));
    }
    
    // Additional security headers
    res.setHeader('X-DNS-Prefetch-Control', 'off');
    res.setHeader('X-Download-Options', 'noopen');
    res.setHeader('X-Permitted-Cross-Domain-Policies', 'none');
    
    next();
  };
}

/**
 * Generate nonce for inline scripts
 */
export function generateNonce(): string {
  const array = new Uint8Array(16);
  crypto.getRandomValues(array);
  return Buffer.from(array).toString('base64');
}

/**
 * Add nonce to CSP for inline scripts
 */
export function addNonceToCSP(csp: CSPDirectives, nonce: string): CSPDirectives {
  return {
    ...csp,
    'script-src': [...(csp['script-src'] || []), `'nonce-${nonce}'`],
    'style-src': [...(csp['style-src'] || []), `'nonce-${nonce}'`],
  };
}

/**
 * CSP violation report handler
 */
export function cspReportHandler() {
  return (req: any, res: any) => {
    const report = req.body;
    
    console.warn('[CSP] Violation report:', {
      documentUri: report['csp-report']?.['document-uri'],
      violatedDirective: report['csp-report']?.['violated-directive'],
      blockedUri: report['csp-report']?.['blocked-uri'],
      sourceFile: report['csp-report']?.['source-file'],
      lineNumber: report['csp-report']?.['line-number'],
    });
    
    res.status(204).end();
  };
}

/**
 * Development-friendly CSP (more permissive)
 */
export const developmentCSP: CSPDirectives = {
  'default-src': ["'self'"],
  'script-src': ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
  'style-src': ["'self'", "'unsafe-inline'"],
  'img-src': ["'self'", 'data:', 'https:', 'blob:', 'http:'],
  'font-src': ["'self'", 'https:', 'data:'],
  'connect-src': ["'self'", 'https:', 'http:', 'ws:', 'wss:'],
  'media-src': ["'self'", 'https:', 'blob:'],
  'object-src': ["'none'"],
  'frame-src': ["'self'", 'https:'],
  'frame-ancestors': ["'self'"],
};

/**
 * Production CSP (strict)
 */
export const productionCSP: CSPDirectives = {
  'default-src': ["'self'"],
  'script-src': ["'self'"],
  'style-src': ["'self'", "'unsafe-inline'"],
  'img-src': ["'self'", 'data:', 'https:'],
  'font-src': ["'self'", 'https://fonts.gstatic.com'],
  'connect-src': ["'self'", 'https:'],
  'media-src': ["'self'"],
  'object-src': ["'none'"],
  'frame-src': ["'none'"],
  'frame-ancestors': ["'none'"],
  'form-action': ["'self'"],
  'base-uri': ["'self'"],
  'upgrade-insecure-requests': true,
  'block-all-mixed-content': true,
};

/**
 * Get CSP based on environment
 */
export function getEnvironmentCSP(): CSPDirectives {
  return process.env.NODE_ENV === 'production' ? productionCSP : developmentCSP;
}

export default {
  buildCSPHeader,
  buildPermissionsPolicy,
  securityHeadersMiddleware,
  generateNonce,
  addNonceToCSP,
  cspReportHandler,
  developmentCSP,
  productionCSP,
  getEnvironmentCSP,
  DEFAULT_CSP,
  DEFAULT_OPTIONS,
};
