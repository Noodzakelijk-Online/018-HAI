import { getDb } from '../db';
import { connectors } from '../../drizzle/schema';
import { eq } from 'drizzle-orm';
import { getServiceHealthStats } from './healthCheckService';
import { sendEmail } from './emailService';

/**
 * Downtime Alert Service
 * Monitors service uptime and sends alerts when it drops below threshold
 */

const ALERT_COOLDOWN_HOURS = 1; // Don't send alerts more than once per hour per service

/**
 * Check if a service needs a downtime alert
 */
export async function checkServiceForAlert(connectorId: number): Promise<void> {
  const db = await getDb();
  if (!db) return;

  try {
    // Get service details
    const service = await db
      .select()
      .from(connectors)
      .where(eq(connectors.id, connectorId))
      .limit(1);

    if (service.length === 0) return;

    const serviceData = service[0];

    // Skip if alerts are disabled
    if (!serviceData.alertsEnabled) return;

    // Skip if no URL (can't check health)
    if (!serviceData.url) return;

    // Check cooldown - don't spam alerts
    if (serviceData.lastAlertTime) {
      const hoursSinceLastAlert =
        (Date.now() - new Date(serviceData.lastAlertTime).getTime()) / (1000 * 60 * 60);

      if (hoursSinceLastAlert < ALERT_COOLDOWN_HOURS) {
        return; // Still in cooldown period
      }
    }

    // Get health stats
    const healthStats = await getServiceHealthStats(connectorId);

    // Check if uptime is below threshold
    const threshold = serviceData.uptimeThreshold || 99;

    if (healthStats.uptime < threshold && healthStats.totalChecks > 0) {
      // Send alert
      await sendDowntimeAlert(serviceData, healthStats);

      // Update last alert time
      await db
        .update(connectors)
        .set({ lastAlertTime: new Date() })
        .where(eq(connectors.id, connectorId));

      console.log(
        `[DowntimeAlert] Alert sent for service "${serviceData.name}" (uptime: ${healthStats.uptime}%)`
      );
    }
  } catch (error) {
    console.error(`[DowntimeAlert] Failed to check service ${connectorId}:`, error);
  }
}

/**
 * Send downtime alert email
 */
async function sendDowntimeAlert(
  service: any,
  healthStats: {
    uptime: number;
    avgResponseTime: number;
    lastCheckTime: Date | null;
    lastCheckStatus: 'success' | 'failure' | 'timeout' | null;
    totalChecks: number;
    successfulChecks: number;
  }
): Promise<void> {
  const db = await getDb();
  if (!db) return;

  // Get user email (assuming userId is on the service)
  // For now, we'll use the owner notification system
  const subject = `⚠️ Service Downtime Alert: ${service.name}`;

  const lastCheckTimeStr = healthStats.lastCheckTime
    ? new Date(healthStats.lastCheckTime).toLocaleString()
    : 'Never';

  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .alert-box { background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0; }
        .stats { background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0; }
        .stat-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #dee2e6; }
        .stat-label { font-weight: bold; }
        .warning { color: #856404; }
        .footer { margin-top: 30px; padding-top: 20px; border-top: 1px solid #dee2e6; font-size: 12px; color: #6c757d; }
      </style>
    </head>
    <body>
      <div class="container">
        <h2 style="color: #856404;">⚠️ Service Downtime Alert</h2>
        
        <div class="alert-box">
          <p class="warning"><strong>Your service "${service.name}" is experiencing downtime.</strong></p>
          <p>The service uptime has dropped below your configured threshold of ${service.uptimeThreshold}%.</p>
        </div>

        <div class="stats">
          <h3>Current Health Statistics</h3>
          <div class="stat-row">
            <span class="stat-label">Service Name:</span>
            <span>${service.name}</span>
          </div>
          <div class="stat-row">
            <span class="stat-label">Service URL:</span>
            <span>${service.url}</span>
          </div>
          <div class="stat-row">
            <span class="stat-label">Current Uptime:</span>
            <span style="color: ${healthStats.uptime < 95 ? '#dc3545' : '#ffc107'}; font-weight: bold;">
              ${healthStats.uptime.toFixed(1)}%
            </span>
          </div>
          <div class="stat-row">
            <span class="stat-label">Threshold:</span>
            <span>${service.uptimeThreshold}%</span>
          </div>
          <div class="stat-row">
            <span class="stat-label">Avg Response Time:</span>
            <span>${healthStats.avgResponseTime}ms</span>
          </div>
          <div class="stat-row">
            <span class="stat-label">Last Check:</span>
            <span>${lastCheckTimeStr}</span>
          </div>
          <div class="stat-row">
            <span class="stat-label">Last Status:</span>
            <span style="text-transform: capitalize;">${healthStats.lastCheckStatus || 'Unknown'}</span>
          </div>
          <div class="stat-row">
            <span class="stat-label">Success Rate:</span>
            <span>${healthStats.successfulChecks} / ${healthStats.totalChecks} checks</span>
          </div>
        </div>

        <h3>Recommended Actions</h3>
        <ul>
          <li>Check if the service is accessible from your location</li>
          <li>Verify the service URL is correct</li>
          <li>Review service logs for errors</li>
          <li>Contact the service provider if the issue persists</li>
        </ul>

        <div class="footer">
          <p>This is an automated alert from HAI Engine Control Center.</p>
          <p>You will not receive another alert for this service for at least ${ALERT_COOLDOWN_HOURS} hour(s).</p>
          <p>To disable alerts for this service, edit the service settings in ServiceHub.</p>
        </div>
      </div>
    </body>
    </html>
  `;

  await sendEmail({
    to: 'owner@example.com', // This will be logged to console if SMTP not configured
    subject,
    html,
  });
}

/**
 * Check all services for downtime alerts
 */
export async function checkAllServicesForAlerts(): Promise<void> {
  const db = await getDb();
  if (!db) return;

  try {
    // Get all services with alerts enabled and URLs
    const servicesWithAlerts = await db
      .select()
      .from(connectors)
      .where(eq(connectors.alertsEnabled, true));

    const checks = servicesWithAlerts
      .filter((service) => service.url) // Only check services with URLs
      .map((service) => checkServiceForAlert(service.id));

    await Promise.allSettled(checks);

    if (checks.length > 0) {
      console.log(`[DowntimeAlert] Checked ${checks.length} services for alerts`);
    }
  } catch (error) {
    console.error('[DowntimeAlert] Failed to check services for alerts:', error);
  }
}
