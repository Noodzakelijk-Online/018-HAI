import { getDb } from "../db";
import { capabilities } from "../../drizzle/schema";
import { eq, and, sql } from "drizzle-orm";
import { EventBus } from "./EventBus";
import { invokeLLM } from "../_core/llm";

/**
 * Frontier Engine - Capability Discovery and Service Integration
 * 
 * Enables HAI to:
 * - Discover new services and APIs
 * - Learn new skills and capabilities
 * - Integrate external services automatically
 * - Expand abilities autonomously
 */

export interface Capability {
  id: number;
  name: string;
  description: string | null;
  category: string;
  provider: string;
  apiEndpoint: string | null;
  authType: 'none' | 'api_key' | 'oauth2' | 'bearer' | null;
  schema: Record<string, unknown> | null;
  cost: number | null;
  reliability: number | null;
  confidence: number | null;
  dependencies: string[] | null;
  examples: Array<{ input: unknown; output: unknown }> | null;
  status: 'discovered' | 'testing' | 'active' | 'deprecated';
  createdAt: Date;
  updatedAt: Date;
}

export interface ServiceDiscoveryResult {
  name: string;
  description: string | null;
  endpoint: string;
  capabilities: string[];
  authType: string;
  schema?: Record<string, unknown>;
  confidence: number;
}

export interface SkillDefinition {
  name: string;
  description: string | null;
  requiredCapabilities: string[];
  steps: Array<{
    action: string;
    capability: string;
    input: Record<string, unknown>;
  }>;
  examples: Array<{ input: unknown; output: unknown }>;
}

class FrontierEngineService {
  /**
   * Discover services from API endpoint
   */
  async discoverService(endpoint: string): Promise<ServiceDiscoveryResult> {
    console.log(`[Frontier] Discovering service at ${endpoint}...`);

    try {
      // Try to fetch OpenAPI/Swagger spec
      const openApiUrls = [
        `${endpoint}/openapi.json`,
        `${endpoint}/swagger.json`,
        `${endpoint}/api-docs`,
        `${endpoint}/docs/swagger.json`,
      ];

      let schema: Record<string, unknown> | undefined;
      for (const url of openApiUrls) {
        try {
          const response = await fetch(url, { method: 'GET', headers: { 'Accept': 'application/json' } });
          if (response.ok) {
            schema = await response.json() as Record<string, unknown>;
            break;
          }
        } catch {
          // Try next URL
        }
      }

      if (schema) {
        // Parse OpenAPI schema
        const capabilities = this.extractCapabilitiesFromSchema(schema);
        const authType = this.detectAuthType(schema);

        await EventBus.publish({
          type: 'frontier.service_discovered',
          source: 'frontier-engine',
          target: '*',
          data: { endpoint, capabilities: capabilities.length },
          metadata: { timestamp: new Date().toISOString() },
        });

        return {
          name: (schema.info as any)?.title || 'Unknown Service',
          description: (schema.info as any)?.description || '',
          endpoint,
          capabilities,
          authType,
          schema,
          confidence: 0.9,
        };
      }

      // Fallback: Use LLM to analyze endpoint
      const llmResult = await invokeLLM({
        messages: [
          {
            role: 'system',
            content: 'You are an API discovery assistant. Analyze API endpoints and describe their capabilities.',
          },
          {
            role: 'user',
            content: `Analyze this API endpoint and describe what it does: ${endpoint}`,
          },
        ],
      });

      const content = llmResult.choices[0]?.message?.content;
      const description = typeof content === 'string' ? content : 'Unknown service';

      return {
        name: 'Unknown Service',
        description,
        endpoint,
        capabilities: [],
        authType: 'unknown',
        confidence: 0.3,
      };
    } catch (error) {
      console.error('[Frontier] Service discovery failed:', error);
      throw error;
    }
  }

  /**
   * Extract capabilities from OpenAPI schema
   */
  private extractCapabilitiesFromSchema(schema: Record<string, unknown>): string[] {
    const capabilities: string[] = [];

    try {
      const paths = schema.paths as Record<string, Record<string, any>>;
      if (!paths) return capabilities;

      for (const [path, methods] of Object.entries(paths)) {
        for (const [method, spec] of Object.entries(methods)) {
          if (typeof spec === 'object' && spec.summary) {
            capabilities.push(`${method.toUpperCase()} ${path}: ${spec.summary}`);
          }
        }
      }
    } catch (error) {
      console.error('[Frontier] Failed to extract capabilities:', error);
    }

    return capabilities;
  }

  /**
   * Detect authentication type from schema
   */
  private detectAuthType(schema: Record<string, unknown>): string {
    try {
      const securitySchemes = (schema.components as any)?.securitySchemes;
      if (!securitySchemes) return 'none';

      const types = Object.values(securitySchemes).map((s: any) => s.type);
      if (types.includes('oauth2')) return 'oauth2';
      if (types.includes('apiKey')) return 'api_key';
      if (types.includes('http')) return 'bearer';
      return 'unknown';
    } catch {
      return 'none';
    }
  }

  /**
   * Register a new capability
   */
  async registerCapability(capability: Omit<Capability, 'id' | 'createdAt' | 'updatedAt'>): Promise<Capability> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const result = await db.insert(capabilities).values({
      name: capability.name,
      description: capability.description,
      category: capability.category,
      provider: capability.provider,
      apiEndpoint: capability.apiEndpoint,
      authType: capability.authType,
      schema: capability.schema,
      cost: capability.cost,
      reliability: capability.reliability,
      confidence: capability.confidence,
      dependencies: capability.dependencies,
      examples: capability.examples,
      status: capability.status,
    });

    await EventBus.publish({
      type: 'frontier.capability_registered',
      source: 'frontier-engine',
      target: '*',
      data: { capabilityId: Number(result[0].insertId), name: capability.name },
      metadata: { timestamp: new Date().toISOString() },
    });

    return {
      id: Number(result[0].insertId),
      ...capability,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
  }

  /**
   * Find capabilities matching a requirement
   */
  async matchCapabilities(requirement: string): Promise<Capability[]> {
    const db = await getDb();
    if (!db) return [];

    // Use LLM to understand the requirement
    const llmResult = await invokeLLM({
      messages: [
        {
          role: 'system',
          content: 'You are a capability matching assistant. Extract keywords and categories from user requirements.',
        },
        {
          role: 'user',
          content: `Extract keywords and category from this requirement: "${requirement}"`,
        },
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'requirement_analysis',
          strict: true,
          schema: {
            type: 'object',
            properties: {
              keywords: { type: 'array', items: { type: 'string' } },
              category: { type: 'string' },
            },
            required: ['keywords', 'category'],
            additionalProperties: false,
          },
        },
      },
    });

    const content = llmResult.choices[0]?.message?.content;
    const contentStr = typeof content === 'string' ? content : '{"keywords":[],"category":"general"}';
    const analysis = JSON.parse(contentStr);

    // Search capabilities
    const allCapabilities = await db.select().from(capabilities).where(eq(capabilities.status, 'active'));

    // Rank by relevance
    const ranked = allCapabilities.map((cap: any) => {
      let score = 0;
      const capText = `${cap.name} ${cap.description} ${cap.category}`.toLowerCase();

      for (const keyword of analysis.keywords) {
        if (capText.includes(keyword.toLowerCase())) {
          score += 1;
        }
      }

      if (cap.category === analysis.category) {
        score += 2;
      }

      return { ...cap, score };
    });

    return ranked
      .filter(c => c.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);
  }

  /**
   * Learn a new skill from examples
   */
  async learnSkill(skill: SkillDefinition): Promise<void> {
    console.log(`[Frontier] Learning new skill: ${skill.name}...`);

    // Verify required capabilities exist
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    for (const capName of skill.requiredCapabilities) {
      const existing = await db.select().from(capabilities).where(eq(capabilities.name, capName)).limit(1);
      if (existing.length === 0) {
        throw new Error(`Required capability not found: ${capName}`);
      }
    }

    // Register skill as a composite capability
    await this.registerCapability({
      name: skill.name,
      description: skill.description,
      category: 'composite',
      provider: 'hai-learned',
      apiEndpoint: null,
      authType: null,
      schema: null,
      cost: null,
      reliability: null,
      confidence: 70,
      dependencies: skill.requiredCapabilities,
      examples: skill.examples,
      status: 'active',
    });

    await EventBus.publish({
      type: 'frontier.skill_learned',
      source: 'frontier-engine',
      target: '*',
      data: { skillName: skill.name, requiredCapabilities: skill.requiredCapabilities.length },
      metadata: { timestamp: new Date().toISOString() },
    });

    console.log(`[Frontier] Skill learned: ${skill.name}`);
  }

  /**
   * Get all capabilities
   */
  async getAllCapabilities(): Promise<Capability[]> {
    const db = await getDb();
    if (!db) return [];

    const results = await db.select().from(capabilities);
    return results.map(r => ({
      ...r,
      schema: r.schema as Record<string, unknown> | null,
      dependencies: r.dependencies as string[] | null,
      examples: r.examples as Array<{ input: unknown; output: unknown }> | null,
    }));
  }

  /**
   * Get capability by ID
   */
  async getCapability(id: number): Promise<Capability | null> {
    const db = await getDb();
    if (!db) return null;

    const result = await db.select().from(capabilities).where(eq(capabilities.id, id)).limit(1);
    return result.length > 0 ? result[0] as Capability : null;
  }

  /**
   * Update capability status
   */
  async updateCapabilityStatus(id: number, status: Capability['status']): Promise<void> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    await db.update(capabilities).set({ status, updatedAt: new Date() }).where(eq(capabilities.id, id));

    await EventBus.publish({
      type: 'frontier.capability_status_updated',
      source: 'frontier-engine',
      target: '*',
      data: { capabilityId: id, status },
      metadata: { timestamp: new Date().toISOString() },
    });
  }

  /**
   * Get capability statistics
   */
  async getStatistics(): Promise<{
    total: number;
    byCategory: Record<string, number>;
    byStatus: Record<string, number>;
    byProvider: Record<string, number>;
  }> {
    const db = await getDb();
    if (!db) return { total: 0, byCategory: {}, byStatus: {}, byProvider: {} };

    const allCaps = await db.select().from(capabilities);

    const byCategory: Record<string, number> = {};
    const byStatus: Record<string, number> = {};
    const byProvider: Record<string, number> = {};

    for (const cap of allCaps) {
      byCategory[cap.category] = (byCategory[cap.category] || 0) + 1;
      byStatus[cap.status] = (byStatus[cap.status] || 0) + 1;
      byProvider[cap.provider] = (byProvider[cap.provider] || 0) + 1;
    }

    return {
      total: allCaps.length,
      byCategory,
      byStatus,
      byProvider,
    };
  }
}

export const frontierEngine = new FrontierEngineService();
