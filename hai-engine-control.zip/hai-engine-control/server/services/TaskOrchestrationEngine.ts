import { getDb } from "../db";
import { tasks, InsertTask, Task } from "../../drizzle/schema";
import { eq, and, desc, inArray } from "drizzle-orm";
import { EventBus } from "./EventBus";
import { LLMService } from "./LLMService";
import { DecisionEngine } from "./DecisionEngine";
import { logActivity } from "./activityTracker";

/**
 * Task status in the lifecycle
 */
export type TaskStatus = 
  | 'draft'              // Initial state, not yet approved
  | 'pending_approval'   // Waiting for user approval
  | 'approved'           // Approved, ready to execute
  | 'in_progress'        // Currently executing
  | 'completed'          // Successfully completed
  | 'failed'             // Execution failed
  | 'cancelled';         // User cancelled

/**
 * Task priority levels
 */
export type TaskPriority = 'low' | 'medium' | 'high' | 'urgent';

/**
 * Subtask structure for decomposition
 */
export interface Subtask {
  title: string;
  description: string;
  taskType: string;
  priority: TaskPriority;
  estimatedTime?: number; // minutes
  dependencies?: number[]; // indices of other subtasks this depends on
  assignedEngine?: string;
}

/**
 * Task decomposition result
 */
export interface TaskDecomposition {
  goal: string;
  subtasks: Subtask[];
  executionOrder: number[]; // Order to execute subtasks (topological sort)
  estimatedTotalTime: number; // minutes
  complexity: 'simple' | 'moderate' | 'complex';
}

/**
 * Task dependency
 */
export interface TaskDependency {
  taskId: number;
  dependsOnTaskId: number;
}

/**
 * Task execution result
 */
export interface TaskExecutionResult {
  success: boolean;
  output?: any;
  error?: string;
  duration?: number; // milliseconds
}

/**
 * Task Orchestration Engine
 * 
 * Breaks down complex goals into executable tasks and manages their lifecycle.
 */
class TaskOrchestrationEngineService {
  /**
   * Decompose a goal into subtasks
   */
  async decomposeGoal(params: {
    userId: number;
    goal: string;
    context?: string;
  }): Promise<TaskDecomposition> {
    const { userId, goal, context } = params;

    // Use LLM to break down the goal
    const prompt = `You are a task planning AI. Break down the following goal into concrete, executable subtasks.

Goal: ${goal}
${context ? `Context: ${context}` : ''}

For each subtask, provide:
1. Title (concise, action-oriented)
2. Description (what needs to be done)
3. Task type (email, calendar, finance, research, automation, communication)
4. Priority (low, medium, high, urgent)
5. Estimated time in minutes
6. Dependencies (which other subtasks must complete first, by index)
7. Assigned engine (which HAI engine should handle this)

Return a JSON object with this structure:
{
  "subtasks": [
    {
      "title": "string",
      "description": "string",
      "taskType": "email|calendar|finance|research|automation|communication",
      "priority": "low|medium|high|urgent",
      "estimatedTime": number,
      "dependencies": [number],
      "assignedEngine": "string"
    }
  ],
  "complexity": "simple|moderate|complex"
}`;

    const response = await LLMService.chat({
      userId,
      conversationId: `task_decompose_${Date.now()}`,
      message: prompt,
      engineType: 'task',
    });

    // Parse LLM response
    let decomposition: any;
    try {
      // Extract JSON from response
      const jsonMatch = response.response.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        decomposition = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('No JSON found in response');
      }
    } catch (error) {
      console.error('[TaskOrchestration] Error parsing decomposition:', error);
      // Fallback: create a single task
      decomposition = {
        subtasks: [{
          title: goal,
          description: goal,
          taskType: 'automation',
          priority: 'medium',
          estimatedTime: 30,
          dependencies: [],
          assignedEngine: 'task_orchestration',
        }],
        complexity: 'simple',
      };
    }

    // Calculate execution order (topological sort)
    const executionOrder = this.calculateExecutionOrder(decomposition.subtasks);

    // Calculate total estimated time
    const estimatedTotalTime = decomposition.subtasks.reduce(
      (sum: number, task: Subtask) => sum + (task.estimatedTime || 0),
      0
    );

    const result: TaskDecomposition = {
      goal,
      subtasks: decomposition.subtasks,
      executionOrder,
      estimatedTotalTime,
      complexity: decomposition.complexity || 'moderate',
    };

    // Publish decomposition event
    await EventBus.publish({
      type: 'task.decomposed',
      source: 'TaskOrchestrationEngine',
      target: '*',
      data: {
        userId,
        goal,
        subtaskCount: result.subtasks.length,
        complexity: result.complexity,
      },
    });

    return result;
  }

  /**
   * Create tasks from decomposition
   */
  async createTasksFromDecomposition(params: {
    userId: number;
    decomposition: TaskDecomposition;
    requireApproval?: boolean;
  }): Promise<Task[]> {
    const { userId, decomposition, requireApproval = true } = params;

    const db = await getDb();
    if (!db) {
      throw new Error('Database not available');
    }

    const createdTasks: Task[] = [];

    // Create tasks in order
    for (let i = 0; i < decomposition.subtasks.length; i++) {
      const subtask = decomposition.subtasks[i];

      const status: TaskStatus = requireApproval ? 'pending_approval' : 'approved';

      await db.insert(tasks).values({
        userId,
        title: subtask.title,
        taskType: subtask.taskType as any,
        description: subtask.description,
        status: status as any,
        priority: subtask.priority as any,
        autonomyLevel: 2, // Default to Level 2
        assignedEngine: subtask.assignedEngine,
        metadata: {
          estimatedTime: subtask.estimatedTime,
          dependencies: subtask.dependencies,
          decompositionIndex: i,
          goal: decomposition.goal,
        } as any,
      });

      // Fetch the created task
      const created = await db
        .select()
        .from(tasks)
        .where(eq(tasks.userId, userId))
        .orderBy(desc(tasks.id))
        .limit(1);

      if (created.length > 0) {
        createdTasks.push(created[0] as Task);
      }
    }

    // Publish task creation event
    await EventBus.publish({
      type: 'task.batch_created',
      source: 'TaskOrchestrationEngine',
      target: '*',
      data: {
        userId,
        taskCount: createdTasks.length,
        goal: decomposition.goal,
      },
    });
    
    // Log task creation activity
    await logActivity({
      engine: 'task',
      action: 'create_tasks',
      title: `Created ${createdTasks.length} tasks for: ${decomposition.goal}`,
      description: `Decomposed goal into ${createdTasks.length} executable subtasks`,
      metadata: JSON.stringify({
        goal: decomposition.goal,
        taskCount: createdTasks.length,
        complexity: decomposition.complexity,
        estimatedTime: decomposition.estimatedTotalTime,
      }),
      impact: 'medium',
      status: 'completed',
      userId,
    });

    return createdTasks;
  }

  /**
   * Calculate execution order using topological sort
   */
  private calculateExecutionOrder(subtasks: Subtask[]): number[] {
    const n = subtasks.length;
    const inDegree = new Array(n).fill(0);
    const adjList: number[][] = Array.from({ length: n }, () => []);

    // Build adjacency list and calculate in-degrees
    for (let i = 0; i < n; i++) {
      const deps = subtasks[i].dependencies || [];
      for (const dep of deps) {
        if (dep >= 0 && dep < n) {
          adjList[dep].push(i);
          inDegree[i]++;
        }
      }
    }

    // Kahn's algorithm for topological sort
    const queue: number[] = [];
    const result: number[] = [];

    // Start with nodes that have no dependencies
    for (let i = 0; i < n; i++) {
      if (inDegree[i] === 0) {
        queue.push(i);
      }
    }

    while (queue.length > 0) {
      const current = queue.shift()!;
      result.push(current);

      // Reduce in-degree for neighbors
      for (const neighbor of adjList[current]) {
        inDegree[neighbor]--;
        if (inDegree[neighbor] === 0) {
          queue.push(neighbor);
        }
      }
    }

    // Check for circular dependencies
    if (result.length !== n) {
      console.warn('[TaskOrchestration] Circular dependencies detected, using simple order');
      return Array.from({ length: n }, (_, i) => i);
    }

    return result;
  }

  /**
   * Get tasks ready for execution (no pending dependencies)
   */
  async getReadyTasks(userId: number): Promise<Task[]> {
    const db = await getDb();
    if (!db) return [];

    // Get all approved tasks
    const approvedTasks = await db
      .select()
      .from(tasks)
      .where(and(
        eq(tasks.userId, userId),
        eq(tasks.status, 'approved' as any)
      ));

    // Filter tasks with no pending dependencies
    const readyTasks: Task[] = [];

    for (const task of approvedTasks) {
      const metadata = task.metadata as any;
      const dependencies = metadata?.dependencies || [];

      if (dependencies.length === 0) {
        readyTasks.push(task as Task);
        continue;
      }

      // Check if all dependencies are completed
      // Get all tasks for this user and filter by goal in memory
      const allUserTasks = await db
        .select()
        .from(tasks)
        .where(eq(tasks.userId, userId));
      
      const allTasksInGoal = allUserTasks.filter(
        (t: any) => t.metadata?.goal === metadata.goal
      );

      const allCompleted = dependencies.every((depIndex: number) => {
        const depTask = allTasksInGoal.find(
          (t: any) => t.metadata?.decompositionIndex === depIndex
        );
        return depTask && depTask.status === 'completed';
      });

      if (allCompleted) {
        readyTasks.push(task as Task);
      }
    }

    return readyTasks as Task[];
  }

  /**
   * Start task execution
   */
  async startTask(taskId: number): Promise<boolean> {
    const db = await getDb();
    if (!db) return false;

    try {
      // Update task status
      await db
        .update(tasks)
        .set({
          status: 'in_progress' as any,
          startedAt: new Date(),
        })
        .where(eq(tasks.id, taskId));

      // Get task details
      const task = await db
        .select()
        .from(tasks)
        .where(eq(tasks.id, taskId))
        .limit(1);

      if (task.length === 0) return false;

      // Publish task started event
      await EventBus.publish({
        type: 'task.started',
        source: 'TaskOrchestrationEngine',
        target: task[0].assignedEngine || '*',
        data: {
          taskId,
          task: task[0],
        },
      });

      return true;
    } catch (error) {
      console.error('[TaskOrchestration] Error starting task:', error);
      return false;
    }
  }

  /**
   * Complete a task
   */
  async completeTask(params: {
    taskId: number;
    result?: any;
  }): Promise<boolean> {
    const { taskId, result } = params;

    const db = await getDb();
    if (!db) return false;

    try {
      // Update task status
      await db
        .update(tasks)
        .set({
          status: 'completed' as any,
          completedAt: new Date(),
          result: result as any,
        })
        .where(eq(tasks.id, taskId));

      // Get task details
      const task = await db
        .select()
        .from(tasks)
        .where(eq(tasks.id, taskId))
        .limit(1);

      if (task.length === 0) return false;

      // Publish task completed event
      await EventBus.publish({
        type: 'task.completed',
        source: 'TaskOrchestrationEngine',
        target: '*',
        data: {
          taskId,
          task: task[0],
        },
      });
      
      // Log task completion activity
      const completedTask = task[0] as Task;
      await logActivity({
        engine: 'task',
        action: 'complete_task',
        title: `Completed task: ${completedTask.title}`,
        description: `Successfully completed task of type ${completedTask.taskType}`,
        metadata: JSON.stringify({
          taskId,
          taskType: completedTask.taskType,
          priority: completedTask.priority,
          result: result ? 'success' : 'no result',
        }),
        impact: completedTask.priority === 'urgent' || completedTask.priority === 'high' ? 'high' : 'medium',
        status: 'completed',
        userId: completedTask.userId,
      });

      // Check if this completes a goal
      await this.checkGoalCompletion(task[0] as Task);

      return true;
    } catch (error) {
      console.error('[TaskOrchestration] Error completing task:', error);
      return false;
    }
  }

  /**
   * Fail a task
   */
  async failTask(params: {
    taskId: number;
    error: string;
  }): Promise<boolean> {
    const { taskId, error } = params;

    const db = await getDb();
    if (!db) return false;

    try {
      // Update task status
      await db
        .update(tasks)
        .set({
          status: 'failed' as any,
          errorMessage: error,
        })
        .where(eq(tasks.id, taskId));

      // Get task details
      const task = await db
        .select()
        .from(tasks)
        .where(eq(tasks.id, taskId))
        .limit(1);

      if (task.length === 0) return false;

      // Publish task failed event
      await EventBus.publish({
        type: 'task.failed',
        source: 'TaskOrchestrationEngine',
        target: '*',
        data: {
          taskId,
          task: task[0],
          error,
        },
      });

      return true;
    } catch (error) {
      console.error('[TaskOrchestration] Error failing task:', error);
      return false;
    }
  }

  /**
   * Cancel a task
   */
  async cancelTask(taskId: number): Promise<boolean> {
    const db = await getDb();
    if (!db) return false;

    try {
      // Update task status
      await db
        .update(tasks)
        .set({
          status: 'cancelled' as any,
        })
        .where(eq(tasks.id, taskId));

      // Publish task cancelled event
      await EventBus.publish({
        type: 'task.cancelled',
        source: 'TaskOrchestrationEngine',
        target: '*',
        data: {
          taskId,
        },
      });

      return true;
    } catch (error) {
      console.error('[TaskOrchestration] Error cancelling task:', error);
      return false;
    }
  }

  /**
   * Check if a goal is completed
   */
  private async checkGoalCompletion(completedTask: Task): Promise<void> {
    const db = await getDb();
    if (!db) return;

    const metadata = completedTask.metadata as any;
    const goal = metadata?.goal;

    if (!goal) return;

    // Get all tasks for this goal
    // Get all user tasks and filter by goal in memory
    const allUserTasks = await db
      .select()
      .from(tasks)
      .where(eq(tasks.userId, completedTask.userId));
    
    const allTasks = allUserTasks.filter(
      (t: any) => t.metadata?.goal === goal
    );

    // Check if all tasks are completed
    const allCompleted = allTasks.every(
      (t: any) => t.status === 'completed' || t.status === 'cancelled'
    );

    if (allCompleted) {
      // Publish goal completed event
      await EventBus.publish({
        type: 'goal.completed',
        source: 'TaskOrchestrationEngine',
        target: '*',
        data: {
          userId: completedTask.userId,
          goal,
          taskCount: allTasks.length,
        },
      });
    }
  }

  /**
   * Get task statistics for a user
   */
  async getTaskStats(userId: number): Promise<{
    total: number;
    byStatus: Record<string, number>;
    byPriority: Record<string, number>;
    inProgress: number;
    completed: number;
  }> {
    const db = await getDb();
    if (!db) {
      return {
        total: 0,
        byStatus: {},
        byPriority: {},
        inProgress: 0,
        completed: 0,
      };
    }

    const allTasks = await db
      .select()
      .from(tasks)
      .where(eq(tasks.userId, userId));

    const byStatus: Record<string, number> = {};
    const byPriority: Record<string, number> = {};
    let inProgress = 0;
    let completed = 0;

    for (const task of allTasks) {
      // Count by status
      byStatus[task.status] = (byStatus[task.status] || 0) + 1;

      // Count by priority
      byPriority[task.priority] = (byPriority[task.priority] || 0) + 1;

      // Count in progress
      if (task.status === 'in_progress') inProgress++;

      // Count completed
      if (task.status === 'completed') completed++;
    }

    return {
      total: allTasks.length,
      byStatus,
      byPriority,
      inProgress,
      completed,
    };
  }
}

// Export singleton instance
export const TaskOrchestrationEngine = new TaskOrchestrationEngineService();
