/**
 * Foreign Key Constraints Helper
 * Implements P1 #79: Add foreign key constraints
 */

import { sql } from 'drizzle-orm';

export interface ForeignKeyDefinition {
  name: string;
  table: string;
  column: string;
  referencesTable: string;
  referencesColumn: string;
  onDelete: 'CASCADE' | 'SET NULL' | 'RESTRICT' | 'NO ACTION';
  onUpdate: 'CASCADE' | 'SET NULL' | 'RESTRICT' | 'NO ACTION';
}

/**
 * Recommended foreign keys for the application
 */
export const RECOMMENDED_FOREIGN_KEYS: ForeignKeyDefinition[] = [
  // Tasks -> Users
  {
    name: 'fk_tasks_user',
    table: 'tasks',
    column: 'userId',
    referencesTable: 'users',
    referencesColumn: 'id',
    onDelete: 'CASCADE',
    onUpdate: 'CASCADE',
  },
  // Connectors -> Users
  {
    name: 'fk_connectors_user',
    table: 'connectors',
    column: 'userId',
    referencesTable: 'users',
    referencesColumn: 'id',
    onDelete: 'CASCADE',
    onUpdate: 'CASCADE',
  },
  // Events -> Users (optional)
  {
    name: 'fk_events_user',
    table: 'events',
    column: 'userId',
    referencesTable: 'users',
    referencesColumn: 'id',
    onDelete: 'SET NULL',
    onUpdate: 'CASCADE',
  },
  // Audit logs -> Users
  {
    name: 'fk_audit_user',
    table: 'audit_logs',
    column: 'userId',
    referencesTable: 'users',
    referencesColumn: 'id',
    onDelete: 'SET NULL',
    onUpdate: 'CASCADE',
  },
  // Sessions -> Users
  {
    name: 'fk_sessions_user',
    table: 'sessions',
    column: 'userId',
    referencesTable: 'users',
    referencesColumn: 'id',
    onDelete: 'CASCADE',
    onUpdate: 'CASCADE',
  },
];

/**
 * Generate ADD FOREIGN KEY SQL
 */
export function generateAddForeignKeySQL(fk: ForeignKeyDefinition): string {
  return `
    ALTER TABLE ${fk.table}
    ADD CONSTRAINT ${fk.name}
    FOREIGN KEY (${fk.column})
    REFERENCES ${fk.referencesTable}(${fk.referencesColumn})
    ON DELETE ${fk.onDelete}
    ON UPDATE ${fk.onUpdate}
  `.trim();
}

/**
 * Generate DROP FOREIGN KEY SQL
 */
export function generateDropForeignKeySQL(tableName: string, constraintName: string): string {
  return `ALTER TABLE ${tableName} DROP FOREIGN KEY ${constraintName}`;
}

/**
 * Add foreign keys
 */
export async function addForeignKeys(
  db: any,
  foreignKeys: ForeignKeyDefinition[] = RECOMMENDED_FOREIGN_KEYS
): Promise<{ added: string[]; errors: string[] }> {
  const added: string[] = [];
  const errors: string[] = [];
  
  for (const fk of foreignKeys) {
    try {
      const sqlStatement = generateAddForeignKeySQL(fk);
      await db.execute(sql.raw(sqlStatement));
      added.push(fk.name);
      console.log(`[FK] Added foreign key: ${fk.name}`);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      // Ignore "already exists" errors
      if (!message.includes('Duplicate') && !message.includes('already exists')) {
        errors.push(`${fk.name}: ${message}`);
      }
    }
  }
  
  return { added, errors };
}

/**
 * Drop foreign keys
 */
export async function dropForeignKeys(
  db: any,
  foreignKeys: ForeignKeyDefinition[]
): Promise<{ dropped: string[]; errors: string[] }> {
  const dropped: string[] = [];
  const errors: string[] = [];
  
  for (const fk of foreignKeys) {
    try {
      const sqlStatement = generateDropForeignKeySQL(fk.table, fk.name);
      await db.execute(sql.raw(sqlStatement));
      dropped.push(fk.name);
      console.log(`[FK] Dropped foreign key: ${fk.name}`);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      errors.push(`${fk.name}: ${message}`);
    }
  }
  
  return { dropped, errors };
}

/**
 * Get existing foreign keys for a table
 */
export async function getTableForeignKeys(db: any, tableName: string): Promise<any[]> {
  try {
    const result = await db.execute(sql.raw(`
      SELECT 
        CONSTRAINT_NAME,
        COLUMN_NAME,
        REFERENCED_TABLE_NAME,
        REFERENCED_COLUMN_NAME
      FROM information_schema.KEY_COLUMN_USAGE
      WHERE TABLE_NAME = '${tableName}'
        AND REFERENCED_TABLE_NAME IS NOT NULL
    `));
    return result.rows || result;
  } catch {
    return [];
  }
}

/**
 * Validate foreign key integrity
 */
export async function validateForeignKeyIntegrity(
  db: any,
  fk: ForeignKeyDefinition
): Promise<{ valid: boolean; orphanCount: number }> {
  try {
    const result = await db.execute(sql.raw(`
      SELECT COUNT(*) as orphan_count
      FROM ${fk.table} t
      LEFT JOIN ${fk.referencesTable} r ON t.${fk.column} = r.${fk.referencesColumn}
      WHERE t.${fk.column} IS NOT NULL AND r.${fk.referencesColumn} IS NULL
    `));
    
    const orphanCount = result.rows?.[0]?.orphan_count || 0;
    return { valid: orphanCount === 0, orphanCount };
  } catch {
    return { valid: false, orphanCount: -1 };
  }
}

/**
 * Fix orphan records
 */
export async function fixOrphanRecords(
  db: any,
  fk: ForeignKeyDefinition,
  action: 'delete' | 'nullify'
): Promise<number> {
  try {
    if (action === 'delete') {
      const result = await db.execute(sql.raw(`
        DELETE t FROM ${fk.table} t
        LEFT JOIN ${fk.referencesTable} r ON t.${fk.column} = r.${fk.referencesColumn}
        WHERE t.${fk.column} IS NOT NULL AND r.${fk.referencesColumn} IS NULL
      `));
      return result.rowsAffected || 0;
    } else {
      const result = await db.execute(sql.raw(`
        UPDATE ${fk.table} t
        LEFT JOIN ${fk.referencesTable} r ON t.${fk.column} = r.${fk.referencesColumn}
        SET t.${fk.column} = NULL
        WHERE t.${fk.column} IS NOT NULL AND r.${fk.referencesColumn} IS NULL
      `));
      return result.rowsAffected || 0;
    }
  } catch {
    return 0;
  }
}

export default {
  RECOMMENDED_FOREIGN_KEYS,
  generateAddForeignKeySQL,
  generateDropForeignKeySQL,
  addForeignKeys,
  dropForeignKeys,
  getTableForeignKeys,
  validateForeignKeyIntegrity,
  fixOrphanRecords,
};
