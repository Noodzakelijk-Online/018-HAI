/**
 * Need-Based Priority Adjuster
 * 
 * Adjusts task priorities based on Maslow's Hierarchy of Needs fulfillment levels.
 * Tasks that address unfulfilled lower-level needs get priority boosts.
 */

import * as db from "../db";
import { getMostCriticalNeed, assessUserNeeds } from "./needAssessmentEngine";

export interface PriorityAdjustment {
  originalPriority: "low" | "medium" | "high" | "urgent";
  adjustedPriority: "low" | "medium" | "high" | "urgent";
  reason: string;
  needCategory: string;
  fulfillmentGap: number;
  boosted: boolean;
}

/**
 * Map task types to Maslow need categories
 */
const TASK_TO_NEED_MAPPING: Record<string, number> = {
  // Physiological (level 1)
  health: 1,
  sleep: 1,
  food: 1,
  
  // Safety (level 2)
  finance: 2,
  security: 2,
  insurance: 2,
  
  // Love & Belonging (level 3)
  communication: 3,
  social: 3,
  family: 3,
  
  // Esteem (level 4)
  career: 4,
  achievement: 4,
  recognition: 4,
  
  // Self-Actualization (level 5)
  research: 5,
  learning: 5,
  creative: 5,
  personal_growth: 5,
};

/**
 * Priority levels in order
 */
const PRIORITY_LEVELS = ["low", "medium", "high", "urgent"] as const;

/**
 * Adjust task priority based on user's need fulfillment
 */
export async function adjustTaskPriority(
  userId: number,
  taskType: string,
  originalPriority: "low" | "medium" | "high" | "urgent"
): Promise<PriorityAdjustment> {
  // Get user's current need assessments
  const assessments = await assessUserNeeds(userId);
  
  // Determine which need category this task addresses
  const needLevel = TASK_TO_NEED_MAPPING[taskType] || 3; // Default to Love & Belonging
  const relevantNeed = assessments.find(a => a.level === needLevel);
  
  if (!relevantNeed) {
    // No assessment available, return original priority
    return {
      originalPriority,
      adjustedPriority: originalPriority,
      reason: "No need assessment available",
      needCategory: "Unknown",
      fulfillmentGap: 0,
      boosted: false,
    };
  }
  
  const fulfillmentGap = 100 - relevantNeed.fulfillmentLevel;
  let adjustedPriority = originalPriority;
  let boosted = false;
  let reason = "";
  
  // Critical unfulfillment (< 30%) - boost by 2 levels
  if (relevantNeed.fulfillmentLevel < 30) {
    adjustedPriority = boostPriority(originalPriority, 2);
    boosted = adjustedPriority !== originalPriority;
    reason = `Critical ${relevantNeed.categoryName} need (${relevantNeed.fulfillmentLevel.toFixed(0)}% fulfilled). Boosted by 2 levels.`;
  }
  // Significant unfulfillment (< 50%) - boost by 1 level
  else if (relevantNeed.fulfillmentLevel < 50) {
    adjustedPriority = boostPriority(originalPriority, 1);
    boosted = adjustedPriority !== originalPriority;
    reason = `Low ${relevantNeed.categoryName} need (${relevantNeed.fulfillmentLevel.toFixed(0)}% fulfilled). Boosted by 1 level.`;
  }
  // Moderate unfulfillment (< 70%) for lower-level needs - boost by 1 level
  else if (relevantNeed.fulfillmentLevel < 70 && relevantNeed.level <= 2) {
    adjustedPriority = boostPriority(originalPriority, 1);
    boosted = adjustedPriority !== originalPriority;
    reason = `Foundation need (${relevantNeed.categoryName}) at ${relevantNeed.fulfillmentLevel.toFixed(0)}%. Boosted by 1 level.`;
  }
  // Well-fulfilled - no boost
  else {
    reason = `${relevantNeed.categoryName} need well-fulfilled (${relevantNeed.fulfillmentLevel.toFixed(0)}%). No boost needed.`;
  }
  
  return {
    originalPriority,
    adjustedPriority,
    reason,
    needCategory: relevantNeed.categoryName,
    fulfillmentGap,
    boosted,
  };
}

/**
 * Boost priority by specified levels
 */
function boostPriority(
  current: "low" | "medium" | "high" | "urgent",
  levels: number
): "low" | "medium" | "high" | "urgent" {
  const currentIndex = PRIORITY_LEVELS.indexOf(current);
  const newIndex = Math.min(currentIndex + levels, PRIORITY_LEVELS.length - 1);
  return PRIORITY_LEVELS[newIndex];
}

/**
 * Get recommended task type based on most critical unfulfilled need
 */
export async function getRecommendedTaskType(userId: number): Promise<{
  taskType: string;
  needCategory: string;
  reason: string;
  fulfillmentLevel: number;
} | null> {
  const criticalNeed = await getMostCriticalNeed(userId);
  
  if (!criticalNeed) {
    return null; // All needs well-fulfilled
  }
  
  // Map need level to recommended task type
  const taskTypeMap: Record<number, string> = {
    1: "health", // Physiological
    2: "finance", // Safety
    3: "communication", // Love & Belonging
    4: "career", // Esteem
    5: "research", // Self-Actualization
  };
  
  const taskType = taskTypeMap[criticalNeed.level] || "automation";
  
  return {
    taskType,
    needCategory: criticalNeed.categoryName,
    reason: criticalNeed.insights,
    fulfillmentLevel: criticalNeed.fulfillmentLevel,
  };
}

/**
 * Determine if a task should be escalated based on need urgency
 */
export async function shouldEscalateTask(
  userId: number,
  taskType: string
): Promise<{
  shouldEscalate: boolean;
  reason: string;
  urgencyLevel: "normal" | "elevated" | "critical";
}> {
  const assessments = await assessUserNeeds(userId);
  const needLevel = TASK_TO_NEED_MAPPING[taskType] || 3;
  const relevantNeed = assessments.find(a => a.level === needLevel);
  
  if (!relevantNeed) {
    return {
      shouldEscalate: false,
      reason: "No assessment available",
      urgencyLevel: "normal",
    };
  }
  
  // Critical unfulfillment (< 30%)
  if (relevantNeed.fulfillmentLevel < 30) {
    return {
      shouldEscalate: true,
      reason: `Critical ${relevantNeed.categoryName} need at ${relevantNeed.fulfillmentLevel.toFixed(0)}%. Immediate action required.`,
      urgencyLevel: "critical",
    };
  }
  
  // Significant unfulfillment (< 50%) for foundation needs
  if (relevantNeed.fulfillmentLevel < 50 && relevantNeed.level <= 2) {
    return {
      shouldEscalate: true,
      reason: `Foundation need (${relevantNeed.categoryName}) significantly unfulfilled at ${relevantNeed.fulfillmentLevel.toFixed(0)}%.`,
      urgencyLevel: "elevated",
    };
  }
  
  return {
    shouldEscalate: false,
    reason: `${relevantNeed.categoryName} need at acceptable level (${relevantNeed.fulfillmentLevel.toFixed(0)}%)`,
    urgencyLevel: "normal",
  };
}

/**
 * Route task to appropriate engine based on need category
 */
export async function routeTaskByNeed(
  userId: number,
  taskType: string
): Promise<{
  recommendedEngine: string;
  reason: string;
  needContext: string;
}> {
  const assessments = await assessUserNeeds(userId);
  const needLevel = TASK_TO_NEED_MAPPING[taskType] || 3;
  const relevantNeed = assessments.find(a => a.level === needLevel);
  
  // Engine routing based on need level and task type
  const engineMap: Record<string, string> = {
    health: "Task Orchestration Engine",
    sleep: "Task Orchestration Engine",
    finance: "Decision Engine",
    security: "Policy Engine",
    communication: "Communication Engine",
    social: "Communication Engine",
    career: "Task Orchestration Engine",
    research: "Frontier Engine",
    learning: "Self-Model Engine",
    creative: "Frontier Engine",
  };
  
  const recommendedEngine = engineMap[taskType] || "Task Orchestration Engine";
  
  const needContext = relevantNeed
    ? `${relevantNeed.categoryName} need at ${relevantNeed.fulfillmentLevel.toFixed(0)}% fulfillment`
    : "No specific need context";
  
  const reason = relevantNeed && relevantNeed.fulfillmentLevel < 70
    ? `Routed to ${recommendedEngine} to address unfulfilled ${relevantNeed.categoryName} need`
    : `Standard routing to ${recommendedEngine} for ${taskType} tasks`;
  
  return {
    recommendedEngine,
    reason,
    needContext,
  };
}

/**
 * Record priority adjustment in database
 */
export async function recordPriorityAdjustment(
  taskId: number,
  adjustment: PriorityAdjustment,
  categoryId: number
): Promise<void> {
  await db.createNeedBasedAdjustment({
    taskId,
    categoryId,
    originalPriority: adjustment.originalPriority,
    adjustedPriority: adjustment.adjustedPriority,
    reason: adjustment.reason,
    fulfillmentGap: adjustment.fulfillmentGap.toString(),
  });
  
  // Log event
  await db.logEvent({
    eventType: "task_priority_adjusted",
    direction: "system",
    sourceEngine: "Need Priority Adjuster",
    entityType: "task",
    entityId: taskId,
    payload: {
      originalPriority: adjustment.originalPriority,
      adjustedPriority: adjustment.adjustedPriority,
      needCategory: adjustment.needCategory,
      fulfillmentGap: adjustment.fulfillmentGap,
      boosted: adjustment.boosted,
    },
    metadata: {
      reason: adjustment.reason,
    },
  });
}
