/**
 * Autonomous Task Generation (#54)
 * 
 * Creates tasks from emails, calendar events, and other sources proactively.
 * Uses AI to identify action items and create tasks automatically.
 * 
 * Features:
 * - Email action item extraction
 * - Calendar-based task creation
 * - Deadline detection and assignment
 * - Priority inference
 * - Zero human intervention required
 */

import { invokeLLM } from '../../_core/llm';

interface GeneratedTask {
  id: string;
  title: string;
  description: string;
  source: 'email' | 'calendar' | 'document' | 'conversation' | 'system';
  sourceId: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  deadline?: Date;
  assignee?: string;
  tags: string[];
  status: 'pending' | 'created' | 'rejected';
  confidence: number;
  createdAt: Date;
}

interface TaskExtractionResult {
  tasks: GeneratedTask[];
  sourceAnalysis: {
    hasActionItems: boolean;
    urgencyLevel: number;
    keyTopics: string[];
  };
}

export class AutonomousTaskGeneration {
  private userId: number;
  private generatedTasks: Map<string, GeneratedTask> = new Map();
  private config: {
    minConfidence: number;
    autoCreateThreshold: number;
    defaultPriority: GeneratedTask['priority'];
    maxTasksPerSource: number;
  };

  constructor(userId: number) {
    this.userId = userId;
    this.config = {
      minConfidence: 0.6,
      autoCreateThreshold: 0.8,
      defaultPriority: 'medium',
      maxTasksPerSource: 5,
    };
  }

  /**
   * Extract tasks from email content
   */
  async extractFromEmail(email: { id: string; from: string; subject: string; body: string; receivedAt: Date }): Promise<TaskExtractionResult> {
    try {
      const response = await invokeLLM({
        messages: [
          {
            role: 'system',
            content: `You are a task extraction AI. Analyze emails and extract action items.
            
            Return JSON:
            {
              "tasks": [
                {
                  "title": "Brief task title",
                  "description": "Task details",
                  "priority": "low|medium|high|critical",
                  "deadline": "ISO date string or null",
                  "confidence": 0.0-1.0
                }
              ],
              "hasActionItems": true/false,
              "urgencyLevel": 1-10,
              "keyTopics": ["topic1", "topic2"]
            }
            
            Look for:
            - Direct requests ("Please do X", "Can you Y")
            - Deadlines ("by Friday", "before the meeting")
            - Follow-up items ("Let me know", "Get back to me")
            - Commitments made ("I will", "I'll send")
            - Questions requiring response`
          },
          {
            role: 'user',
            content: `From: ${email.from}
Subject: ${email.subject}
Body: ${email.body}
Received: ${email.receivedAt.toISOString()}`
          }
        ],
        response_format: { type: 'json_object' },
      });

      const result = JSON.parse(response.choices[0]?.message?.content || '{}');
      
      const tasks: GeneratedTask[] = (result.tasks || []).slice(0, this.config.maxTasksPerSource).map((t: any) => ({
        id: `task_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        title: t.title,
        description: t.description,
        source: 'email' as const,
        sourceId: email.id,
        priority: t.priority || this.config.defaultPriority,
        deadline: t.deadline ? new Date(t.deadline) : undefined,
        tags: result.keyTopics || [],
        status: 'pending' as const,
        confidence: t.confidence || 0.7,
        createdAt: new Date(),
      }));

      // Auto-create high confidence tasks
      for (const task of tasks) {
        if (task.confidence >= this.config.autoCreateThreshold) {
          task.status = 'created';
          this.generatedTasks.set(task.id, task);
          console.log(`[TaskGen] Auto-created task: ${task.title} (confidence: ${task.confidence})`);
        } else if (task.confidence >= this.config.minConfidence) {
          this.generatedTasks.set(task.id, task);
        }
      }

      return {
        tasks,
        sourceAnalysis: {
          hasActionItems: result.hasActionItems ?? tasks.length > 0,
          urgencyLevel: result.urgencyLevel || 5,
          keyTopics: result.keyTopics || [],
        },
      };
    } catch (error) {
      return {
        tasks: [],
        sourceAnalysis: { hasActionItems: false, urgencyLevel: 0, keyTopics: [] },
      };
    }
  }

  /**
   * Extract tasks from calendar event
   */
  async extractFromCalendar(event: { id: string; title: string; description?: string; startTime: Date; attendees: string[] }): Promise<TaskExtractionResult> {
    const tasks: GeneratedTask[] = [];
    
    // Pre-meeting preparation task
    const prepTask: GeneratedTask = {
      id: `task_${Date.now()}_prep`,
      title: `Prepare for: ${event.title}`,
      description: `Review materials and prepare for the meeting "${event.title}"`,
      source: 'calendar',
      sourceId: event.id,
      priority: 'medium',
      deadline: new Date(event.startTime.getTime() - 30 * 60 * 1000), // 30 min before
      tags: ['meeting-prep'],
      status: 'created',
      confidence: 0.85,
      createdAt: new Date(),
    };
    tasks.push(prepTask);
    this.generatedTasks.set(prepTask.id, prepTask);

    // Post-meeting follow-up task
    const followUpTask: GeneratedTask = {
      id: `task_${Date.now()}_followup`,
      title: `Follow up: ${event.title}`,
      description: `Send meeting notes and action items from "${event.title}"`,
      source: 'calendar',
      sourceId: event.id,
      priority: 'medium',
      deadline: new Date(event.startTime.getTime() + 24 * 60 * 60 * 1000), // 24 hours after
      tags: ['meeting-followup'],
      status: 'created',
      confidence: 0.8,
      createdAt: new Date(),
    };
    tasks.push(followUpTask);
    this.generatedTasks.set(followUpTask.id, followUpTask);

    return {
      tasks,
      sourceAnalysis: {
        hasActionItems: true,
        urgencyLevel: 6,
        keyTopics: ['meeting', event.title.toLowerCase()],
      },
    };
  }

  /**
   * Extract tasks from document content
   */
  async extractFromDocument(doc: { id: string; title: string; content: string; type: string }): Promise<TaskExtractionResult> {
    try {
      const response = await invokeLLM({
        messages: [
          {
            role: 'system',
            content: `Extract action items from this document. Return JSON:
            {
              "tasks": [{ "title": "...", "description": "...", "priority": "...", "deadline": null, "confidence": 0.0-1.0 }],
              "hasActionItems": true/false,
              "keyTopics": []
            }`
          },
          {
            role: 'user',
            content: `Document: ${doc.title}\nType: ${doc.type}\nContent: ${doc.content.substring(0, 2000)}`
          }
        ],
        response_format: { type: 'json_object' },
      });

      const result = JSON.parse(response.choices[0]?.message?.content || '{}');
      
      const tasks: GeneratedTask[] = (result.tasks || []).slice(0, this.config.maxTasksPerSource).map((t: any) => ({
        id: `task_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        title: t.title,
        description: t.description,
        source: 'document' as const,
        sourceId: doc.id,
        priority: t.priority || this.config.defaultPriority,
        deadline: t.deadline ? new Date(t.deadline) : undefined,
        tags: result.keyTopics || [],
        status: t.confidence >= this.config.autoCreateThreshold ? 'created' : 'pending',
        confidence: t.confidence || 0.7,
        createdAt: new Date(),
      }));

      for (const task of tasks) {
        if (task.confidence >= this.config.minConfidence) {
          this.generatedTasks.set(task.id, task);
        }
      }

      return {
        tasks,
        sourceAnalysis: {
          hasActionItems: result.hasActionItems ?? tasks.length > 0,
          urgencyLevel: 5,
          keyTopics: result.keyTopics || [],
        },
      };
    } catch {
      return { tasks: [], sourceAnalysis: { hasActionItems: false, urgencyLevel: 0, keyTopics: [] } };
    }
  }

  /**
   * Get all generated tasks
   */
  getTasks(filter?: { status?: GeneratedTask['status']; source?: GeneratedTask['source'] }): GeneratedTask[] {
    let tasks = Array.from(this.generatedTasks.values());
    
    if (filter?.status) {
      tasks = tasks.filter(t => t.status === filter.status);
    }
    if (filter?.source) {
      tasks = tasks.filter(t => t.source === filter.source);
    }
    
    return tasks.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  /**
   * Approve a pending task
   */
  approveTask(taskId: string): boolean {
    const task = this.generatedTasks.get(taskId);
    if (task && task.status === 'pending') {
      task.status = 'created';
      return true;
    }
    return false;
  }

  /**
   * Reject a pending task
   */
  rejectTask(taskId: string): boolean {
    const task = this.generatedTasks.get(taskId);
    if (task) {
      task.status = 'rejected';
      return true;
    }
    return false;
  }

  /**
   * Get statistics
   */
  getStats(): { total: number; created: number; pending: number; rejected: number; bySource: Record<string, number> } {
    const tasks = Array.from(this.generatedTasks.values());
    const bySource: Record<string, number> = {};
    
    for (const task of tasks) {
      bySource[task.source] = (bySource[task.source] || 0) + 1;
    }

    return {
      total: tasks.length,
      created: tasks.filter(t => t.status === 'created').length,
      pending: tasks.filter(t => t.status === 'pending').length,
      rejected: tasks.filter(t => t.status === 'rejected').length,
      bySource,
    };
  }
}

// Singleton instances
const taskGenInstances = new Map<number, AutonomousTaskGeneration>();

export function getTaskGenerator(userId: number): AutonomousTaskGeneration {
  if (!taskGenInstances.has(userId)) {
    taskGenInstances.set(userId, new AutonomousTaskGeneration(userId));
  }
  return taskGenInstances.get(userId)!;
}
