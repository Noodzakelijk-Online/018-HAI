/**
 * Adaptive Threat Detection (#86)
 * 
 * Detects and responds to security threats automatically without human intervention.
 * Uses AI to identify anomalies and take protective actions.
 * 
 * Features:
 * - Real-time anomaly detection
 * - Automatic threat response
 * - Self-learning threat patterns
 * - Automatic IP blocking
 * - Zero human approval for responses
 */

interface ThreatEvent {
  id: string;
  type: 'brute_force' | 'injection' | 'anomaly' | 'data_exfiltration' | 'privilege_escalation' | 'ddos' | 'malware';
  severity: 'low' | 'medium' | 'high' | 'critical';
  source: string; // IP or identifier
  target: string; // Resource being targeted
  timestamp: Date;
  details: Record<string, any>;
  status: 'detected' | 'mitigating' | 'mitigated' | 'escalated';
  response?: ThreatResponse;
}

interface ThreatResponse {
  action: 'block_ip' | 'rate_limit' | 'require_2fa' | 'terminate_session' | 'alert_admin' | 'quarantine';
  automated: boolean;
  timestamp: Date;
  success: boolean;
  details: string;
}

interface SecurityMetrics {
  totalThreats: number;
  threatsBlocked: number;
  falsePositives: number;
  avgResponseTime: number;
  threatsByType: Record<string, number>;
  threatsBySeverity: Record<string, number>;
}

interface AnomalyPattern {
  id: string;
  pattern: string;
  frequency: number;
  lastSeen: Date;
  isThreat: boolean;
  confidence: number;
}

export class AdaptiveThreatDetection {
  private userId: number;
  private threats: Map<string, ThreatEvent> = new Map();
  private blockedIPs: Set<string> = new Set();
  private rateLimitedIPs: Map<string, { count: number; resetAt: Date }> = new Map();
  private anomalyPatterns: Map<string, AnomalyPattern> = new Map();
  private metrics: SecurityMetrics;
  private config: {
    maxLoginAttempts: number;
    rateLimitWindow: number; // seconds
    rateLimitMax: number;
    autoBlockThreshold: number;
    anomalyThreshold: number;
  };

  constructor(userId: number) {
    this.userId = userId;
    this.metrics = {
      totalThreats: 0,
      threatsBlocked: 0,
      falsePositives: 0,
      avgResponseTime: 0,
      threatsByType: {},
      threatsBySeverity: {},
    };
    this.config = {
      maxLoginAttempts: 5,
      rateLimitWindow: 60,
      rateLimitMax: 100,
      autoBlockThreshold: 3,
      anomalyThreshold: 0.8,
    };
  }

  /**
   * Analyze request for threats
   */
  async analyzeRequest(request: {
    ip: string;
    path: string;
    method: string;
    headers: Record<string, string>;
    body?: any;
    userId?: number;
  }): Promise<{ safe: boolean; threat?: ThreatEvent }> {
    const startTime = Date.now();

    // Check if IP is blocked
    if (this.blockedIPs.has(request.ip)) {
      return { safe: false, threat: this.createThreat('anomaly', 'high', request.ip, request.path, { reason: 'Blocked IP' }) };
    }

    // Check rate limiting
    const rateLimited = this.checkRateLimit(request.ip);
    if (rateLimited) {
      const threat = await this.handleThreat(
        this.createThreat('ddos', 'medium', request.ip, request.path, { reason: 'Rate limit exceeded' })
      );
      return { safe: false, threat };
    }

    // Check for injection attacks
    const injectionThreat = this.detectInjection(request);
    if (injectionThreat) {
      const threat = await this.handleThreat(injectionThreat);
      return { safe: false, threat };
    }

    // Check for anomalies
    const anomalyThreat = await this.detectAnomaly(request);
    if (anomalyThreat) {
      const threat = await this.handleThreat(anomalyThreat);
      return { safe: false, threat };
    }

    // Update metrics
    this.updateResponseTime(Date.now() - startTime);

    return { safe: true };
  }

  /**
   * Check and update rate limiting
   */
  private checkRateLimit(ip: string): boolean {
    const now = new Date();
    const limit = this.rateLimitedIPs.get(ip);

    if (limit) {
      if (now > limit.resetAt) {
        // Reset window
        this.rateLimitedIPs.set(ip, { count: 1, resetAt: new Date(now.getTime() + this.config.rateLimitWindow * 1000) });
        return false;
      }
      
      limit.count++;
      if (limit.count > this.config.rateLimitMax) {
        return true;
      }
    } else {
      this.rateLimitedIPs.set(ip, { count: 1, resetAt: new Date(now.getTime() + this.config.rateLimitWindow * 1000) });
    }

    return false;
  }

  /**
   * Detect injection attacks
   */
  private detectInjection(request: { path: string; body?: any; headers: Record<string, string> }): ThreatEvent | null {
    const injectionPatterns = [
      /(\%27)|(\')|(\-\-)|(\%23)|(#)/i, // SQL injection
      /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, // XSS
      /\.\.\//g, // Path traversal
      /\$\{.*\}/g, // Template injection
      /\{\{.*\}\}/g, // Template injection
    ];

    const checkString = (str: string): boolean => {
      return injectionPatterns.some(pattern => pattern.test(str));
    };

    // Check path
    if (checkString(request.path)) {
      return this.createThreat('injection', 'high', 'unknown', request.path, { type: 'path_injection' });
    }

    // Check body
    if (request.body) {
      const bodyStr = typeof request.body === 'string' ? request.body : JSON.stringify(request.body);
      if (checkString(bodyStr)) {
        return this.createThreat('injection', 'critical', 'unknown', request.path, { type: 'body_injection' });
      }
    }

    // Check headers
    for (const [key, value] of Object.entries(request.headers)) {
      if (checkString(value)) {
        return this.createThreat('injection', 'high', 'unknown', request.path, { type: 'header_injection', header: key });
      }
    }

    return null;
  }

  /**
   * Detect anomalous behavior
   */
  private async detectAnomaly(request: { ip: string; path: string; method: string; userId?: number }): Promise<ThreatEvent | null> {
    // Create pattern signature
    const patternKey = `${request.ip}_${request.method}_${request.path.split('/').slice(0, 3).join('/')}`;
    
    const pattern = this.anomalyPatterns.get(patternKey);
    
    if (pattern) {
      pattern.frequency++;
      pattern.lastSeen = new Date();
      
      // Check if frequency is anomalous
      if (pattern.frequency > 100 && !pattern.isThreat) {
        // High frequency from same source - potential threat
        pattern.isThreat = true;
        pattern.confidence = 0.7;
        
        return this.createThreat('anomaly', 'medium', request.ip, request.path, { 
          reason: 'Unusual request frequency',
          frequency: pattern.frequency,
        });
      }
    } else {
      this.anomalyPatterns.set(patternKey, {
        id: patternKey,
        pattern: patternKey,
        frequency: 1,
        lastSeen: new Date(),
        isThreat: false,
        confidence: 0,
      });
    }

    return null;
  }

  /**
   * Create threat event
   */
  private createThreat(
    type: ThreatEvent['type'],
    severity: ThreatEvent['severity'],
    source: string,
    target: string,
    details: Record<string, any>
  ): ThreatEvent {
    return {
      id: `threat_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type,
      severity,
      source,
      target,
      timestamp: new Date(),
      details,
      status: 'detected',
    };
  }

  /**
   * Handle detected threat
   */
  private async handleThreat(threat: ThreatEvent): Promise<ThreatEvent> {
    this.threats.set(threat.id, threat);
    this.metrics.totalThreats++;
    this.metrics.threatsByType[threat.type] = (this.metrics.threatsByType[threat.type] || 0) + 1;
    this.metrics.threatsBySeverity[threat.severity] = (this.metrics.threatsBySeverity[threat.severity] || 0) + 1;

    threat.status = 'mitigating';

    // Determine response based on severity
    const response = await this.determineResponse(threat);
    threat.response = response;

    if (response.success) {
      threat.status = 'mitigated';
      this.metrics.threatsBlocked++;
    } else {
      threat.status = 'escalated';
    }

    console.log(`[ThreatDetection] ${threat.type} threat from ${threat.source}: ${response.action} (${response.success ? 'success' : 'failed'})`);

    return threat;
  }

  /**
   * Determine appropriate response to threat
   */
  private async determineResponse(threat: ThreatEvent): Promise<ThreatResponse> {
    let action: ThreatResponse['action'];
    let success = true;

    switch (threat.severity) {
      case 'critical':
        action = 'block_ip';
        this.blockedIPs.add(threat.source);
        break;
      case 'high':
        // Check if this IP has multiple threats
        const ipThreats = Array.from(this.threats.values()).filter(t => t.source === threat.source);
        if (ipThreats.length >= this.config.autoBlockThreshold) {
          action = 'block_ip';
          this.blockedIPs.add(threat.source);
        } else {
          action = 'rate_limit';
          this.rateLimitedIPs.set(threat.source, { count: this.config.rateLimitMax, resetAt: new Date(Date.now() + 3600000) });
        }
        break;
      case 'medium':
        action = 'rate_limit';
        const current = this.rateLimitedIPs.get(threat.source);
        if (current) {
          current.count = Math.min(current.count + 50, this.config.rateLimitMax);
        } else {
          this.rateLimitedIPs.set(threat.source, { count: 50, resetAt: new Date(Date.now() + 300000) });
        }
        break;
      default:
        action = 'alert_admin';
    }

    return {
      action,
      automated: true,
      timestamp: new Date(),
      success,
      details: `Automated response to ${threat.type} threat`,
    };
  }

  /**
   * Update average response time
   */
  private updateResponseTime(time: number): void {
    const total = this.metrics.avgResponseTime * this.metrics.totalThreats + time;
    this.metrics.avgResponseTime = total / (this.metrics.totalThreats + 1);
  }

  /**
   * Record login attempt
   */
  async recordLoginAttempt(ip: string, userId: string, success: boolean): Promise<{ blocked: boolean; threat?: ThreatEvent }> {
    if (success) {
      return { blocked: false };
    }

    // Track failed attempts
    const key = `login_${ip}_${userId}`;
    const pattern = this.anomalyPatterns.get(key);
    
    if (pattern) {
      pattern.frequency++;
      
      if (pattern.frequency >= this.config.maxLoginAttempts) {
        const threat = await this.handleThreat(
          this.createThreat('brute_force', 'high', ip, `user:${userId}`, { 
            attempts: pattern.frequency,
            reason: 'Multiple failed login attempts',
          })
        );
        return { blocked: true, threat };
      }
    } else {
      this.anomalyPatterns.set(key, {
        id: key,
        pattern: key,
        frequency: 1,
        lastSeen: new Date(),
        isThreat: false,
        confidence: 0,
      });
    }

    return { blocked: false };
  }

  /**
   * Unblock IP address
   */
  unblockIP(ip: string): boolean {
    return this.blockedIPs.delete(ip);
  }

  /**
   * Get security report
   */
  getSecurityReport(): {
    metrics: SecurityMetrics;
    blockedIPs: string[];
    recentThreats: ThreatEvent[];
    topThreats: { type: string; count: number }[];
  } {
    const recentThreats = Array.from(this.threats.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, 20);

    const topThreats = Object.entries(this.metrics.threatsByType)
      .map(([type, count]) => ({ type, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    return {
      metrics: { ...this.metrics },
      blockedIPs: Array.from(this.blockedIPs),
      recentThreats,
      topThreats,
    };
  }

  /**
   * Learn from false positive
   */
  markFalsePositive(threatId: string): void {
    const threat = this.threats.get(threatId);
    if (threat) {
      this.metrics.falsePositives++;
      
      // Unblock if was blocked
      if (threat.response?.action === 'block_ip') {
        this.blockedIPs.delete(threat.source);
      }
      
      // Update pattern confidence
      const patternKey = `${threat.source}_${threat.target}`;
      const pattern = this.anomalyPatterns.get(patternKey);
      if (pattern) {
        pattern.isThreat = false;
        pattern.confidence *= 0.5;
      }
    }
  }

  /**
   * Run cleanup cycle
   */
  runCleanup(): { expiredPatterns: number; expiredRateLimits: number } {
    const now = new Date();
    let expiredPatterns = 0;
    let expiredRateLimits = 0;

    // Clean old patterns
    for (const [key, pattern] of this.anomalyPatterns) {
      const age = now.getTime() - pattern.lastSeen.getTime();
      if (age > 24 * 60 * 60 * 1000) { // 24 hours
        this.anomalyPatterns.delete(key);
        expiredPatterns++;
      }
    }

    // Clean expired rate limits
    for (const [ip, limit] of this.rateLimitedIPs) {
      if (now > limit.resetAt) {
        this.rateLimitedIPs.delete(ip);
        expiredRateLimits++;
      }
    }

    return { expiredPatterns, expiredRateLimits };
  }
}

// Singleton instances per user
const detectionInstances = new Map<number, AdaptiveThreatDetection>();

export function getThreatDetection(userId: number): AdaptiveThreatDetection {
  if (!detectionInstances.has(userId)) {
    detectionInstances.set(userId, new AdaptiveThreatDetection(userId));
  }
  return detectionInstances.get(userId)!;
}
