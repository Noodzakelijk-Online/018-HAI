/**
 * Service Metrics Store
 * 
 * Stores and retrieves historical metrics for autonomous services.
 * Enables tracking performance over time and identifying trends.
 */

export interface ServiceMetric {
  id: string;
  serviceId: string;
  serviceName: string;
  timestamp: Date;
  metricType: 'execution' | 'performance' | 'error' | 'success' | 'cost_savings';
  value: number;
  unit: string;
  metadata?: Record<string, any>;
}

export interface MetricsSummary {
  serviceId: string;
  serviceName: string;
  totalExecutions: number;
  successRate: number;
  avgExecutionTime: number;
  totalErrors: number;
  totalCostSavings: number;
  trend: 'improving' | 'stable' | 'declining';
  lastUpdated: Date;
}

export interface MetricsQuery {
  serviceId?: string;
  metricType?: string;
  startDate?: Date;
  endDate?: Date;
  limit?: number;
}

class ServiceMetricsStore {
  private metrics: ServiceMetric[] = [];
  private maxMetrics: number = 10000; // Keep last 10k metrics in memory
  private summaryCache: Map<string, MetricsSummary> = new Map();

  constructor() {
    // Initialize with some baseline metrics
    this.initializeBaselineMetrics();
  }

  private initializeBaselineMetrics(): void {
    const services = [
      { id: 'email-management', name: 'Autonomous Email Management' },
      { id: 'threat-detection', name: 'Adaptive Threat Detection' },
      { id: 'calendar-optimization', name: 'Proactive Calendar Management' },
      { id: 'cost-optimization', name: 'Self-Optimizing Costs' },
      { id: 'model-improvement', name: 'Continuous Model Improvement' },
      { id: 'connector-discovery', name: 'Self-Configuring Connectors' },
    ];

    // Generate historical metrics for the past 24 hours
    const now = Date.now();
    const hourMs = 60 * 60 * 1000;

    services.forEach(service => {
      for (let i = 24; i >= 0; i--) {
        const timestamp = new Date(now - i * hourMs);
        
        // Execution metric
        this.addMetric({
          serviceId: service.id,
          serviceName: service.name,
          metricType: 'execution',
          value: Math.floor(Math.random() * 10) + 1,
          unit: 'count',
          timestamp,
        });

        // Performance metric (execution time)
        this.addMetric({
          serviceId: service.id,
          serviceName: service.name,
          metricType: 'performance',
          value: Math.floor(Math.random() * 500) + 50,
          unit: 'ms',
          timestamp,
        });

        // Success rate
        this.addMetric({
          serviceId: service.id,
          serviceName: service.name,
          metricType: 'success',
          value: 85 + Math.random() * 15,
          unit: 'percent',
          timestamp,
        });

        // Cost savings (only for cost-optimization service)
        if (service.id === 'cost-optimization') {
          this.addMetric({
            serviceId: service.id,
            serviceName: service.name,
            metricType: 'cost_savings',
            value: Math.floor(Math.random() * 100) + 10,
            unit: 'USD',
            timestamp,
          });
        }
      }
    });
  }

  addMetric(metric: Omit<ServiceMetric, 'id'>): ServiceMetric {
    const newMetric: ServiceMetric = {
      ...metric,
      id: `metric_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: metric.timestamp || new Date(),
    };

    this.metrics.push(newMetric);

    // Trim old metrics if we exceed max
    if (this.metrics.length > this.maxMetrics) {
      this.metrics = this.metrics.slice(-this.maxMetrics);
    }

    // Invalidate summary cache for this service
    this.summaryCache.delete(metric.serviceId);

    return newMetric;
  }

  getMetrics(query: MetricsQuery = {}): ServiceMetric[] {
    let result = [...this.metrics];

    if (query.serviceId) {
      result = result.filter(m => m.serviceId === query.serviceId);
    }

    if (query.metricType) {
      result = result.filter(m => m.metricType === query.metricType);
    }

    if (query.startDate) {
      result = result.filter(m => m.timestamp >= query.startDate!);
    }

    if (query.endDate) {
      result = result.filter(m => m.timestamp <= query.endDate!);
    }

    // Sort by timestamp descending
    result.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

    if (query.limit) {
      result = result.slice(0, query.limit);
    }

    return result;
  }

  getServiceSummary(serviceId: string): MetricsSummary | null {
    // Check cache first
    if (this.summaryCache.has(serviceId)) {
      return this.summaryCache.get(serviceId)!;
    }

    const serviceMetrics = this.metrics.filter(m => m.serviceId === serviceId);
    if (serviceMetrics.length === 0) return null;

    const executions = serviceMetrics.filter(m => m.metricType === 'execution');
    const performances = serviceMetrics.filter(m => m.metricType === 'performance');
    const successes = serviceMetrics.filter(m => m.metricType === 'success');
    const errors = serviceMetrics.filter(m => m.metricType === 'error');
    const costSavings = serviceMetrics.filter(m => m.metricType === 'cost_savings');

    const totalExecutions = executions.reduce((sum, m) => sum + m.value, 0);
    const avgSuccessRate = successes.length > 0
      ? successes.reduce((sum, m) => sum + m.value, 0) / successes.length
      : 100;
    const avgExecutionTime = performances.length > 0
      ? performances.reduce((sum, m) => sum + m.value, 0) / performances.length
      : 0;
    const totalErrors = errors.reduce((sum, m) => sum + m.value, 0);
    const totalSavings = costSavings.reduce((sum, m) => sum + m.value, 0);

    // Calculate trend based on recent vs older success rates
    const recentSuccesses = successes.slice(0, Math.floor(successes.length / 2));
    const olderSuccesses = successes.slice(Math.floor(successes.length / 2));
    
    const recentAvg = recentSuccesses.length > 0
      ? recentSuccesses.reduce((sum, m) => sum + m.value, 0) / recentSuccesses.length
      : 0;
    const olderAvg = olderSuccesses.length > 0
      ? olderSuccesses.reduce((sum, m) => sum + m.value, 0) / olderSuccesses.length
      : 0;

    let trend: 'improving' | 'stable' | 'declining' = 'stable';
    if (recentAvg > olderAvg + 2) trend = 'improving';
    else if (recentAvg < olderAvg - 2) trend = 'declining';

    const summary: MetricsSummary = {
      serviceId,
      serviceName: serviceMetrics[0].serviceName,
      totalExecutions,
      successRate: avgSuccessRate,
      avgExecutionTime,
      totalErrors,
      totalCostSavings: totalSavings,
      trend,
      lastUpdated: new Date(),
    };

    this.summaryCache.set(serviceId, summary);
    return summary;
  }

  getAllSummaries(): MetricsSummary[] {
    const serviceIds = [...new Set(this.metrics.map(m => m.serviceId))];
    return serviceIds
      .map(id => this.getServiceSummary(id))
      .filter((s): s is MetricsSummary => s !== null);
  }

  getMetricsTimeSeries(serviceId: string, metricType: string, hours: number = 24): { timestamp: Date; value: number }[] {
    const startDate = new Date(Date.now() - hours * 60 * 60 * 1000);
    const metrics = this.getMetrics({
      serviceId,
      metricType,
      startDate,
    });

    return metrics.map(m => ({
      timestamp: m.timestamp,
      value: m.value,
    })).reverse(); // Chronological order
  }

  recordExecution(serviceId: string, serviceName: string, executionTimeMs: number, success: boolean): void {
    this.addMetric({
      serviceId,
      serviceName,
      metricType: 'execution',
      value: 1,
      unit: 'count',
    });

    this.addMetric({
      serviceId,
      serviceName,
      metricType: 'performance',
      value: executionTimeMs,
      unit: 'ms',
    });

    this.addMetric({
      serviceId,
      serviceName,
      metricType: success ? 'success' : 'error',
      value: success ? 100 : 0,
      unit: 'percent',
    });
  }

  recordCostSavings(serviceId: string, serviceName: string, amount: number): void {
    this.addMetric({
      serviceId,
      serviceName,
      metricType: 'cost_savings',
      value: amount,
      unit: 'USD',
    });
  }

  exportMetrics(query: MetricsQuery = {}): string {
    const metrics = this.getMetrics(query);
    return JSON.stringify(metrics, null, 2);
  }

  clearMetrics(serviceId?: string): void {
    if (serviceId) {
      this.metrics = this.metrics.filter(m => m.serviceId !== serviceId);
      this.summaryCache.delete(serviceId);
    } else {
      this.metrics = [];
      this.summaryCache.clear();
    }
  }
}

// Singleton instance
let metricsStoreInstance: ServiceMetricsStore | null = null;

export function getServiceMetricsStore(): ServiceMetricsStore {
  if (!metricsStoreInstance) {
    metricsStoreInstance = new ServiceMetricsStore();
  }
  return metricsStoreInstance;
}
