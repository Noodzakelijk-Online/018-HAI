/**
 * Autonomous Framework - Main Export
 * 
 * Core infrastructure for fully autonomous operation with zero human intervention
 */

export {
  // Core Engine
  AutonomousEngine,
  autonomousEngine,
  makeAutonomousDecision,
  recordDecisionOutcome,
  getAutonomousMetrics,
  type AutonomousDecision,
  type DecisionOutcome,
  type Strategy
} from './AutonomousCore';

export {
  // Learning Pipeline
  learningPipeline,
  learnFrom,
  getLearningInsights,
  type LearningEvent,
  type Pattern
} from './LearningPipeline';

export {
  // Auto Optimizer
  autoOptimizer,
  recordOptimizationMetric,
  getOptimizationStatus,
  type OptimizationTarget,
  type OptimizationAction
} from './AutoOptimizer';

// Feature Categories
export * as Intelligence from './intelligence';
export * as Integration from './integration';
export * as Learning from './learning';
export * as Security from './security';
export * as Optimization from './optimization';

// ============================================================================
// Phase 30: Fully Autonomous Enhancements (50 services)
// Services are available in individual files:
// - P0: SelfImprovingTaskRouter, AutonomousEmailManager, ProactiveCalendarManager,
//       SelfConfiguringConnectors, ContinuousModelImprovement, AdaptiveThreatDetection,
//       SelfOptimizingCosts
// - P1: AutonomousTaskGeneration, SelfLearningPreferences, AutonomousDocumentProcessing,
//       PredictiveActionExecution, AutonomousWorkflowOrchestration, AutonomousAPIDiscovery,
//       P1Services bundle (15 services)
// - P2: P2Services bundle (20 services)
// - P3: P3Services (MeetingParticipation, HabitFormation)
// ============================================================================
