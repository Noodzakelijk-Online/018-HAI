/**
 * Self-Learning Preference Engine (#55)
 * 
 * Learns user preferences from behavior without explicit configuration.
 * Uses AI to detect patterns and adapt system behavior automatically.
 * 
 * Features:
 * - Behavior pattern detection
 * - Implicit preference learning
 * - Automatic system adaptation
 * - Preference prediction
 * - Zero explicit configuration required
 */

interface UserAction {
  id: string;
  type: string;
  target: string;
  context: Record<string, any>;
  timestamp: Date;
  duration?: number;
  outcome?: 'success' | 'failure' | 'cancelled';
}

interface LearnedPreference {
  id: string;
  category: string;
  preference: string;
  value: any;
  confidence: number;
  learnedFrom: string[];
  lastUpdated: Date;
  appliedCount: number;
}

interface BehaviorPattern {
  id: string;
  pattern: string;
  frequency: number;
  timeOfDay?: number[];
  dayOfWeek?: number[];
  context: Record<string, any>;
  confidence: number;
}

export class SelfLearningPreferences {
  private userId: number;
  private actions: UserAction[] = [];
  private preferences: Map<string, LearnedPreference> = new Map();
  private patterns: Map<string, BehaviorPattern> = new Map();
  private config: {
    minActionsForLearning: number;
    confidenceThreshold: number;
    decayFactor: number;
    maxActions: number;
  };

  constructor(userId: number) {
    this.userId = userId;
    this.config = {
      minActionsForLearning: 5,
      confidenceThreshold: 0.7,
      decayFactor: 0.95,
      maxActions: 10000,
    };

    // Initialize default preference categories
    this.initializeCategories();
  }

  private initializeCategories(): void {
    const categories = [
      'ui_theme', 'notification_timing', 'task_priority', 'communication_style',
      'meeting_times', 'focus_hours', 'response_speed', 'detail_level'
    ];
    
    for (const cat of categories) {
      this.preferences.set(cat, {
        id: cat,
        category: cat,
        preference: cat,
        value: null,
        confidence: 0,
        learnedFrom: [],
        lastUpdated: new Date(),
        appliedCount: 0,
      });
    }
  }

  /**
   * Record user action for learning
   */
  async recordAction(action: Omit<UserAction, 'id'>): Promise<void> {
    const fullAction: UserAction = {
      ...action,
      id: `action_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    };

    this.actions.push(fullAction);
    
    // Trim old actions
    if (this.actions.length > this.config.maxActions) {
      this.actions = this.actions.slice(-this.config.maxActions);
    }

    // Learn from this action
    await this.learnFromAction(fullAction);
  }

  /**
   * Learn preferences from action
   */
  private async learnFromAction(action: UserAction): Promise<void> {
    // Update patterns
    await this.updatePatterns(action);
    
    // Infer preferences
    await this.inferPreferences(action);
  }

  /**
   * Update behavior patterns
   */
  private async updatePatterns(action: UserAction): Promise<void> {
    const patternKey = `${action.type}_${action.target}`;
    const hour = action.timestamp.getHours();
    const day = action.timestamp.getDay();

    const existing = this.patterns.get(patternKey);
    
    if (existing) {
      existing.frequency++;
      existing.timeOfDay = existing.timeOfDay || [];
      existing.timeOfDay.push(hour);
      if (existing.timeOfDay.length > 100) existing.timeOfDay.shift();
      
      existing.dayOfWeek = existing.dayOfWeek || [];
      existing.dayOfWeek.push(day);
      if (existing.dayOfWeek.length > 100) existing.dayOfWeek.shift();
      
      existing.confidence = Math.min(0.99, existing.confidence + 0.01);
    } else {
      this.patterns.set(patternKey, {
        id: patternKey,
        pattern: patternKey,
        frequency: 1,
        timeOfDay: [hour],
        dayOfWeek: [day],
        context: action.context,
        confidence: 0.3,
      });
    }
  }

  /**
   * Infer preferences from action patterns
   */
  private async inferPreferences(action: UserAction): Promise<void> {
    const hour = action.timestamp.getHours();
    
    // Learn theme preference from UI interactions
    if (action.type === 'theme_change') {
      this.updatePreference('ui_theme', action.target, [action.id]);
    }

    // Learn focus hours from task completion patterns
    if (action.type === 'task_complete' && action.outcome === 'success') {
      const focusPref = this.preferences.get('focus_hours');
      if (focusPref) {
        const currentHours = focusPref.value as number[] || [];
        if (!currentHours.includes(hour)) {
          currentHours.push(hour);
          this.updatePreference('focus_hours', currentHours.slice(-5), [action.id]);
        }
      }
    }

    // Learn notification timing preferences
    if (action.type === 'notification_dismiss') {
      const notifPref = this.preferences.get('notification_timing');
      if (notifPref) {
        const badHours = notifPref.value as number[] || [];
        if (!badHours.includes(hour)) {
          badHours.push(hour);
          this.updatePreference('notification_timing', { avoid: badHours.slice(-5) }, [action.id]);
        }
      }
    }

    // Learn communication style from message patterns
    if (action.type === 'message_send') {
      const length = action.context.messageLength || 0;
      const style = length > 500 ? 'detailed' : length > 100 ? 'moderate' : 'brief';
      this.updatePreference('communication_style', style, [action.id]);
    }

    // Learn meeting time preferences
    if (action.type === 'meeting_accept') {
      const meetingPref = this.preferences.get('meeting_times');
      if (meetingPref) {
        const preferredHours = meetingPref.value as number[] || [];
        if (!preferredHours.includes(hour)) {
          preferredHours.push(hour);
          this.updatePreference('meeting_times', preferredHours.slice(-5), [action.id]);
        }
      }
    }

    // Learn response speed preference
    if (action.type === 'email_reply' && action.duration) {
      const speed = action.duration < 300000 ? 'fast' : action.duration < 3600000 ? 'moderate' : 'slow';
      this.updatePreference('response_speed', speed, [action.id]);
    }
  }

  /**
   * Update a preference
   */
  private updatePreference(category: string, value: any, sources: string[]): void {
    const pref = this.preferences.get(category);
    if (pref) {
      pref.value = value;
      pref.confidence = Math.min(0.99, pref.confidence + 0.05);
      pref.learnedFrom.push(...sources);
      if (pref.learnedFrom.length > 50) {
        pref.learnedFrom = pref.learnedFrom.slice(-50);
      }
      pref.lastUpdated = new Date();
    }
  }

  /**
   * Get preference value
   */
  getPreference(category: string): { value: any; confidence: number } | null {
    const pref = this.preferences.get(category);
    if (pref && pref.confidence >= this.config.confidenceThreshold) {
      pref.appliedCount++;
      return { value: pref.value, confidence: pref.confidence };
    }
    return null;
  }

  /**
   * Get all learned preferences
   */
  getAllPreferences(): LearnedPreference[] {
    return Array.from(this.preferences.values())
      .filter(p => p.confidence >= this.config.confidenceThreshold)
      .sort((a, b) => b.confidence - a.confidence);
  }

  /**
   * Predict user action
   */
  predictNextAction(context: { currentTime: Date; currentActivity?: string }): { action: string; confidence: number } | null {
    const hour = context.currentTime.getHours();
    const day = context.currentTime.getDay();

    // Find patterns that match current context
    let bestMatch: { pattern: BehaviorPattern; score: number } | null = null;

    for (const pattern of this.patterns.values()) {
      let score = 0;
      
      // Time match
      if (pattern.timeOfDay?.includes(hour)) {
        score += 0.3;
      }
      
      // Day match
      if (pattern.dayOfWeek?.includes(day)) {
        score += 0.2;
      }
      
      // Frequency bonus
      score += Math.min(0.3, pattern.frequency / 100);
      
      // Confidence bonus
      score += pattern.confidence * 0.2;

      if (!bestMatch || score > bestMatch.score) {
        bestMatch = { pattern, score };
      }
    }

    if (bestMatch && bestMatch.score > 0.5) {
      return {
        action: bestMatch.pattern.pattern,
        confidence: bestMatch.score,
      };
    }

    return null;
  }

  /**
   * Apply decay to old preferences
   */
  applyDecay(): void {
    for (const pref of this.preferences.values()) {
      const age = Date.now() - pref.lastUpdated.getTime();
      const days = age / (24 * 60 * 60 * 1000);
      
      if (days > 7) {
        pref.confidence *= this.config.decayFactor;
      }
    }
  }

  /**
   * Get learning statistics
   */
  getStats(): {
    totalActions: number;
    patternsLearned: number;
    preferencesLearned: number;
    avgConfidence: number;
  } {
    const learnedPrefs = Array.from(this.preferences.values()).filter(p => p.confidence >= this.config.confidenceThreshold);
    const avgConfidence = learnedPrefs.length > 0
      ? learnedPrefs.reduce((sum, p) => sum + p.confidence, 0) / learnedPrefs.length
      : 0;

    return {
      totalActions: this.actions.length,
      patternsLearned: this.patterns.size,
      preferencesLearned: learnedPrefs.length,
      avgConfidence,
    };
  }
}

// Singleton instances
const prefInstances = new Map<number, SelfLearningPreferences>();

export function getPreferenceEngine(userId: number): SelfLearningPreferences {
  if (!prefInstances.has(userId)) {
    prefInstances.set(userId, new SelfLearningPreferences(userId));
  }
  return prefInstances.get(userId)!;
}
