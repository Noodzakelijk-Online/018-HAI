/**
 * Service Dependency Graph
 * 
 * Maps relationships between autonomous services and enables
 * automatic triggering of dependent services.
 */

export interface ServiceDependency {
  sourceServiceId: string;
  targetServiceId: string;
  triggerType: 'on_success' | 'on_failure' | 'on_complete' | 'scheduled';
  priority: number;
  enabled: boolean;
  metadata?: Record<string, any>;
}

export interface DependencyNode {
  serviceId: string;
  serviceName: string;
  dependencies: string[]; // Services this depends on
  dependents: string[]; // Services that depend on this
  level: number; // Execution level (0 = no dependencies)
}

export interface TriggerEvent {
  id: string;
  sourceServiceId: string;
  targetServiceId: string;
  triggerType: string;
  timestamp: Date;
  status: 'pending' | 'executing' | 'completed' | 'failed';
  result?: any;
}

class ServiceDependencyGraph {
  private dependencies: ServiceDependency[] = [];
  private triggerHistory: TriggerEvent[] = [];
  private maxHistory: number = 1000;

  constructor() {
    this.initializeDefaultDependencies();
  }

  private initializeDefaultDependencies(): void {
    // P0 Service Dependencies
    
    // Threat detection triggers security hardening on detection
    this.addDependency({
      sourceServiceId: 'threat-detection',
      targetServiceId: 'security-hardening',
      triggerType: 'on_success',
      priority: 1,
      enabled: true,
      metadata: { description: 'Harden security when threats are detected' },
    });

    // Threat detection triggers credential rotation on breach attempt
    this.addDependency({
      sourceServiceId: 'threat-detection',
      targetServiceId: 'credential-rotation',
      triggerType: 'on_success',
      priority: 2,
      enabled: true,
      metadata: { description: 'Rotate credentials after security events' },
    });

    // Cost optimization triggers capacity planning
    this.addDependency({
      sourceServiceId: 'cost-optimization',
      targetServiceId: 'capacity-planning',
      triggerType: 'on_complete',
      priority: 1,
      enabled: true,
      metadata: { description: 'Update capacity plans after cost analysis' },
    });

    // Email management triggers task generation
    this.addDependency({
      sourceServiceId: 'email-management',
      targetServiceId: 'task-generation',
      triggerType: 'on_success',
      priority: 1,
      enabled: true,
      metadata: { description: 'Generate tasks from processed emails' },
    });

    // Calendar optimization triggers preference learning
    this.addDependency({
      sourceServiceId: 'calendar-optimization',
      targetServiceId: 'preference-learning',
      triggerType: 'on_complete',
      priority: 2,
      enabled: true,
      metadata: { description: 'Learn preferences from calendar patterns' },
    });

    // Model improvement triggers all ML-based services
    this.addDependency({
      sourceServiceId: 'model-improvement',
      targetServiceId: 'predictive-execution',
      triggerType: 'on_success',
      priority: 1,
      enabled: true,
      metadata: { description: 'Update predictive models after improvement' },
    });

    // Connector discovery triggers API discovery
    this.addDependency({
      sourceServiceId: 'connector-discovery',
      targetServiceId: 'api-discovery',
      triggerType: 'on_success',
      priority: 1,
      enabled: true,
      metadata: { description: 'Discover APIs for new connectors' },
    });

    // Self-healing triggers backup on failure
    this.addDependency({
      sourceServiceId: 'self-healing',
      targetServiceId: 'backup-recovery',
      triggerType: 'on_failure',
      priority: 1,
      enabled: true,
      metadata: { description: 'Create backup when healing fails' },
    });

    // Document processing triggers workflow creation
    this.addDependency({
      sourceServiceId: 'document-processing',
      targetServiceId: 'workflow-orchestration',
      triggerType: 'on_success',
      priority: 2,
      enabled: true,
      metadata: { description: 'Create workflows from processed documents' },
    });

    // Compliance check triggers audit
    this.addDependency({
      sourceServiceId: 'compliance',
      targetServiceId: 'self-auditing',
      triggerType: 'on_complete',
      priority: 1,
      enabled: true,
      metadata: { description: 'Run audit after compliance check' },
    });
  }

  addDependency(dependency: ServiceDependency): void {
    // Check for circular dependencies
    if (this.wouldCreateCycle(dependency.sourceServiceId, dependency.targetServiceId)) {
      console.warn(`[DependencyGraph] Circular dependency detected: ${dependency.sourceServiceId} -> ${dependency.targetServiceId}`);
      return;
    }

    // Check if dependency already exists
    const existing = this.dependencies.find(
      d => d.sourceServiceId === dependency.sourceServiceId && 
           d.targetServiceId === dependency.targetServiceId
    );

    if (existing) {
      Object.assign(existing, dependency);
    } else {
      this.dependencies.push(dependency);
    }
  }

  removeDependency(sourceServiceId: string, targetServiceId: string): boolean {
    const index = this.dependencies.findIndex(
      d => d.sourceServiceId === sourceServiceId && d.targetServiceId === targetServiceId
    );

    if (index >= 0) {
      this.dependencies.splice(index, 1);
      return true;
    }
    return false;
  }

  getDependencies(serviceId: string): ServiceDependency[] {
    return this.dependencies.filter(d => d.sourceServiceId === serviceId && d.enabled);
  }

  getDependents(serviceId: string): ServiceDependency[] {
    return this.dependencies.filter(d => d.targetServiceId === serviceId && d.enabled);
  }

  getAllDependencies(): ServiceDependency[] {
    return [...this.dependencies];
  }

  private wouldCreateCycle(sourceId: string, targetId: string): boolean {
    // Check if adding this dependency would create a cycle
    const visited = new Set<string>();
    const stack = [targetId];

    while (stack.length > 0) {
      const current = stack.pop()!;
      if (current === sourceId) return true;
      if (visited.has(current)) continue;
      
      visited.add(current);
      
      const deps = this.dependencies.filter(d => d.sourceServiceId === current);
      deps.forEach(d => stack.push(d.targetServiceId));
    }

    return false;
  }

  async triggerDependents(
    sourceServiceId: string, 
    triggerType: 'on_success' | 'on_failure' | 'on_complete',
    executor: (serviceId: string) => Promise<any>
  ): Promise<TriggerEvent[]> {
    const deps = this.getDependencies(sourceServiceId)
      .filter(d => d.triggerType === triggerType)
      .sort((a, b) => a.priority - b.priority);

    const events: TriggerEvent[] = [];

    for (const dep of deps) {
      const event: TriggerEvent = {
        id: `trigger_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        sourceServiceId,
        targetServiceId: dep.targetServiceId,
        triggerType,
        timestamp: new Date(),
        status: 'pending',
      };

      events.push(event);
      this.triggerHistory.push(event);

      try {
        event.status = 'executing';
        console.log(`[DependencyGraph] Triggering ${dep.targetServiceId} from ${sourceServiceId}`);
        
        event.result = await executor(dep.targetServiceId);
        event.status = 'completed';
        
        console.log(`[DependencyGraph] Completed ${dep.targetServiceId}`);
      } catch (error) {
        event.status = 'failed';
        event.result = { error: error instanceof Error ? error.message : 'Unknown error' };
        console.error(`[DependencyGraph] Failed ${dep.targetServiceId}:`, error);
      }
    }

    // Trim history
    if (this.triggerHistory.length > this.maxHistory) {
      this.triggerHistory = this.triggerHistory.slice(-this.maxHistory);
    }

    return events;
  }

  getNode(serviceId: string): DependencyNode | null {
    const dependencies = this.dependencies
      .filter(d => d.targetServiceId === serviceId)
      .map(d => d.sourceServiceId);
    
    const dependents = this.dependencies
      .filter(d => d.sourceServiceId === serviceId)
      .map(d => d.targetServiceId);

    if (dependencies.length === 0 && dependents.length === 0) {
      return null;
    }

    // Calculate level (max level of dependencies + 1)
    const level = dependencies.length === 0 ? 0 : 
      Math.max(...dependencies.map(d => this.getNode(d)?.level || 0)) + 1;

    return {
      serviceId,
      serviceName: serviceId, // Would be resolved from service registry
      dependencies,
      dependents,
      level,
    };
  }

  getGraph(): { nodes: DependencyNode[]; edges: ServiceDependency[] } {
    const serviceIds = new Set<string>();
    this.dependencies.forEach(d => {
      serviceIds.add(d.sourceServiceId);
      serviceIds.add(d.targetServiceId);
    });

    const nodes = Array.from(serviceIds)
      .map(id => this.getNode(id))
      .filter((n): n is DependencyNode => n !== null);

    return {
      nodes,
      edges: this.dependencies,
    };
  }

  getTriggerHistory(limit: number = 100): TriggerEvent[] {
    return this.triggerHistory.slice(-limit).reverse();
  }

  enableDependency(sourceServiceId: string, targetServiceId: string): boolean {
    const dep = this.dependencies.find(
      d => d.sourceServiceId === sourceServiceId && d.targetServiceId === targetServiceId
    );
    if (dep) {
      dep.enabled = true;
      return true;
    }
    return false;
  }

  disableDependency(sourceServiceId: string, targetServiceId: string): boolean {
    const dep = this.dependencies.find(
      d => d.sourceServiceId === sourceServiceId && d.targetServiceId === targetServiceId
    );
    if (dep) {
      dep.enabled = false;
      return true;
    }
    return false;
  }
}

// Singleton instance
let dependencyGraphInstance: ServiceDependencyGraph | null = null;

export function getServiceDependencyGraph(): ServiceDependencyGraph {
  if (!dependencyGraphInstance) {
    dependencyGraphInstance = new ServiceDependencyGraph();
  }
  return dependencyGraphInstance;
}
