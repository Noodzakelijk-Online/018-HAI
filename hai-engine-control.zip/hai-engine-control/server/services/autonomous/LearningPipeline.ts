/**
 * Continuous Learning Pipeline
 * 
 * Automatically learns from all system interactions and outcomes
 * to improve decision-making without human intervention
 */

import { autonomousEngine, DecisionOutcome } from './AutonomousCore';

export interface LearningEvent {
  type: 'task_completed' | 'error_occurred' | 'user_feedback' | 'performance_metric';
  source: string;
  data: Record<string, any>;
  timestamp: Date;
}

export interface Pattern {
  id: string;
  type: string;
  description: string;
  confidence: number;
  occurrences: number;
  lastSeen: Date;
  actionable: boolean;
}

class ContinuousLearning {
  private events: LearningEvent[] = [];
  private patterns: Map<string, Pattern> = new Map();
  private learningRate = 0.1;
  
  /**
   * Ingest any system event for learning
   */
  ingest(event: LearningEvent): void {
    this.events.push(event);
    
    // Detect patterns
    this.detectPatterns();
    
    // Extract learning signals
    this.extractLearningSignals(event);
    
    // Trigger adaptation if needed
    if (this.events.length % 50 === 0) {
      this.adapt();
    }
  }
  
  /**
   * Automatically detect patterns in events
   */
  private detectPatterns(): void {
    const recentEvents = this.events.slice(-1000);
    
    // Group by type and source
    const grouped = new Map<string, LearningEvent[]>();
    
    for (const event of recentEvents) {
      const key = `${event.type}-${event.source}`;
      if (!grouped.has(key)) {
        grouped.set(key, []);
      }
      grouped.get(key)!.push(event);
    }
    
    // Detect frequent patterns
    for (const [key, events] of grouped.entries()) {
      if (events.length >= 10) {
        const pattern: Pattern = {
          id: key,
          type: events[0].type,
          description: `Frequent ${events[0].type} from ${events[0].source}`,
          confidence: Math.min(events.length / 100, 1.0),
          occurrences: events.length,
          lastSeen: events[events.length - 1].timestamp,
          actionable: this.isActionable(events)
        };
        
        this.patterns.set(key, pattern);
      }
    }
  }
  
  private isActionable(events: LearningEvent[]): boolean {
    // Pattern is actionable if it shows consistent outcomes
    if (events[0].type === 'task_completed') {
      const successes = events.filter(e => e.data.success).length;
      const successRate = successes / events.length;
      
      // Actionable if consistently successful or consistently failing
      return successRate > 0.9 || successRate < 0.3;
    }
    
    if (events[0].type === 'error_occurred') {
      // Recurring errors are actionable
      return events.length > 5;
    }
    
    return false;
  }
  
  /**
   * Extract learning signals from events
   */
  private extractLearningSignals(event: LearningEvent): void {
    switch (event.type) {
      case 'task_completed':
        this.learnFromTaskCompletion(event);
        break;
      
      case 'error_occurred':
        this.learnFromError(event);
        break;
      
      case 'performance_metric':
        this.learnFromMetrics(event);
        break;
    }
  }
  
  private learnFromTaskCompletion(event: LearningEvent): void {
    const outcome: DecisionOutcome = {
      decisionId: event.data.decisionId || `auto-${Date.now()}`,
      success: event.data.success || false,
      actualResult: event.data.result,
      metrics: {
        duration: event.data.duration || 0,
        cost: event.data.cost || 0,
        quality: event.data.quality || 0.5
      }
    };
    
    // Feed into autonomous engine
    autonomousEngine.recordOutcome(outcome);
  }
  
  private learnFromError(event: LearningEvent): void {
    // Errors are negative learning signals
    const outcome: DecisionOutcome = {
      decisionId: event.data.decisionId || `error-${Date.now()}`,
      success: false,
      actualResult: null,
      metrics: {
        duration: 0,
        cost: 0,
        quality: 0
      },
      errorMessage: event.data.error || 'Unknown error'
    };
    
    autonomousEngine.recordOutcome(outcome);
    
    // Log for error correction system
    console.log(`[LearningPipeline] Learned from error: ${event.data.error}`);
  }
  
  private learnFromMetrics(event: LearningEvent): void {
    // Performance metrics inform optimization
    console.log(`[LearningPipeline] Performance metric: ${event.source} = ${event.data.value}`);
  }
  
  /**
   * Adapt system based on learned patterns
   */
  private adapt(): void {
    console.log('[LearningPipeline] Adapting based on learned patterns...');
    
    // Find actionable patterns
    const actionablePatterns = Array.from(this.patterns.values())
      .filter(p => p.actionable)
      .sort((a, b) => b.confidence - a.confidence);
    
    for (const pattern of actionablePatterns.slice(0, 5)) {
      console.log(`[LearningPipeline] Actionable pattern detected: ${pattern.description} (confidence: ${pattern.confidence.toFixed(2)})`);
      
      // TODO: Implement automatic adaptations based on patterns
      // For now, just log them
    }
  }
  
  /**
   * Get learning insights
   */
  getInsights(): {
    totalEvents: number;
    patternsDetected: number;
    actionablePatterns: number;
    learningRate: number;
  } {
    const actionable = Array.from(this.patterns.values()).filter(p => p.actionable).length;
    
    return {
      totalEvents: this.events.length,
      patternsDetected: this.patterns.size,
      actionablePatterns: actionable,
      learningRate: this.learningRate
    };
  }
}

// Singleton instance
export const learningPipeline = new ContinuousLearning();

// Convenience functions
export function learnFrom(event: LearningEvent): void {
  learningPipeline.ingest(event);
}

export function getLearningInsights() {
  return learningPipeline.getInsights();
}
