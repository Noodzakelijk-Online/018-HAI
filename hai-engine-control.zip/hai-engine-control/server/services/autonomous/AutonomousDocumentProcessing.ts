/**
 * Autonomous Document Processing (#56)
 * 
 * Auto-processes all documents without human intervention.
 * Uses AI to classify, extract, summarize, and route documents.
 * 
 * Features:
 * - Automatic document classification
 * - Key information extraction
 * - Smart summarization
 * - Automatic routing and filing
 * - Zero human intervention required
 */

import { invokeLLM } from '../../_core/llm';

interface Document {
  id: string;
  filename: string;
  type: string;
  content: string;
  metadata: Record<string, any>;
  uploadedAt: Date;
  size: number;
}

interface ProcessedDocument {
  id: string;
  documentId: string;
  classification: {
    category: string;
    subcategory?: string;
    confidence: number;
  };
  extraction: {
    entities: { type: string; value: string; confidence: number }[];
    dates: { label: string; date: Date }[];
    amounts: { label: string; amount: number; currency: string }[];
    keyPhrases: string[];
  };
  summary: {
    brief: string;
    detailed: string;
    actionItems: string[];
  };
  routing: {
    destination: string;
    priority: 'low' | 'medium' | 'high';
    tags: string[];
  };
  processedAt: Date;
}

export class AutonomousDocumentProcessing {
  private userId: number;
  private processedDocs: Map<string, ProcessedDocument> = new Map();
  private config: {
    maxContentLength: number;
    autoRouteThreshold: number;
    categories: string[];
  };

  constructor(userId: number) {
    this.userId = userId;
    this.config = {
      maxContentLength: 10000,
      autoRouteThreshold: 0.8,
      categories: ['invoice', 'contract', 'report', 'correspondence', 'legal', 'hr', 'technical', 'marketing', 'other'],
    };
  }

  /**
   * Process a document automatically
   */
  async processDocument(doc: Document): Promise<ProcessedDocument> {
    const content = doc.content.substring(0, this.config.maxContentLength);

    // Step 1: Classify document
    const classification = await this.classifyDocument(content, doc.filename);
    
    // Step 2: Extract information
    const extraction = await this.extractInformation(content, classification.category);
    
    // Step 3: Generate summary
    const summary = await this.generateSummary(content, classification.category);
    
    // Step 4: Determine routing
    const routing = this.determineRouting(classification, extraction);

    const processed: ProcessedDocument = {
      id: `proc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      documentId: doc.id,
      classification,
      extraction,
      summary,
      routing,
      processedAt: new Date(),
    };

    this.processedDocs.set(processed.id, processed);
    
    // Auto-route if confidence is high
    if (classification.confidence >= this.config.autoRouteThreshold) {
      await this.routeDocument(processed);
    }

    console.log(`[DocProcessor] Processed ${doc.filename}: ${classification.category} (${(classification.confidence * 100).toFixed(0)}%)`);
    
    return processed;
  }

  /**
   * Classify document using AI
   */
  private async classifyDocument(content: string, filename: string): Promise<ProcessedDocument['classification']> {
    try {
      const response = await invokeLLM({
        messages: [
          {
            role: 'system',
            content: `Classify this document into one of these categories: ${this.config.categories.join(', ')}.
            
            Return JSON: { "category": "...", "subcategory": "...", "confidence": 0.0-1.0 }`
          },
          {
            role: 'user',
            content: `Filename: ${filename}\nContent: ${content.substring(0, 2000)}`
          }
        ],
        response_format: { type: 'json_object' },
      });

      const result = JSON.parse(response.choices[0]?.message?.content || '{}');
      return {
        category: result.category || 'other',
        subcategory: result.subcategory,
        confidence: result.confidence || 0.7,
      };
    } catch {
      return { category: 'other', confidence: 0.5 };
    }
  }

  /**
   * Extract information from document
   */
  private async extractInformation(content: string, category: string): Promise<ProcessedDocument['extraction']> {
    try {
      const response = await invokeLLM({
        messages: [
          {
            role: 'system',
            content: `Extract key information from this ${category} document.
            
            Return JSON:
            {
              "entities": [{ "type": "person|org|location|product", "value": "...", "confidence": 0.0-1.0 }],
              "dates": [{ "label": "...", "date": "ISO date" }],
              "amounts": [{ "label": "...", "amount": number, "currency": "USD" }],
              "keyPhrases": ["phrase1", "phrase2"]
            }`
          },
          {
            role: 'user',
            content: content.substring(0, 3000)
          }
        ],
        response_format: { type: 'json_object' },
      });

      const result = JSON.parse(response.choices[0]?.message?.content || '{}');
      return {
        entities: (result.entities || []).map((e: any) => ({
          type: e.type,
          value: e.value,
          confidence: e.confidence || 0.7,
        })),
        dates: (result.dates || []).map((d: any) => ({
          label: d.label,
          date: new Date(d.date),
        })),
        amounts: result.amounts || [],
        keyPhrases: result.keyPhrases || [],
      };
    } catch {
      return { entities: [], dates: [], amounts: [], keyPhrases: [] };
    }
  }

  /**
   * Generate document summary
   */
  private async generateSummary(content: string, category: string): Promise<ProcessedDocument['summary']> {
    try {
      const response = await invokeLLM({
        messages: [
          {
            role: 'system',
            content: `Summarize this ${category} document.
            
            Return JSON:
            {
              "brief": "One sentence summary",
              "detailed": "2-3 paragraph summary",
              "actionItems": ["action1", "action2"]
            }`
          },
          {
            role: 'user',
            content: content.substring(0, 4000)
          }
        ],
        response_format: { type: 'json_object' },
      });

      const result = JSON.parse(response.choices[0]?.message?.content || '{}');
      return {
        brief: result.brief || 'No summary available',
        detailed: result.detailed || '',
        actionItems: result.actionItems || [],
      };
    } catch {
      return { brief: 'Processing failed', detailed: '', actionItems: [] };
    }
  }

  /**
   * Determine document routing
   */
  private determineRouting(classification: ProcessedDocument['classification'], extraction: ProcessedDocument['extraction']): ProcessedDocument['routing'] {
    const categoryRoutes: Record<string, string> = {
      'invoice': 'finance',
      'contract': 'legal',
      'report': 'management',
      'correspondence': 'inbox',
      'legal': 'legal',
      'hr': 'hr',
      'technical': 'engineering',
      'marketing': 'marketing',
      'other': 'inbox',
    };

    const destination = categoryRoutes[classification.category] || 'inbox';
    
    // Determine priority based on content
    let priority: 'low' | 'medium' | 'high' = 'medium';
    
    if (extraction.dates.some(d => {
      const daysUntil = (d.date.getTime() - Date.now()) / (1000 * 60 * 60 * 24);
      return daysUntil >= 0 && daysUntil <= 7;
    })) {
      priority = 'high';
    }
    
    if (extraction.amounts.some(a => a.amount > 10000)) {
      priority = 'high';
    }

    const tags = [
      classification.category,
      ...(classification.subcategory ? [classification.subcategory] : []),
      ...extraction.keyPhrases.slice(0, 3),
    ];

    return { destination, priority, tags };
  }

  /**
   * Route document to destination
   */
  private async routeDocument(processed: ProcessedDocument): Promise<void> {
    console.log(`[DocProcessor] Auto-routing to ${processed.routing.destination} with priority ${processed.routing.priority}`);
    // In production, would move file or create task
  }

  /**
   * Get processed documents
   */
  getProcessedDocuments(filter?: { category?: string; destination?: string }): ProcessedDocument[] {
    let docs = Array.from(this.processedDocs.values());
    
    if (filter?.category) {
      docs = docs.filter(d => d.classification.category === filter.category);
    }
    if (filter?.destination) {
      docs = docs.filter(d => d.routing.destination === filter.destination);
    }
    
    return docs.sort((a, b) => b.processedAt.getTime() - a.processedAt.getTime());
  }

  /**
   * Get processing statistics
   */
  getStats(): { total: number; byCategory: Record<string, number>; avgConfidence: number } {
    const docs = Array.from(this.processedDocs.values());
    const byCategory: Record<string, number> = {};
    
    for (const doc of docs) {
      byCategory[doc.classification.category] = (byCategory[doc.classification.category] || 0) + 1;
    }

    const avgConfidence = docs.length > 0
      ? docs.reduce((sum, d) => sum + d.classification.confidence, 0) / docs.length
      : 0;

    return { total: docs.length, byCategory, avgConfidence };
  }
}

// Singleton instances
const docInstances = new Map<number, AutonomousDocumentProcessing>();

export function getDocumentProcessor(userId: number): AutonomousDocumentProcessing {
  if (!docInstances.has(userId)) {
    docInstances.set(userId, new AutonomousDocumentProcessing(userId));
  }
  return docInstances.get(userId)!;
}
