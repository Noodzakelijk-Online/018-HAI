/**
 * Core Autonomous Framework
 * 
 * Provides foundational infrastructure for fully autonomous operation:
 * - Self-improving decision making
 * - Continuous learning from outcomes
 * - Automatic optimization
 * - Zero human intervention
 */

import { invokeLLM } from '../../_core/llm';

// ============================================================================
// Types & Interfaces
// ============================================================================

export interface AutonomousDecision {
  id: string;
  timestamp: Date;
  context: Record<string, any>;
  decision: any;
  confidence: number;
  reasoning: string;
  strategyUsed: string;
}

export interface DecisionOutcome {
  decisionId: string;
  success: boolean;
  actualResult: any;
  metrics: {
    duration: number;
    cost: number;
    quality: number;
  };
  errorMessage?: string;
}

export interface Strategy {
  id: string;
  name: string;
  description: string;
  parameters: Record<string, any>;
  performance: {
    successRate: number;
    avgDuration: number;
    avgCost: number;
    avgQuality: number;
    sampleSize: number;
  };
  createdAt: Date;
  lastUsed: Date;
}

export interface LearningSignal {
  type: 'success' | 'failure' | 'improvement' | 'degradation';
  context: Record<string, any>;
  impact: number;
  timestamp: Date;
}

// ============================================================================
// Core Autonomous Engine
// ============================================================================

export class AutonomousEngine {
  private strategies: Map<string, Strategy> = new Map();
  private decisions: AutonomousDecision[] = [];
  private outcomes: DecisionOutcome[] = [];
  private learningSignals: LearningSignal[] = [];
  private currentExperiment: { strategyA: string; strategyB: string; startTime: Date } | null = null;
  
  constructor() {
    this.initializeBaselineStrategies();
  }
  
  // ==========================================================================
  // Public API
  // ==========================================================================
  
  /**
   * Make an autonomous decision with zero human intervention
   */
  async makeDecision(context: {
    type: string;
    data: Record<string, any>;
    constraints?: Record<string, any>;
  }): Promise<AutonomousDecision> {
    // Select optimal strategy (includes A/B testing)
    const strategy = this.selectStrategy(context);
    
    // Apply strategy to make decision
    const decision = await this.applyStrategy(strategy, context);
    
    // Record decision for learning
    this.decisions.push(decision);
    
    return decision;
  }
  
  /**
   * Record outcome of a decision for continuous learning
   */
  recordOutcome(outcome: DecisionOutcome): void {
    this.outcomes.push(outcome);
    
    // Update strategy performance metrics
    this.updateStrategyPerformance(outcome);
    
    // Generate learning signals
    this.generateLearningSignals(outcome);
    
    // Trigger optimization if enough data collected
    if (this.outcomes.length % 100 === 0) {
      this.autonomousOptimize();
    }
  }
  
  /**
   * Get current performance metrics
   */
  getPerformanceMetrics(): {
    overallSuccessRate: number;
    avgDecisionTime: number;
    avgCost: number;
    strategiesCount: number;
    decisionsCount: number;
    improvementRate: number;
  } {
    const recentOutcomes = this.outcomes.slice(-1000);
    
    if (recentOutcomes.length === 0) {
      return {
        overallSuccessRate: 0,
        avgDecisionTime: 0,
        avgCost: 0,
        strategiesCount: this.strategies.size,
        decisionsCount: this.decisions.length,
        improvementRate: 0
      };
    }
    
    const successRate = recentOutcomes.filter(o => o.success).length / recentOutcomes.length;
    const avgDuration = recentOutcomes.reduce((sum, o) => sum + o.metrics.duration, 0) / recentOutcomes.length;
    const avgCost = recentOutcomes.reduce((sum, o) => sum + o.metrics.cost, 0) / recentOutcomes.length;
    
    // Calculate improvement rate (compare last 100 vs previous 100)
    const recent100 = recentOutcomes.slice(-100);
    const previous100 = recentOutcomes.slice(-200, -100);
    
    let improvementRate = 0;
    if (previous100.length > 0) {
      const recentSuccess = recent100.filter(o => o.success).length / recent100.length;
      const previousSuccess = previous100.filter(o => o.success).length / previous100.length;
      improvementRate = ((recentSuccess - previousSuccess) / previousSuccess) * 100;
    }
    
    return {
      overallSuccessRate: successRate,
      avgDecisionTime: avgDuration,
      avgCost,
      strategiesCount: this.strategies.size,
      decisionsCount: this.decisions.length,
      improvementRate
    };
  }
  
  // ==========================================================================
  // Strategy Management
  // ==========================================================================
  
  private initializeBaselineStrategies(): void {
    // Fast & Cheap strategy
    this.strategies.set('fast-cheap', {
      id: 'fast-cheap',
      name: 'Fast & Cheap',
      description: 'Prioritize speed and cost over quality',
      parameters: {
        maxDuration: 5,
        maxCost: 0.01,
        minQuality: 0.7
      },
      performance: {
        successRate: 0.80,
        avgDuration: 3,
        avgCost: 0.005,
        avgQuality: 0.75,
        sampleSize: 0
      },
      createdAt: new Date(),
      lastUsed: new Date()
    });
    
    // Balanced strategy
    this.strategies.set('balanced', {
      id: 'balanced',
      name: 'Balanced',
      description: 'Balance speed, cost, and quality',
      parameters: {
        maxDuration: 15,
        maxCost: 0.03,
        minQuality: 0.85
      },
      performance: {
        successRate: 0.90,
        avgDuration: 10,
        avgCost: 0.02,
        avgQuality: 0.88,
        sampleSize: 0
      },
      createdAt: new Date(),
      lastUsed: new Date()
    });
    
    // High Quality strategy
    this.strategies.set('high-quality', {
      id: 'high-quality',
      name: 'High Quality',
      description: 'Prioritize quality over speed and cost',
      parameters: {
        maxDuration: 30,
        maxCost: 0.10,
        minQuality: 0.95
      },
      performance: {
        successRate: 0.95,
        avgDuration: 20,
        avgCost: 0.05,
        avgQuality: 0.96,
        sampleSize: 0
      },
      createdAt: new Date(),
      lastUsed: new Date()
    });
  }
  
  private selectStrategy(context: any): Strategy {
    // If running A/B test, randomly assign
    if (this.currentExperiment && Math.random() < 0.5) {
      return this.strategies.get(this.currentExperiment.strategyA)!;
    } else if (this.currentExperiment) {
      return this.strategies.get(this.currentExperiment.strategyB)!;
    }
    
    // Otherwise, select best performing strategy
    return this.getBestStrategy();
  }
  
  private getBestStrategy(): Strategy {
    let best: Strategy | null = null;
    let bestScore = -Infinity;
    
    for (const strategy of this.strategies.values()) {
      // Composite score: success_rate (60%) + quality (25%) - normalized_cost (10%) - normalized_duration (5%)
      const score = 
        strategy.performance.successRate * 0.6 +
        strategy.performance.avgQuality * 0.25 -
        (strategy.performance.avgCost / 0.10) * 0.10 -
        (strategy.performance.avgDuration / 30) * 0.05;
      
      if (score > bestScore && strategy.performance.sampleSize > 10) {
        bestScore = score;
        best = strategy;
      }
    }
    
    // Fallback to balanced if no strategy has enough samples
    return best || this.strategies.get('balanced')!;
  }
  
  private async applyStrategy(strategy: Strategy, context: any): Promise<AutonomousDecision> {
    // Use LLM to make intelligent decision based on strategy parameters
    const prompt = `Make an autonomous decision for this context using the specified strategy.

Context Type: ${context.type}
Context Data: ${JSON.stringify(context.data, null, 2)}
Constraints: ${JSON.stringify(context.constraints || {}, null, 2)}

Strategy: ${strategy.name}
Parameters: ${JSON.stringify(strategy.parameters, null, 2)}

Provide a decision that optimizes for the strategy's parameters while respecting constraints.
Include your reasoning and confidence level (0-1).`;

    const response = await invokeLLM({
      messages: [
        { role: 'system', content: 'You are an autonomous decision-making system. Make optimal decisions without human intervention.' },
        { role: 'user', content: prompt }
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'autonomous_decision',
          strict: true,
          schema: {
            type: 'object',
            properties: {
              decision: { type: 'object' },
              confidence: { type: 'number' },
              reasoning: { type: 'string' }
            },
            required: ['decision', 'confidence', 'reasoning'],
            additionalProperties: false
          }
        }
      }
    });
    
    const result = JSON.parse(response.choices[0].message.content);
    
    const decision: AutonomousDecision = {
      id: `decision-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date(),
      context,
      decision: result.decision,
      confidence: result.confidence,
      reasoning: result.reasoning,
      strategyUsed: strategy.id
    };
    
    // Update strategy last used
    strategy.lastUsed = new Date();
    
    return decision;
  }
  
  // ==========================================================================
  // Learning & Optimization
  // ==========================================================================
  
  private updateStrategyPerformance(outcome: DecisionOutcome): void {
    const decision = this.decisions.find(d => d.id === outcome.decisionId);
    if (!decision) return;
    
    const strategy = this.strategies.get(decision.strategyUsed);
    if (!strategy) return;
    
    // Update running averages
    const n = strategy.performance.sampleSize;
    const newN = n + 1;
    
    strategy.performance.successRate = (strategy.performance.successRate * n + (outcome.success ? 1 : 0)) / newN;
    strategy.performance.avgDuration = (strategy.performance.avgDuration * n + outcome.metrics.duration) / newN;
    strategy.performance.avgCost = (strategy.performance.avgCost * n + outcome.metrics.cost) / newN;
    strategy.performance.avgQuality = (strategy.performance.avgQuality * n + outcome.metrics.quality) / newN;
    strategy.performance.sampleSize = newN;
  }
  
  private generateLearningSignals(outcome: DecisionOutcome): void {
    const decision = this.decisions.find(d => d.id === outcome.decisionId);
    if (!decision) return;
    
    // Generate success/failure signal
    this.learningSignals.push({
      type: outcome.success ? 'success' : 'failure',
      context: decision.context,
      impact: outcome.success ? outcome.metrics.quality : -0.5,
      timestamp: new Date()
    });
    
    // Detect improvement/degradation trends
    const recentOutcomes = this.outcomes.slice(-20);
    if (recentOutcomes.length >= 20) {
      const recent10 = recentOutcomes.slice(-10);
      const previous10 = recentOutcomes.slice(-20, -10);
      
      const recentSuccess = recent10.filter(o => o.success).length / 10;
      const previousSuccess = previous10.filter(o => o.success).length / 10;
      
      if (recentSuccess > previousSuccess + 0.1) {
        this.learningSignals.push({
          type: 'improvement',
          context: decision.context,
          impact: recentSuccess - previousSuccess,
          timestamp: new Date()
        });
      } else if (recentSuccess < previousSuccess - 0.1) {
        this.learningSignals.push({
          type: 'degradation',
          context: decision.context,
          impact: previousSuccess - recentSuccess,
          timestamp: new Date()
        });
      }
    }
  }
  
  private autonomousOptimize(): void {
    console.log('[AutonomousEngine] Starting autonomous optimization...');
    
    // Evaluate current experiment if running
    if (this.currentExperiment) {
      this.evaluateExperiment();
    }
    
    // Start new experiment
    this.startNewExperiment();
    
    // Generate new strategy variations
    this.generateStrategyVariations();
    
    // Prune underperforming strategies
    this.pruneStrategies();
    
    console.log(`[AutonomousEngine] Optimization complete. Active strategies: ${this.strategies.size}`);
  }
  
  private evaluateExperiment(): void {
    if (!this.currentExperiment) return;
    
    const strategyA = this.strategies.get(this.currentExperiment.strategyA);
    const strategyB = this.strategies.get(this.currentExperiment.strategyB);
    
    if (!strategyA || !strategyB) {
      this.currentExperiment = null;
      return;
    }
    
    // Calculate composite scores
    const scoreA = this.calculateStrategyScore(strategyA);
    const scoreB = this.calculateStrategyScore(strategyB);
    
    console.log(`[AutonomousEngine] Experiment results: ${strategyA.name} (${scoreA.toFixed(3)}) vs ${strategyB.name} (${scoreB.toFixed(3)})`);
    
    // Remove loser if statistically significant
    if (Math.abs(scoreA - scoreB) > 0.05 && strategyA.performance.sampleSize > 30 && strategyB.performance.sampleSize > 30) {
      const loser = scoreA < scoreB ? strategyA.id : strategyB.id;
      this.strategies.delete(loser);
      console.log(`[AutonomousEngine] Removed underperforming strategy: ${loser}`);
    }
    
    this.currentExperiment = null;
  }
  
  private startNewExperiment(): void {
    const strategies = Array.from(this.strategies.keys());
    
    if (strategies.length >= 2) {
      // Pick two random strategies
      const idx1 = Math.floor(Math.random() * strategies.length);
      let idx2 = Math.floor(Math.random() * strategies.length);
      while (idx2 === idx1) {
        idx2 = Math.floor(Math.random() * strategies.length);
      }
      
      this.currentExperiment = {
        strategyA: strategies[idx1],
        strategyB: strategies[idx2],
        startTime: new Date()
      };
      
      console.log(`[AutonomousEngine] Starting A/B test: ${this.currentExperiment.strategyA} vs ${this.currentExperiment.strategyB}`);
    }
  }
  
  private generateStrategyVariations(): void {
    const best = this.getBestStrategy();
    
    // Generate 2 variations with parameter mutations
    for (let i = 0; i < 2; i++) {
      const variation: Strategy = {
        id: `variation-${Date.now()}-${i}`,
        name: `${best.name} Variation ${i + 1}`,
        description: `Auto-generated variation of ${best.name}`,
        parameters: this.mutateParameters(best.parameters),
        performance: {
          successRate: 0.85,
          avgDuration: best.performance.avgDuration,
          avgCost: best.performance.avgCost,
          avgQuality: best.performance.avgQuality,
          sampleSize: 0
        },
        createdAt: new Date(),
        lastUsed: new Date()
      };
      
      this.strategies.set(variation.id, variation);
      console.log(`[AutonomousEngine] Generated strategy variation: ${variation.id}`);
    }
  }
  
  private mutateParameters(params: Record<string, any>): Record<string, any> {
    const mutated = { ...params };
    
    for (const key in mutated) {
      if (typeof mutated[key] === 'number') {
        // Mutate by ±20%
        const mutation = 0.8 + Math.random() * 0.4;
        mutated[key] = mutated[key] * mutation;
      }
    }
    
    return mutated;
  }
  
  private pruneStrategies(): void {
    // Remove strategies with poor performance and sufficient samples
    const toRemove: string[] = [];
    
    for (const [id, strategy] of this.strategies.entries()) {
      if (strategy.performance.sampleSize > 50) {
        const score = this.calculateStrategyScore(strategy);
        
        // Remove if score is significantly below average
        const avgScore = Array.from(this.strategies.values())
          .filter(s => s.performance.sampleSize > 50)
          .reduce((sum, s) => sum + this.calculateStrategyScore(s), 0) / this.strategies.size;
        
        if (score < avgScore * 0.7) {
          toRemove.push(id);
        }
      }
    }
    
    // Keep at least 3 strategies
    if (this.strategies.size - toRemove.length >= 3) {
      for (const id of toRemove) {
        this.strategies.delete(id);
        console.log(`[AutonomousEngine] Pruned low-performing strategy: ${id}`);
      }
    }
  }
  
  private calculateStrategyScore(strategy: Strategy): number {
    return (
      strategy.performance.successRate * 0.6 +
      strategy.performance.avgQuality * 0.25 -
      (strategy.performance.avgCost / 0.10) * 0.10 -
      (strategy.performance.avgDuration / 30) * 0.05
    );
  }
}

// ============================================================================
// Singleton Instance
// ============================================================================

export const autonomousEngine = new AutonomousEngine();

// ============================================================================
// Convenience Functions
// ============================================================================

export async function makeAutonomousDecision(context: {
  type: string;
  data: Record<string, any>;
  constraints?: Record<string, any>;
}): Promise<AutonomousDecision> {
  return autonomousEngine.makeDecision(context);
}

export function recordDecisionOutcome(outcome: DecisionOutcome): void {
  autonomousEngine.recordOutcome(outcome);
}

export function getAutonomousMetrics() {
  return autonomousEngine.getPerformanceMetrics();
}

export function getAutonomousCore() {
  return autonomousEngine;
}
