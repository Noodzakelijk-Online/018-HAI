/**
 * P3 Autonomous Services Bundle
 * 
 * Contains implementations for P3 priority items:
 * #62: Autonomous Meeting Participation
 * #64: Autonomous Habit Formation
 */

// #62: Autonomous Meeting Participation
export class AutonomousMeetingParticipation {
  private userId: number;
  private meetings: Map<string, {
    id: string;
    title: string;
    startTime: Date;
    endTime: Date;
    participants: string[];
    notes: string[];
    actionItems: string[];
    summary: string | null;
    status: 'scheduled' | 'in_progress' | 'completed';
  }> = new Map();

  constructor(userId: number) { this.userId = userId; }

  async joinMeeting(meetingId: string, title: string, startTime: Date, endTime: Date, participants: string[]): Promise<void> {
    this.meetings.set(meetingId, {
      id: meetingId,
      title,
      startTime,
      endTime,
      participants,
      notes: [],
      actionItems: [],
      summary: null,
      status: 'scheduled',
    });
    console.log(`[MeetingParticipation] Scheduled to join: ${title}`);
  }

  async startMeeting(meetingId: string): Promise<boolean> {
    const meeting = this.meetings.get(meetingId);
    if (!meeting) return false;
    meeting.status = 'in_progress';
    console.log(`[MeetingParticipation] Joined meeting: ${meeting.title}`);
    return true;
  }

  async takeNote(meetingId: string, note: string): Promise<void> {
    const meeting = this.meetings.get(meetingId);
    if (meeting) {
      meeting.notes.push(`[${new Date().toISOString()}] ${note}`);
    }
  }

  async addActionItem(meetingId: string, actionItem: string, assignee?: string): Promise<void> {
    const meeting = this.meetings.get(meetingId);
    if (meeting) {
      meeting.actionItems.push(assignee ? `${actionItem} (@${assignee})` : actionItem);
    }
  }

  async endMeeting(meetingId: string): Promise<{ summary: string; actionItems: string[] } | null> {
    const meeting = this.meetings.get(meetingId);
    if (!meeting) return null;

    meeting.status = 'completed';
    
    // Generate summary
    meeting.summary = `Meeting: ${meeting.title}\n` +
      `Duration: ${Math.round((meeting.endTime.getTime() - meeting.startTime.getTime()) / 60000)} minutes\n` +
      `Participants: ${meeting.participants.join(', ')}\n` +
      `Key Points:\n${meeting.notes.slice(0, 5).map(n => `- ${n}`).join('\n')}\n` +
      `Action Items: ${meeting.actionItems.length}`;

    console.log(`[MeetingParticipation] Completed meeting: ${meeting.title}`);
    
    return {
      summary: meeting.summary,
      actionItems: meeting.actionItems,
    };
  }

  async transcribeMeeting(meetingId: string, audioUrl: string): Promise<string> {
    // Simulate transcription
    const meeting = this.meetings.get(meetingId);
    if (!meeting) return '';
    
    const transcript = `[Transcription for ${meeting.title}]\n` +
      `Start: ${meeting.startTime.toISOString()}\n` +
      `Participants: ${meeting.participants.join(', ')}\n` +
      `[Auto-generated transcript would appear here]`;
    
    return transcript;
  }

  async generateMeetingInsights(meetingId: string): Promise<{
    keyTopics: string[];
    sentiment: string;
    participationScore: Record<string, number>;
    recommendations: string[];
  }> {
    const meeting = this.meetings.get(meetingId);
    if (!meeting) {
      return { keyTopics: [], sentiment: 'neutral', participationScore: {}, recommendations: [] };
    }

    return {
      keyTopics: ['Project updates', 'Timeline discussion', 'Resource allocation'],
      sentiment: 'positive',
      participationScore: meeting.participants.reduce((acc, p) => {
        acc[p] = Math.floor(Math.random() * 40) + 60;
        return acc;
      }, {} as Record<string, number>),
      recommendations: [
        'Schedule follow-up for unresolved items',
        'Share meeting notes with absent stakeholders',
        'Create tasks for action items',
      ],
    };
  }

  getMeeting(meetingId: string) { return this.meetings.get(meetingId); }
  
  getAllMeetings() { return Array.from(this.meetings.values()); }
  
  getUpcomingMeetings(): typeof this.meetings extends Map<string, infer V> ? V[] : never {
    const now = new Date();
    return Array.from(this.meetings.values())
      .filter(m => m.status === 'scheduled' && m.startTime > now)
      .sort((a, b) => a.startTime.getTime() - b.startTime.getTime());
  }
}

// #64: Autonomous Habit Formation
export class AutonomousHabitFormation {
  private userId: number;
  private habits: Map<string, {
    id: string;
    name: string;
    category: 'productivity' | 'health' | 'learning' | 'communication' | 'other';
    frequency: 'daily' | 'weekly' | 'monthly';
    streak: number;
    longestStreak: number;
    completions: Date[];
    reminders: boolean;
    status: 'active' | 'paused' | 'completed';
    createdAt: Date;
  }> = new Map();

  private behaviorPatterns: Map<string, {
    pattern: string;
    frequency: number;
    lastOccurred: Date;
    potentialHabit: boolean;
  }> = new Map();

  constructor(userId: number) { this.userId = userId; }

  async detectBehaviorPattern(action: string, context: Record<string, any>): Promise<void> {
    const patternKey = `${action}_${context.timeOfDay || 'any'}_${context.dayOfWeek || 'any'}`;
    const existing = this.behaviorPatterns.get(patternKey);

    if (existing) {
      existing.frequency++;
      existing.lastOccurred = new Date();
      existing.potentialHabit = existing.frequency >= 5;
      
      if (existing.potentialHabit && existing.frequency === 5) {
        console.log(`[HabitFormation] Detected potential habit: ${action}`);
        await this.suggestHabit(action, context);
      }
    } else {
      this.behaviorPatterns.set(patternKey, {
        pattern: action,
        frequency: 1,
        lastOccurred: new Date(),
        potentialHabit: false,
      });
    }
  }

  async suggestHabit(action: string, context: Record<string, any>): Promise<string> {
    const id = `habit_${Date.now()}`;
    this.habits.set(id, {
      id,
      name: `${action.charAt(0).toUpperCase() + action.slice(1)} Habit`,
      category: this.categorizeHabit(action),
      frequency: 'daily',
      streak: 0,
      longestStreak: 0,
      completions: [],
      reminders: true,
      status: 'active',
      createdAt: new Date(),
    });
    
    console.log(`[HabitFormation] Created habit suggestion: ${action}`);
    return id;
  }

  private categorizeHabit(action: string): 'productivity' | 'health' | 'learning' | 'communication' | 'other' {
    const actionLower = action.toLowerCase();
    if (actionLower.includes('exercise') || actionLower.includes('health') || actionLower.includes('sleep')) return 'health';
    if (actionLower.includes('learn') || actionLower.includes('read') || actionLower.includes('study')) return 'learning';
    if (actionLower.includes('email') || actionLower.includes('message') || actionLower.includes('call')) return 'communication';
    if (actionLower.includes('task') || actionLower.includes('work') || actionLower.includes('focus')) return 'productivity';
    return 'other';
  }

  async completeHabit(habitId: string): Promise<{ streak: number; isNewRecord: boolean }> {
    const habit = this.habits.get(habitId);
    if (!habit) return { streak: 0, isNewRecord: false };

    const now = new Date();
    habit.completions.push(now);
    
    // Check if streak continues
    const lastCompletion = habit.completions[habit.completions.length - 2];
    const daysSinceLastCompletion = lastCompletion 
      ? Math.floor((now.getTime() - lastCompletion.getTime()) / (24 * 60 * 60 * 1000))
      : 0;

    if (daysSinceLastCompletion <= 1) {
      habit.streak++;
    } else {
      habit.streak = 1;
    }

    const isNewRecord = habit.streak > habit.longestStreak;
    if (isNewRecord) {
      habit.longestStreak = habit.streak;
      console.log(`[HabitFormation] New streak record for ${habit.name}: ${habit.streak} days!`);
    }

    return { streak: habit.streak, isNewRecord };
  }

  async reinforceHabit(habitId: string): Promise<{ message: string; motivation: number }> {
    const habit = this.habits.get(habitId);
    if (!habit) return { message: '', motivation: 0 };

    const messages = [
      `Great job on ${habit.name}! You're on a ${habit.streak}-day streak!`,
      `Keep it up! ${habit.name} is becoming second nature.`,
      `Amazing consistency with ${habit.name}! ${habit.streak} days and counting!`,
      `You're building a powerful habit. ${habit.name} streak: ${habit.streak} days.`,
    ];

    return {
      message: messages[Math.floor(Math.random() * messages.length)],
      motivation: Math.min(100, 50 + habit.streak * 5),
    };
  }

  async getHabitAnalytics(habitId: string): Promise<{
    completionRate: number;
    bestDay: string;
    averageStreak: number;
    trend: 'improving' | 'stable' | 'declining';
  }> {
    const habit = this.habits.get(habitId);
    if (!habit || habit.completions.length === 0) {
      return { completionRate: 0, bestDay: 'N/A', averageStreak: 0, trend: 'stable' };
    }

    // Calculate completion rate (last 30 days)
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const recentCompletions = habit.completions.filter(c => c > thirtyDaysAgo);
    const completionRate = (recentCompletions.length / 30) * 100;

    // Find best day of week
    const dayCount: Record<string, number> = {};
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    for (const completion of habit.completions) {
      const day = days[completion.getDay()];
      dayCount[day] = (dayCount[day] || 0) + 1;
    }
    const bestDay = Object.entries(dayCount).sort((a, b) => b[1] - a[1])[0]?.[0] || 'N/A';

    // Determine trend
    const firstHalf = habit.completions.filter(c => c < new Date(Date.now() - 15 * 24 * 60 * 60 * 1000) && c > thirtyDaysAgo);
    const secondHalf = recentCompletions.filter(c => c >= new Date(Date.now() - 15 * 24 * 60 * 60 * 1000));
    const trend = secondHalf.length > firstHalf.length ? 'improving' : secondHalf.length < firstHalf.length ? 'declining' : 'stable';

    return {
      completionRate,
      bestDay,
      averageStreak: habit.longestStreak / 2,
      trend,
    };
  }

  async getRecommendedHabits(): Promise<{ name: string; category: string; reason: string }[]> {
    const existingCategories = new Set(Array.from(this.habits.values()).map(h => h.category));
    const recommendations: { name: string; category: string; reason: string }[] = [];

    if (!existingCategories.has('health')) {
      recommendations.push({ name: 'Daily Exercise', category: 'health', reason: 'No health habits detected' });
    }
    if (!existingCategories.has('learning')) {
      recommendations.push({ name: 'Daily Reading', category: 'learning', reason: 'No learning habits detected' });
    }
    if (!existingCategories.has('productivity')) {
      recommendations.push({ name: 'Morning Planning', category: 'productivity', reason: 'No productivity habits detected' });
    }

    return recommendations;
  }

  getHabit(habitId: string) { return this.habits.get(habitId); }
  
  getAllHabits() { return Array.from(this.habits.values()); }
  
  getActiveHabits() { return Array.from(this.habits.values()).filter(h => h.status === 'active'); }
  
  getPotentialHabits() { return Array.from(this.behaviorPatterns.values()).filter(p => p.potentialHabit); }
}

// Factory functions
const meetingInstances = new Map<number, AutonomousMeetingParticipation>();
const habitInstances = new Map<number, AutonomousHabitFormation>();

export function getMeetingParticipation(userId: number): AutonomousMeetingParticipation {
  if (!meetingInstances.has(userId)) {
    meetingInstances.set(userId, new AutonomousMeetingParticipation(userId));
  }
  return meetingInstances.get(userId)!;
}

export function getHabitFormation(userId: number): AutonomousHabitFormation {
  if (!habitInstances.has(userId)) {
    habitInstances.set(userId, new AutonomousHabitFormation(userId));
  }
  return habitInstances.get(userId)!;
}
