/**
 * Autonomous Services Background Scheduler
 * 
 * Runs autonomous services on scheduled intervals without human intervention.
 * This is the core of Level 5 autonomy - services that operate independently.
 */

import { getEmailManager } from './AutonomousEmailManager';
import { getCalendarManager } from './ProactiveCalendarManager';
import { getThreatDetection } from './AdaptiveThreatDetection';
import { getCostOptimizer } from './SelfOptimizingCosts';
import { getModelImprovement } from './ContinuousModelImprovement';
import { getConnectorManager } from './SelfConfiguringConnectors';

interface ScheduledJob {
  id: string;
  name: string;
  service: string;
  interval: number; // in milliseconds
  lastRun: Date | null;
  nextRun: Date;
  status: 'active' | 'paused' | 'running' | 'error';
  runCount: number;
  errorCount: number;
  lastError: string | null;
}

interface SchedulerMetrics {
  totalJobs: number;
  activeJobs: number;
  totalRuns: number;
  totalErrors: number;
  uptime: number;
  startedAt: Date;
}

class AutonomousScheduler {
  private jobs: Map<string, ScheduledJob> = new Map();
  private timers: Map<string, NodeJS.Timeout> = new Map();
  private isRunning: boolean = false;
  private startedAt: Date | null = null;
  private totalRuns: number = 0;
  private totalErrors: number = 0;
  private userId: number = 1; // Default system user

  constructor() {
    this.initializeJobs();
  }

  private initializeJobs(): void {
    // OPTIMIZED: Reduced frequencies to save resources (50% reduction target)
    // P0 Critical Services - Run less frequently to reduce load
    this.registerJob({
      id: 'email-management',
      name: 'Autonomous Email Management',
      service: 'email',
      interval: 15 * 60 * 1000, // Every 15 minutes (was 5 min)
    });

    this.registerJob({
      id: 'threat-detection',
      name: 'Adaptive Threat Detection',
      service: 'security',
      interval: 5 * 60 * 1000, // Every 5 minutes (was 1 min)
    });

    this.registerJob({
      id: 'calendar-optimization',
      name: 'Proactive Calendar Management',
      service: 'calendar',
      interval: 30 * 60 * 1000, // Every 30 minutes (was 15 min)
    });

    this.registerJob({
      id: 'cost-optimization',
      name: 'Self-Optimizing Costs',
      service: 'costs',
      interval: 2 * 60 * 60 * 1000, // Every 2 hours (was 1 hour)
    });

    this.registerJob({
      id: 'model-improvement',
      name: 'Continuous Model Improvement',
      service: 'learning',
      interval: 60 * 60 * 1000, // Every 1 hour (was 30 min)
    });

    this.registerJob({
      id: 'connector-discovery',
      name: 'Self-Configuring Connectors',
      service: 'connectors',
      interval: 2 * 60 * 60 * 1000, // Every 2 hours (was 1 hour)
    });

    console.log(`[AutonomousScheduler] Initialized ${this.jobs.size} jobs`);
  }

  private registerJob(config: { id: string; name: string; service: string; interval: number }): void {
    const job: ScheduledJob = {
      id: config.id,
      name: config.name,
      service: config.service,
      interval: config.interval,
      lastRun: null,
      nextRun: new Date(Date.now() + config.interval),
      status: 'active',
      runCount: 0,
      errorCount: 0,
      lastError: null,
    };
    this.jobs.set(config.id, job);
  }

  async start(): Promise<void> {
    if (this.isRunning) {
      console.log('[AutonomousScheduler] Already running');
      return;
    }

    this.isRunning = true;
    this.startedAt = new Date();
    console.log('[AutonomousScheduler] Starting autonomous scheduler...');

    // Schedule all jobs
    for (const [jobId, job] of this.jobs) {
      if (job.status === 'active') {
        this.scheduleJob(jobId);
      }
    }

    console.log(`[AutonomousScheduler] Started ${this.jobs.size} autonomous jobs`);
  }

  stop(): void {
    if (!this.isRunning) {
      console.log('[AutonomousScheduler] Not running');
      return;
    }

    this.isRunning = false;
    
    // Clear all timers
    for (const [jobId, timer] of this.timers) {
      clearTimeout(timer);
      console.log(`[AutonomousScheduler] Stopped job: ${jobId}`);
    }
    this.timers.clear();

    console.log('[AutonomousScheduler] Stopped all autonomous jobs');
  }

  private scheduleJob(jobId: string): void {
    const job = this.jobs.get(jobId);
    if (!job || job.status !== 'active') return;

    const timer = setTimeout(async () => {
      await this.runJob(jobId);
      // Reschedule after completion
      if (this.isRunning && job.status === 'active') {
        this.scheduleJob(jobId);
      }
    }, job.interval);

    this.timers.set(jobId, timer);
    job.nextRun = new Date(Date.now() + job.interval);
  }

  private async runJob(jobId: string): Promise<void> {
    const job = this.jobs.get(jobId);
    if (!job) return;

    job.status = 'running';
    const startTime = Date.now();

    try {
      console.log(`[AutonomousScheduler] Running job: ${job.name}`);
      
      switch (job.service) {
        case 'email':
          await this.runEmailManagement();
          break;
        case 'security':
          await this.runThreatDetection();
          break;
        case 'calendar':
          await this.runCalendarOptimization();
          break;
        case 'costs':
          await this.runCostOptimization();
          break;
        case 'learning':
          await this.runModelImprovement();
          break;
        case 'connectors':
          await this.runConnectorDiscovery();
          break;
        default:
          console.log(`[AutonomousScheduler] Unknown service: ${job.service}`);
      }

      job.lastRun = new Date();
      job.runCount++;
      job.status = 'active';
      job.lastError = null;
      this.totalRuns++;

      const duration = Date.now() - startTime;
      console.log(`[AutonomousScheduler] Job completed: ${job.name} (${duration}ms)`);

    } catch (error) {
      job.status = 'error';
      job.errorCount++;
      job.lastError = error instanceof Error ? error.message : 'Unknown error';
      this.totalErrors++;
      
      console.error(`[AutonomousScheduler] Job failed: ${job.name}`, error);
      
      // Auto-recover after error
      setTimeout(() => {
        if (job.status === 'error') {
          job.status = 'active';
          console.log(`[AutonomousScheduler] Auto-recovered job: ${job.name}`);
        }
      }, 60000); // Recover after 1 minute
    }
  }

  // Service execution methods
  private async runEmailManagement(): Promise<void> {
    const manager = getEmailManager(this.userId);
    // Process any pending emails in the queue
    const stats = manager.getStats();
    console.log(`[EmailManagement] Stats: ${JSON.stringify(stats)}`);
  }

  private async runThreatDetection(): Promise<void> {
    const detection = getThreatDetection(this.userId);
    // Check for active threats
    const threats = detection.getActiveThreats();
    console.log(`[ThreatDetection] Active threats: ${threats.length}`);
  }

  private async runCalendarOptimization(): Promise<void> {
    const manager = getCalendarManager(this.userId);
    const result = await manager.optimizeSchedule();
    console.log(`[CalendarOptimization] Optimizations: ${result.optimizations?.length || 0}`);
  }

  private async runCostOptimization(): Promise<void> {
    const optimizer = getCostOptimizer(this.userId);
    const result = await optimizer.analyzeAndOptimize();
    console.log(`[CostOptimization] Savings: $${result.totalSavings || 0}`);
  }

  private async runModelImprovement(): Promise<void> {
    const improvement = getModelImprovement(this.userId);
    const stats = improvement.getStats();
    console.log(`[ModelImprovement] Models tracked: ${stats.modelsTracked || 0}`);
  }

  private async runConnectorDiscovery(): Promise<void> {
    const manager = getConnectorManager(this.userId);
    const discovered = await manager.discoverServices();
    console.log(`[ConnectorDiscovery] Discovered: ${discovered.length} services`);
  }

  // Public API
  getJobs(): ScheduledJob[] {
    return Array.from(this.jobs.values());
  }

  getJob(jobId: string): ScheduledJob | undefined {
    return this.jobs.get(jobId);
  }

  pauseJob(jobId: string): boolean {
    const job = this.jobs.get(jobId);
    if (!job) return false;

    job.status = 'paused';
    const timer = this.timers.get(jobId);
    if (timer) {
      clearTimeout(timer);
      this.timers.delete(jobId);
    }
    
    console.log(`[AutonomousScheduler] Paused job: ${job.name}`);
    return true;
  }

  resumeJob(jobId: string): boolean {
    const job = this.jobs.get(jobId);
    if (!job) return false;

    job.status = 'active';
    if (this.isRunning) {
      this.scheduleJob(jobId);
    }
    
    console.log(`[AutonomousScheduler] Resumed job: ${job.name}`);
    return true;
  }

  async runJobNow(jobId: string): Promise<boolean> {
    const job = this.jobs.get(jobId);
    if (!job) return false;

    await this.runJob(jobId);
    return true;
  }

  getMetrics(): SchedulerMetrics {
    const activeJobs = Array.from(this.jobs.values()).filter(j => j.status === 'active').length;
    
    return {
      totalJobs: this.jobs.size,
      activeJobs,
      totalRuns: this.totalRuns,
      totalErrors: this.totalErrors,
      uptime: this.startedAt ? Date.now() - this.startedAt.getTime() : 0,
      startedAt: this.startedAt || new Date(),
    };
  }

  isSchedulerRunning(): boolean {
    return this.isRunning;
  }
}

// Singleton instance
let schedulerInstance: AutonomousScheduler | null = null;

export function getAutonomousScheduler(): AutonomousScheduler {
  if (!schedulerInstance) {
    schedulerInstance = new AutonomousScheduler();
  }
  return schedulerInstance;
}

// Auto-start scheduler when module is loaded
const scheduler = getAutonomousScheduler();
scheduler.start().catch(err => {
  console.error('[AutonomousScheduler] Failed to start:', err);
});
