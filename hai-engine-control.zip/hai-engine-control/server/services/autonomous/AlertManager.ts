/**
 * Alert Manager
 * 
 * Manages notifications and alerts for autonomous services.
 * Supports configurable thresholds and multiple notification channels.
 */

import { notifyOwner } from '../../_core/notification';

export type AlertSeverity = 'info' | 'warning' | 'error' | 'critical';
export type AlertChannel = 'in_app' | 'email' | 'push';

export interface AlertRule {
  id: string;
  name: string;
  serviceId: string;
  condition: 'threshold_exceeded' | 'failure_count' | 'success_rate_below' | 'cost_savings_above' | 'custom';
  threshold: number;
  severity: AlertSeverity;
  channels: AlertChannel[];
  enabled: boolean;
  cooldownMinutes: number; // Minimum time between alerts
  metadata?: Record<string, any>;
}

export interface Alert {
  id: string;
  ruleId: string;
  ruleName: string;
  serviceId: string;
  serviceName: string;
  severity: AlertSeverity;
  title: string;
  message: string;
  timestamp: Date;
  acknowledged: boolean;
  acknowledgedBy?: string;
  acknowledgedAt?: Date;
  channels: AlertChannel[];
  metadata?: Record<string, any>;
}

export interface AlertStats {
  total: number;
  unacknowledged: number;
  bySeverity: Record<AlertSeverity, number>;
  byService: Record<string, number>;
  last24Hours: number;
}

class AlertManager {
  private rules: AlertRule[] = [];
  private alerts: Alert[] = [];
  private lastAlertTime: Map<string, Date> = new Map();
  private maxAlerts: number = 5000;

  constructor() {
    this.initializeDefaultRules();
  }

  private initializeDefaultRules(): void {
    // Critical service failure alerts
    this.addRule({
      id: 'rule_critical_failure',
      name: 'Critical Service Failure',
      serviceId: '*', // All services
      condition: 'failure_count',
      threshold: 3,
      severity: 'critical',
      channels: ['in_app', 'email'],
      enabled: true,
      cooldownMinutes: 15,
    });

    // Threat detection alert
    this.addRule({
      id: 'rule_threat_detected',
      name: 'Security Threat Detected',
      serviceId: 'threat-detection',
      condition: 'custom',
      threshold: 1,
      severity: 'critical',
      channels: ['in_app', 'email'],
      enabled: true,
      cooldownMinutes: 5,
      metadata: { description: 'Alert when security threats are detected' },
    });

    // Cost savings milestone
    this.addRule({
      id: 'rule_cost_savings_100',
      name: 'Cost Savings Milestone ($100)',
      serviceId: 'cost-optimization',
      condition: 'cost_savings_above',
      threshold: 100,
      severity: 'info',
      channels: ['in_app'],
      enabled: true,
      cooldownMinutes: 60,
    });

    this.addRule({
      id: 'rule_cost_savings_500',
      name: 'Cost Savings Milestone ($500)',
      serviceId: 'cost-optimization',
      condition: 'cost_savings_above',
      threshold: 500,
      severity: 'info',
      channels: ['in_app', 'email'],
      enabled: true,
      cooldownMinutes: 1440, // Once per day
    });

    // Success rate degradation
    this.addRule({
      id: 'rule_success_rate_low',
      name: 'Low Success Rate',
      serviceId: '*',
      condition: 'success_rate_below',
      threshold: 80,
      severity: 'warning',
      channels: ['in_app'],
      enabled: true,
      cooldownMinutes: 30,
    });

    // Email processing backlog
    this.addRule({
      id: 'rule_email_backlog',
      name: 'Email Processing Backlog',
      serviceId: 'email-management',
      condition: 'threshold_exceeded',
      threshold: 100,
      severity: 'warning',
      channels: ['in_app'],
      enabled: true,
      cooldownMinutes: 60,
      metadata: { metric: 'pending_emails' },
    });

    // Model degradation
    this.addRule({
      id: 'rule_model_degradation',
      name: 'Model Performance Degradation',
      serviceId: 'model-improvement',
      condition: 'success_rate_below',
      threshold: 85,
      severity: 'warning',
      channels: ['in_app', 'email'],
      enabled: true,
      cooldownMinutes: 120,
    });
  }

  addRule(rule: AlertRule): void {
    const existing = this.rules.findIndex(r => r.id === rule.id);
    if (existing >= 0) {
      this.rules[existing] = rule;
    } else {
      this.rules.push(rule);
    }
  }

  removeRule(ruleId: string): boolean {
    const index = this.rules.findIndex(r => r.id === ruleId);
    if (index >= 0) {
      this.rules.splice(index, 1);
      return true;
    }
    return false;
  }

  getRule(ruleId: string): AlertRule | undefined {
    return this.rules.find(r => r.id === ruleId);
  }

  getAllRules(): AlertRule[] {
    return [...this.rules];
  }

  enableRule(ruleId: string): boolean {
    const rule = this.rules.find(r => r.id === ruleId);
    if (rule) {
      rule.enabled = true;
      return true;
    }
    return false;
  }

  disableRule(ruleId: string): boolean {
    const rule = this.rules.find(r => r.id === ruleId);
    if (rule) {
      rule.enabled = false;
      return true;
    }
    return false;
  }

  async checkAndTrigger(
    serviceId: string,
    serviceName: string,
    metrics: {
      failureCount?: number;
      successRate?: number;
      costSavings?: number;
      customValue?: number;
      customCondition?: string;
    }
  ): Promise<Alert[]> {
    const triggeredAlerts: Alert[] = [];
    const applicableRules = this.rules.filter(
      r => r.enabled && (r.serviceId === serviceId || r.serviceId === '*')
    );

    for (const rule of applicableRules) {
      // Check cooldown
      const lastAlert = this.lastAlertTime.get(rule.id);
      if (lastAlert) {
        const cooldownMs = rule.cooldownMinutes * 60 * 1000;
        if (Date.now() - lastAlert.getTime() < cooldownMs) {
          continue;
        }
      }

      let shouldTrigger = false;
      let alertMessage = '';

      switch (rule.condition) {
        case 'failure_count':
          if (metrics.failureCount !== undefined && metrics.failureCount >= rule.threshold) {
            shouldTrigger = true;
            alertMessage = `Service has failed ${metrics.failureCount} times (threshold: ${rule.threshold})`;
          }
          break;

        case 'success_rate_below':
          if (metrics.successRate !== undefined && metrics.successRate < rule.threshold) {
            shouldTrigger = true;
            alertMessage = `Success rate dropped to ${metrics.successRate.toFixed(1)}% (threshold: ${rule.threshold}%)`;
          }
          break;

        case 'cost_savings_above':
          if (metrics.costSavings !== undefined && metrics.costSavings >= rule.threshold) {
            shouldTrigger = true;
            alertMessage = `Cost savings reached $${metrics.costSavings.toFixed(2)} (milestone: $${rule.threshold})`;
          }
          break;

        case 'threshold_exceeded':
          if (metrics.customValue !== undefined && metrics.customValue >= rule.threshold) {
            shouldTrigger = true;
            alertMessage = `Threshold exceeded: ${metrics.customValue} (limit: ${rule.threshold})`;
          }
          break;

        case 'custom':
          if (metrics.customCondition === rule.id) {
            shouldTrigger = true;
            alertMessage = rule.metadata?.description || 'Custom alert triggered';
          }
          break;
      }

      if (shouldTrigger) {
        const alert = await this.createAlert(rule, serviceId, serviceName, alertMessage);
        triggeredAlerts.push(alert);
      }
    }

    return triggeredAlerts;
  }

  private async createAlert(
    rule: AlertRule,
    serviceId: string,
    serviceName: string,
    message: string
  ): Promise<Alert> {
    const alert: Alert = {
      id: `alert_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      ruleId: rule.id,
      ruleName: rule.name,
      serviceId,
      serviceName,
      severity: rule.severity,
      title: `${rule.name} - ${serviceName}`,
      message,
      timestamp: new Date(),
      acknowledged: false,
      channels: rule.channels,
    };

    this.alerts.push(alert);
    this.lastAlertTime.set(rule.id, new Date());

    // Trim old alerts
    if (this.alerts.length > this.maxAlerts) {
      this.alerts = this.alerts.slice(-this.maxAlerts);
    }

    // Send notifications
    await this.sendNotifications(alert);

    console.log(`[AlertManager] Alert created: ${alert.title} (${alert.severity})`);
    return alert;
  }

  private async sendNotifications(alert: Alert): Promise<void> {
    for (const channel of alert.channels) {
      try {
        switch (channel) {
          case 'in_app':
            // In-app notifications are stored in the alerts array
            console.log(`[AlertManager] In-app notification: ${alert.title}`);
            break;

          case 'email':
            // Send email notification via notifyOwner
            if (alert.severity === 'critical' || alert.severity === 'error') {
              await notifyOwner({
                title: `[${alert.severity.toUpperCase()}] ${alert.title}`,
                content: `${alert.message}\n\nService: ${alert.serviceName}\nTime: ${alert.timestamp.toISOString()}`,
              });
              console.log(`[AlertManager] Email notification sent: ${alert.title}`);
            }
            break;

          case 'push':
            // Push notifications would be implemented here
            console.log(`[AlertManager] Push notification: ${alert.title}`);
            break;
        }
      } catch (error) {
        console.error(`[AlertManager] Failed to send ${channel} notification:`, error);
      }
    }
  }

  getAlerts(options: {
    serviceId?: string;
    severity?: AlertSeverity;
    acknowledged?: boolean;
    limit?: number;
  } = {}): Alert[] {
    let result = [...this.alerts];

    if (options.serviceId) {
      result = result.filter(a => a.serviceId === options.serviceId);
    }

    if (options.severity) {
      result = result.filter(a => a.severity === options.severity);
    }

    if (options.acknowledged !== undefined) {
      result = result.filter(a => a.acknowledged === options.acknowledged);
    }

    // Sort by timestamp descending
    result.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

    if (options.limit) {
      result = result.slice(0, options.limit);
    }

    return result;
  }

  acknowledgeAlert(alertId: string, userId?: string): boolean {
    const alert = this.alerts.find(a => a.id === alertId);
    if (alert && !alert.acknowledged) {
      alert.acknowledged = true;
      alert.acknowledgedBy = userId;
      alert.acknowledgedAt = new Date();
      console.log(`[AlertManager] Alert acknowledged: ${alert.title}`);
      return true;
    }
    return false;
  }

  acknowledgeAll(serviceId?: string): number {
    let count = 0;
    this.alerts.forEach(alert => {
      if (!alert.acknowledged && (!serviceId || alert.serviceId === serviceId)) {
        alert.acknowledged = true;
        alert.acknowledgedAt = new Date();
        count++;
      }
    });
    return count;
  }

  getStats(): AlertStats {
    const now = Date.now();
    const dayAgo = now - 24 * 60 * 60 * 1000;

    const bySeverity: Record<AlertSeverity, number> = {
      info: 0,
      warning: 0,
      error: 0,
      critical: 0,
    };

    const byService: Record<string, number> = {};

    this.alerts.forEach(alert => {
      bySeverity[alert.severity]++;
      byService[alert.serviceId] = (byService[alert.serviceId] || 0) + 1;
    });

    return {
      total: this.alerts.length,
      unacknowledged: this.alerts.filter(a => !a.acknowledged).length,
      bySeverity,
      byService,
      last24Hours: this.alerts.filter(a => a.timestamp.getTime() > dayAgo).length,
    };
  }

  clearAlerts(options: { serviceId?: string; acknowledged?: boolean } = {}): number {
    const initialCount = this.alerts.length;

    if (options.serviceId || options.acknowledged !== undefined) {
      this.alerts = this.alerts.filter(a => {
        if (options.serviceId && a.serviceId === options.serviceId) return false;
        if (options.acknowledged !== undefined && a.acknowledged === options.acknowledged) return false;
        return true;
      });
    } else {
      this.alerts = [];
    }

    return initialCount - this.alerts.length;
  }
}

// Singleton instance
let alertManagerInstance: AlertManager | null = null;

export function getAlertManager(): AlertManager {
  if (!alertManagerInstance) {
    alertManagerInstance = new AlertManager();
  }
  return alertManagerInstance;
}
