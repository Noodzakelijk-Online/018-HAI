/**
 * Self-Optimizing Costs (#94)
 * 
 * Minimizes operational costs automatically without human intervention.
 * Uses AI to identify savings opportunities and implement optimizations.
 * 
 * Features:
 * - Automatic resource usage analysis
 * - Cost anomaly detection
 * - Automatic scaling decisions
 * - Service tier optimization
 * - Zero human approval for optimizations
 */

interface ResourceUsage {
  resourceId: string;
  resourceType: 'compute' | 'storage' | 'network' | 'api' | 'database' | 'cdn';
  usage: number;
  limit: number;
  cost: number;
  period: 'hourly' | 'daily' | 'monthly';
  timestamp: Date;
}

interface CostOptimization {
  id: string;
  type: 'downscale' | 'upscale' | 'terminate' | 'migrate' | 'cache' | 'batch' | 'tier_change';
  resourceId: string;
  currentCost: number;
  projectedCost: number;
  savings: number;
  savingsPercent: number;
  risk: 'low' | 'medium' | 'high';
  status: 'identified' | 'approved' | 'implementing' | 'implemented' | 'reverted';
  implementedAt?: Date;
  details: string;
}

interface CostReport {
  totalCost: number;
  costByResource: Record<string, number>;
  costByType: Record<string, number>;
  trend: 'increasing' | 'stable' | 'decreasing';
  projectedMonthly: number;
  savingsOpportunities: number;
  optimizationsApplied: number;
}

interface BudgetAlert {
  id: string;
  threshold: number;
  currentSpend: number;
  percentUsed: number;
  triggered: boolean;
  triggeredAt?: Date;
}

export class SelfOptimizingCosts {
  private userId: number;
  private usageHistory: Map<string, ResourceUsage[]> = new Map();
  private optimizations: Map<string, CostOptimization> = new Map();
  private budgetAlerts: Map<string, BudgetAlert> = new Map();
  private config: {
    utilizationThreshold: number; // Below this, consider downscaling
    costAnomalyThreshold: number; // Percent increase to flag
    autoOptimizeRisk: 'low' | 'medium' | 'high'; // Max risk level for auto-optimization
    minSavingsPercent: number; // Minimum savings to trigger optimization
    budgetLimit: number;
  };

  constructor(userId: number) {
    this.userId = userId;
    this.config = {
      utilizationThreshold: 0.3, // 30% utilization
      costAnomalyThreshold: 0.2, // 20% increase
      autoOptimizeRisk: 'medium',
      minSavingsPercent: 0.1, // 10% savings minimum
      budgetLimit: 1000, // Monthly budget
    };

    // Initialize budget alert
    this.budgetAlerts.set('monthly', {
      id: 'monthly',
      threshold: this.config.budgetLimit,
      currentSpend: 0,
      percentUsed: 0,
      triggered: false,
    });
  }

  /**
   * Record resource usage
   */
  async recordUsage(usage: ResourceUsage): Promise<void> {
    const history = this.usageHistory.get(usage.resourceId) || [];
    history.push(usage);
    
    // Keep last 30 days of hourly data
    if (history.length > 720) {
      history.shift();
    }
    
    this.usageHistory.set(usage.resourceId, history);

    // Check for optimization opportunities
    await this.analyzeResource(usage.resourceId);
    
    // Update budget tracking
    await this.updateBudget(usage);
  }

  /**
   * Analyze resource for optimization opportunities
   */
  private async analyzeResource(resourceId: string): Promise<CostOptimization[]> {
    const history = this.usageHistory.get(resourceId) || [];
    if (history.length < 24) return []; // Need at least 24 hours of data

    const opportunities: CostOptimization[] = [];
    const recent = history.slice(-24);
    
    // Calculate average utilization
    const avgUtilization = recent.reduce((sum, u) => sum + (u.usage / u.limit), 0) / recent.length;
    const avgCost = recent.reduce((sum, u) => sum + u.cost, 0) / recent.length;
    const resourceType = recent[0].resourceType;

    // Check for underutilization
    if (avgUtilization < this.config.utilizationThreshold) {
      const projectedSavings = avgCost * (1 - avgUtilization / this.config.utilizationThreshold) * 0.5;
      
      if (projectedSavings / avgCost >= this.config.minSavingsPercent) {
        opportunities.push({
          id: `opt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          type: 'downscale',
          resourceId,
          currentCost: avgCost * 24 * 30, // Monthly
          projectedCost: (avgCost - projectedSavings) * 24 * 30,
          savings: projectedSavings * 24 * 30,
          savingsPercent: projectedSavings / avgCost,
          risk: 'low',
          status: 'identified',
          details: `Resource utilization at ${(avgUtilization * 100).toFixed(1)}%, recommend downscaling`,
        });
      }
    }

    // Check for cost anomalies
    const olderHistory = history.slice(-168, -24); // Previous week
    if (olderHistory.length > 0) {
      const oldAvgCost = olderHistory.reduce((sum, u) => sum + u.cost, 0) / olderHistory.length;
      const costIncrease = (avgCost - oldAvgCost) / oldAvgCost;
      
      if (costIncrease > this.config.costAnomalyThreshold) {
        opportunities.push({
          id: `opt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          type: 'migrate',
          resourceId,
          currentCost: avgCost * 24 * 30,
          projectedCost: oldAvgCost * 24 * 30,
          savings: (avgCost - oldAvgCost) * 24 * 30,
          savingsPercent: costIncrease,
          risk: 'medium',
          status: 'identified',
          details: `Cost increased ${(costIncrease * 100).toFixed(1)}% - investigate and optimize`,
        });
      }
    }

    // Resource-specific optimizations
    switch (resourceType) {
      case 'api':
        // Check for caching opportunities
        if (avgUtilization > 0.7) {
          opportunities.push({
            id: `opt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            type: 'cache',
            resourceId,
            currentCost: avgCost * 24 * 30,
            projectedCost: avgCost * 24 * 30 * 0.6,
            savings: avgCost * 24 * 30 * 0.4,
            savingsPercent: 0.4,
            risk: 'low',
            status: 'identified',
            details: 'High API usage - implement caching to reduce calls',
          });
        }
        break;
        
      case 'storage':
        // Check for tier optimization
        opportunities.push({
          id: `opt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          type: 'tier_change',
          resourceId,
          currentCost: avgCost * 24 * 30,
          projectedCost: avgCost * 24 * 30 * 0.7,
          savings: avgCost * 24 * 30 * 0.3,
          savingsPercent: 0.3,
          risk: 'low',
          status: 'identified',
          details: 'Move infrequently accessed data to cold storage tier',
        });
        break;
    }

    // Auto-implement low-risk optimizations
    for (const opt of opportunities) {
      if (this.shouldAutoImplement(opt)) {
        await this.implementOptimization(opt);
      } else {
        this.optimizations.set(opt.id, opt);
      }
    }

    return opportunities;
  }

  /**
   * Check if optimization should be auto-implemented
   */
  private shouldAutoImplement(opt: CostOptimization): boolean {
    const riskLevels = { 'low': 1, 'medium': 2, 'high': 3 };
    const maxRisk = riskLevels[this.config.autoOptimizeRisk];
    const optRisk = riskLevels[opt.risk];
    
    return optRisk <= maxRisk && opt.savingsPercent >= this.config.minSavingsPercent;
  }

  /**
   * Implement an optimization
   */
  async implementOptimization(opt: CostOptimization): Promise<boolean> {
    opt.status = 'implementing';
    this.optimizations.set(opt.id, opt);

    try {
      // Simulate implementation based on type
      switch (opt.type) {
        case 'downscale':
          console.log(`[CostOptimizer] Downscaling ${opt.resourceId}`);
          break;
        case 'cache':
          console.log(`[CostOptimizer] Enabling caching for ${opt.resourceId}`);
          break;
        case 'tier_change':
          console.log(`[CostOptimizer] Changing storage tier for ${opt.resourceId}`);
          break;
        case 'batch':
          console.log(`[CostOptimizer] Enabling batch processing for ${opt.resourceId}`);
          break;
        default:
          console.log(`[CostOptimizer] Implementing ${opt.type} for ${opt.resourceId}`);
      }

      opt.status = 'implemented';
      opt.implementedAt = new Date();
      
      console.log(`[CostOptimizer] Optimization implemented: ${opt.details} - Projected savings: $${opt.savings.toFixed(2)}/month`);
      
      return true;
    } catch (error) {
      opt.status = 'identified';
      console.error(`[CostOptimizer] Failed to implement optimization:`, error);
      return false;
    }
  }

  /**
   * Revert an optimization
   */
  async revertOptimization(optId: string): Promise<boolean> {
    const opt = this.optimizations.get(optId);
    if (!opt || opt.status !== 'implemented') return false;

    opt.status = 'reverted';
    console.log(`[CostOptimizer] Reverted optimization: ${opt.details}`);
    return true;
  }

  /**
   * Update budget tracking
   */
  private async updateBudget(usage: ResourceUsage): Promise<void> {
    const alert = this.budgetAlerts.get('monthly');
    if (!alert) return;

    // Add to current spend (simplified - assumes daily cost)
    if (usage.period === 'daily') {
      alert.currentSpend += usage.cost;
    } else if (usage.period === 'hourly') {
      alert.currentSpend += usage.cost * 24;
    }

    alert.percentUsed = alert.currentSpend / alert.threshold;

    // Check thresholds
    if (!alert.triggered && alert.percentUsed >= 0.8) {
      alert.triggered = true;
      alert.triggeredAt = new Date();
      console.log(`[CostOptimizer] Budget alert: ${(alert.percentUsed * 100).toFixed(1)}% of monthly budget used`);
      
      // Trigger aggressive optimization
      await this.runAggressiveOptimization();
    }
  }

  /**
   * Run aggressive optimization when budget is at risk
   */
  private async runAggressiveOptimization(): Promise<void> {
    console.log('[CostOptimizer] Running aggressive optimization due to budget pressure');
    
    // Temporarily allow higher risk optimizations
    const originalRisk = this.config.autoOptimizeRisk;
    this.config.autoOptimizeRisk = 'high';
    
    // Re-analyze all resources
    for (const resourceId of this.usageHistory.keys()) {
      await this.analyzeResource(resourceId);
    }
    
    // Restore original risk level
    this.config.autoOptimizeRisk = originalRisk;
  }

  /**
   * Get cost report
   */
  getCostReport(): CostReport {
    let totalCost = 0;
    const costByResource: Record<string, number> = {};
    const costByType: Record<string, number> = {};

    for (const [resourceId, history] of this.usageHistory) {
      if (history.length === 0) continue;
      
      const recent = history.slice(-24);
      const dailyCost = recent.reduce((sum, u) => sum + u.cost, 0);
      const monthlyCost = dailyCost * 30;
      
      totalCost += monthlyCost;
      costByResource[resourceId] = monthlyCost;
      
      const type = recent[0].resourceType;
      costByType[type] = (costByType[type] || 0) + monthlyCost;
    }

    // Calculate trend
    let trend: 'increasing' | 'stable' | 'decreasing' = 'stable';
    const implementedOpts = Array.from(this.optimizations.values()).filter(o => o.status === 'implemented');
    const totalSavings = implementedOpts.reduce((sum, o) => sum + o.savings, 0);
    
    if (totalSavings > totalCost * 0.1) trend = 'decreasing';
    else if (totalSavings < 0) trend = 'increasing';

    const pendingOpts = Array.from(this.optimizations.values()).filter(o => o.status === 'identified');

    return {
      totalCost,
      costByResource,
      costByType,
      trend,
      projectedMonthly: totalCost - totalSavings,
      savingsOpportunities: pendingOpts.reduce((sum, o) => sum + o.savings, 0),
      optimizationsApplied: implementedOpts.length,
    };
  }

  /**
   * Get pending optimizations
   */
  getPendingOptimizations(): CostOptimization[] {
    return Array.from(this.optimizations.values())
      .filter(o => o.status === 'identified')
      .sort((a, b) => b.savings - a.savings);
  }

  /**
   * Run optimization cycle
   */
  async runOptimizationCycle(): Promise<{ analyzed: number; optimized: number; totalSavings: number }> {
    let analyzed = 0;
    let optimized = 0;
    let totalSavings = 0;

    for (const resourceId of this.usageHistory.keys()) {
      analyzed++;
      const opts = await this.analyzeResource(resourceId);
      
      for (const opt of opts) {
        if (opt.status === 'implemented') {
          optimized++;
          totalSavings += opt.savings;
        }
      }
    }

    return { analyzed, optimized, totalSavings };
  }
}

// Singleton instances per user
const costInstances = new Map<number, SelfOptimizingCosts>();

export function getCostOptimizer(userId: number): SelfOptimizingCosts {
  if (!costInstances.has(userId)) {
    costInstances.set(userId, new SelfOptimizingCosts(userId));
  }
  return costInstances.get(userId)!;
}
