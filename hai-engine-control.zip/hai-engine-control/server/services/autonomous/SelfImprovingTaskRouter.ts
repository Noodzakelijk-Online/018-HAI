/**
 * Self-Improving Task Router (#51)
 * 
 * AI continuously optimizes task routing without human feedback.
 * Uses reinforcement learning to improve routing decisions over time.
 * 
 * Features:
 * - Automatic task classification
 * - Dynamic agent selection based on performance
 * - Continuous learning from outcomes
 * - Zero human intervention required
 */

import { getDb } from '../../db';
import { invokeLLM } from '../../_core/llm';

interface TaskContext {
  taskId: string;
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  category?: string;
  metadata?: Record<string, any>;
}

interface RoutingDecision {
  taskId: string;
  selectedAgent: string;
  confidence: number;
  reasoning: string;
  alternativeAgents: string[];
  predictedCompletionTime: number; // minutes
  predictedSuccessRate: number;
}

interface AgentPerformance {
  agentId: string;
  agentName: string;
  taskCategory: string;
  successRate: number;
  avgCompletionTime: number;
  totalTasks: number;
  recentTrend: 'improving' | 'stable' | 'declining';
}

interface RoutingModel {
  version: number;
  categoryWeights: Map<string, Map<string, number>>; // category -> agent -> weight
  lastUpdated: Date;
  totalDecisions: number;
  accuracy: number;
}

export class SelfImprovingTaskRouter {
  private userId: number;
  private model: RoutingModel;
  private performanceCache: Map<string, AgentPerformance[]> = new Map();
  private learningRate = 0.1;
  private explorationRate = 0.15; // 15% exploration for discovering better routes

  constructor(userId: number) {
    this.userId = userId;
    this.model = {
      version: 1,
      categoryWeights: new Map(),
      lastUpdated: new Date(),
      totalDecisions: 0,
      accuracy: 0.5, // Start with 50% baseline
    };
  }

  /**
   * Route a task to the best available agent
   * Uses a combination of historical performance and exploration
   */
  async routeTask(task: TaskContext): Promise<RoutingDecision> {
    // Step 1: Classify the task
    const category = await this.classifyTask(task);
    
    // Step 2: Get available agents and their performance
    const agents = await this.getAvailableAgents();
    const performances = await this.getAgentPerformances(category);
    
    // Step 3: Select best agent using epsilon-greedy strategy
    const selectedAgent = this.selectAgent(performances, category);
    
    // Step 4: Calculate confidence and alternatives
    const confidence = this.calculateConfidence(selectedAgent, performances);
    const alternatives = this.getAlternativeAgents(performances, selectedAgent.agentId);
    
    // Step 5: Predict outcomes
    const predictedTime = this.predictCompletionTime(selectedAgent, task);
    const predictedSuccess = this.predictSuccessRate(selectedAgent, task);
    
    // Step 6: Record decision for learning
    await this.recordDecision(task.taskId, selectedAgent.agentId, category);
    
    // Step 7: Update model statistics
    this.model.totalDecisions++;
    
    return {
      taskId: task.taskId,
      selectedAgent: selectedAgent.agentName,
      confidence,
      reasoning: this.generateReasoning(selectedAgent, category, performances),
      alternativeAgents: alternatives,
      predictedCompletionTime: predictedTime,
      predictedSuccessRate: predictedSuccess,
    };
  }

  /**
   * Classify task into a category using LLM
   */
  private async classifyTask(task: TaskContext): Promise<string> {
    if (task.category) return task.category;

    try {
      const response = await invokeLLM({
        messages: [
          {
            role: 'system',
            content: `You are a task classification AI. Classify tasks into one of these categories:
            - communication: emails, messages, notifications
            - research: information gathering, analysis
            - scheduling: calendar, meetings, reminders
            - document: file processing, reports
            - data: data entry, synchronization
            - automation: workflow, integrations
            - other: anything else
            
            Respond with ONLY the category name, nothing else.`
          },
          {
            role: 'user',
            content: `Task: ${task.title}\nDescription: ${task.description}`
          }
        ],
      });

      const category = response.choices[0]?.message?.content?.trim().toLowerCase() || 'other';
      return ['communication', 'research', 'scheduling', 'document', 'data', 'automation'].includes(category) 
        ? category 
        : 'other';
    } catch {
      return 'other';
    }
  }

  /**
   * Get all available agents
   */
  private async getAvailableAgents(): Promise<{ id: string; name: string; capabilities: string[] }[]> {
    // Return default agents - in production, this would query the database
    return [
      { id: 'research', name: 'Research Agent', capabilities: ['research', 'data', 'document'] },
      { id: 'communication', name: 'Communication Agent', capabilities: ['communication', 'scheduling'] },
      { id: 'automation', name: 'Automation Agent', capabilities: ['automation', 'data'] },
      { id: 'analysis', name: 'Analysis Agent', capabilities: ['research', 'document', 'data'] },
      { id: 'general', name: 'General Agent', capabilities: ['other'] },
    ];
  }

  /**
   * Get agent performance metrics for a category
   */
  private async getAgentPerformances(category: string): Promise<AgentPerformance[]> {
    // Check cache first
    const cached = this.performanceCache.get(category);
    if (cached) return cached;

    // Generate performance data based on model weights
    const agents = await this.getAvailableAgents();
    const performances: AgentPerformance[] = agents.map(agent => {
      const weight = this.model.categoryWeights.get(category)?.get(agent.id) || 0.5;
      const hasCapability = agent.capabilities.includes(category);
      
      return {
        agentId: agent.id,
        agentName: agent.name,
        taskCategory: category,
        successRate: hasCapability ? 0.7 + (weight * 0.25) : 0.4 + (weight * 0.2),
        avgCompletionTime: hasCapability ? 15 - (weight * 5) : 25 - (weight * 5),
        totalTasks: Math.floor(50 + (weight * 100)),
        recentTrend: weight > 0.6 ? 'improving' : weight > 0.4 ? 'stable' : 'declining',
      };
    });

    this.performanceCache.set(category, performances);
    return performances;
  }

  /**
   * Select best agent using epsilon-greedy strategy
   */
  private selectAgent(performances: AgentPerformance[], category: string): AgentPerformance {
    // Exploration: randomly select an agent
    if (Math.random() < this.explorationRate) {
      const randomIndex = Math.floor(Math.random() * performances.length);
      return performances[randomIndex];
    }

    // Exploitation: select best performing agent
    return performances.reduce((best, current) => {
      const bestScore = this.calculateAgentScore(best);
      const currentScore = this.calculateAgentScore(current);
      return currentScore > bestScore ? current : best;
    });
  }

  /**
   * Calculate agent score based on multiple factors
   */
  private calculateAgentScore(agent: AgentPerformance): number {
    const successWeight = 0.5;
    const timeWeight = 0.3;
    const trendWeight = 0.2;

    const successScore = agent.successRate;
    const timeScore = 1 - (agent.avgCompletionTime / 60); // Normalize to 0-1
    const trendScore = agent.recentTrend === 'improving' ? 1 : agent.recentTrend === 'stable' ? 0.5 : 0;

    return (successScore * successWeight) + (timeScore * timeWeight) + (trendScore * trendWeight);
  }

  /**
   * Calculate confidence in the routing decision
   */
  private calculateConfidence(agent: AgentPerformance, allPerformances: AgentPerformance[]): number {
    const agentScore = this.calculateAgentScore(agent);
    const avgScore = allPerformances.reduce((sum, p) => sum + this.calculateAgentScore(p), 0) / allPerformances.length;
    
    // Higher confidence if selected agent is significantly better than average
    const relativeDiff = (agentScore - avgScore) / avgScore;
    return Math.min(0.95, Math.max(0.5, 0.7 + relativeDiff));
  }

  /**
   * Get alternative agents sorted by score
   */
  private getAlternativeAgents(performances: AgentPerformance[], excludeId: string): string[] {
    return performances
      .filter(p => p.agentId !== excludeId)
      .sort((a, b) => this.calculateAgentScore(b) - this.calculateAgentScore(a))
      .slice(0, 3)
      .map(p => p.agentName);
  }

  /**
   * Predict completion time based on historical data
   */
  private predictCompletionTime(agent: AgentPerformance, task: TaskContext): number {
    const baseTime = agent.avgCompletionTime;
    const priorityMultiplier = task.priority === 'critical' ? 0.7 : 
                               task.priority === 'high' ? 0.85 : 
                               task.priority === 'medium' ? 1 : 1.2;
    return Math.round(baseTime * priorityMultiplier);
  }

  /**
   * Predict success rate based on agent performance and task complexity
   */
  private predictSuccessRate(agent: AgentPerformance, task: TaskContext): number {
    const baseRate = agent.successRate;
    const priorityAdjustment = task.priority === 'critical' ? -0.05 : 0;
    return Math.min(0.99, Math.max(0.3, baseRate + priorityAdjustment));
  }

  /**
   * Generate human-readable reasoning for the decision
   */
  private generateReasoning(agent: AgentPerformance, category: string, performances: AgentPerformance[]): string {
    const score = this.calculateAgentScore(agent);
    const rank = performances.filter(p => this.calculateAgentScore(p) > score).length + 1;
    
    return `Selected ${agent.agentName} (ranked #${rank}) for ${category} tasks. ` +
           `Success rate: ${(agent.successRate * 100).toFixed(1)}%, ` +
           `Avg completion: ${agent.avgCompletionTime} min, ` +
           `Trend: ${agent.recentTrend}. ` +
           `Model confidence: ${(this.model.accuracy * 100).toFixed(1)}%.`;
  }

  /**
   * Record routing decision for learning
   */
  private async recordDecision(taskId: string, agentId: string, category: string): Promise<void> {
    // In production, this would persist to database
    console.log(`[TaskRouter] Recorded decision: Task ${taskId} -> Agent ${agentId} (${category})`);
  }

  /**
   * Learn from task outcome - called when task completes
   * This is the core self-improvement mechanism
   */
  async learnFromOutcome(taskId: string, agentId: string, category: string, success: boolean, completionTime: number): Promise<void> {
    // Update category weights using reinforcement learning
    if (!this.model.categoryWeights.has(category)) {
      this.model.categoryWeights.set(category, new Map());
    }
    
    const categoryWeights = this.model.categoryWeights.get(category)!;
    const currentWeight = categoryWeights.get(agentId) || 0.5;
    
    // Calculate reward
    const successReward = success ? 1 : -0.5;
    const timeReward = completionTime < 15 ? 0.2 : completionTime > 30 ? -0.2 : 0;
    const totalReward = successReward + timeReward;
    
    // Update weight using learning rate
    const newWeight = Math.min(1, Math.max(0, currentWeight + (this.learningRate * totalReward)));
    categoryWeights.set(agentId, newWeight);
    
    // Update model accuracy
    this.model.accuracy = (this.model.accuracy * 0.95) + (success ? 0.05 : 0);
    this.model.lastUpdated = new Date();
    this.model.version++;
    
    // Clear performance cache to reflect new weights
    this.performanceCache.delete(category);
    
    console.log(`[TaskRouter] Learned from outcome: Agent ${agentId} ${success ? 'succeeded' : 'failed'} on ${category}. New weight: ${newWeight.toFixed(3)}`);
  }

  /**
   * Get current model statistics
   */
  getModelStats(): { version: number; accuracy: number; totalDecisions: number; lastUpdated: Date } {
    return {
      version: this.model.version,
      accuracy: this.model.accuracy,
      totalDecisions: this.model.totalDecisions,
      lastUpdated: this.model.lastUpdated,
    };
  }

  /**
   * Run autonomous optimization cycle
   * Analyzes recent performance and adjusts exploration rate
   */
  async runOptimizationCycle(): Promise<{ adjustments: string[]; newExplorationRate: number }> {
    const adjustments: string[] = [];
    
    // Adjust exploration rate based on model accuracy
    if (this.model.accuracy > 0.85) {
      // High accuracy - reduce exploration
      this.explorationRate = Math.max(0.05, this.explorationRate - 0.02);
      adjustments.push(`Reduced exploration rate to ${(this.explorationRate * 100).toFixed(1)}% (high accuracy)`);
    } else if (this.model.accuracy < 0.6) {
      // Low accuracy - increase exploration
      this.explorationRate = Math.min(0.3, this.explorationRate + 0.03);
      adjustments.push(`Increased exploration rate to ${(this.explorationRate * 100).toFixed(1)}% (low accuracy)`);
    }
    
    // Clear stale cache
    this.performanceCache.clear();
    adjustments.push('Cleared performance cache');
    
    return {
      adjustments,
      newExplorationRate: this.explorationRate,
    };
  }
}

// Singleton instance per user
const routerInstances = new Map<number, SelfImprovingTaskRouter>();

export function getTaskRouter(userId: number): SelfImprovingTaskRouter {
  if (!routerInstances.has(userId)) {
    routerInstances.set(userId, new SelfImprovingTaskRouter(userId));
  }
  return routerInstances.get(userId)!;
}
