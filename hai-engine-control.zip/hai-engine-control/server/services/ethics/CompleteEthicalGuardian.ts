/**
 * Complete Ethical Guardian
 * 
 * Protects household well-being using Maslow's hierarchy.
 * Provides gentle pushback on harmful requests.
 * Supports positive behavior change.
 */

import { EventEmitter } from 'events';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

export interface NeedAssessment {
  id: string;
  memberId: number;
  householdId: number;
  timestamp: Date;
  needs: MaslowNeeds;
  overallWellbeing: number; // 0-100
  concerns: WellbeingConcern[];
  recommendations: Recommendation[];
}

export interface MaslowNeeds {
  physiological: NeedLevel;
  safety: NeedLevel;
  belonging: NeedLevel;
  esteem: NeedLevel;
  selfActualization: NeedLevel;
}

export interface NeedLevel {
  score: number; // 0-100
  status: 'critical' | 'unmet' | 'partially_met' | 'met' | 'thriving';
  factors: NeedFactor[];
  lastUpdated: Date;
}

export interface NeedFactor {
  name: string;
  category: string;
  score: number;
  weight: number;
  indicators: string[];
}

export interface WellbeingConcern {
  id: string;
  type: ConcernType;
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  affectedNeeds: (keyof MaslowNeeds)[];
  detectedAt: Date;
  status: 'active' | 'monitoring' | 'addressed' | 'resolved';
  suggestedActions: string[];
}

export type ConcernType =
  | 'sleep_deprivation' | 'poor_nutrition' | 'dehydration'
  | 'sedentary_lifestyle' | 'social_isolation' | 'financial_stress'
  | 'work_life_imbalance' | 'relationship_strain' | 'health_neglect'
  | 'excessive_screen_time' | 'substance_concern' | 'mental_health'
  | 'safety_risk' | 'burnout' | 'grief' | 'anxiety' | 'depression';

export interface Recommendation {
  id: string;
  type: RecommendationType;
  priority: number;
  title: string;
  description: string;
  targetNeed: keyof MaslowNeeds;
  expectedImpact: number;
  effort: 'low' | 'medium' | 'high';
  timeframe: string;
  steps: string[];
  resources?: string[];
}

export type RecommendationType =
  | 'habit' | 'activity' | 'connection' | 'resource'
  | 'professional' | 'lifestyle' | 'mindset';

export interface PushbackDecision {
  id: string;
  requestId: string;
  timestamp: Date;
  originalRequest: string;
  analysis: RequestAnalysis;
  decision: 'allow' | 'pushback' | 'refuse' | 'escalate';
  pushbackType?: PushbackType;
  response: string;
  alternatives?: string[];
  memberId: number;
}

export interface RequestAnalysis {
  harmPotential: HarmAssessment;
  ethicalConcerns: string[];
  affectedParties: string[];
  shortTermImpact: string;
  longTermImpact: string;
  reversibility: boolean;
  alignsWithGoals: boolean;
  alignsWithValues: boolean;
}

export interface HarmAssessment {
  selfHarm: number; // 0-100
  harmToOthers: number;
  financialHarm: number;
  reputationalHarm: number;
  legalRisk: number;
  healthRisk: number;
  relationshipRisk: number;
  overallRisk: number;
}

export type PushbackType =
  | 'gentle_reminder' | 'concern_expression' | 'alternative_suggestion'
  | 'delay_request' | 'information_provision' | 'boundary_setting'
  | 'professional_referral' | 'emergency_intervention';

export interface BehaviorGoal {
  id: string;
  memberId: number;
  householdId: number;
  type: GoalType;
  title: string;
  description: string;
  targetBehavior: string;
  currentState: string;
  desiredState: string;
  motivation: string;
  obstacles: string[];
  strategies: string[];
  milestones: Milestone[];
  progress: number; // 0-100
  status: 'active' | 'paused' | 'completed' | 'abandoned';
  startDate: Date;
  targetDate?: Date;
  checkIns: CheckIn[];
}

export type GoalType =
  | 'health' | 'fitness' | 'nutrition' | 'sleep'
  | 'financial' | 'career' | 'education' | 'relationship'
  | 'hobby' | 'mindfulness' | 'productivity' | 'habit_break';

export interface Milestone {
  id: string;
  title: string;
  description: string;
  targetDate: Date;
  completed: boolean;
  completedAt?: Date;
  celebration?: string;
}

export interface CheckIn {
  id: string;
  timestamp: Date;
  progress: number;
  mood: 'great' | 'good' | 'okay' | 'struggling' | 'bad';
  notes?: string;
  obstacles?: string[];
  wins?: string[];
  nextSteps?: string[];
}

// ============================================================================
// COMPLETE ETHICAL GUARDIAN
// ============================================================================

export class CompleteEthicalGuardian extends EventEmitter {
  private assessments: Map<string, NeedAssessment> = new Map();
  private pushbackHistory: Map<string, PushbackDecision> = new Map();
  private behaviorGoals: Map<string, BehaviorGoal> = new Map();

  constructor() {
    super();
  }

  // -------------------------------------------------------------------------
  // MASLOW NEEDS ASSESSMENT
  // -------------------------------------------------------------------------

  async assessNeeds(memberId: number, householdId: number, data: {
    sleepHours?: number;
    mealsToday?: number;
    waterIntake?: number;
    exerciseMinutes?: number;
    socialInteractions?: number;
    workHours?: number;
    stressLevel?: number;
    financialStability?: number;
    relationshipQuality?: number;
    accomplishments?: string[];
    concerns?: string[];
  }): Promise<NeedAssessment> {
    const needs = this.calculateMaslowNeeds(data);
    const overallWellbeing = this.calculateOverallWellbeing(needs);
    const concerns = this.identifyConcerns(needs, data);
    const recommendations = this.generateRecommendations(needs, concerns);

    const assessment: NeedAssessment = {
      id: this.generateId('assess'),
      memberId,
      householdId,
      timestamp: new Date(),
      needs,
      overallWellbeing,
      concerns,
      recommendations,
    };

    this.assessments.set(assessment.id, assessment);
    this.emit('needs_assessed', assessment);

    // Check for critical concerns
    const criticalConcerns = concerns.filter(c => c.severity === 'critical');
    if (criticalConcerns.length > 0) {
      this.emit('critical_concern_detected', { assessment, concerns: criticalConcerns });
    }

    return assessment;
  }

  private calculateMaslowNeeds(data: any): MaslowNeeds {
    return {
      physiological: this.assessPhysiological(data),
      safety: this.assessSafety(data),
      belonging: this.assessBelonging(data),
      esteem: this.assessEsteem(data),
      selfActualization: this.assessSelfActualization(data),
    };
  }

  private assessPhysiological(data: any): NeedLevel {
    const factors: NeedFactor[] = [];
    let totalScore = 0;
    let totalWeight = 0;

    // Sleep assessment
    const sleepScore = data.sleepHours ? Math.min(100, (data.sleepHours / 8) * 100) : 50;
    factors.push({
      name: 'Sleep',
      category: 'rest',
      score: sleepScore,
      weight: 0.3,
      indicators: data.sleepHours ? [`${data.sleepHours} hours of sleep`] : ['Sleep data not available'],
    });
    totalScore += sleepScore * 0.3;
    totalWeight += 0.3;

    // Nutrition assessment
    const nutritionScore = data.mealsToday ? Math.min(100, (data.mealsToday / 3) * 100) : 50;
    factors.push({
      name: 'Nutrition',
      category: 'food',
      score: nutritionScore,
      weight: 0.25,
      indicators: data.mealsToday ? [`${data.mealsToday} meals today`] : ['Nutrition data not available'],
    });
    totalScore += nutritionScore * 0.25;
    totalWeight += 0.25;

    // Hydration assessment
    const hydrationScore = data.waterIntake ? Math.min(100, (data.waterIntake / 8) * 100) : 50;
    factors.push({
      name: 'Hydration',
      category: 'water',
      score: hydrationScore,
      weight: 0.2,
      indicators: data.waterIntake ? [`${data.waterIntake} glasses of water`] : ['Hydration data not available'],
    });
    totalScore += hydrationScore * 0.2;
    totalWeight += 0.2;

    // Exercise assessment
    const exerciseScore = data.exerciseMinutes ? Math.min(100, (data.exerciseMinutes / 30) * 100) : 50;
    factors.push({
      name: 'Physical Activity',
      category: 'exercise',
      score: exerciseScore,
      weight: 0.25,
      indicators: data.exerciseMinutes ? [`${data.exerciseMinutes} minutes of exercise`] : ['Exercise data not available'],
    });
    totalScore += exerciseScore * 0.25;
    totalWeight += 0.25;

    const finalScore = totalWeight > 0 ? totalScore / totalWeight : 50;

    return {
      score: Math.round(finalScore),
      status: this.getStatus(finalScore),
      factors,
      lastUpdated: new Date(),
    };
  }

  private assessSafety(data: any): NeedLevel {
    const factors: NeedFactor[] = [];
    let totalScore = 0;

    // Financial security
    const financialScore = data.financialStability ?? 50;
    factors.push({
      name: 'Financial Security',
      category: 'financial',
      score: financialScore,
      weight: 0.4,
      indicators: [`Financial stability: ${financialScore}%`],
    });
    totalScore += financialScore * 0.4;

    // Physical safety (assumed from home security status)
    const physicalSafetyScore = 80; // Default assumption
    factors.push({
      name: 'Physical Safety',
      category: 'security',
      score: physicalSafetyScore,
      weight: 0.3,
      indicators: ['Home security active'],
    });
    totalScore += physicalSafetyScore * 0.3;

    // Health security
    const healthScore = data.stressLevel ? 100 - data.stressLevel : 60;
    factors.push({
      name: 'Health Security',
      category: 'health',
      score: healthScore,
      weight: 0.3,
      indicators: data.stressLevel ? [`Stress level: ${data.stressLevel}%`] : ['Health data not available'],
    });
    totalScore += healthScore * 0.3;

    return {
      score: Math.round(totalScore),
      status: this.getStatus(totalScore),
      factors,
      lastUpdated: new Date(),
    };
  }

  private assessBelonging(data: any): NeedLevel {
    const factors: NeedFactor[] = [];
    let totalScore = 0;

    // Social connections
    const socialScore = data.socialInteractions ? Math.min(100, data.socialInteractions * 20) : 50;
    factors.push({
      name: 'Social Connections',
      category: 'social',
      score: socialScore,
      weight: 0.4,
      indicators: data.socialInteractions ? [`${data.socialInteractions} social interactions`] : ['Social data not available'],
    });
    totalScore += socialScore * 0.4;

    // Relationship quality
    const relationshipScore = data.relationshipQuality ?? 60;
    factors.push({
      name: 'Relationship Quality',
      category: 'relationships',
      score: relationshipScore,
      weight: 0.4,
      indicators: [`Relationship quality: ${relationshipScore}%`],
    });
    totalScore += relationshipScore * 0.4;

    // Community involvement
    const communityScore = 60; // Default
    factors.push({
      name: 'Community',
      category: 'community',
      score: communityScore,
      weight: 0.2,
      indicators: ['Community involvement assessed'],
    });
    totalScore += communityScore * 0.2;

    return {
      score: Math.round(totalScore),
      status: this.getStatus(totalScore),
      factors,
      lastUpdated: new Date(),
    };
  }

  private assessEsteem(data: any): NeedLevel {
    const factors: NeedFactor[] = [];
    let totalScore = 0;

    // Accomplishments
    const accomplishmentScore = data.accomplishments?.length ? Math.min(100, data.accomplishments.length * 25) : 50;
    factors.push({
      name: 'Accomplishments',
      category: 'achievement',
      score: accomplishmentScore,
      weight: 0.35,
      indicators: data.accomplishments || ['No recent accomplishments recorded'],
    });
    totalScore += accomplishmentScore * 0.35;

    // Work-life balance
    const workLifeScore = data.workHours ? (data.workHours <= 8 ? 80 : Math.max(20, 100 - (data.workHours - 8) * 10)) : 60;
    factors.push({
      name: 'Work-Life Balance',
      category: 'balance',
      score: workLifeScore,
      weight: 0.35,
      indicators: data.workHours ? [`${data.workHours} work hours`] : ['Work hours not tracked'],
    });
    totalScore += workLifeScore * 0.35;

    // Self-confidence (derived from other factors)
    const confidenceScore = (accomplishmentScore + workLifeScore) / 2;
    factors.push({
      name: 'Self-Confidence',
      category: 'confidence',
      score: confidenceScore,
      weight: 0.3,
      indicators: ['Derived from accomplishments and balance'],
    });
    totalScore += confidenceScore * 0.3;

    return {
      score: Math.round(totalScore),
      status: this.getStatus(totalScore),
      factors,
      lastUpdated: new Date(),
    };
  }

  private assessSelfActualization(data: any): NeedLevel {
    const factors: NeedFactor[] = [];
    
    // This is the hardest to measure - based on goal progress and personal growth
    const growthScore = 60; // Default baseline
    factors.push({
      name: 'Personal Growth',
      category: 'growth',
      score: growthScore,
      weight: 0.5,
      indicators: ['Personal growth activities tracked'],
    });

    const purposeScore = 60;
    factors.push({
      name: 'Sense of Purpose',
      category: 'purpose',
      score: purposeScore,
      weight: 0.5,
      indicators: ['Purpose alignment assessed'],
    });

    const totalScore = (growthScore * 0.5) + (purposeScore * 0.5);

    return {
      score: Math.round(totalScore),
      status: this.getStatus(totalScore),
      factors,
      lastUpdated: new Date(),
    };
  }

  private getStatus(score: number): NeedLevel['status'] {
    if (score >= 90) return 'thriving';
    if (score >= 70) return 'met';
    if (score >= 50) return 'partially_met';
    if (score >= 30) return 'unmet';
    return 'critical';
  }

  private calculateOverallWellbeing(needs: MaslowNeeds): number {
    // Weighted average with lower needs having more weight
    const weights = {
      physiological: 0.3,
      safety: 0.25,
      belonging: 0.2,
      esteem: 0.15,
      selfActualization: 0.1,
    };

    let total = 0;
    for (const [need, weight] of Object.entries(weights)) {
      total += needs[need as keyof MaslowNeeds].score * weight;
    }

    return Math.round(total);
  }

  private identifyConcerns(needs: MaslowNeeds, data: any): WellbeingConcern[] {
    const concerns: WellbeingConcern[] = [];

    // Sleep deprivation
    if (data.sleepHours && data.sleepHours < 6) {
      concerns.push({
        id: this.generateId('concern'),
        type: 'sleep_deprivation',
        severity: data.sleepHours < 4 ? 'critical' : 'high',
        description: `Only ${data.sleepHours} hours of sleep - below recommended 7-9 hours`,
        affectedNeeds: ['physiological', 'safety'],
        detectedAt: new Date(),
        status: 'active',
        suggestedActions: [
          'Set a consistent bedtime',
          'Reduce screen time before bed',
          'Create a relaxing bedtime routine',
        ],
      });
    }

    // Poor nutrition
    if (data.mealsToday !== undefined && data.mealsToday < 2) {
      concerns.push({
        id: this.generateId('concern'),
        type: 'poor_nutrition',
        severity: data.mealsToday === 0 ? 'high' : 'medium',
        description: `Only ${data.mealsToday} meals today - inadequate nutrition`,
        affectedNeeds: ['physiological'],
        detectedAt: new Date(),
        status: 'active',
        suggestedActions: [
          'Set meal reminders',
          'Prepare easy-to-grab healthy snacks',
          'Consider meal prepping',
        ],
      });
    }

    // Social isolation
    if (data.socialInteractions !== undefined && data.socialInteractions === 0) {
      concerns.push({
        id: this.generateId('concern'),
        type: 'social_isolation',
        severity: 'medium',
        description: 'No social interactions recorded today',
        affectedNeeds: ['belonging', 'esteem'],
        detectedAt: new Date(),
        status: 'active',
        suggestedActions: [
          'Reach out to a friend or family member',
          'Join a community activity',
          'Schedule regular social time',
        ],
      });
    }

    // Financial stress
    if (data.financialStability !== undefined && data.financialStability < 40) {
      concerns.push({
        id: this.generateId('concern'),
        type: 'financial_stress',
        severity: data.financialStability < 20 ? 'critical' : 'high',
        description: 'Financial stability is concerning',
        affectedNeeds: ['safety', 'esteem'],
        detectedAt: new Date(),
        status: 'active',
        suggestedActions: [
          'Review and adjust budget',
          'Identify areas to reduce spending',
          'Consider speaking with a financial advisor',
        ],
      });
    }

    // Work-life imbalance
    if (data.workHours && data.workHours > 10) {
      concerns.push({
        id: this.generateId('concern'),
        type: 'work_life_imbalance',
        severity: data.workHours > 12 ? 'high' : 'medium',
        description: `Working ${data.workHours} hours - potential burnout risk`,
        affectedNeeds: ['physiological', 'belonging', 'esteem'],
        detectedAt: new Date(),
        status: 'active',
        suggestedActions: [
          'Set boundaries for work hours',
          'Schedule breaks throughout the day',
          'Prioritize tasks and delegate when possible',
        ],
      });
    }

    // High stress
    if (data.stressLevel && data.stressLevel > 70) {
      concerns.push({
        id: this.generateId('concern'),
        type: 'burnout',
        severity: data.stressLevel > 85 ? 'critical' : 'high',
        description: `Stress level at ${data.stressLevel}% - needs attention`,
        affectedNeeds: ['physiological', 'safety', 'esteem'],
        detectedAt: new Date(),
        status: 'active',
        suggestedActions: [
          'Practice stress-reduction techniques',
          'Take regular breaks',
          'Consider speaking with a professional',
        ],
      });
    }

    return concerns;
  }

  private generateRecommendations(needs: MaslowNeeds, concerns: WellbeingConcern[]): Recommendation[] {
    const recommendations: Recommendation[] = [];

    // Prioritize lower-level needs first (Maslow's hierarchy)
    if (needs.physiological.status === 'critical' || needs.physiological.status === 'unmet') {
      recommendations.push({
        id: this.generateId('rec'),
        type: 'habit',
        priority: 1,
        title: 'Establish Basic Self-Care Routine',
        description: 'Focus on meeting fundamental physical needs',
        targetNeed: 'physiological',
        expectedImpact: 30,
        effort: 'medium',
        timeframe: '1-2 weeks',
        steps: [
          'Set consistent sleep and wake times',
          'Plan and prepare regular meals',
          'Keep water bottle nearby for hydration',
          'Schedule 20-minute daily walks',
        ],
      });
    }

    if (needs.safety.status === 'critical' || needs.safety.status === 'unmet') {
      recommendations.push({
        id: this.generateId('rec'),
        type: 'resource',
        priority: 2,
        title: 'Address Security Concerns',
        description: 'Work on financial and physical safety',
        targetNeed: 'safety',
        expectedImpact: 25,
        effort: 'high',
        timeframe: '1-3 months',
        steps: [
          'Create or review emergency fund',
          'Review insurance coverage',
          'Assess home security measures',
          'Create a financial safety plan',
        ],
      });
    }

    if (needs.belonging.status === 'critical' || needs.belonging.status === 'unmet') {
      recommendations.push({
        id: this.generateId('rec'),
        type: 'connection',
        priority: 3,
        title: 'Strengthen Social Connections',
        description: 'Build and maintain meaningful relationships',
        targetNeed: 'belonging',
        expectedImpact: 20,
        effort: 'medium',
        timeframe: '2-4 weeks',
        steps: [
          'Schedule weekly calls with friends/family',
          'Join a club or group activity',
          'Volunteer in the community',
          'Plan regular family activities',
        ],
      });
    }

    // Add concern-specific recommendations
    for (const concern of concerns) {
      if (concern.severity === 'critical' || concern.severity === 'high') {
        recommendations.push({
          id: this.generateId('rec'),
          type: 'activity',
          priority: concern.severity === 'critical' ? 1 : 2,
          title: `Address ${concern.type.replace(/_/g, ' ')}`,
          description: concern.description,
          targetNeed: concern.affectedNeeds[0],
          expectedImpact: 15,
          effort: 'medium',
          timeframe: '1-2 weeks',
          steps: concern.suggestedActions,
        });
      }
    }

    return recommendations.sort((a, b) => a.priority - b.priority);
  }

  // -------------------------------------------------------------------------
  // PUSHBACK SYSTEM
  // -------------------------------------------------------------------------

  async evaluateRequest(
    request: string,
    memberId: number,
    context?: Record<string, any>
  ): Promise<PushbackDecision> {
    const analysis = this.analyzeRequest(request, context);
    const decision = this.makeDecision(analysis);
    const response = this.generateResponse(request, analysis, decision);

    const pushbackDecision: PushbackDecision = {
      id: this.generateId('pushback'),
      requestId: this.generateId('req'),
      timestamp: new Date(),
      originalRequest: request,
      analysis,
      decision: decision.action,
      pushbackType: decision.pushbackType,
      response,
      alternatives: decision.alternatives,
      memberId,
    };

    this.pushbackHistory.set(pushbackDecision.id, pushbackDecision);
    this.emit('request_evaluated', pushbackDecision);

    return pushbackDecision;
  }

  private analyzeRequest(request: string, context?: Record<string, any>): RequestAnalysis {
    const lowerRequest = request.toLowerCase();

    // Analyze for various harm indicators
    const harmPotential: HarmAssessment = {
      selfHarm: this.assessSelfHarmRisk(lowerRequest),
      harmToOthers: this.assessHarmToOthersRisk(lowerRequest),
      financialHarm: this.assessFinancialHarmRisk(lowerRequest),
      reputationalHarm: this.assessReputationalHarmRisk(lowerRequest),
      legalRisk: this.assessLegalRisk(lowerRequest),
      healthRisk: this.assessHealthRisk(lowerRequest),
      relationshipRisk: this.assessRelationshipRisk(lowerRequest),
      overallRisk: 0,
    };

    // Calculate overall risk
    harmPotential.overallRisk = Math.max(
      harmPotential.selfHarm,
      harmPotential.harmToOthers,
      harmPotential.financialHarm,
      harmPotential.reputationalHarm,
      harmPotential.legalRisk,
      harmPotential.healthRisk,
      harmPotential.relationshipRisk
    );

    return {
      harmPotential,
      ethicalConcerns: this.identifyEthicalConcerns(lowerRequest),
      affectedParties: this.identifyAffectedParties(lowerRequest),
      shortTermImpact: this.assessShortTermImpact(lowerRequest),
      longTermImpact: this.assessLongTermImpact(lowerRequest),
      reversibility: this.assessReversibility(lowerRequest),
      alignsWithGoals: true, // Would check against stored goals
      alignsWithValues: true, // Would check against stored values
    };
  }

  private assessSelfHarmRisk(request: string): number {
    const indicators = ['hurt myself', 'end it', 'give up', 'worthless', 'no point'];
    return indicators.some(i => request.includes(i)) ? 90 : 0;
  }

  private assessHarmToOthersRisk(request: string): number {
    const indicators = ['hurt them', 'revenge', 'make them pay', 'destroy'];
    return indicators.some(i => request.includes(i)) ? 80 : 0;
  }

  private assessFinancialHarmRisk(request: string): number {
    const indicators = ['all my savings', 'max out', 'borrow everything', 'gamble'];
    return indicators.some(i => request.includes(i)) ? 70 : 0;
  }

  private assessReputationalHarmRisk(request: string): number {
    const indicators = ['expose', 'embarrass', 'ruin reputation', 'spread rumors'];
    return indicators.some(i => request.includes(i)) ? 60 : 0;
  }

  private assessLegalRisk(request: string): number {
    const indicators = ['illegal', 'break the law', 'hack', 'steal'];
    return indicators.some(i => request.includes(i)) ? 85 : 0;
  }

  private assessHealthRisk(request: string): number {
    const indicators = ['skip medication', 'ignore symptoms', 'dangerous diet', 'excessive'];
    return indicators.some(i => request.includes(i)) ? 50 : 0;
  }

  private assessRelationshipRisk(request: string): number {
    const indicators = ['cut off', 'never speak', 'divorce', 'abandon'];
    return indicators.some(i => request.includes(i)) ? 40 : 0;
  }

  private identifyEthicalConcerns(request: string): string[] {
    const concerns: string[] = [];
    if (request.includes('lie') || request.includes('deceive')) concerns.push('Honesty');
    if (request.includes('hide') || request.includes('secret')) concerns.push('Transparency');
    if (request.includes('without permission')) concerns.push('Consent');
    return concerns;
  }

  private identifyAffectedParties(request: string): string[] {
    const parties: string[] = ['Self'];
    if (request.includes('family') || request.includes('spouse') || request.includes('kids')) {
      parties.push('Family');
    }
    if (request.includes('work') || request.includes('colleague') || request.includes('boss')) {
      parties.push('Work');
    }
    return parties;
  }

  private assessShortTermImpact(request: string): string {
    return 'Immediate effects being evaluated';
  }

  private assessLongTermImpact(request: string): string {
    return 'Long-term consequences being considered';
  }

  private assessReversibility(request: string): boolean {
    const irreversibleIndicators = ['permanent', 'forever', 'never again', 'final'];
    return !irreversibleIndicators.some(i => request.includes(i));
  }

  private makeDecision(analysis: RequestAnalysis): {
    action: PushbackDecision['decision'];
    pushbackType?: PushbackType;
    alternatives?: string[];
  } {
    const risk = analysis.harmPotential.overallRisk;

    if (risk >= 80) {
      return {
        action: analysis.harmPotential.selfHarm >= 80 ? 'escalate' : 'refuse',
        pushbackType: 'emergency_intervention',
        alternatives: ['Please speak with someone who can help', 'Consider professional support'],
      };
    }

    if (risk >= 60) {
      return {
        action: 'pushback',
        pushbackType: 'concern_expression',
        alternatives: ['Consider the potential consequences', 'Perhaps we can find a safer approach'],
      };
    }

    if (risk >= 40) {
      return {
        action: 'pushback',
        pushbackType: 'gentle_reminder',
        alternatives: ['Have you considered...', 'Another option might be...'],
      };
    }

    if (analysis.ethicalConcerns.length > 0) {
      return {
        action: 'pushback',
        pushbackType: 'information_provision',
        alternatives: ['Here are some things to consider...'],
      };
    }

    return { action: 'allow' };
  }

  private generateResponse(
    request: string,
    analysis: RequestAnalysis,
    decision: { action: string; pushbackType?: PushbackType; alternatives?: string[] }
  ): string {
    switch (decision.action) {
      case 'allow':
        return "I'll help you with that.";
      case 'pushback':
        switch (decision.pushbackType) {
          case 'gentle_reminder':
            return "I want to help, but I noticed this might have some unintended effects. Have you considered the potential impact?";
          case 'concern_expression':
            return "I care about your wellbeing, and I'm a bit concerned about this request. Can we talk about what's driving this?";
          case 'alternative_suggestion':
            return `I understand what you're trying to achieve. Would you consider this alternative approach instead? ${decision.alternatives?.[0] || ''}`;
          case 'information_provision':
            return "Before we proceed, I think it's important to consider some factors that might affect the outcome.";
          default:
            return "I want to make sure this is the best approach. Can we discuss it further?";
        }
      case 'refuse':
        return "I'm not able to help with this request as it could cause harm. I care about your wellbeing and the wellbeing of others.";
      case 'escalate':
        return "I'm concerned about what you've shared. This seems like something that would benefit from professional support. Would you like me to help connect you with resources?";
      default:
        return "Let me think about the best way to help with this.";
    }
  }

  // -------------------------------------------------------------------------
  // BEHAVIOR CHANGE SUPPORT
  // -------------------------------------------------------------------------

  async createBehaviorGoal(
    memberId: number,
    householdId: number,
    goalData: {
      type: GoalType;
      title: string;
      description: string;
      targetBehavior: string;
      currentState: string;
      desiredState: string;
      motivation: string;
      targetDate?: Date;
    }
  ): Promise<BehaviorGoal> {
    const goal: BehaviorGoal = {
      id: this.generateId('goal'),
      memberId,
      householdId,
      type: goalData.type,
      title: goalData.title,
      description: goalData.description,
      targetBehavior: goalData.targetBehavior,
      currentState: goalData.currentState,
      desiredState: goalData.desiredState,
      motivation: goalData.motivation,
      obstacles: [],
      strategies: this.generateStrategies(goalData.type, goalData.targetBehavior),
      milestones: this.generateMilestones(goalData),
      progress: 0,
      status: 'active',
      startDate: new Date(),
      targetDate: goalData.targetDate,
      checkIns: [],
    };

    this.behaviorGoals.set(goal.id, goal);
    this.emit('goal_created', goal);

    return goal;
  }

  private generateStrategies(type: GoalType, targetBehavior: string): string[] {
    const baseStrategies: Record<GoalType, string[]> = {
      health: [
        'Start with small, achievable changes',
        'Track progress daily',
        'Celebrate small wins',
        'Find an accountability partner',
      ],
      fitness: [
        'Schedule workouts like appointments',
        'Start with 10-minute sessions',
        'Find activities you enjoy',
        'Track your progress',
      ],
      nutrition: [
        'Plan meals in advance',
        'Keep healthy snacks available',
        'Practice mindful eating',
        'Stay hydrated',
      ],
      sleep: [
        'Set a consistent bedtime',
        'Create a relaxing routine',
        'Limit screen time before bed',
        'Keep your bedroom cool and dark',
      ],
      financial: [
        'Track all expenses',
        'Set up automatic savings',
        'Review subscriptions monthly',
        'Use the 24-hour rule for purchases',
      ],
      career: [
        'Set specific, measurable goals',
        'Seek feedback regularly',
        'Build your network',
        'Invest in learning',
      ],
      education: [
        'Break learning into small chunks',
        'Use spaced repetition',
        'Teach others what you learn',
        'Apply knowledge practically',
      ],
      relationship: [
        'Schedule quality time',
        'Practice active listening',
        'Express appreciation daily',
        'Address issues promptly',
      ],
      hobby: [
        'Schedule dedicated time',
        'Join a community',
        'Set small challenges',
        'Share your progress',
      ],
      mindfulness: [
        'Start with 5 minutes daily',
        'Use guided meditations',
        'Practice throughout the day',
        'Be patient with yourself',
      ],
      productivity: [
        'Use time blocking',
        'Eliminate distractions',
        'Take regular breaks',
        'Prioritize ruthlessly',
      ],
      habit_break: [
        'Identify triggers',
        'Replace with positive alternatives',
        'Remove temptations',
        'Get support from others',
      ],
    };

    return baseStrategies[type] || baseStrategies.health;
  }

  private generateMilestones(goalData: any): Milestone[] {
    const milestones: Milestone[] = [];
    const now = new Date();

    // Week 1 milestone
    milestones.push({
      id: this.generateId('mile'),
      title: 'First Week Complete',
      description: 'Successfully maintained focus for one week',
      targetDate: new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000),
      completed: false,
      celebration: 'Treat yourself to something small you enjoy!',
    });

    // Month 1 milestone
    milestones.push({
      id: this.generateId('mile'),
      title: 'One Month Progress',
      description: 'Maintained consistent effort for a full month',
      targetDate: new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000),
      completed: false,
      celebration: 'Share your progress with someone who supports you!',
    });

    // Halfway milestone (if target date provided)
    if (goalData.targetDate) {
      const halfway = new Date((now.getTime() + new Date(goalData.targetDate).getTime()) / 2);
      milestones.push({
        id: this.generateId('mile'),
        title: 'Halfway There',
        description: 'Reached the midpoint of your journey',
        targetDate: halfway,
        completed: false,
        celebration: 'Reflect on how far you\'ve come!',
      });
    }

    return milestones;
  }

  async recordCheckIn(
    goalId: string,
    checkInData: {
      progress: number;
      mood: CheckIn['mood'];
      notes?: string;
      obstacles?: string[];
      wins?: string[];
    }
  ): Promise<CheckIn> {
    const goal = this.behaviorGoals.get(goalId);
    if (!goal) throw new Error('Goal not found');

    const checkIn: CheckIn = {
      id: this.generateId('checkin'),
      timestamp: new Date(),
      progress: checkInData.progress,
      mood: checkInData.mood,
      notes: checkInData.notes,
      obstacles: checkInData.obstacles,
      wins: checkInData.wins,
      nextSteps: this.generateNextSteps(goal, checkInData),
    };

    goal.checkIns.push(checkIn);
    goal.progress = checkInData.progress;

    // Check milestones
    for (const milestone of goal.milestones) {
      if (!milestone.completed && new Date() >= milestone.targetDate) {
        milestone.completed = true;
        milestone.completedAt = new Date();
        this.emit('milestone_completed', { goal, milestone });
      }
    }

    // Update goal status
    if (goal.progress >= 100) {
      goal.status = 'completed';
      this.emit('goal_completed', goal);
    }

    this.emit('check_in_recorded', { goal, checkIn });

    return checkIn;
  }

  private generateNextSteps(goal: BehaviorGoal, checkIn: any): string[] {
    const steps: string[] = [];

    if (checkIn.mood === 'struggling' || checkIn.mood === 'bad') {
      steps.push('Be kind to yourself - setbacks are part of the journey');
      steps.push('Consider what might be causing the difficulty');
      steps.push('Reach out for support if needed');
    } else if (checkIn.mood === 'great' || checkIn.mood === 'good') {
      steps.push('Keep up the great work!');
      steps.push('Consider increasing your challenge slightly');
    }

    if (checkIn.obstacles?.length) {
      steps.push('Address the obstacles you identified');
    }

    return steps;
  }

  // -------------------------------------------------------------------------
  // QUERIES
  // -------------------------------------------------------------------------

  getLatestAssessment(memberId: number): NeedAssessment | undefined {
    return Array.from(this.assessments.values())
      .filter(a => a.memberId === memberId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())[0];
  }

  getActiveGoals(memberId: number): BehaviorGoal[] {
    return Array.from(this.behaviorGoals.values())
      .filter(g => g.memberId === memberId && g.status === 'active');
  }

  getPushbackHistory(memberId: number, limit: number = 20): PushbackDecision[] {
    return Array.from(this.pushbackHistory.values())
      .filter(p => p.memberId === memberId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  getWellbeingTrends(memberId: number): {
    current: number;
    trend: 'improving' | 'stable' | 'declining';
    history: Array<{ date: Date; score: number }>;
  } {
    const assessments = Array.from(this.assessments.values())
      .filter(a => a.memberId === memberId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

    if (assessments.length === 0) {
      return { current: 50, trend: 'stable', history: [] };
    }

    const current = assessments[0].overallWellbeing;
    const history = assessments.map(a => ({ date: a.timestamp, score: a.overallWellbeing }));

    let trend: 'improving' | 'stable' | 'declining' = 'stable';
    if (assessments.length >= 2) {
      const diff = assessments[0].overallWellbeing - assessments[1].overallWellbeing;
      if (diff > 5) trend = 'improving';
      else if (diff < -5) trend = 'declining';
    }

    return { current, trend, history };
  }

  // -------------------------------------------------------------------------
  // HELPERS
  // -------------------------------------------------------------------------

  private generateId(prefix: string): string {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

export const completeEthicalGuardian = new CompleteEthicalGuardian();
