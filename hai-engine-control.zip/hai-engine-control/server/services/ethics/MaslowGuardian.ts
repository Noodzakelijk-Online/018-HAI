/**
 * ETHICAL FRAMEWORK: Maslow Guardian
 * 
 * Ensures HAI prioritizes human well-being using Maslow's hierarchy:
 * 1. Physiological (food, water, shelter, sleep)
 * 2. Safety (security, health, financial stability)
 * 3. Love/Belonging (relationships, family)
 * 4. Esteem (achievement, respect)
 * 5. Self-actualization (growth, fulfillment)
 */

export type MaslowLevel = 'physiological' | 'safety' | 'belonging' | 'esteem' | 'self_actualization';
export type NeedStatus = 'critical' | 'at_risk' | 'stable' | 'thriving';

export interface NeedAssessment {
  id: number;
  householdId: number;
  memberId: number;
  level: MaslowLevel;
  category: string;
  status: NeedStatus;
  score: number; // 0-100
  indicators: Array<{ name: string; value: number; weight: number }>;
  concerns: string[];
  recommendations: string[];
  lastAssessedAt: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface WellbeingSnapshot {
  householdId: number;
  memberId: number;
  timestamp: Date;
  overallScore: number;
  byLevel: Record<MaslowLevel, { score: number; status: NeedStatus }>;
  topConcerns: string[];
  improvements: string[];
}

export interface PushbackEvent {
  id: number;
  householdId: number;
  memberId?: number;
  requestType: string;
  requestDetails: string;
  pushbackReason: string;
  severity: 'gentle' | 'moderate' | 'strong';
  response: string;
  wasOverridden: boolean;
  createdAt: Date;
}

export interface BehaviorGoal {
  id: number;
  householdId: number;
  memberId: number;
  category: string;
  title: string;
  description: string;
  targetValue?: number;
  currentValue?: number;
  unit?: string;
  startDate: Date;
  targetDate?: Date;
  status: 'active' | 'completed' | 'paused' | 'abandoned';
  milestones: Array<{ title: string; completed: boolean; completedAt?: Date }>;
  encouragements: string[];
  createdAt: Date;
  updatedAt: Date;
}

const assessmentStore: Map<number, NeedAssessment> = new Map();
const pushbackStore: Map<number, PushbackEvent> = new Map();
const goalStore: Map<number, BehaviorGoal> = new Map();
let assessmentIdCounter = 1;
let pushbackIdCounter = 1;
let goalIdCounter = 1;

export class MaslowGuardianService {
  private static instance: MaslowGuardianService;
  private constructor() {}
  static getInstance(): MaslowGuardianService {
    if (!MaslowGuardianService.instance) {
      MaslowGuardianService.instance = new MaslowGuardianService();
    }
    return MaslowGuardianService.instance;
  }

  // ============================================================================
  // NEED ASSESSMENT
  // ============================================================================

  async assessNeed(householdId: number, memberId: number, data: {
    level: MaslowLevel;
    category: string;
    indicators: Array<{ name: string; value: number; weight: number }>;
  }): Promise<NeedAssessment> {
    const totalWeight = data.indicators.reduce((sum, i) => sum + i.weight, 0);
    const score = data.indicators.reduce((sum, i) => sum + (i.value * i.weight), 0) / (totalWeight || 1);
    
    const status: NeedStatus = score >= 80 ? 'thriving' : score >= 60 ? 'stable' : score >= 40 ? 'at_risk' : 'critical';
    
    const concerns: string[] = [];
    const recommendations: string[] = [];
    
    for (const indicator of data.indicators) {
      if (indicator.value < 50) {
        concerns.push(`Low ${indicator.name} score (${indicator.value})`);
        recommendations.push(`Consider improving ${indicator.name}`);
      }
    }

    const assessment: NeedAssessment = {
      id: assessmentIdCounter++,
      householdId,
      memberId,
      level: data.level,
      category: data.category,
      status,
      score,
      indicators: data.indicators,
      concerns,
      recommendations,
      lastAssessedAt: new Date(),
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    assessmentStore.set(assessment.id, assessment);
    return assessment;
  }

  async getWellbeingSnapshot(householdId: number, memberId: number): Promise<WellbeingSnapshot> {
    const assessments = Array.from(assessmentStore.values())
      .filter(a => a.householdId === householdId && a.memberId === memberId);

    const byLevel: Record<MaslowLevel, { score: number; status: NeedStatus }> = {
      physiological: { score: 75, status: 'stable' },
      safety: { score: 80, status: 'thriving' },
      belonging: { score: 70, status: 'stable' },
      esteem: { score: 65, status: 'stable' },
      self_actualization: { score: 60, status: 'stable' },
    };

    for (const assessment of assessments) {
      byLevel[assessment.level] = { score: assessment.score, status: assessment.status };
    }

    const scores = Object.values(byLevel).map(l => l.score);
    const overallScore = scores.reduce((a, b) => a + b, 0) / scores.length;

    const topConcerns = assessments.flatMap(a => a.concerns).slice(0, 5);
    const improvements = assessments.flatMap(a => a.recommendations).slice(0, 5);

    return {
      householdId,
      memberId,
      timestamp: new Date(),
      overallScore,
      byLevel,
      topConcerns,
      improvements,
    };
  }

  async getAssessments(householdId: number, memberId?: number, level?: MaslowLevel): Promise<NeedAssessment[]> {
    let assessments = Array.from(assessmentStore.values()).filter(a => a.householdId === householdId);
    if (memberId) assessments = assessments.filter(a => a.memberId === memberId);
    if (level) assessments = assessments.filter(a => a.level === level);
    return assessments.sort((a, b) => b.lastAssessedAt.getTime() - a.lastAssessedAt.getTime());
  }

  // ============================================================================
  // PUSHBACK SYSTEM
  // ============================================================================

  async recordPushback(householdId: number, data: {
    memberId?: number;
    requestType: string;
    requestDetails: string;
    pushbackReason: string;
    severity: 'gentle' | 'moderate' | 'strong';
    response: string;
  }): Promise<PushbackEvent> {
    const event: PushbackEvent = {
      id: pushbackIdCounter++,
      householdId,
      memberId: data.memberId,
      requestType: data.requestType,
      requestDetails: data.requestDetails,
      pushbackReason: data.pushbackReason,
      severity: data.severity,
      response: data.response,
      wasOverridden: false,
      createdAt: new Date(),
    };

    pushbackStore.set(event.id, event);
    return event;
  }

  async evaluateRequest(request: { type: string; details: string; memberId?: number }): Promise<{
    shouldPushback: boolean;
    reason?: string;
    severity?: 'gentle' | 'moderate' | 'strong';
    suggestedResponse?: string;
  }> {
    // Simple heuristic-based evaluation
    const harmfulPatterns = [
      { pattern: /excessive spending/i, reason: 'Financial well-being concern', severity: 'gentle' as const },
      { pattern: /skip (meal|sleep)/i, reason: 'Physiological needs concern', severity: 'moderate' as const },
      { pattern: /ignore (family|friend)/i, reason: 'Social connection concern', severity: 'gentle' as const },
      { pattern: /dangerous/i, reason: 'Safety concern', severity: 'strong' as const },
    ];

    for (const { pattern, reason, severity } of harmfulPatterns) {
      if (pattern.test(request.details)) {
        return {
          shouldPushback: true,
          reason,
          severity,
          suggestedResponse: `I notice this might affect your ${reason.toLowerCase()}. Would you like to discuss alternatives?`,
        };
      }
    }

    return { shouldPushback: false };
  }

  async getPushbackHistory(householdId: number, limit?: number): Promise<PushbackEvent[]> {
    const events = Array.from(pushbackStore.values())
      .filter(e => e.householdId === householdId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    return limit ? events.slice(0, limit) : events;
  }

  // ============================================================================
  // BEHAVIOR CHANGE SUPPORT
  // ============================================================================

  async createGoal(householdId: number, memberId: number, data: {
    category: string;
    title: string;
    description: string;
    targetValue?: number;
    unit?: string;
    targetDate?: Date;
    milestones?: Array<{ title: string }>;
  }): Promise<BehaviorGoal> {
    const goal: BehaviorGoal = {
      id: goalIdCounter++,
      householdId,
      memberId,
      category: data.category,
      title: data.title,
      description: data.description,
      targetValue: data.targetValue,
      currentValue: 0,
      unit: data.unit,
      startDate: new Date(),
      targetDate: data.targetDate,
      status: 'active',
      milestones: data.milestones?.map(m => ({ title: m.title, completed: false })) || [],
      encouragements: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    goalStore.set(goal.id, goal);
    return goal;
  }

  async updateGoalProgress(goalId: number, progress: { currentValue?: number; milestoneIndex?: number }): Promise<BehaviorGoal | undefined> {
    const goal = goalStore.get(goalId);
    if (!goal) return undefined;

    if (progress.currentValue !== undefined) {
      goal.currentValue = progress.currentValue;
      
      // Generate encouragement based on progress
      const percentage = goal.targetValue ? (goal.currentValue / goal.targetValue) * 100 : 0;
      if (percentage >= 25 && !goal.encouragements.includes('25%')) {
        goal.encouragements.push('25%');
      }
      if (percentage >= 50 && !goal.encouragements.includes('50%')) {
        goal.encouragements.push('50%');
      }
      if (percentage >= 75 && !goal.encouragements.includes('75%')) {
        goal.encouragements.push('75%');
      }
      if (percentage >= 100) {
        goal.status = 'completed';
        goal.encouragements.push('100%');
      }
    }

    if (progress.milestoneIndex !== undefined && goal.milestones[progress.milestoneIndex]) {
      goal.milestones[progress.milestoneIndex].completed = true;
      goal.milestones[progress.milestoneIndex].completedAt = new Date();
    }

    goal.updatedAt = new Date();
    return goal;
  }

  async getGoals(householdId: number, memberId?: number, status?: BehaviorGoal['status']): Promise<BehaviorGoal[]> {
    let goals = Array.from(goalStore.values()).filter(g => g.householdId === householdId);
    if (memberId) goals = goals.filter(g => g.memberId === memberId);
    if (status) goals = goals.filter(g => g.status === status);
    return goals.sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime());
  }

  async getGoal(goalId: number): Promise<BehaviorGoal | undefined> {
    return goalStore.get(goalId);
  }

  // ============================================================================
  // STATISTICS
  // ============================================================================

  async getStatistics(householdId: number): Promise<{
    assessmentCount: number;
    avgWellbeingScore: number;
    criticalNeeds: number;
    pushbackCount: number;
    pushbackOverrideRate: number;
    activeGoals: number;
    completedGoals: number;
    goalCompletionRate: number;
  }> {
    const assessments = Array.from(assessmentStore.values()).filter(a => a.householdId === householdId);
    const pushbacks = Array.from(pushbackStore.values()).filter(p => p.householdId === householdId);
    const goals = Array.from(goalStore.values()).filter(g => g.householdId === householdId);

    const avgScore = assessments.length > 0 ? assessments.reduce((sum, a) => sum + a.score, 0) / assessments.length : 75;
    const overridden = pushbacks.filter(p => p.wasOverridden).length;
    const completed = goals.filter(g => g.status === 'completed').length;
    const total = goals.filter(g => g.status !== 'active').length;

    return {
      assessmentCount: assessments.length,
      avgWellbeingScore: avgScore,
      criticalNeeds: assessments.filter(a => a.status === 'critical').length,
      pushbackCount: pushbacks.length,
      pushbackOverrideRate: pushbacks.length > 0 ? overridden / pushbacks.length : 0,
      activeGoals: goals.filter(g => g.status === 'active').length,
      completedGoals: completed,
      goalCompletionRate: total > 0 ? completed / total : 0,
    };
  }
}

export const maslowGuardianService = MaslowGuardianService.getInstance();
