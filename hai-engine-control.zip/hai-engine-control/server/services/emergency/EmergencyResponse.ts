/**
 * EMERGENCY RESPONSE SYSTEM
 * 
 * Handles critical situations requiring immediate action
 */

export type EmergencyType = 'medical' | 'security' | 'fire' | 'flood' | 'power_outage' | 'gas_leak' | 'intrusion' | 'child_safety' | 'elderly_care' | 'financial_fraud' | 'custom';
export type EmergencySeverity = 'critical' | 'high' | 'medium' | 'low';
export type EmergencyStatus = 'detected' | 'acknowledged' | 'responding' | 'resolved' | 'escalated' | 'false_alarm';

export interface EmergencyEvent {
  id: number;
  householdId: number;
  type: EmergencyType;
  severity: EmergencySeverity;
  title: string;
  description: string;
  detectedAt: Date;
  detectionSource: string;
  detectionConfidence: number;
  location?: { area: string; device?: string };
  status: EmergencyStatus;
  acknowledgedAt?: Date;
  acknowledgedBy?: number;
  resolvedAt?: Date;
  actionsTriggered: string[];
  contactsNotified: number[];
  escalationLevel: number;
  notes: string[];
  createdAt: Date;
  updatedAt: Date;
}

export interface EmergencyProtocol {
  id: number;
  householdId: number;
  name: string;
  emergencyType: EmergencyType;
  severity: EmergencySeverity;
  triggers: Array<{ source: string; condition: string; threshold?: number }>;
  actions: Array<{ order: number; type: string; target: string; message?: string; delay?: number }>;
  escalationRules: Array<{ afterMinutes: number; action: string; target: string }>;
  isActive: boolean;
  lastTriggeredAt?: Date;
  triggerCount: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface EmergencyContact {
  id: number;
  householdId: number;
  name: string;
  relationship: string;
  phone: string;
  email?: string;
  priority: number;
  emergencyTypes: EmergencyType[];
  isAvailable: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const eventStore: Map<number, EmergencyEvent> = new Map();
const protocolStore: Map<number, EmergencyProtocol> = new Map();
const contactStore: Map<number, EmergencyContact> = new Map();
let eventIdCounter = 1;
let protocolIdCounter = 1;
let contactIdCounter = 1;

export class EmergencyResponseService {
  private static instance: EmergencyResponseService;
  private constructor() { this.initDefaults(); }
  static getInstance(): EmergencyResponseService {
    if (!EmergencyResponseService.instance) {
      EmergencyResponseService.instance = new EmergencyResponseService();
    }
    return EmergencyResponseService.instance;
  }

  private initDefaults(): void {
    const id = protocolIdCounter++;
    protocolStore.set(id, {
      id, householdId: 0, name: 'Medical Emergency', emergencyType: 'medical', severity: 'critical',
      triggers: [{ source: 'voice_command', condition: 'contains' }],
      actions: [{ order: 1, type: 'notify', target: 'all_members', message: 'Medical emergency!' }],
      escalationRules: [{ afterMinutes: 5, action: 'call', target: '911' }],
      isActive: true, triggerCount: 0, createdAt: new Date(), updatedAt: new Date(),
    });
  }

  async reportEmergency(householdId: number, data: { type: EmergencyType; severity: EmergencySeverity; title: string; description: string; detectionSource: string; detectionConfidence?: number; location?: { area: string; device?: string } }): Promise<EmergencyEvent> {
    const event: EmergencyEvent = {
      id: eventIdCounter++, householdId, type: data.type, severity: data.severity, title: data.title, description: data.description,
      detectedAt: new Date(), detectionSource: data.detectionSource, detectionConfidence: data.detectionConfidence || 1,
      location: data.location, status: 'detected', actionsTriggered: [], contactsNotified: [], escalationLevel: 0, notes: [],
      createdAt: new Date(), updatedAt: new Date(),
    };
    eventStore.set(event.id, event);
    return event;
  }

  async acknowledgeEmergency(eventId: number, userId: number): Promise<EmergencyEvent | undefined> {
    const event = eventStore.get(eventId);
    if (!event) return undefined;
    event.status = 'acknowledged'; event.acknowledgedAt = new Date(); event.acknowledgedBy = userId; event.updatedAt = new Date();
    return event;
  }

  async resolveEmergency(eventId: number, userId: number, resolution: { isFalseAlarm?: boolean; notes?: string }): Promise<EmergencyEvent | undefined> {
    const event = eventStore.get(eventId);
    if (!event) return undefined;
    event.status = resolution.isFalseAlarm ? 'false_alarm' : 'resolved'; event.resolvedAt = new Date(); event.updatedAt = new Date();
    if (resolution.notes) event.notes.push(resolution.notes);
    return event;
  }

  async escalateEmergency(eventId: number): Promise<EmergencyEvent | undefined> {
    const event = eventStore.get(eventId);
    if (!event) return undefined;
    event.escalationLevel++; event.status = 'escalated'; event.updatedAt = new Date();
    return event;
  }

  async createProtocol(householdId: number, data: Omit<EmergencyProtocol, 'id' | 'householdId' | 'createdAt' | 'updatedAt' | 'lastTriggeredAt' | 'triggerCount'>): Promise<EmergencyProtocol> {
    const protocol: EmergencyProtocol = { id: protocolIdCounter++, householdId, ...data, triggerCount: 0, createdAt: new Date(), updatedAt: new Date() };
    protocolStore.set(protocol.id, protocol);
    return protocol;
  }

  async getActiveProtocols(householdId: number, type?: EmergencyType): Promise<EmergencyProtocol[]> {
    let protocols = Array.from(protocolStore.values()).filter(p => p.isActive && (p.householdId === 0 || p.householdId === householdId));
    if (type) protocols = protocols.filter(p => p.emergencyType === type);
    return protocols;
  }

  async addContact(householdId: number, data: Omit<EmergencyContact, 'id' | 'householdId' | 'createdAt' | 'updatedAt'>): Promise<EmergencyContact> {
    const contact: EmergencyContact = { id: contactIdCounter++, householdId, ...data, createdAt: new Date(), updatedAt: new Date() };
    contactStore.set(contact.id, contact);
    return contact;
  }

  async getContacts(householdId: number, type?: EmergencyType): Promise<EmergencyContact[]> {
    let contacts = Array.from(contactStore.values()).filter(c => c.householdId === householdId);
    if (type) contacts = contacts.filter(c => c.emergencyTypes.includes(type));
    return contacts.sort((a, b) => a.priority - b.priority);
  }

  async getEmergency(eventId: number): Promise<EmergencyEvent | undefined> { return eventStore.get(eventId); }

  async getEmergencies(householdId: number, options?: { status?: EmergencyStatus; type?: EmergencyType; limit?: number }): Promise<EmergencyEvent[]> {
    let events = Array.from(eventStore.values()).filter(e => e.householdId === householdId);
    if (options?.status) events = events.filter(e => e.status === options.status);
    if (options?.type) events = events.filter(e => e.type === options.type);
    events.sort((a, b) => b.detectedAt.getTime() - a.detectedAt.getTime());
    return options?.limit ? events.slice(0, options.limit) : events;
  }

  async getStatistics(householdId: number): Promise<{ totalEvents: number; activeEvents: number; resolvedEvents: number; falseAlarms: number; byType: Record<EmergencyType, number>; bySeverity: Record<EmergencySeverity, number>; protocolCount: number; contactCount: number }> {
    const events = Array.from(eventStore.values()).filter(e => e.householdId === householdId);
    const protocols = await this.getActiveProtocols(householdId);
    const contacts = await this.getContacts(householdId);
    const byType: Record<EmergencyType, number> = { medical: 0, security: 0, fire: 0, flood: 0, power_outage: 0, gas_leak: 0, intrusion: 0, child_safety: 0, elderly_care: 0, financial_fraud: 0, custom: 0 };
    const bySeverity: Record<EmergencySeverity, number> = { critical: 0, high: 0, medium: 0, low: 0 };
    for (const event of events) { byType[event.type]++; bySeverity[event.severity]++; }
    const activeStatuses: EmergencyStatus[] = ['detected', 'acknowledged', 'responding', 'escalated'];
    return {
      totalEvents: events.length, activeEvents: events.filter(e => activeStatuses.includes(e.status)).length,
      resolvedEvents: events.filter(e => e.status === 'resolved').length, falseAlarms: events.filter(e => e.status === 'false_alarm').length,
      byType, bySeverity, protocolCount: protocols.length, contactCount: contacts.length,
    };
  }
}

export const emergencyResponseService = EmergencyResponseService.getInstance();
