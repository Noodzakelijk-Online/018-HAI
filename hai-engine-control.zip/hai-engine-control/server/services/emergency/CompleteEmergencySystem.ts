/**
 * Complete Emergency & Crisis System
 * 
 * Handles EVERY type of emergency from fire to medical to financial crisis.
 * HAI protects the household 24/7 with intelligent escalation.
 */

import { EventEmitter } from 'events';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

export interface Emergency {
  id: string;
  type: EmergencyType;
  category: EmergencyCategory;
  severity: EmergencySeverity;
  status: EmergencyStatus;
  title: string;
  description: string;
  detectedAt: Date;
  acknowledgedAt?: Date;
  resolvedAt?: Date;
  source: EmergencySource;
  location?: EmergencyLocation;
  affectedMembers: number[];
  triggers: EmergencyTrigger[];
  actions: EmergencyAction[];
  escalations: Escalation[];
  timeline: TimelineEvent[];
  metadata: Record<string, any>;
  householdId: number;
}

export type EmergencyType =
  // Life Safety
  | 'fire' | 'carbon_monoxide' | 'gas_leak' | 'smoke'
  | 'intrusion' | 'break_in' | 'suspicious_activity'
  | 'medical' | 'fall' | 'unresponsive' | 'chest_pain' | 'breathing'
  | 'child_emergency' | 'elderly_emergency'
  // Environmental
  | 'flood' | 'water_leak' | 'pipe_burst'
  | 'severe_weather' | 'tornado' | 'hurricane' | 'earthquake'
  | 'power_outage' | 'utility_failure'
  | 'temperature_extreme' | 'hvac_failure'
  // Security
  | 'alarm_triggered' | 'door_forced' | 'window_broken'
  | 'vehicle_theft' | 'package_theft'
  | 'cyber_attack' | 'account_breach'
  // Financial
  | 'fraud_detected' | 'unusual_transaction' | 'identity_theft'
  | 'overdraft' | 'payment_failure' | 'collection_notice'
  // Personal Safety
  | 'missing_person' | 'late_arrival' | 'no_check_in'
  | 'distress_signal' | 'panic_button'
  // Infrastructure
  | 'appliance_failure' | 'structural_damage' | 'roof_leak'
  | 'pest_infestation' | 'mold_detected';

export type EmergencyCategory =
  | 'life_safety' | 'security' | 'environmental'
  | 'financial' | 'health' | 'infrastructure';

export type EmergencySeverity =
  | 'critical' | 'high' | 'medium' | 'low';

export type EmergencyStatus =
  | 'detected' | 'acknowledged' | 'responding'
  | 'contained' | 'resolved' | 'false_alarm';

export interface EmergencySource {
  type: 'sensor' | 'device' | 'service' | 'member' | 'external' | 'ai_detection';
  id: string;
  name: string;
  confidence: number;
}

export interface EmergencyLocation {
  area: string;
  room?: string;
  coordinates?: { lat: number; lng: number };
  address?: string;
}

export interface EmergencyTrigger {
  type: string;
  value: any;
  threshold?: any;
  timestamp: Date;
}

export interface EmergencyAction {
  id: string;
  type: EmergencyActionType;
  description: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  automated: boolean;
  priority: number;
  executedAt?: Date;
  result?: string;
}

export type EmergencyActionType =
  | 'alert_member' | 'alert_all' | 'call_emergency_services'
  | 'notify_contact' | 'activate_alarm' | 'lock_doors'
  | 'unlock_doors' | 'turn_off_gas' | 'turn_off_water'
  | 'turn_on_lights' | 'record_video' | 'take_snapshot'
  | 'send_location' | 'play_announcement' | 'dispatch_help'
  | 'freeze_accounts' | 'change_passwords' | 'backup_data';

export interface Escalation {
  level: number;
  triggeredAt: Date;
  reason: string;
  contacts: EscalationContact[];
  actions: string[];
}

export interface EscalationContact {
  id: string;
  name: string;
  relationship: string;
  method: 'call' | 'sms' | 'push' | 'email';
  contacted: boolean;
  respondedAt?: Date;
}

export interface TimelineEvent {
  timestamp: Date;
  event: string;
  details?: string;
  actor?: string;
}

export interface EmergencyProtocol {
  emergencyType: EmergencyType;
  name: string;
  description: string;
  severity: EmergencySeverity;
  autoActions: EmergencyActionType[];
  escalationPath: EscalationLevel[];
  responseTime: number; // seconds
  requiresAcknowledgment: boolean;
  notifyAuthorities: boolean;
}

export interface EscalationLevel {
  level: number;
  delay: number; // seconds after previous level
  contacts: string[]; // contact types: 'owner', 'adult', 'emergency_contact', 'authorities'
  actions: EmergencyActionType[];
}

// ============================================================================
// EMERGENCY PROTOCOLS
// ============================================================================

export const EMERGENCY_PROTOCOLS: Record<EmergencyType, EmergencyProtocol> = {
  // Life Safety - Critical
  fire: {
    emergencyType: 'fire',
    name: 'Fire Emergency',
    description: 'Fire or smoke detected in the home',
    severity: 'critical',
    autoActions: ['alert_all', 'activate_alarm', 'unlock_doors', 'turn_on_lights', 'call_emergency_services'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['all_members'], actions: ['alert_all', 'activate_alarm'] },
      { level: 2, delay: 30, contacts: ['emergency_contact'], actions: ['notify_contact'] },
      { level: 3, delay: 60, contacts: ['authorities'], actions: ['call_emergency_services'] },
    ],
    responseTime: 30,
    requiresAcknowledgment: true,
    notifyAuthorities: true,
  },
  carbon_monoxide: {
    emergencyType: 'carbon_monoxide',
    name: 'Carbon Monoxide Alert',
    description: 'Dangerous CO levels detected',
    severity: 'critical',
    autoActions: ['alert_all', 'activate_alarm', 'unlock_doors', 'call_emergency_services'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['all_members'], actions: ['alert_all', 'activate_alarm'] },
      { level: 2, delay: 30, contacts: ['authorities'], actions: ['call_emergency_services'] },
    ],
    responseTime: 15,
    requiresAcknowledgment: true,
    notifyAuthorities: true,
  },
  gas_leak: {
    emergencyType: 'gas_leak',
    name: 'Gas Leak Detected',
    description: 'Natural gas leak detected',
    severity: 'critical',
    autoActions: ['alert_all', 'turn_off_gas', 'unlock_doors', 'call_emergency_services'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['all_members'], actions: ['alert_all', 'turn_off_gas'] },
      { level: 2, delay: 30, contacts: ['authorities'], actions: ['call_emergency_services'] },
    ],
    responseTime: 15,
    requiresAcknowledgment: true,
    notifyAuthorities: true,
  },
  smoke: {
    emergencyType: 'smoke',
    name: 'Smoke Detected',
    description: 'Smoke detected - possible fire',
    severity: 'high',
    autoActions: ['alert_all', 'activate_alarm', 'turn_on_lights'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['all_members'], actions: ['alert_all'] },
      { level: 2, delay: 60, contacts: ['emergency_contact'], actions: ['notify_contact'] },
      { level: 3, delay: 120, contacts: ['authorities'], actions: ['call_emergency_services'] },
    ],
    responseTime: 60,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  intrusion: {
    emergencyType: 'intrusion',
    name: 'Intrusion Alert',
    description: 'Unauthorized entry detected',
    severity: 'critical',
    autoActions: ['alert_all', 'activate_alarm', 'lock_doors', 'record_video', 'call_emergency_services'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member', 'record_video'] },
      { level: 2, delay: 30, contacts: ['all_members'], actions: ['alert_all', 'activate_alarm'] },
      { level: 3, delay: 60, contacts: ['authorities'], actions: ['call_emergency_services'] },
    ],
    responseTime: 30,
    requiresAcknowledgment: true,
    notifyAuthorities: true,
  },
  break_in: {
    emergencyType: 'break_in',
    name: 'Break-in Detected',
    description: 'Forced entry detected',
    severity: 'critical',
    autoActions: ['alert_all', 'activate_alarm', 'record_video', 'call_emergency_services'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['authorities'], actions: ['call_emergency_services', 'record_video'] },
      { level: 2, delay: 0, contacts: ['all_members'], actions: ['alert_all'] },
    ],
    responseTime: 0,
    requiresAcknowledgment: false,
    notifyAuthorities: true,
  },
  suspicious_activity: {
    emergencyType: 'suspicious_activity',
    name: 'Suspicious Activity',
    description: 'Unusual activity detected around property',
    severity: 'medium',
    autoActions: ['alert_member', 'record_video', 'turn_on_lights'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member', 'record_video'] },
      { level: 2, delay: 300, contacts: ['adult'], actions: ['alert_member'] },
    ],
    responseTime: 300,
    requiresAcknowledgment: false,
    notifyAuthorities: false,
  },
  medical: {
    emergencyType: 'medical',
    name: 'Medical Emergency',
    description: 'Medical emergency detected',
    severity: 'critical',
    autoActions: ['alert_all', 'call_emergency_services', 'unlock_doors', 'send_location'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['authorities'], actions: ['call_emergency_services'] },
      { level: 2, delay: 0, contacts: ['emergency_contact'], actions: ['notify_contact'] },
    ],
    responseTime: 0,
    requiresAcknowledgment: false,
    notifyAuthorities: true,
  },
  fall: {
    emergencyType: 'fall',
    name: 'Fall Detected',
    description: 'Fall detected - checking on member',
    severity: 'high',
    autoActions: ['alert_member', 'play_announcement'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['affected_member'], actions: ['play_announcement'] },
      { level: 2, delay: 60, contacts: ['owner'], actions: ['alert_member'] },
      { level: 3, delay: 180, contacts: ['emergency_contact'], actions: ['notify_contact'] },
      { level: 4, delay: 300, contacts: ['authorities'], actions: ['call_emergency_services'] },
    ],
    responseTime: 60,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  unresponsive: {
    emergencyType: 'unresponsive',
    name: 'Unresponsive Person',
    description: 'Person not responding to check-ins',
    severity: 'high',
    autoActions: ['alert_member', 'notify_contact'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member'] },
      { level: 2, delay: 300, contacts: ['emergency_contact'], actions: ['notify_contact'] },
      { level: 3, delay: 600, contacts: ['authorities'], actions: ['call_emergency_services'] },
    ],
    responseTime: 300,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  chest_pain: {
    emergencyType: 'chest_pain',
    name: 'Chest Pain Reported',
    description: 'Member reporting chest pain',
    severity: 'critical',
    autoActions: ['call_emergency_services', 'alert_all', 'unlock_doors'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['authorities'], actions: ['call_emergency_services'] },
    ],
    responseTime: 0,
    requiresAcknowledgment: false,
    notifyAuthorities: true,
  },
  breathing: {
    emergencyType: 'breathing',
    name: 'Breathing Difficulty',
    description: 'Member having difficulty breathing',
    severity: 'critical',
    autoActions: ['call_emergency_services', 'alert_all'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['authorities'], actions: ['call_emergency_services'] },
    ],
    responseTime: 0,
    requiresAcknowledgment: false,
    notifyAuthorities: true,
  },
  child_emergency: {
    emergencyType: 'child_emergency',
    name: 'Child Emergency',
    description: 'Emergency involving a child',
    severity: 'critical',
    autoActions: ['alert_all', 'call_emergency_services'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['all_members'], actions: ['alert_all'] },
      { level: 2, delay: 30, contacts: ['authorities'], actions: ['call_emergency_services'] },
    ],
    responseTime: 0,
    requiresAcknowledgment: false,
    notifyAuthorities: true,
  },
  elderly_emergency: {
    emergencyType: 'elderly_emergency',
    name: 'Elderly Emergency',
    description: 'Emergency involving elderly member',
    severity: 'critical',
    autoActions: ['alert_all', 'notify_contact', 'call_emergency_services'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member'] },
      { level: 2, delay: 60, contacts: ['emergency_contact'], actions: ['notify_contact'] },
      { level: 3, delay: 120, contacts: ['authorities'], actions: ['call_emergency_services'] },
    ],
    responseTime: 60,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  // Environmental
  flood: {
    emergencyType: 'flood',
    name: 'Flood Warning',
    description: 'Flooding detected or imminent',
    severity: 'high',
    autoActions: ['alert_all', 'turn_off_water'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['all_members'], actions: ['alert_all'] },
      { level: 2, delay: 300, contacts: ['emergency_contact'], actions: ['notify_contact'] },
    ],
    responseTime: 60,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  water_leak: {
    emergencyType: 'water_leak',
    name: 'Water Leak Detected',
    description: 'Water leak detected',
    severity: 'medium',
    autoActions: ['alert_member', 'turn_off_water'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member'] },
      { level: 2, delay: 600, contacts: ['adult'], actions: ['alert_member'] },
    ],
    responseTime: 300,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  pipe_burst: {
    emergencyType: 'pipe_burst',
    name: 'Pipe Burst',
    description: 'Major water pipe burst',
    severity: 'high',
    autoActions: ['alert_all', 'turn_off_water'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['all_members'], actions: ['alert_all', 'turn_off_water'] },
      { level: 2, delay: 60, contacts: ['emergency_contact'], actions: ['notify_contact'] },
    ],
    responseTime: 30,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  severe_weather: {
    emergencyType: 'severe_weather',
    name: 'Severe Weather Alert',
    description: 'Severe weather warning in effect',
    severity: 'high',
    autoActions: ['alert_all', 'play_announcement'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['all_members'], actions: ['alert_all'] },
    ],
    responseTime: 60,
    requiresAcknowledgment: false,
    notifyAuthorities: false,
  },
  tornado: {
    emergencyType: 'tornado',
    name: 'Tornado Warning',
    description: 'Tornado warning - take shelter immediately',
    severity: 'critical',
    autoActions: ['alert_all', 'activate_alarm', 'play_announcement'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['all_members'], actions: ['alert_all', 'activate_alarm'] },
    ],
    responseTime: 0,
    requiresAcknowledgment: false,
    notifyAuthorities: false,
  },
  hurricane: {
    emergencyType: 'hurricane',
    name: 'Hurricane Warning',
    description: 'Hurricane approaching area',
    severity: 'high',
    autoActions: ['alert_all'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['all_members'], actions: ['alert_all'] },
    ],
    responseTime: 3600,
    requiresAcknowledgment: false,
    notifyAuthorities: false,
  },
  earthquake: {
    emergencyType: 'earthquake',
    name: 'Earthquake Detected',
    description: 'Earthquake activity detected',
    severity: 'high',
    autoActions: ['alert_all', 'turn_off_gas'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['all_members'], actions: ['alert_all'] },
    ],
    responseTime: 0,
    requiresAcknowledgment: false,
    notifyAuthorities: false,
  },
  power_outage: {
    emergencyType: 'power_outage',
    name: 'Power Outage',
    description: 'Power outage detected',
    severity: 'medium',
    autoActions: ['alert_member'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member'] },
    ],
    responseTime: 300,
    requiresAcknowledgment: false,
    notifyAuthorities: false,
  },
  utility_failure: {
    emergencyType: 'utility_failure',
    name: 'Utility Failure',
    description: 'Utility service disruption',
    severity: 'medium',
    autoActions: ['alert_member'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member'] },
    ],
    responseTime: 600,
    requiresAcknowledgment: false,
    notifyAuthorities: false,
  },
  temperature_extreme: {
    emergencyType: 'temperature_extreme',
    name: 'Extreme Temperature',
    description: 'Dangerous temperature detected',
    severity: 'high',
    autoActions: ['alert_all'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['all_members'], actions: ['alert_all'] },
    ],
    responseTime: 300,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  hvac_failure: {
    emergencyType: 'hvac_failure',
    name: 'HVAC System Failure',
    description: 'Heating/cooling system not functioning',
    severity: 'medium',
    autoActions: ['alert_member'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member'] },
    ],
    responseTime: 3600,
    requiresAcknowledgment: false,
    notifyAuthorities: false,
  },
  // Security
  alarm_triggered: {
    emergencyType: 'alarm_triggered',
    name: 'Alarm Triggered',
    description: 'Security alarm activated',
    severity: 'high',
    autoActions: ['alert_all', 'record_video'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member'] },
      { level: 2, delay: 60, contacts: ['all_members'], actions: ['alert_all'] },
      { level: 3, delay: 180, contacts: ['authorities'], actions: ['call_emergency_services'] },
    ],
    responseTime: 60,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  door_forced: {
    emergencyType: 'door_forced',
    name: 'Door Forced Open',
    description: 'Door forced open detected',
    severity: 'critical',
    autoActions: ['alert_all', 'activate_alarm', 'record_video', 'call_emergency_services'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['authorities'], actions: ['call_emergency_services'] },
      { level: 2, delay: 0, contacts: ['all_members'], actions: ['alert_all'] },
    ],
    responseTime: 0,
    requiresAcknowledgment: false,
    notifyAuthorities: true,
  },
  window_broken: {
    emergencyType: 'window_broken',
    name: 'Window Broken',
    description: 'Window break detected',
    severity: 'high',
    autoActions: ['alert_all', 'activate_alarm', 'record_video'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member', 'record_video'] },
      { level: 2, delay: 60, contacts: ['all_members'], actions: ['alert_all', 'activate_alarm'] },
      { level: 3, delay: 180, contacts: ['authorities'], actions: ['call_emergency_services'] },
    ],
    responseTime: 60,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  vehicle_theft: {
    emergencyType: 'vehicle_theft',
    name: 'Vehicle Theft',
    description: 'Vehicle theft in progress',
    severity: 'high',
    autoActions: ['alert_all', 'call_emergency_services', 'send_location'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member'] },
      { level: 2, delay: 30, contacts: ['authorities'], actions: ['call_emergency_services', 'send_location'] },
    ],
    responseTime: 30,
    requiresAcknowledgment: false,
    notifyAuthorities: true,
  },
  package_theft: {
    emergencyType: 'package_theft',
    name: 'Package Theft',
    description: 'Package theft detected',
    severity: 'low',
    autoActions: ['alert_member', 'record_video'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member', 'record_video'] },
    ],
    responseTime: 600,
    requiresAcknowledgment: false,
    notifyAuthorities: false,
  },
  cyber_attack: {
    emergencyType: 'cyber_attack',
    name: 'Cyber Attack Detected',
    description: 'Network security breach detected',
    severity: 'high',
    autoActions: ['alert_member', 'backup_data'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member'] },
    ],
    responseTime: 60,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  account_breach: {
    emergencyType: 'account_breach',
    name: 'Account Breach',
    description: 'Account security breach detected',
    severity: 'high',
    autoActions: ['alert_member', 'change_passwords'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member'] },
    ],
    responseTime: 60,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  // Financial
  fraud_detected: {
    emergencyType: 'fraud_detected',
    name: 'Fraud Detected',
    description: 'Potential fraudulent activity detected',
    severity: 'high',
    autoActions: ['alert_member', 'freeze_accounts'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member'] },
    ],
    responseTime: 30,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  unusual_transaction: {
    emergencyType: 'unusual_transaction',
    name: 'Unusual Transaction',
    description: 'Unusual financial transaction detected',
    severity: 'medium',
    autoActions: ['alert_member'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member'] },
    ],
    responseTime: 300,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  identity_theft: {
    emergencyType: 'identity_theft',
    name: 'Identity Theft Alert',
    description: 'Potential identity theft detected',
    severity: 'critical',
    autoActions: ['alert_member', 'freeze_accounts'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member', 'freeze_accounts'] },
    ],
    responseTime: 15,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  overdraft: {
    emergencyType: 'overdraft',
    name: 'Overdraft Warning',
    description: 'Account overdraft detected',
    severity: 'medium',
    autoActions: ['alert_member'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member'] },
    ],
    responseTime: 3600,
    requiresAcknowledgment: false,
    notifyAuthorities: false,
  },
  payment_failure: {
    emergencyType: 'payment_failure',
    name: 'Payment Failed',
    description: 'Scheduled payment failed',
    severity: 'medium',
    autoActions: ['alert_member'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member'] },
    ],
    responseTime: 3600,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  collection_notice: {
    emergencyType: 'collection_notice',
    name: 'Collection Notice',
    description: 'Collection notice received',
    severity: 'high',
    autoActions: ['alert_member'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member'] },
    ],
    responseTime: 86400,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  // Personal Safety
  missing_person: {
    emergencyType: 'missing_person',
    name: 'Missing Person',
    description: 'Household member not located',
    severity: 'critical',
    autoActions: ['alert_all', 'send_location'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['all_members'], actions: ['alert_all'] },
      { level: 2, delay: 1800, contacts: ['emergency_contact'], actions: ['notify_contact'] },
      { level: 3, delay: 3600, contacts: ['authorities'], actions: ['call_emergency_services'] },
    ],
    responseTime: 1800,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  late_arrival: {
    emergencyType: 'late_arrival',
    name: 'Late Arrival',
    description: 'Expected arrival significantly delayed',
    severity: 'medium',
    autoActions: ['alert_member'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member'] },
      { level: 2, delay: 1800, contacts: ['emergency_contact'], actions: ['notify_contact'] },
    ],
    responseTime: 1800,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  no_check_in: {
    emergencyType: 'no_check_in',
    name: 'Missed Check-in',
    description: 'Expected check-in not received',
    severity: 'medium',
    autoActions: ['alert_member'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member'] },
      { level: 2, delay: 3600, contacts: ['emergency_contact'], actions: ['notify_contact'] },
    ],
    responseTime: 3600,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  distress_signal: {
    emergencyType: 'distress_signal',
    name: 'Distress Signal',
    description: 'Distress signal received',
    severity: 'critical',
    autoActions: ['alert_all', 'call_emergency_services', 'send_location'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['authorities'], actions: ['call_emergency_services', 'send_location'] },
      { level: 2, delay: 0, contacts: ['all_members'], actions: ['alert_all'] },
    ],
    responseTime: 0,
    requiresAcknowledgment: false,
    notifyAuthorities: true,
  },
  panic_button: {
    emergencyType: 'panic_button',
    name: 'Panic Button Pressed',
    description: 'Panic button activated',
    severity: 'critical',
    autoActions: ['alert_all', 'call_emergency_services', 'record_video'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['authorities'], actions: ['call_emergency_services'] },
      { level: 2, delay: 0, contacts: ['all_members'], actions: ['alert_all'] },
    ],
    responseTime: 0,
    requiresAcknowledgment: false,
    notifyAuthorities: true,
  },
  // Infrastructure
  appliance_failure: {
    emergencyType: 'appliance_failure',
    name: 'Appliance Failure',
    description: 'Major appliance malfunction',
    severity: 'low',
    autoActions: ['alert_member'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member'] },
    ],
    responseTime: 86400,
    requiresAcknowledgment: false,
    notifyAuthorities: false,
  },
  structural_damage: {
    emergencyType: 'structural_damage',
    name: 'Structural Damage',
    description: 'Structural damage detected',
    severity: 'high',
    autoActions: ['alert_all'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['all_members'], actions: ['alert_all'] },
    ],
    responseTime: 3600,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  roof_leak: {
    emergencyType: 'roof_leak',
    name: 'Roof Leak',
    description: 'Roof leak detected',
    severity: 'medium',
    autoActions: ['alert_member'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member'] },
    ],
    responseTime: 3600,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
  pest_infestation: {
    emergencyType: 'pest_infestation',
    name: 'Pest Infestation',
    description: 'Pest infestation detected',
    severity: 'low',
    autoActions: ['alert_member'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member'] },
    ],
    responseTime: 86400,
    requiresAcknowledgment: false,
    notifyAuthorities: false,
  },
  mold_detected: {
    emergencyType: 'mold_detected',
    name: 'Mold Detected',
    description: 'Mold growth detected',
    severity: 'medium',
    autoActions: ['alert_member'],
    escalationPath: [
      { level: 1, delay: 0, contacts: ['owner'], actions: ['alert_member'] },
    ],
    responseTime: 86400,
    requiresAcknowledgment: true,
    notifyAuthorities: false,
  },
};

// ============================================================================
// COMPLETE EMERGENCY SYSTEM
// ============================================================================

export class CompleteEmergencySystem extends EventEmitter {
  private emergencies: Map<string, Emergency> = new Map();
  private escalationTimers: Map<string, NodeJS.Timeout[]> = new Map();

  constructor() {
    super();
  }

  // -------------------------------------------------------------------------
  // EMERGENCY DETECTION & CREATION
  // -------------------------------------------------------------------------

  async detectEmergency(
    type: EmergencyType,
    source: EmergencySource,
    householdId: number,
    metadata?: Record<string, any>
  ): Promise<Emergency> {
    const protocol = EMERGENCY_PROTOCOLS[type];
    if (!protocol) {
      throw new Error(`Unknown emergency type: ${type}`);
    }

    const emergency: Emergency = {
      id: this.generateId('emg'),
      type,
      category: this.getCategory(type),
      severity: protocol.severity,
      status: 'detected',
      title: protocol.name,
      description: protocol.description,
      detectedAt: new Date(),
      source,
      affectedMembers: [],
      triggers: [{
        type: 'detection',
        value: source.type,
        timestamp: new Date(),
      }],
      actions: [],
      escalations: [],
      timeline: [{
        timestamp: new Date(),
        event: 'Emergency detected',
        details: `${protocol.name} detected from ${source.name}`,
        actor: 'system',
      }],
      metadata: metadata || {},
      householdId,
    };

    this.emergencies.set(emergency.id, emergency);
    this.emit('emergency_detected', emergency);

    // Execute automatic actions
    await this.executeAutoActions(emergency, protocol);

    // Start escalation sequence
    this.startEscalation(emergency, protocol);

    return emergency;
  }

  // -------------------------------------------------------------------------
  // AUTOMATIC ACTIONS
  // -------------------------------------------------------------------------

  private async executeAutoActions(
    emergency: Emergency,
    protocol: EmergencyProtocol
  ): Promise<void> {
    for (const actionType of protocol.autoActions) {
      const action: EmergencyAction = {
        id: this.generateId('act'),
        type: actionType,
        description: this.getActionDescription(actionType),
        status: 'pending',
        automated: true,
        priority: this.getActionPriority(actionType),
      };

      emergency.actions.push(action);
      await this.executeAction(emergency, action);
    }
  }

  private async executeAction(
    emergency: Emergency,
    action: EmergencyAction
  ): Promise<void> {
    action.status = 'in_progress';
    action.executedAt = new Date();

    try {
      // Execute based on action type
      switch (action.type) {
        case 'alert_all':
          await this.alertAllMembers(emergency);
          break;
        case 'alert_member':
          await this.alertMember(emergency, emergency.affectedMembers[0]);
          break;
        case 'call_emergency_services':
          await this.callEmergencyServices(emergency);
          break;
        case 'activate_alarm':
          await this.activateAlarm(emergency);
          break;
        case 'lock_doors':
          await this.lockDoors(emergency);
          break;
        case 'unlock_doors':
          await this.unlockDoors(emergency);
          break;
        case 'turn_off_gas':
          await this.turnOffGas(emergency);
          break;
        case 'turn_off_water':
          await this.turnOffWater(emergency);
          break;
        case 'turn_on_lights':
          await this.turnOnLights(emergency);
          break;
        case 'record_video':
          await this.recordVideo(emergency);
          break;
        case 'send_location':
          await this.sendLocation(emergency);
          break;
        case 'play_announcement':
          await this.playAnnouncement(emergency);
          break;
        case 'freeze_accounts':
          await this.freezeAccounts(emergency);
          break;
        case 'change_passwords':
          await this.changePasswords(emergency);
          break;
        case 'backup_data':
          await this.backupData(emergency);
          break;
      }

      action.status = 'completed';
      action.result = 'Success';

      emergency.timeline.push({
        timestamp: new Date(),
        event: `Action completed: ${action.type}`,
        details: action.description,
        actor: 'system',
      });
    } catch (error: any) {
      action.status = 'failed';
      action.result = error.message;

      emergency.timeline.push({
        timestamp: new Date(),
        event: `Action failed: ${action.type}`,
        details: error.message,
        actor: 'system',
      });
    }

    this.emit('action_executed', { emergency, action });
  }

  // Action implementations
  private async alertAllMembers(emergency: Emergency): Promise<void> {
    console.log(`[Emergency] Alerting all members: ${emergency.title}`);
  }

  private async alertMember(emergency: Emergency, memberId: number): Promise<void> {
    console.log(`[Emergency] Alerting member ${memberId}: ${emergency.title}`);
  }

  private async callEmergencyServices(emergency: Emergency): Promise<void> {
    console.log(`[Emergency] Calling emergency services for: ${emergency.title}`);
  }

  private async activateAlarm(emergency: Emergency): Promise<void> {
    console.log(`[Emergency] Activating alarm for: ${emergency.title}`);
  }

  private async lockDoors(emergency: Emergency): Promise<void> {
    console.log(`[Emergency] Locking all doors`);
  }

  private async unlockDoors(emergency: Emergency): Promise<void> {
    console.log(`[Emergency] Unlocking all doors for emergency egress`);
  }

  private async turnOffGas(emergency: Emergency): Promise<void> {
    console.log(`[Emergency] Shutting off gas supply`);
  }

  private async turnOffWater(emergency: Emergency): Promise<void> {
    console.log(`[Emergency] Shutting off water supply`);
  }

  private async turnOnLights(emergency: Emergency): Promise<void> {
    console.log(`[Emergency] Turning on all lights`);
  }

  private async recordVideo(emergency: Emergency): Promise<void> {
    console.log(`[Emergency] Starting video recording`);
  }

  private async sendLocation(emergency: Emergency): Promise<void> {
    console.log(`[Emergency] Sending location to emergency contacts`);
  }

  private async playAnnouncement(emergency: Emergency): Promise<void> {
    console.log(`[Emergency] Playing announcement: ${emergency.title}`);
  }

  private async freezeAccounts(emergency: Emergency): Promise<void> {
    console.log(`[Emergency] Freezing financial accounts`);
  }

  private async changePasswords(emergency: Emergency): Promise<void> {
    console.log(`[Emergency] Initiating password change protocol`);
  }

  private async backupData(emergency: Emergency): Promise<void> {
    console.log(`[Emergency] Backing up critical data`);
  }

  // -------------------------------------------------------------------------
  // ESCALATION
  // -------------------------------------------------------------------------

  private startEscalation(emergency: Emergency, protocol: EmergencyProtocol): void {
    const timers: NodeJS.Timeout[] = [];

    for (const level of protocol.escalationPath) {
      const timer = setTimeout(() => {
        this.escalateToLevel(emergency, level);
      }, level.delay * 1000);

      timers.push(timer);
    }

    this.escalationTimers.set(emergency.id, timers);
  }

  private async escalateToLevel(emergency: Emergency, level: EscalationLevel): Promise<void> {
    if (emergency.status === 'resolved' || emergency.status === 'false_alarm') {
      return;
    }

    const escalation: Escalation = {
      level: level.level,
      triggeredAt: new Date(),
      reason: `Automatic escalation after ${level.delay} seconds`,
      contacts: level.contacts.map(c => ({
        id: c,
        name: c,
        relationship: c,
        method: 'push' as const,
        contacted: false,
      })),
      actions: level.actions,
    };

    emergency.escalations.push(escalation);
    emergency.timeline.push({
      timestamp: new Date(),
      event: `Escalated to level ${level.level}`,
      details: `Contacting: ${level.contacts.join(', ')}`,
      actor: 'system',
    });

    // Execute escalation actions
    for (const actionType of level.actions) {
      const action: EmergencyAction = {
        id: this.generateId('act'),
        type: actionType,
        description: this.getActionDescription(actionType),
        status: 'pending',
        automated: true,
        priority: this.getActionPriority(actionType),
      };

      emergency.actions.push(action);
      await this.executeAction(emergency, action);
    }

    this.emit('emergency_escalated', { emergency, level: level.level });
  }

  // -------------------------------------------------------------------------
  // EMERGENCY MANAGEMENT
  // -------------------------------------------------------------------------

  async acknowledgeEmergency(emergencyId: string, memberId: number): Promise<boolean> {
    const emergency = this.emergencies.get(emergencyId);
    if (!emergency) return false;

    emergency.status = 'acknowledged';
    emergency.acknowledgedAt = new Date();
    emergency.timeline.push({
      timestamp: new Date(),
      event: 'Emergency acknowledged',
      details: `Acknowledged by member ${memberId}`,
      actor: `member_${memberId}`,
    });

    this.emit('emergency_acknowledged', emergency);
    return true;
  }

  async resolveEmergency(
    emergencyId: string,
    resolution: string,
    memberId: number
  ): Promise<boolean> {
    const emergency = this.emergencies.get(emergencyId);
    if (!emergency) return false;

    emergency.status = 'resolved';
    emergency.resolvedAt = new Date();
    emergency.timeline.push({
      timestamp: new Date(),
      event: 'Emergency resolved',
      details: resolution,
      actor: `member_${memberId}`,
    });

    // Cancel pending escalations
    this.cancelEscalations(emergencyId);

    this.emit('emergency_resolved', emergency);
    return true;
  }

  async markFalseAlarm(emergencyId: string, memberId: number): Promise<boolean> {
    const emergency = this.emergencies.get(emergencyId);
    if (!emergency) return false;

    emergency.status = 'false_alarm';
    emergency.resolvedAt = new Date();
    emergency.timeline.push({
      timestamp: new Date(),
      event: 'Marked as false alarm',
      actor: `member_${memberId}`,
    });

    // Cancel pending escalations
    this.cancelEscalations(emergencyId);

    this.emit('emergency_false_alarm', emergency);
    return true;
  }

  private cancelEscalations(emergencyId: string): void {
    const timers = this.escalationTimers.get(emergencyId);
    if (timers) {
      timers.forEach(timer => clearTimeout(timer));
      this.escalationTimers.delete(emergencyId);
    }
  }

  // -------------------------------------------------------------------------
  // QUERIES
  // -------------------------------------------------------------------------

  getActiveEmergencies(householdId: number): Emergency[] {
    return Array.from(this.emergencies.values())
      .filter(e => e.householdId === householdId && 
                   !['resolved', 'false_alarm'].includes(e.status))
      .sort((a, b) => {
        const severityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
        return severityOrder[a.severity] - severityOrder[b.severity];
      });
  }

  getEmergencyHistory(householdId: number, limit: number = 50): Emergency[] {
    return Array.from(this.emergencies.values())
      .filter(e => e.householdId === householdId)
      .sort((a, b) => b.detectedAt.getTime() - a.detectedAt.getTime())
      .slice(0, limit);
  }

  getEmergencyById(emergencyId: string): Emergency | undefined {
    return this.emergencies.get(emergencyId);
  }

  getEmergencyStats(householdId: number): {
    total: number;
    active: number;
    resolved: number;
    falseAlarms: number;
    bySeverity: Record<EmergencySeverity, number>;
    byCategory: Record<EmergencyCategory, number>;
  } {
    const emergencies = Array.from(this.emergencies.values())
      .filter(e => e.householdId === householdId);

    const stats = {
      total: emergencies.length,
      active: emergencies.filter(e => !['resolved', 'false_alarm'].includes(e.status)).length,
      resolved: emergencies.filter(e => e.status === 'resolved').length,
      falseAlarms: emergencies.filter(e => e.status === 'false_alarm').length,
      bySeverity: { critical: 0, high: 0, medium: 0, low: 0 },
      byCategory: {
        life_safety: 0, security: 0, environmental: 0,
        financial: 0, health: 0, infrastructure: 0,
      },
    };

    for (const e of emergencies) {
      stats.bySeverity[e.severity]++;
      stats.byCategory[e.category]++;
    }

    return stats;
  }

  // -------------------------------------------------------------------------
  // HELPERS
  // -------------------------------------------------------------------------

  private generateId(prefix: string): string {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private getCategory(type: EmergencyType): EmergencyCategory {
    const categoryMap: Record<string, EmergencyCategory> = {
      fire: 'life_safety', carbon_monoxide: 'life_safety', gas_leak: 'life_safety',
      smoke: 'life_safety', intrusion: 'security', break_in: 'security',
      suspicious_activity: 'security', medical: 'health', fall: 'health',
      unresponsive: 'health', chest_pain: 'health', breathing: 'health',
      child_emergency: 'life_safety', elderly_emergency: 'health',
      flood: 'environmental', water_leak: 'environmental', pipe_burst: 'environmental',
      severe_weather: 'environmental', tornado: 'environmental', hurricane: 'environmental',
      earthquake: 'environmental', power_outage: 'infrastructure', utility_failure: 'infrastructure',
      temperature_extreme: 'environmental', hvac_failure: 'infrastructure',
      alarm_triggered: 'security', door_forced: 'security', window_broken: 'security',
      vehicle_theft: 'security', package_theft: 'security', cyber_attack: 'security',
      account_breach: 'security', fraud_detected: 'financial', unusual_transaction: 'financial',
      identity_theft: 'financial', overdraft: 'financial', payment_failure: 'financial',
      collection_notice: 'financial', missing_person: 'life_safety', late_arrival: 'life_safety',
      no_check_in: 'life_safety', distress_signal: 'life_safety', panic_button: 'life_safety',
      appliance_failure: 'infrastructure', structural_damage: 'infrastructure',
      roof_leak: 'infrastructure', pest_infestation: 'infrastructure', mold_detected: 'infrastructure',
    };
    return categoryMap[type] || 'infrastructure';
  }

  private getActionDescription(actionType: EmergencyActionType): string {
    const descriptions: Record<EmergencyActionType, string> = {
      alert_member: 'Alert household member',
      alert_all: 'Alert all household members',
      call_emergency_services: 'Call emergency services (911)',
      notify_contact: 'Notify emergency contact',
      activate_alarm: 'Activate security alarm',
      lock_doors: 'Lock all doors',
      unlock_doors: 'Unlock doors for emergency egress',
      turn_off_gas: 'Shut off gas supply',
      turn_off_water: 'Shut off water supply',
      turn_on_lights: 'Turn on all lights',
      record_video: 'Start security camera recording',
      take_snapshot: 'Capture security camera snapshots',
      send_location: 'Send location to emergency contacts',
      play_announcement: 'Play emergency announcement',
      dispatch_help: 'Dispatch emergency assistance',
      freeze_accounts: 'Freeze financial accounts',
      change_passwords: 'Initiate password change',
      backup_data: 'Backup critical data',
    };
    return descriptions[actionType] || actionType;
  }

  private getActionPriority(actionType: EmergencyActionType): number {
    const priorities: Record<EmergencyActionType, number> = {
      call_emergency_services: 1,
      alert_all: 2,
      activate_alarm: 3,
      unlock_doors: 4,
      turn_off_gas: 5,
      turn_off_water: 6,
      alert_member: 7,
      notify_contact: 8,
      lock_doors: 9,
      turn_on_lights: 10,
      record_video: 11,
      take_snapshot: 12,
      send_location: 13,
      play_announcement: 14,
      dispatch_help: 15,
      freeze_accounts: 16,
      change_passwords: 17,
      backup_data: 18,
    };
    return priorities[actionType] || 99;
  }
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

export const completeEmergencySystem = new CompleteEmergencySystem();
