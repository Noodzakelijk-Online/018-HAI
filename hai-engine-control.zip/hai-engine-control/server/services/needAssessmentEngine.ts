/**
 * Need Assessment Engine
 * 
 * Analyzes user data to determine Maslow's Hierarchy fulfillment levels
 * and provides insights for task prioritization.
 */

import * as db from "../db";

export interface NeedAssessment {
  categoryId: number;
  categoryName: string;
  level: number;
  fulfillmentLevel: number; // 0-100%
  trend: "improving" | "stable" | "declining";
  indicators: NeedIndicatorResult[];
  insights: string;
  recommendations: string[];
  criticalGaps: string[];
}

export interface NeedIndicatorResult {
  name: string;
  current: number;
  target: number;
  fulfillment: number; // 0-100%
  source: string;
}

/**
 * Maslow's Hierarchy Categories with default indicators
 */
export const MASLOW_CATEGORIES = {
  PHYSIOLOGICAL: {
    level: 1,
    name: "Physiological",
    indicators: [
      { name: "Sleep Quality", target: 8, measurementType: "duration", dataSource: "calendar" },
      { name: "Health Checkups", target: 4, measurementType: "count", dataSource: "calendar" },
      { name: "Meal Regularity", target: 90, measurementType: "percentage", dataSource: "tasks" },
      { name: "Exercise Frequency", target: 3, measurementType: "frequency", dataSource: "calendar" },
    ],
  },
  SAFETY: {
    level: 2,
    name: "Safety",
    indicators: [
      { name: "Financial Stability", target: 80, measurementType: "percentage", dataSource: "finance" },
      { name: "Insurance Coverage", target: 100, measurementType: "percentage", dataSource: "tasks" },
      { name: "Emergency Fund", target: 6, measurementType: "count", dataSource: "finance" },
      { name: "Home Security", target: 100, measurementType: "percentage", dataSource: "tasks" },
    ],
  },
  LOVE_BELONGING: {
    level: 3,
    name: "Love & Belonging",
    indicators: [
      { name: "Social Interactions", target: 10, measurementType: "frequency", dataSource: "calendar" },
      { name: "Family Time", target: 7, measurementType: "frequency", dataSource: "calendar" },
      { name: "Close Relationships", target: 5, measurementType: "count", dataSource: "communication" },
      { name: "Community Involvement", target: 2, measurementType: "frequency", dataSource: "tasks" },
    ],
  },
  ESTEEM: {
    level: 4,
    name: "Esteem",
    indicators: [
      { name: "Career Progress", target: 80, measurementType: "percentage", dataSource: "tasks" },
      { name: "Skill Development", target: 4, measurementType: "count", dataSource: "tasks" },
      { name: "Recognition Received", target: 5, measurementType: "count", dataSource: "communication" },
      { name: "Goals Achieved", target: 75, measurementType: "percentage", dataSource: "tasks" },
    ],
  },
  SELF_ACTUALIZATION: {
    level: 5,
    name: "Self-Actualization",
    indicators: [
      { name: "Creative Projects", target: 2, measurementType: "count", dataSource: "tasks" },
      { name: "Learning New Skills", target: 3, measurementType: "count", dataSource: "tasks" },
      { name: "Personal Growth Activities", target: 5, measurementType: "frequency", dataSource: "calendar" },
      { name: "Purpose Alignment", target: 90, measurementType: "percentage", dataSource: "tasks" },
    ],
  },
};

/**
 * Assess all needs for a user
 */
export async function assessUserNeeds(userId: number): Promise<NeedAssessment[]> {
  const assessments: NeedAssessment[] = [];

  // Get all need categories from database
  const categories = await db.getNeedCategories();

  for (const category of categories) {
    const assessment = await assessNeedCategory(userId, category.id);
    assessments.push(assessment);
  }

  // Sort by level (bottom to top of pyramid)
  return assessments.sort((a, b) => a.level - b.level);
}

/**
 * Assess a specific need category
 */
async function assessNeedCategory(userId: number, categoryId: number): Promise<NeedAssessment> {
  const category = await db.getNeedCategoryById(categoryId);
  if (!category) {
    throw new Error(`Need category ${categoryId} not found`);
  }

  // Get indicators for this category
  const indicators = await db.getNeedIndicatorsByCategory(categoryId);

  // Calculate fulfillment for each indicator
  const indicatorResults: NeedIndicatorResult[] = [];
  let totalFulfillment = 0;

  for (const indicator of indicators) {
    const measurement = await measureIndicator(userId, indicator);
    indicatorResults.push(measurement);
    totalFulfillment += measurement.fulfillment * parseFloat(indicator.weight?.toString() || "1");
  }

  // Calculate overall category fulfillment
  const totalWeight = indicators.reduce((sum, ind) => sum + parseFloat(ind.weight?.toString() || "1"), 0);
  const fulfillmentLevel = totalWeight > 0 ? totalFulfillment / totalWeight : 0;

  // Determine trend
  const previousAssessment = await db.getPreviousNeedAssessment(userId, categoryId);
  let trend: "improving" | "stable" | "declining" = "stable";
  if (previousAssessment) {
    const previous = parseFloat(previousAssessment.fulfillmentLevel?.toString() || "0");
    if (fulfillmentLevel > previous + 5) trend = "improving";
    else if (fulfillmentLevel < previous - 5) trend = "declining";
  }

  // Generate insights and recommendations
  const { insights, recommendations, criticalGaps } = generateInsights(
    category,
    fulfillmentLevel,
    indicatorResults,
    trend
  );

  return {
    categoryId: category.id,
    categoryName: category.name,
    level: category.level,
    fulfillmentLevel: Math.round(fulfillmentLevel * 100) / 100,
    trend,
    indicators: indicatorResults,
    insights,
    recommendations,
    criticalGaps,
  };
}

/**
 * Measure a specific indicator
 */
async function measureIndicator(userId: number, indicator: any): Promise<NeedIndicatorResult> {
  // Get recent measurements for this indicator
  const measurements = await db.getNeedIndicatorMeasurements(userId, indicator.id, 30); // Last 30 days

  let current = 0;
  const target = parseFloat(indicator.targetValue?.toString() || "100");

  if (measurements.length > 0) {
    // Calculate average or sum based on measurement type
    switch (indicator.measurementType) {
      case "count":
        current = measurements.length;
        break;
      case "percentage":
      case "duration":
      case "frequency":
        current = measurements.reduce((sum, m) => sum + parseFloat(m.value?.toString() || "0"), 0) / measurements.length;
        break;
      case "boolean":
        current = measurements.some(m => parseFloat(m.value?.toString() || "0") > 0) ? 100 : 0;
        break;
    }
  }

  const fulfillment = target > 0 ? Math.min((current / target) * 100, 100) : 0;

  return {
    name: indicator.name,
    current: Math.round(current * 100) / 100,
    target,
    fulfillment: Math.round(fulfillment * 100) / 100,
    source: indicator.dataSource || "manual",
  };
}

/**
 * Generate insights and recommendations
 */
function generateInsights(
  category: any,
  fulfillmentLevel: number,
  indicators: NeedIndicatorResult[],
  trend: "improving" | "stable" | "declining"
): {
  insights: string;
  recommendations: string[];
  criticalGaps: string[];
} {
  const criticalGaps: string[] = [];
  const recommendations: string[] = [];

  // Identify critical gaps (< 50% fulfillment)
  indicators.forEach(ind => {
    if (ind.fulfillment < 50) {
      criticalGaps.push(`${ind.name}: ${ind.fulfillment.toFixed(0)}% fulfilled`);
      recommendations.push(`Improve ${ind.name} from ${ind.current} to ${ind.target}`);
    }
  });

  // Generate overall insight
  let insights = "";
  if (fulfillmentLevel >= 80) {
    insights = `Your ${category.name} needs are well-fulfilled (${fulfillmentLevel.toFixed(0)}%). `;
    if (trend === "improving") {
      insights += "Excellent progress! Keep maintaining these healthy habits.";
    } else if (trend === "declining") {
      insights += "However, there's a slight decline. Monitor closely to prevent further drops.";
    } else {
      insights += "Maintain your current practices to sustain this level.";
    }
  } else if (fulfillmentLevel >= 50) {
    insights = `Your ${category.name} needs are moderately fulfilled (${fulfillmentLevel.toFixed(0)}%). `;
    if (trend === "improving") {
      insights += "You're making progress! Continue focusing on improvement.";
    } else if (trend === "declining") {
      insights += "Attention needed: this area is declining and requires immediate focus.";
    } else {
      insights += "There's room for improvement in several areas.";
    }
  } else {
    insights = `⚠️ Critical: Your ${category.name} needs are significantly unfulfilled (${fulfillmentLevel.toFixed(0)}%). `;
    insights += "This requires immediate attention as it forms the foundation of your well-being.";
    if (category.level <= 2) {
      insights += " Lower-level needs must be addressed before higher-level growth can occur.";
    }
  }

  // Add specific recommendations based on category
  if (recommendations.length === 0) {
    recommendations.push(`Continue monitoring your ${category.name} indicators`);
    recommendations.push(`Set new goals to further improve this area`);
  }

  return { insights, recommendations, criticalGaps };
}

/**
 * Get the most critical unfulfilled need
 */
export async function getMostCriticalNeed(userId: number): Promise<NeedAssessment | null> {
  const assessments = await assessUserNeeds(userId);

  // Filter to needs below 70% fulfillment
  const unfulfilled = assessments.filter(a => a.fulfillmentLevel < 70);

  if (unfulfilled.length === 0) return null;

  // Sort by level (lower levels are more critical) and fulfillment (lower is more critical)
  unfulfilled.sort((a, b) => {
    if (a.level !== b.level) return a.level - b.level; // Lower level = more critical
    return a.fulfillmentLevel - b.fulfillmentLevel; // Lower fulfillment = more critical
  });

  return unfulfilled[0];
}

/**
 * Record a measurement for an indicator
 */
export async function recordIndicatorMeasurement(
  userId: number,
  indicatorId: number,
  value: number,
  source: string,
  sourceId?: number
): Promise<void> {
  await db.createNeedIndicatorMeasurement({
    userId,
    indicatorId,
    value: value.toString(),
    source,
    sourceId,
    metadata: {},
  });
}

/**
 * Update user need assessment
 */
export async function updateUserNeedAssessment(
  userId: number,
  assessment: NeedAssessment
): Promise<void> {
  await db.upsertUserNeedAssessment({
    userId,
    categoryId: assessment.categoryId,
    fulfillmentLevel: assessment.fulfillmentLevel.toString(),
    trend: assessment.trend,
    lastAssessedAt: new Date(),
    assessmentData: {
      indicators: assessment.indicators,
      criticalGaps: assessment.criticalGaps,
    },
    insights: assessment.insights,
    recommendations: assessment.recommendations.join("\n"),
  });
}

/**
 * Run full assessment and update database
 */
export async function runFullAssessment(userId: number): Promise<NeedAssessment[]> {
  const assessments = await assessUserNeeds(userId);

  // Update database with results
  for (const assessment of assessments) {
    await updateUserNeedAssessment(userId, assessment);
  }

  // Log assessment event
  await db.logEvent({
    eventType: "need_assessment_completed",
    direction: "system",
    sourceEngine: "Need Assessment Engine",
    userId,
    entityType: "assessment",
    payload: {
      assessmentCount: assessments.length,
      averageFulfillment: assessments.reduce((sum, a) => sum + a.fulfillmentLevel, 0) / assessments.length,
      criticalNeeds: assessments.filter(a => a.fulfillmentLevel < 50).map(a => a.categoryName),
    },
  });

  return assessments;
}
