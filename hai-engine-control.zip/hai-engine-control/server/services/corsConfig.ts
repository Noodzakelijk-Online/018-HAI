/**
 * CORS Configuration Service
 * Implements P1 #68: Implement proper CORS configuration
 */

export interface CORSOptions {
  origin: string | string[] | boolean | ((origin: string) => boolean);
  methods?: string[];
  allowedHeaders?: string[];
  exposedHeaders?: string[];
  credentials?: boolean;
  maxAge?: number;
  preflightContinue?: boolean;
  optionsSuccessStatus?: number;
}

const DEFAULT_OPTIONS: CORSOptions = {
  origin: false,
  methods: ['GET', 'HEAD', 'PUT', 'PATCH', 'POST', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  exposedHeaders: [],
  credentials: true,
  maxAge: 86400, // 24 hours
  preflightContinue: false,
  optionsSuccessStatus: 204,
};

/**
 * Check if origin is allowed
 */
export function isOriginAllowed(
  requestOrigin: string | undefined,
  allowedOrigin: CORSOptions['origin']
): boolean {
  if (!requestOrigin) return false;
  
  if (allowedOrigin === true) return true;
  if (allowedOrigin === false) return false;
  
  if (typeof allowedOrigin === 'string') {
    return requestOrigin === allowedOrigin;
  }
  
  if (Array.isArray(allowedOrigin)) {
    return allowedOrigin.some(origin => {
      if (origin === '*') return true;
      if (origin.includes('*')) {
        const regex = new RegExp('^' + origin.replace(/\*/g, '.*') + '$');
        return regex.test(requestOrigin);
      }
      return origin === requestOrigin;
    });
  }
  
  if (typeof allowedOrigin === 'function') {
    return allowedOrigin(requestOrigin);
  }
  
  return false;
}

/**
 * CORS middleware
 */
export function corsMiddleware(options: Partial<CORSOptions> = {}) {
  const opts = { ...DEFAULT_OPTIONS, ...options };
  
  return (req: any, res: any, next: any) => {
    const requestOrigin = req.headers.origin;
    
    // Check if origin is allowed
    const originAllowed = isOriginAllowed(requestOrigin, opts.origin);
    
    if (originAllowed && requestOrigin) {
      res.setHeader('Access-Control-Allow-Origin', requestOrigin);
    } else if (opts.origin === '*') {
      res.setHeader('Access-Control-Allow-Origin', '*');
    }
    
    // Credentials
    if (opts.credentials) {
      res.setHeader('Access-Control-Allow-Credentials', 'true');
    }
    
    // Exposed headers
    if (opts.exposedHeaders && opts.exposedHeaders.length > 0) {
      res.setHeader('Access-Control-Expose-Headers', opts.exposedHeaders.join(', '));
    }
    
    // Handle preflight
    if (req.method === 'OPTIONS') {
      // Methods
      if (opts.methods) {
        res.setHeader('Access-Control-Allow-Methods', opts.methods.join(', '));
      }
      
      // Allowed headers
      const requestHeaders = req.headers['access-control-request-headers'];
      if (requestHeaders) {
        res.setHeader('Access-Control-Allow-Headers', requestHeaders);
      } else if (opts.allowedHeaders) {
        res.setHeader('Access-Control-Allow-Headers', opts.allowedHeaders.join(', '));
      }
      
      // Max age
      if (opts.maxAge) {
        res.setHeader('Access-Control-Max-Age', String(opts.maxAge));
      }
      
      if (opts.preflightContinue) {
        next();
      } else {
        res.status(opts.optionsSuccessStatus || 204).end();
      }
      return;
    }
    
    next();
  };
}

/**
 * Environment-based CORS configuration
 */
export function getEnvironmentCORS(): CORSOptions {
  const env = process.env.NODE_ENV;
  
  if (env === 'development') {
    return {
      ...DEFAULT_OPTIONS,
      origin: true, // Allow all origins in development
    };
  }
  
  // Production - restrict to known origins
  const allowedOrigins = (process.env.ALLOWED_ORIGINS || '')
    .split(',')
    .map(o => o.trim())
    .filter(Boolean);
  
  return {
    ...DEFAULT_OPTIONS,
    origin: allowedOrigins.length > 0 ? allowedOrigins : false,
  };
}

/**
 * Create CORS options for specific routes
 */
export function createRouteCORS(routeOptions: Partial<CORSOptions>): CORSOptions {
  return { ...DEFAULT_OPTIONS, ...routeOptions };
}

/**
 * CORS configuration presets
 */
export const corsPresets = {
  // Public API - allow all origins
  publicApi: {
    origin: '*',
    methods: ['GET', 'POST'],
    credentials: false,
  } as CORSOptions,
  
  // Private API - same origin only
  privateApi: {
    origin: false,
    credentials: true,
  } as CORSOptions,
  
  // Webhook endpoints - allow specific origins
  webhook: (origins: string[]): CORSOptions => ({
    origin: origins,
    methods: ['POST'],
    credentials: false,
    maxAge: 3600,
  }),
  
  // OAuth callbacks - allow OAuth providers
  oauth: {
    origin: true,
    methods: ['GET', 'POST'],
    credentials: true,
  } as CORSOptions,
  
  // WebSocket - allow upgrade
  websocket: {
    origin: true,
    credentials: true,
    methods: ['GET'],
  } as CORSOptions,
};

/**
 * Dynamic CORS based on request
 */
export function dynamicCORS(
  getOptions: (req: any) => CORSOptions | Promise<CORSOptions>
) {
  return async (req: any, res: any, next: any) => {
    const options = await getOptions(req);
    return corsMiddleware(options)(req, res, next);
  };
}

/**
 * Validate CORS configuration
 */
export function validateCORSConfig(options: CORSOptions): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Check for dangerous configurations
  if (options.origin === '*' && options.credentials) {
    errors.push('Cannot use wildcard origin with credentials');
  }
  
  if (options.origin === true && process.env.NODE_ENV === 'production') {
    errors.push('Allowing all origins in production is not recommended');
  }
  
  if (!options.methods || options.methods.length === 0) {
    errors.push('No HTTP methods specified');
  }
  
  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Log CORS requests for debugging
 */
export function corsLogger() {
  return (req: any, res: any, next: any) => {
    if (req.headers.origin) {
      console.log('[CORS]', {
        origin: req.headers.origin,
        method: req.method,
        path: req.path,
        allowed: res.getHeader('Access-Control-Allow-Origin') ? 'yes' : 'no',
      });
    }
    next();
  };
}

export default {
  corsMiddleware,
  isOriginAllowed,
  getEnvironmentCORS,
  createRouteCORS,
  corsPresets,
  dynamicCORS,
  validateCORSConfig,
  corsLogger,
  DEFAULT_OPTIONS,
};
