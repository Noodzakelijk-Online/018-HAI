/**
 * N+1 Query Detection
 * Implements P1 #80: Add N+1 query detection
 */

export interface QueryPattern {
  pattern: string;
  count: number;
  queries: string[];
  timestamp: Date;
}

export interface N1Detection {
  detected: boolean;
  pattern: string;
  count: number;
  threshold: number;
  suggestion: string;
}

// Configuration
const CONFIG = {
  threshold: 5, // Minimum similar queries to trigger detection
  windowMs: 5000, // Time window for detection (5 seconds)
  maxPatterns: 100,
};

// Query tracking
const queryPatterns: Map<string, QueryPattern> = new Map();
const detections: N1Detection[] = [];

/**
 * Normalize query to pattern
 */
function normalizeToPattern(query: string): string {
  return query
    .replace(/\s+/g, ' ')
    .replace(/= ?'[^']*'/g, "= ?")
    .replace(/= ?\"[^\"]*\"/g, '= ?')
    .replace(/= ?\d+/g, '= ?')
    .replace(/IN ?\([^)]+\)/gi, 'IN (?)')
    .replace(/LIMIT \d+/gi, 'LIMIT ?')
    .replace(/OFFSET \d+/gi, 'OFFSET ?')
    .trim()
    .toLowerCase();
}

/**
 * Track a query execution
 */
export function trackQuery(query: string): N1Detection | null {
  const pattern = normalizeToPattern(query);
  const now = new Date();
  
  // Get or create pattern entry
  let entry = queryPatterns.get(pattern);
  
  if (!entry) {
    entry = {
      pattern,
      count: 0,
      queries: [],
      timestamp: now,
    };
    queryPatterns.set(pattern, entry);
  }
  
  // Check if within time window
  const timeDiff = now.getTime() - entry.timestamp.getTime();
  if (timeDiff > CONFIG.windowMs) {
    // Reset if outside window
    entry.count = 0;
    entry.queries = [];
    entry.timestamp = now;
  }
  
  // Increment count
  entry.count++;
  entry.queries.push(query);
  
  // Check for N+1
  if (entry.count >= CONFIG.threshold) {
    const detection: N1Detection = {
      detected: true,
      pattern,
      count: entry.count,
      threshold: CONFIG.threshold,
      suggestion: generateSuggestion(pattern, entry.queries),
    };
    
    detections.push(detection);
    
    // Reset after detection
    entry.count = 0;
    entry.queries = [];
    
    console.warn('[N+1 Detection]', {
      pattern,
      count: detection.count,
      suggestion: detection.suggestion,
    });
    
    return detection;
  }
  
  return null;
}

/**
 * Generate optimization suggestion
 */
function generateSuggestion(pattern: string, queries: string[]): string {
  const upperPattern = pattern.toUpperCase();
  
  // Detect common N+1 patterns
  if (upperPattern.includes('WHERE') && upperPattern.includes('= ?')) {
    // Single ID lookup pattern
    const tableMatch = pattern.match(/from\s+(\w+)/i);
    const columnMatch = pattern.match(/where\s+(\w+)\s*=/i);
    
    if (tableMatch && columnMatch) {
      return `Consider using a batch query: SELECT * FROM ${tableMatch[1]} WHERE ${columnMatch[1]} IN (id1, id2, ...) instead of individual queries`;
    }
  }
  
  if (upperPattern.includes('JOIN')) {
    return 'Consider eager loading related data in a single query with JOINs';
  }
  
  return 'Consider batching these queries using IN clause or implementing DataLoader pattern';
}

/**
 * Get recent detections
 */
export function getDetections(limit: number = 10): N1Detection[] {
  return detections.slice(-limit);
}

/**
 * Clear detection history
 */
export function clearDetections(): void {
  detections.length = 0;
  queryPatterns.clear();
}

/**
 * Get current patterns
 */
export function getPatterns(): QueryPattern[] {
  return Array.from(queryPatterns.values());
}

/**
 * Configure detection settings
 */
export function configure(options: Partial<typeof CONFIG>): void {
  Object.assign(CONFIG, options);
}

/**
 * Get configuration
 */
export function getConfig(): typeof CONFIG {
  return { ...CONFIG };
}

/**
 * Middleware for automatic tracking
 */
export function n1DetectionMiddleware() {
  return (req: any, res: any, next: any) => {
    // Store original query function
    const originalQuery = req.db?.query;
    
    if (originalQuery) {
      req.db.query = async (...args: any[]) => {
        const query = args[0];
        if (typeof query === 'string') {
          trackQuery(query);
        }
        return originalQuery.apply(req.db, args);
      };
    }
    
    next();
  };
}

/**
 * Drizzle query wrapper with N+1 detection
 */
export function wrapDrizzleQuery<T extends (...args: any[]) => Promise<any>>(
  queryFn: T,
  queryName: string
): T {
  return (async (...args: any[]) => {
    trackQuery(`${queryName}: ${JSON.stringify(args).slice(0, 100)}`);
    return queryFn(...args);
  }) as T;
}

/**
 * DataLoader-style batching helper
 */
export class QueryBatcher<K, V> {
  private batch: Map<K, { resolve: (v: V) => void; reject: (e: Error) => void }[]> = new Map();
  private batchFn: (keys: K[]) => Promise<Map<K, V>>;
  private timeout: NodeJS.Timeout | null = null;
  private batchDelayMs: number;
  
  constructor(
    batchFn: (keys: K[]) => Promise<Map<K, V>>,
    batchDelayMs: number = 10
  ) {
    this.batchFn = batchFn;
    this.batchDelayMs = batchDelayMs;
  }
  
  async load(key: K): Promise<V> {
    return new Promise((resolve, reject) => {
      const existing = this.batch.get(key);
      if (existing) {
        existing.push({ resolve, reject });
      } else {
        this.batch.set(key, [{ resolve, reject }]);
      }
      
      this.scheduleBatch();
    });
  }
  
  private scheduleBatch(): void {
    if (this.timeout) return;
    
    this.timeout = setTimeout(async () => {
      this.timeout = null;
      
      const currentBatch = new Map(this.batch);
      this.batch.clear();
      
      const keys = Array.from(currentBatch.keys());
      
      try {
        const results = await this.batchFn(keys);
        
        for (const [key, callbacks] of currentBatch) {
          const value = results.get(key);
          for (const { resolve, reject } of callbacks) {
            if (value !== undefined) {
              resolve(value);
            } else {
              reject(new Error(`No result for key: ${key}`));
            }
          }
        }
      } catch (error) {
        for (const callbacks of currentBatch.values()) {
          for (const { reject } of callbacks) {
            reject(error instanceof Error ? error : new Error(String(error)));
          }
        }
      }
    }, this.batchDelayMs);
  }
  
  clear(): void {
    this.batch.clear();
    if (this.timeout) {
      clearTimeout(this.timeout);
      this.timeout = null;
    }
  }
}

/**
 * Statistics
 */
export function getStats(): {
  totalDetections: number;
  activePatterns: number;
  recentDetections: number;
} {
  const fiveMinutesAgo = Date.now() - 5 * 60 * 1000;
  const recentDetections = detections.filter(d => 
    new Date().getTime() - fiveMinutesAgo < 5 * 60 * 1000
  ).length;
  
  return {
    totalDetections: detections.length,
    activePatterns: queryPatterns.size,
    recentDetections,
  };
}

export default {
  trackQuery,
  getDetections,
  clearDetections,
  getPatterns,
  configure,
  getConfig,
  n1DetectionMiddleware,
  wrapDrizzleQuery,
  QueryBatcher,
  getStats,
};
