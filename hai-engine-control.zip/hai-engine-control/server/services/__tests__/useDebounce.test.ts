import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { renderHook, act, waitFor } from '@testing-library/react';
import { useDebounce, useDebouncedState, useDebouncedCallback } from '../useDebounce';

describe('useDebounce', () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  describe('useDebounce hook', () => {
    it('should return initial value immediately', () => {
      const { result } = renderHook(() => useDebounce('initial', 300));
      expect(result.current).toBe('initial');
    });

    it('should debounce value changes', () => {
      const { result, rerender } = renderHook(
        ({ value }) => useDebounce(value, 300),
        { initialProps: { value: 'initial' } }
      );

      expect(result.current).toBe('initial');

      // Change value
      rerender({ value: 'changed' });
      
      // Should still be initial (not yet debounced)
      expect(result.current).toBe('initial');

      // Fast-forward time
      act(() => {
        vi.advanceTimersByTime(300);
      });

      // Now should be updated
      expect(result.current).toBe('changed');
    });

    it('should reset timer on rapid changes', () => {
      const { result, rerender } = renderHook(
        ({ value }) => useDebounce(value, 300),
        { initialProps: { value: 'a' } }
      );

      // Rapid changes
      rerender({ value: 'b' });
      act(() => { vi.advanceTimersByTime(100); });
      
      rerender({ value: 'c' });
      act(() => { vi.advanceTimersByTime(100); });
      
      rerender({ value: 'd' });
      act(() => { vi.advanceTimersByTime(100); });

      // Should still be 'a' (timer keeps resetting)
      expect(result.current).toBe('a');

      // Wait full delay
      act(() => { vi.advanceTimersByTime(300); });

      // Now should be final value
      expect(result.current).toBe('d');
    });
  });

  describe('useDebouncedState hook', () => {
    it('should return immediate value, debounced value, and setter', () => {
      const { result } = renderHook(() => useDebouncedState('initial', 300));
      
      const [value, debouncedValue, setValue] = result.current;
      
      expect(value).toBe('initial');
      expect(debouncedValue).toBe('initial');
      expect(typeof setValue).toBe('function');
    });

    it('should update immediate value immediately but debounce the other', () => {
      const { result } = renderHook(() => useDebouncedState('initial', 300));

      // Update value
      act(() => {
        result.current[2]('changed');
      });

      // Immediate value should update
      expect(result.current[0]).toBe('changed');
      // Debounced value should still be initial
      expect(result.current[1]).toBe('initial');

      // Wait for debounce
      act(() => { vi.advanceTimersByTime(300); });

      // Now both should be updated
      expect(result.current[0]).toBe('changed');
      expect(result.current[1]).toBe('changed');
    });
  });

  describe('useDebouncedCallback hook', () => {
    it('should debounce callback execution', () => {
      const callback = vi.fn();
      const { result } = renderHook(() => useDebouncedCallback(callback, 300));

      // Call multiple times rapidly
      act(() => {
        result.current('a');
        result.current('b');
        result.current('c');
      });

      // Callback should not have been called yet
      expect(callback).not.toHaveBeenCalled();

      // Wait for debounce
      act(() => { vi.advanceTimersByTime(300); });

      // Callback should be called once with last value
      expect(callback).toHaveBeenCalledTimes(1);
      expect(callback).toHaveBeenCalledWith('c');
    });

    it('should pass all arguments to callback', () => {
      const callback = vi.fn();
      const { result } = renderHook(() => useDebouncedCallback(callback, 300));

      act(() => {
        result.current('arg1', 'arg2', 123);
      });

      act(() => { vi.advanceTimersByTime(300); });

      expect(callback).toHaveBeenCalledWith('arg1', 'arg2', 123);
    });
  });
});
