import { describe, it, expect, beforeEach, vi } from 'vitest';
import { cacheService, CacheKeys, CacheTTL } from '../cacheService';

describe('CacheService', () => {
  beforeEach(() => {
    // Clear cache before each test
    cacheService.clear();
  });

  describe('set and get', () => {
    it('should store and retrieve data', () => {
      const testData = { name: 'test', value: 123 };
      cacheService.set('test-key', testData);
      
      const retrieved = cacheService.get<typeof testData>('test-key');
      expect(retrieved).toEqual(testData);
    });

    it('should return undefined for non-existent keys', () => {
      const result = cacheService.get('non-existent');
      expect(result).toBeUndefined();
    });

    it('should return undefined for expired entries', async () => {
      cacheService.set('short-lived', 'data', 10); // 10ms TTL
      
      // Wait for expiration
      await new Promise(resolve => setTimeout(resolve, 20));
      
      const result = cacheService.get('short-lived');
      expect(result).toBeUndefined();
    });
  });

  describe('has', () => {
    it('should return true for existing valid entries', () => {
      cacheService.set('exists', 'data');
      expect(cacheService.has('exists')).toBe(true);
    });

    it('should return false for non-existent entries', () => {
      expect(cacheService.has('does-not-exist')).toBe(false);
    });
  });

  describe('invalidate', () => {
    it('should remove specific cache entry', () => {
      cacheService.set('to-remove', 'data');
      expect(cacheService.has('to-remove')).toBe(true);
      
      cacheService.invalidate('to-remove');
      expect(cacheService.has('to-remove')).toBe(false);
    });
  });

  describe('invalidatePattern', () => {
    it('should remove entries matching pattern', () => {
      cacheService.set('user:1:profile', 'data1');
      cacheService.set('user:2:profile', 'data2');
      cacheService.set('other:key', 'data3');
      
      cacheService.invalidatePattern('^user:');
      
      expect(cacheService.has('user:1:profile')).toBe(false);
      expect(cacheService.has('user:2:profile')).toBe(false);
      expect(cacheService.has('other:key')).toBe(true);
    });
  });

  describe('getOrFetch', () => {
    it('should return cached data without calling fetcher', async () => {
      const fetcher = vi.fn().mockResolvedValue('fresh-data');
      
      // Pre-populate cache
      cacheService.set('cached-key', 'cached-data');
      
      const result = await cacheService.getOrFetch('cached-key', fetcher);
      
      expect(result).toBe('cached-data');
      expect(fetcher).not.toHaveBeenCalled();
    });

    it('should call fetcher and cache result when not cached', async () => {
      const fetcher = vi.fn().mockResolvedValue('fresh-data');
      
      const result = await cacheService.getOrFetch('new-key', fetcher);
      
      expect(result).toBe('fresh-data');
      expect(fetcher).toHaveBeenCalledTimes(1);
      expect(cacheService.get('new-key')).toBe('fresh-data');
    });

    it('should call fetcher when cache is expired', async () => {
      const fetcher = vi.fn().mockResolvedValue('fresh-data');
      
      // Set with very short TTL
      cacheService.set('expiring-key', 'old-data', 10);
      
      // Wait for expiration
      await new Promise(resolve => setTimeout(resolve, 20));
      
      const result = await cacheService.getOrFetch('expiring-key', fetcher);
      
      expect(result).toBe('fresh-data');
      expect(fetcher).toHaveBeenCalledTimes(1);
    });
  });

  describe('CacheKeys', () => {
    it('should generate consistent cache keys', () => {
      expect(CacheKeys.dashboardStats(1)).toBe('dashboard:stats:1');
      expect(CacheKeys.householdData(5)).toBe('household:5');
      expect(CacheKeys.connectorList(10)).toBe('connectors:list:10');
      expect(CacheKeys.agentList(3)).toBe('agents:list:3');
      expect(CacheKeys.todaysActivities(7)).toBe('activities:today:7');
      expect(CacheKeys.approvalQueue(2)).toBe('approval:queue:2');
    });
  });

  describe('CacheTTL', () => {
    it('should have correct TTL values', () => {
      expect(CacheTTL.SHORT).toBe(30 * 1000);
      expect(CacheTTL.MEDIUM).toBe(2 * 60 * 1000);
      expect(CacheTTL.LONG).toBe(10 * 60 * 1000);
      expect(CacheTTL.HOUR).toBe(60 * 60 * 1000);
    });
  });

  describe('getStats', () => {
    it('should return cache statistics', () => {
      cacheService.set('key1', 'data1');
      cacheService.set('key2', 'data2');
      
      const stats = cacheService.getStats();
      
      expect(stats.size).toBe(2);
      expect(stats.maxEntries).toBe(1000);
    });
  });

  describe('clear', () => {
    it('should remove all entries', () => {
      cacheService.set('key1', 'data1');
      cacheService.set('key2', 'data2');
      
      cacheService.clear();
      
      expect(cacheService.getStats().size).toBe(0);
    });
  });
});
