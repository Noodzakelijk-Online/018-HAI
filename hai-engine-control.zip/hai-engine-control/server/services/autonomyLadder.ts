/**
 * Autonomy Ladder Enforcement Service
 * 
 * Implements the 6-level autonomy ladder (0-5) with MVP ceiling at level 2.
 * Ensures tasks respect autonomy constraints and require appropriate approvals.
 */

export interface AutonomyLevel {
  level: number;
  name: string;
  description: string;
  requiresApproval: boolean;
  allowedActions: string[];
  restrictions: string[];
}

/**
 * Autonomy Ladder Levels (RAI v0.3 specification)
 */
export const AUTONOMY_LEVELS: Record<number, AutonomyLevel> = {
  0: {
    level: 0,
    name: "Observe Only",
    description: "System can only observe and log data. No actions taken.",
    requiresApproval: false,
    allowedActions: ["log", "observe", "record", "analyze"],
    restrictions: ["Cannot modify data", "Cannot send messages", "Cannot make decisions"],
  },
  1: {
    level: 1,
    name: "Suggest",
    description: "System can suggest actions but requires explicit approval for each one.",
    requiresApproval: true,
    allowedActions: ["suggest", "draft", "propose", "recommend"],
    restrictions: ["Cannot execute without approval", "Cannot modify external systems"],
  },
  2: {
    level: 2,
    name: "Draft & Approve",
    description: "System can draft actions and execute after single approval (MVP ceiling).",
    requiresApproval: true,
    allowedActions: ["draft", "execute_after_approval", "send", "modify"],
    restrictions: ["Requires approval before execution", "Cannot create new accounts", "Cannot make financial transactions"],
  },
  3: {
    level: 3,
    name: "Execute with Playbook",
    description: "System can execute predefined playbooks without approval.",
    requiresApproval: false,
    allowedActions: ["execute_playbook", "automated_workflows", "scheduled_tasks"],
    restrictions: ["Only predefined playbooks", "Cannot deviate from script", "Requires playbook approval"],
  },
  4: {
    level: 4,
    name: "Autonomous within Policy",
    description: "System can act autonomously within policy constraints.",
    requiresApproval: false,
    allowedActions: ["autonomous_action", "policy_based_decisions", "adaptive_behavior"],
    restrictions: ["Must respect policy boundaries", "Cannot violate constraints", "Requires policy approval"],
  },
  5: {
    level: 5,
    name: "Full Autonomy",
    description: "System has full autonomy with minimal constraints.",
    requiresApproval: false,
    allowedActions: ["unrestricted_action", "policy_modification", "self_improvement"],
    restrictions: ["Must respect legal boundaries", "Cannot harm users", "Requires explicit opt-in"],
  },
};

/**
 * MVP ceiling - maximum autonomy level allowed in current version
 */
export const MVP_CEILING = 2;

/**
 * Check if a task's autonomy level is within MVP ceiling
 */
export function isWithinMVPCeiling(autonomyLevel: number): boolean {
  return autonomyLevel <= MVP_CEILING;
}

/**
 * Check if a task requires approval based on its autonomy level
 */
export function requiresApproval(autonomyLevel: number): boolean {
  if (autonomyLevel > MVP_CEILING) {
    throw new Error(`Autonomy level ${autonomyLevel} exceeds MVP ceiling of ${MVP_CEILING}`);
  }
  return AUTONOMY_LEVELS[autonomyLevel]?.requiresApproval ?? true;
}

/**
 * Validate that a task can be executed at the requested autonomy level
 */
export function validateAutonomyLevel(
  autonomyLevel: number,
  taskType: string,
  action: string
): { valid: boolean; reason?: string } {
  // Check MVP ceiling
  if (!isWithinMVPCeiling(autonomyLevel)) {
    return {
      valid: false,
      reason: `Autonomy level ${autonomyLevel} exceeds MVP ceiling of ${MVP_CEILING}. Please reduce the autonomy level or wait for future releases.`,
    };
  }

  // Get level configuration
  const levelConfig = AUTONOMY_LEVELS[autonomyLevel];
  if (!levelConfig) {
    return {
      valid: false,
      reason: `Invalid autonomy level: ${autonomyLevel}. Must be between 0 and 5.`,
    };
  }

  // Check if action is allowed at this level
  const actionAllowed = levelConfig.allowedActions.some((allowed) =>
    action.toLowerCase().includes(allowed.toLowerCase())
  );

  if (!actionAllowed) {
    return {
      valid: false,
      reason: `Action "${action}" is not allowed at autonomy level ${autonomyLevel} (${levelConfig.name}). Allowed actions: ${levelConfig.allowedActions.join(", ")}`,
    };
  }

  return { valid: true };
}

/**
 * Get the appropriate autonomy level for a task type
 */
export function getRecommendedAutonomyLevel(taskType: string): number {
  const recommendations: Record<string, number> = {
    email: 2, // Draft & Approve
    calendar: 1, // Suggest
    finance: 1, // Suggest (sensitive)
    research: 0, // Observe Only
    automation: 2, // Draft & Approve
    communication: 2, // Draft & Approve
  };

  return recommendations[taskType] ?? 1; // Default to Suggest
}

/**
 * Determine if a task should transition to pending_approval status
 */
export function shouldRequireApproval(
  autonomyLevel: number,
  taskType: string,
  currentStatus: string
): boolean {
  // Always require approval for levels 1-2
  if (autonomyLevel >= 1 && autonomyLevel <= 2) {
    return currentStatus === "draft";
  }

  // Level 0 (observe only) doesn't require approval
  if (autonomyLevel === 0) {
    return false;
  }

  // Levels 3+ would require approval but are blocked by MVP ceiling
  return false;
}

/**
 * Get autonomy level information
 */
export function getAutonomyLevelInfo(level: number): AutonomyLevel | null {
  return AUTONOMY_LEVELS[level] ?? null;
}

/**
 * Enforce autonomy ladder rules when creating a task
 */
export function enforceAutonomyRules(task: {
  autonomyLevel: number;
  taskType: string;
  status: string;
}): {
  valid: boolean;
  suggestedStatus?: string;
  suggestedAutonomyLevel?: number;
  reason?: string;
} {
  // Check MVP ceiling
  if (!isWithinMVPCeiling(task.autonomyLevel)) {
    return {
      valid: false,
      suggestedAutonomyLevel: MVP_CEILING,
      reason: `Autonomy level ${task.autonomyLevel} exceeds MVP ceiling. Suggested: Level ${MVP_CEILING}`,
    };
  }

  // Check if approval is required
  if (requiresApproval(task.autonomyLevel) && task.status === "draft") {
    return {
      valid: true,
      suggestedStatus: "pending_approval",
      reason: `Tasks at autonomy level ${task.autonomyLevel} require approval before execution`,
    };
  }

  return { valid: true };
}

/**
 * Check if a user can approve a task (for future role-based access control)
 */
export function canApproveTask(
  userRole: string,
  taskAutonomyLevel: number
): boolean {
  // For MVP, only admins/owners can approve
  // In future, this could be more granular based on autonomy level
  return userRole === "admin" || userRole === "owner";
}

/**
 * Get human-readable autonomy level description
 */
export function getAutonomyDescription(level: number): string {
  const info = getAutonomyLevelInfo(level);
  if (!info) return `Unknown autonomy level: ${level}`;
  
  return `Level ${level}: ${info.name} - ${info.description}`;
}

/**
 * Validate task transition based on autonomy rules
 */
export function validateTaskTransition(
  currentStatus: string,
  newStatus: string,
  autonomyLevel: number
): { valid: boolean; reason?: string } {
  // Draft → Pending Approval (required for levels 1-2)
  if (currentStatus === "draft" && newStatus === "pending_approval") {
    if (requiresApproval(autonomyLevel)) {
      return { valid: true };
    }
    return {
      valid: false,
      reason: `Tasks at autonomy level ${autonomyLevel} do not require approval`,
    };
  }

  // Pending Approval → Approved
  if (currentStatus === "pending_approval" && newStatus === "approved") {
    return { valid: true };
  }

  // Pending Approval → Rejected (cancelled)
  if (currentStatus === "pending_approval" && newStatus === "cancelled") {
    return { valid: true };
  }

  // Approved → In Progress
  if (currentStatus === "approved" && newStatus === "in_progress") {
    return { valid: true };
  }

  // In Progress → Completed
  if (currentStatus === "in_progress" && newStatus === "completed") {
    return { valid: true };
  }

  // In Progress → Failed
  if (currentStatus === "in_progress" && newStatus === "failed") {
    return { valid: true };
  }

  return {
    valid: false,
    reason: `Invalid status transition: ${currentStatus} → ${newStatus}`,
  };
}
