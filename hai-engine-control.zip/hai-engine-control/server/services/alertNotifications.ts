/**
 * Alert Notification Service
 * Monitors metrics and triggers alerts when thresholds are exceeded
 */

import { EventEmitter } from 'events';
import { metricsStreaming, SystemMetrics } from './metricsStreaming';
import { getMonitoringConfig } from '../config/production';
import { createLogger } from './logger';

const logger = createLogger('AlertNotifications');

export type AlertSeverity = 'info' | 'warning' | 'critical';
export type AlertChannel = 'email' | 'in_app' | 'webhook' | 'slack';

export interface AlertRule {
  id: string;
  name: string;
  description: string;
  condition: (metrics: SystemMetrics) => boolean;
  severity: AlertSeverity;
  channels: AlertChannel[];
  cooldownMs: number; // Minimum time between alerts
  enabled: boolean;
}

export interface Alert {
  id: string;
  ruleId: string;
  ruleName: string;
  severity: AlertSeverity;
  message: string;
  timestamp: Date;
  metrics: Partial<SystemMetrics>;
  acknowledged: boolean;
  acknowledgedBy?: number;
  acknowledgedAt?: Date;
  resolvedAt?: Date;
}

export interface AlertNotification {
  alertId: string;
  channel: AlertChannel;
  recipient?: string;
  sentAt: Date;
  success: boolean;
  error?: string;
}

class AlertNotificationService extends EventEmitter {
  private rules: Map<string, AlertRule> = new Map();
  private alerts: Alert[] = [];
  private notifications: AlertNotification[] = [];
  private lastAlertTime: Map<string, number> = new Map();
  private maxAlerts = 1000;
  private maxNotifications = 5000;
  private isMonitoring = false;

  constructor() {
    super();
    this.initializeDefaultRules();
  }

  /**
   * Initialize default alert rules based on production config
   */
  private initializeDefaultRules(): void {
    const config = getMonitoringConfig();
    const thresholds = config.alertThresholds;

    // High error rate alert
    this.addRule({
      id: 'high-error-rate',
      name: 'High Error Rate',
      description: `Error rate exceeds ${thresholds.errorRatePercent}%`,
      condition: (metrics) => metrics.requests.errorRate > thresholds.errorRatePercent,
      severity: 'critical',
      channels: ['in_app', 'email'],
      cooldownMs: 300000, // 5 minutes
      enabled: true,
    });

    // Slow response time alert
    this.addRule({
      id: 'slow-response-time',
      name: 'Slow Response Time',
      description: `Average response time exceeds ${thresholds.responseTimeMs}ms`,
      condition: (metrics) => metrics.requests.avgResponseTime > thresholds.responseTimeMs,
      severity: 'warning',
      channels: ['in_app'],
      cooldownMs: 600000, // 10 minutes
      enabled: true,
    });

    // High memory usage alert
    this.addRule({
      id: 'high-memory-usage',
      name: 'High Memory Usage',
      description: `Memory usage exceeds ${thresholds.memoryUsagePercent}%`,
      condition: (metrics) => metrics.memory.usagePercent > thresholds.memoryUsagePercent,
      severity: 'critical',
      channels: ['in_app', 'email'],
      cooldownMs: 600000, // 10 minutes
      enabled: true,
    });

    // High CPU usage alert
    this.addRule({
      id: 'high-cpu-usage',
      name: 'High CPU Usage',
      description: 'CPU usage exceeds 90%',
      condition: (metrics) => metrics.cpu.usage > 90,
      severity: 'warning',
      channels: ['in_app'],
      cooldownMs: 300000, // 5 minutes
      enabled: true,
    });

    // No requests alert (potential downtime)
    this.addRule({
      id: 'no-requests',
      name: 'No Incoming Requests',
      description: 'No requests received in monitoring period',
      condition: (metrics) => metrics.requests.perSecond === 0 && metrics.uptime > 60,
      severity: 'info',
      channels: ['in_app'],
      cooldownMs: 1800000, // 30 minutes
      enabled: true,
    });
  }

  /**
   * Add a custom alert rule
   */
  addRule(rule: AlertRule): void {
    this.rules.set(rule.id, rule);
    logger.info(`Alert rule added: ${rule.name}`, { ruleId: rule.id });
  }

  /**
   * Remove an alert rule
   */
  removeRule(ruleId: string): boolean {
    const removed = this.rules.delete(ruleId);
    if (removed) {
      logger.info(`Alert rule removed`, { ruleId });
    }
    return removed;
  }

  /**
   * Enable/disable a rule
   */
  setRuleEnabled(ruleId: string, enabled: boolean): boolean {
    const rule = this.rules.get(ruleId);
    if (rule) {
      rule.enabled = enabled;
      logger.info(`Alert rule ${enabled ? 'enabled' : 'disabled'}`, { ruleId });
      return true;
    }
    return false;
  }

  /**
   * Start monitoring metrics for alerts
   */
  startMonitoring(): void {
    if (this.isMonitoring) return;

    logger.info('Starting alert monitoring');
    this.isMonitoring = true;

    metricsStreaming.on('metrics', (metrics: SystemMetrics) => {
      this.checkAlerts(metrics);
    });
  }

  /**
   * Stop monitoring
   */
  stopMonitoring(): void {
    this.isMonitoring = false;
    metricsStreaming.removeAllListeners('metrics');
    logger.info('Stopped alert monitoring');
  }

  /**
   * Check all rules against current metrics
   */
  private checkAlerts(metrics: SystemMetrics): void {
    for (const [ruleId, rule] of this.rules) {
      if (!rule.enabled) continue;

      // Check cooldown
      const lastAlert = this.lastAlertTime.get(ruleId) || 0;
      if (Date.now() - lastAlert < rule.cooldownMs) continue;

      try {
        if (rule.condition(metrics)) {
          this.triggerAlert(rule, metrics);
        }
      } catch (error) {
        logger.error(`Error checking alert rule ${ruleId}`, error as Error);
      }
    }
  }

  /**
   * Trigger an alert
   */
  private triggerAlert(rule: AlertRule, metrics: SystemMetrics): void {
    const alert: Alert = {
      id: `alert-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      ruleId: rule.id,
      ruleName: rule.name,
      severity: rule.severity,
      message: rule.description,
      timestamp: new Date(),
      metrics: {
        cpu: metrics.cpu,
        memory: metrics.memory,
        requests: metrics.requests,
      },
      acknowledged: false,
    };

    // Store alert
    this.alerts.push(alert);
    if (this.alerts.length > this.maxAlerts) {
      this.alerts = this.alerts.slice(-this.maxAlerts);
    }

    // Update last alert time
    this.lastAlertTime.set(rule.id, Date.now());

    // Emit event
    this.emit('alert', alert);

    // Send notifications
    this.sendNotifications(alert, rule.channels);

    logger.warn(`Alert triggered: ${rule.name}`, {
      alertId: alert.id,
      severity: rule.severity,
      metrics: alert.metrics,
    });
  }

  /**
   * Send notifications through configured channels
   */
  private async sendNotifications(alert: Alert, channels: AlertChannel[]): Promise<void> {
    for (const channel of channels) {
      const notification: AlertNotification = {
        alertId: alert.id,
        channel,
        sentAt: new Date(),
        success: false,
      };

      try {
        switch (channel) {
          case 'in_app':
            await this.sendInAppNotification(alert);
            notification.success = true;
            break;
          case 'email':
            await this.sendEmailNotification(alert);
            notification.success = true;
            break;
          case 'webhook':
            await this.sendWebhookNotification(alert);
            notification.success = true;
            break;
          case 'slack':
            await this.sendSlackNotification(alert);
            notification.success = true;
            break;
        }
      } catch (error) {
        notification.error = error instanceof Error ? error.message : 'Unknown error';
        logger.error(`Failed to send ${channel} notification`, error as Error);
      }

      this.notifications.push(notification);
      if (this.notifications.length > this.maxNotifications) {
        this.notifications = this.notifications.slice(-this.maxNotifications);
      }
    }
  }

  /**
   * Send in-app notification
   */
  private async sendInAppNotification(alert: Alert): Promise<void> {
    // Emit event for real-time UI updates
    this.emit('in_app_notification', {
      type: 'alert',
      severity: alert.severity,
      title: alert.ruleName,
      message: alert.message,
      timestamp: alert.timestamp,
      alertId: alert.id,
    });
    logger.info(`In-app notification sent for alert ${alert.id}`);
  }

  /**
   * Send email notification
   */
  private async sendEmailNotification(alert: Alert): Promise<void> {
    // Use the notification service to send owner notification
    try {
      const { notifyOwner } = await import('../_core/notification');
      await notifyOwner({
        title: `[${alert.severity.toUpperCase()}] ${alert.ruleName}`,
        content: `
Alert: ${alert.ruleName}
Severity: ${alert.severity}
Time: ${alert.timestamp.toISOString()}
Message: ${alert.message}

Metrics:
- CPU Usage: ${alert.metrics.cpu?.usage}%
- Memory Usage: ${alert.metrics.memory?.usagePercent}%
- Error Rate: ${alert.metrics.requests?.errorRate}%
- Avg Response Time: ${alert.metrics.requests?.avgResponseTime}ms
        `.trim(),
      });
      logger.info(`Email notification sent for alert ${alert.id}`);
    } catch (error) {
      logger.error('Failed to send email notification', error as Error);
      throw error;
    }
  }

  /**
   * Send webhook notification
   */
  private async sendWebhookNotification(alert: Alert): Promise<void> {
    const webhookUrl = process.env.ALERT_WEBHOOK_URL;
    if (!webhookUrl) {
      logger.warn('Webhook URL not configured, skipping webhook notification');
      return;
    }

    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: 'alert',
        alert,
      }),
    });

    if (!response.ok) {
      throw new Error(`Webhook failed: ${response.status}`);
    }
    logger.info(`Webhook notification sent for alert ${alert.id}`);
  }

  /**
   * Send Slack notification
   */
  private async sendSlackNotification(alert: Alert): Promise<void> {
    const slackWebhookUrl = process.env.SLACK_WEBHOOK_URL;
    if (!slackWebhookUrl) {
      logger.warn('Slack webhook URL not configured, skipping Slack notification');
      return;
    }

    const color = alert.severity === 'critical' ? '#dc2626' : 
                  alert.severity === 'warning' ? '#f59e0b' : '#3b82f6';

    const response = await fetch(slackWebhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        attachments: [{
          color,
          title: `[${alert.severity.toUpperCase()}] ${alert.ruleName}`,
          text: alert.message,
          fields: [
            { title: 'CPU', value: `${alert.metrics.cpu?.usage}%`, short: true },
            { title: 'Memory', value: `${alert.metrics.memory?.usagePercent}%`, short: true },
            { title: 'Error Rate', value: `${alert.metrics.requests?.errorRate}%`, short: true },
            { title: 'Response Time', value: `${alert.metrics.requests?.avgResponseTime}ms`, short: true },
          ],
          ts: Math.floor(alert.timestamp.getTime() / 1000),
        }],
      }),
    });

    if (!response.ok) {
      throw new Error(`Slack webhook failed: ${response.status}`);
    }
    logger.info(`Slack notification sent for alert ${alert.id}`);
  }

  /**
   * Acknowledge an alert
   */
  acknowledgeAlert(alertId: string, userId: number): boolean {
    const alert = this.alerts.find(a => a.id === alertId);
    if (alert && !alert.acknowledged) {
      alert.acknowledged = true;
      alert.acknowledgedBy = userId;
      alert.acknowledgedAt = new Date();
      this.emit('alert_acknowledged', alert);
      logger.info(`Alert acknowledged`, { alertId, userId });
      return true;
    }
    return false;
  }

  /**
   * Resolve an alert
   */
  resolveAlert(alertId: string): boolean {
    const alert = this.alerts.find(a => a.id === alertId);
    if (alert && !alert.resolvedAt) {
      alert.resolvedAt = new Date();
      this.emit('alert_resolved', alert);
      logger.info(`Alert resolved`, { alertId });
      return true;
    }
    return false;
  }

  /**
   * Get all alerts
   */
  getAlerts(options?: {
    severity?: AlertSeverity;
    acknowledged?: boolean;
    limit?: number;
  }): Alert[] {
    let alerts = [...this.alerts];

    if (options?.severity) {
      alerts = alerts.filter(a => a.severity === options.severity);
    }
    if (options?.acknowledged !== undefined) {
      alerts = alerts.filter(a => a.acknowledged === options.acknowledged);
    }

    alerts.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

    if (options?.limit) {
      alerts = alerts.slice(0, options.limit);
    }

    return alerts;
  }

  /**
   * Get active (unacknowledged) alerts
   */
  getActiveAlerts(): Alert[] {
    return this.getAlerts({ acknowledged: false });
  }

  /**
   * Get all rules
   */
  getRules(): AlertRule[] {
    return Array.from(this.rules.values());
  }

  /**
   * Get alert statistics
   */
  getStats(): {
    total: number;
    bySeverity: Record<AlertSeverity, number>;
    unacknowledged: number;
    last24h: number;
  } {
    const now = Date.now();
    const dayAgo = now - 86400000;

    const bySeverity: Record<AlertSeverity, number> = {
      info: 0,
      warning: 0,
      critical: 0,
    };

    let unacknowledged = 0;
    let last24h = 0;

    for (const alert of this.alerts) {
      bySeverity[alert.severity]++;
      if (!alert.acknowledged) unacknowledged++;
      if (alert.timestamp.getTime() > dayAgo) last24h++;
    }

    return {
      total: this.alerts.length,
      bySeverity,
      unacknowledged,
      last24h,
    };
  }
}

// Singleton instance
export const alertNotifications = new AlertNotificationService();

// Auto-start monitoring
alertNotifications.startMonitoring();

export default alertNotifications;
