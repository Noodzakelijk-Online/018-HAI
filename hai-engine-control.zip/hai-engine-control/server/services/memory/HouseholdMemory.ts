/**
 * HOUSEHOLD MEMORY & CONTEXT SYSTEM
 * 
 * Maintains persistent knowledge about the household:
 * - Facts and preferences
 * - Relationships and dynamics
 * - Historical context
 * - Conflict resolution
 */

export type MemoryType = 'fact' | 'preference' | 'event' | 'relationship' | 'routine' | 'conflict' | 'resolution';
export type MemoryImportance = 'critical' | 'high' | 'medium' | 'low';
export type ConflictStatus = 'active' | 'mediating' | 'resolved' | 'escalated';

export interface HouseholdMemory {
  id: number;
  householdId: number;
  type: MemoryType;
  category: string;
  subject: string;
  content: string;
  importance: MemoryImportance;
  relatedMembers: number[];
  tags: string[];
  source: string;
  confidence: number;
  validFrom?: Date;
  validUntil?: Date;
  lastAccessedAt: Date;
  accessCount: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface ConflictRecord {
  id: number;
  householdId: number;
  title: string;
  description: string;
  involvedMembers: number[];
  status: ConflictStatus;
  severity: 'minor' | 'moderate' | 'major';
  category: string;
  rootCause?: string;
  mediationAttempts: Array<{
    timestamp: Date;
    approach: string;
    outcome: string;
    success: boolean;
  }>;
  resolution?: {
    approach: string;
    outcome: string;
    agreedBy: number[];
    resolvedAt: Date;
  };
  preventionSuggestions: string[];
  createdAt: Date;
  updatedAt: Date;
}

export interface ContextSnapshot {
  householdId: number;
  timestamp: Date;
  activeMembers: number[];
  currentActivities: string[];
  recentEvents: string[];
  pendingTasks: string[];
  mood: 'positive' | 'neutral' | 'tense';
  relevantMemories: HouseholdMemory[];
}

const memoryStore: Map<number, HouseholdMemory> = new Map();
const conflictStore: Map<number, ConflictRecord> = new Map();
let memoryIdCounter = 1;
let conflictIdCounter = 1;

export class HouseholdMemoryService {
  private static instance: HouseholdMemoryService;
  private constructor() {}
  static getInstance(): HouseholdMemoryService {
    if (!HouseholdMemoryService.instance) {
      HouseholdMemoryService.instance = new HouseholdMemoryService();
    }
    return HouseholdMemoryService.instance;
  }

  // ============================================================================
  // MEMORY MANAGEMENT
  // ============================================================================

  async storeMemory(householdId: number, data: {
    type: MemoryType;
    category: string;
    subject: string;
    content: string;
    importance?: MemoryImportance;
    relatedMembers?: number[];
    tags?: string[];
    source: string;
    confidence?: number;
    validFrom?: Date;
    validUntil?: Date;
  }): Promise<HouseholdMemory> {
    const memory: HouseholdMemory = {
      id: memoryIdCounter++,
      householdId,
      type: data.type,
      category: data.category,
      subject: data.subject,
      content: data.content,
      importance: data.importance || 'medium',
      relatedMembers: data.relatedMembers || [],
      tags: data.tags || [],
      source: data.source,
      confidence: data.confidence || 1,
      validFrom: data.validFrom,
      validUntil: data.validUntil,
      lastAccessedAt: new Date(),
      accessCount: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    memoryStore.set(memory.id, memory);
    return memory;
  }

  async recallMemory(memoryId: number): Promise<HouseholdMemory | undefined> {
    const memory = memoryStore.get(memoryId);
    if (memory) {
      memory.lastAccessedAt = new Date();
      memory.accessCount++;
    }
    return memory;
  }

  async searchMemories(householdId: number, query: {
    type?: MemoryType;
    category?: string;
    tags?: string[];
    memberId?: number;
    keyword?: string;
    importance?: MemoryImportance;
    limit?: number;
  }): Promise<HouseholdMemory[]> {
    let memories = Array.from(memoryStore.values()).filter(m => m.householdId === householdId);

    if (query.type) memories = memories.filter(m => m.type === query.type);
    if (query.category) memories = memories.filter(m => m.category === query.category);
    if (query.importance) memories = memories.filter(m => m.importance === query.importance);
    if (query.memberId) memories = memories.filter(m => m.relatedMembers.includes(query.memberId!));
    if (query.tags?.length) memories = memories.filter(m => query.tags!.some(t => m.tags.includes(t)));
    if (query.keyword) {
      const kw = query.keyword.toLowerCase();
      memories = memories.filter(m => 
        m.subject.toLowerCase().includes(kw) || m.content.toLowerCase().includes(kw)
      );
    }

    // Filter out expired memories
    const now = new Date();
    memories = memories.filter(m => !m.validUntil || m.validUntil > now);

    // Sort by importance and recency
    memories.sort((a, b) => {
      const importanceOrder = { critical: 0, high: 1, medium: 2, low: 3 };
      const impDiff = importanceOrder[a.importance] - importanceOrder[b.importance];
      if (impDiff !== 0) return impDiff;
      return b.lastAccessedAt.getTime() - a.lastAccessedAt.getTime();
    });

    return query.limit ? memories.slice(0, query.limit) : memories;
  }

  async updateMemory(memoryId: number, updates: Partial<Pick<HouseholdMemory, 'content' | 'importance' | 'tags' | 'confidence' | 'validUntil'>>): Promise<HouseholdMemory | undefined> {
    const memory = memoryStore.get(memoryId);
    if (!memory) return undefined;
    Object.assign(memory, updates, { updatedAt: new Date() });
    return memory;
  }

  async forgetMemory(memoryId: number): Promise<boolean> {
    return memoryStore.delete(memoryId);
  }

  // ============================================================================
  // CONFLICT RESOLUTION
  // ============================================================================

  async recordConflict(householdId: number, data: {
    title: string;
    description: string;
    involvedMembers: number[];
    severity: 'minor' | 'moderate' | 'major';
    category: string;
    rootCause?: string;
  }): Promise<ConflictRecord> {
    const conflict: ConflictRecord = {
      id: conflictIdCounter++,
      householdId,
      title: data.title,
      description: data.description,
      involvedMembers: data.involvedMembers,
      status: 'active',
      severity: data.severity,
      category: data.category,
      rootCause: data.rootCause,
      mediationAttempts: [],
      preventionSuggestions: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    conflictStore.set(conflict.id, conflict);
    return conflict;
  }

  async attemptMediation(conflictId: number, approach: string, outcome: string, success: boolean): Promise<ConflictRecord | undefined> {
    const conflict = conflictStore.get(conflictId);
    if (!conflict) return undefined;

    conflict.mediationAttempts.push({
      timestamp: new Date(),
      approach,
      outcome,
      success,
    });

    conflict.status = success ? 'resolved' : 'mediating';
    conflict.updatedAt = new Date();

    if (success) {
      conflict.resolution = {
        approach,
        outcome,
        agreedBy: conflict.involvedMembers,
        resolvedAt: new Date(),
      };
    }

    return conflict;
  }

  async resolveConflict(conflictId: number, resolution: {
    approach: string;
    outcome: string;
    agreedBy: number[];
    preventionSuggestions?: string[];
  }): Promise<ConflictRecord | undefined> {
    const conflict = conflictStore.get(conflictId);
    if (!conflict) return undefined;

    conflict.status = 'resolved';
    conflict.resolution = {
      approach: resolution.approach,
      outcome: resolution.outcome,
      agreedBy: resolution.agreedBy,
      resolvedAt: new Date(),
    };
    if (resolution.preventionSuggestions) {
      conflict.preventionSuggestions = resolution.preventionSuggestions;
    }
    conflict.updatedAt = new Date();

    // Store as memory for future reference
    await this.storeMemory(conflict.householdId, {
      type: 'resolution',
      category: conflict.category,
      subject: `Resolved: ${conflict.title}`,
      content: `${conflict.description}\n\nResolution: ${resolution.outcome}`,
      importance: conflict.severity === 'major' ? 'high' : 'medium',
      relatedMembers: conflict.involvedMembers,
      tags: ['conflict', 'resolution', conflict.category],
      source: 'conflict_resolution',
    });

    return conflict;
  }

  async getConflicts(householdId: number, status?: ConflictStatus): Promise<ConflictRecord[]> {
    let conflicts = Array.from(conflictStore.values()).filter(c => c.householdId === householdId);
    if (status) conflicts = conflicts.filter(c => c.status === status);
    return conflicts.sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime());
  }

  async getConflict(conflictId: number): Promise<ConflictRecord | undefined> {
    return conflictStore.get(conflictId);
  }

  // ============================================================================
  // CONTEXT
  // ============================================================================

  async getContextSnapshot(householdId: number): Promise<ContextSnapshot> {
    const recentMemories = await this.searchMemories(householdId, { limit: 10 });
    const activeConflicts = await this.getConflicts(householdId, 'active');

    return {
      householdId,
      timestamp: new Date(),
      activeMembers: [], // Would be populated from presence system
      currentActivities: [],
      recentEvents: recentMemories.filter(m => m.type === 'event').map(m => m.subject),
      pendingTasks: [],
      mood: activeConflicts.length > 0 ? 'tense' : 'neutral',
      relevantMemories: recentMemories,
    };
  }

  // ============================================================================
  // STATISTICS
  // ============================================================================

  async getStatistics(householdId: number): Promise<{
    totalMemories: number;
    byType: Record<MemoryType, number>;
    byImportance: Record<MemoryImportance, number>;
    totalConflicts: number;
    activeConflicts: number;
    resolvedConflicts: number;
    avgMediationAttempts: number;
  }> {
    const memories = Array.from(memoryStore.values()).filter(m => m.householdId === householdId);
    const conflicts = Array.from(conflictStore.values()).filter(c => c.householdId === householdId);

    const byType: Record<MemoryType, number> = { fact: 0, preference: 0, event: 0, relationship: 0, routine: 0, conflict: 0, resolution: 0 };
    const byImportance: Record<MemoryImportance, number> = { critical: 0, high: 0, medium: 0, low: 0 };

    for (const m of memories) { byType[m.type]++; byImportance[m.importance]++; }

    const resolved = conflicts.filter(c => c.status === 'resolved');
    const totalAttempts = conflicts.reduce((sum, c) => sum + c.mediationAttempts.length, 0);

    return {
      totalMemories: memories.length,
      byType,
      byImportance,
      totalConflicts: conflicts.length,
      activeConflicts: conflicts.filter(c => c.status === 'active' || c.status === 'mediating').length,
      resolvedConflicts: resolved.length,
      avgMediationAttempts: conflicts.length > 0 ? totalAttempts / conflicts.length : 0,
    };
  }
}

export const householdMemoryService = HouseholdMemoryService.getInstance();
