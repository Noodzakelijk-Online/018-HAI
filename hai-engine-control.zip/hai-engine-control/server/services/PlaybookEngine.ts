import { getDb } from "../db";
import { playbooks, playbookExecutions, playbookTemplates, tasks, Playbook, PlaybookExecution, InsertPlaybookExecution } from "../../drizzle/schema";
import { eq, desc } from "drizzle-orm";
import { EventBus } from "./EventBus";
import { LLMService } from "./LLMService";
import { CommunicationEngine } from "./CommunicationEngine";

/**
 * Workflow step definition
 */
interface WorkflowStep {
  id: string;
  name: string;
  type: 'action' | 'condition' | 'loop' | 'parallel';
  action?: string; // Engine action to execute
  condition?: string; // Condition to evaluate
  onSuccess?: string; // Next step ID on success
  onFailure?: string; // Next step ID on failure
  params?: Record<string, unknown>;
}

/**
 * Playbook definition structure
 */
interface PlaybookDefinition {
  steps: WorkflowStep[];
  variables?: Record<string, unknown>;
  triggers?: string[]; // Event types that trigger this playbook
  timeout?: number; // Max execution time in seconds
}

/**
 * Execution context
 */
interface ExecutionContext {
  variables: Record<string, unknown>;
  stepResults: Record<string, unknown>;
  startTime: Date;
}

/**
 * Playbook Engine Service
 * 
 * Manages predefined workflows with:
 * - Template library
 * - Workflow versioning
 * - Step-by-step execution
 * - Integration with Task Orchestration
 */
export class PlaybookEngine {
  /**
   * Create a new playbook
   */
  static async createPlaybook(params: {
    name: string;
    description?: string;
    category?: string;
    definition: PlaybookDefinition;
    metadata?: Record<string, unknown>;
  }): Promise<Playbook> {
    const { name, description, category, definition, metadata } = params;

    const db = await getDb();
    if (!db) throw new Error('Database not available');

    // Validate definition
    this.validateDefinition(definition);

    // Create playbook
    await db.insert(playbooks).values({
      name,
      description,
      category,
      version: '1.0.0',
      status: 'draft',
      definition: definition as any,
      metadata: metadata as any,
    });

    const created = await db
      .select()
      .from(playbooks)
      .where(eq(playbooks.name, name))
      .orderBy(desc(playbooks.createdAt))
      .limit(1);

    if (created.length === 0) {
      throw new Error('Failed to create playbook');
    }

    // Publish event
    await EventBus.publish({
      type: 'playbook.created',
      source: 'playbook_engine',
      target: '*',
      data: {
        playbookId: created[0].id,
        name,
        category,
      },
      metadata: {
        priority: 'normal',
      },
    });

    return created[0];
  }

  /**
   * Execute a playbook
   */
  static async executePlaybook(params: {
    playbookId: number;
    taskId?: number;
    initialContext?: Record<string, unknown>;
  }): Promise<PlaybookExecution> {
    const { playbookId, taskId, initialContext = {} } = params;

    const db = await getDb();
    if (!db) throw new Error('Database not available');

    // Get playbook
    const playbook = await db
      .select()
      .from(playbooks)
      .where(eq(playbooks.id, playbookId))
      .limit(1);

    if (playbook.length === 0) {
      throw new Error('Playbook not found');
    }

    if (playbook[0].status !== 'active') {
      throw new Error('Playbook is not active');
    }

    const definition = playbook[0].definition as PlaybookDefinition;

    // Create execution record
    await db.insert(playbookExecutions).values({
      playbookId,
      taskId,
      status: 'pending',
      currentStep: 0,
      totalSteps: definition.steps.length,
      executionLog: [] as any,
      context: initialContext as any,
    });

    const execution = await db
      .select()
      .from(playbookExecutions)
      .where(eq(playbookExecutions.playbookId, playbookId))
      .orderBy(desc(playbookExecutions.createdAt))
      .limit(1);

    if (execution.length === 0) {
      throw new Error('Failed to create execution');
    }

    // Publish event
    await EventBus.publish({
      type: 'playbook.execution.started',
      source: 'playbook_engine',
      target: '*',
      data: {
        executionId: execution[0].id,
        playbookId,
        taskId,
      },
      metadata: {
        priority: 'normal',
      },
    });

    // Start execution asynchronously
    this.runExecution(execution[0].id, definition, initialContext).catch((error) => {
      console.error('[PlaybookEngine] Execution error:', error);
    });

    return execution[0];
  }

  /**
   * Run playbook execution
   */
  private static async runExecution(
    executionId: number,
    definition: PlaybookDefinition,
    initialContext: Record<string, unknown>
  ): Promise<void> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const context: ExecutionContext = {
      variables: { ...definition.variables, ...initialContext },
      stepResults: {},
      startTime: new Date(),
    };

    const executionLog: Array<{ step: string; status: string; result?: unknown; error?: string; timestamp: string }> = [];

    try {
      // Update status to running
      await db
        .update(playbookExecutions)
        .set({
          status: 'running',
          startedAt: new Date(),
        })
        .where(eq(playbookExecutions.id, executionId));

      // Execute steps sequentially
      for (let i = 0; i < definition.steps.length; i++) {
        const step = definition.steps[i];

        // Update current step
        await db
          .update(playbookExecutions)
          .set({ currentStep: i + 1 })
          .where(eq(playbookExecutions.id, executionId));

        try {
          // Execute step
          const result = await this.executeStep(step, context);

          executionLog.push({
            step: step.name,
            status: 'success',
            result,
            timestamp: new Date().toISOString(),
          });

          context.stepResults[step.id] = result;

          // Check for conditional branching
          if (step.type === 'condition' && step.onSuccess && step.onFailure) {
            const nextStepId = result ? step.onSuccess : step.onFailure;
            const nextStepIndex = definition.steps.findIndex(s => s.id === nextStepId);
            if (nextStepIndex !== -1) {
              i = nextStepIndex - 1; // -1 because loop will increment
            }
          }
        } catch (error: any) {
          executionLog.push({
            step: step.name,
            status: 'error',
            error: error.message,
            timestamp: new Date().toISOString(),
          });

          // Handle failure
          if (step.onFailure) {
            const nextStepIndex = definition.steps.findIndex(s => s.id === step.onFailure);
            if (nextStepIndex !== -1) {
              i = nextStepIndex - 1;
              continue;
            }
          }

          throw error;
        }
      }

      // Execution completed successfully
      await db
        .update(playbookExecutions)
        .set({
          status: 'completed',
          completedAt: new Date(),
          executionLog: executionLog as any,
          context: context as any,
        })
        .where(eq(playbookExecutions.id, executionId));

      // Publish event
      await EventBus.publish({
        type: 'playbook.execution.completed',
        source: 'playbook_engine',
        target: '*',
        data: {
          executionId,
          duration: Date.now() - context.startTime.getTime(),
        },
        metadata: {
          priority: 'normal',
        },
      });
    } catch (error: any) {
      // Execution failed
      await db
        .update(playbookExecutions)
        .set({
          status: 'failed',
          completedAt: new Date(),
          errorMessage: error.message,
          executionLog: executionLog as any,
          context: context as any,
        })
        .where(eq(playbookExecutions.id, executionId));

      // Publish event
      await EventBus.publish({
        type: 'playbook.execution.failed',
        source: 'playbook_engine',
        target: '*',
        data: {
          executionId,
          error: error.message,
        },
        metadata: {
          priority: 'high',
        },
      });
    }
  }

  /**
   * Execute a single workflow step
   */
  private static async executeStep(
    step: WorkflowStep,
    context: ExecutionContext
  ): Promise<unknown> {
    switch (step.type) {
      case 'action':
        return await this.executeAction(step, context);
      case 'condition':
        return await this.evaluateCondition(step, context);
      case 'loop':
        return await this.executeLoop(step, context);
      case 'parallel':
        return await this.executeParallel(step, context);
      default:
        throw new Error(`Unknown step type: ${step.type}`);
    }
  }

  /**
   * Execute an action step
   */
  private static async executeAction(
    step: WorkflowStep,
    context: ExecutionContext
  ): Promise<unknown> {
    if (!step.action) {
      throw new Error('Action step requires action field');
    }

    const action = step.action;
    const params = step.params || {};

    // Route to appropriate engine based on action type
    try {
      // Communication actions
      if (action.startsWith('send_')) {
        return await this.executeCommunicationAction(action, params, context);
      }

      // Task actions
      if (action.startsWith('task_')) {
        return await this.executeTaskAction(action, params, context);
      }

      // Knowledge Graph actions
      if (action.startsWith('kg_')) {
        return await this.executeKnowledgeGraphAction(action, params, context);
      }

      // Default: log and return success
      console.log(`[PlaybookEngine] Executing action: ${action}`, params);
      return { success: true, action, params };
    } catch (error: any) {
      console.error(`[PlaybookEngine] Action failed: ${action}`, error);
      throw error;
    }
  }

  /**
   * Execute communication-related actions
   */
  private static async executeCommunicationAction(
    action: string,
    params: Record<string, unknown>,
    context: ExecutionContext
  ): Promise<unknown> {
    switch (action) {
      case 'send_email':
        return await CommunicationEngine.sendMessage({
          channel: 'email',
          recipient: this.resolveVariable(params.recipient as string, context),
          subject: this.resolveVariable(params.subject as string, context),
          body: this.resolveVariable(params.body as string, context),
        });

      case 'send_notification':
        return await CommunicationEngine.sendMessage({
          channel: 'notification',
          recipient: this.resolveVariable(params.recipient as string, context),
          subject: this.resolveVariable(params.subject as string, context),
          body: this.resolveVariable(params.body as string, context),
        });

      case 'send_sms':
        return await CommunicationEngine.sendMessage({
          channel: 'sms',
          recipient: this.resolveVariable(params.recipient as string, context),
          body: this.resolveVariable(params.body as string, context),
        });

      default:
        throw new Error(`Unknown communication action: ${action}`);
    }
  }

  /**
   * Execute task-related actions
   */
  private static async executeTaskAction(
    action: string,
    params: Record<string, unknown>,
    context: ExecutionContext
  ): Promise<unknown> {
    // Placeholder for task actions
    console.log(`[PlaybookEngine] Task action: ${action}`, params);
    return { success: true, action, params };
  }

  /**
   * Execute Knowledge Graph actions
   */
  private static async executeKnowledgeGraphAction(
    action: string,
    params: Record<string, unknown>,
    context: ExecutionContext
  ): Promise<unknown> {
    // Placeholder for KG actions
    console.log(`[PlaybookEngine] Knowledge Graph action: ${action}`, params);
    return { success: true, action, params };
  }

  /**
   * Resolve variables in strings (e.g., {{variableName}})
   */
  private static resolveVariable(value: string, context: ExecutionContext): string {
    if (!value) return value;
    
    return value.replace(/\{\{(\w+)\}\}/g, (match, varName) => {
      const resolved = context.variables[varName];
      return resolved !== undefined ? String(resolved) : match;
    });
  }

  /**
   * Evaluate a condition step
   */
  private static async evaluateCondition(
    step: WorkflowStep,
    context: ExecutionContext
  ): Promise<boolean> {
    if (!step.condition) {
      throw new Error('Condition step requires condition field');
    }

    // Simple condition evaluation
    // In a real implementation, this would use a proper expression evaluator
    try {
      // Replace variables in condition
      let condition = step.condition;
      for (const [key, value] of Object.entries(context.variables)) {
        condition = condition.replace(new RegExp(`\\$${key}`, 'g'), JSON.stringify(value));
      }

      // Evaluate (simplified - in production use a safe evaluator)
      return eval(condition);
    } catch (error) {
      console.error('[PlaybookEngine] Condition evaluation error:', error);
      return false;
    }
  }

  /**
   * Execute a loop step
   */
  private static async executeLoop(
    step: WorkflowStep,
    context: ExecutionContext
  ): Promise<unknown> {
    // Simplified loop implementation
    const iterations = (step.params?.iterations as number) || 1;
    const results = [];

    for (let i = 0; i < iterations; i++) {
      context.variables['loopIndex'] = i;
      results.push({ iteration: i, success: true });
    }

    return results;
  }

  /**
   * Execute parallel steps
   */
  private static async executeParallel(
    step: WorkflowStep,
    context: ExecutionContext
  ): Promise<unknown> {
    // Simplified parallel execution
    const parallelSteps = (step.params?.steps as WorkflowStep[]) || [];
    const results = await Promise.all(
      parallelSteps.map(s => this.executeStep(s, context))
    );

    return results;
  }

  /**
   * Validate playbook definition
   */
  private static validateDefinition(definition: PlaybookDefinition): void {
    if (!definition.steps || definition.steps.length === 0) {
      throw new Error('Playbook must have at least one step');
    }

    // Validate step IDs are unique
    const stepIds = new Set<string>();
    for (const step of definition.steps) {
      if (!step.id || !step.name || !step.type) {
        throw new Error('Each step must have id, name, and type');
      }

      if (stepIds.has(step.id)) {
        throw new Error(`Duplicate step ID: ${step.id}`);
      }

      stepIds.add(step.id);
    }

    // Validate step references
    for (const step of definition.steps) {
      if (step.onSuccess && !stepIds.has(step.onSuccess)) {
        throw new Error(`Invalid onSuccess reference: ${step.onSuccess}`);
      }
      if (step.onFailure && !stepIds.has(step.onFailure)) {
        throw new Error(`Invalid onFailure reference: ${step.onFailure}`);
      }
    }
  }

  /**
   * Get all playbooks
   */
  static async getAllPlaybooks(): Promise<Playbook[]> {
    const db = await getDb();
    if (!db) return [];

    return await db.select().from(playbooks).orderBy(desc(playbooks.createdAt));
  }

  /**
   * Get playbook by ID
   */
  static async getPlaybookById(id: number): Promise<Playbook | null> {
    const db = await getDb();
    if (!db) return null;

    const result = await db.select().from(playbooks).where(eq(playbooks.id, id)).limit(1);
    return result.length > 0 ? result[0] : null;
  }

  /**
   * Get execution by ID
   */
  static async getExecutionById(id: number): Promise<PlaybookExecution | null> {
    const db = await getDb();
    if (!db) return null;

    const result = await db.select().from(playbookExecutions).where(eq(playbookExecutions.id, id)).limit(1);
    return result.length > 0 ? result[0] : null;
  }

  /**
   * Get executions for a playbook
   */
  static async getExecutionsByPlaybookId(playbookId: number): Promise<PlaybookExecution[]> {
    const db = await getDb();
    if (!db) return [];

    return await db
      .select()
      .from(playbookExecutions)
      .where(eq(playbookExecutions.playbookId, playbookId))
      .orderBy(desc(playbookExecutions.createdAt));
  }

  /**
   * Cancel execution
   */
  static async cancelExecution(executionId: number): Promise<void> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    await db
      .update(playbookExecutions)
      .set({
        status: 'cancelled',
        completedAt: new Date(),
      })
      .where(eq(playbookExecutions.id, executionId));

    // Publish event
    await EventBus.publish({
      type: 'playbook.execution.cancelled',
      source: 'playbook_engine',
      target: '*',
      data: {
        executionId,
      },
      metadata: {
        priority: 'normal',
      },
    });
  }
}
