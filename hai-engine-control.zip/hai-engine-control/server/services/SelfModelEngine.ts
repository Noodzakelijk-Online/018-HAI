import { getDb } from "../db";
import { userTraits, InsertUserTrait, UserTrait, events } from "../../drizzle/schema";
import { eq, and, desc, sql } from "drizzle-orm";
import { EventBus } from "./EventBus";
import { LLMService } from "./LLMService";

/**
 * Trait categories that SME can learn
 */
export type TraitCategory = 
  | 'communication_style'      // How user prefers to communicate
  | 'decision_making_style'    // How user makes decisions
  | 'priority_preference'      // What user considers important
  | 'time_preference'          // When user prefers to do things
  | 'escalation_threshold'     // When user wants to be notified
  | 'autonomy_preference'      // How much autonomy user wants
  | 'relationship_pattern'     // Patterns in user's relationships
  | 'emotional_pattern'        // User's emotional responses
  | 'work_pattern'             // Work habits and preferences
  | 'personal_value';          // Core values and beliefs

/**
 * Learned trait with evidence
 */
export interface LearnedTrait {
  id: number;
  userId: number;
  traitType: string;
  traitValue: string;
  confidence: number;
  evidence: number[];
  lastUpdated: Date;
  createdAt: Date;
}

/**
 * User profile summary
 */
export interface UserProfile {
  userId: number;
  traits: LearnedTrait[];
  completeness: number; // 0-100
  overallConfidence: number; // 0-100
  lastUpdated: Date;
  traitsByCategory: Record<string, LearnedTrait[]>;
}

/**
 * Pattern detected in user behavior
 */
export interface DetectedPattern {
  patternType: string;
  description: string;
  frequency: number;
  confidence: number;
  examples: string[];
  firstObserved: Date;
  lastObserved: Date;
}

/**
 * Self-Model Engine (SME)
 * 
 * Learns user preferences, patterns, and behaviors through observation.
 * Builds a comprehensive user model for personalized AI assistance.
 */
class SelfModelEngineService {
  /**
   * Learn traits from a conversation or action
   */
  async learnFromConversation(params: {
    userId: number;
    conversationId: string;
    messages: Array<{ role: string; content: string }>;
  }): Promise<LearnedTrait[]> {
    const { userId, conversationId, messages } = params;

    // Use LLM to extract traits from conversation
    const conversationText = messages
      .filter(m => m.role === 'user')
      .map(m => m.content)
      .join('\n\n');

    if (!conversationText.trim()) {
      return [];
    }

    const analysis = await LLMService.analyze({
      text: conversationText,
      context: `Analyze this conversation to identify user traits, preferences, and patterns. 
Focus on:
- Communication style (formal, casual, direct, indirect)
- Decision-making patterns (analytical, intuitive, collaborative)
- Priorities (family, work, health, relationships)
- Time preferences (morning person, night owl, structured, flexible)
- Emotional patterns (optimistic, cautious, empathetic)
- Values (privacy, efficiency, relationships, autonomy)`,
      engineType: 'selfModel',
    });

    const learnedTraits: LearnedTrait[] = [];

    // Extract traits from entities
    if (analysis.entities && analysis.entities.length > 0) {
      for (const entity of analysis.entities) {
        // Map entity types to trait categories
        const traitType = this.mapEntityToTraitType(entity.type);
        
        if (traitType) {
          const trait = await this.storeTrait({
            userId,
            traitType,
            traitValue: entity.value,
            confidence: Math.round(analysis.confidence * 100),
            context: entity.context || conversationText.substring(0, 200),
          });

          if (trait) {
            learnedTraits.push(trait);
          }
        }
      }
    }

    // Publish learning event
    await EventBus.publish({
      type: 'sme.traits_learned',
      source: 'SelfModelEngine',
      target: '*',
      data: {
        userId,
        conversationId,
        traitsLearned: learnedTraits.length,
        traits: learnedTraits,
      },
    });

    return learnedTraits;
  }

  /**
   * Store or update a trait
   */
  async storeTrait(params: {
    userId: number;
    traitType: string;
    traitValue: string;
    confidence: number;
    context: string;
  }): Promise<LearnedTrait | null> {
    const { userId, traitType, traitValue, confidence, context } = params;

    const db = await getDb();
    if (!db) return null;

    try {
      // Check if trait already exists
      const existing = await db
        .select()
        .from(userTraits)
        .where(
          and(
            eq(userTraits.userId, userId),
            eq(userTraits.traitType, traitType),
            eq(userTraits.traitValue, traitValue)
          )
        )
        .limit(1);

      if (existing.length > 0) {
        // Update existing trait - reinforce confidence
        const currentTrait = existing[0];
        const currentEvidence = (currentTrait.evidence as number[]) || [];
        
        // Weighted average of confidences (new evidence has more weight)
        const newConfidence = Math.min(
          100,
          Math.round((currentTrait.confidence * 0.7) + (confidence * 0.3))
        );

        await db
          .update(userTraits)
          .set({
            confidence: newConfidence,
            evidence: [...currentEvidence, Date.now()],
            lastUpdated: new Date(),
          })
          .where(eq(userTraits.id, currentTrait.id));

        // Return updated trait
        const updated = await db
          .select()
          .from(userTraits)
          .where(eq(userTraits.id, currentTrait.id))
          .limit(1);

        return updated[0] as LearnedTrait;
      }

      // Create new trait
      await db.insert(userTraits).values({
        userId,
        traitType,
        traitValue,
        confidence,
        evidence: [Date.now()],
        lastUpdated: new Date(),
      });

      // Fetch the created trait
      const created = await db
        .select()
        .from(userTraits)
        .where(
          and(
            eq(userTraits.userId, userId),
            eq(userTraits.traitType, traitType),
            eq(userTraits.traitValue, traitValue)
          )
        )
        .orderBy(desc(userTraits.id))
        .limit(1);

      return created[0] as LearnedTrait;
    } catch (error) {
      console.error('[SME] Error storing trait:', error);
      return null;
    }
  }

  /**
   * Get user profile with all learned traits
   */
  async getUserProfile(userId: number): Promise<UserProfile | null> {
    const db = await getDb();
    if (!db) return null;

    try {
      const traits = await db
        .select()
        .from(userTraits)
        .where(eq(userTraits.userId, userId))
        .orderBy(desc(userTraits.confidence));

      if (traits.length === 0) {
        return {
          userId,
          traits: [],
          completeness: 0,
          overallConfidence: 0,
          lastUpdated: new Date(),
          traitsByCategory: {},
        };
      }

      // Group traits by category
      const traitsByCategory: Record<string, LearnedTrait[]> = {};
      for (const trait of traits) {
        const category = trait.traitType;
        if (!traitsByCategory[category]) {
          traitsByCategory[category] = [];
        }
        traitsByCategory[category].push(trait as LearnedTrait);
      }

      // Calculate completeness (how many trait categories have been learned)
      const totalCategories = 10; // Total possible trait categories
      const learnedCategories = Object.keys(traitsByCategory).length;
      const completeness = Math.round((learnedCategories / totalCategories) * 100);

      // Calculate overall confidence (average of all trait confidences)
      const overallConfidence = Math.round(
        traits.reduce((sum, t) => sum + t.confidence, 0) / traits.length
      );

      // Get most recent update
      const lastUpdated = traits.reduce((latest, t) => {
        return t.lastUpdated > latest ? t.lastUpdated : latest;
      }, traits[0].lastUpdated);

      return {
        userId,
        traits: traits as LearnedTrait[],
        completeness,
        overallConfidence,
        lastUpdated,
        traitsByCategory,
      };
    } catch (error) {
      console.error('[SME] Error getting user profile:', error);
      return null;
    }
  }

  /**
   * Detect patterns in user behavior
   */
  async detectPatterns(userId: number): Promise<DetectedPattern[]> {
    const db = await getDb();
    if (!db) return [];

    try {
      // Get all user events
      const userEvents = await db
        .select()
        .from(events)
        .where(eq(events.userId, userId))
        .orderBy(desc(events.timestamp))
        .limit(1000);

      if (userEvents.length === 0) {
        return [];
      }

      const patterns: DetectedPattern[] = [];

      // Pattern 1: Event frequency by type
      const eventTypeCounts = new Map<string, number>();
      for (const event of userEvents) {
        const count = eventTypeCounts.get(event.eventType) || 0;
        eventTypeCounts.set(event.eventType, count + 1);
      }

      const eventTypeEntries = Array.from(eventTypeCounts.entries());
      for (const [eventType, count] of eventTypeEntries) {
        if (count >= 3) {
          // Pattern detected
          const relevantEvents = userEvents.filter(e => e.eventType === eventType);
          const firstObserved = relevantEvents[relevantEvents.length - 1].timestamp;
          const lastObserved = relevantEvents[0].timestamp;

          patterns.push({
            patternType: 'event_frequency',
            description: `User frequently performs ${eventType} actions`,
            frequency: count,
            confidence: Math.min(100, count * 10),
            examples: relevantEvents.slice(0, 3).map(e => 
              `${eventType} at ${e.timestamp.toISOString()}`
            ),
            firstObserved,
            lastObserved,
          });
        }
      }

      // Pattern 2: Time-based patterns (hour of day)
      const hourCounts = new Map<number, number>();
      for (const event of userEvents) {
        const hour = event.timestamp.getHours();
        const count = hourCounts.get(hour) || 0;
        hourCounts.set(hour, count + 1);
      }

      const hourEntries = Array.from(hourCounts.entries());
      const mostActiveHour = hourEntries.sort((a, b) => b[1] - a[1])[0];

      if (mostActiveHour && mostActiveHour[1] >= 5) {
        patterns.push({
          patternType: 'time_preference',
          description: `User is most active around ${mostActiveHour[0]}:00`,
          frequency: mostActiveHour[1],
          confidence: Math.min(100, mostActiveHour[1] * 5),
          examples: [`${mostActiveHour[1]} events at hour ${mostActiveHour[0]}`],
          firstObserved: userEvents[userEvents.length - 1].timestamp,
          lastObserved: userEvents[0].timestamp,
        });
      }

      // Publish pattern detection event
      await EventBus.publish({
        type: 'sme.patterns_detected',
        source: 'SelfModelEngine',
        target: '*',
        data: {
          userId,
          patternsDetected: patterns.length,
          patterns,
        },
      });

      return patterns;
    } catch (error) {
      console.error('[SME] Error detecting patterns:', error);
      return [];
    }
  }

  /**
   * Get trait recommendations based on incomplete profile
   */
  async getTraitRecommendations(userId: number): Promise<string[]> {
    const profile = await this.getUserProfile(userId);
    if (!profile) return [];

    const recommendations: string[] = [];
    const learnedCategories = Object.keys(profile.traitsByCategory);

    // Recommend missing categories
    const allCategories: TraitCategory[] = [
      'communication_style',
      'decision_making_style',
      'priority_preference',
      'time_preference',
      'escalation_threshold',
      'autonomy_preference',
      'relationship_pattern',
      'emotional_pattern',
      'work_pattern',
      'personal_value',
    ];

    for (const category of allCategories) {
      if (!learnedCategories.includes(category)) {
        recommendations.push(`Learn more about user's ${category.replace(/_/g, ' ')}`);
      }
    }

    return recommendations.slice(0, 5); // Top 5 recommendations
  }

  /**
   * Map entity type to trait type
   */
  private mapEntityToTraitType(entityType: string): string | null {
    const mapping: Record<string, string> = {
      'communication_style': 'communication_style',
      'decision_style': 'decision_making_style',
      'priority': 'priority_preference',
      'time_preference': 'time_preference',
      'notification_preference': 'escalation_threshold',
      'autonomy_level': 'autonomy_preference',
      'relationship': 'relationship_pattern',
      'emotion': 'emotional_pattern',
      'work_habit': 'work_pattern',
      'value': 'personal_value',
    };

    return mapping[entityType] || null;
  }

  /**
   * Update trait confidence based on new evidence
   */
  async updateTraitConfidence(params: {
    traitId: number;
    reinforcement: number; // -100 to +100
  }): Promise<boolean> {
    const { traitId, reinforcement } = params;

    const db = await getDb();
    if (!db) return false;

    try {
      const trait = await db
        .select()
        .from(userTraits)
        .where(eq(userTraits.id, traitId))
        .limit(1);

      if (trait.length === 0) return false;

      const currentConfidence = trait[0].confidence;
      const newConfidence = Math.max(
        0,
        Math.min(100, currentConfidence + reinforcement)
      );

      await db
        .update(userTraits)
        .set({
          confidence: newConfidence,
          lastUpdated: new Date(),
        })
        .where(eq(userTraits.id, traitId));

      return true;
    } catch (error) {
      console.error('[SME] Error updating trait confidence:', error);
      return false;
    }
  }

  /**
   * Delete a trait (user correction)
   */
  async deleteTrait(traitId: number): Promise<boolean> {
    const db = await getDb();
    if (!db) return false;

    try {
      await db
        .delete(userTraits)
        .where(eq(userTraits.id, traitId));

      return true;
    } catch (error) {
      console.error('[SME] Error deleting trait:', error);
      return false;
    }
  }
}

// Export singleton instance
export const SelfModelEngine = new SelfModelEngineService();
