/**
 * LLM Fallback Service
 * Implements P1 #49: Add fallback mechanisms for AI services
 */

export interface LLMProvider {
  name: string;
  priority: number;
  isAvailable: () => Promise<boolean>;
  invoke: (params: LLMParams) => Promise<LLMResponse>;
}

export interface LLMParams {
  messages: Array<{
    role: 'system' | 'user' | 'assistant';
    content: string;
  }>;
  temperature?: number;
  maxTokens?: number;
  stream?: boolean;
}

export interface LLMResponse {
  content: string;
  provider: string;
  usage?: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
  finishReason?: string;
}

// Provider health status
const providerHealth: Map<string, { healthy: boolean; lastCheck: Date; failures: number }> = new Map();

/**
 * Check provider health
 */
async function checkProviderHealth(provider: LLMProvider): Promise<boolean> {
  const health = providerHealth.get(provider.name);
  
  // If recently checked and healthy, skip
  if (health && health.healthy && Date.now() - health.lastCheck.getTime() < 30000) {
    return true;
  }
  
  try {
    const available = await provider.isAvailable();
    providerHealth.set(provider.name, {
      healthy: available,
      lastCheck: new Date(),
      failures: available ? 0 : (health?.failures || 0) + 1,
    });
    return available;
  } catch {
    providerHealth.set(provider.name, {
      healthy: false,
      lastCheck: new Date(),
      failures: (health?.failures || 0) + 1,
    });
    return false;
  }
}

/**
 * LLM Fallback Manager
 */
export class LLMFallbackManager {
  private providers: LLMProvider[] = [];
  private defaultTimeout = 30000;

  /**
   * Register a provider
   */
  registerProvider(provider: LLMProvider): void {
    this.providers.push(provider);
    this.providers.sort((a, b) => a.priority - b.priority);
  }

  /**
   * Remove a provider
   */
  removeProvider(name: string): void {
    this.providers = this.providers.filter(p => p.name !== name);
  }

  /**
   * Get available providers
   */
  async getAvailableProviders(): Promise<LLMProvider[]> {
    const available: LLMProvider[] = [];
    
    for (const provider of this.providers) {
      if (await checkProviderHealth(provider)) {
        available.push(provider);
      }
    }
    
    return available;
  }

  /**
   * Invoke LLM with fallback
   */
  async invoke(params: LLMParams): Promise<LLMResponse> {
    const errors: Error[] = [];
    
    for (const provider of this.providers) {
      // Skip unhealthy providers
      const health = providerHealth.get(provider.name);
      if (health && !health.healthy && health.failures >= 3) {
        // Check if enough time has passed to retry
        if (Date.now() - health.lastCheck.getTime() < 60000) {
          continue;
        }
      }
      
      try {
        console.log(`[LLM] Trying provider: ${provider.name}`);
        const response = await this.invokeWithTimeout(provider, params);
        
        // Mark provider as healthy
        providerHealth.set(provider.name, {
          healthy: true,
          lastCheck: new Date(),
          failures: 0,
        });
        
        return response;
      } catch (error) {
        const err = error instanceof Error ? error : new Error(String(error));
        errors.push(err);
        
        console.warn(`[LLM] Provider ${provider.name} failed:`, err.message);
        
        // Mark provider as unhealthy
        const currentHealth = providerHealth.get(provider.name);
        providerHealth.set(provider.name, {
          healthy: false,
          lastCheck: new Date(),
          failures: (currentHealth?.failures || 0) + 1,
        });
      }
    }
    
    // All providers failed
    throw new Error(`All LLM providers failed: ${errors.map(e => e.message).join('; ')}`);
  }

  /**
   * Invoke with timeout
   */
  private async invokeWithTimeout(
    provider: LLMProvider,
    params: LLMParams
  ): Promise<LLMResponse> {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        reject(new Error(`Provider ${provider.name} timed out`));
      }, this.defaultTimeout);
      
      provider.invoke(params)
        .then(result => {
          clearTimeout(timer);
          resolve(result);
        })
        .catch(error => {
          clearTimeout(timer);
          reject(error);
        });
    });
  }

  /**
   * Get provider health status
   */
  getHealthStatus(): Record<string, { healthy: boolean; failures: number }> {
    const status: Record<string, { healthy: boolean; failures: number }> = {};
    
    for (const provider of this.providers) {
      const health = providerHealth.get(provider.name);
      status[provider.name] = {
        healthy: health?.healthy ?? true,
        failures: health?.failures ?? 0,
      };
    }
    
    return status;
  }

  /**
   * Reset provider health
   */
  resetHealth(providerName?: string): void {
    if (providerName) {
      providerHealth.delete(providerName);
    } else {
      providerHealth.clear();
    }
  }
}

// Global fallback manager instance
export const llmFallback = new LLMFallbackManager();

/**
 * Create a mock provider for testing
 */
export function createMockProvider(name: string, priority: number): LLMProvider {
  return {
    name,
    priority,
    isAvailable: async () => true,
    invoke: async (params) => ({
      content: `Mock response from ${name}`,
      provider: name,
      usage: {
        promptTokens: 10,
        completionTokens: 5,
        totalTokens: 15,
      },
    }),
  };
}

/**
 * Create provider from invokeLLM function
 */
export function createProviderFromInvokeLLM(
  name: string,
  priority: number,
  invokeFn: (params: any) => Promise<any>
): LLMProvider {
  return {
    name,
    priority,
    isAvailable: async () => true,
    invoke: async (params) => {
      const response = await invokeFn({
        messages: params.messages,
        temperature: params.temperature,
        max_tokens: params.maxTokens,
      });
      
      return {
        content: response.choices?.[0]?.message?.content || '',
        provider: name,
        usage: response.usage ? {
          promptTokens: response.usage.prompt_tokens,
          completionTokens: response.usage.completion_tokens,
          totalTokens: response.usage.total_tokens,
        } : undefined,
        finishReason: response.choices?.[0]?.finish_reason,
      };
    },
  };
}

/**
 * Simple retry wrapper for LLM calls
 */
export async function retryLLM<T>(
  fn: () => Promise<T>,
  maxRetries: number = 3,
  delayMs: number = 1000
): Promise<T> {
  let lastError: Error | undefined;
  
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      console.warn(`[LLM] Retry ${i + 1}/${maxRetries} failed:`, lastError.message);
      
      if (i < maxRetries - 1) {
        await new Promise(resolve => setTimeout(resolve, delayMs * (i + 1)));
      }
    }
  }
  
  throw lastError;
}

export default {
  LLMFallbackManager,
  llmFallback,
  createMockProvider,
  createProviderFromInvokeLLM,
  retryLLM,
};
