/**
 * Event Helper Functions
 * Provides type-safe event publishing with sensible defaults
 */

import EventBus, { HAIEvent } from './EventBus';

/**
 * Event categories for type-safe event publishing
 */
export const EventTypes = {
  // Email events
  EMAIL_RECEIVED: 'email.received',
  EMAIL_SENT: 'email.sent',
  EMAIL_CATEGORIZED: 'email.categorized',
  
  // Communication events
  COMMUNICATION_QUEUED: 'communication.message.queued',
  COMMUNICATION_SENT: 'communication.message.sent',
  COMMUNICATION_FAILED: 'communication.message.failed',
  
  // Decision events
  DECISION_EVALUATED: 'decision.evaluated',
  DECISION_PENDING: 'decision.pending_approval',
  DECISION_EXECUTED: 'decision.executed',
  DECISION_APPROVED: 'decision.approved',
  DECISION_REJECTED: 'decision.rejected',
  
  // Approval events
  APPROVAL_APPROVED: 'approval.approved',
  APPROVAL_REJECTED: 'approval.rejected',
  APPROVAL_EXPIRED: 'approval.expired',
  
  // Task events
  TASK_CREATED: 'task.created',
  TASK_STARTED: 'task.started',
  TASK_COMPLETED: 'task.completed',
  TASK_FAILED: 'task.failed',
  
  // Agent events
  AGENT_STARTED: 'agent.started',
  AGENT_STOPPED: 'agent.stopped',
  AGENT_ERROR: 'agent.error',
  
  // System events
  SYSTEM_HEALTH: 'system.health',
  SYSTEM_ERROR: 'system.error',
  SYSTEM_WARNING: 'system.warning',
} as const;

export type EventType = typeof EventTypes[keyof typeof EventTypes];

/**
 * Simplified event publishing with automatic target defaulting
 */
export interface SimpleEventInput {
  type: string;
  source: string;
  target?: string | string[];
  data: Record<string, unknown>;
  metadata?: {
    userId?: number;
    priority?: 'low' | 'normal' | 'high' | 'critical';
    correlationId?: string;
    causationId?: string;
  };
}

/**
 * Publish an event with sensible defaults
 * - target defaults to '*' (broadcast)
 * - metadata is optional
 */
export async function publishEvent(event: SimpleEventInput): Promise<void> {
  await EventBus.publish({
    type: event.type,
    source: event.source,
    target: event.target || '*',
    data: event.data,
    metadata: event.metadata,
  });
}

/**
 * Publish a broadcast event to all engines
 */
export async function broadcastEvent(
  type: string,
  source: string,
  data: Record<string, unknown>,
  priority: 'low' | 'normal' | 'high' | 'critical' = 'normal'
): Promise<void> {
  await EventBus.publish({
    type,
    source,
    target: '*',
    data,
    metadata: { priority },
  });
}

/**
 * Publish a targeted event to specific engine(s)
 */
export async function targetedEvent(
  type: string,
  source: string,
  target: string | string[],
  data: Record<string, unknown>,
  priority: 'low' | 'normal' | 'high' | 'critical' = 'normal'
): Promise<void> {
  await EventBus.publish({
    type,
    source,
    target,
    data,
    metadata: { priority },
  });
}

/**
 * Create a scoped event publisher for a specific source
 */
export function createEventPublisher(source: string) {
  return {
    broadcast: (type: string, data: Record<string, unknown>, priority?: 'low' | 'normal' | 'high' | 'critical') =>
      broadcastEvent(type, source, data, priority),
    
    targeted: (type: string, target: string | string[], data: Record<string, unknown>, priority?: 'low' | 'normal' | 'high' | 'critical') =>
      targetedEvent(type, source, target, data, priority),
    
    publish: (event: Omit<SimpleEventInput, 'source'>) =>
      publishEvent({ ...event, source }),
  };
}

export default {
  EventTypes,
  publishEvent,
  broadcastEvent,
  targetedEvent,
  createEventPublisher,
};
