import { getDb } from "../db";
import { decisions, InsertDecision, Decision } from "../../drizzle/schema";
import { eq, and, desc, sql } from "drizzle-orm";
import { EventBus } from "./EventBus";
import { SelfModelEngine } from "./SelfModelEngine";
import { LLMService } from "./LLMService";
import { logActivity } from "./activityTracker";

/**
 * Autonomy Ladder - 5 levels of decision-making autonomy
 * 
 * Based on the concept from "Designing Autonomous AI" research
 */
export enum AutonomyLevel {
  NOTIFY = 1,           // Just inform user after decision
  SUGGEST = 2,          // Suggest options, user decides
  ASK = 3,              // Ask for permission before acting
  ACT_THEN_REPORT = 4,  // Act first, report after
  AUTONOMOUS = 5,       // Fully autonomous, no user interaction
}

/**
 * Decision types that HAI can make
 */
export type DecisionType =
  | 'action'              // Take an action (send message, create task)
  | 'communication'       // Send a message or notification
  | 'scheduling'          // Schedule or reschedule something
  | 'resource_allocation' // Allocate time, money, or resources
  | 'policy_change'       // Suggest changing a policy
  | 'escalation';         // Escalate an issue to user

/**
 * Decision context for evaluation
 */
export interface DecisionContext {
  type: DecisionType;
  description: string;
  urgency: 'low' | 'medium' | 'high' | 'critical';
  impact: 'low' | 'medium' | 'high';
  reversibility: 'easy' | 'moderate' | 'difficult' | 'irreversible';
  alternatives?: string[];
  relatedEntities?: string[];
  estimatedCost?: number;
  estimatedTime?: number;
}

/**
 * Decision evaluation result
 */
export interface DecisionEvaluation {
  shouldAct: boolean;
  autonomyLevel: AutonomyLevel;
  confidence: number; // 0-100
  reasoning: string;
  risks: string[];
  benefits: string[];
  alternatives: Array<{
    description: string;
    pros: string[];
    cons: string[];
  }>;
  requiresApproval: boolean;
  policyConstraints: string[];
}

/**
 * Decision outcome tracking
 */
export interface DecisionOutcome {
  success: boolean;
  actualImpact: string;
  userFeedback?: 'positive' | 'negative' | 'neutral';
  lessonsLearned: string[];
}

/**
 * Decision Engine
 * 
 * Makes autonomous decisions within policy constraints.
 * Uses the autonomy ladder to determine what requires approval.
 */
class DecisionEngineService {
  /**
   * Evaluate a decision and determine autonomy level
   */
  async evaluateDecision(params: {
    userId: number;
    context: DecisionContext;
    userPreferences?: any;
  }): Promise<DecisionEvaluation> {
    const { userId, context, userPreferences } = params;

    // Get user profile for preference-based evaluation
    const profile = await SelfModelEngine.getUserProfile(userId);

    // Use LLM to analyze the decision
    const systemPrompt = `You are a decision evaluation AI. Analyze decisions and determine:
1. Should we act on this decision?
2. What autonomy level is appropriate? (1=notify, 2=suggest, 3=ask, 4=act-then-report, 5=autonomous)
3. What are the risks and benefits?
4. What alternatives exist?

Consider:
- User preferences and patterns from their profile
- Urgency and impact of the decision
- Reversibility of the action
- Policy constraints

User profile summary:
${profile ? `Completeness: ${profile.completeness}%, Confidence: ${profile.overallConfidence}%` : 'No profile data yet'}
${profile?.traits.slice(0, 5).map(t => `- ${t.traitType}: ${t.traitValue}`).join('\n') || ''}`;

    const userPrompt = `Evaluate this decision:

Type: ${context.type}
Description: ${context.description}
Urgency: ${context.urgency}
Impact: ${context.impact}
Reversibility: ${context.reversibility}
${context.alternatives ? `Alternatives: ${context.alternatives.join(', ')}` : ''}
${context.estimatedCost ? `Estimated cost: $${context.estimatedCost}` : ''}
${context.estimatedTime ? `Estimated time: ${context.estimatedTime} minutes` : ''}`;

    const analysis = await LLMService.chat({
      userId,
      conversationId: `decision_eval_${Date.now()}`,
      message: `${systemPrompt}\n\n${userPrompt}`,
      engineType: 'decision',
    });

    // Parse LLM response to extract decision factors
    const shouldAct = this.determineShouldAct(context, analysis.response);
    const autonomyLevel = this.determineAutonomyLevel(context, profile);
    const confidence = this.calculateConfidence(context, profile);
    const risks = this.identifyRisks(context);
    const benefits = this.identifyBenefits(context);
    const alternatives = this.generateAlternatives(context);
    const policyConstraints = this.checkPolicyConstraints(context);

    const evaluation: DecisionEvaluation = {
      shouldAct,
      autonomyLevel,
      confidence,
      reasoning: analysis.response.substring(0, 500),
      risks,
      benefits,
      alternatives,
      requiresApproval: autonomyLevel <= AutonomyLevel.ASK,
      policyConstraints,
    };

    // Publish evaluation event
    await EventBus.publish({
      type: 'decision.evaluated',
      source: 'DecisionEngine',
      target: '*',
      data: {
        userId,
        context,
        evaluation,
      },
    });

    return evaluation;
  }

  /**
   * Make a decision and execute or request approval
   */
  async makeDecision(params: {
    userId: number;
    context: DecisionContext;
    evaluation?: DecisionEvaluation;
  }): Promise<Decision> {
    const { userId, context, evaluation: providedEvaluation } = params;

    // Evaluate if not provided
    const evaluation = providedEvaluation || await this.evaluateDecision({
      userId,
      context,
    });

    const db = await getDb();
    if (!db) {
      throw new Error('Database not available');
    }

    // Create decision record
    const status = evaluation.requiresApproval ? 'pending_approval' : 'approved';

    await db.insert(decisions).values({
      userId,
      decisionType: context.type,
      description: context.description,
      autonomyLevel: evaluation.autonomyLevel,
      confidence: evaluation.confidence,
      reasoning: evaluation.reasoning,
      status,
      context: context as any,
      evaluation: evaluation as any,
    });

    // Fetch the created decision
    const created = await db
      .select()
      .from(decisions)
      .where(eq(decisions.userId, userId))
      .orderBy(desc(decisions.id))
      .limit(1);

    const decision = created[0] as Decision;

    // Publish decision event
    await EventBus.publish({
      type: evaluation.requiresApproval ? 'decision.pending_approval' : 'decision.executed',
      source: 'DecisionEngine',
      target: '*',
      data: {
        userId,
        decisionId: decision.id,
        decision,
      },
    });

    // If requires approval, notify user
    if (evaluation.requiresApproval) {
      await this.requestApproval(decision);
    } else {
      // Execute immediately for autonomous decisions
      await this.executeDecision(decision.id);
      
      // Log autonomous decision activity
      await logActivity({
        engine: 'decision',
        action: 'autonomous_decision',
        title: `Made decision: ${context.description}`,
        description: `Autonomously decided to ${context.description} (confidence: ${evaluation.confidence}%)`,
        metadata: JSON.stringify({
          decisionId: decision.id,
          type: context.type,
          autonomyLevel: evaluation.autonomyLevel,
          confidence: evaluation.confidence,
          reasoning: evaluation.reasoning,
        }),
        impact: context.impact,
        status: 'completed',
      });
    }

    return decision;
  }

  /**
   * Request approval for a decision
   */
  private async requestApproval(decision: Decision): Promise<void> {
    // Publish approval request event
    await EventBus.publish({
      type: 'decision.approval_requested',
      source: 'DecisionEngine',
      target: 'user',
      data: {
        decisionId: decision.id,
        decision,
      },
    });

    // TODO: Send notification to user via notification service
    console.log(`[DecisionEngine] Approval requested for decision ${decision.id}`);
  }

  /**
   * Execute a decision
   */
  async executeDecision(decisionId: number): Promise<boolean> {
    const db = await getDb();
    if (!db) return false;

    try {
      const decision = await db
        .select()
        .from(decisions)
        .where(eq(decisions.id, decisionId))
        .limit(1);

      if (decision.length === 0) {
        throw new Error('Decision not found');
      }

      const dec = decision[0];

      // Update status to executing
      await db
        .update(decisions)
        .set({
          status: 'executing',
          executedAt: new Date(),
        })
        .where(eq(decisions.id, decisionId));

      // TODO: Actual execution logic based on decision type
      console.log(`[DecisionEngine] Executing decision ${decisionId}: ${dec.description}`);
      
      // Log decision execution
      await logActivity({
        engine: 'decision',
        action: 'execute_decision',
        title: `Executed decision: ${dec.description}`,
        description: `Successfully executed decision after ${dec.status === 'approved' ? 'approval' : 'evaluation'}`,
        metadata: JSON.stringify({
          decisionId,
          type: dec.decisionType,
          status: dec.status,
        }),
        impact: 'medium',
        status: 'completed',
      });

      // Simulate execution
      await new Promise(resolve => setTimeout(resolve, 100));

      // Update status to executed
      await db
        .update(decisions)
        .set({
          status: 'executed',
        })
        .where(eq(decisions.id, decisionId));

      // Publish execution event
      await EventBus.publish({
        type: 'decision.executed',
        source: 'DecisionEngine',
        target: '*',
        data: {
          decisionId,
          decision: dec,
        },
      });

      return true;
    } catch (error) {
      console.error('[DecisionEngine] Error executing decision:', error);

      // Update status to failed
      await db
        .update(decisions)
        .set({
          status: 'failed',
        })
        .where(eq(decisions.id, decisionId));

      return false;
    }
  }

  /**
   * Approve a decision
   */
  async approveDecision(params: {
    decisionId: number;
    userId: number;
    feedback?: string;
  }): Promise<boolean> {
    const { decisionId, userId, feedback } = params;

    const db = await getDb();
    if (!db) return false;

    try {
      // Update decision status
      await db
        .update(decisions)
        .set({
          status: 'approved',
          approvedAt: new Date(),
          feedback,
        })
        .where(and(
          eq(decisions.id, decisionId),
          eq(decisions.userId, userId)
        ));

      // Execute the decision
      await this.executeDecision(decisionId);

      // Publish approval event
      await EventBus.publish({
        type: 'decision.approved',
        source: 'DecisionEngine',
        target: '*',
        data: {
          decisionId,
          userId,
          feedback,
        },
      });

      return true;
    } catch (error) {
      console.error('[DecisionEngine] Error approving decision:', error);
      return false;
    }
  }

  /**
   * Reject a decision
   */
  async rejectDecision(params: {
    decisionId: number;
    userId: number;
    reason?: string;
  }): Promise<boolean> {
    const { decisionId, userId, reason } = params;

    const db = await getDb();
    if (!db) return false;

    try {
      // Update decision status
      await db
        .update(decisions)
        .set({
          status: 'rejected',
          feedback: reason,
        })
        .where(and(
          eq(decisions.id, decisionId),
          eq(decisions.userId, userId)
        ));

      // Publish rejection event
      await EventBus.publish({
        type: 'decision.rejected',
        source: 'DecisionEngine',
        target: '*',
        data: {
          decisionId,
          userId,
          reason,
        },
      });

      return true;
    } catch (error) {
      console.error('[DecisionEngine] Error rejecting decision:', error);
      return false;
    }
  }

  /**
   * Get pending decisions for approval
   */
  async getPendingDecisions(userId: number): Promise<Decision[]> {
    const db = await getDb();
    if (!db) return [];

    const pending = await db
      .select()
      .from(decisions)
      .where(and(
        eq(decisions.userId, userId),
        eq(decisions.status, 'pending_approval')
      ))
      .orderBy(desc(decisions.createdAt));

    return pending as Decision[];
  }

  /**
   * Get decision history
   */
  async getDecisionHistory(params: {
    userId: number;
    limit?: number;
    status?: string;
  }): Promise<Decision[]> {
    const { userId, limit = 50, status } = params;

    const db = await getDb();
    if (!db) return [];

    const conditions = [eq(decisions.userId, userId)];
    
    if (status) {
      conditions.push(sql`${decisions.status} = ${status}`);
    }

    let query = db
      .select()
      .from(decisions)
      .where(and(...conditions));

    const history = await query
      .orderBy(desc(decisions.createdAt))
      .limit(limit);

    return history as Decision[];
  }

  /**
   * Helper: Determine if should act
   */
  private determineShouldAct(context: DecisionContext, llmResponse: string): boolean {
    // High urgency + high impact = should act
    if (context.urgency === 'critical' || context.urgency === 'high') {
      return true;
    }

    // Check LLM recommendation
    const shouldActKeywords = ['should act', 'recommend acting', 'take action', 'proceed'];
    return shouldActKeywords.some(keyword => 
      llmResponse.toLowerCase().includes(keyword)
    );
  }

  /**
   * Helper: Determine autonomy level
   */
  private determineAutonomyLevel(
    context: DecisionContext,
    profile: any
  ): AutonomyLevel {
    // Critical decisions always require approval
    if (context.urgency === 'critical' || context.impact === 'high') {
      return AutonomyLevel.ASK;
    }

    // Irreversible decisions require approval
    if (context.reversibility === 'irreversible' || context.reversibility === 'difficult') {
      return AutonomyLevel.ASK;
    }

    // Low impact + easy reversibility = autonomous
    if (context.impact === 'low' && context.reversibility === 'easy') {
      return AutonomyLevel.AUTONOMOUS;
    }

    // Medium impact = act then report
    if (context.impact === 'medium') {
      return AutonomyLevel.ACT_THEN_REPORT;
    }

    // Default: ask for approval
    return AutonomyLevel.ASK;
  }

  /**
   * Helper: Calculate confidence
   */
  private calculateConfidence(context: DecisionContext, profile: any): number {
    let confidence = 50; // Base confidence

    // Higher confidence for low impact decisions
    if (context.impact === 'low') confidence += 20;
    if (context.impact === 'high') confidence -= 20;

    // Higher confidence for easily reversible decisions
    if (context.reversibility === 'easy') confidence += 15;
    if (context.reversibility === 'irreversible') confidence -= 30;

    // Higher confidence if we have good user profile
    if (profile && profile.completeness > 50) {
      confidence += Math.floor(profile.completeness / 10);
    }

    return Math.max(0, Math.min(100, confidence));
  }

  /**
   * Helper: Identify risks
   */
  private identifyRisks(context: DecisionContext): string[] {
    const risks: string[] = [];

    if (context.impact === 'high') {
      risks.push('High impact decision - could significantly affect user');
    }

    if (context.reversibility === 'irreversible' || context.reversibility === 'difficult') {
      risks.push('Difficult or impossible to undo');
    }

    if (context.estimatedCost && context.estimatedCost > 100) {
      risks.push(`Significant cost: $${context.estimatedCost}`);
    }

    if (context.urgency === 'critical') {
      risks.push('Time-sensitive - may not have time for thorough evaluation');
    }

    return risks;
  }

  /**
   * Helper: Identify benefits
   */
  private identifyBenefits(context: DecisionContext): string[] {
    const benefits: string[] = [];

    if (context.urgency === 'high' || context.urgency === 'critical') {
      benefits.push('Addresses urgent need');
    }

    if (context.reversibility === 'easy') {
      benefits.push('Easy to undo if needed');
    }

    if (context.impact === 'high') {
      benefits.push('Potential for significant positive impact');
    }

    return benefits;
  }

  /**
   * Helper: Generate alternatives
   */
  private generateAlternatives(context: DecisionContext): Array<{
    description: string;
    pros: string[];
    cons: string[];
  }> {
    const alternatives: Array<{
      description: string;
      pros: string[];
      cons: string[];
    }> = [];

    // Always include "do nothing" as an alternative
    alternatives.push({
      description: 'Do nothing / Wait',
      pros: ['No risk', 'More time to evaluate'],
      cons: ['May miss opportunity', 'Problem may worsen'],
    });

    // Include provided alternatives
    if (context.alternatives) {
      context.alternatives.forEach(alt => {
        alternatives.push({
          description: alt,
          pros: ['Alternative approach'],
          cons: ['May not be optimal'],
        });
      });
    }

    return alternatives;
  }

  /**
   * Helper: Check policy constraints
   */
  private checkPolicyConstraints(context: DecisionContext): string[] {
    const constraints: string[] = [];

    // TODO: Integrate with Policy Engine
    // For now, return basic constraints based on decision type

    if (context.type === 'resource_allocation' && context.estimatedCost && context.estimatedCost > 1000) {
      constraints.push('Requires approval for expenditures over $1000');
    }

    if (context.type === 'communication') {
      constraints.push('Must respect user communication preferences');
    }

    return constraints;
  }
}

// Export singleton instance
export const DecisionEngine = new DecisionEngineService();
