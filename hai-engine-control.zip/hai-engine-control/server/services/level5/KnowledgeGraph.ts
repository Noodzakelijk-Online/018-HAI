/**
 * Knowledge Graph - Relationship Intelligence System
 * 
 * Manages entities and relationships across HAI's digital ecosystem.
 * Provides context-aware understanding through graph traversal and pattern matching.
 * 
 * This is the foundation for HAI's contextual intelligence.
 */

import { getDb } from "../../db";
import { knowledgeEntities, knowledgeRelationships } from "../../../drizzle/schema-level5";
import { eq, like, and } from "drizzle-orm";
import { v4 as uuidv4 } from 'uuid';

// ============================================================================
// Types
// ============================================================================

export interface Entity {
  id?: number;
  entityId: string; // UUID
  entityType: string; // person, organization, event, concept, etc.
  name: string;
  properties?: Record<string, any>;
  source?: string;
  confidence: number; // 0-1
}

export interface Relationship {
  id?: number;
  relationshipId: string; // UUID
  sourceEntityId: string;
  targetEntityId: string;
  relationshipType: string; // knows, works_at, manages, etc.
  properties?: Record<string, any>;
  confidence: number; // 0-1
}

export interface GraphQuery {
  entityType?: string;
  entityName?: string;
  relationshipType?: string;
  minConfidence?: number;
  limit?: number;
}

export interface GraphPath {
  entities: Entity[];
  relationships: Relationship[];
  pathLength: number;
}

// ============================================================================
// Knowledge Graph Service
// ============================================================================

export class KnowledgeGraph {
  /**
   * Add or update an entity
   */
  async upsertEntity(entity: Omit<Entity, 'id'>): Promise<string> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const entityId = entity.entityId || uuidv4();
    
    // Check if entity exists
    const existing = await db.select()
      .from(knowledgeEntities)
      .where(eq(knowledgeEntities.entityId, entityId))
      .limit(1);
    
    if (existing && existing.length > 0) {
      // Update existing entity
      await db.update(knowledgeEntities)
        .set({
          entityType: entity.entityType,
          name: entity.name,
          properties: entity.properties ? JSON.stringify(entity.properties) : undefined,
          source: entity.source,
          confidence: entity.confidence,
          updatedAt: new Date()
        })
        .where(eq(knowledgeEntities.entityId, entityId));
    } else {
      // Insert new entity
      await db.insert(knowledgeEntities).values({
        entityId,
        entityType: entity.entityType,
        name: entity.name,
        properties: entity.properties ? JSON.stringify(entity.properties) : undefined,
        source: entity.source,
        confidence: entity.confidence
      });
    }
    
    return entityId;
  }
  
  /**
   * Add a relationship between entities
   */
  async addRelationship(relationship: Omit<Relationship, 'id'>): Promise<string> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const relationshipId = relationship.relationshipId || uuidv4();
    
    await db.insert(knowledgeRelationships).values({
      relationshipId,
      sourceEntityId: relationship.sourceEntityId,
      targetEntityId: relationship.targetEntityId,
      relationshipType: relationship.relationshipType,
      properties: relationship.properties ? JSON.stringify(relationship.properties) : undefined,
      confidence: relationship.confidence
    });
    
    return relationshipId;
  }
  
  /**
   * Get entity by ID
   */
  async getEntity(entityId: string): Promise<Entity | null> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const entities = await db.select()
      .from(knowledgeEntities)
      .where(eq(knowledgeEntities.entityId, entityId))
      .limit(1);
    
    if (!entities || entities.length === 0) return null;
    
    const entity = entities[0];
    return {
      id: entity.id,
      entityId: entity.entityId,
      entityType: entity.entityType,
      name: entity.name,
      properties: entity.properties ? JSON.parse(entity.properties as string) : undefined,
      source: entity.source || undefined,
      confidence: entity.confidence
    };
  }
  
  /**
   * Search entities
   */
  async searchEntities(query: GraphQuery): Promise<Entity[]> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    let conditions: any[] = [];
    
    if (query.entityType) {
      conditions.push(eq(knowledgeEntities.entityType, query.entityType));
    }
    
    if (query.entityName) {
      conditions.push(like(knowledgeEntities.name, `%${query.entityName}%`));
    }
    
    if (query.minConfidence !== undefined) {
      // Note: This would need a custom SQL condition in production
      // For now, we'll filter in memory
    }
    
    const results = await db.select()
      .from(knowledgeEntities)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .limit(query.limit || 100);
    
    return results.map(entity => ({
      id: entity.id,
      entityId: entity.entityId,
      entityType: entity.entityType,
      name: entity.name,
      properties: entity.properties ? JSON.parse(entity.properties as string) : undefined,
      source: entity.source || undefined,
      confidence: entity.confidence
    })).filter(e => !query.minConfidence || e.confidence >= query.minConfidence);
  }
  
  /**
   * Get relationships for an entity
   */
  async getRelationships(entityId: string, direction: 'outgoing' | 'incoming' | 'both' = 'both'): Promise<Relationship[]> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    let conditions: any[] = [];
    
    if (direction === 'outgoing' || direction === 'both') {
      const outgoing = await db.select()
        .from(knowledgeRelationships)
        .where(eq(knowledgeRelationships.sourceEntityId, entityId));
      
      if (direction === 'outgoing') {
        return this.parseRelationships(outgoing);
      }
      
      conditions.push(...outgoing);
    }
    
    if (direction === 'incoming' || direction === 'both') {
      const incoming = await db.select()
        .from(knowledgeRelationships)
        .where(eq(knowledgeRelationships.targetEntityId, entityId));
      
      if (direction === 'incoming') {
        return this.parseRelationships(incoming);
      }
      
      conditions.push(...incoming);
    }
    
    return this.parseRelationships(conditions);
  }
  
  /**
   * Find path between two entities
   */
  async findPath(sourceEntityId: string, targetEntityId: string, maxDepth: number = 3): Promise<GraphPath | null> {
    // This is a simplified version - in production, use Neo4j for efficient graph traversal
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    // BFS to find shortest path
    const visited = new Set<string>();
    const queue: { entityId: string; path: Entity[]; relationships: Relationship[] }[] = [];
    
    const sourceEntity = await this.getEntity(sourceEntityId);
    if (!sourceEntity) return null;
    
    queue.push({
      entityId: sourceEntityId,
      path: [sourceEntity],
      relationships: []
    });
    
    while (queue.length > 0) {
      const current = queue.shift()!;
      
      if (current.entityId === targetEntityId) {
        return {
          entities: current.path,
          relationships: current.relationships,
          pathLength: current.path.length - 1
        };
      }
      
      if (current.path.length > maxDepth) continue;
      if (visited.has(current.entityId)) continue;
      
      visited.add(current.entityId);
      
      // Get outgoing relationships
      const relationships = await this.getRelationships(current.entityId, 'outgoing');
      
      for (const rel of relationships) {
        const nextEntity = await this.getEntity(rel.targetEntityId);
        if (!nextEntity) continue;
        
        queue.push({
          entityId: rel.targetEntityId,
          path: [...current.path, nextEntity],
          relationships: [...current.relationships, rel]
        });
      }
    }
    
    return null; // No path found
  }
  
  /**
   * Get related entities (1-hop neighbors)
   */
  async getRelatedEntities(entityId: string): Promise<{ entity: Entity; relationship: Relationship }[]> {
    const relationships = await this.getRelationships(entityId, 'both');
    const results: { entity: Entity; relationship: Relationship }[] = [];
    
    for (const rel of relationships) {
      const relatedEntityId = rel.sourceEntityId === entityId ? rel.targetEntityId : rel.sourceEntityId;
      const entity = await this.getEntity(relatedEntityId);
      
      if (entity) {
        results.push({ entity, relationship: rel });
      }
    }
    
    return results;
  }
  
  /**
   * Get entity context (entity + relationships + related entities)
   */
  async getEntityContext(entityId: string): Promise<{
    entity: Entity;
    relationships: Relationship[];
    relatedEntities: Entity[];
  } | null> {
    const entity = await this.getEntity(entityId);
    if (!entity) return null;
    
    const relationships = await this.getRelationships(entityId);
    const related = await this.getRelatedEntities(entityId);
    
    return {
      entity,
      relationships,
      relatedEntities: related.map(r => r.entity)
    };
  }
  
  // ============================================================================
  // Utilities
  // ============================================================================
  
  private parseRelationships(raw: any[]): Relationship[] {
    return raw.map(rel => ({
      id: rel.id,
      relationshipId: rel.relationshipId || rel.relationship_id,
      sourceEntityId: rel.sourceEntityId || rel.source_entity_id,
      targetEntityId: rel.targetEntityId || rel.target_entity_id,
      relationshipType: rel.relationshipType || rel.relationship_type,
      properties: rel.properties ? (typeof rel.properties === 'string' ? JSON.parse(rel.properties) : rel.properties) : undefined,
      confidence: rel.confidence
    }));
  }
}

// ============================================================================
// Export singleton instance
// ============================================================================

export const knowledgeGraph = new KnowledgeGraph();
