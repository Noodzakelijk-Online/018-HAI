/**
 * Semantic Memory - Facts and Concepts
 * 
 * Stores factual knowledge, concepts, and their relationships.
 * Enables knowledge retrieval and reasoning about the world.
 * 
 * Examples: "Paris is the capital of France", "HTTP is a protocol", "User prefers dark mode"
 */

import { getDb } from "../../../db";
import { semanticMemory } from "../../../../drizzle/schema-level5";
import { eq, like, and, desc } from "drizzle-orm";
import { v4 as uuidv4 } from 'uuid';

// ============================================================================
// Types
// ============================================================================

export interface Concept {
  id?: number;
  conceptId: string; // UUID
  conceptType: string; // fact, preference, rule, definition, etc.
  content: string; // The actual knowledge
  relatedConcepts?: string[]; // IDs of related concepts
  confidence: number; // 0-1
  source?: string; // Where this knowledge came from
}

export interface ConceptQuery {
  conceptType?: string;
  searchTerm?: string;
  minConfidence?: number;
  limit?: number;
}

// ============================================================================
// Semantic Memory Service
// ============================================================================

export class SemanticMemory {
  /**
   * Store a new concept or fact
   */
  async storeConcept(concept: Omit<Concept, 'id'>): Promise<string> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const conceptId = concept.conceptId || uuidv4();
    
    // Check if concept exists
    const existing = await db.select()
      .from(semanticMemory)
      .where(eq(semanticMemory.conceptId, conceptId))
      .limit(1);
    
    if (existing && existing.length > 0) {
      // Update existing concept
      await db.update(semanticMemory)
        .set({
          conceptType: concept.conceptType,
          content: concept.content,
          relatedConcepts: concept.relatedConcepts ? JSON.stringify(concept.relatedConcepts) : undefined,
          confidence: concept.confidence,
          source: concept.source,
          updatedAt: new Date()
        })
        .where(eq(semanticMemory.conceptId, conceptId));
    } else {
      // Insert new concept
      await db.insert(semanticMemory).values({
        conceptId,
        conceptType: concept.conceptType,
        content: concept.content,
        relatedConcepts: concept.relatedConcepts ? JSON.stringify(concept.relatedConcepts) : undefined,
        confidence: concept.confidence,
        source: concept.source
      });
    }
    
    return conceptId;
  }
  
  /**
   * Retrieve a concept by ID
   */
  async getConcept(conceptId: string): Promise<Concept | null> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const concepts = await db.select()
      .from(semanticMemory)
      .where(eq(semanticMemory.conceptId, conceptId))
      .limit(1);
    
    if (!concepts || concepts.length === 0) return null;
    
    return this.parseConcept(concepts[0]);
  }
  
  /**
   * Search concepts
   */
  async searchConcepts(query: ConceptQuery): Promise<Concept[]> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    let conditions: any[] = [];
    
    if (query.conceptType) {
      conditions.push(eq(semanticMemory.conceptType, query.conceptType));
    }
    
    if (query.searchTerm) {
      conditions.push(like(semanticMemory.content, `%${query.searchTerm}%`));
    }
    
    const results = await db.select()
      .from(semanticMemory)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(semanticMemory.confidence))
      .limit(query.limit || 100);
    
    return results
      .map(c => this.parseConcept(c))
      .filter(c => !query.minConfidence || c.confidence >= query.minConfidence);
  }
  
  /**
   * Get related concepts
   */
  async getRelatedConcepts(conceptId: string): Promise<Concept[]> {
    const concept = await this.getConcept(conceptId);
    if (!concept || !concept.relatedConcepts) return [];
    
    const related: Concept[] = [];
    for (const relatedId of concept.relatedConcepts) {
      const relatedConcept = await this.getConcept(relatedId);
      if (relatedConcept) {
        related.push(relatedConcept);
      }
    }
    
    return related;
  }
  
  /**
   * Link two concepts together
   */
  async linkConcepts(conceptId1: string, conceptId2: string): Promise<void> {
    const concept1 = await this.getConcept(conceptId1);
    const concept2 = await this.getConcept(conceptId2);
    
    if (!concept1 || !concept2) {
      throw new Error('One or both concepts not found');
    }
    
    // Add bidirectional links
    const related1 = concept1.relatedConcepts || [];
    if (!related1.includes(conceptId2)) {
      related1.push(conceptId2);
      await this.updateRelatedConcepts(conceptId1, related1);
    }
    
    const related2 = concept2.relatedConcepts || [];
    if (!related2.includes(conceptId1)) {
      related2.push(conceptId1);
      await this.updateRelatedConcepts(conceptId2, related2);
    }
  }
  
  /**
   * Update related concepts for a concept
   */
  private async updateRelatedConcepts(conceptId: string, relatedConcepts: string[]): Promise<void> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    await db.update(semanticMemory)
      .set({
        relatedConcepts: JSON.stringify(relatedConcepts),
        updatedAt: new Date()
      })
      .where(eq(semanticMemory.conceptId, conceptId));
  }
  
  /**
   * Update concept confidence
   */
  async updateConfidence(conceptId: string, newConfidence: number): Promise<void> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    await db.update(semanticMemory)
      .set({
        confidence: Math.max(0, Math.min(1, newConfidence)), // Clamp to [0, 1]
        updatedAt: new Date()
      })
      .where(eq(semanticMemory.conceptId, conceptId));
  }
  
  /**
   * Reinforce a concept (increase confidence)
   */
  async reinforceConcept(conceptId: string, reinforcement: number = 0.1): Promise<void> {
    const concept = await this.getConcept(conceptId);
    if (!concept) return;
    
    const newConfidence = Math.min(1.0, concept.confidence + reinforcement);
    await this.updateConfidence(conceptId, newConfidence);
  }
  
  /**
   * Decay concept confidence over time (forgetting)
   */
  async decayConcept(conceptId: string, decayRate: number = 0.05): Promise<void> {
    const concept = await this.getConcept(conceptId);
    if (!concept) return;
    
    const newConfidence = Math.max(0.0, concept.confidence - decayRate);
    await this.updateConfidence(conceptId, newConfidence);
  }
  
  /**
   * Get all concepts of a specific type
   */
  async getConceptsByType(conceptType: string): Promise<Concept[]> {
    return this.searchConcepts({ conceptType });
  }
  
  /**
   * Get high-confidence concepts
   */
  async getHighConfidenceConcepts(minConfidence: number = 0.8, limit: number = 50): Promise<Concept[]> {
    return this.searchConcepts({ minConfidence, limit });
  }
  
  /**
   * Get low-confidence concepts (uncertain knowledge)
   */
  async getLowConfidenceConcepts(maxConfidence: number = 0.5, limit: number = 50): Promise<Concept[]> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const results = await db.select()
      .from(semanticMemory)
      .orderBy(semanticMemory.confidence)
      .limit(limit);
    
    return results
      .map(c => this.parseConcept(c))
      .filter(c => c.confidence <= maxConfidence);
  }
  
  /**
   * Delete a concept
   */
  async deleteConcept(conceptId: string): Promise<void> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    await db.delete(semanticMemory)
      .where(eq(semanticMemory.conceptId, conceptId));
  }
  
  /**
   * Get concept network (concept + related concepts recursively)
   */
  async getConceptNetwork(conceptId: string, maxDepth: number = 2): Promise<{
    concepts: Concept[];
    relationships: Array<{ from: string; to: string }>;
  }> {
    const visited = new Set<string>();
    const concepts: Concept[] = [];
    const relationships: Array<{ from: string; to: string }> = [];
    
    const traverse = async (id: string, depth: number) => {
      if (depth > maxDepth || visited.has(id)) return;
      
      visited.add(id);
      const concept = await this.getConcept(id);
      if (!concept) return;
      
      concepts.push(concept);
      
      if (concept.relatedConcepts) {
        for (const relatedId of concept.relatedConcepts) {
          relationships.push({ from: id, to: relatedId });
          await traverse(relatedId, depth + 1);
        }
      }
    };
    
    await traverse(conceptId, 0);
    
    return { concepts, relationships };
  }
  
  // ============================================================================
  // Utilities
  // ============================================================================
  
  private parseConcept(raw: any): Concept {
    return {
      id: raw.id,
      conceptId: raw.conceptId || raw.concept_id,
      conceptType: raw.conceptType || raw.concept_type,
      content: raw.content,
      relatedConcepts: raw.relatedConcepts || raw.related_concepts
        ? (typeof raw.relatedConcepts === 'string' || typeof raw.related_concepts === 'string'
          ? JSON.parse(raw.relatedConcepts || raw.related_concepts)
          : raw.relatedConcepts || raw.related_concepts)
        : undefined,
      confidence: raw.confidence,
      source: raw.source || undefined
    };
  }
}

// ============================================================================
// Export singleton instance
// ============================================================================

export const semanticMemory = new SemanticMemory();
