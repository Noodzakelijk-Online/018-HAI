/**
 * Procedural Memory - Skills and Procedures
 * 
 * Stores learned skills, procedures, and how-to knowledge.
 * Tracks success rates and improves execution over time.
 * 
 * Examples: "How to send an email", "How to schedule a meeting", "How to analyze data"
 */

import { getDb } from "../../../db";
import { proceduralMemory } from "../../../../drizzle/schema-level5";
import { eq, and, desc } from "drizzle-orm";

// ============================================================================
// Types
// ============================================================================

export interface Skill {
  id?: number;
  skillName: string;
  skillType: string; // communication, analysis, automation, etc.
  procedure: {
    steps: Step[];
    prerequisites?: string[];
    expectedOutcome: string;
    estimatedDuration?: number; // seconds
  };
  successRate: number; // 0-1
  timesExecuted: number;
  lastExecuted?: Date;
}

export interface Step {
  stepNumber: number;
  action: string;
  parameters?: Record<string, any>;
  expectedResult?: string;
  fallbackAction?: string;
}

export interface ExecutionResult {
  success: boolean;
  duration: number; // seconds
  outcome: string;
  errors?: string[];
}

// ============================================================================
// Procedural Memory Service
// ============================================================================

export class ProceduralMemory {
  /**
   * Store a new skill or procedure
   */
  async storeSkill(skill: Omit<Skill, 'id' | 'successRate' | 'timesExecuted'>): Promise<number> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const result = await db.insert(proceduralMemory).values({
      skillName: skill.skillName,
      skillType: skill.skillType,
      procedure: JSON.stringify(skill.procedure),
      successRate: 0.0,
      timesExecuted: 0
    });
    
    return result[0].insertId;
  }
  
  /**
   * Retrieve a skill by name
   */
  async getSkill(skillName: string): Promise<Skill | null> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const skills = await db.select()
      .from(proceduralMemory)
      .where(eq(proceduralMemory.skillName, skillName))
      .limit(1);
    
    if (!skills || skills.length === 0) return null;
    
    const skill = skills[0];
    return {
      id: skill.id,
      skillName: skill.skillName,
      skillType: skill.skillType,
      procedure: JSON.parse(skill.procedure as string),
      successRate: skill.successRate,
      timesExecuted: skill.timesExecuted,
      lastExecuted: skill.lastExecuted || undefined
    };
  }
  
  /**
   * Get all skills of a specific type
   */
  async getSkillsByType(skillType: string): Promise<Skill[]> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const skills = await db.select()
      .from(proceduralMemory)
      .where(eq(proceduralMemory.skillType, skillType))
      .orderBy(desc(proceduralMemory.successRate));
    
    return skills.map(skill => ({
      id: skill.id,
      skillName: skill.skillName,
      skillType: skill.skillType,
      procedure: JSON.parse(skill.procedure as string),
      successRate: skill.successRate,
      timesExecuted: skill.timesExecuted,
      lastExecuted: skill.lastExecuted || undefined
    }));
  }
  
  /**
   * Execute a skill and record the result
   */
  async executeSkill(skillName: string, context?: Record<string, any>): Promise<ExecutionResult> {
    const skill = await this.getSkill(skillName);
    if (!skill) {
      throw new Error(`Skill "${skillName}" not found`);
    }
    
    const startTime = Date.now();
    const errors: string[] = [];
    let success = true;
    let outcome = '';
    
    try {
      // Execute each step
      for (const step of skill.procedure.steps) {
        console.log(`[ProceduralMemory] Executing step ${step.stepNumber}: ${step.action}`);
        
        // In production, this would actually execute the action
        // For now, we simulate execution
        const stepResult = await this.simulateStepExecution(step, context);
        
        if (!stepResult.success) {
          if (step.fallbackAction) {
            console.log(`[ProceduralMemory] Step failed, executing fallback: ${step.fallbackAction}`);
            // Execute fallback
          } else {
            errors.push(`Step ${step.stepNumber} failed: ${stepResult.error}`);
            success = false;
            break;
          }
        }
        
        outcome += `${step.action} completed. `;
      }
      
      if (success) {
        outcome = skill.procedure.expectedOutcome;
      }
    } catch (error) {
      success = false;
      errors.push(error instanceof Error ? error.message : String(error));
    }
    
    const duration = (Date.now() - startTime) / 1000;
    
    // Update skill statistics
    await this.recordExecution(skillName, success);
    
    return {
      success,
      duration,
      outcome,
      errors: errors.length > 0 ? errors : undefined
    };
  }
  
  /**
   * Record skill execution result
   */
  async recordExecution(skillName: string, success: boolean): Promise<void> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const skill = await this.getSkill(skillName);
    if (!skill) return;
    
    // Calculate new success rate using exponential moving average
    const alpha = 0.1; // Weight for new observation
    const newSuccessRate = success
      ? skill.successRate + alpha * (1 - skill.successRate)
      : skill.successRate * (1 - alpha);
    
    await db.update(proceduralMemory)
      .set({
        successRate: newSuccessRate,
        timesExecuted: skill.timesExecuted + 1,
        lastExecuted: new Date(),
        updatedAt: new Date()
      })
      .where(eq(proceduralMemory.skillName, skillName));
  }
  
  /**
   * Update a skill's procedure (learning/improvement)
   */
  async updateProcedure(skillName: string, newProcedure: Skill['procedure']): Promise<void> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    await db.update(proceduralMemory)
      .set({
        procedure: JSON.stringify(newProcedure),
        updatedAt: new Date()
      })
      .where(eq(proceduralMemory.skillName, skillName));
  }
  
  /**
   * Get most successful skills
   */
  async getTopSkills(limit: number = 10): Promise<Skill[]> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const skills = await db.select()
      .from(proceduralMemory)
      .orderBy(desc(proceduralMemory.successRate))
      .limit(limit);
    
    return skills.map(skill => ({
      id: skill.id,
      skillName: skill.skillName,
      skillType: skill.skillType,
      procedure: JSON.parse(skill.procedure as string),
      successRate: skill.successRate,
      timesExecuted: skill.timesExecuted,
      lastExecuted: skill.lastExecuted || undefined
    }));
  }
  
  /**
   * Get skills that need improvement (low success rate)
   */
  async getSkillsNeedingImprovement(threshold: number = 0.7): Promise<Skill[]> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const skills = await db.select()
      .from(proceduralMemory);
    
    return skills
      .filter(skill => skill.successRate < threshold && skill.timesExecuted > 0)
      .map(skill => ({
        id: skill.id,
        skillName: skill.skillName,
        skillType: skill.skillType,
        procedure: JSON.parse(skill.procedure as string),
        successRate: skill.successRate,
        timesExecuted: skill.timesExecuted,
        lastExecuted: skill.lastExecuted || undefined
      }))
      .sort((a, b) => a.successRate - b.successRate);
  }
  
  // ============================================================================
  // Utilities
  // ============================================================================
  
  private async simulateStepExecution(
    step: Step,
    context?: Record<string, any>
  ): Promise<{ success: boolean; error?: string }> {
    // Simulate step execution with 90% success rate
    // In production, this would actually execute the action
    const success = Math.random() > 0.1;
    
    if (!success) {
      return {
        success: false,
        error: `Failed to execute: ${step.action}`
      };
    }
    
    return { success: true };
  }
}

// ============================================================================
// Export singleton instance
// ============================================================================

export const proceduralMemory = new ProceduralMemory();
