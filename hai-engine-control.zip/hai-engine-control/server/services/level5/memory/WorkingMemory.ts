/**
 * Working Memory - Short-Term Active Items
 * 
 * Manages currently active information with limited capacity (7±2 items).
 * Items expire after TTL or when capacity is exceeded.
 * 
 * Mimics human working memory for maintaining context during active tasks.
 * 
 * Examples: "Current conversation context", "Active task parameters", "Temporary calculations"
 */

import { getDb } from "../../../db";
import { workingMemory } from "../../../../drizzle/schema-level5";
import { eq, lt, desc } from "drizzle-orm";
import { v4 as uuidv4 } from 'uuid';

// ============================================================================
// Types
// ============================================================================

export interface WorkingMemoryItem {
  id?: number;
  itemId: string; // UUID
  itemType: string; // conversation_context, task_param, calculation, etc.
  content: any; // Flexible JSON content
  priority: number; // 1-10, higher = more important
  ttlSeconds: number; // Time to live
  createdAt?: Date;
  expiresAt: Date;
}

export const WORKING_MEMORY_CAPACITY = 7; // Miller's Law: 7±2

// ============================================================================
// Working Memory Service
// ============================================================================

export class WorkingMemory {
  /**
   * Add item to working memory
   */
  async addItem(item: Omit<WorkingMemoryItem, 'id' | 'itemId' | 'createdAt' | 'expiresAt'>): Promise<string> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    // Clean up expired items first
    await this.cleanupExpired();
    
    // Check capacity
    const currentItems = await this.getActiveItems();
    
    if (currentItems.length >= WORKING_MEMORY_CAPACITY) {
      // Remove lowest priority item to make room
      await this.evictLowestPriority();
    }
    
    const itemId = uuidv4();
    const now = new Date();
    const expiresAt = new Date(now.getTime() + item.ttlSeconds * 1000);
    
    await db.insert(workingMemory).values({
      itemId,
      itemType: item.itemType,
      content: JSON.stringify(item.content),
      priority: item.priority,
      ttlSeconds: item.ttlSeconds,
      expiresAt
    });
    
    return itemId;
  }
  
  /**
   * Get an item by ID
   */
  async getItem(itemId: string): Promise<WorkingMemoryItem | null> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const items = await db.select()
      .from(workingMemory)
      .where(eq(workingMemory.itemId, itemId))
      .limit(1);
    
    if (!items || items.length === 0) return null;
    
    const item = items[0];
    
    // Check if expired
    if (new Date() > new Date(item.expiresAt)) {
      await this.removeItem(itemId);
      return null;
    }
    
    return this.parseItem(item);
  }
  
  /**
   * Get all active (non-expired) items
   */
  async getActiveItems(): Promise<WorkingMemoryItem[]> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const now = new Date();
    
    const items = await db.select()
      .from(workingMemory)
      .where(lt(workingMemory.expiresAt, now) ? undefined : undefined) // Get all, we'll filter
      .orderBy(desc(workingMemory.priority));
    
    // Filter expired and parse
    return items
      .filter(item => new Date(item.expiresAt) > now)
      .map(item => this.parseItem(item))
      .slice(0, WORKING_MEMORY_CAPACITY);
  }
  
  /**
   * Get items by type
   */
  async getItemsByType(itemType: string): Promise<WorkingMemoryItem[]> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const now = new Date();
    
    const items = await db.select()
      .from(workingMemory)
      .where(eq(workingMemory.itemType, itemType))
      .orderBy(desc(workingMemory.priority));
    
    return items
      .filter(item => new Date(item.expiresAt) > now)
      .map(item => this.parseItem(item));
  }
  
  /**
   * Update item priority
   */
  async updatePriority(itemId: string, newPriority: number): Promise<void> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    await db.update(workingMemory)
      .set({ priority: Math.max(1, Math.min(10, newPriority)) }) // Clamp to [1, 10]
      .where(eq(workingMemory.itemId, itemId));
  }
  
  /**
   * Extend item TTL (keep it in memory longer)
   */
  async extendTTL(itemId: string, additionalSeconds: number): Promise<void> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const item = await this.getItem(itemId);
    if (!item) return;
    
    const newExpiresAt = new Date(item.expiresAt.getTime() + additionalSeconds * 1000);
    
    await db.update(workingMemory)
      .set({
        ttlSeconds: item.ttlSeconds + additionalSeconds,
        expiresAt: newExpiresAt
      })
      .where(eq(workingMemory.itemId, itemId));
  }
  
  /**
   * Remove an item
   */
  async removeItem(itemId: string): Promise<void> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    await db.delete(workingMemory)
      .where(eq(workingMemory.itemId, itemId));
  }
  
  /**
   * Clear all items
   */
  async clear(): Promise<void> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    await db.delete(workingMemory);
  }
  
  /**
   * Clean up expired items
   */
  async cleanupExpired(): Promise<number> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const now = new Date();
    
    const result = await db.delete(workingMemory)
      .where(lt(workingMemory.expiresAt, now));
    
    return result[0].affectedRows || 0;
  }
  
  /**
   * Evict lowest priority item to make room
   */
  private async evictLowestPriority(): Promise<void> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const items = await this.getActiveItems();
    
    if (items.length === 0) return;
    
    // Sort by priority (ascending) and remove the lowest
    const lowestPriorityItem = items.sort((a, b) => a.priority - b.priority)[0];
    
    if (lowestPriorityItem) {
      await this.removeItem(lowestPriorityItem.itemId);
      console.log(`[WorkingMemory] Evicted item ${lowestPriorityItem.itemId} (priority ${lowestPriorityItem.priority})`);
    }
  }
  
  /**
   * Get current capacity usage
   */
  async getCapacityUsage(): Promise<{
    current: number;
    max: number;
    percentage: number;
  }> {
    const activeItems = await this.getActiveItems();
    
    return {
      current: activeItems.length,
      max: WORKING_MEMORY_CAPACITY,
      percentage: (activeItems.length / WORKING_MEMORY_CAPACITY) * 100
    };
  }
  
  /**
   * Get memory snapshot (for debugging/monitoring)
   */
  async getSnapshot(): Promise<{
    items: WorkingMemoryItem[];
    capacity: { current: number; max: number; percentage: number };
    expiringSoon: WorkingMemoryItem[];
  }> {
    const items = await this.getActiveItems();
    const capacity = await this.getCapacityUsage();
    
    // Items expiring in next 60 seconds
    const now = new Date();
    const soonThreshold = new Date(now.getTime() + 60 * 1000);
    const expiringSoon = items.filter(item => item.expiresAt <= soonThreshold);
    
    return {
      items,
      capacity,
      expiringSoon
    };
  }
  
  // ============================================================================
  // Utilities
  // ============================================================================
  
  private parseItem(raw: any): WorkingMemoryItem {
    return {
      id: raw.id,
      itemId: raw.itemId || raw.item_id,
      itemType: raw.itemType || raw.item_type,
      content: raw.content ? (typeof raw.content === 'string' ? JSON.parse(raw.content) : raw.content) : {},
      priority: raw.priority,
      ttlSeconds: raw.ttlSeconds || raw.ttl_seconds,
      createdAt: new Date(raw.createdAt || raw.created_at),
      expiresAt: new Date(raw.expiresAt || raw.expires_at)
    };
  }
}

// ============================================================================
// Export singleton instance
// ============================================================================

export const workingMemory = new WorkingMemory();
