/**
 * Episodic Memory - Personal Experiences
 * 
 * Stores autobiographical memories of specific events and experiences.
 * Captures context, emotions, and outcomes to learn from past interactions.
 * 
 * Examples: "User was frustrated when the email failed to send", "Successfully helped user plan vacation"
 */

import { getDb } from "../../../db";
import { episodicMemory } from "../../../../drizzle/schema-level5";
import { eq, and, desc, gte, lte } from "drizzle-orm";
import { v4 as uuidv4 } from 'uuid';

// ============================================================================
// Types
// ============================================================================

export interface Episode {
  id?: number;
  episodeId: string; // UUID
  eventType: string; // conversation, task_completion, error, success, etc.
  description: string;
  participants?: string[]; // User IDs, agent IDs
  location?: string; // Context: email, calendar, chat, etc.
  emotionalContext?: {
    userEmotion?: string; // happy, frustrated, neutral, etc.
    intensity?: number; // 0-1
    sentiment?: number; // -1 to 1
  };
  outcome?: string; // What happened as a result
  occurredAt: Date;
}

export interface EpisodeQuery {
  eventType?: string;
  participant?: string;
  location?: string;
  startDate?: Date;
  endDate?: Date;
  limit?: number;
}

// ============================================================================
// Episodic Memory Service
// ============================================================================

export class EpisodicMemory {
  /**
   * Store a new episode
   */
  async storeEpisode(episode: Omit<Episode, 'id'>): Promise<string> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const episodeId = episode.episodeId || uuidv4();
    
    await db.insert(episodicMemory).values({
      episodeId,
      eventType: episode.eventType,
      description: episode.description,
      participants: episode.participants ? JSON.stringify(episode.participants) : undefined,
      location: episode.location,
      emotionalContext: episode.emotionalContext ? JSON.stringify(episode.emotionalContext) : undefined,
      outcome: episode.outcome,
      occurredAt: episode.occurredAt
    });
    
    return episodeId;
  }
  
  /**
   * Retrieve an episode by ID
   */
  async getEpisode(episodeId: string): Promise<Episode | null> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const episodes = await db.select()
      .from(episodicMemory)
      .where(eq(episodicMemory.episodeId, episodeId))
      .limit(1);
    
    if (!episodes || episodes.length === 0) return null;
    
    return this.parseEpisode(episodes[0]);
  }
  
  /**
   * Search episodes
   */
  async searchEpisodes(query: EpisodeQuery): Promise<Episode[]> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    let conditions: any[] = [];
    
    if (query.eventType) {
      conditions.push(eq(episodicMemory.eventType, query.eventType));
    }
    
    if (query.location) {
      conditions.push(eq(episodicMemory.location, query.location));
    }
    
    if (query.startDate) {
      conditions.push(gte(episodicMemory.occurredAt, query.startDate));
    }
    
    if (query.endDate) {
      conditions.push(lte(episodicMemory.occurredAt, query.endDate));
    }
    
    const results = await db.select()
      .from(episodicMemory)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(episodicMemory.occurredAt))
      .limit(query.limit || 100);
    
    let episodes = results.map(e => this.parseEpisode(e));
    
    // Filter by participant if specified (JSON field, need to filter in memory)
    if (query.participant) {
      episodes = episodes.filter(e =>
        e.participants && e.participants.includes(query.participant!)
      );
    }
    
    return episodes;
  }
  
  /**
   * Get recent episodes
   */
  async getRecentEpisodes(limit: number = 20): Promise<Episode[]> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const results = await db.select()
      .from(episodicMemory)
      .orderBy(desc(episodicMemory.occurredAt))
      .limit(limit);
    
    return results.map(e => this.parseEpisode(e));
  }
  
  /**
   * Get episodes by event type
   */
  async getEpisodesByType(eventType: string, limit: number = 50): Promise<Episode[]> {
    return this.searchEpisodes({ eventType, limit });
  }
  
  /**
   * Get episodes involving a specific participant
   */
  async getEpisodesByParticipant(participantId: string, limit: number = 50): Promise<Episode[]> {
    return this.searchEpisodes({ participant: participantId, limit });
  }
  
  /**
   * Get episodes in a time range
   */
  async getEpisodesInTimeRange(startDate: Date, endDate: Date): Promise<Episode[]> {
    return this.searchEpisodes({ startDate, endDate });
  }
  
  /**
   * Get emotional episodes (with emotional context)
   */
  async getEmotionalEpisodes(limit: number = 50): Promise<Episode[]> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const results = await db.select()
      .from(episodicMemory)
      .orderBy(desc(episodicMemory.occurredAt))
      .limit(limit * 2); // Get more to filter
    
    return results
      .map(e => this.parseEpisode(e))
      .filter(e => e.emotionalContext !== undefined)
      .slice(0, limit);
  }
  
  /**
   * Get successful episodes (positive outcomes)
   */
  async getSuccessfulEpisodes(limit: number = 50): Promise<Episode[]> {
    return this.searchEpisodes({ eventType: 'success', limit });
  }
  
  /**
   * Get failure episodes (to learn from)
   */
  async getFailureEpisodes(limit: number = 50): Promise<Episode[]> {
    return this.searchEpisodes({ eventType: 'error', limit });
  }
  
  /**
   * Analyze emotional patterns
   */
  async analyzeEmotionalPatterns(participantId?: string): Promise<{
    totalEpisodes: number;
    emotionalEpisodes: number;
    averageSentiment: number;
    emotionDistribution: Record<string, number>;
  }> {
    let episodes: Episode[];
    
    if (participantId) {
      episodes = await this.getEpisodesByParticipant(participantId, 1000);
    } else {
      episodes = await this.getRecentEpisodes(1000);
    }
    
    const emotionalEpisodes = episodes.filter(e => e.emotionalContext);
    
    let totalSentiment = 0;
    const emotionCounts: Record<string, number> = {};
    
    for (const episode of emotionalEpisodes) {
      if (episode.emotionalContext) {
        if (episode.emotionalContext.sentiment !== undefined) {
          totalSentiment += episode.emotionalContext.sentiment;
        }
        
        if (episode.emotionalContext.userEmotion) {
          const emotion = episode.emotionalContext.userEmotion;
          emotionCounts[emotion] = (emotionCounts[emotion] || 0) + 1;
        }
      }
    }
    
    return {
      totalEpisodes: episodes.length,
      emotionalEpisodes: emotionalEpisodes.length,
      averageSentiment: emotionalEpisodes.length > 0
        ? totalSentiment / emotionalEpisodes.length
        : 0,
      emotionDistribution: emotionCounts
    };
  }
  
  /**
   * Get similar past episodes (for learning)
   */
  async getSimilarEpisodes(episode: Episode, limit: number = 10): Promise<Episode[]> {
    // Simple similarity based on event type and location
    // In production, use embeddings for semantic similarity
    return this.searchEpisodes({
      eventType: episode.eventType,
      location: episode.location,
      limit
    });
  }
  
  /**
   * Learn from past episodes
   */
  async learnFromPastEpisodes(eventType: string): Promise<{
    totalAttempts: number;
    successRate: number;
    commonOutcomes: Array<{ outcome: string; count: number }>;
    recommendations: string[];
  }> {
    const episodes = await this.getEpisodesByType(eventType, 100);
    
    const successes = episodes.filter(e =>
      e.outcome && (e.outcome.includes('success') || e.eventType === 'success')
    );
    
    const outcomeCounts: Record<string, number> = {};
    for (const episode of episodes) {
      if (episode.outcome) {
        outcomeCounts[episode.outcome] = (outcomeCounts[episode.outcome] || 0) + 1;
      }
    }
    
    const commonOutcomes = Object.entries(outcomeCounts)
      .map(([outcome, count]) => ({ outcome, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
    
    // Generate recommendations based on patterns
    const recommendations: string[] = [];
    
    if (successes.length / episodes.length < 0.5) {
      recommendations.push('Success rate is low. Consider reviewing the approach.');
    }
    
    if (episodes.some(e => e.emotionalContext?.userEmotion === 'frustrated')) {
      recommendations.push('Users have experienced frustration. Improve error handling.');
    }
    
    return {
      totalAttempts: episodes.length,
      successRate: episodes.length > 0 ? successes.length / episodes.length : 0,
      commonOutcomes,
      recommendations
    };
  }
  
  // ============================================================================
  // Utilities
  // ============================================================================
  
  private parseEpisode(raw: any): Episode {
    return {
      id: raw.id,
      episodeId: raw.episodeId || raw.episode_id,
      eventType: raw.eventType || raw.event_type,
      description: raw.description,
      participants: raw.participants
        ? (typeof raw.participants === 'string' ? JSON.parse(raw.participants) : raw.participants)
        : undefined,
      location: raw.location || undefined,
      emotionalContext: raw.emotionalContext || raw.emotional_context
        ? (typeof raw.emotionalContext === 'string' || typeof raw.emotional_context === 'string'
          ? JSON.parse(raw.emotionalContext || raw.emotional_context)
          : raw.emotionalContext || raw.emotional_context)
        : undefined,
      outcome: raw.outcome || undefined,
      occurredAt: new Date(raw.occurredAt || raw.occurred_at)
    };
  }
}

// ============================================================================
// Export singleton instance
// ============================================================================

export const episodicMemory = new EpisodicMemory();
