/**
 * Maturity Detection - User AI Sophistication Assessment
 * 
 * Detects and tracks user AI maturity level across 5 stages:
 * 1. Spark - Curious, basic exploration
 * 2. Adoption - Intentional experimentation
 * 3. Integration - Strategic operationalization
 * 4. Amplification - Embedded intelligence
 * 5. Transformation - AI-driven reinvention
 * 
 * Enables adaptive UX that matches user sophistication.
 */

import { getDb } from "../../db";
import { userMaturity } from "../../../drizzle/schema-level5";
import { eq } from "drizzle-orm";

// ============================================================================
// Types
// ============================================================================

export type MaturityLevel = 'spark' | 'adoption' | 'integration' | 'amplification' | 'transformation';

export interface UserMaturityProfile {
  userId: number;
  maturityLevel: MaturityLevel;
  aiLiteracyScore: number; // 0-100
  usageFrequency: string; // daily, weekly, monthly, occasional
  featureAdoption: {
    basicFeatures: string[]; // Features user has used
    advancedFeatures: string[];
    expertFeatures: string[];
  };
  progressionHistory: Array<{
    level: MaturityLevel;
    achievedAt: Date;
  }>;
  lastAssessed: Date;
}

export interface MaturityIndicators {
  commandComplexity: number; // 0-1, complexity of user requests
  featureUsageBreadth: number; // 0-1, variety of features used
  errorRecoveryRate: number; // 0-1, how well user handles errors
  customizationLevel: number; // 0-1, degree of personalization
  collaborationDepth: number; // 0-1, multi-step task engagement
}

// ============================================================================
// Maturity Level Definitions
// ============================================================================

const MATURITY_LEVELS: Record<MaturityLevel, {
  name: string;
  description: string;
  characteristics: string[];
  minScore: number;
  maxScore: number;
}> = {
  spark: {
    name: 'Spark (Curiosity)',
    description: 'Curious exploration, basic tasks',
    characteristics: [
      'Uses simple, single-step commands',
      'Explores basic features',
      'Occasional usage',
      'Needs guidance and examples'
    ],
    minScore: 0,
    maxScore: 20
  },
  adoption: {
    name: 'Adoption (Experimentation)',
    description: 'Intentional experimentation, building foundational skills',
    characteristics: [
      'Regular usage for specific tasks',
      'Experiments with different features',
      'Starts to build workflows',
      'Asks clarifying questions'
    ],
    minScore: 20,
    maxScore: 40
  },
  integration: {
    name: 'Integration (Operationalization)',
    description: 'Strategic integration into workflows',
    characteristics: [
      'Daily usage for core tasks',
      'Creates custom workflows',
      'Integrates with other tools',
      'Optimizes for efficiency'
    ],
    minScore: 40,
    maxScore: 60
  },
  amplification: {
    name: 'Amplification (Embedded Intelligence)',
    description: 'AI embedded in all processes, collaborative partnership',
    characteristics: [
      'AI is default tool for most tasks',
      'Uses advanced features fluently',
      'Delegates complex multi-step tasks',
      'Provides feedback for improvement'
    ],
    minScore: 60,
    maxScore: 80
  },
  transformation: {
    name: 'Transformation (Reinvention)',
    description: 'AI-driven transformation, pioneering new use cases',
    characteristics: [
      'Reimagines workflows around AI',
      'Creates novel use cases',
      'Mentors others on AI usage',
      'Pushes boundaries of what\'s possible'
    ],
    minScore: 80,
    maxScore: 100
  }
};

// ============================================================================
// Maturity Detection Service
// ============================================================================

export class MaturityDetection {
  /**
   * Assess user maturity level
   */
  async assessUser(userId: number, indicators: MaturityIndicators): Promise<UserMaturityProfile> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    // Calculate AI literacy score from indicators
    const aiLiteracyScore = this.calculateLiteracyScore(indicators);
    
    // Determine maturity level
    const maturityLevel = this.determineMaturityLevel(aiLiteracyScore);
    
    // Get existing profile
    const existing = await db.select()
      .from(userMaturity)
      .where(eq(userMaturity.userId, userId))
      .limit(1);
    
    let progressionHistory: Array<{ level: MaturityLevel; achievedAt: Date }> = [];
    
    if (existing && existing.length > 0) {
      const existingProfile = existing[0];
      progressionHistory = existingProfile.progressionHistory
        ? JSON.parse(existingProfile.progressionHistory as string)
        : [];
      
      // Check if level changed
      if (existingProfile.maturityLevel !== maturityLevel) {
        progressionHistory.push({
          level: maturityLevel,
          achievedAt: new Date()
        });
      }
    } else {
      // First assessment
      progressionHistory.push({
        level: maturityLevel,
        achievedAt: new Date()
      });
    }
    
    // Feature adoption (placeholder - would be tracked from actual usage)
    const featureAdoption = {
      basicFeatures: ['chat', 'search'],
      advancedFeatures: maturityLevel !== 'spark' ? ['workflows', 'integrations'] : [],
      expertFeatures: ['amplification', 'transformation'].includes(maturityLevel) ? ['custom_agents', 'api_access'] : []
    };
    
    // Usage frequency (placeholder - would be calculated from actual usage data)
    const usageFrequency = this.determineUsageFrequency(maturityLevel);
    
    // Update or insert
    if (existing && existing.length > 0) {
      await db.update(userMaturity)
        .set({
          maturityLevel,
          aiLiteracyScore,
          usageFrequency,
          featureAdoption: JSON.stringify(featureAdoption),
          progressionHistory: JSON.stringify(progressionHistory),
          lastAssessed: new Date(),
          updatedAt: new Date()
        })
        .where(eq(userMaturity.userId, userId));
    } else {
      await db.insert(userMaturity).values({
        userId,
        maturityLevel,
        aiLiteracyScore,
        usageFrequency,
        featureAdoption: JSON.stringify(featureAdoption),
        progressionHistory: JSON.stringify(progressionHistory),
        lastAssessed: new Date()
      });
    }
    
    return {
      userId,
      maturityLevel,
      aiLiteracyScore,
      usageFrequency,
      featureAdoption,
      progressionHistory,
      lastAssessed: new Date()
    };
  }
  
  /**
   * Get user maturity profile
   */
  async getUserProfile(userId: number): Promise<UserMaturityProfile | null> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const profiles = await db.select()
      .from(userMaturity)
      .where(eq(userMaturity.userId, userId))
      .limit(1);
    
    if (!profiles || profiles.length === 0) return null;
    
    const profile = profiles[0];
    
    return {
      userId: profile.userId,
      maturityLevel: profile.maturityLevel as MaturityLevel,
      aiLiteracyScore: profile.aiLiteracyScore,
      usageFrequency: profile.usageFrequency || 'occasional',
      featureAdoption: profile.featureAdoption ? JSON.parse(profile.featureAdoption as string) : {
        basicFeatures: [],
        advancedFeatures: [],
        expertFeatures: []
      },
      progressionHistory: profile.progressionHistory ? JSON.parse(profile.progressionHistory as string) : [],
      lastAssessed: new Date(profile.lastAssessed)
    };
  }
  
  /**
   * Get maturity level details
   */
  getMaturityLevelDetails(level: MaturityLevel) {
    return MATURITY_LEVELS[level];
  }
  
  /**
   * Get all maturity levels
   */
  getAllMaturityLevels() {
    return MATURITY_LEVELS;
  }
  
  /**
   * Get recommended features for user's maturity level
   */
  getRecommendedFeatures(maturityLevel: MaturityLevel): {
    shouldShow: string[];
    shouldHide: string[];
    shouldSuggest: string[];
  } {
    const recommendations: Record<MaturityLevel, {
      shouldShow: string[];
      shouldHide: string[];
      shouldSuggest: string[];
    }> = {
      spark: {
        shouldShow: ['basic_chat', 'simple_search', 'templates', 'tutorials'],
        shouldHide: ['api_access', 'custom_agents', 'advanced_workflows'],
        shouldSuggest: ['getting_started_guide', 'example_prompts']
      },
      adoption: {
        shouldShow: ['workflows', 'integrations', 'saved_prompts', 'history'],
        shouldHide: ['api_access', 'custom_agents'],
        shouldSuggest: ['workflow_builder', 'integration_setup']
      },
      integration: {
        shouldShow: ['advanced_workflows', 'automation', 'analytics', 'team_features'],
        shouldHide: [],
        shouldSuggest: ['optimization_tips', 'advanced_integrations']
      },
      amplification: {
        shouldShow: ['custom_agents', 'api_access', 'advanced_analytics', 'collaboration'],
        shouldHide: [],
        shouldSuggest: ['agent_customization', 'api_documentation']
      },
      transformation: {
        shouldShow: ['all_features', 'beta_features', 'developer_tools'],
        shouldHide: [],
        shouldSuggest: ['contribute_feedback', 'join_beta_program']
      }
    };
    
    return recommendations[maturityLevel];
  }
  
  /**
   * Get UI complexity level for user
   */
  getUIComplexity(maturityLevel: MaturityLevel): 'simple' | 'moderate' | 'advanced' | 'expert' {
    const complexityMap: Record<MaturityLevel, 'simple' | 'moderate' | 'advanced' | 'expert'> = {
      spark: 'simple',
      adoption: 'moderate',
      integration: 'advanced',
      amplification: 'expert',
      transformation: 'expert'
    };
    
    return complexityMap[maturityLevel];
  }
  
  // ============================================================================
  // Private Methods
  // ============================================================================
  
  private calculateLiteracyScore(indicators: MaturityIndicators): number {
    // Weighted average of indicators
    const weights = {
      commandComplexity: 0.25,
      featureUsageBreadth: 0.20,
      errorRecoveryRate: 0.15,
      customizationLevel: 0.20,
      collaborationDepth: 0.20
    };
    
    const score =
      indicators.commandComplexity * weights.commandComplexity * 100 +
      indicators.featureUsageBreadth * weights.featureUsageBreadth * 100 +
      indicators.errorRecoveryRate * weights.errorRecoveryRate * 100 +
      indicators.customizationLevel * weights.customizationLevel * 100 +
      indicators.collaborationDepth * weights.collaborationDepth * 100;
    
    return Math.round(Math.max(0, Math.min(100, score)));
  }
  
  private determineMaturityLevel(score: number): MaturityLevel {
    for (const [level, config] of Object.entries(MATURITY_LEVELS)) {
      if (score >= config.minScore && score <= config.maxScore) {
        return level as MaturityLevel;
      }
    }
    
    return 'spark'; // Default
  }
  
  private determineUsageFrequency(level: MaturityLevel): string {
    const frequencyMap: Record<MaturityLevel, string> = {
      spark: 'occasional',
      adoption: 'weekly',
      integration: 'daily',
      amplification: 'daily',
      transformation: 'daily'
    };
    
    return frequencyMap[level];
  }
}

// ============================================================================
// Export singleton instance
// ============================================================================

export const maturityDetection = new MaturityDetection();
