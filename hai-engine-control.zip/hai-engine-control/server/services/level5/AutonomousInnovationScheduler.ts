/**
 * Autonomous Innovation Scheduler
 * 
 * Self-directed AI that generates, evaluates, and implements innovations
 * without human prompting. Runs on a scheduled interval to achieve Level 5 autonomy.
 */

import { InnovationEngine } from "./InnovationEngine";
import { GoalManagement } from "./GoalManagement";
import { MultiAgentSystem } from "./MultiAgentSystem";
import { SystemMetrics } from "./observability/SystemMetrics";
import { ErrorLogging } from "./observability/ErrorLogging";

export class AutonomousInnovationScheduler {
  private innovationEngine: InnovationEngine;
  private goalManagement: GoalManagement;
  private multiAgentSystem: MultiAgentSystem;
  private systemMetrics: SystemMetrics;
  private errorLogging: ErrorLogging;
  private isRunning: boolean = false;
  private intervalId: NodeJS.Timeout | null = null;

  // Configuration
  private readonly INNOVATION_INTERVAL_MS = 6 * 60 * 60 * 1000; // 6 hours
  private readonly MIN_FEASIBILITY_THRESHOLD = 0.6; // 60%
  private readonly MIN_IMPACT_THRESHOLD = 0.5; // 50%
  private readonly AUTO_IMPLEMENT_THRESHOLD = 0.85; // 85% combined score

  constructor(userId: number) {
    this.innovationEngine = new InnovationEngine(userId);
    this.goalManagement = new GoalManagement(userId);
    this.multiAgentSystem = new MultiAgentSystem(userId);
    this.systemMetrics = new SystemMetrics(userId);
    this.errorLogging = new ErrorLogging(userId);
  }

  /**
   * Start the autonomous innovation cycle
   */
  async start(): Promise<void> {
    if (this.isRunning) {
      console.log("[AutonomousInnovation] Already running");
      return;
    }

    this.isRunning = true;
    console.log("[AutonomousInnovation] Started autonomous innovation engine");

    // Run immediately on start
    await this.runInnovationCycle();

    // Schedule recurring cycles
    this.intervalId = setInterval(async () => {
      await this.runInnovationCycle();
    }, this.INNOVATION_INTERVAL_MS);
  }

  /**
   * Stop the autonomous innovation cycle
   */
  stop(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    this.isRunning = false;
    console.log("[AutonomousInnovation] Stopped autonomous innovation engine");
  }

  /**
   * Run a complete innovation cycle
   */
  private async runInnovationCycle(): Promise<void> {
    const cycleStartTime = Date.now();
    console.log("[AutonomousInnovation] Starting innovation cycle");

    try {
      // Step 1: Analyze current state
      const context = await this.analyzeContext();

      // Step 2: Generate innovation ideas
      const ideas = await this.generateIdeas(context);
      console.log(`[AutonomousInnovation] Generated ${ideas.length} ideas`);

      // Step 3: Evaluate ideas
      const evaluatedIdeas = await this.evaluateIdeas(ideas);

      // Step 4: Select top ideas for implementation
      const selectedIdeas = this.selectTopIdeas(evaluatedIdeas);
      console.log(`[AutonomousInnovation] Selected ${selectedIdeas.length} ideas for implementation`);

      // Step 5: Implement selected ideas
      for (const idea of selectedIdeas) {
        await this.implementIdea(idea);
      }

      // Step 6: Track metrics
      const cycleDuration = Date.now() - cycleStartTime;
      await this.systemMetrics.recordMetric({
        category: "innovation",
        name: "cycle_duration_ms",
        value: cycleDuration,
        unit: "milliseconds",
      });

      await this.systemMetrics.recordMetric({
        category: "innovation",
        name: "ideas_generated",
        value: ideas.length,
        unit: "count",
      });

      await this.systemMetrics.recordMetric({
        category: "innovation",
        name: "ideas_implemented",
        value: selectedIdeas.length,
        unit: "count",
      });

      console.log(`[AutonomousInnovation] Cycle completed in ${cycleDuration}ms`);
    } catch (error) {
      console.error("[AutonomousInnovation] Error in innovation cycle:", error);
      await this.errorLogging.logError({
        category: "innovation",
        message: "Innovation cycle failed",
        severity: "high",
        context: { error: String(error) },
      });
    }
  }

  /**
   * Analyze current system context to identify innovation opportunities
   */
  private async analyzeContext(): Promise<InnovationContext> {
    // Get current goals
    const goals = await this.goalManagement.getAllGoals();
    const activeGoals = goals.filter(g => g.status === "in_progress");

    // Get agent status
    const agents = await this.multiAgentSystem.getAllAgents();
    const busyAgents = agents.filter(a => a.status === "busy");

    // Get recent metrics
    const metrics = await this.systemMetrics.getMetrics({
      category: "business",
      timeRange: "24h",
    });

    // Identify pain points
    const painPoints: string[] = [];
    
    if (activeGoals.length > 10) {
      painPoints.push("Too many active goals - need better prioritization");
    }
    
    if (busyAgents.length === agents.length) {
      painPoints.push("All agents busy - need more agents or better task distribution");
    }

    const avgEngagement = metrics.find(m => m.name === "user_engagement")?.value || 0;
    if (avgEngagement < 0.5) {
      painPoints.push("Low user engagement - need better UX or features");
    }

    return {
      goals: activeGoals,
      agents,
      metrics,
      painPoints,
      timestamp: new Date(),
    };
  }

  /**
   * Generate innovation ideas based on context
   */
  private async generateIdeas(context: InnovationContext): Promise<InnovationIdea[]> {
    const ideas: InnovationIdea[] = [];

    // Generate ideas for each pain point
    for (const painPoint of context.painPoints) {
      // Use different creativity patterns
      const patterns = ["scamper", "lateral_thinking", "analogical_transfer", "random_stimulation"];
      
      for (const pattern of patterns) {
        try {
          const idea = await this.innovationEngine.generateIdea({
            problem: painPoint,
            creativityPattern: pattern as any,
            context: {
              activeGoals: context.goals.length,
              availableAgents: context.agents.filter(a => a.status === "active").length,
            },
          });

          ideas.push({
            title: idea.title,
            description: idea.description,
            creativityPattern: pattern,
            painPoint,
            timestamp: new Date(),
          });
        } catch (error) {
          console.error(`[AutonomousInnovation] Error generating idea with ${pattern}:`, error);
        }
      }
    }

    return ideas;
  }

  /**
   * Evaluate ideas for feasibility and impact
   */
  private async evaluateIdeas(ideas: InnovationIdea[]): Promise<EvaluatedIdea[]> {
    const evaluated: EvaluatedIdea[] = [];

    for (const idea of ideas) {
      try {
        const evaluation = await this.innovationEngine.evaluateIdea({
          title: idea.title,
          description: idea.description,
        });

        evaluated.push({
          ...idea,
          feasibilityScore: evaluation.feasibilityScore,
          impactScore: evaluation.impactScore,
          combinedScore: (evaluation.feasibilityScore + evaluation.impactScore) / 2,
        });
      } catch (error) {
        console.error("[AutonomousInnovation] Error evaluating idea:", error);
      }
    }

    return evaluated;
  }

  /**
   * Select top ideas for implementation
   */
  private selectTopIdeas(ideas: EvaluatedIdea[]): EvaluatedIdea[] {
    return ideas
      .filter(idea => 
        idea.feasibilityScore >= this.MIN_FEASIBILITY_THRESHOLD &&
        idea.impactScore >= this.MIN_IMPACT_THRESHOLD
      )
      .sort((a, b) => b.combinedScore - a.combinedScore)
      .slice(0, 3); // Top 3 ideas per cycle
  }

  /**
   * Implement an innovation idea
   */
  private async implementIdea(idea: EvaluatedIdea): Promise<void> {
    console.log(`[AutonomousInnovation] Implementing: ${idea.title}`);

    try {
      // Create innovation record
      const innovation = await this.innovationEngine.createInnovation({
        title: idea.title,
        description: idea.description,
        creativityPattern: idea.creativityPattern as any,
        feasibilityScore: idea.feasibilityScore,
        impactScore: idea.impactScore,
      });

      // Auto-implement if score is high enough
      if (idea.combinedScore >= this.AUTO_IMPLEMENT_THRESHOLD) {
        console.log(`[AutonomousInnovation] Auto-implementing high-score idea: ${idea.title}`);
        
        // Create a goal for implementation
        await this.goalManagement.createGoal({
          title: `Implement: ${idea.title}`,
          description: idea.description,
          priority: "high",
          type: "innovation",
        });

        // Delegate to appropriate agent
        const agent = await this.multiAgentSystem.findBestAgent({
          taskType: "innovation_implementation",
          requiredSkills: ["problem_solving", "creativity"],
        });

        if (agent) {
          await this.multiAgentSystem.delegateTask({
            agentId: agent.id,
            task: {
              title: `Implement: ${idea.title}`,
              description: idea.description,
              priority: "high",
            },
          });
        }

        // Update innovation status
        await this.innovationEngine.updateInnovationStatus({
          innovationId: innovation.id,
          status: "implementing",
        });
      } else {
        console.log(`[AutonomousInnovation] Idea requires human approval: ${idea.title}`);
        // Leave in "evaluating" status for human review
      }
    } catch (error) {
      console.error("[AutonomousInnovation] Error implementing idea:", error);
      await this.errorLogging.logError({
        category: "innovation",
        message: `Failed to implement: ${idea.title}`,
        severity: "medium",
        context: { idea, error: String(error) },
      });
    }
  }

  /**
   * Get current status
   */
  getStatus(): {
    isRunning: boolean;
    intervalMs: number;
    nextCycleIn: number | null;
  } {
    return {
      isRunning: this.isRunning,
      intervalMs: this.INNOVATION_INTERVAL_MS,
      nextCycleIn: this.intervalId ? this.INNOVATION_INTERVAL_MS : null,
    };
  }
}

// ============================================================================
// Types
// ============================================================================

interface InnovationContext {
  goals: any[];
  agents: any[];
  metrics: any[];
  painPoints: string[];
  timestamp: Date;
}

interface InnovationIdea {
  title: string;
  description: string;
  creativityPattern: string;
  painPoint: string;
  timestamp: Date;
}

interface EvaluatedIdea extends InnovationIdea {
  feasibilityScore: number;
  impactScore: number;
  combinedScore: number;
}
