import { getDb } from '../db';
import { connectors, serviceHealthChecks } from '../../drizzle/schema';
import { eq } from 'drizzle-orm';
import { checkAllServicesForAlerts } from './downtimeAlertService';

/**
 * Service Health Check System
 * Monitors service availability and tracks uptime/response times
 */

const CHECK_TIMEOUT_MS = 10000; // 10 seconds timeout
const MAX_HISTORY_DAYS = 30; // Keep 30 days of history

/**
 * Ping a service URL and record the result
 */
export async function checkServiceHealth(connectorId: number, url: string): Promise<{
  status: 'success' | 'failure' | 'timeout';
  responseTime?: number;
  statusCode?: number;
  errorMessage?: string;
}> {
  const startTime = Date.now();

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), CHECK_TIMEOUT_MS);

    const response = await fetch(url, {
      method: 'HEAD', // Use HEAD to minimize data transfer
      signal: controller.signal,
      headers: {
        'User-Agent': 'HAI-HealthCheck/1.0',
      },
    });

    clearTimeout(timeoutId);
    const responseTime = Date.now() - startTime;

    const result = {
      status: response.ok ? ('success' as const) : ('failure' as const),
      responseTime,
      statusCode: response.status,
      errorMessage: response.ok ? undefined : `HTTP ${response.status} ${response.statusText}`,
    };

    // Record the check
    await recordHealthCheck(connectorId, result);

    return result;
  } catch (error: any) {
    const responseTime = Date.now() - startTime;

    let result;
    if (error.name === 'AbortError') {
      result = {
        status: 'timeout' as const,
        responseTime,
        errorMessage: `Request timed out after ${CHECK_TIMEOUT_MS}ms`,
      };
    } else {
      result = {
        status: 'failure' as const,
        responseTime,
        errorMessage: error.message || 'Unknown error',
      };
    }

    // Record the check
    await recordHealthCheck(connectorId, result);

    return result;
  }
}

/**
 * Record a health check result in the database
 */
async function recordHealthCheck(
  connectorId: number,
  result: {
    status: 'success' | 'failure' | 'timeout';
    responseTime?: number;
    statusCode?: number;
    errorMessage?: string;
  }
): Promise<void> {
  const db = await getDb();
  if (!db) return;

  try {
    await db.insert(serviceHealthChecks).values({
      connectorId,
      status: result.status,
      responseTime: result.responseTime,
      statusCode: result.statusCode,
      errorMessage: result.errorMessage,
    });
  } catch (error) {
    console.error('[HealthCheck] Failed to record check:', error);
  }
}

/**
 * Check all services with URLs
 */
export async function checkAllServices(): Promise<void> {
  const db = await getDb();
  if (!db) return;

  try {
    // Get all connectors with URLs
    const servicesWithUrls = await db
      .select()
      .from(connectors)
      .where(eq(connectors.url, connectors.url)); // This will get all non-null URLs

    const checks = servicesWithUrls
      .filter((service) => service.url) // Filter out null URLs
      .map((service) => checkServiceHealth(service.id, service.url!));

    await Promise.allSettled(checks); // Run all checks in parallel, don't fail if one fails

    console.log(`[HealthCheck] Checked ${checks.length} services`);

    // After health checks, check for downtime alerts
    await checkAllServicesForAlerts();
  } catch (error) {
    console.error('[HealthCheck] Failed to check services:', error);
  }
}

/**
 * Get health statistics for a service
 */
export async function getServiceHealthStats(connectorId: number): Promise<{
  uptime: number; // Percentage (0-100)
  avgResponseTime: number; // Milliseconds
  lastCheckTime: Date | null;
  lastCheckStatus: 'success' | 'failure' | 'timeout' | null;
  totalChecks: number;
  successfulChecks: number;
}> {
  const db = await getDb();
  if (!db) {
    return {
      uptime: 0,
      avgResponseTime: 0,
      lastCheckTime: null,
      lastCheckStatus: null,
      totalChecks: 0,
      successfulChecks: 0,
    };
  }

  try {
    // Get all checks for this service (last 30 days)
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - MAX_HISTORY_DAYS);

    const checks = await db
      .select()
      .from(serviceHealthChecks)
      .where(eq(serviceHealthChecks.connectorId, connectorId))
      .orderBy(serviceHealthChecks.checkTime);

    if (checks.length === 0) {
      return {
        uptime: 0,
        avgResponseTime: 0,
        lastCheckTime: null,
        lastCheckStatus: null,
        totalChecks: 0,
        successfulChecks: 0,
      };
    }

    const successfulChecks = checks.filter((c) => c.status === 'success').length;
    const uptime = (successfulChecks / checks.length) * 100;

    const responseTimes = checks
      .filter((c) => c.responseTime !== null)
      .map((c) => c.responseTime!);
    const avgResponseTime =
      responseTimes.length > 0
        ? responseTimes.reduce((a, b) => a + b, 0) / responseTimes.length
        : 0;

    const lastCheck = checks[checks.length - 1];

    return {
      uptime: Math.round(uptime * 10) / 10, // Round to 1 decimal place
      avgResponseTime: Math.round(avgResponseTime),
      lastCheckTime: lastCheck.checkTime,
      lastCheckStatus: lastCheck.status,
      totalChecks: checks.length,
      successfulChecks,
    };
  } catch (error) {
    console.error('[HealthCheck] Failed to get stats:', error);
    return {
      uptime: 0,
      avgResponseTime: 0,
      lastCheckTime: null,
      lastCheckStatus: null,
      totalChecks: 0,
      successfulChecks: 0,
    };
  }
}

/**
 * Clean up old health check records
 */
export async function cleanupOldHealthChecks(): Promise<void> {
  const db = await getDb();
  if (!db) return;

  try {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - MAX_HISTORY_DAYS);

    // Note: Drizzle doesn't have a direct "delete where date < X" syntax
    // We'll need to use raw SQL for this
    await db.execute(`
      DELETE FROM serviceHealthChecks
      WHERE checkTime < '${cutoffDate.toISOString()}'
    `);

    console.log('[HealthCheck] Cleaned up old health check records');
  } catch (error) {
    console.error('[HealthCheck] Failed to cleanup old records:', error);
  }
}

/**
 * Start periodic health checking (every 5 minutes)
 */
let healthCheckInterval: NodeJS.Timeout | null = null;

export function startHealthCheckScheduler(): void {
  if (healthCheckInterval) {
    console.log('[HealthCheck] Scheduler already running');
    return;
  }

  // OPTIMIZED: Defer initial check to reduce startup load
  setTimeout(() => {
    checkAllServices();
  }, 30 * 1000); // Wait 30 seconds after startup

  // OPTIMIZED: Run every 15 minutes (was 5 minutes) - 66% reduction
  healthCheckInterval = setInterval(() => {
    checkAllServices();
  }, 15 * 60 * 1000); // 15 minutes (was 5 minutes)

  // Cleanup old records once per day
  setInterval(() => {
    cleanupOldHealthChecks();
  }, 24 * 60 * 60 * 1000); // 24 hours

  console.log('[HealthCheck] Scheduler started (checking every 15 minutes)');
}

export function stopHealthCheckScheduler(): void {
  if (healthCheckInterval) {
    clearInterval(healthCheckInterval);
    healthCheckInterval = null;
    console.log('[HealthCheck] Scheduler stopped');
  }
}
