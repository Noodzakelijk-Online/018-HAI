/**
 * IP-Based Access Control
 * Implements P2 #63: Add IP-based access control
 */

export interface IPRule {
  id: string;
  type: 'allow' | 'deny';
  ip: string;
  cidr?: number;
  description?: string;
  createdAt: Date;
  expiresAt?: Date;
}

export interface IPAccessConfig {
  defaultPolicy: 'allow' | 'deny';
  rules: IPRule[];
  enableLogging?: boolean;
  trustProxy?: boolean;
}

const DEFAULT_CONFIG: IPAccessConfig = {
  defaultPolicy: 'allow',
  rules: [],
  enableLogging: true,
  trustProxy: true,
};

let config: IPAccessConfig = { ...DEFAULT_CONFIG };

/**
 * Parse IP address to numeric value
 */
function ipToNumber(ip: string): number {
  const parts = ip.split('.').map(Number);
  return (parts[0] << 24) + (parts[1] << 16) + (parts[2] << 8) + parts[3];
}

/**
 * Check if IP matches a rule
 */
function ipMatchesRule(ip: string, rule: IPRule): boolean {
  // Handle IPv6 localhost
  if (ip === '::1' || ip === '::ffff:127.0.0.1') {
    ip = '127.0.0.1';
  }
  
  // Remove IPv6 prefix if present
  if (ip.startsWith('::ffff:')) {
    ip = ip.slice(7);
  }
  
  // Exact match
  if (rule.ip === ip) return true;
  
  // CIDR match
  if (rule.cidr !== undefined) {
    const ruleIpNum = ipToNumber(rule.ip);
    const requestIpNum = ipToNumber(ip);
    const mask = ~((1 << (32 - rule.cidr)) - 1);
    
    return (ruleIpNum & mask) === (requestIpNum & mask);
  }
  
  // Wildcard match (e.g., 192.168.*.*)
  if (rule.ip.includes('*')) {
    const regex = new RegExp('^' + rule.ip.replace(/\./g, '\\.').replace(/\*/g, '\\d+') + '$');
    return regex.test(ip);
  }
  
  return false;
}

/**
 * Check if IP is allowed
 */
export function isIPAllowed(ip: string): { allowed: boolean; matchedRule?: IPRule } {
  // Check rules in order
  for (const rule of config.rules) {
    // Skip expired rules
    if (rule.expiresAt && rule.expiresAt < new Date()) continue;
    
    if (ipMatchesRule(ip, rule)) {
      return {
        allowed: rule.type === 'allow',
        matchedRule: rule,
      };
    }
  }
  
  // Default policy
  return { allowed: config.defaultPolicy === 'allow' };
}

/**
 * Add an IP rule
 */
export function addIPRule(rule: Omit<IPRule, 'id' | 'createdAt'>): IPRule {
  const newRule: IPRule = {
    ...rule,
    id: `ip_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    createdAt: new Date(),
  };
  
  config.rules.push(newRule);
  return newRule;
}

/**
 * Remove an IP rule
 */
export function removeIPRule(ruleId: string): boolean {
  const index = config.rules.findIndex(r => r.id === ruleId);
  if (index === -1) return false;
  
  config.rules.splice(index, 1);
  return true;
}

/**
 * Get all rules
 */
export function getIPRules(): IPRule[] {
  return [...config.rules];
}

/**
 * Update configuration
 */
export function updateIPConfig(updates: Partial<IPAccessConfig>): void {
  config = { ...config, ...updates };
}

/**
 * Get current configuration
 */
export function getIPConfig(): IPAccessConfig {
  return { ...config };
}

/**
 * IP access control middleware
 */
export function ipAccessMiddleware(options: Partial<IPAccessConfig> = {}) {
  const opts = { ...DEFAULT_CONFIG, ...options };
  
  return (req: any, res: any, next: any) => {
    let ip = req.ip;
    
    // Trust proxy headers
    if (opts.trustProxy) {
      ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || 
           req.headers['x-real-ip'] || 
           req.ip;
    }
    
    const result = isIPAllowed(ip);
    
    if (opts.enableLogging) {
      console.log('[IPAccess]', {
        ip,
        allowed: result.allowed,
        rule: result.matchedRule?.id,
        path: req.path,
      });
    }
    
    if (!result.allowed) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Your IP address is not allowed to access this resource',
      });
    }
    
    // Store IP info in request
    req.clientIP = ip;
    req.ipAccessRule = result.matchedRule;
    
    next();
  };
}

/**
 * Admin-only IP restriction
 */
export function adminIPMiddleware(allowedIPs: string[]) {
  // Add allowed IPs as rules
  for (const ip of allowedIPs) {
    addIPRule({
      type: 'allow',
      ip,
      description: 'Admin IP',
    });
  }
  
  return ipAccessMiddleware({ defaultPolicy: 'deny' });
}

/**
 * Temporary IP ban
 */
export function banIP(ip: string, durationMinutes: number, reason?: string): IPRule {
  return addIPRule({
    type: 'deny',
    ip,
    description: reason || 'Temporary ban',
    expiresAt: new Date(Date.now() + durationMinutes * 60 * 1000),
  });
}

/**
 * Whitelist an IP
 */
export function whitelistIP(ip: string, description?: string): IPRule {
  return addIPRule({
    type: 'allow',
    ip,
    description: description || 'Whitelisted',
  });
}

/**
 * Blacklist an IP
 */
export function blacklistIP(ip: string, description?: string): IPRule {
  return addIPRule({
    type: 'deny',
    ip,
    description: description || 'Blacklisted',
  });
}

/**
 * Clean up expired rules
 */
export function cleanupExpiredRules(): number {
  const now = new Date();
  const before = config.rules.length;
  
  config.rules = config.rules.filter(rule => 
    !rule.expiresAt || rule.expiresAt > now
  );
  
  return before - config.rules.length;
}

/**
 * Get IP access statistics
 */
export function getIPStats(): {
  totalRules: number;
  allowRules: number;
  denyRules: number;
  expiredRules: number;
} {
  const now = new Date();
  const expired = config.rules.filter(r => r.expiresAt && r.expiresAt < now).length;
  
  return {
    totalRules: config.rules.length,
    allowRules: config.rules.filter(r => r.type === 'allow').length,
    denyRules: config.rules.filter(r => r.type === 'deny').length,
    expiredRules: expired,
  };
}

export default {
  isIPAllowed,
  addIPRule,
  removeIPRule,
  getIPRules,
  updateIPConfig,
  getIPConfig,
  ipAccessMiddleware,
  adminIPMiddleware,
  banIP,
  whitelistIP,
  blacklistIP,
  cleanupExpiredRules,
  getIPStats,
};
