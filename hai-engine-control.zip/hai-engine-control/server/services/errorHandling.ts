/**
 * Error Handling Utilities
 * Implements P0 #41: Add try-catch to critical async operations
 * Implements P1 #42: Circuit breaker for external APIs
 * Implements P1 #43: Retry logic with exponential backoff
 */

import { createLogger } from './logger';

const logger = createLogger('ErrorHandling');

// ============================================================================
// Custom Error Types (#12)
// ============================================================================

export class HAIError extends Error {
  constructor(
    message: string,
    public code: string,
    public statusCode: number = 500,
    public details?: Record<string, unknown>
  ) {
    super(message);
    this.name = 'HAIError';
  }
}

export class ValidationError extends HAIError {
  constructor(message: string, details?: Record<string, unknown>) {
    super(message, 'VALIDATION_ERROR', 400, details);
    this.name = 'ValidationError';
  }
}

export class AuthenticationError extends HAIError {
  constructor(message: string = 'Authentication required') {
    super(message, 'AUTH_ERROR', 401);
    this.name = 'AuthenticationError';
  }
}

export class AuthorizationError extends HAIError {
  constructor(message: string = 'Permission denied') {
    super(message, 'FORBIDDEN', 403);
    this.name = 'AuthorizationError';
  }
}

export class NotFoundError extends HAIError {
  constructor(resource: string, id?: string | number) {
    super(`${resource}${id ? ` with ID ${id}` : ''} not found`, 'NOT_FOUND', 404);
    this.name = 'NotFoundError';
  }
}

export class ConflictError extends HAIError {
  constructor(message: string) {
    super(message, 'CONFLICT', 409);
    this.name = 'ConflictError';
  }
}

export class RateLimitError extends HAIError {
  constructor(retryAfter?: number) {
    super('Rate limit exceeded', 'RATE_LIMIT', 429, { retryAfter });
    this.name = 'RateLimitError';
  }
}

export class ExternalServiceError extends HAIError {
  constructor(service: string, originalError?: Error) {
    super(`External service error: ${service}`, 'EXTERNAL_ERROR', 502, {
      service,
      originalMessage: originalError?.message,
    });
    this.name = 'ExternalServiceError';
  }
}

// ============================================================================
// Safe Async Wrapper (#41)
// ============================================================================

export type AsyncResult<T> = { success: true; data: T } | { success: false; error: Error };

/**
 * Wrap an async function to catch errors safely
 */
export async function safeAsync<T>(
  operation: () => Promise<T>,
  context?: string
): Promise<AsyncResult<T>> {
  try {
    const data = await operation();
    return { success: true, data };
  } catch (error) {
    const err = error instanceof Error ? error : new Error(String(error));
    if (context) {
      logger.error(`Error in ${context}`, err);
    }
    return { success: false, error: err };
  }
}

/**
 * Wrap an async function with automatic error logging
 */
export function withErrorLogging<T extends (...args: any[]) => Promise<any>>(
  fn: T,
  context: string
): T {
  return (async (...args: Parameters<T>) => {
    try {
      return await fn(...args);
    } catch (error) {
      logger.error(`Error in ${context}`, error instanceof Error ? error : new Error(String(error)), {
        args: args.map(a => typeof a === 'object' ? '[object]' : String(a)),
      });
      throw error;
    }
  }) as T;
}

// ============================================================================
// Retry Logic (#43)
// ============================================================================

export interface RetryConfig {
  maxRetries: number;
  baseDelayMs: number;
  maxDelayMs: number;
  exponentialBase: number;
  retryOn?: (error: Error) => boolean;
}

const DEFAULT_RETRY_CONFIG: RetryConfig = {
  maxRetries: 3,
  baseDelayMs: 100,
  maxDelayMs: 10000,
  exponentialBase: 2,
};

/**
 * Execute an operation with exponential backoff retry
 */
export async function withRetry<T>(
  operation: () => Promise<T>,
  config: Partial<RetryConfig> = {},
  context?: string
): Promise<T> {
  const cfg = { ...DEFAULT_RETRY_CONFIG, ...config };
  let lastError: Error | null = null;
  
  for (let attempt = 0; attempt <= cfg.maxRetries; attempt++) {
    try {
      return await operation();
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      
      // Check if we should retry this error
      if (cfg.retryOn && !cfg.retryOn(lastError)) {
        throw lastError;
      }
      
      if (attempt < cfg.maxRetries) {
        // Calculate delay with jitter
        const delay = Math.min(
          cfg.baseDelayMs * Math.pow(cfg.exponentialBase, attempt) + Math.random() * 100,
          cfg.maxDelayMs
        );
        
        logger.warn(`${context || 'Operation'} failed, retrying in ${Math.round(delay)}ms`, {
          attempt: attempt + 1,
          maxRetries: cfg.maxRetries,
          error: lastError.message,
        });
        
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }
  
  throw lastError;
}

// ============================================================================
// Circuit Breaker (#42)
// ============================================================================

export interface CircuitBreakerConfig {
  failureThreshold: number;    // Number of failures before opening
  successThreshold: number;    // Number of successes to close from half-open
  timeout: number;             // Time in ms before trying again (half-open)
  monitoringPeriod: number;    // Time window for counting failures
}

type CircuitState = 'closed' | 'open' | 'half-open';

interface CircuitStats {
  failures: number;
  successes: number;
  lastFailure: number;
  state: CircuitState;
}

const DEFAULT_CIRCUIT_CONFIG: CircuitBreakerConfig = {
  failureThreshold: 5,
  successThreshold: 2,
  timeout: 30000,
  monitoringPeriod: 60000,
};

const circuits = new Map<string, CircuitStats>();

/**
 * Get or create circuit stats
 */
function getCircuit(name: string): CircuitStats {
  if (!circuits.has(name)) {
    circuits.set(name, {
      failures: 0,
      successes: 0,
      lastFailure: 0,
      state: 'closed',
    });
  }
  return circuits.get(name)!;
}

/**
 * Execute an operation with circuit breaker protection
 */
export async function withCircuitBreaker<T>(
  name: string,
  operation: () => Promise<T>,
  config: Partial<CircuitBreakerConfig> = {}
): Promise<T> {
  const cfg = { ...DEFAULT_CIRCUIT_CONFIG, ...config };
  const circuit = getCircuit(name);
  const now = Date.now();
  
  // Check circuit state
  if (circuit.state === 'open') {
    // Check if timeout has passed
    if (now - circuit.lastFailure >= cfg.timeout) {
      circuit.state = 'half-open';
      circuit.successes = 0;
      logger.info(`Circuit ${name} transitioning to half-open`);
    } else {
      throw new ExternalServiceError(name, new Error('Circuit breaker is open'));
    }
  }
  
  try {
    const result = await operation();
    
    // Success handling
    if (circuit.state === 'half-open') {
      circuit.successes++;
      if (circuit.successes >= cfg.successThreshold) {
        circuit.state = 'closed';
        circuit.failures = 0;
        logger.info(`Circuit ${name} closed after successful recovery`);
      }
    } else {
      // Reset failures on success in closed state
      circuit.failures = 0;
    }
    
    return result;
  } catch (error) {
    // Failure handling
    circuit.failures++;
    circuit.lastFailure = now;
    
    if (circuit.state === 'half-open') {
      circuit.state = 'open';
      logger.warn(`Circuit ${name} reopened after failure in half-open state`);
    } else if (circuit.failures >= cfg.failureThreshold) {
      circuit.state = 'open';
      logger.warn(`Circuit ${name} opened after ${circuit.failures} failures`);
    }
    
    throw error;
  }
}

/**
 * Get circuit breaker status
 */
export function getCircuitStatus(name: string): CircuitStats | null {
  return circuits.get(name) || null;
}

/**
 * Reset a circuit breaker
 */
export function resetCircuit(name: string): void {
  circuits.delete(name);
}

// ============================================================================
// Timeout Wrapper (#45)
// ============================================================================

/**
 * Execute an operation with a timeout
 */
export async function withTimeout<T>(
  operation: () => Promise<T>,
  timeoutMs: number,
  context?: string
): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new HAIError(
        `${context || 'Operation'} timed out after ${timeoutMs}ms`,
        'TIMEOUT',
        408
      ));
    }, timeoutMs);
    
    operation()
      .then(result => {
        clearTimeout(timer);
        resolve(result);
      })
      .catch(error => {
        clearTimeout(timer);
        reject(error);
      });
  });
}

// ============================================================================
// Combined Utilities
// ============================================================================

/**
 * Execute an operation with retry, circuit breaker, and timeout
 */
export async function resilientCall<T>(
  name: string,
  operation: () => Promise<T>,
  options: {
    timeout?: number;
    retry?: Partial<RetryConfig>;
    circuitBreaker?: Partial<CircuitBreakerConfig>;
  } = {}
): Promise<T> {
  const wrappedOperation = async () => {
    let op = operation;
    
    // Apply timeout if specified
    if (options.timeout) {
      const originalOp = op;
      op = () => withTimeout(originalOp, options.timeout!, name);
    }
    
    // Apply retry if specified
    if (options.retry) {
      const originalOp = op;
      op = () => withRetry(originalOp, options.retry, name);
    }
    
    return op();
  };
  
  // Apply circuit breaker
  return withCircuitBreaker(name, wrappedOperation, options.circuitBreaker);
}

export default {
  // Errors
  HAIError,
  ValidationError,
  AuthenticationError,
  AuthorizationError,
  NotFoundError,
  ConflictError,
  RateLimitError,
  ExternalServiceError,
  // Utilities
  safeAsync,
  withErrorLogging,
  withRetry,
  withCircuitBreaker,
  withTimeout,
  resilientCall,
  getCircuitStatus,
  resetCircuit,
};
