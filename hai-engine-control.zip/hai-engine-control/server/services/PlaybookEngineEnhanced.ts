import { EventBus } from './EventBus';

/**
 * Enhanced Playbook Engine - Peak Performance
 * 
 * Features:
 * - Visual workflow designer (node-based drag-drop)
 * - Advanced error handling with retry strategies
 * - Workflow versioning and rollback
 * - Human-in-the-loop approvals
 * - Parallel execution with fan-out/fan-in
 * - Workflow templates marketplace
 * - Real-time execution monitoring
 * - Workflow analytics and optimization
 */

export interface WorkflowNode {
  id: string;
  type: 'start' | 'action' | 'decision' | 'parallel' | 'approval' | 'end';
  label: string;
  config: Record<string, any>;
  position: { x: number; y: number };
  connections: Array<{
    targetId: string;
    condition?: string; // For decision nodes
    label?: string;
  }>;
}

export interface VisualWorkflow {
  id: string;
  name: string;
  description?: string;
  nodes: WorkflowNode[];
  variables: Record<string, any>;
  version: number;
  status: 'draft' | 'published' | 'archived';
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface ErrorHandlingStrategy {
  nodeId: string;
  strategy: 'retry' | 'skip' | 'fallback' | 'abort';
  retryConfig?: {
    maxAttempts: number;
    backoffType: 'fixed' | 'exponential' | 'linear';
    initialDelay: number; // milliseconds
    maxDelay?: number;
  };
  fallbackAction?: string;
  onError?: string; // Node ID to jump to on error
}

export interface WorkflowVersion {
  id: string;
  workflowId: string;
  version: number;
  snapshot: VisualWorkflow;
  changes: string;
  createdBy: string;
  createdAt: Date;
  isActive: boolean;
}

export interface ApprovalRequest {
  id: string;
  workflowExecutionId: string;
  nodeId: string;
  requestedBy: string;
  approvers: string[];
  message: string;
  context: Record<string, any>;
  status: 'pending' | 'approved' | 'rejected' | 'expired';
  responses: Array<{
    approverId: string;
    decision: 'approve' | 'reject';
    comment?: string;
    timestamp: Date;
  }>;
  expiresAt?: Date;
  createdAt: Date;
}

export interface ParallelExecution {
  id: string;
  workflowExecutionId: string;
  parentNodeId: string;
  branches: Array<{
    branchId: string;
    nodeIds: string[];
    status: 'pending' | 'running' | 'completed' | 'failed';
    startedAt?: Date;
    completedAt?: Date;
    result?: any;
    error?: string;
  }>;
  fanInNodeId: string; // Where branches merge
  strategy: 'wait_all' | 'wait_any' | 'wait_majority';
  status: 'pending' | 'running' | 'completed' | 'failed';
}

export interface WorkflowTemplate {
  id: string;
  name: string;
  category: string;
  description: string;
  workflow: VisualWorkflow;
  tags: string[];
  author: string;
  downloads: number;
  rating: number;
  reviews: Array<{
    userId: string;
    rating: number;
    comment: string;
    timestamp: Date;
  }>;
  isPremium: boolean;
  price?: number;
}

export interface ExecutionMonitor {
  executionId: string;
  workflowId: string;
  status: 'running' | 'paused' | 'completed' | 'failed' | 'cancelled';
  currentNode: string;
  progress: number; // 0-100
  startedAt: Date;
  estimatedCompletion?: Date;
  metrics: {
    nodesExecuted: number;
    nodesTotal: number;
    errorsCount: number;
    retriesCount: number;
    approvalsCount: number;
  };
  realTimeUpdates: Array<{
    timestamp: Date;
    nodeId: string;
    event: 'started' | 'completed' | 'failed' | 'waiting_approval';
    data?: any;
  }>;
}

export interface WorkflowAnalytics {
  workflowId: string;
  period: { start: Date; end: Date };
  executions: {
    total: number;
    successful: number;
    failed: number;
    cancelled: number;
  };
  performance: {
    averageDuration: number; // milliseconds
    medianDuration: number;
    p95Duration: number;
    fastestExecution: number;
    slowestExecution: number;
  };
  bottlenecks: Array<{
    nodeId: string;
    nodeName: string;
    averageDuration: number;
    failureRate: number;
  }>;
  errorAnalysis: Record<string, number>; // error type -> count
  recommendations: string[];
}

export class PlaybookEngineEnhanced {
  private eventBus: typeof EventBus;
  private workflows: Map<string, VisualWorkflow> = new Map();
  private versions: Map<string, WorkflowVersion[]> = new Map();
  private approvals: Map<string, ApprovalRequest> = new Map();
  private parallelExecutions: Map<string, ParallelExecution> = new Map();
  private templates: Map<string, WorkflowTemplate> = new Map();
  private monitors: Map<string, ExecutionMonitor> = new Map();
  private errorStrategies: Map<string, ErrorHandlingStrategy[]> = new Map();

  constructor(eventBus: typeof EventBus) {
    this.eventBus = eventBus;
  }

  /**
   * Create visual workflow
   */
  async createVisualWorkflow(workflow: Omit<VisualWorkflow, 'id' | 'version' | 'createdAt' | 'updatedAt'>): Promise<VisualWorkflow> {
    const newWorkflow: VisualWorkflow = {
      ...workflow,
      id: `wf_${Date.now()}`,
      version: 1,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    this.workflows.set(newWorkflow.id, newWorkflow);

    await this.eventBus.publish({
      type: 'playbook.workflow.created',
      source: 'PlaybookEngine',
      target: 'system',
      data: { workflowId: newWorkflow.id, nodesCount: newWorkflow.nodes.length },
    });

    return newWorkflow;
  }

  /**
   * Validate workflow structure
   */
  async validateWorkflow(workflowId: string): Promise<{ valid: boolean; errors: string[] }> {
    const workflow = this.workflows.get(workflowId);
    if (!workflow) {
      return { valid: false, errors: ['Workflow not found'] };
    }

    const errors: string[] = [];

    // Check for start node
    const startNodes = workflow.nodes.filter(n => n.type === 'start');
    if (startNodes.length === 0) {
      errors.push('Workflow must have a start node');
    } else if (startNodes.length > 1) {
      errors.push('Workflow can only have one start node');
    }

    // Check for end node
    const endNodes = workflow.nodes.filter(n => n.type === 'end');
    if (endNodes.length === 0) {
      errors.push('Workflow must have at least one end node');
    }

    // Check for orphaned nodes
    const nodeIds = new Set(workflow.nodes.map(n => n.id));
    const connectedNodes = new Set<string>();
    
    workflow.nodes.forEach(node => {
      node.connections.forEach(conn => {
        if (!nodeIds.has(conn.targetId)) {
          errors.push(`Node ${node.id} connects to non-existent node ${conn.targetId}`);
        }
        connectedNodes.add(conn.targetId);
      });
    });

    // Check for unreachable nodes (except start)
    workflow.nodes.forEach(node => {
      if (node.type !== 'start' && !connectedNodes.has(node.id)) {
        errors.push(`Node ${node.id} is unreachable`);
      }
    });

    return { valid: errors.length === 0, errors };
  }

  /**
   * Add error handling strategy
   */
  async addErrorHandling(workflowId: string, strategy: ErrorHandlingStrategy): Promise<void> {
    if (!this.errorStrategies.has(workflowId)) {
      this.errorStrategies.set(workflowId, []);
    }

    this.errorStrategies.get(workflowId)!.push(strategy);

    await this.eventBus.publish({
      type: 'playbook.error_handling.added',
      source: 'PlaybookEngine',
      target: 'system',
      data: { workflowId, nodeId: strategy.nodeId, strategy: strategy.strategy },
    });
  }

  /**
   * Execute node with error handling
   */
  async executeNodeWithErrorHandling(
    workflowId: string,
    nodeId: string,
    action: () => Promise<any>
  ): Promise<{ success: boolean; result?: any; error?: string }> {
    const strategies = this.errorStrategies.get(workflowId) || [];
    const nodeStrategy = strategies.find(s => s.nodeId === nodeId);

    if (!nodeStrategy) {
      // No error handling, execute directly
      try {
        const result = await action();
        return { success: true, result };
      } catch (error) {
        return { success: false, error: String(error) };
      }
    }

    // Apply error handling strategy
    if (nodeStrategy.strategy === 'retry' && nodeStrategy.retryConfig) {
      return await this.retryWithBackoff(action, nodeStrategy.retryConfig);
    } else if (nodeStrategy.strategy === 'skip') {
      try {
        const result = await action();
        return { success: true, result };
      } catch (error) {
        return { success: true, result: null }; // Skip error
      }
    } else if (nodeStrategy.strategy === 'fallback' && nodeStrategy.fallbackAction) {
      try {
        const result = await action();
        return { success: true, result };
      } catch (error) {
        // Execute fallback
        return { success: true, result: { fallback: nodeStrategy.fallbackAction } };
      }
    }

    // Default: abort on error
    try {
      const result = await action();
      return { success: true, result };
    } catch (error) {
      return { success: false, error: String(error) };
    }
  }

  private async retryWithBackoff(
    action: () => Promise<any>,
    config: NonNullable<ErrorHandlingStrategy['retryConfig']>
  ): Promise<{ success: boolean; result?: any; error?: string }> {
    let lastError: any;

    for (let attempt = 0; attempt < config.maxAttempts; attempt++) {
      try {
        const result = await action();
        return { success: true, result };
      } catch (error) {
        lastError = error;

        if (attempt < config.maxAttempts - 1) {
          // Calculate delay
          let delay = config.initialDelay;
          
          if (config.backoffType === 'exponential') {
            delay = config.initialDelay * Math.pow(2, attempt);
          } else if (config.backoffType === 'linear') {
            delay = config.initialDelay * (attempt + 1);
          }

          if (config.maxDelay) {
            delay = Math.min(delay, config.maxDelay);
          }

          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
    }

    return { success: false, error: String(lastError) };
  }

  /**
   * Create workflow version
   */
  async createVersion(workflowId: string, changes: string, createdBy: string): Promise<WorkflowVersion> {
    const workflow = this.workflows.get(workflowId);
    if (!workflow) {
      throw new Error('Workflow not found');
    }

    const existingVersions = this.versions.get(workflowId) || [];
    
    // Deactivate previous versions
    existingVersions.forEach(v => v.isActive = false);

    const version: WorkflowVersion = {
      id: `ver_${Date.now()}`,
      workflowId,
      version: existingVersions.length + 1,
      snapshot: JSON.parse(JSON.stringify(workflow)), // Deep copy
      changes,
      createdBy,
      createdAt: new Date(),
      isActive: true,
    };

    if (!this.versions.has(workflowId)) {
      this.versions.set(workflowId, []);
    }
    this.versions.get(workflowId)!.push(version);

    workflow.version = version.version;

    await this.eventBus.publish({
      type: 'playbook.version.created',
      source: 'PlaybookEngine',
      target: 'system',
      data: { workflowId, version: version.version },
    });

    return version;
  }

  /**
   * Rollback to previous version
   */
  async rollbackVersion(workflowId: string, targetVersion: number): Promise<VisualWorkflow> {
    const versions = this.versions.get(workflowId) || [];
    const targetVer = versions.find(v => v.version === targetVersion);

    if (!targetVer) {
      throw new Error(`Version ${targetVersion} not found`);
    }

    // Restore workflow from snapshot
    const restoredWorkflow = JSON.parse(JSON.stringify(targetVer.snapshot));
    restoredWorkflow.updatedAt = new Date();
    
    this.workflows.set(workflowId, restoredWorkflow);

    // Mark version as active
    versions.forEach(v => v.isActive = v.version === targetVersion);

    await this.eventBus.publish({
      type: 'playbook.version.rolled_back',
      source: 'PlaybookEngine',
      target: 'system',
      data: { workflowId, targetVersion },
    });

    return restoredWorkflow;
  }

  /**
   * Request approval
   */
  async requestApproval(request: Omit<ApprovalRequest, 'id' | 'status' | 'responses' | 'createdAt'>): Promise<ApprovalRequest> {
    const newRequest: ApprovalRequest = {
      ...request,
      id: `appr_${Date.now()}`,
      status: 'pending',
      responses: [],
      createdAt: new Date(),
    };

    this.approvals.set(newRequest.id, newRequest);

    await this.eventBus.publish({
      type: 'playbook.approval.requested',
      source: 'PlaybookEngine',
      target: 'system',
      data: { approvalId: newRequest.id, approversCount: newRequest.approvers.length },
    });

    return newRequest;
  }

  /**
   * Submit approval response
   */
  async submitApproval(
    approvalId: string,
    approverId: string,
    decision: 'approve' | 'reject',
    comment?: string
  ): Promise<ApprovalRequest> {
    const approval = this.approvals.get(approvalId);
    if (!approval) {
      throw new Error('Approval request not found');
    }

    if (approval.status !== 'pending') {
      throw new Error('Approval request is no longer pending');
    }

    if (!approval.approvers.includes(approverId)) {
      throw new Error('User is not an approver');
    }

    approval.responses.push({
      approverId,
      decision,
      comment,
      timestamp: new Date(),
    });

    // Check if all approvers have responded
    if (approval.responses.length === approval.approvers.length) {
      const allApproved = approval.responses.every(r => r.decision === 'approve');
      approval.status = allApproved ? 'approved' : 'rejected';
    }

    await this.eventBus.publish({
      type: 'playbook.approval.submitted',
      source: 'PlaybookEngine',
      target: 'system',
      data: { approvalId, decision, status: approval.status },
    });

    return approval;
  }

  /**
   * Execute parallel branches
   */
  async executeParallel(
    workflowExecutionId: string,
    parentNodeId: string,
    branches: Array<{ branchId: string; nodeIds: string[] }>,
    fanInNodeId: string,
    strategy: ParallelExecution['strategy']
  ): Promise<ParallelExecution> {
    const parallel: ParallelExecution = {
      id: `par_${Date.now()}`,
      workflowExecutionId,
      parentNodeId,
      branches: branches.map(b => ({
        ...b,
        status: 'pending',
      })),
      fanInNodeId,
      strategy,
      status: 'running',
    };

    this.parallelExecutions.set(parallel.id, parallel);

    // Execute branches in parallel
    const branchPromises = parallel.branches.map(async (branch) => {
      branch.status = 'running';
      branch.startedAt = new Date();

      try {
        // Simulate branch execution
        await new Promise(resolve => setTimeout(resolve, Math.random() * 2000));
        branch.result = { success: true };
        branch.status = 'completed';
        branch.completedAt = new Date();
      } catch (error) {
        branch.error = String(error);
        branch.status = 'failed';
        branch.completedAt = new Date();
      }
    });

    // Wait based on strategy
    if (strategy === 'wait_all') {
      await Promise.all(branchPromises);
    } else if (strategy === 'wait_any') {
      await Promise.race(branchPromises);
    } else if (strategy === 'wait_majority') {
      const majority = Math.ceil(branches.length / 2);
      let completed = 0;
      await new Promise<void>(resolve => {
        branchPromises.forEach(p => p.then(() => {
          completed++;
          if (completed >= majority) resolve();
        }));
      });
    }

    parallel.status = 'completed';

    await this.eventBus.publish({
      type: 'playbook.parallel.completed',
      source: 'PlaybookEngine',
      target: 'system',
      data: { parallelId: parallel.id, branchesCount: branches.length },
    });

    return parallel;
  }

  /**
   * Create workflow template
   */
  async createTemplate(template: Omit<WorkflowTemplate, 'id' | 'downloads' | 'rating' | 'reviews'>): Promise<WorkflowTemplate> {
    const newTemplate: WorkflowTemplate = {
      ...template,
      id: `tmpl_${Date.now()}`,
      downloads: 0,
      rating: 0,
      reviews: [],
    };

    this.templates.set(newTemplate.id, newTemplate);

    return newTemplate;
  }

  /**
   * Start execution monitoring
   */
  async startMonitoring(executionId: string, workflowId: string): Promise<ExecutionMonitor> {
    const workflow = this.workflows.get(workflowId);
    if (!workflow) {
      throw new Error('Workflow not found');
    }

    const monitor: ExecutionMonitor = {
      executionId,
      workflowId,
      status: 'running',
      currentNode: workflow.nodes.find(n => n.type === 'start')?.id || '',
      progress: 0,
      startedAt: new Date(),
      metrics: {
        nodesExecuted: 0,
        nodesTotal: workflow.nodes.length,
        errorsCount: 0,
        retriesCount: 0,
        approvalsCount: 0,
      },
      realTimeUpdates: [],
    };

    this.monitors.set(executionId, monitor);

    return monitor;
  }

  /**
   * Update execution monitor
   */
  async updateMonitor(
    executionId: string,
    update: {
      currentNode?: string;
      event?: ExecutionMonitor['realTimeUpdates'][0];
      incrementErrors?: boolean;
      incrementRetries?: boolean;
      incrementApprovals?: boolean;
    }
  ): Promise<void> {
    const monitor = this.monitors.get(executionId);
    if (!monitor) return;

    if (update.currentNode) {
      monitor.currentNode = update.currentNode;
      monitor.metrics.nodesExecuted++;
      monitor.progress = (monitor.metrics.nodesExecuted / monitor.metrics.nodesTotal) * 100;
    }

    if (update.event) {
      monitor.realTimeUpdates.push(update.event);
    }

    if (update.incrementErrors) monitor.metrics.errorsCount++;
    if (update.incrementRetries) monitor.metrics.retriesCount++;
    if (update.incrementApprovals) monitor.metrics.approvalsCount++;

    await this.eventBus.publish({
      type: 'playbook.monitor.updated',
      source: 'PlaybookEngine',
      target: 'system',
      data: { executionId, progress: monitor.progress },
    });
  }

  /**
   * Generate workflow analytics
   */
  async generateAnalytics(workflowId: string, period: { start: Date; end: Date }): Promise<WorkflowAnalytics> {
    // Mock analytics data
    const analytics: WorkflowAnalytics = {
      workflowId,
      period,
      executions: {
        total: 100,
        successful: 85,
        failed: 10,
        cancelled: 5,
      },
      performance: {
        averageDuration: 45000, // 45 seconds
        medianDuration: 40000,
        p95Duration: 90000,
        fastestExecution: 20000,
        slowestExecution: 180000,
      },
      bottlenecks: [
        {
          nodeId: 'node_123',
          nodeName: 'API Call',
          averageDuration: 15000,
          failureRate: 0.05,
        },
      ],
      errorAnalysis: {
        'timeout': 5,
        'validation_error': 3,
        'network_error': 2,
      },
      recommendations: [
        'Add timeout to API Call node',
        'Implement retry logic for network errors',
        'Consider parallel execution for independent tasks',
      ],
    };

    await this.eventBus.publish({
      type: 'playbook.analytics.generated',
      source: 'PlaybookEngine',
      target: 'system',
      data: { workflowId, successRate: analytics.executions.successful / analytics.executions.total },
    });

    return analytics;
  }

  /**
   * Get workflow versions
   */
  getVersions(workflowId: string): WorkflowVersion[] {
    return this.versions.get(workflowId) || [];
  }

  /**
   * Get pending approvals
   */
  getPendingApprovals(approverId?: string): ApprovalRequest[] {
    const pending = Array.from(this.approvals.values()).filter(a => a.status === 'pending');
    return approverId ? pending.filter(a => a.approvers.includes(approverId)) : pending;
  }

  /**
   * Get templates
   */
  getTemplates(category?: string): WorkflowTemplate[] {
    const templates = Array.from(this.templates.values());
    return category ? templates.filter(t => t.category === category) : templates;
  }

  /**
   * Get execution monitor
   */
  getMonitor(executionId: string): ExecutionMonitor | undefined {
    return this.monitors.get(executionId);
  }
}
