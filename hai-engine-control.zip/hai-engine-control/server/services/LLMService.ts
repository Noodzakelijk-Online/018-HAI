import { invokeLLM } from "../_core/llm";
import { EventBus } from "./EventBus";

/**
 * Message format for LLM conversations
 */
export interface LLMMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

/**
 * LLM reasoning result
 */
export interface ReasoningResult {
  response: string;
  confidence: number;
  reasoning: string;
  suggestedActions?: Array<{
    type: string;
    description: string;
    priority: "low" | "medium" | "high";
  }>;
  entities?: Array<{
    type: string;
    value: string;
    context?: string;
  }>;
}

/**
 * Conversation context for maintaining state
 */
export interface ConversationContext {
  userId: number;
  conversationId: string;
  messages: LLMMessage[];
  metadata: {
    startedAt: string;
    lastMessageAt: string;
    messageCount: number;
  };
}

/**
 * LLM Service for HAI reasoning capabilities
 * 
 * This service provides:
 * - Natural language understanding
 * - Context-aware reasoning
 * - Entity extraction
 * - Action suggestion
 * - Conversation management
 */
class LLMServiceClass {
  private conversations: Map<string, ConversationContext> = new Map();
  private readonly MAX_CONTEXT_MESSAGES = 20;

  /**
   * System prompts for different HAI engines
   */
  private readonly SYSTEM_PROMPTS = {
    general: `You are HAI (Household AI), a universal AI assistant that serves as a 24/7 digital cognitive extension for your user. You understand their life across ALL domains (work, health, finance, legal, social, education, etc.) and help them manage obligations, make decisions, and improve their well-being.

Key principles:
- Use universal reasoning from first principles, not domain-specific rules
- Understand context deeply before suggesting actions
- Map everything to Maslow's Hierarchy of Needs
- Be proactive but respectful of autonomy
- Maintain complete transparency
- Learn continuously from interactions

When analyzing user input:
1. Extract entities (people, places, obligations, emotions)
2. Identify needs being expressed (which level of Maslow's hierarchy?)
3. Understand context (what's the real problem?)
4. Suggest actions (what would help?)
5. Assess urgency (how critical is this?)`,

    selfModel: `You are the Self-Model Engine of HAI. Your purpose is to learn and understand the user deeply by:
- Extracting patterns from their behavior and communication
- Identifying their values, preferences, and triggers
- Building a comprehensive model of who they are
- Connecting scattered fragments of information
- Asking clarifying questions to fill gaps

When the user shares information:
1. Extract key facts about their identity, relationships, goals, habits
2. Identify patterns and preferences
3. Note emotional states and triggers
4. Connect to previous information
5. Ask targeted questions to deepen understanding`,

    decision: `You are the Decision Engine of HAI. Your purpose is to help users make better decisions by:
- Analyzing options objectively
- Considering short-term and long-term consequences
- Evaluating alignment with user's values and goals
- Assessing risks and opportunities
- Providing clear recommendations with reasoning

When helping with decisions:
1. Clarify the decision to be made
2. Identify all options
3. Analyze pros/cons of each
4. Consider impact on user's needs and goals
5. Recommend a course of action with confidence level`,

    task: `You are the Task Orchestration Engine of HAI. Your purpose is to help users manage their obligations by:
- Breaking down complex goals into actionable tasks
- Identifying dependencies and sequencing
- Estimating effort and time required
- Prioritizing based on urgency and importance
- Tracking progress and adjusting plans

When processing task-related input:
1. Extract the goal or obligation
2. Break it into concrete steps
3. Identify dependencies
4. Suggest priorities
5. Estimate timeline`,

    knowledge: `You are the Knowledge Graph Engine of HAI. Your purpose is to connect information by:
- Extracting entities (people, places, things, concepts)
- Identifying relationships between entities
- Building semantic connections
- Enabling pattern discovery
- Supporting reasoning across domains

When processing information:
1. Extract all entities mentioned
2. Identify relationships (who relates to whom, what affects what)
3. Note temporal aspects (past, present, future)
4. Connect to existing knowledge
5. Identify patterns and insights`,
  };

  /**
   * Get or create conversation context
   */
  private getConversation(userId: number, conversationId?: string): ConversationContext {
    const id = conversationId || `conv_${userId}_${Date.now()}`;
    
    if (!this.conversations.has(id)) {
      this.conversations.set(id, {
        userId,
        conversationId: id,
        messages: [],
        metadata: {
          startedAt: new Date().toISOString(),
          lastMessageAt: new Date().toISOString(),
          messageCount: 0,
        },
      });
    }

    return this.conversations.get(id)!;
  }

  /**
   * Add message to conversation context
   */
  private addMessage(conversationId: string, message: LLMMessage): void {
    const conversation = this.conversations.get(conversationId);
    if (!conversation) return;

    conversation.messages.push(message);
    conversation.metadata.lastMessageAt = new Date().toISOString();
    conversation.metadata.messageCount++;

    // Trim context if too long
    if (conversation.messages.length > this.MAX_CONTEXT_MESSAGES) {
      // Keep system message and recent messages
      const systemMessages = conversation.messages.filter(m => m.role === 'system');
      const recentMessages = conversation.messages.slice(-this.MAX_CONTEXT_MESSAGES + systemMessages.length);
      conversation.messages = [...systemMessages, ...recentMessages];
    }
  }

  /**
   * Chat with HAI - general conversation
   */
  async chat(params: {
    userId: number;
    message: string;
    conversationId?: string;
    engineType?: 'general' | 'selfModel' | 'decision' | 'task' | 'knowledge';
  }): Promise<{ response: string; conversationId: string }> {
    const { userId, message, conversationId, engineType = 'general' } = params;

    // Get or create conversation
    const conversation = this.getConversation(userId, conversationId);

    // Add system prompt if this is the first message
    if (conversation.messages.length === 0) {
      const systemPrompt = this.SYSTEM_PROMPTS[engineType] || this.SYSTEM_PROMPTS.general;
      this.addMessage(conversation.conversationId, {
        role: 'system',
        content: systemPrompt,
      });
    }

    // Add user message
    this.addMessage(conversation.conversationId, {
      role: 'user',
      content: message,
    });

    // Get LLM response
    const llmResponse = await invokeLLM({
      messages: conversation.messages,
    });

    const responseContent = llmResponse.choices[0]?.message?.content;
    const response = typeof responseContent === 'string' ? responseContent : "I'm sorry, I couldn't process that.";

    // Add assistant response
    if (typeof responseContent === 'string') {
      this.addMessage(conversation.conversationId, {
        role: 'assistant',
        content: responseContent,
      });
    }

    // Publish event
    await EventBus.publish({
      type: 'chat.message',
      source: 'LLMService',
      target: '*',
      data: {
        userId,
        conversationId: conversation.conversationId,
        message,
        response,
      },
    });

    return {
      response,
      conversationId: conversation.conversationId,
    };
  }

  /**
   * Analyze text for reasoning and entity extraction
   */
  async analyze(params: {
    text: string;
    context?: string;
    engineType?: 'general' | 'selfModel' | 'decision' | 'task' | 'knowledge';
  }): Promise<ReasoningResult> {
    const { text, context, engineType = 'general' } = params;

    const systemPrompt = this.SYSTEM_PROMPTS[engineType] || this.SYSTEM_PROMPTS.general;
    
    const analysisPrompt = `${systemPrompt}

${context ? `Context: ${context}\n\n` : ''}User input: "${text}"

Analyze this input and provide:
1. Your understanding of what the user is expressing
2. Entities mentioned (people, places, obligations, emotions, etc.)
3. Which of Maslow's needs are relevant
4. Suggested actions HAI could take
5. Confidence level (0-1) in your analysis

Respond in JSON format:
{
  "response": "Your natural language response to the user",
  "confidence": 0.85,
  "reasoning": "Explanation of your analysis",
  "suggestedActions": [
    {
      "type": "action_type",
      "description": "What to do",
      "priority": "high"
    }
  ],
  "entities": [
    {
      "type": "person|place|obligation|emotion|etc",
      "value": "entity value",
      "context": "additional context"
    }
  ]
}`;

    const llmResponse = await invokeLLM({
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: analysisPrompt },
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'reasoning_result',
          strict: true,
          schema: {
            type: 'object',
            properties: {
              response: { type: 'string' },
              confidence: { type: 'number' },
              reasoning: { type: 'string' },
              suggestedActions: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    type: { type: 'string' },
                    description: { type: 'string' },
                    priority: { type: 'string', enum: ['low', 'medium', 'high'] },
                  },
                  required: ['type', 'description', 'priority'],
                  additionalProperties: false,
                },
              },
              entities: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    type: { type: 'string' },
                    value: { type: 'string' },
                    context: { type: 'string' },
                  },
                  required: ['type', 'value'],
                  additionalProperties: false,
                },
              },
            },
            required: ['response', 'confidence', 'reasoning'],
            additionalProperties: false,
          },
        },
      },
    });

    const content = llmResponse.choices[0]?.message?.content;
    if (!content || typeof content !== 'string') {
      throw new Error('No valid response from LLM');
    }

    const result: ReasoningResult = JSON.parse(content);

    // Publish event
    await EventBus.publish({
      type: 'llm.analysis',
      source: 'LLMService',
      target: '*',
      data: {
        text,
        result,
      },
    });

    return result;
  }

  /**
   * Extract entities from text
   */
  async extractEntities(text: string): Promise<Array<{ type: string; value: string; context?: string }>> {
    const result = await this.analyze({ text, engineType: 'knowledge' });
    return result.entities || [];
  }

  /**
   * Get conversation history
   */
  getConversationHistory(conversationId: string): LLMMessage[] {
    const conversation = this.conversations.get(conversationId);
    return conversation ? [...conversation.messages] : [];
  }

  /**
   * Clear conversation
   */
  clearConversation(conversationId: string): void {
    this.conversations.delete(conversationId);
  }

  /**
   * Get all active conversations for a user
   */
  getUserConversations(userId: number): ConversationContext[] {
    return Array.from(this.conversations.values()).filter(c => c.userId === userId);
  }
}

// Export singleton instance
export const LLMService = new LLMServiceClass();
