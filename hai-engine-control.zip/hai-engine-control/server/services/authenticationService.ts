import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { getDb } from '../db';
import { users } from '../../drizzle/schema';
import { eq } from 'drizzle-orm';
import { sendAccountLockoutEmail } from './emailService';

const MAX_LOGIN_ATTEMPTS = 3;
const LOCKOUT_DURATION_MINUTES = 30;

/**
 * Authentication Service
 * Handles password hashing, login attempt tracking, account lockout, and password recovery
 */

/**
 * Hash a password using bcrypt
 */
export async function hashPassword(password: string): Promise<string> {
  const saltRounds = 10;
  return await bcrypt.hash(password, saltRounds);
}

/**
 * Verify a password against a hash
 */
export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return await bcrypt.compare(password, hash);
}

/**
 * Check if an account is currently locked
 */
export async function isAccountLocked(userId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;

  const result = await db
    .select()
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);

  if (result.length === 0) return false;

  const user = result[0];
  
  // Check if account is locked and lockout hasn't expired
  if (user.accountLockedUntil) {
    const now = new Date();
    if (user.accountLockedUntil > now) {
      return true;
    } else {
      // Lockout expired, reset failed attempts
      await db
        .update(users)
        .set({
          failedLoginAttempts: 0,
          accountLockedUntil: null,
        })
        .where(eq(users.id, userId));
      return false;
    }
  }

  return false;
}

/**
 * Record a failed login attempt
 * Locks account after MAX_LOGIN_ATTEMPTS failures
 */
export async function recordFailedLogin(userId: number): Promise<{ locked: boolean; attemptsRemaining: number }> {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  const result = await db
    .select()
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);

  if (result.length === 0) throw new Error('User not found');

  const user = result[0];
  const newAttempts = (user.failedLoginAttempts || 0) + 1;

  if (newAttempts >= MAX_LOGIN_ATTEMPTS) {
    // Lock the account
    const lockoutUntil = new Date();
    lockoutUntil.setMinutes(lockoutUntil.getMinutes() + LOCKOUT_DURATION_MINUTES);

    await db
      .update(users)
      .set({
        failedLoginAttempts: newAttempts,
        accountLockedUntil: lockoutUntil,
      })
      .where(eq(users.id, userId));

    // Send lockout notification email
    if (user.email) {
      await sendAccountLockoutEmail(user.email, user.name || 'User', lockoutUntil);
    }

    return { locked: true, attemptsRemaining: 0 };
  } else {
    // Increment failed attempts
    await db
      .update(users)
      .set({
        failedLoginAttempts: newAttempts,
      })
      .where(eq(users.id, userId));

    return { locked: false, attemptsRemaining: MAX_LOGIN_ATTEMPTS - newAttempts };
  }
}

/**
 * Reset failed login attempts after successful login
 */
export async function resetFailedLoginAttempts(userId: number): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db
    .update(users)
    .set({
      failedLoginAttempts: 0,
      accountLockedUntil: null,
      lastSignedIn: new Date(),
    })
    .where(eq(users.id, userId));
}

/**
 * Generate a password reset token
 */
export async function generatePasswordResetToken(userId: number): Promise<string> {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  // Generate a secure random token
  const token = crypto.randomBytes(32).toString('hex');
  
  // Token expires in 1 hour
  const expiry = new Date();
  expiry.setHours(expiry.getHours() + 1);

  await db
    .update(users)
    .set({
      passwordResetToken: token,
      passwordResetExpiry: expiry,
    })
    .where(eq(users.id, userId));

  return token;
}

/**
 * Verify a password reset token
 */
export async function verifyPasswordResetToken(token: string): Promise<number | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(users)
    .where(eq(users.passwordResetToken, token))
    .limit(1);

  if (result.length === 0) return null;

  const user = result[0];

  // Check if token has expired
  if (!user.passwordResetExpiry || user.passwordResetExpiry < new Date()) {
    return null;
  }

  return user.id;
}

/**
 * Reset password using a valid token
 */
export async function resetPasswordWithToken(token: string, newPassword: string): Promise<boolean> {
  const userId = await verifyPasswordResetToken(token);
  if (!userId) return false;

  const db = await getDb();
  if (!db) return false;

  const passwordHash = await hashPassword(newPassword);

  await db
    .update(users)
    .set({
      passwordHash,
      passwordResetToken: null,
      passwordResetExpiry: null,
      lastPasswordChange: new Date(),
      failedLoginAttempts: 0,
      accountLockedUntil: null,
    })
    .where(eq(users.id, userId));

  return true;
}

/**
 * Change password for a user (requires current password verification)
 */
export async function changePassword(
  userId: number,
  currentPassword: string,
  newPassword: string
): Promise<{ success: boolean; error?: string }> {
  const db = await getDb();
  if (!db) return { success: false, error: 'Database not available' };

  const result = await db
    .select()
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);

  if (result.length === 0) {
    return { success: false, error: 'User not found' };
  }

  const user = result[0];

  // Verify current password
  if (!user.passwordHash) {
    return { success: false, error: 'No password set for this account' };
  }

  const isValid = await verifyPassword(currentPassword, user.passwordHash);
  if (!isValid) {
    return { success: false, error: 'Current password is incorrect' };
  }

  // Hash and save new password
  const passwordHash = await hashPassword(newPassword);

  await db
    .update(users)
    .set({
      passwordHash,
      lastPasswordChange: new Date(),
    })
    .where(eq(users.id, userId));

  return { success: true };
}

/**
 * Get account lockout status
 */
export async function getAccountLockoutStatus(userId: number): Promise<{
  isLocked: boolean;
  lockedUntil: Date | null;
  failedAttempts: number;
  attemptsRemaining: number;
}> {
  const db = await getDb();
  if (!db) {
    return {
      isLocked: false,
      lockedUntil: null,
      failedAttempts: 0,
      attemptsRemaining: MAX_LOGIN_ATTEMPTS,
    };
  }

  const result = await db
    .select()
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);

  if (result.length === 0) {
    return {
      isLocked: false,
      lockedUntil: null,
      failedAttempts: 0,
      attemptsRemaining: MAX_LOGIN_ATTEMPTS,
    };
  }

  const user = result[0];
  const isLocked = await isAccountLocked(userId);

  return {
    isLocked,
    lockedUntil: user.accountLockedUntil || null,
    failedAttempts: user.failedLoginAttempts || 0,
    attemptsRemaining: Math.max(0, MAX_LOGIN_ATTEMPTS - (user.failedLoginAttempts || 0)),
  };
}
