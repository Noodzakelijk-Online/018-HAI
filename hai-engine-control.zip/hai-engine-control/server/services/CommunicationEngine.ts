import { getDb } from "../db";
import { communicationMessages, communicationTemplates, CommunicationMessage, InsertCommunicationMessage } from "../../drizzle/schema";
import { eq, desc } from "drizzle-orm";
import { EventBus } from "./EventBus";
import { notifyOwner } from "../_core/notification";
import { logActivity } from "./activityTracker";

/**
 * Communication Engine Service
 * 
 * Handles multi-channel messaging with:
 * - Email delivery
 * - In-app notifications
 * - SMS messaging
 * - Chat messages
 * - Template rendering
 * - Delivery tracking
 */
export class CommunicationEngine {
  /**
   * Send a message through specified channel
   */
  static async sendMessage(params: {
    channel: "email" | "notification" | "sms" | "chat";
    recipient: string;
    subject?: string;
    body: string;
    templateId?: number;
    metadata?: Record<string, unknown>;
  }): Promise<CommunicationMessage> {
    const { channel, recipient, subject, body, templateId, metadata } = params;

    const db = await getDb();
    if (!db) throw new Error('Database not available');

    // Create message record
    await db.insert(communicationMessages).values({
      channel,
      recipient,
      subject,
      body,
      templateId,
      status: 'queued',
      metadata: metadata as any,
      retryCount: 0,
    });

    const created = await db
      .select()
      .from(communicationMessages)
      .orderBy(desc(communicationMessages.createdAt))
      .limit(1);

    if (created.length === 0) {
      throw new Error('Failed to create message');
    }

    const message = created[0];

    // Publish event
    await EventBus.publish({
      type: 'communication.message.queued',
      source: 'communication_engine',
      target: '*',
      data: {
        messageId: message.id,
        channel,
        recipient,
      },
      metadata: {
        priority: 'normal',
      },
    });

    // Process message asynchronously
    this.processMessage(message.id).catch((error) => {
      console.error('[CommunicationEngine] Message processing error:', error);
    });

    return message;
  }

  /**
   * Process and deliver a message
   */
  private static async processMessage(messageId: number): Promise<void> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const messages = await db
      .select()
      .from(communicationMessages)
      .where(eq(communicationMessages.id, messageId))
      .limit(1);

    if (messages.length === 0) {
      throw new Error('Message not found');
    }

    const message = messages[0];

    try {
      // Deliver based on channel
      switch (message.channel) {
        case 'email':
          await this.sendEmail(message);
          break;
        case 'notification':
          await this.sendNotification(message);
          break;
        case 'sms':
          await this.sendSMS(message);
          break;
        case 'chat':
          await this.sendChat(message);
          break;
        default:
          throw new Error(`Unknown channel: ${message.channel}`);
      }

      // Update status to sent
      await db
        .update(communicationMessages)
        .set({
          status: 'sent',
          sentAt: new Date(),
        })
        .where(eq(communicationMessages.id, messageId));

      // Publish success event
      await EventBus.publish({
        type: 'communication.message.sent',
        source: 'communication_engine',
        target: '*',
        data: {
          messageId,
          channel: message.channel,
        },
        metadata: {
          priority: 'normal',
        },
      });
    } catch (error: any) {
      // Update status to failed
      await db
        .update(communicationMessages)
        .set({
          status: 'failed',
          errorMessage: error.message,
          retryCount: message.retryCount + 1,
        })
        .where(eq(communicationMessages.id, messageId));

      // Publish failure event
      await EventBus.publish({
        type: 'communication.message.failed',
        source: 'communication_engine',
        target: '*',
        data: {
          messageId,
          error: error.message,
        },
        metadata: {
          priority: 'high',
        },
      });

      // Retry if not exceeded max retries
      if (message.retryCount < 3) {
        setTimeout(() => {
          this.processMessage(messageId).catch(console.error);
        }, 5000 * (message.retryCount + 1)); // Exponential backoff
      }
    }
  }

  /**
   * Send email message
   */
  private static async sendEmail(message: CommunicationMessage): Promise<void> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    // Try to find a connected Gmail connector
    const { connectors } = await import('../../drizzle/schema');
    const { eq, and } = await import('drizzle-orm');
    
    const gmailConnectors = await db
      .select()
      .from(connectors)
      .where(
        and(
          eq(connectors.connectorType, 'gmail'),
          eq(connectors.status, 'connected')
        )
      )
      .limit(1);

    if (gmailConnectors.length > 0) {
      // Use Gmail connector
      const gmailConnector = gmailConnectors[0];
      console.log('[CommunicationEngine] Using Gmail connector:', gmailConnector.name);
      
      try {
        const { mockGmailSendEmail, decryptCredentials, isTokenExpired } = await import('./mockOAuthService');
        
        if (!gmailConnector.credentials) {
          throw new Error('Gmail connector not authenticated');
        }

        const token = decryptCredentials(gmailConnector.credentials);
        
        if (isTokenExpired(new Date(token.expiresAt))) {
          throw new Error('Gmail token expired. Please reconnect.');
        }

        // Send via Gmail API
        await mockGmailSendEmail(
          token.accessToken,
          [message.recipient],
          message.subject || 'No Subject',
          message.body
        );

        console.log('[CommunicationEngine] Email sent via Gmail connector');
        
        // Log activity
        await logActivity({
          engine: 'communication',
          action: 'send_email',
          title: `Sent email: ${message.subject || 'No Subject'}`,
          description: `Sent email to ${message.recipient} via Gmail connector`,
          metadata: JSON.stringify({
            recipient: message.recipient,
            subject: message.subject,
            method: 'gmail',
            connectorId: gmailConnector.id,
          }),
          impact: 'medium',
          status: 'completed',
        });
        
        return;
      } catch (error: any) {
        console.error('[CommunicationEngine] Gmail connector failed:', error.message);
        console.log('[CommunicationEngine] Falling back to console logging');
      }
    }

    // Fallback: console logging
    console.log('[CommunicationEngine] No Gmail connector available, logging to console');
    console.log('[CommunicationEngine] Sending email:', {
      to: message.recipient,
      subject: message.subject,
      body: message.body.substring(0, 100) + '...',
    });

    // Simulate email sending
    await new Promise(resolve => setTimeout(resolve, 100));
    console.log('[CommunicationEngine] Email logged successfully');
    
    // Log activity
    await logActivity({
      engine: 'communication',
      action: 'send_email',
      title: `Sent email: ${message.subject || 'No Subject'}`,
      description: `Sent email to ${message.recipient} (console fallback)`,
      metadata: JSON.stringify({
        recipient: message.recipient,
        subject: message.subject,
        method: 'console',
      }),
      impact: 'low',
      status: 'completed',
    });
  }

  /**
   * Send notification
   */
  private static async sendNotification(message: CommunicationMessage): Promise<void> {
    // Use the built-in notification system
    await notifyOwner({
      title: message.subject || 'New Notification',
      content: message.body,
    });

    console.log('[CommunicationEngine] Notification sent successfully');
  }

  /**
   * Send SMS message
   */
  private static async sendSMS(message: CommunicationMessage): Promise<void> {
    // In a real implementation, this would use SMS service API (Twilio, etc.)
    console.log('[CommunicationEngine] Sending SMS:', {
      to: message.recipient,
      body: message.body.substring(0, 100) + '...',
    });

    // Simulate SMS sending
    await new Promise(resolve => setTimeout(resolve, 100));

    console.log('[CommunicationEngine] SMS sent successfully');
  }

  /**
   * Send chat message
   */
  private static async sendChat(message: CommunicationMessage): Promise<void> {
    // In a real implementation, this would integrate with chat system
    console.log('[CommunicationEngine] Sending chat message:', {
      to: message.recipient,
      body: message.body.substring(0, 100) + '...',
    });

    // Simulate chat sending
    await new Promise(resolve => setTimeout(resolve, 50));

    console.log('[CommunicationEngine] Chat message sent successfully');
  }

  /**
   * Render template with variables
   */
  static async renderTemplate(
    templateId: number,
    variables: Record<string, string>
  ): Promise<{ subject?: string; body: string }> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const templates = await db
      .select()
      .from(communicationTemplates)
      .where(eq(communicationTemplates.id, templateId))
      .limit(1);

    if (templates.length === 0) {
      throw new Error('Template not found');
    }

    const template = templates[0];

    // Simple variable replacement
    let subject = template.subject || '';
    let body = template.body;

    for (const [key, value] of Object.entries(variables)) {
      const regex = new RegExp(`{{${key}}}`, 'g');
      subject = subject.replace(regex, value);
      body = body.replace(regex, value);
    }

    // Increment usage count
    await db
      .update(communicationTemplates)
      .set({
        usageCount: template.usageCount + 1,
      })
      .where(eq(communicationTemplates.id, templateId));

    return { subject: subject || undefined, body };
  }

  /**
   * Create a message template
   */
  static async createTemplate(params: {
    name: string;
    description?: string;
    channel: "email" | "notification" | "sms" | "chat";
    subject?: string;
    body: string;
    variables?: string[];
    category?: string;
  }) {
    const { name, description, channel, subject, body, variables, category } = params;

    const db = await getDb();
    if (!db) throw new Error('Database not available');

    await db.insert(communicationTemplates).values({
      name,
      description,
      channel,
      subject,
      body,
      variables: variables as any,
      category,
      isActive: 1,
      usageCount: 0,
    });

    const created = await db
      .select()
      .from(communicationTemplates)
      .orderBy(desc(communicationTemplates.createdAt))
      .limit(1);

    return created.length > 0 ? created[0] : null;
  }

  /**
   * Get all messages with optional filtering
   */
  static async getMessages(filters?: {
    channel?: string;
    status?: string;
    limit?: number;
  }) {
    const db = await getDb();
    if (!db) return [];

    let query = db.select().from(communicationMessages);

    // Apply filters if provided
    // Note: Drizzle doesn't support dynamic where clauses easily, so we fetch all and filter in memory
    const allMessages = await query.orderBy(desc(communicationMessages.createdAt)).limit(filters?.limit || 100);

    if (filters?.channel) {
      return allMessages.filter(m => m.channel === filters.channel);
    }

    if (filters?.status) {
      return allMessages.filter(m => m.status === filters.status);
    }

    return allMessages;
  }

  /**
   * Get all templates
   */
  static async getTemplates(channel?: string) {
    const db = await getDb();
    if (!db) return [];

    const allTemplates = await db
      .select()
      .from(communicationTemplates)
      .orderBy(desc(communicationTemplates.createdAt));

    if (channel) {
      return allTemplates.filter(t => t.channel === channel);
    }

    return allTemplates;
  }

  /**
   * Get message by ID
   */
  static async getMessageById(id: number) {
    const db = await getDb();
    if (!db) return null;

    const result = await db
      .select()
      .from(communicationMessages)
      .where(eq(communicationMessages.id, id))
      .limit(1);

    return result.length > 0 ? result[0] : null;
  }

  /**
   * Get delivery statistics
   */
  static async getStats() {
    const db = await getDb();
    if (!db) {
      return {
        total: 0,
        sent: 0,
        failed: 0,
        queued: 0,
      };
    }

    const allMessages = await db.select().from(communicationMessages);

    return {
      total: allMessages.length,
      sent: allMessages.filter(m => m.status === 'sent' || m.status === 'delivered').length,
      failed: allMessages.filter(m => m.status === 'failed').length,
      queued: allMessages.filter(m => m.status === 'queued').length,
    };
  }
}
