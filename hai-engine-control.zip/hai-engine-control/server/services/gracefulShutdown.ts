/**
 * Graceful Shutdown Handler
 * Implements P1 #46: Graceful shutdown handlers
 */

import EventBus from './EventBus';
import { stopTokenRefreshScheduler } from './oauthTokenRefresh';
import { stopCleanupScheduler } from './sessionManagement';
import { stopHealthMonitoring } from './healthCheck';

type ShutdownCallback = () => Promise<void> | void;

interface ShutdownConfig {
  timeout: number;           // Max time to wait for graceful shutdown
  forceExitDelay: number;    // Delay before force exit
}

const DEFAULT_CONFIG: ShutdownConfig = {
  timeout: 30000,            // 30 seconds
  forceExitDelay: 5000,      // 5 seconds
};

const shutdownCallbacks: ShutdownCallback[] = [];
let isShuttingDown = false;
let config = { ...DEFAULT_CONFIG };

/**
 * Register a callback to be called during shutdown
 */
export function onShutdown(callback: ShutdownCallback): void {
  shutdownCallbacks.push(callback);
}

/**
 * Configure shutdown behavior
 */
export function configure(newConfig: Partial<ShutdownConfig>): void {
  config = { ...config, ...newConfig };
}

/**
 * Execute graceful shutdown
 */
async function executeShutdown(signal: string): Promise<void> {
  if (isShuttingDown) {
    console.log('[Shutdown] Already shutting down...');
    return;
  }
  
  isShuttingDown = true;
  console.log(`[Shutdown] Received ${signal}, starting graceful shutdown...`);
  
  const startTime = Date.now();
  
  try {
    // Stop accepting new connections
    console.log('[Shutdown] Stopping new connections...');
    
    // Stop scheduled tasks
    console.log('[Shutdown] Stopping scheduled tasks...');
    stopTokenRefreshScheduler();
    stopCleanupScheduler();
    stopHealthMonitoring();
    
    // Disconnect from EventBus
    console.log('[Shutdown] Disconnecting from EventBus...');
    try {
      await EventBus.disconnect();
    } catch (error) {
      console.warn('[Shutdown] EventBus disconnect error:', error);
    }
    
    // Execute registered callbacks with timeout
    console.log(`[Shutdown] Executing ${shutdownCallbacks.length} shutdown callbacks...`);
    
    const callbackPromises = shutdownCallbacks.map(async (callback, index) => {
      try {
        await Promise.race([
          callback(),
          new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Callback timeout')), config.timeout / 2)
          ),
        ]);
        console.log(`[Shutdown] Callback ${index + 1} completed`);
      } catch (error) {
        console.warn(`[Shutdown] Callback ${index + 1} failed:`, error);
      }
    });
    
    await Promise.allSettled(callbackPromises);
    
    const elapsed = Date.now() - startTime;
    console.log(`[Shutdown] Graceful shutdown completed in ${elapsed}ms`);
    
    // Exit after a short delay
    setTimeout(() => {
      console.log('[Shutdown] Exiting process...');
      process.exit(0);
    }, config.forceExitDelay);
    
  } catch (error) {
    console.error('[Shutdown] Error during shutdown:', error);
    process.exit(1);
  }
}

/**
 * Force shutdown (for unrecoverable errors)
 */
export function forceShutdown(reason: string): void {
  console.error(`[Shutdown] Force shutdown: ${reason}`);
  process.exit(1);
}

/**
 * Setup signal handlers for graceful shutdown
 */
export function setupShutdownHandlers(): void {
  // Handle SIGTERM (from process managers like PM2, Docker)
  process.on('SIGTERM', () => executeShutdown('SIGTERM'));
  
  // Handle SIGINT (Ctrl+C)
  process.on('SIGINT', () => executeShutdown('SIGINT'));
  
  // Handle uncaught exceptions
  process.on('uncaughtException', (error) => {
    console.error('[Shutdown] Uncaught exception:', error);
    executeShutdown('uncaughtException');
  });
  
  // Handle unhandled promise rejections
  process.on('unhandledRejection', (reason, promise) => {
    console.error('[Shutdown] Unhandled rejection at:', promise, 'reason:', reason);
    // Don't exit on unhandled rejections in development
    if (process.env.NODE_ENV === 'production') {
      executeShutdown('unhandledRejection');
    }
  });
  
  // Handle process warnings
  process.on('warning', (warning) => {
    console.warn('[Process Warning]', warning.name, warning.message);
  });
  
  console.log('[Shutdown] Graceful shutdown handlers registered');
}

/**
 * Check if system is shutting down
 */
export function isSystemShuttingDown(): boolean {
  return isShuttingDown;
}

/**
 * Middleware to reject requests during shutdown
 */
export function shutdownMiddleware(req: any, res: any, next: any): void {
  if (isShuttingDown) {
    res.status(503).json({
      error: 'Service Unavailable',
      message: 'Server is shutting down',
    });
    return;
  }
  next();
}

export default {
  onShutdown,
  configure,
  forceShutdown,
  setupShutdownHandlers,
  isSystemShuttingDown,
  shutdownMiddleware,
};
