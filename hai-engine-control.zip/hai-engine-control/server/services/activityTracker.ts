import { getDb } from "../db";
import { haiActivities, type HaiActivity, type InsertHaiActivity } from "../../drizzle/schema";
import { eq, and, or, gte, lte, desc, sql } from "drizzle-orm";

/**
 * Log an autonomous activity
 */
export async function logActivity(data: {
  engine: "communication" | "decision" | "task" | "system";
  action: string;
  title: string;
  description?: string;
  metadata?: any;
  impact?: string;
  status: "completed" | "in_progress" | "failed";
  userId?: number; // Optional: defaults to 0 for autonomous HAI actions
}): Promise<HaiActivity> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const [activity] = await db.insert(haiActivities).values({
    ...data,
    userId: data.userId ?? 0, // Default to 0 for autonomous actions
  }).$returningId();
  const [newActivity] = await db.select().from(haiActivities).where(eq(haiActivities.id, activity.id));
  
  console.log(`[ActivityTracker] Logged activity: ${data.title} (${data.engine})`);
  
  return newActivity!;
}

/**
 * Get activities since last dashboard visit
 */
export async function getActivitiesSinceLastVisit(
  userId: number,
  lastVisit: Date | null
): Promise<HaiActivity[]> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  // If no last visit, show today's activities
  const sinceDate = lastVisit || (() => {
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);
    return startOfDay;
  })();

  // Include both user's activities AND autonomous activities (userId=0)
  return await db
    .select()
    .from(haiActivities)
    .where(
      and(
        or(
          eq(haiActivities.userId, userId),
          eq(haiActivities.userId, 0) // Include autonomous HAI activities
        ),
        gte(haiActivities.createdAt, sinceDate)
      )
    )
    .orderBy(desc(haiActivities.createdAt));
}

/**
 * Get today's activities
 */
export async function getTodaysActivities(userId: number): Promise<HaiActivity[]> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);

  const endOfDay = new Date();
  endOfDay.setHours(23, 59, 59, 999);

  // Include both user's activities AND autonomous activities (userId=0)
  return await db
    .select()
    .from(haiActivities)
    .where(
      and(
        or(
          eq(haiActivities.userId, userId),
          eq(haiActivities.userId, 0) // Include autonomous HAI activities
        ),
        gte(haiActivities.createdAt, startOfDay),
        lte(haiActivities.createdAt, endOfDay)
      )
    )
    .orderBy(desc(haiActivities.createdAt));
}

/**
 * Get activities by date range
 */
export async function getActivitiesByDateRange(
  userId: number,
  startDate: Date,
  endDate: Date
): Promise<HaiActivity[]> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  // Include both user's activities AND autonomous activities (userId=0)
  return await db
    .select()
    .from(haiActivities)
    .where(
      and(
        or(
          eq(haiActivities.userId, userId),
          eq(haiActivities.userId, 0) // Include autonomous HAI activities
        ),
        gte(haiActivities.createdAt, startDate),
        lte(haiActivities.createdAt, endDate)
      )
    )
    .orderBy(desc(haiActivities.createdAt));
}

/**
 * Get activities by engine
 */
export async function getActivitiesByEngine(
  userId: number,
  engine: "communication" | "decision" | "task" | "system"
): Promise<HaiActivity[]> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  // Include both user's activities AND autonomous activities (userId=0)
  return await db
    .select()
    .from(haiActivities)
    .where(
      and(
        or(
          eq(haiActivities.userId, userId),
          eq(haiActivities.userId, 0) // Include autonomous HAI activities
        ),
        eq(haiActivities.engine, engine)
      )
    )
    .orderBy(desc(haiActivities.createdAt));
}

/**
 * Get activity statistics for today
 */
export async function getTodaysStatistics(userId: number): Promise<{
  totalActivities: number;
  byEngine: Record<string, number>;
  byStatus: Record<string, number>;
  byImpact: Record<string, number>;
}> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const activities = await getTodaysActivities(userId);

  const stats = {
    totalActivities: activities.length,
    byEngine: {} as Record<string, number>,
    byStatus: {} as Record<string, number>,
    byImpact: {} as Record<string, number>,
  };

  activities.forEach(activity => {
    // Count by engine
    stats.byEngine[activity.engine] = (stats.byEngine[activity.engine] || 0) + 1;

    // Count by status
    stats.byStatus[activity.status] = (stats.byStatus[activity.status] || 0) + 1;

    // Count by impact
    if (activity.impact) {
      stats.byImpact[activity.impact] = (stats.byImpact[activity.impact] || 0) + 1;
    }
  });

  return stats;
}

/**
 * Get recent activities (last N)
 */
export async function getRecentActivities(userId: number, limit: number = 50): Promise<HaiActivity[]> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  // Include both user's activities AND autonomous activities (userId=0)
  return await db
    .select()
    .from(haiActivities)
    .where(
      or(
        eq(haiActivities.userId, userId),
        eq(haiActivities.userId, 0) // Include autonomous HAI activities
      )
    )
    .orderBy(desc(haiActivities.createdAt))
    .limit(limit);
}

/**
 * Get activity timeline grouped by time of day
 */
export async function getActivityTimeline(userId: number, date: Date): Promise<{
  morning: HaiActivity[];
  afternoon: HaiActivity[];
  evening: HaiActivity[];
  night: HaiActivity[];
}> {
  // Use server's local date to avoid timezone mismatches
  // When date is passed from frontend, use it as a reference but query in server timezone
  const serverDate = new Date(); // Current server time
  const startOfDay = new Date(serverDate);
  startOfDay.setHours(0, 0, 0, 0);
  
  const endOfDay = new Date(serverDate);
  endOfDay.setHours(23, 59, 59, 999);
  
  const activities = await getActivitiesByDateRange(
    userId,
    startOfDay,
    endOfDay
  );

  const timeline = {
    morning: [] as HaiActivity[],
    afternoon: [] as HaiActivity[],
    evening: [] as HaiActivity[],
    night: [] as HaiActivity[],
  };

  activities.forEach(activity => {
    const hour = activity.createdAt.getHours();
    
    if (hour >= 6 && hour < 12) {
      timeline.morning.push(activity);
    } else if (hour >= 12 && hour < 17) {
      timeline.afternoon.push(activity);
    } else if (hour >= 17 && hour < 21) {
      timeline.evening.push(activity);
    } else {
      timeline.night.push(activity);
    }
  });

  return timeline;
}

/**
 * Update activity status
 */
export async function updateActivityStatus(
  activityId: number,
  status: "completed" | "in_progress" | "failed"
): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db
    .update(haiActivities)
    .set({ status })
    .where(eq(haiActivities.id, activityId));
}
