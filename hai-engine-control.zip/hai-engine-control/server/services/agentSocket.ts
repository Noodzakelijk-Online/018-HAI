import { Server as SocketIOServer } from "socket.io";
import { Server as HTTPServer } from "http";
import { getAgentByApiKey, updateAgentHeartbeat } from "./agentManager";
import type { Agent } from "../../drizzle/schema";

let io: SocketIOServer | null = null;

// Map of agentId -> socket.id for quick lookup
const agentSockets = new Map<number, string>();

/**
 * Initialize Socket.IO server
 */
export function initializeAgentSocket(httpServer: HTTPServer): SocketIOServer {
  io = new SocketIOServer(httpServer, {
    cors: {
      origin: "*", // Configure appropriately for production
      methods: ["GET", "POST"],
    },
    path: "/agent-socket",
  });

  io.on("connection", (socket) => {
    console.log(`[AgentSocket] Client connected: ${socket.id}`);

    let authenticatedAgent: Agent | null = null;

    // Agent authentication
    socket.on("authenticate", async (data: { apiKey: string }) => {
      try {
        const agent = await getAgentByApiKey(data.apiKey);
        
        if (!agent) {
          socket.emit("auth_error", { message: "Invalid API key" });
          socket.disconnect();
          return;
        }

        authenticatedAgent = agent;
        agentSockets.set(agent.id, socket.id);

        // Update agent status to online
        await updateAgentHeartbeat(agent.id, "online");

        socket.emit("authenticated", {
          agentId: agent.id,
          name: agent.name,
          message: "Successfully authenticated",
        });

        console.log(`[AgentSocket] Agent authenticated: ${agent.name} (ID: ${agent.id})`);
      } catch (error) {
        console.error("[AgentSocket] Authentication error:", error);
        socket.emit("auth_error", { message: "Authentication failed" });
        socket.disconnect();
      }
    });

    // Heartbeat
    socket.on("heartbeat", async (data: { status?: "online" | "busy" | "idle" }) => {
      if (!authenticatedAgent) {
        socket.emit("error", { message: "Not authenticated" });
        return;
      }

      try {
        await updateAgentHeartbeat(authenticatedAgent.id, data.status);
        socket.emit("heartbeat_ack", { timestamp: new Date().toISOString() });
      } catch (error) {
        console.error("[AgentSocket] Heartbeat error:", error);
      }
    });

    // Capability update
    socket.on("update_capabilities", async (capabilities: any) => {
      if (!authenticatedAgent) {
        socket.emit("error", { message: "Not authenticated" });
        return;
      }

      try {
        const { updateAgentCapabilities } = await import("./agentManager");
        await updateAgentCapabilities(authenticatedAgent.id, capabilities);
        socket.emit("capabilities_updated", { success: true });
        console.log(`[AgentSocket] Capabilities updated for agent ${authenticatedAgent.id}`);
      } catch (error) {
        console.error("[AgentSocket] Capability update error:", error);
        socket.emit("error", { message: "Failed to update capabilities" });
      }
    });

    // Task result submission
    socket.on("task_result", async (data: {
      taskId: number;
      result: any;
      status: "completed" | "failed";
      errorMessage?: string;
    }) => {
      if (!authenticatedAgent) {
        socket.emit("error", { message: "Not authenticated" });
        return;
      }

      try {
        // Update task in database
        const { updateTaskResult } = await import("./taskQueue");
        await updateTaskResult(data.taskId, {
          status: data.status,
          result: data.result,
          errorMessage: data.errorMessage,
          completedAt: new Date(),
        });

        socket.emit("task_result_ack", { taskId: data.taskId });
        console.log(`[AgentSocket] Task ${data.taskId} ${data.status} by agent ${authenticatedAgent.id}`);

        // Notify Control Center about task completion
        io?.emit("task_completed", {
          taskId: data.taskId,
          agentId: authenticatedAgent.id,
          status: data.status,
        });
      } catch (error) {
        console.error("[AgentSocket] Task result error:", error);
        socket.emit("error", { message: "Failed to submit task result" });
      }
    });

    // Task progress update
    socket.on("task_progress", (data: {
      taskId: number;
      progress: number; // 0-100
      message?: string;
    }) => {
      if (!authenticatedAgent) {
        return;
      }

      // Broadcast progress to Control Center
      io?.emit("task_progress", {
        taskId: data.taskId,
        agentId: authenticatedAgent.id,
        progress: data.progress,
        message: data.message,
      });
    });

    // Disconnect
    socket.on("disconnect", async () => {
      if (authenticatedAgent) {
        console.log(`[AgentSocket] Agent disconnected: ${authenticatedAgent.name} (ID: ${authenticatedAgent.id})`);
        
        // Update agent status to offline
        try {
          await updateAgentHeartbeat(authenticatedAgent.id, "offline");
        } catch (error) {
          console.error("[AgentSocket] Error updating agent status on disconnect:", error);
        }

        agentSockets.delete(authenticatedAgent.id);
      } else {
        console.log(`[AgentSocket] Unauthenticated client disconnected: ${socket.id}`);
      }
    });
  });

  // Start heartbeat checker
  startHeartbeatChecker();

  console.log("[AgentSocket] Socket.IO server initialized");
  return io;
}

/**
 * Send task assignment to agent
 */
export function assignTaskToAgent(agentId: number, task: {
  taskId: number;
  type: string;
  payload: any;
  priority: string;
}): boolean {
  if (!io) {
    console.error("[AgentSocket] Socket.IO not initialized");
    return false;
  }

  const socketId = agentSockets.get(agentId);
  if (!socketId) {
    console.error(`[AgentSocket] Agent ${agentId} not connected`);
    return false;
  }

  io.to(socketId).emit("task_assigned", task);
  console.log(`[AgentSocket] Task ${task.taskId} assigned to agent ${agentId}`);
  return true;
}

/**
 * Cancel task on agent
 */
export function cancelTaskOnAgent(agentId: number, taskId: number): boolean {
  if (!io) {
    return false;
  }

  const socketId = agentSockets.get(agentId);
  if (!socketId) {
    return false;
  }

  io.to(socketId).emit("task_cancelled", { taskId });
  console.log(`[AgentSocket] Task ${taskId} cancelled on agent ${agentId}`);
  return true;
}

/**
 * Broadcast message to all connected agents
 */
export function broadcastToAgents(event: string, data: any): void {
  if (!io) {
    return;
  }

  io.emit(event, data);
}

/**
 * Get connected agent count
 */
export function getConnectedAgentCount(): number {
  return agentSockets.size;
}

/**
 * Check if agent is connected
 */
export function isAgentConnected(agentId: number): boolean {
  return agentSockets.has(agentId);
}

/**
 * Periodically check for stale agents and mark them offline
 * OPTIMIZED: Reduced frequency from 1 min to 5 min (80% reduction)
 */
function startHeartbeatChecker(): void {
  // OPTIMIZED: Defer first check to reduce startup load
  setTimeout(async () => {
    try {
      const { markStaleAgentsOffline } = await import("./agentManager");
      await markStaleAgentsOffline();
    } catch (error) {
      console.error("[AgentSocket] Initial heartbeat check error:", error);
    }
  }, 60 * 1000); // Wait 1 minute after startup

  // OPTIMIZED: Check every 5 minutes (was 1 minute)
  setInterval(async () => {
    try {
      const { markStaleAgentsOffline } = await import("./agentManager");
      await markStaleAgentsOffline();
    } catch (error) {
      console.error("[AgentSocket] Heartbeat checker error:", error);
    }
  }, 5 * 60 * 1000); // 5 minutes (was 1 minute)
}

export { io };
