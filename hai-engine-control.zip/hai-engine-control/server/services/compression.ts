/**
 * Response Compression
 * Implements P2 #90: Add response compression
 */

import { createGzip, createDeflate, createBrotliCompress, constants } from 'zlib';
import type { Request, Response, NextFunction } from 'express';

export interface CompressionOptions {
  threshold: number;           // Minimum size to compress (bytes)
  level: number;               // Compression level (1-9)
  filter?: (req: Request, res: Response) => boolean;
  encodings?: string[];        // Allowed encodings
}

const DEFAULT_OPTIONS: CompressionOptions = {
  threshold: 1024,             // 1KB minimum
  level: 6,                    // Default compression level
  encodings: ['br', 'gzip', 'deflate'],
};

// Content types that should be compressed
const COMPRESSIBLE_TYPES = [
  'text/html',
  'text/css',
  'text/plain',
  'text/xml',
  'text/javascript',
  'application/json',
  'application/javascript',
  'application/xml',
  'application/x-javascript',
  'image/svg+xml',
];

/**
 * Check if content type is compressible
 */
function isCompressible(contentType: string | undefined): boolean {
  if (!contentType) return false;
  const type = contentType.split(';')[0].trim().toLowerCase();
  return COMPRESSIBLE_TYPES.some(t => type.includes(t));
}

/**
 * Parse Accept-Encoding header
 */
function parseAcceptEncoding(header: string | undefined): string[] {
  if (!header) return [];
  
  return header
    .split(',')
    .map(part => {
      const [encoding, quality] = part.trim().split(';q=');
      return {
        encoding: encoding.trim().toLowerCase(),
        quality: quality ? parseFloat(quality) : 1,
      };
    })
    .filter(e => e.quality > 0)
    .sort((a, b) => b.quality - a.quality)
    .map(e => e.encoding);
}

/**
 * Get best encoding based on client preference and server support
 */
function getBestEncoding(
  acceptEncoding: string | undefined,
  supported: string[]
): string | null {
  const preferred = parseAcceptEncoding(acceptEncoding);
  
  for (const encoding of preferred) {
    if (supported.includes(encoding)) {
      return encoding;
    }
    // Handle wildcard
    if (encoding === '*' && supported.length > 0) {
      return supported[0];
    }
  }
  
  return null;
}

/**
 * Create compression stream based on encoding
 */
function createCompressor(encoding: string, level: number) {
  switch (encoding) {
    case 'br':
      return createBrotliCompress({
        params: {
          [constants.BROTLI_PARAM_QUALITY]: Math.min(level, 11),
        },
      });
    case 'gzip':
      return createGzip({ level });
    case 'deflate':
      return createDeflate({ level });
    default:
      return null;
  }
}

/**
 * Compression middleware
 */
export function compressionMiddleware(options: Partial<CompressionOptions> = {}) {
  const opts = { ...DEFAULT_OPTIONS, ...options };
  
  return (req: Request, res: Response, next: NextFunction) => {
    // Skip if no Accept-Encoding header
    const acceptEncoding = req.headers['accept-encoding'] as string;
    if (!acceptEncoding) {
      return next();
    }
    
    // Get best encoding
    const encoding = getBestEncoding(acceptEncoding, opts.encodings!);
    if (!encoding) {
      return next();
    }
    
    // Custom filter
    if (opts.filter && !opts.filter(req, res)) {
      return next();
    }
    
    // Store original methods
    const originalWrite = res.write.bind(res);
    const originalEnd = res.end.bind(res);
    
    let compressor: ReturnType<typeof createCompressor> = null;
    let buffer: Buffer[] = [];
    let totalSize = 0;
    let headersSent = false;
    
    // Override write
    res.write = function(chunk: any, ...args: any[]): boolean {
      if (!chunk) return true;
      
      const buf = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
      buffer.push(buf);
      totalSize += buf.length;
      
      return true;
    };
    
    // Override end
    res.end = function(chunk?: any, ...args: any[]): Response {
      if (chunk) {
        const buf = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
        buffer.push(buf);
        totalSize += buf.length;
      }
      
      const contentType = res.getHeader('content-type') as string;
      
      // Check if we should compress
      const shouldCompress = 
        totalSize >= opts.threshold &&
        isCompressible(contentType) &&
        !res.getHeader('content-encoding');
      
      if (shouldCompress) {
        compressor = createCompressor(encoding, opts.level);
        
        if (compressor) {
          // Set compression headers
          res.setHeader('Content-Encoding', encoding);
          res.removeHeader('Content-Length');
          res.setHeader('Vary', 'Accept-Encoding');
          
          const fullBuffer = Buffer.concat(buffer);
          const chunks: Buffer[] = [];
          
          compressor.on('data', (chunk: Buffer) => chunks.push(chunk));
          compressor.on('end', () => {
            const compressed = Buffer.concat(chunks);
            originalWrite(compressed);
            originalEnd();
          });
          
          compressor.write(fullBuffer);
          compressor.end();
          
          return res;
        }
      }
      
      // No compression, send as-is
      const fullBuffer = Buffer.concat(buffer);
      originalWrite(fullBuffer);
      return originalEnd();
    };
    
    next();
  };
}

/**
 * Simple gzip compression for specific responses
 */
export async function gzipCompress(data: string | Buffer): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const compressor = createGzip();
    const chunks: Buffer[] = [];
    
    compressor.on('data', chunk => chunks.push(chunk));
    compressor.on('end', () => resolve(Buffer.concat(chunks)));
    compressor.on('error', reject);
    
    compressor.write(data);
    compressor.end();
  });
}

/**
 * Calculate compression ratio
 */
export function getCompressionRatio(original: number, compressed: number): number {
  if (original === 0) return 0;
  return Math.round((1 - compressed / original) * 100);
}

export default {
  compressionMiddleware,
  gzipCompress,
  getCompressionRatio,
  isCompressible,
};
