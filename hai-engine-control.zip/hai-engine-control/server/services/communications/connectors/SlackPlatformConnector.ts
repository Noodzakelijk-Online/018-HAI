/**
 * Slack Platform Connector
 * 
 * Integrates Slack with the autonomous communication system.
 * Extends BasePlatformConnector to provide unified interface.
 */

import { BasePlatformConnector, UnifiedMessage, SendResult, PlatformCapabilities } from '../BasePlatformConnector';

export class SlackPlatformConnector extends BasePlatformConnector {
  private userId: number;
  private botToken?: string;
  private userToken?: string;
  
  constructor(userId: number, connectorId: string, config?: {
    botToken?: string;
    userToken?: string;
  }) {
    super(connectorId, 'slack');
    this.userId = userId;
    this.botToken = config?.botToken;
    this.userToken = config?.userToken;
  }
  
  /**
   * Connect to Slack
   */
  async connect(): Promise<void> {
    if (!this.botToken) {
      throw new Error('Slack bot token not configured');
    }
    
    try {
      // In a real implementation, this would verify Slack credentials
      // using the auth.test API endpoint
      this.emit('connected');
    } catch (error) {
      this.emit('error', new Error('Failed to connect to Slack'));
      throw error;
    }
  }
  
  /**
   * Disconnect from Slack
   */
  async disconnect(): Promise<void> {
    // No persistent connection to close (unless using Socket Mode)
    this.emit('disconnected');
  }
  
  /**
   * Check if connected
   */
  isConnected(): boolean {
    return !!this.botToken;
  }
  
  /**
   * Get platform capabilities
   */
  getCapabilities(): PlatformCapabilities {
    return {
      supportsRichText: true, // Slack markdown
      supportsAttachments: true,
      supportsThreads: true,
      supportsReactions: true,
      supportsTypingIndicator: true,
      supportsReadReceipts: false,
      supportsDeliveryReceipts: true,
      supportsVoice: false,
      supportsVideo: false,
      maxMessageLength: 40000, // Slack limit
    };
  }
  
  /**
   * Normalize Slack message to unified format
   */
  async normalizeMessage(platformMessage: any): Promise<UnifiedMessage | null> {
    try {
      const isDirectMessage = platformMessage.channel_type === 'im';
      const isThread = !!platformMessage.thread_ts;
      
      return {
        id: platformMessage.ts,
        platform: 'slack',
        connectorId: this.connectorId,
        conversationId: isThread ? platformMessage.thread_ts : platformMessage.channel,
        senderId: platformMessage.user,
        senderName: await this.getUserName(platformMessage.user),
        textContent: platformMessage.text,
        timestamp: new Date(parseFloat(platformMessage.ts) * 1000),
        direction: platformMessage.user === this.userId.toString() ? 'outgoing' : 'incoming',
        status: 'delivered',
        metadata: {
          channel: platformMessage.channel,
          channelType: platformMessage.channel_type,
          threadTs: platformMessage.thread_ts,
          isThread,
          isDirectMessage,
          reactions: platformMessage.reactions,
          mentions: this.extractMentions(platformMessage.text),
        },
        attachments: platformMessage.files?.map((file: any) => ({
          type: file.mimetype,
          url: file.url_private,
          name: file.name,
          size: file.size,
        })),
      };
    } catch (error) {
      console.error('[SlackPlatformConnector] Error normalizing message:', error);
      return null;
    }
  }
  
  /**
   * Denormalize unified message to Slack format
   */
  async denormalizeMessage(unifiedMessage: UnifiedMessage): Promise<any> {
    return {
      channel: unifiedMessage.metadata?.channel || unifiedMessage.conversationId,
      text: unifiedMessage.textContent,
      thread_ts: unifiedMessage.metadata?.threadTs,
      attachments: unifiedMessage.attachments?.map(att => ({
        fallback: att.name,
        image_url: att.url,
        title: att.name,
      })),
    };
  }
  
  /**
   * Send Slack message
   */
  async sendMessage(message: UnifiedMessage): Promise<SendResult> {
    try {
      if (!this.isConnected()) {
        throw new Error('Not connected to Slack');
      }
      
      // Check message length
      if (message.textContent.length > this.getCapabilities().maxMessageLength) {
        throw new Error(`Message too long (max ${this.getCapabilities().maxMessageLength} characters)`);
      }
      
      // In a real implementation, this would use Slack Web API to send message
      console.log('[SlackPlatformConnector] Sending Slack message:', {
        channel: message.metadata?.channel || message.conversationId,
        text: message.textContent,
        thread_ts: message.metadata?.threadTs,
      });
      
      return {
        success: true,
        messageId: message.id,
        timestamp: new Date(),
      };
    } catch (error) {
      console.error('[SlackPlatformConnector] Error sending Slack message:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }
  
  /**
   * Get conversation history
   */
  async getConversationHistory(
    conversationId: string,
    limit: number = 50
  ): Promise<UnifiedMessage[]> {
    try {
      // In a real implementation, this would fetch conversation history from Slack
      // using conversations.history or conversations.replies API
      return [];
    } catch (error) {
      console.error('[SlackPlatformConnector] Error getting conversation history:', error);
      return [];
    }
  }
  
  /**
   * Show typing indicator
   */
  async showTypingIndicator(conversationId: string, duration: number): Promise<void> {
    try {
      // In a real implementation, this would send typing indicator using Slack RTM API
      console.log(`[SlackPlatformConnector] Showing typing indicator in ${conversationId} for ${duration}ms`);
    } catch (error) {
      console.error('[SlackPlatformConnector] Error showing typing indicator:', error);
    }
  }
  
  /**
   * Mark as read
   */
  async markAsRead(conversationId: string, messageId: string): Promise<void> {
    try {
      // In a real implementation, this would mark message as read using conversations.mark API
      console.log(`[SlackPlatformConnector] Marking message ${messageId} as read in ${conversationId}`);
    } catch (error) {
      console.error('[SlackPlatformConnector] Error marking as read:', error);
    }
  }
  
  /**
   * Get sender profile information
   */
  async getSenderProfile(senderId: string): Promise<{
    name: string;
    relationship: string;
    communicationStyle?: string;
  } | null> {
    try {
      const name = await this.getUserName(senderId);
      
      return {
        name,
        relationship: 'colleague',
        communicationStyle: 'professional',
      };
    } catch (error) {
      console.error('[SlackPlatformConnector] Error getting sender profile:', error);
      return null;
    }
  }
  
  /**
   * Get user name from Slack user ID
   */
  private async getUserName(userId: string): Promise<string> {
    try {
      // In a real implementation, this would fetch user info from Slack
      // using users.info API
      return `User ${userId}`;
    } catch (error) {
      console.error('[SlackPlatformConnector] Error getting user name:', error);
      return userId;
    }
  }
  
  /**
   * Extract mentions from Slack message text
   */
  private extractMentions(text: string): string[] {
    const mentionRegex = /<@([A-Z0-9]+)>/g;
    const mentions: string[] = [];
    let match;
    
    while ((match = mentionRegex.exec(text)) !== null) {
      mentions.push(match[1]);
    }
    
    return mentions;
  }
  
  /**
   * Add reaction to message
   */
  async addReaction(conversationId: string, messageId: string, emoji: string): Promise<void> {
    try {
      // In a real implementation, this would add reaction using reactions.add API
      console.log(`[SlackPlatformConnector] Adding reaction ${emoji} to message ${messageId}`);
    } catch (error) {
      console.error('[SlackPlatformConnector] Error adding reaction:', error);
    }
  }
  
  /**
   * Remove reaction from message
   */
  async removeReaction(conversationId: string, messageId: string, emoji: string): Promise<void> {
    try {
      // In a real implementation, this would remove reaction using reactions.remove API
      console.log(`[SlackPlatformConnector] Removing reaction ${emoji} from message ${messageId}`);
    } catch (error) {
      console.error('[SlackPlatformConnector] Error removing reaction:', error);
    }
  }
}

/**
 * Factory function to create Slack connector
 */
export function createSlackPlatformConnector(
  userId: number,
  config?: {
    botToken?: string;
    userToken?: string;
  }
): SlackPlatformConnector {
  const connectorId = `slack-${userId}`;
  return new SlackPlatformConnector(userId, connectorId, config);
}
