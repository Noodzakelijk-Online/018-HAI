/**
 * WhatsApp Platform Connector
 * 
 * Integrates existing WhatsApp connector with the autonomous communication system.
 * Extends BasePlatformConnector to provide unified interface.
 */

import { BasePlatformConnector, UnifiedMessage, SendResult, PlatformCapabilities } from '../BasePlatformConnector';
import { WhatsAppConnector, type WhatsAppMessage } from '../../whatsapp/WhatsAppConnector';
import { getDb } from '../../../db';
import { whatsappContacts, whatsappMessages } from '../../../../drizzle/whatsapp-schema';
import { eq, and, desc } from 'drizzle-orm';

export class WhatsAppPlatformConnector extends BasePlatformConnector {
  private whatsappConnector: WhatsAppConnector;
  private userId: number;
  
  constructor(userId: number, connectorId: string) {
    super(connectorId, 'whatsapp');
    this.userId = userId;
    this.whatsappConnector = new WhatsAppConnector(userId);
    
    // Set up event listeners
    this.setupEventListeners();
  }
  
  /**
   * Set up event listeners from WhatsApp connector
   */
  private setupEventListeners(): void {
    this.whatsappConnector.on('ready', () => {
      this.emit('connected');
    });
    
    this.whatsappConnector.on('message', async (message: WhatsAppMessage) => {
      // Convert to unified format and emit
      const unified = await this.normalizeMessage(message);
      if (unified) {
        this.emit('message', unified);
      }
    });
    
    this.whatsappConnector.on('disconnected', () => {
      this.emit('disconnected');
    });
    
    this.whatsappConnector.on('error', (error: Error) => {
      this.emit('error', error);
    });
  }
  
  /**
   * Connect to WhatsApp
   */
  async connect(): Promise<void> {
    await this.whatsappConnector.connect();
  }
  
  /**
   * Disconnect from WhatsApp
   */
  async disconnect(): Promise<void> {
    await this.whatsappConnector.disconnect();
  }
  
  /**
   * Check if connected
   */
  isConnected(): boolean {
    return this.whatsappConnector.isReady;
  }
  
  /**
   * Get platform capabilities
   */
  getCapabilities(): PlatformCapabilities {
    return {
      supportsRichText: false,
      supportsAttachments: true,
      supportsThreads: false,
      supportsReactions: true,
      supportsTypingIndicator: true,
      supportsReadReceipts: true,
      supportsDeliveryReceipts: true,
      supportsVoice: true,
      supportsVideo: true,
      maxMessageLength: 65536, // WhatsApp limit
    };
  }
  
  /**
   * Normalize WhatsApp message to unified format
   */
  async normalizeMessage(platformMessage: WhatsAppMessage): Promise<UnifiedMessage | null> {
    try {
      const db = await getDb();
      if (!db) return null;
      
      // Get contact info from database
      const [contact] = await db.select().from(whatsappContacts)
        .where(and(
          eq(whatsappContacts.userId, this.userId),
          eq(whatsappContacts.phone, platformMessage.from)
        ))
        .limit(1);
      
      return {
        id: platformMessage.id,
        platform: 'whatsapp',
        connectorId: this.connectorId,
        conversationId: platformMessage.chatId,
        senderId: platformMessage.from,
        senderName: contact?.name || platformMessage.from,
        textContent: platformMessage.body,
        timestamp: new Date(platformMessage.timestamp * 1000),
        direction: platformMessage.isFromMe ? 'outgoing' : 'incoming',
        status: 'delivered',
        metadata: {
          hasMedia: platformMessage.hasMedia,
          mediaType: platformMessage.mediaType,
          mediaUrl: platformMessage.mediaUrl,
          isGroup: contact?.isGroup || false,
        },
      };
    } catch (error) {
      console.error('[WhatsAppPlatformConnector] Error normalizing message:', error);
      return null;
    }
  }
  
  /**
   * Denormalize unified message to WhatsApp format
   */
  async denormalizeMessage(unifiedMessage: UnifiedMessage): Promise<WhatsAppMessage> {
    return {
      id: unifiedMessage.id,
      chatId: unifiedMessage.conversationId,
      from: unifiedMessage.senderId,
      to: unifiedMessage.conversationId, // WhatsApp uses chatId for recipient
      body: unifiedMessage.textContent,
      timestamp: Math.floor(unifiedMessage.timestamp.getTime() / 1000),
      isFromMe: unifiedMessage.direction === 'outgoing',
      hasMedia: !!unifiedMessage.attachments && unifiedMessage.attachments.length > 0,
      mediaType: unifiedMessage.attachments?.[0]?.type,
      mediaUrl: unifiedMessage.attachments?.[0]?.url,
    };
  }
  
  /**
   * Send message
   */
  async sendMessage(message: UnifiedMessage): Promise<SendResult> {
    try {
      // Get phone number from conversation ID (chatId)
      const phone = message.conversationId.replace('@c.us', '').replace('@g.us', '');
      
      // Send message
      await this.whatsappConnector.sendMessage(phone, message.textContent);
      
      // Save to database
      const db = await getDb();
      if (db) {
        await db.insert(whatsappMessages).values({
          userId: this.userId,
          contactId: await this.getContactIdByPhone(phone),
          messageId: message.id,
          content: message.textContent,
          timestamp: message.timestamp,
          isFromMe: true,
          hasMedia: false,
          sentiment: null,
        });
      }
      
      return {
        success: true,
        messageId: message.id,
        timestamp: new Date(),
      };
    } catch (error) {
      console.error('[WhatsAppPlatformConnector] Error sending message:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }
  
  /**
   * Get conversation history
   */
  async getConversationHistory(
    conversationId: string,
    limit: number = 50
  ): Promise<UnifiedMessage[]> {
    try {
      const db = await getDb();
      if (!db) return [];
      
      // Get contact by phone
      const phone = conversationId.replace('@c.us', '').replace('@g.us', '');
      const [contact] = await db.select().from(whatsappContacts)
        .where(and(
          eq(whatsappContacts.userId, this.userId),
          eq(whatsappContacts.phone, phone)
        ))
        .limit(1);
      
      if (!contact) return [];
      
      // Get messages
      const messages = await db.select().from(whatsappMessages)
        .where(and(
          eq(whatsappMessages.userId, this.userId),
          eq(whatsappMessages.contactId, contact.id)
        ))
        .orderBy(desc(whatsappMessages.timestamp))
        .limit(limit);
      
      // Convert to unified format
      return messages.map(msg => ({
        id: msg.messageId,
        platform: 'whatsapp',
        connectorId: this.connectorId,
        conversationId,
        senderId: msg.isFromMe ? 'me' : phone,
        senderName: msg.isFromMe ? 'Me' : contact.name,
        textContent: msg.content || '',
        timestamp: msg.timestamp,
        direction: msg.isFromMe ? 'outgoing' : 'incoming',
        status: 'delivered',
        metadata: {
          hasMedia: msg.hasMedia,
          sentiment: msg.sentiment,
        },
      })).reverse(); // Oldest first
    } catch (error) {
      console.error('[WhatsAppPlatformConnector] Error getting conversation history:', error);
      return [];
    }
  }
  
  /**
   * Show typing indicator
   */
  async showTypingIndicator(conversationId: string, duration: number): Promise<void> {
    // WhatsApp Web.js doesn't support typing indicators programmatically
    // This is a limitation of the unofficial API
    console.log(`[WhatsAppPlatformConnector] Typing indicator not supported (${duration}s)`);
  }
  
  /**
   * Mark as read
   */
  async markAsRead(conversationId: string, messageId: string): Promise<void> {
    // WhatsApp Web.js auto-marks as read when messages are received
    console.log(`[WhatsAppPlatformConnector] Message ${messageId} marked as read`);
  }
  
  /**
   * Get contact ID by phone number
   */
  private async getContactIdByPhone(phone: string): Promise<number> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const [contact] = await db.select().from(whatsappContacts)
      .where(and(
        eq(whatsappContacts.userId, this.userId),
        eq(whatsappContacts.phone, phone)
      ))
      .limit(1);
    
    if (!contact) {
      throw new Error(`Contact not found for phone: ${phone}`);
    }
    
    return contact.id;
  }
  
  /**
   * Get sender profile information
   */
  async getSenderProfile(senderId: string): Promise<{
    name: string;
    relationship: string;
    communicationStyle?: string;
  } | null> {
    try {
      const db = await getDb();
      if (!db) return null;
      
      const phone = senderId.replace('@c.us', '').replace('@g.us', '');
      const [contact] = await db.select().from(whatsappContacts)
        .where(and(
          eq(whatsappContacts.userId, this.userId),
          eq(whatsappContacts.phone, phone)
        ))
        .limit(1);
      
      if (!contact) return null;
      
      // Determine relationship based on message frequency and score
      let relationship = 'acquaintance';
      const score = contact.relationshipScore ? parseFloat(contact.relationshipScore) : 0;
      
      if (score > 80) relationship = 'close_friend';
      else if (score > 60) relationship = 'friend';
      else if (score > 40) relationship = 'colleague';
      
      return {
        name: contact.name,
        relationship,
        communicationStyle: contact.isGroup ? 'group' : 'personal',
      };
    } catch (error) {
      console.error('[WhatsAppPlatformConnector] Error getting sender profile:', error);
      return null;
    }
  }
}

/**
 * Factory function to create WhatsApp connector
 */
export function createWhatsAppPlatformConnector(userId: number): WhatsAppPlatformConnector {
  const connectorId = `whatsapp-${userId}`;
  return new WhatsAppPlatformConnector(userId, connectorId);
}
