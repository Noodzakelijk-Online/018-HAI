/**
 * Twitter/X Platform Connector
 * 
 * Enables autonomous communication via Twitter/X (tweets, DMs, mentions, replies).
 */

import { BasePlatformConnector, UnifiedMessage, SendMessageResult, ConversationHistory, SenderProfile } from '../BasePlatformConnector';

export interface TwitterConfig {
  apiKey: string;
  apiSecret: string;
  accessToken: string;
  accessTokenSecret: string;
  bearerToken: string;
}

/**
 * Twitter Platform Connector
 * 
 * Supports:
 * - Direct Messages (DMs)
 * - Mentions and replies
 * - Tweet threads
 * - Media attachments
 * - Character limit handling (280 chars)
 */
export class TwitterPlatformConnector extends BasePlatformConnector {
  private config: TwitterConfig;
  private apiBaseUrl = 'https://api.twitter.com/2';
  
  constructor(connectorId: string, config: TwitterConfig) {
    super(connectorId, 'twitter');
    this.config = config;
  }
  
  /**
   * Send message (DM or tweet reply)
   */
  async sendMessage(message: UnifiedMessage): Promise<SendMessageResult> {
    try {
      // Determine if this is a DM or a tweet reply
      const isDM = message.conversationId.startsWith('dm-');
      
      if (isDM) {
        return await this.sendDirectMessage(message);
      } else {
        return await this.sendTweetReply(message);
      }
    } catch (error) {
      console.error('[TwitterConnector] Send error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }
  
  /**
   * Send direct message
   */
  private async sendDirectMessage(message: UnifiedMessage): Promise<SendMessageResult> {
    const recipientId = message.conversationId.replace('dm-', '');
    
    // Handle character limit (DMs have 10,000 char limit)
    let text = message.textContent;
    if (text.length > 10000) {
      text = text.substring(0, 9997) + '...';
    }
    
    const response = await fetch(`${this.apiBaseUrl}/dm_conversations/with/${recipientId}/messages`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.config.bearerToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text,
        attachments: message.attachments?.map(a => ({
          media_id: a.url, // Assuming media is already uploaded
        })),
      }),
    });
    
    if (!response.ok) {
      throw new Error(`Twitter API error: ${response.statusText}`);
    }
    
    const data = await response.json();
    
    return {
      success: true,
      messageId: data.data.dm_event_id,
      timestamp: new Date(),
    };
  }
  
  /**
   * Send tweet reply
   */
  private async sendTweetReply(message: UnifiedMessage): Promise<SendMessageResult> {
    const tweetId = message.conversationId.replace('tweet-', '');
    
    // Handle character limit (280 chars for tweets)
    let text = message.textContent;
    if (text.length > 280) {
      // Split into thread if needed
      return await this.sendTweetThread(tweetId, text);
    }
    
    const response = await fetch(`${this.apiBaseUrl}/tweets`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.config.bearerToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text,
        reply: {
          in_reply_to_tweet_id: tweetId,
        },
      }),
    });
    
    if (!response.ok) {
      throw new Error(`Twitter API error: ${response.statusText}`);
    }
    
    const data = await response.json();
    
    return {
      success: true,
      messageId: data.data.id,
      timestamp: new Date(),
    };
  }
  
  /**
   * Send tweet thread (for messages > 280 chars)
   */
  private async sendTweetThread(replyToId: string, fullText: string): Promise<SendMessageResult> {
    const tweets = this.splitIntoTweets(fullText);
    let previousTweetId = replyToId;
    
    for (const tweetText of tweets) {
      const response = await fetch(`${this.apiBaseUrl}/tweets`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.config.bearerToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text: tweetText,
          reply: {
            in_reply_to_tweet_id: previousTweetId,
          },
        }),
      });
      
      if (!response.ok) {
        throw new Error(`Twitter API error: ${response.statusText}`);
      }
      
      const data = await response.json();
      previousTweetId = data.data.id;
    }
    
    return {
      success: true,
      messageId: previousTweetId,
      timestamp: new Date(),
    };
  }
  
  /**
   * Split long text into tweet-sized chunks
   */
  private splitIntoTweets(text: string): string[] {
    const maxLength = 270; // Leave room for thread indicators
    const tweets: string[] = [];
    
    let remaining = text;
    let index = 1;
    
    while (remaining.length > 0) {
      let chunk = remaining.substring(0, maxLength);
      
      // Try to break at sentence or word boundary
      if (remaining.length > maxLength) {
        const lastPeriod = chunk.lastIndexOf('. ');
        const lastSpace = chunk.lastIndexOf(' ');
        
        if (lastPeriod > maxLength * 0.7) {
          chunk = chunk.substring(0, lastPeriod + 1);
        } else if (lastSpace > maxLength * 0.7) {
          chunk = chunk.substring(0, lastSpace);
        }
      }
      
      tweets.push(`${chunk} (${index}/${Math.ceil(text.length / maxLength)})`);
      remaining = remaining.substring(chunk.length).trim();
      index++;
    }
    
    return tweets;
  }
  
  /**
   * Get conversation history
   */
  async getConversationHistory(conversationId: string, limit: number = 10): Promise<ConversationHistory> {
    try {
      const isDM = conversationId.startsWith('dm-');
      
      if (isDM) {
        return await this.getDMHistory(conversationId, limit);
      } else {
        return await this.getTweetThread(conversationId, limit);
      }
    } catch (error) {
      console.error('[TwitterConnector] Get history error:', error);
      return {
        conversationId,
        messages: [],
        participants: [],
      };
    }
  }
  
  /**
   * Get DM conversation history
   */
  private async getDMHistory(conversationId: string, limit: number): Promise<ConversationHistory> {
    const recipientId = conversationId.replace('dm-', '');
    
    const response = await fetch(
      `${this.apiBaseUrl}/dm_conversations/with/${recipientId}/dm_events?max_results=${limit}`,
      {
        headers: {
          'Authorization': `Bearer ${this.config.bearerToken}`,
        },
      }
    );
    
    if (!response.ok) {
      throw new Error(`Twitter API error: ${response.statusText}`);
    }
    
    const data = await response.json();
    
    const messages: UnifiedMessage[] = data.data?.map((event: any) => ({
      id: event.id,
      platform: 'twitter',
      connectorId: this.connectorId,
      conversationId,
      senderId: event.sender_id,
      senderName: event.sender_id, // Would need to fetch user details
      textContent: event.text || '',
      timestamp: new Date(event.created_at),
      direction: event.sender_id === this.config.accessToken ? 'outgoing' : 'incoming',
      status: 'delivered',
    })) || [];
    
    return {
      conversationId,
      messages,
      participants: [recipientId],
    };
  }
  
  /**
   * Get tweet thread history
   */
  private async getTweetThread(conversationId: string, limit: number): Promise<ConversationHistory> {
    const tweetId = conversationId.replace('tweet-', '');
    
    const response = await fetch(
      `${this.apiBaseUrl}/tweets/${tweetId}?expansions=author_id,in_reply_to_user_id&tweet.fields=created_at,conversation_id`,
      {
        headers: {
          'Authorization': `Bearer ${this.config.bearerToken}`,
        },
      }
    );
    
    if (!response.ok) {
      throw new Error(`Twitter API error: ${response.statusText}`);
    }
    
    const data = await response.json();
    
    const message: UnifiedMessage = {
      id: data.data.id,
      platform: 'twitter',
      connectorId: this.connectorId,
      conversationId,
      senderId: data.data.author_id,
      senderName: data.includes?.users?.[0]?.username || data.data.author_id,
      textContent: data.data.text,
      timestamp: new Date(data.data.created_at),
      direction: 'incoming',
      status: 'delivered',
    };
    
    return {
      conversationId,
      messages: [message],
      participants: [data.data.author_id],
    };
  }
  
  /**
   * Get sender profile
   */
  async getSenderProfile(senderId: string): Promise<SenderProfile> {
    try {
      const response = await fetch(
        `${this.apiBaseUrl}/users/${senderId}?user.fields=created_at,description,public_metrics,verified`,
        {
          headers: {
            'Authorization': `Bearer ${this.config.bearerToken}`,
          },
        }
      );
      
      if (!response.ok) {
        throw new Error(`Twitter API error: ${response.statusText}`);
      }
      
      const data = await response.json();
      const user = data.data;
      
      // Determine relationship type based on followers/following
      let relationshipType: SenderProfile['relationshipType'] = 'acquaintance';
      if (user.public_metrics?.followers_count > 10000) {
        relationshipType = 'public_figure';
      } else if (user.verified) {
        relationshipType = 'professional';
      }
      
      return {
        id: senderId,
        name: user.name,
        username: user.username,
        platform: 'twitter',
        relationshipType,
        relationshipScore: user.public_metrics?.followers_count > 1000 ? 8 : 5,
        metadata: {
          verified: user.verified,
          followers: user.public_metrics?.followers_count,
          following: user.public_metrics?.following_count,
          bio: user.description,
          joinedDate: user.created_at,
        },
      };
    } catch (error) {
      console.error('[TwitterConnector] Get profile error:', error);
      return {
        id: senderId,
        name: senderId,
        platform: 'twitter',
        relationshipType: 'acquaintance',
        relationshipScore: 5,
      };
    }
  }
  
  /**
   * Check connection health
   */
  async checkConnection(): Promise<boolean> {
    try {
      const response = await fetch(`${this.apiBaseUrl}/users/me`, {
        headers: {
          'Authorization': `Bearer ${this.config.bearerToken}`,
        },
      });
      
      return response.ok;
    } catch (error) {
      console.error('[TwitterConnector] Connection check error:', error);
      return false;
    }
  }
}
