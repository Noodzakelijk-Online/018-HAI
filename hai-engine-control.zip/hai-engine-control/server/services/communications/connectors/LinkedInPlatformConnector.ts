/**
 * LinkedIn Platform Connector
 * 
 * Enables autonomous communication via LinkedIn (messages, connection requests, post comments).
 */

import { BasePlatformConnector, UnifiedMessage, SendMessageResult, ConversationHistory, SenderProfile } from '../BasePlatformConnector';

export interface LinkedInConfig {
  accessToken: string;
  clientId: string;
  clientSecret: string;
}

/**
 * LinkedIn Platform Connector
 * 
 * Supports:
 * - Direct messages
 * - Connection requests with personalized notes
 * - Post comments and replies
 * - Professional tone adaptation
 * - InMail support
 */
export class LinkedInPlatformConnector extends BasePlatformConnector {
  private config: LinkedInConfig;
  private apiBaseUrl = 'https://api.linkedin.com/v2';
  
  constructor(connectorId: string, config: LinkedInConfig) {
    super(connectorId, 'linkedin');
    this.config = config;
  }
  
  /**
   * Send message
   */
  async sendMessage(message: UnifiedMessage): Promise<SendMessageResult> {
    try {
      // Determine message type based on conversation ID
      if (message.conversationId.startsWith('connection-')) {
        return await this.sendConnectionRequest(message);
      } else if (message.conversationId.startsWith('post-')) {
        return await this.sendPostComment(message);
      } else {
        return await this.sendDirectMessage(message);
      }
    } catch (error) {
      console.error('[LinkedInConnector] Send error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }
  
  /**
   * Send direct message
   */
  private async sendDirectMessage(message: UnifiedMessage): Promise<SendMessageResult> {
    const recipientUrn = `urn:li:person:${message.senderId}`;
    
    // LinkedIn messages have a 1900 character limit
    let text = message.textContent;
    if (text.length > 1900) {
      text = text.substring(0, 1897) + '...';
    }
    
    const response = await fetch(`${this.apiBaseUrl}/messages`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.config.accessToken}`,
        'Content-Type': 'application/json',
        'X-Restli-Protocol-Version': '2.0.0',
      },
      body: JSON.stringify({
        recipients: [recipientUrn],
        subject: message.metadata?.subject || 'Message',
        body: text,
      }),
    });
    
    if (!response.ok) {
      throw new Error(`LinkedIn API error: ${response.statusText}`);
    }
    
    const data = await response.json();
    
    return {
      success: true,
      messageId: data.value?.messageUrn || `msg-${Date.now()}`,
      timestamp: new Date(),
    };
  }
  
  /**
   * Send connection request with personalized note
   */
  private async sendConnectionRequest(message: UnifiedMessage): Promise<SendMessageResult> {
    const recipientId = message.conversationId.replace('connection-', '');
    const recipientUrn = `urn:li:person:${recipientId}`;
    
    // Connection notes have a 300 character limit
    let note = message.textContent;
    if (note.length > 300) {
      note = note.substring(0, 297) + '...';
    }
    
    const response = await fetch(`${this.apiBaseUrl}/invitations`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.config.accessToken}`,
        'Content-Type': 'application/json',
        'X-Restli-Protocol-Version': '2.0.0',
      },
      body: JSON.stringify({
        invitee: {
          'com.linkedin.voyager.growth.invitation.InviteeProfile': {
            profileId: recipientId,
          },
        },
        message: note,
      }),
    });
    
    if (!response.ok) {
      throw new Error(`LinkedIn API error: ${response.statusText}`);
    }
    
    return {
      success: true,
      messageId: `invitation-${recipientId}-${Date.now()}`,
      timestamp: new Date(),
    };
  }
  
  /**
   * Send post comment
   */
  private async sendPostComment(message: UnifiedMessage): Promise<SendMessageResult> {
    const postId = message.conversationId.replace('post-', '');
    const postUrn = `urn:li:share:${postId}`;
    
    // Comments have a 1250 character limit
    let text = message.textContent;
    if (text.length > 1250) {
      text = text.substring(0, 1247) + '...';
    }
    
    const response = await fetch(`${this.apiBaseUrl}/socialActions/${postUrn}/comments`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.config.accessToken}`,
        'Content-Type': 'application/json',
        'X-Restli-Protocol-Version': '2.0.0',
      },
      body: JSON.stringify({
        actor: `urn:li:person:${this.config.clientId}`,
        message: {
          text,
        },
      }),
    });
    
    if (!response.ok) {
      throw new Error(`LinkedIn API error: ${response.statusText}`);
    }
    
    const data = await response.json();
    
    return {
      success: true,
      messageId: data.value?.id || `comment-${Date.now()}`,
      timestamp: new Date(),
    };
  }
  
  /**
   * Get conversation history
   */
  async getConversationHistory(conversationId: string, limit: number = 10): Promise<ConversationHistory> {
    try {
      const response = await fetch(
        `${this.apiBaseUrl}/conversations/${conversationId}/events?count=${limit}`,
        {
          headers: {
            'Authorization': `Bearer ${this.config.accessToken}`,
            'X-Restli-Protocol-Version': '2.0.0',
          },
        }
      );
      
      if (!response.ok) {
        throw new Error(`LinkedIn API error: ${response.statusText}`);
      }
      
      const data = await response.json();
      
      const messages: UnifiedMessage[] = data.elements?.map((event: any) => ({
        id: event.entityUrn,
        platform: 'linkedin',
        connectorId: this.connectorId,
        conversationId,
        senderId: event.from?.participant || 'unknown',
        senderName: event.from?.participant || 'Unknown',
        textContent: event.eventContent?.['com.linkedin.voyager.messaging.event.MessageEvent']?.attributedBody?.text || '',
        timestamp: new Date(event.createdAt),
        direction: event.from?.participant === this.config.clientId ? 'outgoing' : 'incoming',
        status: 'delivered',
      })) || [];
      
      return {
        conversationId,
        messages,
        participants: data.participants || [],
      };
    } catch (error) {
      console.error('[LinkedInConnector] Get history error:', error);
      return {
        conversationId,
        messages: [],
        participants: [],
      };
    }
  }
  
  /**
   * Get sender profile
   */
  async getSenderProfile(senderId: string): Promise<SenderProfile> {
    try {
      const response = await fetch(
        `${this.apiBaseUrl}/people/(id:${senderId})?projection=(id,firstName,lastName,headline,industry,positions)`,
        {
          headers: {
            'Authorization': `Bearer ${this.config.accessToken}`,
            'X-Restli-Protocol-Version': '2.0.0',
          },
        }
      );
      
      if (!response.ok) {
        throw new Error(`LinkedIn API error: ${response.statusText}`);
      }
      
      const data = await response.json();
      
      // Determine relationship type based on connection degree and industry
      let relationshipType: SenderProfile['relationshipType'] = 'professional';
      if (data.positions?.values?.[0]) {
        const currentPosition = data.positions.values[0];
        if (currentPosition.company?.name) {
          relationshipType = 'colleague'; // Same company
        }
      }
      
      // Calculate relationship score based on connection strength
      let relationshipScore = 6; // Default for LinkedIn connections
      if (data.connectionDegree === '1ST') {
        relationshipScore = 8; // Direct connection
      } else if (data.connectionDegree === '2ND') {
        relationshipScore = 6; // 2nd degree
      } else {
        relationshipScore = 4; // 3rd degree or no connection
      }
      
      return {
        id: senderId,
        name: `${data.firstName} ${data.lastName}`,
        username: senderId,
        platform: 'linkedin',
        relationshipType,
        relationshipScore,
        metadata: {
          headline: data.headline,
          industry: data.industry,
          currentPosition: data.positions?.values?.[0]?.title,
          currentCompany: data.positions?.values?.[0]?.company?.name,
          connectionDegree: data.connectionDegree,
        },
      };
    } catch (error) {
      console.error('[LinkedInConnector] Get profile error:', error);
      return {
        id: senderId,
        name: senderId,
        platform: 'linkedin',
        relationshipType: 'professional',
        relationshipScore: 6,
      };
    }
  }
  
  /**
   * Check connection health
   */
  async checkConnection(): Promise<boolean> {
    try {
      const response = await fetch(`${this.apiBaseUrl}/me`, {
        headers: {
          'Authorization': `Bearer ${this.config.accessToken}`,
          'X-Restli-Protocol-Version': '2.0.0',
        },
      });
      
      return response.ok;
    } catch (error) {
      console.error('[LinkedInConnector] Connection check error:', error);
      return false;
    }
  }
  
  /**
   * Adapt tone for LinkedIn (always professional)
   */
  adaptToneForLinkedIn(message: string, relationshipType: string): string {
    // LinkedIn requires professional tone regardless of relationship
    // Remove casual language, emojis, slang
    let adapted = message;
    
    // Remove emojis
    adapted = adapted.replace(/[\u{1F600}-\u{1F64F}]/gu, '');
    adapted = adapted.replace(/[\u{1F300}-\u{1F5FF}]/gu, '');
    adapted = adapted.replace(/[\u{1F680}-\u{1F6FF}]/gu, '');
    adapted = adapted.replace(/[\u{2600}-\u{26FF}]/gu, '');
    
    // Replace casual greetings
    adapted = adapted.replace(/^hey\s+/i, 'Hello ');
    adapted = adapted.replace(/^hi\s+/i, 'Hello ');
    adapted = adapted.replace(/^yo\s+/i, 'Hello ');
    
    // Replace casual closings
    adapted = adapted.replace(/\s+cheers!?$/i, ' Best regards');
    adapted = adapted.replace(/\s+thanks!$/i, ' Thank you');
    adapted = adapted.replace(/\s+thx!?$/i, ' Thank you');
    
    return adapted;
  }
}
