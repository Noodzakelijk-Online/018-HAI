/**
 * SMS Platform Connector
 * 
 * Integrates SMS (via Twilio) with the autonomous communication system.
 * Extends BasePlatformConnector to provide unified interface.
 */

import { BasePlatformConnector, UnifiedMessage, SendResult, PlatformCapabilities } from '../BasePlatformConnector';

export class SMSPlatformConnector extends BasePlatformConnector {
  private userId: number;
  private twilioAccountSid?: string;
  private twilioAuthToken?: string;
  private twilioPhoneNumber?: string;
  
  constructor(userId: number, connectorId: string, config?: {
    accountSid?: string;
    authToken?: string;
    phoneNumber?: string;
  }) {
    super(connectorId, 'sms');
    this.userId = userId;
    this.twilioAccountSid = config?.accountSid;
    this.twilioAuthToken = config?.authToken;
    this.twilioPhoneNumber = config?.phoneNumber;
  }
  
  /**
   * Connect to Twilio
   */
  async connect(): Promise<void> {
    if (!this.twilioAccountSid || !this.twilioAuthToken || !this.twilioPhoneNumber) {
      throw new Error('Twilio credentials not configured');
    }
    
    // Verify credentials by making a test API call
    try {
      // In a real implementation, this would verify Twilio credentials
      this.emit('connected');
    } catch (error) {
      this.emit('error', new Error('Failed to connect to Twilio'));
      throw error;
    }
  }
  
  /**
   * Disconnect from Twilio
   */
  async disconnect(): Promise<void> {
    // No persistent connection to close
    this.emit('disconnected');
  }
  
  /**
   * Check if connected
   */
  isConnected(): boolean {
    return !!(this.twilioAccountSid && this.twilioAuthToken && this.twilioPhoneNumber);
  }
  
  /**
   * Get platform capabilities
   */
  getCapabilities(): PlatformCapabilities {
    return {
      supportsRichText: false,
      supportsAttachments: true, // MMS
      supportsThreads: false,
      supportsReactions: false,
      supportsTypingIndicator: false,
      supportsReadReceipts: false,
      supportsDeliveryReceipts: true,
      supportsVoice: false,
      supportsVideo: false,
      maxMessageLength: 1600, // SMS limit (segmented messages)
    };
  }
  
  /**
   * Normalize SMS message to unified format
   */
  async normalizeMessage(platformMessage: any): Promise<UnifiedMessage | null> {
    try {
      return {
        id: platformMessage.sid,
        platform: 'sms',
        connectorId: this.connectorId,
        conversationId: platformMessage.from, // Use phone number as conversation ID
        senderId: platformMessage.from,
        senderName: this.formatPhoneNumber(platformMessage.from),
        textContent: platformMessage.body,
        timestamp: new Date(platformMessage.dateCreated),
        direction: platformMessage.direction === 'outbound-api' ? 'outgoing' : 'incoming',
        status: this.mapTwilioStatus(platformMessage.status),
        metadata: {
          numSegments: platformMessage.numSegments,
          numMedia: platformMessage.numMedia,
          price: platformMessage.price,
          priceUnit: platformMessage.priceUnit,
        },
        attachments: platformMessage.mediaUrls?.map((url: string, index: number) => ({
          type: 'image',
          url,
          name: `media-${index}`,
        })),
      };
    } catch (error) {
      console.error('[SMSPlatformConnector] Error normalizing message:', error);
      return null;
    }
  }
  
  /**
   * Denormalize unified message to Twilio format
   */
  async denormalizeMessage(unifiedMessage: UnifiedMessage): Promise<any> {
    return {
      to: unifiedMessage.conversationId,
      from: this.twilioPhoneNumber,
      body: unifiedMessage.textContent,
      mediaUrl: unifiedMessage.attachments?.map(att => att.url),
    };
  }
  
  /**
   * Send SMS
   */
  async sendMessage(message: UnifiedMessage): Promise<SendResult> {
    try {
      if (!this.isConnected()) {
        throw new Error('Not connected to Twilio');
      }
      
      // Validate phone number
      const phoneNumber = this.normalizePhoneNumber(message.conversationId);
      if (!phoneNumber) {
        throw new Error('Invalid phone number');
      }
      
      // Check message length
      if (message.textContent.length > this.getCapabilities().maxMessageLength) {
        throw new Error(`Message too long (max ${this.getCapabilities().maxMessageLength} characters)`);
      }
      
      // In a real implementation, this would use Twilio API to send SMS
      console.log('[SMSPlatformConnector] Sending SMS:', {
        to: phoneNumber,
        from: this.twilioPhoneNumber,
        body: message.textContent,
      });
      
      return {
        success: true,
        messageId: message.id,
        timestamp: new Date(),
      };
    } catch (error) {
      console.error('[SMSPlatformConnector] Error sending SMS:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }
  
  /**
   * Get conversation history
   */
  async getConversationHistory(
    conversationId: string,
    limit: number = 50
  ): Promise<UnifiedMessage[]> {
    try {
      // In a real implementation, this would fetch SMS history from Twilio
      return [];
    } catch (error) {
      console.error('[SMSPlatformConnector] Error getting conversation history:', error);
      return [];
    }
  }
  
  /**
   * Show typing indicator (not supported for SMS)
   */
  async showTypingIndicator(conversationId: string, duration: number): Promise<void> {
    // SMS doesn't support typing indicators
  }
  
  /**
   * Mark as read (not supported for SMS)
   */
  async markAsRead(conversationId: string, messageId: string): Promise<void> {
    // SMS doesn't support read receipts
  }
  
  /**
   * Get sender profile information
   */
  async getSenderProfile(senderId: string): Promise<{
    name: string;
    relationship: string;
    communicationStyle?: string;
  } | null> {
    try {
      return {
        name: this.formatPhoneNumber(senderId),
        relationship: 'unknown',
        communicationStyle: 'casual',
      };
    } catch (error) {
      console.error('[SMSPlatformConnector] Error getting sender profile:', error);
      return null;
    }
  }
  
  /**
   * Format phone number for display
   */
  private formatPhoneNumber(phoneNumber: string): string {
    // Remove non-digit characters
    const digits = phoneNumber.replace(/\D/g, '');
    
    // Format as (XXX) XXX-XXXX for US numbers
    if (digits.length === 10) {
      return `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6)}`;
    } else if (digits.length === 11 && digits[0] === '1') {
      return `+1 (${digits.slice(1, 4)}) ${digits.slice(4, 7)}-${digits.slice(7)}`;
    }
    
    return phoneNumber;
  }
  
  /**
   * Normalize phone number to E.164 format
   */
  private normalizePhoneNumber(phoneNumber: string): string | null {
    // Remove non-digit characters
    const digits = phoneNumber.replace(/\D/g, '');
    
    // Add country code if missing (assume US)
    if (digits.length === 10) {
      return `+1${digits}`;
    } else if (digits.length === 11 && digits[0] === '1') {
      return `+${digits}`;
    } else if (digits.startsWith('+')) {
      return phoneNumber;
    }
    
    return null;
  }
  
  /**
   * Map Twilio status to unified status
   */
  private mapTwilioStatus(twilioStatus: string): UnifiedMessage['status'] {
    switch (twilioStatus) {
      case 'queued':
      case 'sending':
        return 'sending';
      case 'sent':
        return 'sent';
      case 'delivered':
        return 'delivered';
      case 'read':
        return 'read';
      case 'failed':
      case 'undelivered':
        return 'failed';
      default:
        return 'sent';
    }
  }
}

/**
 * Factory function to create SMS connector
 */
export function createSMSPlatformConnector(
  userId: number,
  config?: {
    accountSid?: string;
    authToken?: string;
    phoneNumber?: string;
  }
): SMSPlatformConnector {
  const connectorId = `sms-${userId}`;
  return new SMSPlatformConnector(userId, connectorId, config);
}
