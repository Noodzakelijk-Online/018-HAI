/**
 * Email Platform Connector
 * 
 * Integrates Gmail/email with the autonomous communication system.
 * Extends BasePlatformConnector to provide unified interface.
 */

import { BasePlatformConnector, UnifiedMessage, SendResult, PlatformCapabilities } from '../BasePlatformConnector';
import { GmailIntegrationService } from '../DigitalEcosystemIntegration';

export class EmailPlatformConnector extends BasePlatformConnector {
  private gmailService: GmailIntegrationService;
  private userId: number;
  
  constructor(userId: number, connectorId: string) {
    super(connectorId, 'email');
    this.userId = userId;
    this.gmailService = new GmailIntegrationService();
  }
  
  /**
   * Connect to Gmail
   */
  async connect(): Promise<void> {
    // Gmail connection is handled by OAuth
    // Just verify we can access the service
    try {
      await this.gmailService.searchEmails('test', 1);
      this.emit('connected');
    } catch (error) {
      this.emit('error', new Error('Failed to connect to Gmail'));
      throw error;
    }
  }
  
  /**
   * Disconnect from Gmail
   */
  async disconnect(): Promise<void> {
    // No persistent connection to close
    this.emit('disconnected');
  }
  
  /**
   * Check if connected
   */
  isConnected(): boolean {
    // Always connected if OAuth is valid
    return true;
  }
  
  /**
   * Get platform capabilities
   */
  getCapabilities(): PlatformCapabilities {
    return {
      supportsRichText: true,
      supportsAttachments: true,
      supportsThreads: true,
      supportsReactions: false,
      supportsTypingIndicator: false,
      supportsReadReceipts: true,
      supportsDeliveryReceipts: true,
      supportsVoice: false,
      supportsVideo: false,
      maxMessageLength: 1000000, // Gmail limit is very high
    };
  }
  
  /**
   * Normalize Gmail message to unified format
   */
  async normalizeMessage(platformMessage: any): Promise<UnifiedMessage | null> {
    try {
      return {
        id: platformMessage.id,
        platform: 'email',
        connectorId: this.connectorId,
        conversationId: platformMessage.threadId || platformMessage.id,
        senderId: platformMessage.from,
        senderName: this.extractName(platformMessage.from),
        textContent: platformMessage.body,
        timestamp: new Date(platformMessage.date),
        direction: platformMessage.from.includes('me') ? 'outgoing' : 'incoming',
        status: 'delivered',
        metadata: {
          subject: platformMessage.subject,
          to: platformMessage.to,
          cc: platformMessage.cc,
          bcc: platformMessage.bcc,
          threadId: platformMessage.threadId,
          labels: platformMessage.labels,
          hasAttachments: platformMessage.attachments && platformMessage.attachments.length > 0,
        },
        attachments: platformMessage.attachments?.map((att: any) => ({
          type: att.mimeType,
          url: att.url,
          name: att.filename,
          size: att.size,
        })),
      };
    } catch (error) {
      console.error('[EmailPlatformConnector] Error normalizing message:', error);
      return null;
    }
  }
  
  /**
   * Denormalize unified message to Gmail format
   */
  async denormalizeMessage(unifiedMessage: UnifiedMessage): Promise<any> {
    return {
      id: unifiedMessage.id,
      threadId: unifiedMessage.conversationId,
      from: unifiedMessage.senderId,
      to: unifiedMessage.metadata?.to || unifiedMessage.conversationId,
      subject: unifiedMessage.metadata?.subject || 'Re: Conversation',
      body: unifiedMessage.textContent,
      date: unifiedMessage.timestamp.toISOString(),
      attachments: unifiedMessage.attachments?.map(att => ({
        filename: att.name,
        mimeType: att.type,
        url: att.url,
        size: att.size,
      })),
    };
  }
  
  /**
   * Send email
   */
  async sendMessage(message: UnifiedMessage): Promise<SendResult> {
    try {
      // In a real implementation, this would use Gmail API to send email
      // For now, we'll simulate success
      console.log('[EmailPlatformConnector] Sending email:', {
        to: message.metadata?.to || message.conversationId,
        subject: message.metadata?.subject,
        body: message.textContent,
      });
      
      return {
        success: true,
        messageId: message.id,
        timestamp: new Date(),
      };
    } catch (error) {
      console.error('[EmailPlatformConnector] Error sending email:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }
  
  /**
   * Get conversation history (email thread)
   */
  async getConversationHistory(
    conversationId: string,
    limit: number = 50
  ): Promise<UnifiedMessage[]> {
    try {
      // In a real implementation, this would fetch the email thread from Gmail
      // For now, return empty array
      return [];
    } catch (error) {
      console.error('[EmailPlatformConnector] Error getting conversation history:', error);
      return [];
    }
  }
  
  /**
   * Show typing indicator (not supported for email)
   */
  async showTypingIndicator(conversationId: string, duration: number): Promise<void> {
    // Email doesn't support typing indicators
  }
  
  /**
   * Mark as read
   */
  async markAsRead(conversationId: string, messageId: string): Promise<void> {
    console.log(`[EmailPlatformConnector] Marking email ${messageId} as read`);
    // In a real implementation, this would mark the email as read in Gmail
  }
  
  /**
   * Get sender profile information
   */
  async getSenderProfile(senderId: string): Promise<{
    name: string;
    relationship: string;
    communicationStyle?: string;
  } | null> {
    try {
      // Extract name from email address
      const name = this.extractName(senderId);
      
      // Determine relationship based on email domain
      let relationship = 'acquaintance';
      if (senderId.includes('@company.com')) {
        relationship = 'colleague';
      } else if (senderId.includes('@gmail.com')) {
        relationship = 'personal';
      }
      
      return {
        name,
        relationship,
        communicationStyle: 'formal',
      };
    } catch (error) {
      console.error('[EmailPlatformConnector] Error getting sender profile:', error);
      return null;
    }
  }
  
  /**
   * Extract name from email address
   */
  private extractName(email: string): string {
    // Extract name from "Name <email@domain.com>" format
    const match = email.match(/^(.+?)\s*<(.+?)>$/);
    if (match) {
      return match[1].trim();
    }
    
    // Extract name from email address (before @)
    const atIndex = email.indexOf('@');
    if (atIndex > 0) {
      const username = email.substring(0, atIndex);
      // Convert dots and underscores to spaces and capitalize
      return username
        .replace(/[._]/g, ' ')
        .split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
    }
    
    return email;
  }
}

/**
 * Factory function to create Email connector
 */
export function createEmailPlatformConnector(userId: number): EmailPlatformConnector {
  const connectorId = `email-${userId}`;
  return new EmailPlatformConnector(userId, connectorId);
}
