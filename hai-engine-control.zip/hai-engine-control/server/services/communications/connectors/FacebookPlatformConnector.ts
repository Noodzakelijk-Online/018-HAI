/**
 * Facebook Messenger Platform Connector
 * 
 * Enables autonomous communication via Facebook Messenger.
 */

import { BasePlatformConnector, UnifiedMessage, SendMessageResult, ConversationHistory, SenderProfile } from '../BasePlatformConnector';

export interface FacebookConfig {
  pageAccessToken: string;
  appId: string;
  appSecret: string;
  verifyToken: string;
}

/**
 * Facebook Messenger Platform Connector
 * 
 * Supports:
 * - Direct messages
 * - Reactions and stickers
 * - Media attachments (images, videos, audio, files)
 * - Read receipts
 * - Typing indicators
 * - Quick replies
 */
export class FacebookPlatformConnector extends BasePlatformConnector {
  private config: FacebookConfig;
  private apiBaseUrl = 'https://graph.facebook.com/v18.0';
  
  constructor(connectorId: string, config: FacebookConfig) {
    super(connectorId, 'facebook');
    this.config = config;
  }
  
  /**
   * Send message
   */
  async sendMessage(message: UnifiedMessage): Promise<SendMessageResult> {
    try {
      // Send typing indicator first for natural feel
      await this.sendTypingIndicator(message.senderId, true);
      
      // Simulate typing delay based on message length
      const typingDelay = Math.min(message.textContent.length * 50, 3000);
      await new Promise(resolve => setTimeout(resolve, typingDelay));
      
      // Send the actual message
      const result = await this.sendMessengerMessage(message);
      
      // Turn off typing indicator
      await this.sendTypingIndicator(message.senderId, false);
      
      return result;
    } catch (error) {
      console.error('[FacebookConnector] Send error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }
  
  /**
   * Send Messenger message
   */
  private async sendMessengerMessage(message: UnifiedMessage): Promise<SendMessageResult> {
    const messageData: any = {
      recipient: {
        id: message.senderId,
      },
      message: {
        text: message.textContent,
      },
    };
    
    // Add attachments if present
    if (message.attachments && message.attachments.length > 0) {
      messageData.message.attachment = {
        type: this.getAttachmentType(message.attachments[0].mimeType),
        payload: {
          url: message.attachments[0].url,
          is_reusable: true,
        },
      };
      
      // If there's text with attachment, send text separately
      if (message.textContent) {
        delete messageData.message.attachment;
      }
    }
    
    const response = await fetch(
      `${this.apiBaseUrl}/me/messages?access_token=${this.config.pageAccessToken}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(messageData),
      }
    );
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(`Facebook API error: ${error.error?.message || response.statusText}`);
    }
    
    const data = await response.json();
    
    // Send attachments separately if we have both text and attachments
    if (message.attachments && message.attachments.length > 0 && message.textContent) {
      for (const attachment of message.attachments) {
        await this.sendAttachment(message.senderId, attachment.url, attachment.mimeType);
      }
    }
    
    return {
      success: true,
      messageId: data.message_id,
      timestamp: new Date(),
    };
  }
  
  /**
   * Send attachment
   */
  private async sendAttachment(recipientId: string, url: string, mimeType: string): Promise<void> {
    const messageData = {
      recipient: {
        id: recipientId,
      },
      message: {
        attachment: {
          type: this.getAttachmentType(mimeType),
          payload: {
            url,
            is_reusable: true,
          },
        },
      },
    };
    
    await fetch(
      `${this.apiBaseUrl}/me/messages?access_token=${this.config.pageAccessToken}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(messageData),
      }
    );
  }
  
  /**
   * Get attachment type from MIME type
   */
  private getAttachmentType(mimeType: string): string {
    if (mimeType.startsWith('image/')) return 'image';
    if (mimeType.startsWith('video/')) return 'video';
    if (mimeType.startsWith('audio/')) return 'audio';
    return 'file';
  }
  
  /**
   * Send typing indicator
   */
  private async sendTypingIndicator(recipientId: string, typing: boolean): Promise<void> {
    try {
      await fetch(
        `${this.apiBaseUrl}/me/messages?access_token=${this.config.pageAccessToken}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            recipient: {
              id: recipientId,
            },
            sender_action: typing ? 'typing_on' : 'typing_off',
          }),
        }
      );
    } catch (error) {
      // Ignore typing indicator errors
      console.warn('[FacebookConnector] Typing indicator error:', error);
    }
  }
  
  /**
   * Mark message as read
   */
  async markAsRead(senderId: string): Promise<void> {
    try {
      await fetch(
        `${this.apiBaseUrl}/me/messages?access_token=${this.config.pageAccessToken}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            recipient: {
              id: senderId,
            },
            sender_action: 'mark_seen',
          }),
        }
      );
    } catch (error) {
      console.warn('[FacebookConnector] Mark read error:', error);
    }
  }
  
  /**
   * Get conversation history
   */
  async getConversationHistory(conversationId: string, limit: number = 10): Promise<ConversationHistory> {
    try {
      const response = await fetch(
        `${this.apiBaseUrl}/${conversationId}/messages?fields=id,from,to,message,created_time,attachments&limit=${limit}&access_token=${this.config.pageAccessToken}`,
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );
      
      if (!response.ok) {
        throw new Error(`Facebook API error: ${response.statusText}`);
      }
      
      const data = await response.json();
      
      const messages: UnifiedMessage[] = data.data?.map((msg: any) => ({
        id: msg.id,
        platform: 'facebook',
        connectorId: this.connectorId,
        conversationId,
        senderId: msg.from.id,
        senderName: msg.from.name || msg.from.id,
        textContent: msg.message || '',
        timestamp: new Date(msg.created_time),
        direction: msg.from.id === this.config.appId ? 'outgoing' : 'incoming',
        status: 'delivered',
        attachments: msg.attachments?.data?.map((att: any) => ({
          type: att.mime_type?.startsWith('image/') ? 'image' : 'file',
          url: att.image_data?.url || att.file_url,
          mimeType: att.mime_type,
          filename: att.name,
        })),
      })) || [];
      
      return {
        conversationId,
        messages,
        participants: data.participants?.data?.map((p: any) => p.id) || [],
      };
    } catch (error) {
      console.error('[FacebookConnector] Get history error:', error);
      return {
        conversationId,
        messages: [],
        participants: [],
      };
    }
  }
  
  /**
   * Get sender profile
   */
  async getSenderProfile(senderId: string): Promise<SenderProfile> {
    try {
      const response = await fetch(
        `${this.apiBaseUrl}/${senderId}?fields=id,name,first_name,last_name,profile_pic&access_token=${this.config.pageAccessToken}`,
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );
      
      if (!response.ok) {
        throw new Error(`Facebook API error: ${response.statusText}`);
      }
      
      const data = await response.json();
      
      // Facebook doesn't provide relationship info, default to friend
      return {
        id: senderId,
        name: data.name || `${data.first_name} ${data.last_name}`,
        username: senderId,
        platform: 'facebook',
        relationshipType: 'friend',
        relationshipScore: 7, // Default for Facebook connections
        metadata: {
          firstName: data.first_name,
          lastName: data.last_name,
          profilePic: data.profile_pic,
        },
      };
    } catch (error) {
      console.error('[FacebookConnector] Get profile error:', error);
      return {
        id: senderId,
        name: senderId,
        platform: 'facebook',
        relationshipType: 'friend',
        relationshipScore: 7,
      };
    }
  }
  
  /**
   * Send reaction to message
   */
  async sendReaction(messageId: string, reaction: string): Promise<boolean> {
    try {
      const response = await fetch(
        `${this.apiBaseUrl}/${messageId}/reactions?access_token=${this.config.pageAccessToken}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            reaction,
          }),
        }
      );
      
      return response.ok;
    } catch (error) {
      console.error('[FacebookConnector] Send reaction error:', error);
      return false;
    }
  }
  
  /**
   * Check connection health
   */
  async checkConnection(): Promise<boolean> {
    try {
      const response = await fetch(
        `${this.apiBaseUrl}/me?access_token=${this.config.pageAccessToken}`,
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );
      
      return response.ok;
    } catch (error) {
      console.error('[FacebookConnector] Connection check error:', error);
      return false;
    }
  }
  
  /**
   * Handle webhook verification (for initial setup)
   */
  static verifyWebhook(mode: string, token: string, challenge: string, verifyToken: string): string | null {
    if (mode === 'subscribe' && token === verifyToken) {
      return challenge;
    }
    return null;
  }
  
  /**
   * Parse incoming webhook message
   */
  static parseWebhookMessage(webhookData: any): UnifiedMessage | null {
    try {
      const entry = webhookData.entry?.[0];
      const messaging = entry?.messaging?.[0];
      
      if (!messaging || !messaging.message) {
        return null;
      }
      
      return {
        id: messaging.message.mid,
        platform: 'facebook',
        connectorId: 'webhook',
        conversationId: messaging.sender.id,
        senderId: messaging.sender.id,
        senderName: messaging.sender.id,
        textContent: messaging.message.text || '',
        timestamp: new Date(messaging.timestamp),
        direction: 'incoming',
        status: 'delivered',
        attachments: messaging.message.attachments?.map((att: any) => ({
          type: att.type,
          url: att.payload?.url,
          mimeType: att.type === 'image' ? 'image/jpeg' : 'application/octet-stream',
        })),
      };
    } catch (error) {
      console.error('[FacebookConnector] Parse webhook error:', error);
      return null;
    }
  }
}
