/**
 * Triple-Layer Analysis Engine
 * 
 * Implements the three-layer analysis system:
 * 1. Factual Verification - Verify facts against personal data
 * 2. Intent & Emotional Intelligence - Understand what they want and how they feel
 * 3. Outcome Evaluation - Ensure responses advance goals constructively
 */

import { invokeLLM } from '../../_core/llm';
import type { UnifiedMessage } from './BasePlatformConnector';

// ============================================================================
// LAYER 1: FACTUAL VERIFICATION
// ============================================================================

export interface FactualClaim {
  claim: string;
  confidence: number; // 0-100
  verified: boolean;
  source?: string; // Where the fact was verified
  contradictions?: string[]; // Contradictory information found
}

export interface FactualVerificationResult {
  claims: FactualClaim[];
  overallConfidence: number; // 0-100
  hasUnverifiedClaims: boolean;
  hasContradictions: boolean;
  verificationSources: string[]; // Which sources were checked
}

export class FactualVerificationService {
  /**
   * Extract factual claims from a message
   */
  private async extractClaims(message: string): Promise<string[]> {
    const response = await invokeLLM({
      messages: [
        {
          role: 'system',
          content: 'Extract all factual claims from the message. Return as JSON array of strings. Only include verifiable facts (dates, times, names, numbers, events), not opinions or questions.',
        },
        {
          role: 'user',
          content: message,
        },
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'factual_claims',
          strict: true,
          schema: {
            type: 'object',
            properties: {
              claims: {
                type: 'array',
                items: { type: 'string' },
                description: 'List of factual claims',
              },
            },
            required: ['claims'],
            additionalProperties: false,
          },
        },
      },
    });
    
    const result = JSON.parse(response.choices[0].message.content || '{"claims":[]}');
    return result.claims || [];
  }
  
  /**
   * Verify a claim against personal data sources
   */
  private async verifyClaim(claim: string, context: Record<string, any>): Promise<FactualClaim> {
    // TODO: Implement actual verification against:
    // - Gmail (search emails for mentions)
    // - Calendar (check events, meetings)
    // - Drive (search documents)
    // - Local files
    // - Previous conversations
    
    // For now, use LLM to assess claim plausibility
    const response = await invokeLLM({
      messages: [
        {
          role: 'system',
          content: 'Assess the factual claim. Determine if it can be verified, if it contradicts known information, and assign a confidence score (0-100). Return as JSON.',
        },
        {
          role: 'user',
          content: `Claim: "${claim}"\n\nContext: ${JSON.stringify(context, null, 2)}`,
        },
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'claim_verification',
          strict: true,
          schema: {
            type: 'object',
            properties: {
              verified: { type: 'boolean' },
              confidence: { type: 'number' },
              source: { type: 'string' },
              contradictions: {
                type: 'array',
                items: { type: 'string' },
              },
            },
            required: ['verified', 'confidence', 'source', 'contradictions'],
            additionalProperties: false,
          },
        },
      },
    });
    
    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      claim,
      confidence: result.confidence || 50,
      verified: result.verified || false,
      source: result.source,
      contradictions: result.contradictions || [],
    };
  }
  
  /**
   * Verify all facts in a message
   */
  async verify(message: UnifiedMessage, context: Record<string, any> = {}): Promise<FactualVerificationResult> {
    const claimTexts = await this.extractClaims(message.textContent);
    
    const claims = await Promise.all(
      claimTexts.map(claim => this.verifyClaim(claim, context))
    );
    
    const hasUnverifiedClaims = claims.some(c => !c.verified);
    const hasContradictions = claims.some(c => c.contradictions && c.contradictions.length > 0);
    
    const overallConfidence = claims.length > 0
      ? claims.reduce((sum, c) => sum + c.confidence, 0) / claims.length
      : 100; // No claims = nothing to verify = high confidence
    
    const verificationSources = Array.from(
      new Set(claims.map(c => c.source).filter(Boolean) as string[])
    );
    
    return {
      claims,
      overallConfidence,
      hasUnverifiedClaims,
      hasContradictions,
      verificationSources,
    };
  }
}

// ============================================================================
// LAYER 2: INTENT & EMOTIONAL INTELLIGENCE
// ============================================================================

export enum IntentType {
  QUESTION = 'question',
  REQUEST = 'request',
  STATEMENT = 'statement',
  GREETING = 'greeting',
  CONFIRMATION = 'confirmation',
  COMPLAINT = 'complaint',
  URGENT = 'urgent',
  CONFLICT = 'conflict',
}

export interface IntentClassification {
  primaryIntent: IntentType;
  secondaryIntents: IntentType[];
  confidence: number; // 0-100
}

export interface SentimentAnalysis {
  polarity: number; // -1.0 (negative) to +1.0 (positive)
  intensity: number; // 0.0 (mild) to 1.0 (extreme)
  primaryEmotion: string; // joy, anger, sadness, fear, surprise, disgust
  confidence: number; // 0-100
}

export interface UrgencyAssessment {
  score: number; // 0-100
  indicators: string[]; // What made it urgent
  confidence: number; // 0-100
}

export interface RelationshipContext {
  type: string; // family, friend, colleague, manager, client, etc.
  strength: number; // 0-100
  communicationFrequency: string; // daily, weekly, monthly, yearly, rare
  lastContact?: Date;
}

export interface IntentEmotionalResult {
  intent: IntentClassification;
  sentiment: SentimentAnalysis;
  urgency: UrgencyAssessment;
  relationship: RelationshipContext;
  stressLevel: number; // 0-100
  conflictDetected: boolean;
  sensitiveTopics: string[];
  overallConfidence: number; // 0-100
}

export class IntentAnalysisService {
  /**
   * Classify message intent
   */
  private async classifyIntent(message: string): Promise<IntentClassification> {
    const response = await invokeLLM({
      messages: [
        {
          role: 'system',
          content: 'Classify the intent of the message. Identify primary and secondary intents. Return as JSON.',
        },
        {
          role: 'user',
          content: message,
        },
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'intent_classification',
          strict: true,
          schema: {
            type: 'object',
            properties: {
              primaryIntent: {
                type: 'string',
                enum: ['question', 'request', 'statement', 'greeting', 'confirmation', 'complaint', 'urgent', 'conflict'],
              },
              secondaryIntents: {
                type: 'array',
                items: {
                  type: 'string',
                  enum: ['question', 'request', 'statement', 'greeting', 'confirmation', 'complaint', 'urgent', 'conflict'],
                },
              },
              confidence: { type: 'number' },
            },
            required: ['primaryIntent', 'secondaryIntents', 'confidence'],
            additionalProperties: false,
          },
        },
      },
    });
    
    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      primaryIntent: result.primaryIntent as IntentType,
      secondaryIntents: result.secondaryIntents as IntentType[],
      confidence: result.confidence || 50,
    };
  }
  
  /**
   * Analyze sentiment
   */
  private async analyzeSentiment(message: string): Promise<SentimentAnalysis> {
    const response = await invokeLLM({
      messages: [
        {
          role: 'system',
          content: 'Analyze the emotional tone and sentiment of the message. Return as JSON.',
        },
        {
          role: 'user',
          content: message,
        },
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'sentiment_analysis',
          strict: true,
          schema: {
            type: 'object',
            properties: {
              polarity: { type: 'number' }, // -1 to 1
              intensity: { type: 'number' }, // 0 to 1
              primaryEmotion: {
                type: 'string',
                enum: ['joy', 'anger', 'sadness', 'fear', 'surprise', 'disgust', 'neutral'],
              },
              confidence: { type: 'number' },
            },
            required: ['polarity', 'intensity', 'primaryEmotion', 'confidence'],
            additionalProperties: false,
          },
        },
      },
    });
    
    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      polarity: Math.max(-1, Math.min(1, result.polarity || 0)),
      intensity: Math.max(0, Math.min(1, result.intensity || 0)),
      primaryEmotion: result.primaryEmotion || 'neutral',
      confidence: result.confidence || 50,
    };
  }
  
  /**
   * Assess urgency
   */
  private async assessUrgency(message: string): Promise<UrgencyAssessment> {
    const response = await invokeLLM({
      messages: [
        {
          role: 'system',
          content: 'Assess the urgency of the message. Look for explicit indicators (ASAP, urgent, immediately) and implicit ones (deadlines, time pressure). Return as JSON.',
        },
        {
          role: 'user',
          content: message,
        },
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'urgency_assessment',
          strict: true,
          schema: {
            type: 'object',
            properties: {
              score: { type: 'number' }, // 0-100
              indicators: {
                type: 'array',
                items: { type: 'string' },
              },
              confidence: { type: 'number' },
            },
            required: ['score', 'indicators', 'confidence'],
            additionalProperties: false,
          },
        },
      },
    });
    
    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      score: Math.max(0, Math.min(100, result.score || 0)),
      indicators: result.indicators || [],
      confidence: result.confidence || 50,
    };
  }
  
  /**
   * Analyze intent and emotional context
   */
  async analyze(message: UnifiedMessage, relationshipContext?: RelationshipContext): Promise<IntentEmotionalResult> {
    const [intent, sentiment, urgency] = await Promise.all([
      this.classifyIntent(message.textContent),
      this.analyzeSentiment(message.textContent),
      this.assessUrgency(message.textContent),
    ]);
    
    // Detect stress and conflict
    const stressLevel = Math.abs(sentiment.polarity) * sentiment.intensity * 100;
    const conflictDetected = intent.primaryIntent === IntentType.CONFLICT || 
                            intent.secondaryIntents.includes(IntentType.CONFLICT);
    
    // TODO: Detect sensitive topics (legal, financial, health, personal)
    const sensitiveTopics: string[] = [];
    
    // Calculate overall confidence
    const overallConfidence = (
      intent.confidence +
      sentiment.confidence +
      urgency.confidence
    ) / 3;
    
    return {
      intent,
      sentiment,
      urgency,
      relationship: relationshipContext || {
        type: 'unknown',
        strength: 50,
        communicationFrequency: 'rare',
      },
      stressLevel,
      conflictDetected,
      sensitiveTopics,
      overallConfidence,
    };
  }
}

// ============================================================================
// LAYER 3: OUTCOME EVALUATION
// ============================================================================

export enum GoalType {
  INFORMATION = 'information', // Get specific data
  ACTION = 'action', // Have you do something
  CONFIRMATION = 'confirmation', // Verify understanding
  RESOLUTION = 'resolution', // Solve a problem
  RELATIONSHIP = 'relationship', // Strengthen connection
  DECISION = 'decision', // Make a choice
}

export interface GoalIdentification {
  primaryGoal: GoalType;
  secondaryGoals: GoalType[];
  confidence: number; // 0-100
}

export interface ResponseEffectiveness {
  completeness: number; // 0-100
  clarity: number; // 0-100
  actionability: number; // 0-100
  timeliness: number; // 0-100
  overallScore: number; // 0-100
}

export interface ConversationAdvancement {
  score: number; // -1 (regression) to +1 (progress)
  reasoning: string;
}

export interface OutcomeEvaluationResult {
  goal: GoalIdentification;
  effectiveness: ResponseEffectiveness;
  advancement: ConversationAdvancement;
  actionItems: string[];
  overallConfidence: number; // 0-100
}

export class OutcomeEvaluationService {
  /**
   * Identify sender's goal
   */
  private async identifyGoal(message: string): Promise<GoalIdentification> {
    const response = await invokeLLM({
      messages: [
        {
          role: 'system',
          content: 'Identify what the sender wants to achieve with this message. Return as JSON.',
        },
        {
          role: 'user',
          content: message,
        },
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'goal_identification',
          strict: true,
          schema: {
            type: 'object',
            properties: {
              primaryGoal: {
                type: 'string',
                enum: ['information', 'action', 'confirmation', 'resolution', 'relationship', 'decision'],
              },
              secondaryGoals: {
                type: 'array',
                items: {
                  type: 'string',
                  enum: ['information', 'action', 'confirmation', 'resolution', 'relationship', 'decision'],
                },
              },
              confidence: { type: 'number' },
            },
            required: ['primaryGoal', 'secondaryGoals', 'confidence'],
            additionalProperties: false,
          },
        },
      },
    });
    
    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      primaryGoal: result.primaryGoal as GoalType,
      secondaryGoals: result.secondaryGoals as GoalType[],
      confidence: result.confidence || 50,
    };
  }
  
  /**
   * Evaluate response effectiveness
   */
  private async evaluateEffectiveness(
    originalMessage: string,
    proposedResponse: string
  ): Promise<ResponseEffectiveness> {
    const response = await invokeLLM({
      messages: [
        {
          role: 'system',
          content: 'Evaluate how effectively the proposed response addresses the original message. Rate completeness, clarity, actionability, and timeliness (0-100 each). Return as JSON.',
        },
        {
          role: 'user',
          content: `Original: "${originalMessage}"\n\nProposed Response: "${proposedResponse}"`,
        },
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'response_effectiveness',
          strict: true,
          schema: {
            type: 'object',
            properties: {
              completeness: { type: 'number' },
              clarity: { type: 'number' },
              actionability: { type: 'number' },
              timeliness: { type: 'number' },
            },
            required: ['completeness', 'clarity', 'actionability', 'timeliness'],
            additionalProperties: false,
          },
        },
      },
    });
    
    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    const overallScore = (
      result.completeness +
      result.clarity +
      result.actionability +
      result.timeliness
    ) / 4;
    
    return {
      completeness: result.completeness || 50,
      clarity: result.clarity || 50,
      actionability: result.actionability || 50,
      timeliness: result.timeliness || 50,
      overallScore,
    };
  }
  
  /**
   * Evaluate conversation advancement
   */
  private async evaluateAdvancement(
    originalMessage: string,
    proposedResponse: string
  ): Promise<ConversationAdvancement> {
    const response = await invokeLLM({
      messages: [
        {
          role: 'system',
          content: 'Evaluate whether the proposed response moves the conversation forward (+1), maintains status quo (0), or creates confusion/conflict (-1). Provide reasoning. Return as JSON.',
        },
        {
          role: 'user',
          content: `Original: "${originalMessage}"\n\nProposed Response: "${proposedResponse}"`,
        },
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'conversation_advancement',
          strict: true,
          schema: {
            type: 'object',
            properties: {
              score: { type: 'number' }, // -1 to 1
              reasoning: { type: 'string' },
            },
            required: ['score', 'reasoning'],
            additionalProperties: false,
          },
        },
      },
    });
    
    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      score: Math.max(-1, Math.min(1, result.score || 0)),
      reasoning: result.reasoning || '',
    };
  }
  
  /**
   * Extract action items
   */
  private async extractActionItems(message: string, response: string): Promise<string[]> {
    const llmResponse = await invokeLLM({
      messages: [
        {
          role: 'system',
          content: 'Extract all action items and commitments from the conversation. Return as JSON array.',
        },
        {
          role: 'user',
          content: `Original: "${message}"\n\nResponse: "${response}"`,
        },
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'action_items',
          strict: true,
          schema: {
            type: 'object',
            properties: {
              items: {
                type: 'array',
                items: { type: 'string' },
              },
            },
            required: ['items'],
            additionalProperties: false,
          },
        },
      },
    });
    
    const result = JSON.parse(llmResponse.choices[0].message.content || '{"items":[]}');
    return result.items || [];
  }
  
  /**
   * Evaluate outcome of proposed response
   */
  async evaluate(
    message: UnifiedMessage,
    proposedResponse: string
  ): Promise<OutcomeEvaluationResult> {
    const [goal, effectiveness, advancement, actionItems] = await Promise.all([
      this.identifyGoal(message.textContent),
      this.evaluateEffectiveness(message.textContent, proposedResponse),
      this.evaluateAdvancement(message.textContent, proposedResponse),
      this.extractActionItems(message.textContent, proposedResponse),
    ]);
    
    const overallConfidence = (
      goal.confidence +
      effectiveness.overallScore
    ) / 2;
    
    return {
      goal,
      effectiveness,
      advancement,
      actionItems,
      overallConfidence,
    };
  }
}

// ============================================================================
// COMPOSITE TRIPLE-LAYER ANALYZER
// ============================================================================

export interface TripleLayerAnalysisResult {
  factual: FactualVerificationResult;
  intentEmotional: IntentEmotionalResult;
  outcome: OutcomeEvaluationResult;
  compositeConfidence: number; // 0-100
  shouldEscalate: boolean;
  escalationReasons: string[];
}

export class TripleLayerAnalyzer {
  private factualService: FactualVerificationService;
  private intentService: IntentAnalysisService;
  private outcomeService: OutcomeEvaluationService;
  
  constructor() {
    this.factualService = new FactualVerificationService();
    this.intentService = new IntentAnalysisService();
    this.outcomeService = new OutcomeEvaluationService();
  }
  
  /**
   * Analyze message through all three layers
   */
  async analyze(
    message: UnifiedMessage,
    proposedResponse: string,
    context: Record<string, any> = {}
  ): Promise<TripleLayerAnalysisResult> {
    // Run all three layers in parallel
    const [factual, intentEmotional, outcome] = await Promise.all([
      this.factualService.verify(message, context),
      this.intentService.analyze(message),
      this.outcomeService.evaluate(message, proposedResponse),
    ]);
    
    // Calculate composite confidence
    let compositeConfidence = (
      factual.overallConfidence +
      intentEmotional.overallConfidence +
      outcome.overallConfidence
    ) / 3;
    
    // Apply adjustments
    const escalationReasons: string[] = [];
    
    // Factual issues
    if (factual.hasContradictions) {
      compositeConfidence -= 40;
      escalationReasons.push('Factual contradictions detected');
    }
    if (factual.hasUnverifiedClaims) {
      compositeConfidence -= 20;
      escalationReasons.push('Unverified factual claims');
    }
    
    // Intent/emotional issues
    if (intentEmotional.conflictDetected) {
      compositeConfidence -= 20;
      escalationReasons.push('Conflict detected');
    }
    if (intentEmotional.sensitiveTopics.length > 0) {
      compositeConfidence -= 25;
      escalationReasons.push(`Sensitive topics: ${intentEmotional.sensitiveTopics.join(', ')}`);
    }
    if (intentEmotional.sentiment.polarity < -0.5 && intentEmotional.sentiment.intensity > 0.7) {
      compositeConfidence -= 10;
      escalationReasons.push('High negative sentiment');
    }
    
    // Outcome issues
    if (outcome.effectiveness.overallScore < 60) {
      compositeConfidence -= 20;
      escalationReasons.push('Low response effectiveness');
    }
    if (outcome.advancement.score < 0) {
      compositeConfidence -= 25;
      escalationReasons.push('Response may cause regression');
    }
    
    // Clamp to [0, 100]
    compositeConfidence = Math.max(0, Math.min(100, compositeConfidence));
    
    // Determine if should escalate
    const shouldEscalate = compositeConfidence < 70 || escalationReasons.length > 0;
    
    return {
      factual,
      intentEmotional,
      outcome,
      compositeConfidence,
      shouldEscalate,
      escalationReasons,
    };
  }
}
