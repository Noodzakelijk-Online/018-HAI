/**
 * Voice Integration Service
 * 
 * Handles voice message transcription and text-to-speech for autonomous communication.
 */

import { transcribeAudio } from '../_core/voiceTranscription';
import { UnifiedMessage } from './BasePlatformConnector';

export interface VoiceTranscriptionResult {
  text: string;
  language: string;
  confidence: number;
  duration: number;
  segments?: Array<{
    text: string;
    start: number;
    end: number;
  }>;
}

export interface VoiceResponseOptions {
  language?: string;
  voice?: 'male' | 'female' | 'neutral';
  speed?: number; // 0.5 to 2.0
  pitch?: number; // -20 to 20
  tone?: 'professional' | 'casual' | 'friendly' | 'formal';
}

export interface GeneratedVoiceResponse {
  audioUrl: string;
  duration: number;
  format: 'mp3' | 'wav' | 'ogg';
  size: number;
  text: string;
}

/**
 * Voice Transcription Service
 * 
 * Transcribes voice messages to text for analysis.
 */
export class VoiceTranscriptionService {
  /**
   * Transcribe voice message
   */
  async transcribeVoiceMessage(
    audioUrl: string,
    options?: {
      language?: string;
      prompt?: string;
    }
  ): Promise<VoiceTranscriptionResult> {
    try {
      console.log('[VoiceTranscription] Transcribing audio:', audioUrl);
      
      // Use the built-in voice transcription service
      const result = await transcribeAudio({
        audioUrl,
        language: options?.language,
        prompt: options?.prompt,
      });
      
      // Extract text and metadata
      const transcription: VoiceTranscriptionResult = {
        text: result.text,
        language: result.language || options?.language || 'en',
        confidence: 0.95, // Whisper is generally high confidence
        duration: result.duration || 0,
        segments: result.segments?.map((seg: any) => ({
          text: seg.text,
          start: seg.start,
          end: seg.end,
        })),
      };
      
      console.log('[VoiceTranscription] Transcription complete:', {
        textLength: transcription.text.length,
        language: transcription.language,
        duration: transcription.duration,
      });
      
      return transcription;
    } catch (error) {
      console.error('[VoiceTranscription] Error:', error);
      throw new Error(`Voice transcription failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  /**
   * Transcribe and create unified message
   */
  async transcribeToUnifiedMessage(
    originalMessage: UnifiedMessage,
    audioUrl: string
  ): Promise<UnifiedMessage> {
    const transcription = await this.transcribeVoiceMessage(audioUrl);
    
    return {
      ...originalMessage,
      textContent: transcription.text,
      metadata: {
        ...originalMessage.metadata,
        voiceTranscription: {
          originalAudioUrl: audioUrl,
          language: transcription.language,
          confidence: transcription.confidence,
          duration: transcription.duration,
        },
      },
    };
  }
  
  /**
   * Detect language from audio
   */
  async detectLanguage(audioUrl: string): Promise<string> {
    const transcription = await this.transcribeVoiceMessage(audioUrl);
    return transcription.language;
  }
}

/**
 * Text-to-Speech Service
 * 
 * Generates voice responses from text.
 */
export class TextToSpeechService {
  private openaiApiKey: string;
  
  constructor(apiKey?: string) {
    this.openaiApiKey = apiKey || process.env.OPENAI_API_KEY || '';
  }
  
  /**
   * Generate voice response from text
   */
  async generateVoiceResponse(
    text: string,
    options?: VoiceResponseOptions
  ): Promise<GeneratedVoiceResponse> {
    try {
      console.log('[TextToSpeech] Generating voice:', {
        textLength: text.length,
        options,
      });
      
      // Select voice based on options
      const voice = this.selectVoice(options);
      
      // Generate speech using OpenAI TTS
      const response = await fetch('https://api.openai.com/v1/audio/speech', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.openaiApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'tts-1', // or 'tts-1-hd' for higher quality
          input: text,
          voice,
          speed: options?.speed || 1.0,
        }),
      });
      
      if (!response.ok) {
        throw new Error(`OpenAI TTS API error: ${response.statusText}`);
      }
      
      // Get audio data
      const audioBuffer = await response.arrayBuffer();
      const audioSize = audioBuffer.byteLength;
      
      // Upload to storage (using S3)
      const { storagePut } = await import('../../storage');
      const audioKey = `voice-responses/${Date.now()}-${Math.random().toString(36).substr(2, 9)}.mp3`;
      const { url: audioUrl } = await storagePut(
        audioKey,
        Buffer.from(audioBuffer),
        'audio/mpeg'
      );
      
      // Estimate duration (rough estimate: 150 words per minute)
      const wordCount = text.split(/\s+/).length;
      const estimatedDuration = (wordCount / 150) * 60;
      
      console.log('[TextToSpeech] Voice generated:', {
        audioUrl,
        size: audioSize,
        duration: estimatedDuration,
      });
      
      return {
        audioUrl,
        duration: estimatedDuration,
        format: 'mp3',
        size: audioSize,
        text,
      };
    } catch (error) {
      console.error('[TextToSpeech] Error:', error);
      throw new Error(`Text-to-speech failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
  
  /**
   * Select appropriate voice based on options
   */
  private selectVoice(options?: VoiceResponseOptions): string {
    // OpenAI TTS voices: alloy, echo, fable, onyx, nova, shimmer
    
    if (options?.voice === 'male') {
      if (options.tone === 'professional' || options.tone === 'formal') {
        return 'onyx'; // Deep, professional male voice
      } else {
        return 'echo'; // Friendly male voice
      }
    } else if (options?.voice === 'female') {
      if (options.tone === 'professional' || options.tone === 'formal') {
        return 'nova'; // Professional female voice
      } else {
        return 'shimmer'; // Warm, friendly female voice
      }
    } else {
      // Neutral or default
      if (options?.tone === 'professional' || options?.tone === 'formal') {
        return 'alloy'; // Balanced, professional
      } else {
        return 'fable'; // Friendly, expressive
      }
    }
  }
  
  /**
   * Generate voice response with tone matching
   */
  async generateVoiceWithTone(
    text: string,
    relationshipType: string,
    platform: string
  ): Promise<GeneratedVoiceResponse> {
    // Determine voice options based on relationship and platform
    const options: VoiceResponseOptions = {
      tone: this.getToneForRelationship(relationshipType, platform),
      speed: 1.0,
    };
    
    // LinkedIn always professional
    if (platform === 'linkedin') {
      options.tone = 'professional';
      options.voice = 'neutral';
    }
    
    // Family/friends more casual
    if (relationshipType === 'family' || relationshipType === 'friend') {
      options.tone = 'friendly';
      options.speed = 1.05; // Slightly faster for casual
    }
    
    // Professional contacts
    if (relationshipType === 'colleague' || relationshipType === 'client') {
      options.tone = 'professional';
      options.speed = 0.95; // Slightly slower for clarity
    }
    
    return await this.generateVoiceResponse(text, options);
  }
  
  /**
   * Get tone based on relationship type
   */
  private getToneForRelationship(relationshipType: string, platform: string): VoiceResponseOptions['tone'] {
    if (platform === 'linkedin') {
      return 'professional';
    }
    
    switch (relationshipType) {
      case 'family':
      case 'friend':
        return 'friendly';
      case 'colleague':
      case 'client':
        return 'professional';
      case 'acquaintance':
        return 'casual';
      default:
        return 'casual';
    }
  }
}

/**
 * Voice Message Handler
 * 
 * Coordinates voice transcription and response generation.
 */
export class VoiceMessageHandler {
  private transcriptionService: VoiceTranscriptionService;
  private ttsService: TextToSpeechService;
  
  constructor() {
    this.transcriptionService = new VoiceTranscriptionService();
    this.ttsService = new TextToSpeechService();
  }
  
  /**
   * Process incoming voice message
   */
  async processIncomingVoiceMessage(
    message: UnifiedMessage,
    audioUrl: string
  ): Promise<UnifiedMessage> {
    console.log('[VoiceHandler] Processing incoming voice message');
    
    // Transcribe the voice message
    const transcribedMessage = await this.transcriptionService.transcribeToUnifiedMessage(
      message,
      audioUrl
    );
    
    console.log('[VoiceHandler] Voice message transcribed:', {
      originalAudioUrl: audioUrl,
      transcribedText: transcribedMessage.textContent.substring(0, 100) + '...',
    });
    
    return transcribedMessage;
  }
  
  /**
   * Generate voice response for outgoing message
   */
  async generateOutgoingVoiceResponse(
    textMessage: string,
    relationshipType: string,
    platform: string
  ): Promise<GeneratedVoiceResponse> {
    console.log('[VoiceHandler] Generating outgoing voice response');
    
    const voiceResponse = await this.ttsService.generateVoiceWithTone(
      textMessage,
      relationshipType,
      platform
    );
    
    console.log('[VoiceHandler] Voice response generated:', {
      audioUrl: voiceResponse.audioUrl,
      duration: voiceResponse.duration,
    });
    
    return voiceResponse;
  }
  
  /**
   * Determine if response should be voice or text
   */
  shouldRespondWithVoice(
    incomingMessage: UnifiedMessage,
    platform: string
  ): boolean {
    // Respond with voice if:
    // 1. Incoming message was voice
    // 2. Platform supports voice (WhatsApp, Telegram, Facebook Messenger)
    // 3. Not a professional platform (not LinkedIn)
    
    const hasVoiceTranscription = !!incomingMessage.metadata?.voiceTranscription;
    const voiceSupportedPlatforms = ['whatsapp', 'telegram', 'facebook'];
    const isProfessionalPlatform = platform === 'linkedin';
    
    return (
      hasVoiceTranscription &&
      voiceSupportedPlatforms.includes(platform) &&
      !isProfessionalPlatform
    );
  }
  
  /**
   * Get voice message statistics
   */
  getVoiceStatistics(): {
    totalTranscribed: number;
    totalGenerated: number;
    averageTranscriptionTime: number;
    averageGenerationTime: number;
  } {
    // TODO: Implement statistics tracking
    return {
      totalTranscribed: 0,
      totalGenerated: 0,
      averageTranscriptionTime: 0,
      averageGenerationTime: 0,
    };
  }
}

/**
 * Global instances
 */
let voiceTranscriptionServiceInstance: VoiceTranscriptionService | null = null;
let textToSpeechServiceInstance: TextToSpeechService | null = null;
let voiceMessageHandlerInstance: VoiceMessageHandler | null = null;

/**
 * Get or create voice transcription service instance
 */
export function getVoiceTranscriptionService(): VoiceTranscriptionService {
  if (!voiceTranscriptionServiceInstance) {
    voiceTranscriptionServiceInstance = new VoiceTranscriptionService();
  }
  return voiceTranscriptionServiceInstance;
}

/**
 * Get or create text-to-speech service instance
 */
export function getTextToSpeechService(): TextToSpeechService {
  if (!textToSpeechServiceInstance) {
    textToSpeechServiceInstance = new TextToSpeechService();
  }
  return textToSpeechServiceInstance;
}

/**
 * Get or create voice message handler instance
 */
export function getVoiceMessageHandler(): VoiceMessageHandler {
  if (!voiceMessageHandlerInstance) {
    voiceMessageHandlerInstance = new VoiceMessageHandler();
  }
  return voiceMessageHandlerInstance;
}
