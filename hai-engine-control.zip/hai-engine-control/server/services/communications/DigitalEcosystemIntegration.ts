/**
 * Digital Ecosystem Integration
 * 
 * Integrates with the user's complete digital back office:
 * - Gmail (emails, contacts, history)
 * - Google Calendar (events, availability, commitments)
 * - Google Drive (documents, files, shared content)
 * - Social Media (LinkedIn, Twitter, Facebook)
 * - Local Files (documents, photos, databases)
 * 
 * Provides unified fact-checking and context enrichment.
 */

import { google } from 'googleapis';
import * as fs from 'fs/promises';
import * as path from 'path';

// ============================================================================
// GMAIL INTEGRATION
// ============================================================================

export interface EmailSearchResult {
  id: string;
  threadId: string;
  subject: string;
  from: string;
  to: string[];
  date: Date;
  snippet: string;
  body?: string;
  attachments?: string[];
}

export class GmailIntegrationService {
  private gmail: any;
  
  constructor(auth: any) {
    this.gmail = google.gmail({ version: 'v1', auth });
  }
  
  /**
   * Search emails by query
   */
  async searchEmails(query: string, maxResults: number = 10): Promise<EmailSearchResult[]> {
    try {
      const response = await this.gmail.users.messages.list({
        userId: 'me',
        q: query,
        maxResults,
      });
      
      if (!response.data.messages) {
        return [];
      }
      
      const emails = await Promise.all(
        response.data.messages.map((msg: any) => this.getEmailDetails(msg.id))
      );
      
      return emails.filter(Boolean) as EmailSearchResult[];
      
    } catch (error) {
      console.error('[Gmail] Search error:', error);
      return [];
    }
  }
  
  /**
   * Get email details
   */
  private async getEmailDetails(messageId: string): Promise<EmailSearchResult | null> {
    try {
      const response = await this.gmail.users.messages.get({
        userId: 'me',
        id: messageId,
        format: 'full',
      });
      
      const message = response.data;
      const headers = message.payload.headers;
      
      const getHeader = (name: string) => {
        const header = headers.find((h: any) => h.name.toLowerCase() === name.toLowerCase());
        return header?.value || '';
      };
      
      return {
        id: message.id,
        threadId: message.threadId,
        subject: getHeader('Subject'),
        from: getHeader('From'),
        to: getHeader('To').split(',').map((e: string) => e.trim()),
        date: new Date(parseInt(message.internalDate)),
        snippet: message.snippet,
        body: this.extractBody(message.payload),
        attachments: this.extractAttachments(message.payload),
      };
      
    } catch (error) {
      console.error(`[Gmail] Error getting message ${messageId}:`, error);
      return null;
    }
  }
  
  /**
   * Extract email body
   */
  private extractBody(payload: any): string {
    if (payload.body?.data) {
      return Buffer.from(payload.body.data, 'base64').toString('utf-8');
    }
    
    if (payload.parts) {
      for (const part of payload.parts) {
        if (part.mimeType === 'text/plain' && part.body?.data) {
          return Buffer.from(part.body.data, 'base64').toString('utf-8');
        }
      }
    }
    
    return '';
  }
  
  /**
   * Extract attachment filenames
   */
  private extractAttachments(payload: any): string[] {
    const attachments: string[] = [];
    
    if (payload.parts) {
      for (const part of payload.parts) {
        if (part.filename) {
          attachments.push(part.filename);
        }
      }
    }
    
    return attachments;
  }
  
  /**
   * Verify claim against email history
   */
  async verifyClaim(claim: string): Promise<{ verified: boolean; confidence: number; evidence?: EmailSearchResult[] }> {
    // Search for relevant emails
    const emails = await this.searchEmails(claim, 5);
    
    if (emails.length === 0) {
      return { verified: false, confidence: 0 };
    }
    
    // Calculate confidence based on number and recency of results
    const confidence = Math.min(100, emails.length * 20 + (emails[0] ? this.getRecencyScore(emails[0].date) : 0));
    
    return {
      verified: true,
      confidence,
      evidence: emails,
    };
  }
  
  /**
   * Get recency score (0-40 based on how recent)
   */
  private getRecencyScore(date: Date): number {
    const daysAgo = (Date.now() - date.getTime()) / (1000 * 60 * 60 * 24);
    
    if (daysAgo < 7) return 40;
    if (daysAgo < 30) return 30;
    if (daysAgo < 90) return 20;
    if (daysAgo < 365) return 10;
    return 5;
  }
}

// ============================================================================
// GOOGLE CALENDAR INTEGRATION
// ============================================================================

export interface CalendarEvent {
  id: string;
  summary: string;
  description?: string;
  start: Date;
  end: Date;
  location?: string;
  attendees?: string[];
  status: string;
}

export class GoogleCalendarService {
  private calendar: any;
  
  constructor(auth: any) {
    this.calendar = google.calendar({ version: 'v3', auth });
  }
  
  /**
   * Get events in date range
   */
  async getEvents(startDate: Date, endDate: Date): Promise<CalendarEvent[]> {
    try {
      const response = await this.calendar.events.list({
        calendarId: 'primary',
        timeMin: startDate.toISOString(),
        timeMax: endDate.toISOString(),
        singleEvents: true,
        orderBy: 'startTime',
      });
      
      return response.data.items.map((event: any) => ({
        id: event.id,
        summary: event.summary || 'Untitled Event',
        description: event.description,
        start: new Date(event.start.dateTime || event.start.date),
        end: new Date(event.end.dateTime || event.end.date),
        location: event.location,
        attendees: event.attendees?.map((a: any) => a.email) || [],
        status: event.status,
      }));
      
    } catch (error) {
      console.error('[Calendar] Error getting events:', error);
      return [];
    }
  }
  
  /**
   * Check if user is available at a specific time
   */
  async checkAvailability(startTime: Date, endTime: Date): Promise<boolean> {
    const events = await this.getEvents(startTime, endTime);
    return events.length === 0;
  }
  
  /**
   * Find next available slot
   */
  async findNextAvailable(
    afterDate: Date,
    duration: number = 60, // minutes
    searchDays: number = 7
  ): Promise<Date | null> {
    const endDate = new Date(afterDate.getTime() + searchDays * 24 * 60 * 60 * 1000);
    const events = await this.getEvents(afterDate, endDate);
    
    // Simple algorithm: find first gap that fits duration
    let currentTime = afterDate;
    
    for (const event of events) {
      const gap = event.start.getTime() - currentTime.getTime();
      if (gap >= duration * 60 * 1000) {
        return currentTime;
      }
      currentTime = event.end;
    }
    
    // If no conflicts, return the start time
    return afterDate;
  }
  
  /**
   * Verify meeting claim
   */
  async verifyMeeting(description: string, date?: Date): Promise<{ verified: boolean; confidence: number; event?: CalendarEvent }> {
    const searchStart = date || new Date();
    const searchEnd = new Date(searchStart.getTime() + 7 * 24 * 60 * 60 * 1000);
    
    const events = await this.getEvents(searchStart, searchEnd);
    
    // Search for matching event
    const match = events.find(event =>
      event.summary.toLowerCase().includes(description.toLowerCase()) ||
      (event.description && event.description.toLowerCase().includes(description.toLowerCase()))
    );
    
    if (match) {
      return {
        verified: true,
        confidence: 95,
        event: match,
      };
    }
    
    return { verified: false, confidence: 0 };
  }
}

// ============================================================================
// GOOGLE DRIVE INTEGRATION
// ============================================================================

export interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  modifiedTime: Date;
  size?: number;
  webViewLink?: string;
  owners?: string[];
  shared: boolean;
}

export class GoogleDriveService {
  private drive: any;
  
  constructor(auth: any) {
    this.drive = google.drive({ version: 'v3', auth });
  }
  
  /**
   * Search files
   */
  async searchFiles(query: string, maxResults: number = 10): Promise<DriveFile[]> {
    try {
      const response = await this.drive.files.list({
        q: `fullText contains '${query}' or name contains '${query}'`,
        pageSize: maxResults,
        fields: 'files(id, name, mimeType, modifiedTime, size, webViewLink, owners, shared)',
      });
      
      return response.data.files.map((file: any) => ({
        id: file.id,
        name: file.name,
        mimeType: file.mimeType,
        modifiedTime: new Date(file.modifiedTime),
        size: file.size ? parseInt(file.size) : undefined,
        webViewLink: file.webViewLink,
        owners: file.owners?.map((o: any) => o.emailAddress) || [],
        shared: file.shared || false,
      }));
      
    } catch (error) {
      console.error('[Drive] Search error:', error);
      return [];
    }
  }
  
  /**
   * Get file content
   */
  async getFileContent(fileId: string): Promise<string> {
    try {
      const response = await this.drive.files.export({
        fileId,
        mimeType: 'text/plain',
      });
      
      return response.data;
      
    } catch (error) {
      console.error(`[Drive] Error getting file ${fileId}:`, error);
      return '';
    }
  }
  
  /**
   * Verify document claim
   */
  async verifyDocument(claim: string): Promise<{ verified: boolean; confidence: number; files?: DriveFile[] }> {
    const files = await this.searchFiles(claim, 5);
    
    if (files.length === 0) {
      return { verified: false, confidence: 0 };
    }
    
    const confidence = Math.min(100, files.length * 20 + this.getRecencyScore(files[0].modifiedTime));
    
    return {
      verified: true,
      confidence,
      files,
    };
  }
  
  /**
   * Get recency score
   */
  private getRecencyScore(date: Date): number {
    const daysAgo = (Date.now() - date.getTime()) / (1000 * 60 * 60 * 24);
    
    if (daysAgo < 7) return 40;
    if (daysAgo < 30) return 30;
    if (daysAgo < 90) return 20;
    if (daysAgo < 365) return 10;
    return 5;
  }
}

// ============================================================================
// LOCAL FILES INTEGRATION
// ============================================================================

export interface LocalFile {
  path: string;
  name: string;
  size: number;
  modifiedTime: Date;
  extension: string;
}

export class LocalFileSystemService {
  private indexedDirectories: string[] = [];
  private fileIndex: Map<string, LocalFile> = new Map();
  
  /**
   * Index a directory
   */
  async indexDirectory(dirPath: string, recursive: boolean = true): Promise<void> {
    try {
      const entries = await fs.readdir(dirPath, { withFileTypes: true });
      
      for (const entry of entries) {
        const fullPath = path.join(dirPath, entry.name);
        
        if (entry.isDirectory() && recursive) {
          await this.indexDirectory(fullPath, recursive);
        } else if (entry.isFile()) {
          const stats = await fs.stat(fullPath);
          const file: LocalFile = {
            path: fullPath,
            name: entry.name,
            size: stats.size,
            modifiedTime: stats.mtime,
            extension: path.extname(entry.name),
          };
          this.fileIndex.set(fullPath, file);
        }
      }
      
      if (!this.indexedDirectories.includes(dirPath)) {
        this.indexedDirectories.push(dirPath);
      }
      
    } catch (error) {
      console.error(`[LocalFiles] Error indexing ${dirPath}:`, error);
    }
  }
  
  /**
   * Search files
   */
  searchFiles(query: string): LocalFile[] {
    const lowerQuery = query.toLowerCase();
    const results: LocalFile[] = [];
    
    for (const file of this.fileIndex.values()) {
      if (file.name.toLowerCase().includes(lowerQuery) ||
          file.path.toLowerCase().includes(lowerQuery)) {
        results.push(file);
      }
    }
    
    return results.sort((a, b) => b.modifiedTime.getTime() - a.modifiedTime.getTime());
  }
  
  /**
   * Read file content
   */
  async readFile(filePath: string): Promise<string> {
    try {
      return await fs.readFile(filePath, 'utf-8');
    } catch (error) {
      console.error(`[LocalFiles] Error reading ${filePath}:`, error);
      return '';
    }
  }
  
  /**
   * Verify file claim
   */
  async verifyFile(claim: string): Promise<{ verified: boolean; confidence: number; files?: LocalFile[] }> {
    const files = this.searchFiles(claim);
    
    if (files.length === 0) {
      return { verified: false, confidence: 0 };
    }
    
    const confidence = Math.min(100, files.length * 20 + this.getRecencyScore(files[0].modifiedTime));
    
    return {
      verified: true,
      confidence,
      files: files.slice(0, 5),
    };
  }
  
  /**
   * Get recency score
   */
  private getRecencyScore(date: Date): number {
    const daysAgo = (Date.now() - date.getTime()) / (1000 * 60 * 60 * 24);
    
    if (daysAgo < 7) return 40;
    if (daysAgo < 30) return 30;
    if (daysAgo < 90) return 20;
    if (daysAgo < 365) return 10;
    return 5;
  }
}

// ============================================================================
// UNIFIED KNOWLEDGE GRAPH
// ============================================================================

export interface KnowledgeFact {
  claim: string;
  verified: boolean;
  confidence: number;
  sources: string[]; // Which services verified this
  evidence: any[];
  timestamp: Date;
}

export class UnifiedKnowledgeGraph {
  private gmail?: GmailIntegrationService;
  private calendar?: GoogleCalendarService;
  private drive?: GoogleDriveService;
  private localFiles: LocalFileSystemService;
  
  private factCache: Map<string, KnowledgeFact> = new Map();
  
  constructor() {
    this.localFiles = new LocalFileSystemService();
  }
  
  /**
   * Initialize with Google OAuth
   */
  async initializeGoogle(auth: any): Promise<void> {
    this.gmail = new GmailIntegrationService(auth);
    this.calendar = new GoogleCalendarService(auth);
    this.drive = new GoogleDriveService(auth);
  }
  
  /**
   * Index local directories
   */
  async indexLocalDirectories(directories: string[]): Promise<void> {
    for (const dir of directories) {
      await this.localFiles.indexDirectory(dir, true);
    }
  }
  
  /**
   * Verify claim across all sources
   */
  async verifyClaim(claim: string): Promise<KnowledgeFact> {
    // Check cache first
    const cached = this.factCache.get(claim);
    if (cached && Date.now() - cached.timestamp.getTime() < 3600000) { // 1 hour cache
      return cached;
    }
    
    // Verify across all sources in parallel
    const results = await Promise.all([
      this.gmail?.verifyClaim(claim) || Promise.resolve({ verified: false, confidence: 0 }),
      this.drive?.verifyDocument(claim) || Promise.resolve({ verified: false, confidence: 0 }),
      this.localFiles.verifyFile(claim),
    ]);
    
    // Aggregate results
    const sources: string[] = [];
    const evidence: any[] = [];
    let totalConfidence = 0;
    let verifiedCount = 0;
    
    if (results[0].verified) {
      sources.push('gmail');
      evidence.push(...(results[0].evidence || []));
      totalConfidence += results[0].confidence;
      verifiedCount++;
    }
    
    if (results[1].verified) {
      sources.push('drive');
      evidence.push(...(results[1].files || []));
      totalConfidence += results[1].confidence;
      verifiedCount++;
    }
    
    if (results[2].verified) {
      sources.push('local_files');
      evidence.push(...(results[2].files || []));
      totalConfidence += results[2].confidence;
      verifiedCount++;
    }
    
    const fact: KnowledgeFact = {
      claim,
      verified: verifiedCount > 0,
      confidence: verifiedCount > 0 ? totalConfidence / verifiedCount : 0,
      sources,
      evidence,
      timestamp: new Date(),
    };
    
    // Cache result
    this.factCache.set(claim, fact);
    
    return fact;
  }
  
  /**
   * Get relevant context for a message
   */
  async getContext(message: string, sender: string): Promise<{
    emails: EmailSearchResult[];
    events: CalendarEvent[];
    files: DriveFile[];
  }> {
    const [emails, events, files] = await Promise.all([
      this.gmail?.searchEmails(`from:${sender} OR to:${sender}`, 5) || Promise.resolve([]),
      this.calendar?.getEvents(new Date(), new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)) || Promise.resolve([]),
      this.drive?.searchFiles(message, 5) || Promise.resolve([]),
    ]);
    
    return { emails, events, files };
  }
}

// Global instance
export const knowledgeGraph = new UnifiedKnowledgeGraph();
