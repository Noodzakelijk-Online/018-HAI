/**
 * Proactive Communication Engine
 * 
 * Enables the autonomous system to initiate communications proactively:
 * - Send status updates before asked
 * - Confirm meetings automatically
 * - Follow up on commitments
 * - Alert to conflicts
 * - Maintain relationship health
 */

import { UnifiedMessage, BasePlatformConnector } from './BasePlatformConnector';
import { GoogleCalendarService } from './DigitalEcosystemIntegration';

export interface Commitment {
  id: string;
  type: 'task' | 'meeting' | 'deadline' | 'promise';
  description: string;
  dueDate: Date;
  status: 'pending' | 'in_progress' | 'completed' | 'overdue';
  platform: string;
  conversationId: string;
  contactId: string;
  contactName: string;
  createdAt: Date;
  lastFollowUp?: Date;
}

export interface ProactiveMessage {
  id: string;
  type: 'status_update' | 'meeting_confirmation' | 'follow_up' | 'conflict_alert' | 'check_in';
  platform: string;
  conversationId: string;
  contactId: string;
  contactName: string;
  message: string;
  scheduledFor: Date;
  sent: boolean;
  sentAt?: Date;
  relatedCommitmentId?: string;
}

export interface RelationshipHealth {
  contactId: string;
  contactName: string;
  platform: string;
  lastContact: Date;
  daysSinceLastContact: number;
  relationshipType: 'family' | 'friend' | 'colleague' | 'client' | 'acquaintance';
  importance: number; // 1-10
  suggestedCheckIn: boolean;
  suggestedMessage?: string;
}

/**
 * Commitment Tracker Service
 * 
 * Extracts and tracks commitments from conversations.
 */
export class CommitmentTracker {
  private commitments: Map<string, Commitment> = new Map();
  
  /**
   * Extract commitments from message
   */
  async extractCommitments(message: UnifiedMessage): Promise<Commitment[]> {
    const extracted: Commitment[] = [];
    
    // Use LLM to extract commitments from message text
    // For now, use simple keyword detection
    const text = message.textContent.toLowerCase();
    
    // Detect task commitments
    if (text.includes('will') || text.includes('going to') || text.includes('plan to')) {
      const commitment: Commitment = {
        id: `commitment-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        type: 'promise',
        description: message.textContent,
        dueDate: this.extractDueDate(message.textContent) || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // Default 7 days
        status: 'pending',
        platform: message.platform,
        conversationId: message.conversationId,
        contactId: message.senderId,
        contactName: message.senderName,
        createdAt: new Date(),
      };
      
      extracted.push(commitment);
      this.commitments.set(commitment.id, commitment);
    }
    
    // Detect meeting commitments
    if (text.includes('meeting') || text.includes('call') || text.includes('appointment')) {
      const commitment: Commitment = {
        id: `commitment-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        type: 'meeting',
        description: message.textContent,
        dueDate: this.extractDueDate(message.textContent) || new Date(Date.now() + 24 * 60 * 60 * 1000), // Default tomorrow
        status: 'pending',
        platform: message.platform,
        conversationId: message.conversationId,
        contactId: message.senderId,
        contactName: message.senderName,
        createdAt: new Date(),
      };
      
      extracted.push(commitment);
      this.commitments.set(commitment.id, commitment);
    }
    
    return extracted;
  }
  
  /**
   * Extract due date from text (simple implementation)
   */
  private extractDueDate(text: string): Date | null {
    const today = new Date();
    const tomorrow = new Date(today.getTime() + 24 * 60 * 60 * 1000);
    const nextWeek = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
    
    if (text.toLowerCase().includes('today')) {
      return today;
    } else if (text.toLowerCase().includes('tomorrow')) {
      return tomorrow;
    } else if (text.toLowerCase().includes('next week')) {
      return nextWeek;
    }
    
    // TODO: Use more sophisticated date extraction
    return null;
  }
  
  /**
   * Get all commitments
   */
  getAllCommitments(): Commitment[] {
    return Array.from(this.commitments.values());
  }
  
  /**
   * Get pending commitments
   */
  getPendingCommitments(): Commitment[] {
    return this.getAllCommitments().filter(c => c.status === 'pending' || c.status === 'in_progress');
  }
  
  /**
   * Get overdue commitments
   */
  getOverdueCommitments(): Commitment[] {
    const now = new Date();
    return this.getAllCommitments().filter(
      c => c.status !== 'completed' && c.dueDate < now
    );
  }
  
  /**
   * Get approaching commitments (due within 24 hours)
   */
  getApproachingCommitments(): Commitment[] {
    const now = new Date();
    const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    
    return this.getAllCommitments().filter(
      c => c.status !== 'completed' && c.dueDate > now && c.dueDate < tomorrow
    );
  }
  
  /**
   * Update commitment status
   */
  updateCommitmentStatus(commitmentId: string, status: Commitment['status']): void {
    const commitment = this.commitments.get(commitmentId);
    if (commitment) {
      commitment.status = status;
    }
  }
  
  /**
   * Mark commitment as followed up
   */
  markFollowedUp(commitmentId: string): void {
    const commitment = this.commitments.get(commitmentId);
    if (commitment) {
      commitment.lastFollowUp = new Date();
    }
  }
}

/**
 * Proactive Messenger Service
 * 
 * Generates and sends proactive messages.
 */
export class ProactiveMessenger {
  private commitmentTracker: CommitmentTracker;
  private calendarService: GoogleCalendarService;
  private scheduledMessages: Map<string, ProactiveMessage> = new Map();
  
  constructor(commitmentTracker: CommitmentTracker) {
    this.commitmentTracker = commitmentTracker;
    this.calendarService = new GoogleCalendarService();
  }
  
  /**
   * Generate proactive messages based on commitments
   */
  async generateProactiveMessages(): Promise<ProactiveMessage[]> {
    const messages: ProactiveMessage[] = [];
    
    // Status updates for approaching commitments
    const approaching = this.commitmentTracker.getApproachingCommitments();
    for (const commitment of approaching) {
      if (!commitment.lastFollowUp || this.daysSince(commitment.lastFollowUp) > 1) {
        messages.push({
          id: `proactive-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          type: 'status_update',
          platform: commitment.platform,
          conversationId: commitment.conversationId,
          contactId: commitment.contactId,
          contactName: commitment.contactName,
          message: this.generateStatusUpdateMessage(commitment),
          scheduledFor: new Date(commitment.dueDate.getTime() - 2 * 60 * 60 * 1000), // 2 hours before
          sent: false,
          relatedCommitmentId: commitment.id,
        });
      }
    }
    
    // Follow-ups for overdue commitments
    const overdue = this.commitmentTracker.getOverdueCommitments();
    for (const commitment of overdue) {
      if (!commitment.lastFollowUp || this.daysSince(commitment.lastFollowUp) > 2) {
        messages.push({
          id: `proactive-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          type: 'follow_up',
          platform: commitment.platform,
          conversationId: commitment.conversationId,
          contactId: commitment.contactId,
          contactName: commitment.contactName,
          message: this.generateFollowUpMessage(commitment),
          scheduledFor: new Date(), // Send now
          sent: false,
          relatedCommitmentId: commitment.id,
        });
      }
    }
    
    // Meeting confirmations
    const meetings = this.commitmentTracker.getPendingCommitments().filter(c => c.type === 'meeting');
    for (const meeting of meetings) {
      const hoursUntil = (meeting.dueDate.getTime() - Date.now()) / (1000 * 60 * 60);
      
      if (hoursUntil > 2 && hoursUntil < 4 && !meeting.lastFollowUp) {
        messages.push({
          id: `proactive-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          type: 'meeting_confirmation',
          platform: meeting.platform,
          conversationId: meeting.conversationId,
          contactId: meeting.contactId,
          contactName: meeting.contactName,
          message: this.generateMeetingConfirmationMessage(meeting),
          scheduledFor: new Date(meeting.dueDate.getTime() - 3 * 60 * 60 * 1000), // 3 hours before
          sent: false,
          relatedCommitmentId: meeting.id,
        });
      }
    }
    
    // Store scheduled messages
    for (const message of messages) {
      this.scheduledMessages.set(message.id, message);
    }
    
    return messages;
  }
  
  /**
   * Send scheduled proactive messages
   */
  async sendScheduledMessages(connector: BasePlatformConnector): Promise<number> {
    const now = new Date();
    let sent = 0;
    
    for (const message of this.scheduledMessages.values()) {
      if (!message.sent && message.scheduledFor <= now) {
        // Create unified message
        const unifiedMessage: UnifiedMessage = {
          id: message.id,
          platform: message.platform,
          connectorId: connector.connectorId,
          conversationId: message.conversationId,
          senderId: 'system',
          senderName: 'You',
          textContent: message.message,
          timestamp: new Date(),
          direction: 'outgoing',
          status: 'sending',
        };
        
        // Send message
        const result = await connector.sendMessage(unifiedMessage);
        
        if (result.success) {
          message.sent = true;
          message.sentAt = new Date();
          sent++;
          
          // Mark commitment as followed up
          if (message.relatedCommitmentId) {
            this.commitmentTracker.markFollowedUp(message.relatedCommitmentId);
          }
          
          console.log('[ProactiveMessenger] Sent proactive message:', {
            type: message.type,
            to: message.contactName,
          });
        }
      }
    }
    
    return sent;
  }
  
  /**
   * Generate status update message
   */
  private generateStatusUpdateMessage(commitment: Commitment): string {
    const timeUntil = this.formatTimeUntil(commitment.dueDate);
    
    switch (commitment.type) {
      case 'task':
        return `Quick update: The task "${commitment.description}" is due ${timeUntil}. I'm on track to complete it on time.`;
      case 'deadline':
        return `Just a heads up: The deadline for "${commitment.description}" is ${timeUntil}. Everything is progressing as planned.`;
      case 'promise':
        return `Quick reminder: I committed to "${commitment.description}" which is due ${timeUntil}. I'll make sure it's done on time.`;
      default:
        return `Status update: "${commitment.description}" is due ${timeUntil}.`;
    }
  }
  
  /**
   * Generate follow-up message
   */
  private generateFollowUpMessage(commitment: Commitment): string {
    return `I wanted to follow up on "${commitment.description}" which was due ${this.formatTimeAgo(commitment.dueDate)}. I apologize for the delay. I'm working on it now and will have it completed soon.`;
  }
  
  /**
   * Generate meeting confirmation message
   */
  private generateMeetingConfirmationMessage(commitment: Commitment): string {
    const timeUntil = this.formatTimeUntil(commitment.dueDate);
    return `Just confirming our meeting ${timeUntil}. I'm looking forward to it. Let me know if anything changes!`;
  }
  
  /**
   * Format time until date
   */
  private formatTimeUntil(date: Date): string {
    const hours = (date.getTime() - Date.now()) / (1000 * 60 * 60);
    
    if (hours < 1) {
      return 'in less than an hour';
    } else if (hours < 24) {
      return `in ${Math.round(hours)} hours`;
    } else {
      const days = Math.round(hours / 24);
      return `in ${days} day${days > 1 ? 's' : ''}`;
    }
  }
  
  /**
   * Format time ago
   */
  private formatTimeAgo(date: Date): string {
    const hours = (Date.now() - date.getTime()) / (1000 * 60 * 60);
    
    if (hours < 24) {
      return `${Math.round(hours)} hours ago`;
    } else {
      const days = Math.round(hours / 24);
      return `${days} day${days > 1 ? 's' : ''} ago`;
    }
  }
  
  /**
   * Calculate days since date
   */
  private daysSince(date: Date): number {
    return (Date.now() - date.getTime()) / (1000 * 60 * 60 * 24);
  }
  
  /**
   * Get all scheduled messages
   */
  getScheduledMessages(): ProactiveMessage[] {
    return Array.from(this.scheduledMessages.values());
  }
  
  /**
   * Get pending messages (not yet sent)
   */
  getPendingMessages(): ProactiveMessage[] {
    return this.getScheduledMessages().filter(m => !m.sent);
  }
}

/**
 * Relationship Manager Service
 * 
 * Tracks relationship health and suggests check-ins.
 */
export class RelationshipManager {
  private lastContacts: Map<string, Date> = new Map();
  private relationshipTypes: Map<string, RelationshipHealth['relationshipType']> = new Map();
  private importanceScores: Map<string, number> = new Map();
  
  /**
   * Update last contact time
   */
  updateLastContact(contactId: string, date: Date): void {
    this.lastContacts.set(contactId, date);
  }
  
  /**
   * Set relationship type
   */
  setRelationshipType(contactId: string, type: RelationshipHealth['relationshipType']): void {
    this.relationshipTypes.set(contactId, type);
  }
  
  /**
   * Set importance score
   */
  setImportanceScore(contactId: string, score: number): void {
    this.importanceScores.set(contactId, Math.max(1, Math.min(10, score)));
  }
  
  /**
   * Get relationship health for contact
   */
  getRelationshipHealth(contactId: string, contactName: string, platform: string): RelationshipHealth {
    const lastContact = this.lastContacts.get(contactId) || new Date(0);
    const daysSince = (Date.now() - lastContact.getTime()) / (1000 * 60 * 60 * 24);
    const relationshipType = this.relationshipTypes.get(contactId) || 'acquaintance';
    const importance = this.importanceScores.get(contactId) || 5;
    
    // Determine if check-in is suggested
    const suggestedCheckIn = this.shouldSuggestCheckIn(daysSince, relationshipType, importance);
    
    return {
      contactId,
      contactName,
      platform,
      lastContact,
      daysSinceLastContact: Math.round(daysSince),
      relationshipType,
      importance,
      suggestedCheckIn,
      suggestedMessage: suggestedCheckIn ? this.generateCheckInMessage(contactName, relationshipType) : undefined,
    };
  }
  
  /**
   * Determine if check-in should be suggested
   */
  private shouldSuggestCheckIn(
    daysSince: number,
    relationshipType: RelationshipHealth['relationshipType'],
    importance: number
  ): boolean {
    // Thresholds based on relationship type
    const thresholds: Record<RelationshipHealth['relationshipType'], number> = {
      family: 7,
      friend: 14,
      colleague: 30,
      client: 21,
      acquaintance: 60,
    };
    
    const threshold = thresholds[relationshipType];
    
    // Adjust threshold based on importance (higher importance = more frequent check-ins)
    const adjustedThreshold = threshold * (11 - importance) / 10;
    
    return daysSince > adjustedThreshold;
  }
  
  /**
   * Generate check-in message
   */
  private generateCheckInMessage(
    contactName: string,
    relationshipType: RelationshipHealth['relationshipType']
  ): string {
    const messages: Record<RelationshipHealth['relationshipType'], string[]> = {
      family: [
        `Hey ${contactName}! It's been a while. How have you been?`,
        `Hi ${contactName}! Just wanted to check in and see how things are going.`,
        `Hey! I was thinking about you. How's everything?`,
      ],
      friend: [
        `Hey ${contactName}! Long time no talk. What's new with you?`,
        `Hi! I realized we haven't caught up in a while. How are you?`,
        `Hey! Want to grab coffee/lunch sometime soon?`,
      ],
      colleague: [
        `Hi ${contactName}, hope you're doing well! Any updates on your end?`,
        `Hey ${contactName}, just checking in. How are things going?`,
        `Hi! Wanted to touch base. Anything I can help with?`,
      ],
      client: [
        `Hi ${contactName}, hope everything is going well! Just wanted to check in.`,
        `Hello ${contactName}, checking in to see if there's anything you need.`,
        `Hi! Just wanted to touch base and see how things are progressing.`,
      ],
      acquaintance: [
        `Hi ${contactName}, hope you're doing well!`,
        `Hey ${contactName}, just wanted to say hi!`,
        `Hi! Hope everything is going great for you.`,
      ],
    };
    
    const options = messages[relationshipType];
    return options[Math.floor(Math.random() * options.length)];
  }
  
  /**
   * Get all relationships needing check-in
   */
  getSuggestedCheckIns(): RelationshipHealth[] {
    const suggested: RelationshipHealth[] = [];
    
    for (const [contactId, lastContact] of this.lastContacts.entries()) {
      const health = this.getRelationshipHealth(contactId, contactId, 'unknown');
      if (health.suggestedCheckIn) {
        suggested.push(health);
      }
    }
    
    // Sort by importance and days since last contact
    return suggested.sort((a, b) => {
      const scoreA = a.importance * a.daysSinceLastContact;
      const scoreB = b.importance * b.daysSinceLastContact;
      return scoreB - scoreA;
    });
  }
}

/**
 * Global instances
 */
let commitmentTrackerInstance: CommitmentTracker | null = null;
let proactiveMessengerInstance: ProactiveMessenger | null = null;
let relationshipManagerInstance: RelationshipManager | null = null;

/**
 * Get or create commitment tracker instance
 */
export function getCommitmentTracker(): CommitmentTracker {
  if (!commitmentTrackerInstance) {
    commitmentTrackerInstance = new CommitmentTracker();
  }
  return commitmentTrackerInstance;
}

/**
 * Get or create proactive messenger instance
 */
export function getProactiveMessenger(): ProactiveMessenger {
  if (!proactiveMessengerInstance) {
    proactiveMessengerInstance = new ProactiveMessenger(getCommitmentTracker());
  }
  return proactiveMessengerInstance;
}

/**
 * Get or create relationship manager instance
 */
export function getRelationshipManager(): RelationshipManager {
  if (!relationshipManagerInstance) {
    relationshipManagerInstance = new RelationshipManager();
  }
  return relationshipManagerInstance;
}
