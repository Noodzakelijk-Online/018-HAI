/**
 * Message Orchestration Service
 * 
 * Coordinates the entire autonomous communication pipeline:
 * 1. Ingest messages from all platforms
 * 2. Analyze through triple-layer system
 * 3. Generate response
 * 4. Validate and score confidence
 * 5. Send autonomously or escalate for human review
 */

import type { UnifiedMessage, BasePlatformConnector, SendResult } from './BasePlatformConnector';
import { TripleLayerAnalyzer, type TripleLayerAnalysisResult } from './TripleLayerAnalyzer';
import { AutonomousResponseGenerator, NaturalTimingSimulator, type GeneratedResponse, type ResponseGenerationContext } from './AutonomousResponseGenerator';

export interface OrchestratorConfig {
  // Confidence thresholds
  autoSendThreshold: number; // >= this: send autonomously (default: 90)
  monitoredSendThreshold: number; // >= this: send with monitoring (default: 70)
  draftThreshold: number; // >= this: generate draft, escalate (default: 50)
  // < draftThreshold: flag for manual handling
  
  // Platform settings
  enabledPlatforms: string[];
  
  // Timing settings
  enableNaturalTiming: boolean;
  minDelay: number; // seconds
  maxDelay: number; // seconds
  
  // VIP contacts (always escalate)
  vipContacts: string[];
  
  // Sensitive keywords (trigger escalation)
  sensitiveKeywords: string[];
}

export interface ProcessedMessage {
  message: UnifiedMessage;
  analysis: TripleLayerAnalysisResult;
  response?: GeneratedResponse;
  decision: 'auto_send' | 'monitored_send' | 'escalate' | 'manual';
  sendAt?: Date;
  status: 'pending' | 'sent' | 'escalated' | 'failed';
  error?: string;
}

export class MessageOrchestrator {
  private analyzer: TripleLayerAnalyzer;
  private generator: AutonomousResponseGenerator;
  private timingSimulator: NaturalTimingSimulator;
  private config: OrchestratorConfig;
  
  // In-memory queues (in production, use database)
  private processingQueue: Map<string, ProcessedMessage> = new Map();
  private escalationQueue: Map<string, ProcessedMessage> = new Map();
  private sentMessages: Map<string, ProcessedMessage> = new Map();
  
  constructor(config: Partial<OrchestratorConfig> = {}) {
    this.analyzer = new TripleLayerAnalyzer();
    this.generator = new AutonomousResponseGenerator();
    this.timingSimulator = new NaturalTimingSimulator();
    
    this.config = {
      autoSendThreshold: config.autoSendThreshold || 90,
      monitoredSendThreshold: config.monitoredSendThreshold || 70,
      draftThreshold: config.draftThreshold || 50,
      enabledPlatforms: config.enabledPlatforms || [],
      enableNaturalTiming: config.enableNaturalTiming !== false,
      minDelay: config.minDelay || 10,
      maxDelay: config.maxDelay || 600,
      vipContacts: config.vipContacts || [],
      sensitiveKeywords: config.sensitiveKeywords || [
        'legal', 'lawsuit', 'attorney', 'lawyer',
        'financial', 'bank', 'payment', 'invoice',
        'health', 'medical', 'doctor', 'hospital',
        'confidential', 'private', 'secret',
        'urgent', 'emergency', 'critical',
      ],
    };
  }
  
  /**
   * Process incoming message through the full pipeline
   */
  async processMessage(
    message: UnifiedMessage,
    connector: BasePlatformConnector,
    context: Partial<ResponseGenerationContext> = {}
  ): Promise<ProcessedMessage> {
    console.log(`[Orchestrator] Processing message ${message.id} from ${message.platform}`);
    
    try {
      // Step 1: Check if message should be processed
      if (!this.shouldProcess(message)) {
        console.log(`[Orchestrator] Skipping message ${message.id} (filtered)`);
        return {
          message,
          analysis: {} as TripleLayerAnalysisResult,
          decision: 'manual',
          status: 'escalated',
        };
      }
      
      // Step 2: Generate initial response
      const generatedResponse = await this.generator.generate({
        message,
        ...context,
      });
      
      console.log(`[Orchestrator] Generated response with ${generatedResponse.confidence}% confidence`);
      
      // Step 3: Analyze through triple-layer system
      const analysis = await this.analyzer.analyze(
        message,
        generatedResponse.text,
        context as Record<string, any>
      );
      
      console.log(`[Orchestrator] Analysis complete: ${analysis.compositeConfidence}% composite confidence`);
      
      // Step 4: Make decision based on confidence and context
      const decision = this.makeDecision(message, analysis, generatedResponse);
      
      console.log(`[Orchestrator] Decision: ${decision}`);
      
      // Step 5: Calculate send time (if applicable)
      let sendAt: Date | undefined;
      if (decision === 'auto_send' || decision === 'monitored_send') {
        const delay = this.config.enableNaturalTiming
          ? this.timingSimulator.calculateDelay(
              message,
              generatedResponse.text.length,
              analysis.intentEmotional.urgency.score
            )
          : 0;
        
        sendAt = new Date(Date.now() + delay * 1000);
        console.log(`[Orchestrator] Scheduled to send at ${sendAt.toISOString()} (${delay}s delay)`);
      }
      
      // Step 6: Create processed message record
      const processed: ProcessedMessage = {
        message,
        analysis,
        response: generatedResponse,
        decision,
        sendAt,
        status: 'pending',
      };
      
      // Step 7: Route based on decision
      if (decision === 'auto_send' || decision === 'monitored_send') {
        this.processingQueue.set(message.id, processed);
        
        // Schedule send
        if (sendAt) {
          const delay = sendAt.getTime() - Date.now();
          setTimeout(() => {
            this.sendResponse(message.id, connector).catch(err => {
              console.error(`[Orchestrator] Failed to send message ${message.id}:`, err);
            });
          }, delay);
        }
      } else {
        // Escalate for human review
        this.escalationQueue.set(message.id, processed);
        console.log(`[Orchestrator] Message ${message.id} escalated for human review`);
      }
      
      return processed;
      
    } catch (error) {
      console.error(`[Orchestrator] Error processing message ${message.id}:`, error);
      
      // On error, escalate for manual handling
      const processed: ProcessedMessage = {
        message,
        analysis: {} as TripleLayerAnalysisResult,
        decision: 'manual',
        status: 'failed',
        error: error instanceof Error ? error.message : 'Unknown error',
      };
      
      this.escalationQueue.set(message.id, processed);
      return processed;
    }
  }
  
  /**
   * Check if message should be processed
   */
  private shouldProcess(message: UnifiedMessage): boolean {
    // Skip outgoing messages (we only process incoming)
    if (message.direction === 'outgoing') {
      return false;
    }
    
    // Check if platform is enabled
    if (this.config.enabledPlatforms.length > 0 &&
        !this.config.enabledPlatforms.includes(message.platform)) {
      return false;
    }
    
    return true;
  }
  
  /**
   * Make decision based on analysis results
   */
  private makeDecision(
    message: UnifiedMessage,
    analysis: TripleLayerAnalysisResult,
    response: GeneratedResponse
  ): 'auto_send' | 'monitored_send' | 'escalate' | 'manual' {
    const { compositeConfidence, shouldEscalate, escalationReasons } = analysis;
    
    // Check VIP contacts (always escalate)
    if (this.isVIPContact(message.senderId)) {
      console.log(`[Orchestrator] VIP contact detected: ${message.senderName}`);
      return 'escalate';
    }
    
    // Check sensitive keywords
    if (this.containsSensitiveKeywords(message.textContent)) {
      console.log(`[Orchestrator] Sensitive keywords detected`);
      return 'escalate';
    }
    
    // Check if analysis recommends escalation
    if (shouldEscalate) {
      console.log(`[Orchestrator] Analysis recommends escalation: ${escalationReasons.join(', ')}`);
      return 'escalate';
    }
    
    // Decision based on confidence thresholds
    if (compositeConfidence >= this.config.autoSendThreshold) {
      return 'auto_send';
    } else if (compositeConfidence >= this.config.monitoredSendThreshold) {
      return 'monitored_send';
    } else if (compositeConfidence >= this.config.draftThreshold) {
      return 'escalate';
    } else {
      return 'manual';
    }
  }
  
  /**
   * Check if contact is VIP
   */
  private isVIPContact(senderId: string): boolean {
    return this.config.vipContacts.includes(senderId);
  }
  
  /**
   * Check if message contains sensitive keywords
   */
  private containsSensitiveKeywords(text: string): boolean {
    const lowerText = text.toLowerCase();
    return this.config.sensitiveKeywords.some(keyword =>
      lowerText.includes(keyword.toLowerCase())
    );
  }
  
  /**
   * Send response through platform connector
   */
  private async sendResponse(
    messageId: string,
    connector: BasePlatformConnector
  ): Promise<void> {
    const processed = this.processingQueue.get(messageId);
    if (!processed || !processed.response) {
      console.error(`[Orchestrator] No processed message found for ${messageId}`);
      return;
    }
    
    console.log(`[Orchestrator] Sending response for message ${messageId}`);
    
    try {
      // Show typing indicator if supported
      const capabilities = connector.getCapabilities();
      if (capabilities.supportsTypingIndicator) {
        const typingDuration = this.timingSimulator.calculateTypingDuration(
          processed.response.text.length
        );
        await connector.showTypingIndicator(
          processed.message.conversationId,
          typingDuration
        );
        
        // Wait for typing indicator duration
        await new Promise(resolve => setTimeout(resolve, typingDuration * 1000));
      }
      
      // Send message
      const responseMessage: UnifiedMessage = {
        ...processed.message,
        id: `response-${messageId}`,
        textContent: processed.response.text,
        direction: 'outgoing',
        timestamp: new Date(),
        status: 'sending' as any,
      };
      
      const result: SendResult = await connector.sendMessage(responseMessage);
      
      if (result.success) {
        console.log(`[Orchestrator] Response sent successfully: ${result.messageId}`);
        processed.status = 'sent';
        this.sentMessages.set(messageId, processed);
        this.processingQueue.delete(messageId);
      } else {
        console.error(`[Orchestrator] Failed to send response: ${result.error}`);
        processed.status = 'failed';
        processed.error = result.error;
        
        // Escalate failed sends
        this.escalationQueue.set(messageId, processed);
        this.processingQueue.delete(messageId);
      }
      
    } catch (error) {
      console.error(`[Orchestrator] Error sending response for ${messageId}:`, error);
      processed.status = 'failed';
      processed.error = error instanceof Error ? error.message : 'Unknown error';
      
      // Escalate errors
      this.escalationQueue.set(messageId, processed);
      this.processingQueue.delete(messageId);
    }
  }
  
  /**
   * Get escalation queue (for human review interface)
   */
  getEscalationQueue(): ProcessedMessage[] {
    return Array.from(this.escalationQueue.values());
  }
  
  /**
   * Approve and send escalated message
   */
  async approveEscalation(
    messageId: string,
    connector: BasePlatformConnector,
    editedResponse?: string
  ): Promise<void> {
    const processed = this.escalationQueue.get(messageId);
    if (!processed) {
      throw new Error(`No escalated message found for ${messageId}`);
    }
    
    // If response was edited, update it
    if (editedResponse && processed.response) {
      processed.response.text = editedResponse;
    }
    
    // Move to processing queue and send
    this.escalationQueue.delete(messageId);
    this.processingQueue.set(messageId, processed);
    
    await this.sendResponse(messageId, connector);
  }
  
  /**
   * Reject escalated message (mark as manual handling)
   */
  rejectEscalation(messageId: string): void {
    const processed = this.escalationQueue.get(messageId);
    if (processed) {
      processed.decision = 'manual';
      processed.status = 'escalated';
      this.escalationQueue.delete(messageId);
    }
  }
  
  /**
   * Get statistics
   */
  getStatistics() {
    return {
      processing: this.processingQueue.size,
      escalated: this.escalationQueue.size,
      sent: this.sentMessages.size,
      total: this.processingQueue.size + this.escalationQueue.size + this.sentMessages.size,
    };
  }
  
  /**
   * Update configuration
   */
  updateConfig(config: Partial<OrchestratorConfig>): void {
    this.config = {
      ...this.config,
      ...config,
    };
  }
}

/**
 * Global orchestrator instance
 */
export const messageOrchestrator = new MessageOrchestrator();
