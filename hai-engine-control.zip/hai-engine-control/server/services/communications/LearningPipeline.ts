/**
 * Learning Pipeline
 * 
 * Collects feedback from human reviews and continuously improves
 * the autonomous communication system based on patterns and outcomes.
 */

import { UnifiedMessage } from './BasePlatformConnector';
import { TripleLayerAnalysis } from './TripleLayerAnalyzer';
import { GeneratedResponse } from './AutonomousResponseGenerator';

export interface FeedbackRecord {
  id: string;
  messageId: string;
  platform: string;
  timestamp: Date;
  
  // Original data
  originalMessage: UnifiedMessage;
  analysis: TripleLayerAnalysis;
  generatedResponse: GeneratedResponse;
  
  // Human decision
  decision: 'approved' | 'rejected' | 'edited';
  editedResponse?: string;
  rejectionReason?: string;
  
  // Outcome tracking
  confidenceScore: number;
  wasCorrectDecision: boolean; // Did the confidence match the outcome?
  responseQuality?: number; // 1-5 rating (optional)
  
  // Context
  conversationContext: {
    previousMessages: number;
    relationshipType: string;
    urgencyLevel: string;
  };
}

export interface LearningInsight {
  type: 'pattern' | 'threshold' | 'tone' | 'escalation';
  category: string;
  insight: string;
  confidence: number;
  sampleSize: number;
  recommendation: string;
}

export interface LearningMetrics {
  totalFeedback: number;
  approvalRate: number;
  editRate: number;
  rejectionRate: number;
  
  confidenceAccuracy: number; // How often does confidence match outcome?
  averageConfidenceScore: number;
  
  platformMetrics: Record<string, {
    approvalRate: number;
    averageConfidence: number;
    sampleSize: number;
  }>;
  
  relationshipMetrics: Record<string, {
    approvalRate: number;
    averageConfidence: number;
    sampleSize: number;
  }>;
  
  trends: {
    approvalRateTrend: number; // Positive = improving
    confidenceAccuracyTrend: number;
  };
}

/**
 * Feedback Collector Service
 * 
 * Collects and stores feedback from human reviews.
 */
export class FeedbackCollector {
  private feedbackRecords: Map<string, FeedbackRecord> = new Map();
  
  /**
   * Record feedback from human review
   */
  recordFeedback(
    messageId: string,
    originalMessage: UnifiedMessage,
    analysis: TripleLayerAnalysis,
    generatedResponse: GeneratedResponse,
    decision: 'approved' | 'rejected' | 'edited',
    options?: {
      editedResponse?: string;
      rejectionReason?: string;
      responseQuality?: number;
    }
  ): FeedbackRecord {
    const feedback: FeedbackRecord = {
      id: `feedback-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      messageId,
      platform: originalMessage.platform,
      timestamp: new Date(),
      
      originalMessage,
      analysis,
      generatedResponse,
      
      decision,
      editedResponse: options?.editedResponse,
      rejectionReason: options?.rejectionReason,
      
      confidenceScore: generatedResponse.confidence,
      wasCorrectDecision: this.evaluateDecisionCorrectness(
        generatedResponse.confidence,
        decision
      ),
      responseQuality: options?.responseQuality,
      
      conversationContext: {
        previousMessages: 0, // TODO: Get from conversation history
        relationshipType: analysis.layer2.intent || 'unknown',
        urgencyLevel: analysis.layer2.urgency || 'normal',
      },
    };
    
    this.feedbackRecords.set(feedback.id, feedback);
    
    console.log('[FeedbackCollector] Recorded feedback:', {
      decision,
      confidence: generatedResponse.confidence,
      wasCorrect: feedback.wasCorrectDecision,
    });
    
    return feedback;
  }
  
  /**
   * Evaluate if the confidence score matched the outcome
   */
  private evaluateDecisionCorrectness(
    confidence: number,
    decision: 'approved' | 'rejected' | 'edited'
  ): boolean {
    if (confidence >= 90 && decision === 'approved') {
      return true; // High confidence, approved = correct
    } else if (confidence < 70 && (decision === 'rejected' || decision === 'edited')) {
      return true; // Low confidence, needed review = correct
    } else if (confidence >= 70 && confidence < 90 && decision === 'edited') {
      return true; // Medium confidence, minor edits = correct
    }
    return false;
  }
  
  /**
   * Get all feedback records
   */
  getAllFeedback(): FeedbackRecord[] {
    return Array.from(this.feedbackRecords.values());
  }
  
  /**
   * Get feedback by platform
   */
  getFeedbackByPlatform(platform: string): FeedbackRecord[] {
    return this.getAllFeedback().filter(f => f.platform === platform);
  }
  
  /**
   * Get feedback by decision
   */
  getFeedbackByDecision(decision: 'approved' | 'rejected' | 'edited'): FeedbackRecord[] {
    return this.getAllFeedback().filter(f => f.decision === decision);
  }
  
  /**
   * Get recent feedback
   */
  getRecentFeedback(limit: number = 100): FeedbackRecord[] {
    return this.getAllFeedback()
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }
}

/**
 * Pattern Analyzer Service
 * 
 * Analyzes feedback patterns to identify improvement opportunities.
 */
export class PatternAnalyzer {
  private feedbackCollector: FeedbackCollector;
  
  constructor(feedbackCollector: FeedbackCollector) {
    this.feedbackCollector = feedbackCollector;
  }
  
  /**
   * Analyze patterns and generate insights
   */
  analyzePatterns(): LearningInsight[] {
    const insights: LearningInsight[] = [];
    const feedback = this.feedbackCollector.getAllFeedback();
    
    if (feedback.length < 10) {
      return []; // Need more data
    }
    
    // Analyze confidence threshold accuracy
    insights.push(...this.analyzeConfidenceThresholds(feedback));
    
    // Analyze platform-specific patterns
    insights.push(...this.analyzePlatformPatterns(feedback));
    
    // Analyze relationship-specific patterns
    insights.push(...this.analyzeRelationshipPatterns(feedback));
    
    // Analyze tone adaptation patterns
    insights.push(...this.analyzeTonePatterns(feedback));
    
    // Analyze escalation trigger effectiveness
    insights.push(...this.analyzeEscalationPatterns(feedback));
    
    return insights;
  }
  
  /**
   * Analyze confidence threshold accuracy
   */
  private analyzeConfidenceThresholds(feedback: FeedbackRecord[]): LearningInsight[] {
    const insights: LearningInsight[] = [];
    
    // Group by confidence ranges
    const ranges = [
      { min: 90, max: 100, label: 'Very High (90-100%)' },
      { min: 80, max: 90, label: 'High (80-90%)' },
      { min: 70, max: 80, label: 'Medium (70-80%)' },
      { min: 0, max: 70, label: 'Low (<70%)' },
    ];
    
    for (const range of ranges) {
      const rangeData = feedback.filter(
        f => f.confidenceScore >= range.min && f.confidenceScore < range.max
      );
      
      if (rangeData.length < 5) continue;
      
      const approvalRate = rangeData.filter(f => f.decision === 'approved').length / rangeData.length;
      const correctDecisions = rangeData.filter(f => f.wasCorrectDecision).length / rangeData.length;
      
      if (correctDecisions < 0.7) {
        insights.push({
          type: 'threshold',
          category: 'confidence',
          insight: `Confidence range ${range.label} has low accuracy (${(correctDecisions * 100).toFixed(1)}%)`,
          confidence: 0.8,
          sampleSize: rangeData.length,
          recommendation: approvalRate > 0.8
            ? `Consider lowering threshold for this range`
            : `Consider raising threshold for this range`,
        });
      }
    }
    
    return insights;
  }
  
  /**
   * Analyze platform-specific patterns
   */
  private analyzePlatformPatterns(feedback: FeedbackRecord[]): LearningInsight[] {
    const insights: LearningInsight[] = [];
    
    const platforms = new Set(feedback.map(f => f.platform));
    
    for (const platform of platforms) {
      const platformData = feedback.filter(f => f.platform === platform);
      
      if (platformData.length < 10) continue;
      
      const approvalRate = platformData.filter(f => f.decision === 'approved').length / platformData.length;
      const avgConfidence = platformData.reduce((sum, f) => sum + f.confidenceScore, 0) / platformData.length;
      
      if (approvalRate < 0.7) {
        insights.push({
          type: 'pattern',
          category: 'platform',
          insight: `Platform "${platform}" has low approval rate (${(approvalRate * 100).toFixed(1)}%)`,
          confidence: 0.85,
          sampleSize: platformData.length,
          recommendation: `Review ${platform}-specific response generation and tone adaptation`,
        });
      }
      
      if (avgConfidence > 85 && approvalRate < 0.8) {
        insights.push({
          type: 'threshold',
          category: 'platform',
          insight: `Platform "${platform}" has overconfident responses`,
          confidence: 0.9,
          sampleSize: platformData.length,
          recommendation: `Lower confidence threshold for ${platform} or improve validation`,
        });
      }
    }
    
    return insights;
  }
  
  /**
   * Analyze relationship-specific patterns
   */
  private analyzeRelationshipPatterns(feedback: FeedbackRecord[]): LearningInsight[] {
    const insights: LearningInsight[] = [];
    
    const relationships = new Set(feedback.map(f => f.conversationContext.relationshipType));
    
    for (const relationship of relationships) {
      const relationshipData = feedback.filter(
        f => f.conversationContext.relationshipType === relationship
      );
      
      if (relationshipData.length < 10) continue;
      
      const approvalRate = relationshipData.filter(f => f.decision === 'approved').length / relationshipData.length;
      
      if (approvalRate < 0.7) {
        insights.push({
          type: 'pattern',
          category: 'relationship',
          insight: `Relationship type "${relationship}" has low approval rate (${(approvalRate * 100).toFixed(1)}%)`,
          confidence: 0.8,
          sampleSize: relationshipData.length,
          recommendation: `Review tone adaptation for ${relationship} relationships`,
        });
      }
    }
    
    return insights;
  }
  
  /**
   * Analyze tone adaptation patterns
   */
  private analyzeTonePatterns(feedback: FeedbackRecord[]): LearningInsight[] {
    const insights: LearningInsight[] = [];
    
    // Analyze edited responses for tone issues
    const edited = feedback.filter(f => f.decision === 'edited' && f.editedResponse);
    
    if (edited.length > 5) {
      insights.push({
        type: 'tone',
        category: 'adaptation',
        insight: `${edited.length} responses required tone adjustments`,
        confidence: 0.75,
        sampleSize: edited.length,
        recommendation: 'Review tone adaptation rules and improve context understanding',
      });
    }
    
    return insights;
  }
  
  /**
   * Analyze escalation trigger effectiveness
   */
  private analyzeEscalationPatterns(feedback: FeedbackRecord[]): LearningInsight[] {
    const insights: LearningInsight[] = [];
    
    // Analyze false positives (escalated but approved without changes)
    const falsePositives = feedback.filter(
      f => f.confidenceScore < 90 && f.decision === 'approved' && !f.editedResponse
    );
    
    if (falsePositives.length > feedback.length * 0.2) {
      insights.push({
        type: 'escalation',
        category: 'false_positive',
        insight: `${(falsePositives.length / feedback.length * 100).toFixed(1)}% of escalations were unnecessary`,
        confidence: 0.85,
        sampleSize: falsePositives.length,
        recommendation: 'Lower escalation threshold or improve confidence scoring',
      });
    }
    
    // Analyze false negatives (auto-sent but should have been escalated)
    const falseNegatives = feedback.filter(
      f => f.confidenceScore >= 90 && (f.decision === 'rejected' || f.decision === 'edited')
    );
    
    if (falseNegatives.length > feedback.length * 0.1) {
      insights.push({
        type: 'escalation',
        category: 'false_negative',
        insight: `${(falseNegatives.length / feedback.length * 100).toFixed(1)}% of auto-sent messages needed review`,
        confidence: 0.9,
        sampleSize: falseNegatives.length,
        recommendation: 'Raise escalation threshold or improve validation pipeline',
      });
    }
    
    return insights;
  }
  
  /**
   * Calculate learning metrics
   */
  calculateMetrics(): LearningMetrics {
    const feedback = this.feedbackCollector.getAllFeedback();
    
    if (feedback.length === 0) {
      return {
        totalFeedback: 0,
        approvalRate: 0,
        editRate: 0,
        rejectionRate: 0,
        confidenceAccuracy: 0,
        averageConfidenceScore: 0,
        platformMetrics: {},
        relationshipMetrics: {},
        trends: {
          approvalRateTrend: 0,
          confidenceAccuracyTrend: 0,
        },
      };
    }
    
    const approved = feedback.filter(f => f.decision === 'approved').length;
    const edited = feedback.filter(f => f.decision === 'edited').length;
    const rejected = feedback.filter(f => f.decision === 'rejected').length;
    const correctDecisions = feedback.filter(f => f.wasCorrectDecision).length;
    
    // Calculate platform metrics
    const platformMetrics: Record<string, any> = {};
    const platforms = new Set(feedback.map(f => f.platform));
    
    for (const platform of platforms) {
      const platformData = feedback.filter(f => f.platform === platform);
      platformMetrics[platform] = {
        approvalRate: platformData.filter(f => f.decision === 'approved').length / platformData.length,
        averageConfidence: platformData.reduce((sum, f) => sum + f.confidenceScore, 0) / platformData.length,
        sampleSize: platformData.length,
      };
    }
    
    // Calculate relationship metrics
    const relationshipMetrics: Record<string, any> = {};
    const relationships = new Set(feedback.map(f => f.conversationContext.relationshipType));
    
    for (const relationship of relationships) {
      const relationshipData = feedback.filter(f => f.conversationContext.relationshipType === relationship);
      relationshipMetrics[relationship] = {
        approvalRate: relationshipData.filter(f => f.decision === 'approved').length / relationshipData.length,
        averageConfidence: relationshipData.reduce((sum, f) => sum + f.confidenceScore, 0) / relationshipData.length,
        sampleSize: relationshipData.length,
      };
    }
    
    // Calculate trends (compare recent vs older feedback)
    const recent = feedback.slice(-50);
    const older = feedback.slice(0, -50);
    
    const recentApprovalRate = recent.filter(f => f.decision === 'approved').length / recent.length;
    const olderApprovalRate = older.length > 0
      ? older.filter(f => f.decision === 'approved').length / older.length
      : recentApprovalRate;
    
    const recentAccuracy = recent.filter(f => f.wasCorrectDecision).length / recent.length;
    const olderAccuracy = older.length > 0
      ? older.filter(f => f.wasCorrectDecision).length / older.length
      : recentAccuracy;
    
    return {
      totalFeedback: feedback.length,
      approvalRate: approved / feedback.length,
      editRate: edited / feedback.length,
      rejectionRate: rejected / feedback.length,
      confidenceAccuracy: correctDecisions / feedback.length,
      averageConfidenceScore: feedback.reduce((sum, f) => sum + f.confidenceScore, 0) / feedback.length,
      platformMetrics,
      relationshipMetrics,
      trends: {
        approvalRateTrend: recentApprovalRate - olderApprovalRate,
        confidenceAccuracyTrend: recentAccuracy - olderAccuracy,
      },
    };
  }
}

/**
 * Continuous Improvement Service
 * 
 * Applies learning insights to improve the system.
 */
export class ContinuousImprovementService {
  private patternAnalyzer: PatternAnalyzer;
  
  constructor(patternAnalyzer: PatternAnalyzer) {
    this.patternAnalyzer = patternAnalyzer;
  }
  
  /**
   * Get improvement recommendations
   */
  getRecommendations(): LearningInsight[] {
    const insights = this.patternAnalyzer.analyzePatterns();
    
    // Sort by confidence and sample size
    return insights.sort((a, b) => {
      const scoreA = a.confidence * Math.log(a.sampleSize + 1);
      const scoreB = b.confidence * Math.log(b.sampleSize + 1);
      return scoreB - scoreA;
    });
  }
  
  /**
   * Apply automatic improvements
   */
  applyAutomaticImprovements(): {
    applied: number;
    recommendations: string[];
  } {
    const insights = this.getRecommendations();
    let applied = 0;
    const recommendations: string[] = [];
    
    for (const insight of insights) {
      if (insight.confidence >= 0.9 && insight.sampleSize >= 20) {
        // High confidence, large sample size - can apply automatically
        console.log('[ContinuousImprovement] Auto-applying:', insight.recommendation);
        applied++;
      } else {
        // Lower confidence - recommend for manual review
        recommendations.push(insight.recommendation);
      }
    }
    
    return { applied, recommendations };
  }
}

/**
 * Global instances
 */
let feedbackCollectorInstance: FeedbackCollector | null = null;
let patternAnalyzerInstance: PatternAnalyzer | null = null;
let continuousImprovementInstance: ContinuousImprovementService | null = null;

/**
 * Get or create feedback collector instance
 */
export function getFeedbackCollector(): FeedbackCollector {
  if (!feedbackCollectorInstance) {
    feedbackCollectorInstance = new FeedbackCollector();
  }
  return feedbackCollectorInstance;
}

/**
 * Get or create pattern analyzer instance
 */
export function getPatternAnalyzer(): PatternAnalyzer {
  if (!patternAnalyzerInstance) {
    patternAnalyzerInstance = new PatternAnalyzer(getFeedbackCollector());
  }
  return patternAnalyzerInstance;
}

/**
 * Get or create continuous improvement instance
 */
export function getContinuousImprovementService(): ContinuousImprovementService {
  if (!continuousImprovementInstance) {
    continuousImprovementInstance = new ContinuousImprovementService(getPatternAnalyzer());
  }
  return continuousImprovementInstance;
}
