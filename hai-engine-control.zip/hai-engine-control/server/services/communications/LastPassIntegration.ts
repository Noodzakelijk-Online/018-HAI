/**
 * LastPass Integration Service
 * 
 * Provides secure access to credentials stored in LastPass vault for
 * universal platform access across all communication channels.
 * 
 * This service enables the autonomous communication system to:
 * - Access credentials for any platform stored in LastPass
 * - Automatically authenticate to platforms without manual intervention
 * - Securely manage and rotate credentials
 * - Enable truly universal communication coverage
 */

import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

export interface LastPassCredential {
  id: string;
  name: string;
  username: string;
  password: string;
  url?: string;
  notes?: string;
  group?: string;
}

export interface LastPassSearchOptions {
  name?: string;
  url?: string;
  group?: string;
}

/**
 * LastPass Integration Service
 * 
 * Uses LastPass CLI (lpass) to access credentials from the vault.
 * 
 * Prerequisites:
 * - LastPass CLI must be installed: `brew install lastpass-cli` or `apt-get install lastpass-cli`
 * - User must be logged in: `lpass login <email>`
 * - Session must be active (or use `--trust` flag during login)
 */
export class LastPassIntegration {
  private isLoggedIn: boolean = false;
  private email: string | null = null;
  
  /**
   * Check if LastPass CLI is installed
   */
  async isInstalled(): Promise<boolean> {
    try {
      await execAsync('which lpass');
      return true;
    } catch {
      return false;
    }
  }
  
  /**
   * Check if user is logged in
   */
  async checkLoginStatus(): Promise<boolean> {
    try {
      const { stdout } = await execAsync('lpass status');
      this.isLoggedIn = stdout.includes('Logged in as');
      
      if (this.isLoggedIn) {
        const match = stdout.match(/Logged in as (.+)\./);
        this.email = match ? match[1] : null;
      }
      
      return this.isLoggedIn;
    } catch {
      this.isLoggedIn = false;
      return false;
    }
  }
  
  /**
   * Login to LastPass
   * 
   * Note: This requires interactive input for the master password.
   * For automated systems, ensure the session is already active or use
   * environment variables with the --trust flag.
   */
  async login(email: string, masterPassword?: string): Promise<void> {
    if (!await this.isInstalled()) {
      throw new Error('LastPass CLI is not installed');
    }
    
    try {
      if (masterPassword) {
        // Non-interactive login (requires LPASS_DISABLE_PINENTRY=1)
        await execAsync(`echo "${masterPassword}" | LPASS_DISABLE_PINENTRY=1 lpass login ${email}`);
      } else {
        // Interactive login
        await execAsync(`lpass login ${email}`);
      }
      
      this.isLoggedIn = true;
      this.email = email;
    } catch (error) {
      throw new Error(`LastPass login failed: ${error}`);
    }
  }
  
  /**
   * Logout from LastPass
   */
  async logout(): Promise<void> {
    try {
      await execAsync('lpass logout --force');
      this.isLoggedIn = false;
      this.email = null;
    } catch (error) {
      console.error('[LastPass] Logout failed:', error);
    }
  }
  
  /**
   * Search for credentials
   */
  async search(options: LastPassSearchOptions): Promise<LastPassCredential[]> {
    if (!await this.checkLoginStatus()) {
      throw new Error('Not logged in to LastPass');
    }
    
    try {
      let query = '';
      if (options.name) query = options.name;
      else if (options.url) query = options.url;
      else if (options.group) query = options.group;
      
      const { stdout } = await execAsync(`lpass ls --long --format="%ai|%an|%au|%ap|%al|%ag" | grep -i "${query}"`);
      
      const lines = stdout.trim().split('\n');
      return lines.map(line => {
        const [id, name, username, password, url, group] = line.split('|');
        return {
          id,
          name,
          username,
          password,
          url,
          group,
        };
      });
    } catch (error) {
      // No results found
      return [];
    }
  }
  
  /**
   * Get credential by exact name
   */
  async getCredential(name: string): Promise<LastPassCredential | null> {
    if (!await this.checkLoginStatus()) {
      throw new Error('Not logged in to LastPass');
    }
    
    try {
      const { stdout: username } = await execAsync(`lpass show --username "${name}"`);
      const { stdout: password } = await execAsync(`lpass show --password "${name}"`);
      const { stdout: url } = await execAsync(`lpass show --url "${name}"`);
      const { stdout: notes } = await execAsync(`lpass show --notes "${name}"`);
      const { stdout: id } = await execAsync(`lpass show --id "${name}"`);
      
      return {
        id: id.trim(),
        name,
        username: username.trim(),
        password: password.trim(),
        url: url.trim() || undefined,
        notes: notes.trim() || undefined,
      };
    } catch (error) {
      return null;
    }
  }
  
  /**
   * Get credential by ID
   */
  async getCredentialById(id: string): Promise<LastPassCredential | null> {
    if (!await this.checkLoginStatus()) {
      throw new Error('Not logged in to LastPass');
    }
    
    try {
      const { stdout: name } = await execAsync(`lpass show --name ${id}`);
      const { stdout: username } = await execAsync(`lpass show --username ${id}`);
      const { stdout: password } = await execAsync(`lpass show --password ${id}`);
      const { stdout: url } = await execAsync(`lpass show --url ${id}`);
      const { stdout: notes } = await execAsync(`lpass show --notes ${id}`);
      
      return {
        id,
        name: name.trim(),
        username: username.trim(),
        password: password.trim(),
        url: url.trim() || undefined,
        notes: notes.trim() || undefined,
      };
    } catch (error) {
      return null;
    }
  }
  
  /**
   * List all credentials
   */
  async listAll(): Promise<Array<{ id: string; name: string; group: string }>> {
    if (!await this.checkLoginStatus()) {
      throw new Error('Not logged in to LastPass');
    }
    
    try {
      const { stdout } = await execAsync('lpass ls --long --format="%ai|%an|%ag"');
      
      const lines = stdout.trim().split('\n');
      return lines.map(line => {
        const [id, name, group] = line.split('|');
        return { id, name, group };
      });
    } catch (error) {
      return [];
    }
  }
  
  /**
   * Get credentials for a specific platform
   * 
   * Searches by platform name and returns the most relevant credential.
   */
  async getCredentialForPlatform(platform: string): Promise<LastPassCredential | null> {
    const platformMappings: Record<string, string[]> = {
      'twitter': ['twitter', 'x.com'],
      'linkedin': ['linkedin'],
      'facebook': ['facebook', 'fb.com'],
      'slack': ['slack'],
      'discord': ['discord'],
      'telegram': ['telegram'],
      'instagram': ['instagram'],
      'whatsapp': ['whatsapp'],
      'email': ['gmail', 'outlook', 'email'],
    };
    
    const searchTerms = platformMappings[platform.toLowerCase()] || [platform];
    
    for (const term of searchTerms) {
      const results = await this.search({ name: term });
      if (results.length > 0) {
        // Return the first result (most relevant)
        return results[0];
      }
    }
    
    return null;
  }
}

/**
 * Global LastPass instance
 */
let lastPassInstance: LastPassIntegration | null = null;

/**
 * Get or create LastPass integration instance
 */
export function getLastPassIntegration(): LastPassIntegration {
  if (!lastPassInstance) {
    lastPassInstance = new LastPassIntegration();
  }
  return lastPassInstance;
}

/**
 * Platform Credential Manager
 * 
 * Manages credentials for all communication platforms using LastPass.
 */
export class PlatformCredentialManager {
  private lastpass: LastPassIntegration;
  private credentialCache: Map<string, { credential: LastPassCredential; timestamp: number }> = new Map();
  private cacheTTL: number = 3600000; // 1 hour
  
  constructor() {
    this.lastpass = getLastPassIntegration();
  }
  
  /**
   * Get credentials for a platform
   */
  async getCredentials(platform: string): Promise<LastPassCredential | null> {
    // Check cache first
    const cached = this.credentialCache.get(platform);
    if (cached && Date.now() - cached.timestamp < this.cacheTTL) {
      return cached.credential;
    }
    
    // Fetch from LastPass
    const credential = await this.lastpass.getCredentialForPlatform(platform);
    
    if (credential) {
      // Cache the result
      this.credentialCache.set(platform, {
        credential,
        timestamp: Date.now(),
      });
    }
    
    return credential;
  }
  
  /**
   * Clear credential cache
   */
  clearCache(): void {
    this.credentialCache.clear();
  }
  
  /**
   * Clear credential cache for a specific platform
   */
  clearPlatformCache(platform: string): void {
    this.credentialCache.delete(platform);
  }
  
  /**
   * Check if credentials are available for a platform
   */
  async hasCredentials(platform: string): Promise<boolean> {
    const credentials = await this.getCredentials(platform);
    return credentials !== null;
  }
  
  /**
   * Get all available platforms (platforms with credentials in LastPass)
   */
  async getAvailablePlatforms(): Promise<string[]> {
    const allCredentials = await this.lastpass.listAll();
    
    const platformKeywords = [
      'twitter', 'linkedin', 'facebook', 'slack', 'discord', 'telegram',
      'instagram', 'whatsapp', 'email', 'gmail', 'outlook', 'teams',
      'messenger', 'signal', 'snapchat', 'tiktok', 'reddit'
    ];
    
    const platforms = new Set<string>();
    
    for (const cred of allCredentials) {
      const nameLower = cred.name.toLowerCase();
      for (const keyword of platformKeywords) {
        if (nameLower.includes(keyword)) {
          platforms.add(keyword);
        }
      }
    }
    
    return Array.from(platforms);
  }
}

/**
 * Global credential manager instance
 */
let credentialManagerInstance: PlatformCredentialManager | null = null;

/**
 * Get or create platform credential manager instance
 */
export function getPlatformCredentialManager(): PlatformCredentialManager {
  if (!credentialManagerInstance) {
    credentialManagerInstance = new PlatformCredentialManager();
  }
  return credentialManagerInstance;
}
