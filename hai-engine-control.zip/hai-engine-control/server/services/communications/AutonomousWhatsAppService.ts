/**
 * Autonomous WhatsApp Service
 * 
 * Integrates WhatsApp connector with the autonomous communication system.
 * Provides end-to-end autonomous message handling for WhatsApp.
 */

import { EventEmitter } from 'events';
import { WhatsAppPlatformConnector, createWhatsAppPlatformConnector } from './connectors/WhatsAppPlatformConnector';
import { MessageOrchestrator } from './MessageOrchestrator';
import { knowledgeGraph } from './DigitalEcosystemIntegration';
import { platformRegistry } from './BasePlatformConnector';
import type { UnifiedMessage } from './BasePlatformConnector';
import type { ProcessedMessage } from './MessageOrchestrator';

export interface AutonomousWhatsAppConfig {
  userId: number;
  autoSendThreshold?: number; // Default: 90
  monitoredSendThreshold?: number; // Default: 70
  draftThreshold?: number; // Default: 50
  enableNaturalTiming?: boolean; // Default: true
  vipContacts?: string[]; // Phone numbers of VIP contacts
  enabledForContacts?: string[]; // If set, only process these contacts
  disabledForContacts?: string[]; // If set, never process these contacts
}

export class AutonomousWhatsAppService extends EventEmitter {
  private connector: WhatsAppPlatformConnector;
  private orchestrator: MessageOrchestrator;
  private config: AutonomousWhatsAppConfig;
  private isRunning: boolean = false;
  
  constructor(config: AutonomousWhatsAppConfig) {
    super();
    this.config = config;
    
    // Create WhatsApp connector
    this.connector = createWhatsAppPlatformConnector(config.userId);
    
    // Register connector
    platformRegistry.register(this.connector);
    
    // Create orchestrator with config
    this.orchestrator = new MessageOrchestrator({
      autoSendThreshold: config.autoSendThreshold || 90,
      monitoredSendThreshold: config.monitoredSendThreshold || 70,
      draftThreshold: config.draftThreshold || 50,
      enableNaturalTiming: config.enableNaturalTiming !== false,
      enabledPlatforms: ['whatsapp'],
      vipContacts: config.vipContacts || [],
    });
    
    // Set up event listeners
    this.setupEventListeners();
  }
  
  /**
   * Set up event listeners
   */
  private setupEventListeners(): void {
    // Connector events
    this.connector.on('connected', () => {
      console.log('[AutonomousWhatsApp] Connected');
      this.emit('connected');
    });
    
    this.connector.on('disconnected', () => {
      console.log('[AutonomousWhatsApp] Disconnected');
      this.emit('disconnected');
    });
    
    this.connector.on('error', (error: Error) => {
      console.error('[AutonomousWhatsApp] Error:', error);
      this.emit('error', error);
    });
    
    // Message events
    this.connector.on('message', async (message: UnifiedMessage) => {
      if (!this.isRunning) return;
      
      // Check if we should process this message
      if (!this.shouldProcessMessage(message)) {
        console.log(`[AutonomousWhatsApp] Skipping message from ${message.senderName} (filtered)`);
        return;
      }
      
      console.log(`[AutonomousWhatsApp] Processing message from ${message.senderName}: ${message.textContent}`);
      
      try {
        // Get conversation history
        const conversationHistory = await this.connector.getConversationHistory(
          message.conversationId,
          10
        );
        
        // Get sender profile
        const senderProfile = await this.connector.getSenderProfile(message.senderId);
        
        // Get context from knowledge graph
        const context = await knowledgeGraph.getContext(
          message.textContent,
          message.senderId
        );
        
        // Process through orchestrator
        const result = await this.orchestrator.processMessage(
          message,
          this.connector,
          {
            conversationHistory,
            senderProfile: senderProfile || undefined,
            relevantEmails: context.emails,
            relevantCalendarEvents: context.events,
            relevantDocuments: context.files,
          }
        );
        
        // Emit result
        this.emit('messageProcessed', result);
        
        // Log decision
        console.log(`[AutonomousWhatsApp] Decision: ${result.decision}, Confidence: ${result.analysis?.compositeConfidence || 0}%`);
        
        if (result.decision === 'escalate' || result.decision === 'manual') {
          console.log(`[AutonomousWhatsApp] Message escalated for human review`);
          this.emit('escalation', result);
        } else {
          console.log(`[AutonomousWhatsApp] Response scheduled: ${result.response?.text}`);
        }
        
      } catch (error) {
        console.error('[AutonomousWhatsApp] Error processing message:', error);
        this.emit('processingError', { message, error });
      }
    });
  }
  
  /**
   * Check if message should be processed
   */
  private shouldProcessMessage(message: UnifiedMessage): boolean {
    // Skip outgoing messages
    if (message.direction === 'outgoing') {
      return false;
    }
    
    // Check enabled/disabled lists
    if (this.config.enabledForContacts && this.config.enabledForContacts.length > 0) {
      if (!this.config.enabledForContacts.includes(message.senderId)) {
        return false;
      }
    }
    
    if (this.config.disabledForContacts && this.config.disabledForContacts.length > 0) {
      if (this.config.disabledForContacts.includes(message.senderId)) {
        return false;
      }
    }
    
    return true;
  }
  
  /**
   * Start autonomous processing
   */
  async start(): Promise<void> {
    if (this.isRunning) {
      throw new Error('Service already running');
    }
    
    console.log('[AutonomousWhatsApp] Starting service...');
    
    // Connect to WhatsApp
    await this.connector.connect();
    
    // Mark as running
    this.isRunning = true;
    
    console.log('[AutonomousWhatsApp] Service started');
    this.emit('started');
  }
  
  /**
   * Stop autonomous processing
   */
  async stop(): Promise<void> {
    if (!this.isRunning) {
      return;
    }
    
    console.log('[AutonomousWhatsApp] Stopping service...');
    
    // Mark as stopped
    this.isRunning = false;
    
    // Disconnect from WhatsApp
    await this.connector.disconnect();
    
    console.log('[AutonomousWhatsApp] Service stopped');
    this.emit('stopped');
  }
  
  /**
   * Get escalation queue
   */
  getEscalationQueue(): ProcessedMessage[] {
    return this.orchestrator.getEscalationQueue();
  }
  
  /**
   * Approve escalated message
   */
  async approveEscalation(messageId: string, editedResponse?: string): Promise<void> {
    await this.orchestrator.approveEscalation(messageId, this.connector, editedResponse);
  }
  
  /**
   * Reject escalated message
   */
  rejectEscalation(messageId: string): void {
    this.orchestrator.rejectEscalation(messageId);
  }
  
  /**
   * Get statistics
   */
  getStatistics() {
    return {
      ...this.orchestrator.getStatistics(),
      isRunning: this.isRunning,
      isConnected: this.connector.isConnected(),
    };
  }
  
  /**
   * Update configuration
   */
  updateConfig(config: Partial<AutonomousWhatsAppConfig>): void {
    this.config = {
      ...this.config,
      ...config,
    };
    
    // Update orchestrator config
    this.orchestrator.updateConfig({
      autoSendThreshold: config.autoSendThreshold,
      monitoredSendThreshold: config.monitoredSendThreshold,
      draftThreshold: config.draftThreshold,
      enableNaturalTiming: config.enableNaturalTiming,
      vipContacts: config.vipContacts,
    });
  }
  
  /**
   * Send manual message
   */
  async sendMessage(conversationId: string, text: string): Promise<void> {
    const message: UnifiedMessage = {
      id: `manual-${Date.now()}`,
      platform: 'whatsapp',
      connectorId: this.connector.connectorId,
      conversationId,
      senderId: 'me',
      senderName: 'Me',
      textContent: text,
      timestamp: new Date(),
      direction: 'outgoing',
      status: 'sending',
    };
    
    await this.connector.sendMessage(message);
  }
}

/**
 * Global service instances (one per user)
 */
const services = new Map<number, AutonomousWhatsAppService>();

/**
 * Get or create autonomous WhatsApp service for a user
 */
export function getAutonomousWhatsAppService(
  userId: number,
  config?: Partial<AutonomousWhatsAppConfig>
): AutonomousWhatsAppService {
  let service = services.get(userId);
  
  if (!service) {
    service = new AutonomousWhatsAppService({
      userId,
      ...config,
    });
    services.set(userId, service);
  } else if (config) {
    service.updateConfig(config);
  }
  
  return service;
}

/**
 * Remove service for a user
 */
export async function removeAutonomousWhatsAppService(userId: number): Promise<void> {
  const service = services.get(userId);
  if (service) {
    await service.stop();
    services.delete(userId);
  }
}
