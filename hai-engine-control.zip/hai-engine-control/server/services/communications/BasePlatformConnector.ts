/**
 * Base Platform Connector Interface
 * 
 * Defines the common interface that all platform connectors must implement.
 * This enables platform-agnostic message handling across WhatsApp, Email, SMS,
 * Slack, Discord, Teams, Telegram, Twitter, LinkedIn, Facebook, Trello, etc.
 */

export enum PlatformType {
  WHATSAPP = 'whatsapp',
  EMAIL = 'email',
  SMS = 'sms',
  SLACK = 'slack',
  DISCORD = 'discord',
  TEAMS = 'teams',
  TELEGRAM = 'telegram',
  TWITTER = 'twitter',
  LINKEDIN = 'linkedin',
  FACEBOOK_MESSENGER = 'facebook_messenger',
  TRELLO = 'trello',
  NOTION = 'notion',
  SIGNAL = 'signal',
  INSTAGRAM = 'instagram',
  OTHER = 'other',
}

export enum MessageStatus {
  QUEUED = 'queued',
  SENDING = 'sending',
  SENT = 'sent',
  DELIVERED = 'delivered',
  READ = 'read',
  FAILED = 'failed',
}

export interface MediaAttachment {
  type: 'image' | 'video' | 'audio' | 'document' | 'location' | 'contact';
  url: string;
  filename?: string;
  mimeType?: string;
  size?: number;
  thumbnail?: string;
  metadata?: Record<string, any>;
}

export interface UnifiedMessage {
  // Identification
  id: string; // System-generated unique ID
  platform: PlatformType;
  platformMessageId: string; // Platform-specific message ID
  
  // Participants
  senderId: string; // Platform-specific sender ID
  senderName: string;
  senderEmail?: string;
  senderPhone?: string;
  conversationId: string; // Unique conversation/thread ID
  
  // Content
  textContent: string;
  htmlContent?: string;
  mediaAttachments?: MediaAttachment[];
  mentions?: string[]; // User IDs mentioned in message
  links?: string[]; // URLs extracted from message
  
  // Context
  timestamp: Date;
  timezone?: string;
  language?: string;
  threadId?: string; // For threaded conversations
  quotedMessage?: Partial<UnifiedMessage>; // Reply context
  
  // Status
  status: MessageStatus;
  direction: 'incoming' | 'outgoing';
  
  // Metadata
  platformMetadata: Record<string, any>; // Platform-specific data
}

export interface SendResult {
  success: boolean;
  messageId?: string; // Platform-specific message ID
  platformMessageId?: string;
  status: MessageStatus;
  error?: string;
  timestamp: Date;
}

export interface ConnectionStatus {
  connected: boolean;
  lastConnected?: Date;
  lastDisconnected?: Date;
  error?: string;
  metadata?: Record<string, any>;
}

export interface PlatformCapabilities {
  supportsReadReceipts: boolean;
  supportsTypingIndicator: boolean;
  supportsMediaAttachments: boolean;
  supportsThreads: boolean;
  supportsReactions: boolean;
  supportsEditing: boolean;
  supportsDeleting: boolean;
  supportsForwarding: boolean;
  maxMessageLength: number;
  supportedMediaTypes: string[];
}

/**
 * Base Platform Connector
 * 
 * Abstract base class that all platform connectors extend.
 * Provides common functionality and enforces interface compliance.
 */
export abstract class BasePlatformConnector {
  protected platform: PlatformType;
  protected name: string;
  protected connected: boolean = false;
  protected lastError?: string;
  
  constructor(platform: PlatformType, name: string) {
    this.platform = platform;
    this.name = name;
  }
  
  /**
   * Get platform type
   */
  getPlatform(): PlatformType {
    return this.platform;
  }
  
  /**
   * Get connector name
   */
  getName(): string {
    return this.name;
  }
  
  /**
   * Connect to the platform
   */
  abstract connect(): Promise<void>;
  
  /**
   * Disconnect from the platform
   */
  abstract disconnect(): Promise<void>;
  
  /**
   * Check if currently connected
   */
  isConnected(): boolean {
    return this.connected;
  }
  
  /**
   * Get connection status with details
   */
  abstract getConnectionStatus(): Promise<ConnectionStatus>;
  
  /**
   * Receive messages from the platform
   * Returns an async iterator that yields messages as they arrive
   */
  abstract receiveMessages(): AsyncIterator<UnifiedMessage>;
  
  /**
   * Send a message through the platform
   */
  abstract sendMessage(message: UnifiedMessage): Promise<SendResult>;
  
  /**
   * Get message status (delivery, read receipts, etc.)
   */
  abstract getMessageStatus(messageId: string): Promise<MessageStatus>;
  
  /**
   * Mark a message as read
   */
  abstract markAsRead(messageId: string): Promise<void>;
  
  /**
   * Show typing indicator (if supported)
   */
  abstract showTypingIndicator(conversationId: string, duration?: number): Promise<void>;
  
  /**
   * Get platform capabilities
   */
  abstract getCapabilities(): PlatformCapabilities;
  
  /**
   * Normalize platform-specific message to unified format
   */
  protected abstract normalizeMessage(platformMessage: any): UnifiedMessage;
  
  /**
   * Convert unified message to platform-specific format
   */
  protected abstract denormalizeMessage(unifiedMessage: UnifiedMessage): any;
  
  /**
   * Handle connection errors
   */
  protected handleError(error: Error): void {
    this.lastError = error.message;
    this.connected = false;
    console.error(`[${this.name}] Error:`, error);
  }
  
  /**
   * Get last error message
   */
  getLastError(): string | undefined {
    return this.lastError;
  }
}

/**
 * Platform Connector Registry
 * 
 * Manages all registered platform connectors and provides
 * unified access to all platforms.
 */
export class PlatformConnectorRegistry {
  private connectors: Map<string, BasePlatformConnector> = new Map();
  
  /**
   * Register a new platform connector
   */
  register(id: string, connector: BasePlatformConnector): void {
    this.connectors.set(id, connector);
  }
  
  /**
   * Unregister a platform connector
   */
  unregister(id: string): void {
    const connector = this.connectors.get(id);
    if (connector && connector.isConnected()) {
      connector.disconnect();
    }
    this.connectors.delete(id);
  }
  
  /**
   * Get a specific connector by ID
   */
  get(id: string): BasePlatformConnector | undefined {
    return this.connectors.get(id);
  }
  
  /**
   * Get all connectors
   */
  getAll(): BasePlatformConnector[] {
    return Array.from(this.connectors.values());
  }
  
  /**
   * Get connectors by platform type
   */
  getByPlatform(platform: PlatformType): BasePlatformConnector[] {
    return this.getAll().filter(c => c.getPlatform() === platform);
  }
  
  /**
   * Get all connected connectors
   */
  getConnected(): BasePlatformConnector[] {
    return this.getAll().filter(c => c.isConnected());
  }
  
  /**
   * Connect all registered connectors
   */
  async connectAll(): Promise<void> {
    const promises = this.getAll().map(c => c.connect().catch(err => {
      console.error(`Failed to connect ${c.getName()}:`, err);
    }));
    await Promise.all(promises);
  }
  
  /**
   * Disconnect all connectors
   */
  async disconnectAll(): Promise<void> {
    const promises = this.getAll().map(c => c.disconnect().catch(err => {
      console.error(`Failed to disconnect ${c.getName()}:`, err);
    }));
    await Promise.all(promises);
  }
}

// Global registry instance
export const platformRegistry = new PlatformConnectorRegistry();
