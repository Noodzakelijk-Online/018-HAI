/**
 * Lazy Loading Service Initialization
 * Implements P2 #91: Implement lazy loading for services
 */

export type ServiceFactory<T> = () => T | Promise<T>;

export interface LazyServiceOptions {
  timeout?: number;
  onLoad?: (service: any) => void;
  onError?: (error: Error) => void;
}

/**
 * Lazy service wrapper
 */
export class LazyService<T> {
  private instance: T | null = null;
  private loading: Promise<T> | null = null;
  private factory: ServiceFactory<T>;
  private options: LazyServiceOptions;

  constructor(factory: ServiceFactory<T>, options: LazyServiceOptions = {}) {
    this.factory = factory;
    this.options = options;
  }

  /**
   * Get the service instance (lazy initialization)
   */
  async get(): Promise<T> {
    if (this.instance) {
      return this.instance;
    }

    if (this.loading) {
      return this.loading;
    }

    this.loading = this.initialize();
    return this.loading;
  }

  /**
   * Initialize the service
   */
  private async initialize(): Promise<T> {
    try {
      const result = this.factory();
      this.instance = result instanceof Promise ? await result : result;
      this.options.onLoad?.(this.instance);
      return this.instance;
    } catch (error) {
      const err = error instanceof Error ? error : new Error(String(error));
      this.options.onError?.(err);
      this.loading = null;
      throw err;
    }
  }

  /**
   * Check if service is loaded
   */
  isLoaded(): boolean {
    return this.instance !== null;
  }

  /**
   * Reset the service (force re-initialization on next get)
   */
  reset(): void {
    this.instance = null;
    this.loading = null;
  }

  /**
   * Get instance synchronously (throws if not loaded)
   */
  getSync(): T {
    if (!this.instance) {
      throw new Error('Service not yet initialized. Call get() first.');
    }
    return this.instance;
  }
}

/**
 * Service registry with lazy loading
 */
class ServiceRegistry {
  private services: Map<string, LazyService<any>> = new Map();
  private loadOrder: string[] = [];

  /**
   * Register a service
   */
  register<T>(
    name: string,
    factory: ServiceFactory<T>,
    options: LazyServiceOptions = {}
  ): void {
    this.services.set(name, new LazyService(factory, options));
    this.loadOrder.push(name);
  }

  /**
   * Get a service
   */
  async get<T>(name: string): Promise<T> {
    const service = this.services.get(name);
    if (!service) {
      throw new Error(`Service '${name}' not registered`);
    }
    return service.get();
  }

  /**
   * Check if service is registered
   */
  has(name: string): boolean {
    return this.services.has(name);
  }

  /**
   * Check if service is loaded
   */
  isLoaded(name: string): boolean {
    return this.services.get(name)?.isLoaded() ?? false;
  }

  /**
   * Get all registered service names
   */
  getNames(): string[] {
    return Array.from(this.services.keys());
  }

  /**
   * Get loaded service names
   */
  getLoadedNames(): string[] {
    return this.getNames().filter(name => this.isLoaded(name));
  }

  /**
   * Preload specific services
   */
  async preload(names: string[]): Promise<void> {
    await Promise.all(names.map(name => this.get(name)));
  }

  /**
   * Preload all services
   */
  async preloadAll(): Promise<void> {
    await this.preload(this.getNames());
  }

  /**
   * Reset a service
   */
  reset(name: string): void {
    this.services.get(name)?.reset();
  }

  /**
   * Reset all services
   */
  resetAll(): void {
    for (const service of this.services.values()) {
      service.reset();
    }
  }

  /**
   * Get service status
   */
  getStatus(): Record<string, { registered: boolean; loaded: boolean }> {
    const status: Record<string, { registered: boolean; loaded: boolean }> = {};
    
    for (const name of this.getNames()) {
      status[name] = {
        registered: true,
        loaded: this.isLoaded(name),
      };
    }
    
    return status;
  }
}

export const serviceRegistry = new ServiceRegistry();

/**
 * Create a lazy singleton
 */
export function lazySingleton<T>(factory: ServiceFactory<T>): () => Promise<T> {
  const service = new LazyService(factory);
  return () => service.get();
}

/**
 * Decorator for lazy service injection
 */
export function LazyInject(serviceName: string) {
  return function (target: any, propertyKey: string) {
    Object.defineProperty(target, propertyKey, {
      get: async function () {
        return serviceRegistry.get(serviceName);
      },
      enumerable: true,
      configurable: true,
    });
  };
}

/**
 * Module loader with dependencies
 */
export class ModuleLoader {
  private modules: Map<string, {
    factory: ServiceFactory<any>;
    dependencies: string[];
    instance: any;
    loading: boolean;
  }> = new Map();

  /**
   * Register a module
   */
  register(
    name: string,
    factory: ServiceFactory<any>,
    dependencies: string[] = []
  ): void {
    this.modules.set(name, {
      factory,
      dependencies,
      instance: null,
      loading: false,
    });
  }

  /**
   * Load a module and its dependencies
   */
  async load<T>(name: string): Promise<T> {
    const module = this.modules.get(name);
    if (!module) {
      throw new Error(`Module '${name}' not registered`);
    }

    if (module.instance) {
      return module.instance;
    }

    if (module.loading) {
      // Wait for loading to complete
      await new Promise(resolve => setTimeout(resolve, 100));
      return this.load(name);
    }

    module.loading = true;

    // Load dependencies first
    for (const dep of module.dependencies) {
      await this.load(dep);
    }

    // Load the module
    const result = module.factory();
    module.instance = result instanceof Promise ? await result : result;
    module.loading = false;

    return module.instance;
  }

  /**
   * Get load order (topological sort)
   */
  getLoadOrder(): string[] {
    const visited = new Set<string>();
    const order: string[] = [];

    const visit = (name: string) => {
      if (visited.has(name)) return;
      visited.add(name);

      const module = this.modules.get(name);
      if (module) {
        for (const dep of module.dependencies) {
          visit(dep);
        }
        order.push(name);
      }
    };

    for (const name of this.modules.keys()) {
      visit(name);
    }

    return order;
  }

  /**
   * Load all modules in dependency order
   */
  async loadAll(): Promise<void> {
    const order = this.getLoadOrder();
    for (const name of order) {
      await this.load(name);
    }
  }
}

export const moduleLoader = new ModuleLoader();

export default {
  LazyService,
  serviceRegistry,
  lazySingleton,
  LazyInject,
  ModuleLoader,
  moduleLoader,
};
