import { EventBus } from './EventBus';

/**
 * Enhanced Communication Engine - Peak Performance
 * 
 * Features:
 * - Message scheduling and queuing
 * - Sentiment analysis and tone adjustment
 * - Multi-language translation
 * - Read receipts and delivery tracking
 * - Message threading and conversations
 * - Auto-response and canned responses
 * - Priority inbox and smart filtering
 * - Communication analytics and insights
 */

export interface ScheduledMessage {
  id: string;
  channel: 'email' | 'sms' | 'notification' | 'chat';
  recipient: string;
  subject?: string;
  body: string;
  scheduledFor: Date;
  timezone?: string;
  status: 'pending' | 'sent' | 'failed' | 'cancelled';
  retryCount: number;
}

export interface SentimentAnalysis {
  messageId: string;
  sentiment: 'positive' | 'neutral' | 'negative';
  score: number; // -1 to 1
  emotions: Record<string, number>; // joy, anger, sadness, etc.
  tone: 'formal' | 'casual' | 'professional' | 'friendly';
  suggestedTone?: string;
}

export interface Translation {
  originalText: string;
  originalLanguage: string;
  targetLanguage: string;
  translatedText: string;
  confidence: number;
}

export interface ReadReceipt {
  messageId: string;
  recipient: string;
  deliveredAt?: Date;
  readAt?: Date;
  status: 'sent' | 'delivered' | 'read' | 'failed';
}

export interface MessageThread {
  id: string;
  subject: string;
  participants: string[];
  messages: Array<{
    id: string;
    senderId: string;
    body: string;
    timestamp: Date;
    attachments?: string[];
  }>;
  createdAt: Date;
  lastActivity: Date;
  status: 'active' | 'archived' | 'closed';
}

export interface AutoResponse {
  id: string;
  trigger: {
    type: 'keyword' | 'sender' | 'time' | 'absence';
    value: string | string[];
  };
  response: {
    template: string;
    variables?: Record<string, string>;
  };
  enabled: boolean;
  priority: number;
}

export interface CannedResponse {
  id: string;
  name: string;
  category: string;
  template: string;
  variables: string[]; // List of {{variable}} names
  usageCount: number;
  lastUsed?: Date;
}

export interface PriorityRule {
  id: string;
  condition: {
    sender?: string[];
    keywords?: string[];
    hasAttachment?: boolean;
    importance?: 'high' | 'normal' | 'low';
  };
  priority: 'urgent' | 'high' | 'normal' | 'low';
  action?: 'flag' | 'folder' | 'notify';
}

export interface CommunicationInsights {
  userId: string;
  period: { start: Date; end: Date };
  totalMessages: {
    sent: number;
    received: number;
  };
  byChannel: Record<string, { sent: number; received: number }>;
  responseTime: {
    average: number; // minutes
    median: number;
    percentile95: number;
  };
  sentimentDistribution: {
    positive: number;
    neutral: number;
    negative: number;
  };
  topContacts: Array<{ contact: string; messageCount: number }>;
  peakHours: number[]; // Hours of day with most activity
  trends: {
    volumeChange: number; // % change from previous period
    sentimentChange: number;
  };
}

export class CommunicationEngineEnhanced {
  private eventBus: typeof EventBus;
  private scheduledMessages: Map<string, ScheduledMessage> = new Map();
  private sentiments: Map<string, SentimentAnalysis> = new Map();
  private receipts: Map<string, ReadReceipt> = new Map();
  private threads: Map<string, MessageThread> = new Map();
  private autoResponses: Map<string, AutoResponse> = new Map();
  private cannedResponses: Map<string, CannedResponse> = new Map();
  private priorityRules: Map<string, PriorityRule> = new Map();
  private messageHistory: Array<{ id: string; timestamp: Date; channel: string; userId: string }> = [];

  constructor(eventBus: typeof EventBus) {
    this.eventBus = eventBus;
  }

  /**
   * Schedule message for future delivery
   */
  async scheduleMessage(message: Omit<ScheduledMessage, 'id' | 'status' | 'retryCount'>): Promise<ScheduledMessage> {
    const scheduled: ScheduledMessage = {
      ...message,
      id: `sched_${Date.now()}`,
      status: 'pending',
      retryCount: 0,
    };

    this.scheduledMessages.set(scheduled.id, scheduled);

    await this.eventBus.publish({
      type: 'communication.message.scheduled',
      source: 'CommunicationEngine',
      target: 'system',
      data: { messageId: scheduled.id, scheduledFor: scheduled.scheduledFor },
    });

    return scheduled;
  }

  /**
   * Process scheduled messages (called by cron)
   */
  async processScheduledMessages(): Promise<{ sent: number; failed: number }> {
    const now = new Date();
    let sent = 0;
    let failed = 0;

    for (const [id, message] of Array.from(this.scheduledMessages.entries())) {
      if (message.status === 'pending' && message.scheduledFor <= now) {
        try {
          // Simulate sending
          message.status = 'sent';
          sent++;
          
          await this.eventBus.publish({
            type: 'communication.message.sent',
            source: 'CommunicationEngine',
            target: 'system',
            data: { messageId: id, channel: message.channel },
          });
        } catch (error) {
          message.retryCount++;
          if (message.retryCount >= 3) {
            message.status = 'failed';
            failed++;
          }
        }
      }
    }

    return { sent, failed };
  }

  /**
   * Analyze message sentiment
   */
  async analyzeSentiment(messageId: string, text: string): Promise<SentimentAnalysis> {
    // Simplified sentiment analysis
    // In production, use actual NLP library
    const positiveWords = ['great', 'excellent', 'happy', 'love', 'wonderful', 'amazing'];
    const negativeWords = ['bad', 'terrible', 'hate', 'awful', 'poor', 'disappointing'];

    const lowerText = text.toLowerCase();
    let score = 0;

    positiveWords.forEach(word => {
      if (lowerText.includes(word)) score += 0.2;
    });

    negativeWords.forEach(word => {
      if (lowerText.includes(word)) score -= 0.2;
    });

    score = Math.max(-1, Math.min(1, score));

    const sentiment: 'positive' | 'neutral' | 'negative' = 
      score > 0.2 ? 'positive' : score < -0.2 ? 'negative' : 'neutral';

    const emotions = {
      joy: score > 0 ? score : 0,
      anger: score < 0 ? Math.abs(score) * 0.5 : 0,
      sadness: score < 0 ? Math.abs(score) * 0.5 : 0,
    };

    const tone: 'formal' | 'casual' | 'professional' | 'friendly' = 
      lowerText.includes('dear') || lowerText.includes('sincerely') ? 'formal' :
      lowerText.includes('hey') || lowerText.includes('thanks') ? 'casual' :
      'professional';

    const analysis: SentimentAnalysis = {
      messageId,
      sentiment,
      score,
      emotions,
      tone,
      suggestedTone: sentiment === 'negative' ? 'professional' : tone,
    };

    this.sentiments.set(messageId, analysis);

    await this.eventBus.publish({
      type: 'communication.sentiment.analyzed',
      source: 'CommunicationEngine',
      target: 'system',
      data: { messageId, sentiment, score },
    });

    return analysis;
  }

  /**
   * Adjust message tone
   */
  async adjustTone(text: string, targetTone: 'formal' | 'casual' | 'professional' | 'friendly'): Promise<string> {
    // Simplified tone adjustment
    let adjusted = text;

    if (targetTone === 'formal') {
      adjusted = adjusted.replace(/hey/gi, 'Dear');
      adjusted = adjusted.replace(/thanks/gi, 'Thank you');
      adjusted = adjusted.replace(/!/g, '.');
    } else if (targetTone === 'casual') {
      adjusted = adjusted.replace(/Dear/gi, 'Hey');
      adjusted = adjusted.replace(/Thank you/gi, 'Thanks');
    }

    return adjusted;
  }

  /**
   * Translate message
   */
  async translateMessage(text: string, targetLanguage: string): Promise<Translation> {
    // Mock translation (in production, use actual translation API)
    const translation: Translation = {
      originalText: text,
      originalLanguage: 'en',
      targetLanguage,
      translatedText: `[${targetLanguage.toUpperCase()}] ${text}`, // Mock
      confidence: 0.95,
    };

    return translation;
  }

  /**
   * Track read receipt
   */
  async trackReceipt(messageId: string, recipient: string, event: 'delivered' | 'read'): Promise<ReadReceipt> {
    let receipt = this.receipts.get(messageId);

    if (!receipt) {
      receipt = {
        messageId,
        recipient,
        status: 'sent',
      };
    }

    if (event === 'delivered') {
      receipt.deliveredAt = new Date();
      receipt.status = 'delivered';
    } else if (event === 'read') {
      receipt.readAt = new Date();
      receipt.status = 'read';
    }

    this.receipts.set(messageId, receipt);

    await this.eventBus.publish({
      type: 'communication.receipt.tracked',
      source: 'CommunicationEngine',
      target: 'system',
      data: { messageId, event },
    });

    return receipt;
  }

  /**
   * Create or update message thread
   */
  async addToThread(
    threadId: string | null,
    message: { senderId: string; body: string; attachments?: string[] },
    subject?: string,
    participants?: string[]
  ): Promise<MessageThread> {
    let thread: MessageThread;

    if (threadId && this.threads.has(threadId)) {
      thread = this.threads.get(threadId)!;
      thread.messages.push({
        id: `msg_${Date.now()}`,
        ...message,
        timestamp: new Date(),
      });
      thread.lastActivity = new Date();
    } else {
      thread = {
        id: `thread_${Date.now()}`,
        subject: subject || 'Untitled Conversation',
        participants: participants || [message.senderId],
        messages: [{
          id: `msg_${Date.now()}`,
          ...message,
          timestamp: new Date(),
        }],
        createdAt: new Date(),
        lastActivity: new Date(),
        status: 'active',
      };
      this.threads.set(thread.id, thread);
    }

    await this.eventBus.publish({
      type: 'communication.thread.updated',
      source: 'CommunicationEngine',
      target: 'system',
      data: { threadId: thread.id, messagesCount: thread.messages.length },
    });

    return thread;
  }

  /**
   * Create auto-response rule
   */
  async createAutoResponse(autoResponse: Omit<AutoResponse, 'id'>): Promise<AutoResponse> {
    const newAutoResponse: AutoResponse = {
      ...autoResponse,
      id: `auto_${Date.now()}`,
    };

    this.autoResponses.set(newAutoResponse.id, newAutoResponse);

    return newAutoResponse;
  }

  /**
   * Check if message triggers auto-response
   */
  async checkAutoResponse(message: { body: string; sender: string }): Promise<string | null> {
    const sorted = Array.from(this.autoResponses.values())
      .filter(ar => ar.enabled)
      .sort((a, b) => b.priority - a.priority);

    for (const autoResp of sorted) {
      if (autoResp.trigger.type === 'keyword') {
        const keywords = Array.isArray(autoResp.trigger.value) ? autoResp.trigger.value : [autoResp.trigger.value];
        if (keywords.some(kw => message.body.toLowerCase().includes(kw.toLowerCase()))) {
          return this.renderTemplate(autoResp.response.template, autoResp.response.variables || {});
        }
      } else if (autoResp.trigger.type === 'sender') {
        const senders = Array.isArray(autoResp.trigger.value) ? autoResp.trigger.value : [autoResp.trigger.value];
        if (senders.includes(message.sender)) {
          return this.renderTemplate(autoResp.response.template, autoResp.response.variables || {});
        }
      }
    }

    return null;
  }

  /**
   * Create canned response
   */
  async createCannedResponse(response: Omit<CannedResponse, 'id' | 'usageCount' | 'lastUsed'>): Promise<CannedResponse> {
    const newResponse: CannedResponse = {
      ...response,
      id: `canned_${Date.now()}`,
      usageCount: 0,
    };

    this.cannedResponses.set(newResponse.id, newResponse);

    return newResponse;
  }

  /**
   * Use canned response
   */
  async useCannedResponse(id: string, variables: Record<string, string>): Promise<string> {
    const response = this.cannedResponses.get(id);
    if (!response) {
      throw new Error('Canned response not found');
    }

    response.usageCount++;
    response.lastUsed = new Date();

    return this.renderTemplate(response.template, variables);
  }

  private renderTemplate(template: string, variables: Record<string, string>): string {
    let rendered = template;
    Object.entries(variables).forEach(([key, value]) => {
      rendered = rendered.replace(new RegExp(`{{${key}}}`, 'g'), value);
    });
    return rendered;
  }

  /**
   * Create priority rule
   */
  async createPriorityRule(rule: Omit<PriorityRule, 'id'>): Promise<PriorityRule> {
    const newRule: PriorityRule = {
      ...rule,
      id: `priority_${Date.now()}`,
    };

    this.priorityRules.set(newRule.id, newRule);

    return newRule;
  }

  /**
   * Determine message priority
   */
  async determinePriority(message: {
    sender: string;
    body: string;
    hasAttachment: boolean;
    importance?: 'high' | 'normal' | 'low';
  }): Promise<'urgent' | 'high' | 'normal' | 'low'> {
    const rules = Array.from(this.priorityRules.values());

    for (const rule of rules) {
      let matches = true;

      if (rule.condition.sender && !rule.condition.sender.includes(message.sender)) {
        matches = false;
      }

      if (rule.condition.keywords) {
        const hasKeyword = rule.condition.keywords.some(kw => 
          message.body.toLowerCase().includes(kw.toLowerCase())
        );
        if (!hasKeyword) matches = false;
      }

      if (rule.condition.hasAttachment !== undefined && rule.condition.hasAttachment !== message.hasAttachment) {
        matches = false;
      }

      if (rule.condition.importance && rule.condition.importance !== message.importance) {
        matches = false;
      }

      if (matches) {
        return rule.priority;
      }
    }

    return 'normal';
  }

  /**
   * Generate communication insights
   */
  async generateInsights(userId: string, period: { start: Date; end: Date }): Promise<CommunicationInsights> {
    const userMessages = this.messageHistory.filter(m =>
      m.userId === userId &&
      m.timestamp >= period.start &&
      m.timestamp <= period.end
    );

    const byChannel: Record<string, { sent: number; received: number }> = {};
    userMessages.forEach(m => {
      if (!byChannel[m.channel]) {
        byChannel[m.channel] = { sent: 0, received: 0 };
      }
      byChannel[m.channel].sent++; // Simplified
    });

    // Mock response time data
    const responseTime = {
      average: 45, // minutes
      median: 30,
      percentile95: 120,
    };

    // Mock sentiment distribution
    const sentiments = Array.from(this.sentiments.values());
    const sentimentDistribution = {
      positive: sentiments.filter(s => s.sentiment === 'positive').length,
      neutral: sentiments.filter(s => s.sentiment === 'neutral').length,
      negative: sentiments.filter(s => s.sentiment === 'negative').length,
    };

    // Peak hours
    const hourCounts = new Map<number, number>();
    userMessages.forEach(m => {
      const hour = m.timestamp.getHours();
      hourCounts.set(hour, (hourCounts.get(hour) || 0) + 1);
    });

    const peakHours: number[] = [];
    let maxCount = 0;
    hourCounts.forEach((count, hour) => {
      if (count > maxCount) {
        maxCount = count;
        peakHours.length = 0;
        peakHours.push(hour);
      } else if (count === maxCount) {
        peakHours.push(hour);
      }
    });

    const insights: CommunicationInsights = {
      userId,
      period,
      totalMessages: {
        sent: userMessages.length,
        received: 0, // Simplified
      },
      byChannel,
      responseTime,
      sentimentDistribution,
      topContacts: [], // Simplified
      peakHours,
      trends: {
        volumeChange: 10, // % change
        sentimentChange: 5,
      },
    };

    await this.eventBus.publish({
      type: 'communication.insights.generated',
      source: 'CommunicationEngine',
      target: 'system',
      data: { userId, messagesCount: userMessages.length },
    });

    return insights;
  }

  /**
   * Get scheduled messages
   */
  getScheduledMessages(status?: ScheduledMessage['status']): ScheduledMessage[] {
    const messages = Array.from(this.scheduledMessages.values());
    return status ? messages.filter(m => m.status === status) : messages;
  }

  /**
   * Get message threads
   */
  getThreads(userId?: string): MessageThread[] {
    const threads = Array.from(this.threads.values());
    return userId ? threads.filter(t => t.participants.includes(userId)) : threads;
  }

  /**
   * Get canned responses
   */
  getCannedResponses(category?: string): CannedResponse[] {
    const responses = Array.from(this.cannedResponses.values());
    return category ? responses.filter(r => r.category === category) : responses;
  }
}
