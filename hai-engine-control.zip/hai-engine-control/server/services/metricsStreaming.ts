/**
 * Real-time Metrics Streaming Service
 * Collects and streams system metrics via WebSocket
 */

import { EventEmitter } from 'events';

export interface SystemMetrics {
  timestamp: Date;
  cpu: {
    usage: number;
    loadAverage: number[];
  };
  memory: {
    heapUsed: number;
    heapTotal: number;
    rss: number;
    external: number;
    usagePercent: number;
  };
  requests: {
    total: number;
    perSecond: number;
    avgResponseTime: number;
    errorRate: number;
  };
  connections: {
    active: number;
    total: number;
  };
  uptime: number;
}

export interface MetricsSnapshot {
  current: SystemMetrics;
  history: SystemMetrics[];
}

class MetricsStreamingService extends EventEmitter {
  private metrics: SystemMetrics[] = [];
  private maxHistorySize = 1000;
  private collectionInterval: NodeJS.Timeout | null = null;
  private requestCount = 0;
  private errorCount = 0;
  private totalResponseTime = 0;
  private activeConnections = 0;
  private totalConnections = 0;
  private lastRequestCount = 0;
  private lastCollectionTime = Date.now();

  constructor() {
    super();
    this.setMaxListeners(100); // Allow many WebSocket connections
  }

  /**
   * Start collecting metrics at specified interval
   */
  start(intervalMs: number = 5000): void {
    if (this.collectionInterval) {
      return; // Already running
    }

    console.log(`[MetricsStreaming] Starting metrics collection (${intervalMs}ms interval)`);
    
    this.collectionInterval = setInterval(() => {
      const metrics = this.collectMetrics();
      this.metrics.push(metrics);
      
      // Trim history
      if (this.metrics.length > this.maxHistorySize) {
        this.metrics = this.metrics.slice(-this.maxHistorySize);
      }
      
      // Emit to all listeners
      this.emit('metrics', metrics);
    }, intervalMs);

    // Collect initial metrics
    const initial = this.collectMetrics();
    this.metrics.push(initial);
    this.emit('metrics', initial);
  }

  /**
   * Stop collecting metrics
   */
  stop(): void {
    if (this.collectionInterval) {
      clearInterval(this.collectionInterval);
      this.collectionInterval = null;
      console.log('[MetricsStreaming] Stopped metrics collection');
    }
  }

  /**
   * Collect current system metrics
   */
  private collectMetrics(): SystemMetrics {
    const memUsage = process.memoryUsage();
    const now = Date.now();
    const timeDelta = (now - this.lastCollectionTime) / 1000;
    
    // Calculate requests per second
    const requestsDelta = this.requestCount - this.lastRequestCount;
    const requestsPerSecond = timeDelta > 0 ? requestsDelta / timeDelta : 0;
    
    // Calculate average response time
    const avgResponseTime = this.requestCount > 0 
      ? this.totalResponseTime / this.requestCount 
      : 0;
    
    // Calculate error rate
    const errorRate = this.requestCount > 0 
      ? (this.errorCount / this.requestCount) * 100 
      : 0;

    // Get CPU usage (simplified - in production use os module or external library)
    const cpuUsage = this.estimateCpuUsage();

    const metrics: SystemMetrics = {
      timestamp: new Date(),
      cpu: {
        usage: cpuUsage,
        loadAverage: this.getLoadAverage(),
      },
      memory: {
        heapUsed: Math.round(memUsage.heapUsed / 1024 / 1024),
        heapTotal: Math.round(memUsage.heapTotal / 1024 / 1024),
        rss: Math.round(memUsage.rss / 1024 / 1024),
        external: Math.round(memUsage.external / 1024 / 1024),
        usagePercent: Math.round((memUsage.heapUsed / memUsage.heapTotal) * 100),
      },
      requests: {
        total: this.requestCount,
        perSecond: Math.round(requestsPerSecond * 100) / 100,
        avgResponseTime: Math.round(avgResponseTime),
        errorRate: Math.round(errorRate * 100) / 100,
      },
      connections: {
        active: this.activeConnections,
        total: this.totalConnections,
      },
      uptime: process.uptime(),
    };

    this.lastRequestCount = this.requestCount;
    this.lastCollectionTime = now;

    return metrics;
  }

  /**
   * Estimate CPU usage (simplified)
   */
  private estimateCpuUsage(): number {
    const usage = process.cpuUsage();
    const total = usage.user + usage.system;
    // Convert to percentage (rough estimate)
    return Math.min(100, Math.round((total / 1000000) * 10) / 10);
  }

  /**
   * Get load average (Unix only)
   */
  private getLoadAverage(): number[] {
    try {
      const os = require('os');
      return os.loadavg().map((v: number) => Math.round(v * 100) / 100);
    } catch {
      return [0, 0, 0];
    }
  }

  /**
   * Record a request (call from middleware)
   */
  recordRequest(responseTimeMs: number, isError: boolean = false): void {
    this.requestCount++;
    this.totalResponseTime += responseTimeMs;
    if (isError) {
      this.errorCount++;
    }
  }

  /**
   * Track connection
   */
  connectionOpened(): void {
    this.activeConnections++;
    this.totalConnections++;
  }

  /**
   * Track connection closed
   */
  connectionClosed(): void {
    this.activeConnections = Math.max(0, this.activeConnections - 1);
  }

  /**
   * Get current metrics snapshot
   */
  getSnapshot(): MetricsSnapshot {
    const current = this.metrics.length > 0 
      ? this.metrics[this.metrics.length - 1] 
      : this.collectMetrics();
    
    return {
      current,
      history: this.metrics.slice(-100), // Last 100 data points
    };
  }

  /**
   * Get metrics history
   */
  getHistory(limit: number = 100): SystemMetrics[] {
    return this.metrics.slice(-limit);
  }

  /**
   * Reset counters (useful for testing)
   */
  reset(): void {
    this.requestCount = 0;
    this.errorCount = 0;
    this.totalResponseTime = 0;
    this.lastRequestCount = 0;
    this.metrics = [];
  }

  /**
   * Get aggregated stats for a time period
   */
  getAggregatedStats(periodMs: number = 3600000): {
    avgResponseTime: number;
    totalRequests: number;
    errorRate: number;
    peakMemory: number;
    avgCpu: number;
  } {
    const cutoff = Date.now() - periodMs;
    const recentMetrics = this.metrics.filter(m => m.timestamp.getTime() > cutoff);
    
    if (recentMetrics.length === 0) {
      return {
        avgResponseTime: 0,
        totalRequests: 0,
        errorRate: 0,
        peakMemory: 0,
        avgCpu: 0,
      };
    }

    const totalRequests = recentMetrics.reduce((sum, m) => sum + m.requests.total, 0);
    const avgResponseTime = recentMetrics.reduce((sum, m) => sum + m.requests.avgResponseTime, 0) / recentMetrics.length;
    const errorRate = recentMetrics.reduce((sum, m) => sum + m.requests.errorRate, 0) / recentMetrics.length;
    const peakMemory = Math.max(...recentMetrics.map(m => m.memory.heapUsed));
    const avgCpu = recentMetrics.reduce((sum, m) => sum + m.cpu.usage, 0) / recentMetrics.length;

    return {
      avgResponseTime: Math.round(avgResponseTime),
      totalRequests,
      errorRate: Math.round(errorRate * 100) / 100,
      peakMemory,
      avgCpu: Math.round(avgCpu * 100) / 100,
    };
  }
}

// Singleton instance
export const metricsStreaming = new MetricsStreamingService();

// Auto-start on import
metricsStreaming.start(5000);

export default metricsStreaming;
