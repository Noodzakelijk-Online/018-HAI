import { createClient, RedisClientType } from 'redis';

/**
 * Standardized event format for all HAI engines
 */
export interface HAIEvent {
  /** Unique event ID (UUID) */
  id: string;
  /** Event type (e.g., "task.created", "email.received", "decision.made") */
  type: string;
  /** Source engine that published the event */
  source: string;
  /** Target engine(s) - "*" for broadcast, defaults to "*" */
  target?: string | string[];
  /** Event payload data */
  data: Record<string, unknown>;
  /** Event metadata */
  metadata: {
    timestamp: string;
    userId?: number;
    priority?: 'low' | 'normal' | 'high' | 'critical';
    correlationId?: string;
    causationId?: string;
  };
}

/**
 * Event handler callback type
 */
export type EventHandler = (event: HAIEvent) => void | Promise<void>;

/**
 * EventBus service for inter-engine communication using Redis Pub/Sub
 * 
 * This provides a decoupled communication mechanism where engines can:
 * - Publish events to notify other engines
 * - Subscribe to specific event types
 * - Broadcast to all engines
 * - Maintain event history for audit
 */
class EventBusService {
  private publisher: RedisClientType | null = null;
  private subscriber: RedisClientType | null = null;
  private handlers: Map<string, Set<EventHandler>> = new Map();
  private connected: boolean = false;
  private eventHistory: HAIEvent[] = [];
  private readonly MAX_HISTORY = 1000;

  /**
   * Initialize Redis connections for pub/sub
   * Falls back to in-memory mode if Redis is unavailable
   */
  async connect(): Promise<void> {
    if (this.connected) return;

    try {
      // Create publisher client
      this.publisher = createClient({
        url: process.env.REDIS_URL || 'redis://localhost:6379',
      });

      // Create subscriber client (must be separate from publisher)
      this.subscriber = createClient({
        url: process.env.REDIS_URL || 'redis://localhost:6379',
      });

      // Connect both clients
      await this.publisher.connect();
      await this.subscriber.connect();

      // Set up message handler for subscriber
      this.subscriber.on('message', (channel: string, message: string) => {
        this.handleMessage(channel, message);
      });

      this.connected = true;
      console.log('[EventBus] Connected to Redis');
    } catch (error) {
      console.warn('[EventBus] Redis not available, using in-memory mode:', error);
      // Use in-memory mode without Redis
      this.connected = true;
      this.publisher = null;
      this.subscriber = null;
    }
  }

  /**
   * Disconnect from Redis
   */
  async disconnect(): Promise<void> {
    if (!this.connected) return;

    try {
      await this.publisher?.quit();
      await this.subscriber?.quit();
      this.connected = false;
      console.log('[EventBus] Disconnected from Redis');
    } catch (error) {
      console.error('[EventBus] Error disconnecting:', error);
    }
  }

  /**
   * Publish an event to the event bus
   * @param event - Event to publish (target defaults to '*' for broadcast)
   */
  async publish(event: { type: string; source: string; target?: string | string[]; data: Record<string, unknown>; metadata?: Partial<HAIEvent['metadata']> }): Promise<void> {
    if (!this.connected) {
      throw new Error('EventBus not connected');
    }

    // Create full event with defaults
    const fullEvent: HAIEvent = {
      id: this.generateEventId(),
      type: event.type,
      source: event.source,
      target: event.target || '*', // Default to broadcast
      data: event.data,
      metadata: {
        timestamp: new Date().toISOString(),
        priority: 'normal',
        ...event.metadata,
      },
    };

    // Store in history
    this.addToHistory(fullEvent);

    if (this.publisher) {
      // Redis mode: publish to channels
      const channels = this.getChannels(fullEvent);
      const message = JSON.stringify(fullEvent);
      for (const channel of channels) {
        await this.publisher.publish(channel, message);
      }
      console.log(`[EventBus] Published event ${fullEvent.type} to ${channels.join(', ')}`);
    } else {
      // In-memory mode: directly call handlers
      const handlers = this.handlers.get(fullEvent.type);
      if (handlers) {
        for (const handler of handlers) {
          try {
            await handler(fullEvent);
          } catch (error) {
            console.error(`[EventBus] Error in handler for ${fullEvent.type}:`, error);
          }
        }
      }
      console.log(`[EventBus] Published event ${fullEvent.type} (in-memory)`);
    }
  }

  /**
   * Check if EventBus is connected
   */
  isConnected(): boolean {
    return this.connected;
  }

  /**
   * Subscribe to specific event types
   */
  async subscribe(eventType: string, handler: EventHandler): Promise<void> {
    if (!this.connected) {
      throw new Error('EventBus not connected');
    }

    // Add handler to map
    if (!this.handlers.has(eventType)) {
      this.handlers.set(eventType, new Set());
      
      // Subscribe to Redis channel if available
      if (this.subscriber) {
        await this.subscriber.subscribe(this.getChannelName(eventType), (message) => {
          this.handleMessage(this.getChannelName(eventType), message);
        });
      }
    }

    this.handlers.get(eventType)!.add(handler);
    console.log(`[EventBus] Subscribed to ${eventType}`);
  }

  /**
   * Unsubscribe from event types
   */
  async unsubscribe(eventType: string, handler?: EventHandler): Promise<void> {
    if (!this.connected || !this.subscriber) return;

    const handlersSet = this.handlers.get(eventType);
    if (!handlersSet) return;

    if (handler) {
      // Remove specific handler
      handlersSet.delete(handler);
      if (handlersSet.size === 0) {
        this.handlers.delete(eventType);
        await this.subscriber.unsubscribe(this.getChannelName(eventType));
      }
    } else {
      // Remove all handlers for this event type
      this.handlers.delete(eventType);
      await this.subscriber.unsubscribe(this.getChannelName(eventType));
    }

    console.log(`[EventBus] Unsubscribed from ${eventType}`);
  }

  /**
   * Get event history (for debugging/audit)
   */
  getHistory(limit?: number): HAIEvent[] {
    if (limit) {
      return this.eventHistory.slice(-limit);
    }
    return [...this.eventHistory];
  }

  /**
   * Clear event history
   */
  clearHistory(): void {
    this.eventHistory = [];
  }

  /**
   * Handle incoming message from Redis
   */
  private handleMessage(channel: string, message: string): void {
    try {
      const event: HAIEvent = JSON.parse(message);
      const handlers = this.handlers.get(event.type);

      if (handlers) {
        // Execute all handlers for this event type
        for (const handler of Array.from(handlers)) {
          try {
            const result = handler(event);
            // Handle async handlers
            if (result instanceof Promise) {
              result.catch((error) => {
                console.error(`[EventBus] Handler error for ${event.type}:`, error);
              });
            }
          } catch (error) {
            console.error(`[EventBus] Handler error for ${event.type}:`, error);
          }
        }
      }
    } catch (error) {
      console.error('[EventBus] Error parsing message:', error);
    }
  }

  /**
   * Get Redis channel name for event type
   */
  private getChannelName(eventType: string): string {
    return `hai:events:${eventType}`;
  }

  /**
   * Get all channels to publish to based on event target
   */
  private getChannels(event: HAIEvent): string[] {
    const channels: string[] = [];

    // Always publish to type-specific channel
    channels.push(this.getChannelName(event.type));

    // If broadcast, also publish to wildcard channel
    if (event.target === '*') {
      channels.push(this.getChannelName('*'));
    }

    // If specific targets, publish to engine-specific channels
    if (Array.isArray(event.target)) {
      for (const target of event.target) {
        channels.push(this.getChannelName(`engine:${target}`));
      }
    } else if (event.target !== '*') {
      channels.push(this.getChannelName(`engine:${event.target}`));
    }

    return channels;
  }

  /**
   * Generate unique event ID
   */
  private generateEventId(): string {
    return `evt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Add event to history with size limit
   */
  private addToHistory(event: HAIEvent): void {
    this.eventHistory.push(event);
    if (this.eventHistory.length > this.MAX_HISTORY) {
      this.eventHistory.shift();
    }
  }
}

// Export singleton instance
export const EventBus = new EventBusService();
export default EventBus;
