import { getDb } from "../db";
import { agents, type Agent, type InsertAgent } from "../../drizzle/schema";
import { eq, and, sql } from "drizzle-orm";
import crypto from "crypto";

/**
 * Generate a secure API key for agent authentication
 */
export function generateApiKey(): string {
  return `hai_${crypto.randomBytes(32).toString("hex")}`;
}

/**
 * Register a new agent
 */
export async function registerAgent(data: {
  name: string;
  type: string;
  userId: number;
  householdId: number;
  capabilities?: any;
}): Promise<Agent> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const apiKey = generateApiKey();

  const [agent] = await db.insert(agents).values({
    name: data.name,
    type: data.type,
    apiKey,
    userId: data.userId,
    householdId: data.householdId,
    capabilities: data.capabilities || {},
    status: "offline",
  }).$returningId();

  const [newAgent] = await db.select().from(agents).where(eq(agents.id, agent.id));
  
  return newAgent!;
}

/**
 * Update agent heartbeat and status
 */
export async function updateAgentHeartbeat(agentId: number, status?: "online" | "offline" | "busy" | "idle"): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const updateData: any = {
    lastHeartbeat: new Date(),
  };

  if (status) {
    updateData.status = status;
  }

  await db.update(agents).set(updateData).where(eq(agents.id, agentId));
}

/**
 * Update agent capabilities
 */
export async function updateAgentCapabilities(agentId: number, capabilities: any): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.update(agents).set({ capabilities }).where(eq(agents.id, agentId));
}

/**
 * Get agent by API key
 */
export async function getAgentByApiKey(apiKey: string): Promise<Agent | undefined> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const [agent] = await db.select().from(agents).where(eq(agents.apiKey, apiKey));
  return agent;
}

/**
 * Get agent by ID
 */
export async function getAgentById(agentId: number): Promise<Agent | undefined> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const [agent] = await db.select().from(agents).where(eq(agents.id, agentId));
  return agent;
}

/**
 * List all agents for a user (legacy - use listAgentsByHousehold instead)
 */
export async function listAgents(userId: number): Promise<Agent[]> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  return await db.select().from(agents).where(eq(agents.userId, userId));
}

/**
 * List all agents for a household
 */
export async function listAgentsByHousehold(householdId: number): Promise<Agent[]> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  return await db.select().from(agents).where(eq(agents.householdId, householdId));
}

/**
 * Get online agents
 */
export async function getOnlineAgents(userId: number): Promise<Agent[]> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  // Consider agents online if heartbeat within last 60 seconds
  const cutoff = new Date(Date.now() - 60 * 1000);

  return await db
    .select()
    .from(agents)
    .where(
      and(
        eq(agents.userId, userId),
        sql`${agents.lastHeartbeat} > ${cutoff}`
      )
    );
}

/**
 * Mark stale agents as offline
 */
export async function markStaleAgentsOffline(): Promise<void> {
  const db = await getDb();
  if (!db) {
    return;
  }

  // Mark agents offline if no heartbeat for 2 minutes
  const cutoff = new Date(Date.now() - 2 * 60 * 1000);

  await db
    .update(agents)
    .set({ status: "offline" })
    .where(
      and(
        sql`${agents.status} != 'offline'`,
        sql`${agents.lastHeartbeat} < ${cutoff}`
      )
    );
}

/**
 * Delete agent
 */
export async function deleteAgent(agentId: number, userId: number): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.delete(agents).where(
    and(
      eq(agents.id, agentId),
      eq(agents.userId, userId)
    )
  );
}

/**
 * Get agent statistics
 */
export async function getAgentStatistics(agentId: number): Promise<{
  totalTasks: number;
  completedTasks: number;
  failedTasks: number;
  successRate: number;
  avgDuration: number;
}> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  // This would query the tasks table - placeholder for now
  return {
    totalTasks: 0,
    completedTasks: 0,
    failedTasks: 0,
    successRate: 0,
    avgDuration: 0,
  };
}
