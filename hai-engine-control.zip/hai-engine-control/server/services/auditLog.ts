/**
 * Audit Logging Service
 * Implements P1 #62: Implement audit logging for sensitive operations
 */

import { getDb } from '../db';
import { getCorrelationId } from './correlationId';

export type AuditAction = 
  | 'create' | 'read' | 'update' | 'delete'
  | 'login' | 'logout' | 'login_failed'
  | 'permission_granted' | 'permission_denied'
  | 'config_changed' | 'secret_accessed'
  | 'export' | 'import' | 'bulk_operation'
  | 'api_key_created' | 'api_key_revoked'
  | 'user_invited' | 'user_removed' | 'role_changed';

export type AuditSeverity = 'info' | 'warning' | 'critical';

export interface AuditEntry {
  id?: number;
  timestamp: Date;
  action: AuditAction;
  severity: AuditSeverity;
  userId?: number;
  targetType: string;
  targetId?: string | number;
  description: string;
  metadata?: Record<string, unknown>;
  ipAddress?: string;
  userAgent?: string;
  correlationId?: string;
  success: boolean;
  errorMessage?: string;
}

// In-memory audit log for when database is unavailable
const inMemoryLog: AuditEntry[] = [];
const MAX_IN_MEMORY = 10000;

/**
 * Log an audit entry
 */
export async function logAudit(entry: Omit<AuditEntry, 'id' | 'timestamp' | 'correlationId'>): Promise<void> {
  const fullEntry: AuditEntry = {
    ...entry,
    timestamp: new Date(),
    correlationId: getCorrelationId(),
  };
  
  // Always log to console for critical actions
  if (entry.severity === 'critical') {
    console.log(`[AUDIT:CRITICAL] ${entry.action} - ${entry.description}`, {
      userId: entry.userId,
      targetType: entry.targetType,
      targetId: entry.targetId,
      success: entry.success,
    });
  }
  
  // Store in memory as backup
  inMemoryLog.push(fullEntry);
  if (inMemoryLog.length > MAX_IN_MEMORY) {
    inMemoryLog.shift();
  }
  
  // Try to persist to database
  try {
    const db = await getDb();
    if (db) {
      // Would insert into audit_logs table
      // await db.insert(auditLogs).values(fullEntry);
    }
  } catch (error) {
    console.error('[AuditLog] Failed to persist audit entry:', error);
  }
}

/**
 * Helper functions for common audit scenarios
 */
export const audit = {
  // Authentication events
  loginSuccess: (userId: number, ipAddress?: string, userAgent?: string) =>
    logAudit({
      action: 'login',
      severity: 'info',
      userId,
      targetType: 'user',
      targetId: userId,
      description: 'User logged in successfully',
      ipAddress,
      userAgent,
      success: true,
    }),
  
  loginFailed: (email: string, reason: string, ipAddress?: string) =>
    logAudit({
      action: 'login_failed',
      severity: 'warning',
      targetType: 'user',
      description: `Login failed for ${email}: ${reason}`,
      metadata: { email, reason },
      ipAddress,
      success: false,
      errorMessage: reason,
    }),
  
  logout: (userId: number) =>
    logAudit({
      action: 'logout',
      severity: 'info',
      userId,
      targetType: 'user',
      targetId: userId,
      description: 'User logged out',
      success: true,
    }),
  
  // Data operations
  dataCreated: (userId: number, targetType: string, targetId: string | number, description?: string) =>
    logAudit({
      action: 'create',
      severity: 'info',
      userId,
      targetType,
      targetId,
      description: description || `Created ${targetType} ${targetId}`,
      success: true,
    }),
  
  dataUpdated: (userId: number, targetType: string, targetId: string | number, changes?: Record<string, unknown>) =>
    logAudit({
      action: 'update',
      severity: 'info',
      userId,
      targetType,
      targetId,
      description: `Updated ${targetType} ${targetId}`,
      metadata: changes ? { changes } : undefined,
      success: true,
    }),
  
  dataDeleted: (userId: number, targetType: string, targetId: string | number) =>
    logAudit({
      action: 'delete',
      severity: 'warning',
      userId,
      targetType,
      targetId,
      description: `Deleted ${targetType} ${targetId}`,
      success: true,
    }),
  
  // Permission events
  permissionGranted: (userId: number, targetUserId: number, permission: string) =>
    logAudit({
      action: 'permission_granted',
      severity: 'warning',
      userId,
      targetType: 'user',
      targetId: targetUserId,
      description: `Granted ${permission} permission to user ${targetUserId}`,
      metadata: { permission },
      success: true,
    }),
  
  permissionDenied: (userId: number, resource: string, action: string) =>
    logAudit({
      action: 'permission_denied',
      severity: 'warning',
      userId,
      targetType: 'resource',
      description: `Access denied to ${resource} for action ${action}`,
      metadata: { resource, action },
      success: false,
    }),
  
  // Configuration events
  configChanged: (userId: number, configKey: string, oldValue?: unknown, newValue?: unknown) =>
    logAudit({
      action: 'config_changed',
      severity: 'critical',
      userId,
      targetType: 'config',
      targetId: configKey,
      description: `Configuration changed: ${configKey}`,
      metadata: { oldValue: oldValue ? '[REDACTED]' : undefined, newValue: newValue ? '[REDACTED]' : undefined },
      success: true,
    }),
  
  secretAccessed: (userId: number, secretName: string) =>
    logAudit({
      action: 'secret_accessed',
      severity: 'critical',
      userId,
      targetType: 'secret',
      targetId: secretName,
      description: `Secret accessed: ${secretName}`,
      success: true,
    }),
  
  // API key events
  apiKeyCreated: (userId: number, keyName: string, keyId: string) =>
    logAudit({
      action: 'api_key_created',
      severity: 'critical',
      userId,
      targetType: 'api_key',
      targetId: keyId,
      description: `API key created: ${keyName}`,
      success: true,
    }),
  
  apiKeyRevoked: (userId: number, keyId: string) =>
    logAudit({
      action: 'api_key_revoked',
      severity: 'critical',
      userId,
      targetType: 'api_key',
      targetId: keyId,
      description: `API key revoked: ${keyId}`,
      success: true,
    }),
  
  // User management events
  roleChanged: (userId: number, targetUserId: number, oldRole: string, newRole: string) =>
    logAudit({
      action: 'role_changed',
      severity: 'critical',
      userId,
      targetType: 'user',
      targetId: targetUserId,
      description: `Role changed from ${oldRole} to ${newRole} for user ${targetUserId}`,
      metadata: { oldRole, newRole },
      success: true,
    }),
  
  // Bulk operations
  bulkOperation: (userId: number, operation: string, count: number, targetType: string) =>
    logAudit({
      action: 'bulk_operation',
      severity: 'warning',
      userId,
      targetType,
      description: `Bulk ${operation} of ${count} ${targetType} records`,
      metadata: { operation, count },
      success: true,
    }),
  
  // Export/Import
  dataExported: (userId: number, dataType: string, recordCount: number) =>
    logAudit({
      action: 'export',
      severity: 'warning',
      userId,
      targetType: dataType,
      description: `Exported ${recordCount} ${dataType} records`,
      metadata: { recordCount },
      success: true,
    }),
};

/**
 * Query audit logs
 */
export async function queryAuditLogs(options: {
  userId?: number;
  action?: AuditAction;
  targetType?: string;
  severity?: AuditSeverity;
  startDate?: Date;
  endDate?: Date;
  limit?: number;
  offset?: number;
}): Promise<AuditEntry[]> {
  // For now, query from in-memory log
  let results = [...inMemoryLog];
  
  if (options.userId) {
    results = results.filter(e => e.userId === options.userId);
  }
  if (options.action) {
    results = results.filter(e => e.action === options.action);
  }
  if (options.targetType) {
    results = results.filter(e => e.targetType === options.targetType);
  }
  if (options.severity) {
    results = results.filter(e => e.severity === options.severity);
  }
  if (options.startDate) {
    results = results.filter(e => e.timestamp >= options.startDate!);
  }
  if (options.endDate) {
    results = results.filter(e => e.timestamp <= options.endDate!);
  }
  
  // Sort by timestamp descending
  results.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  
  // Apply pagination
  const offset = options.offset ?? 0;
  const limit = options.limit ?? 100;
  
  return results.slice(offset, offset + limit);
}

/**
 * Get audit statistics
 */
export function getAuditStats(): {
  total: number;
  bySeverity: Record<AuditSeverity, number>;
  byAction: Record<string, number>;
  recentCritical: AuditEntry[];
} {
  const bySeverity: Record<AuditSeverity, number> = {
    info: 0,
    warning: 0,
    critical: 0,
  };
  
  const byAction: Record<string, number> = {};
  
  for (const entry of inMemoryLog) {
    bySeverity[entry.severity]++;
    byAction[entry.action] = (byAction[entry.action] || 0) + 1;
  }
  
  const recentCritical = inMemoryLog
    .filter(e => e.severity === 'critical')
    .slice(-10)
    .reverse();
  
  return {
    total: inMemoryLog.length,
    bySeverity,
    byAction,
    recentCritical,
  };
}

export default {
  logAudit,
  audit,
  queryAuditLogs,
  getAuditStats,
};
