import { BaseConnector, ConnectorConfig, ConnectorHealth, ConnectorStatus } from "./BaseConnector";
import { EventBus } from "../EventBus";

/**
 * Registered connector info
 */
interface RegisteredConnector {
  connector: BaseConnector;
  config: ConnectorConfig;
  health?: ConnectorHealth;
  lastHealthCheck?: Date;
}

/**
 * Connector Registry
 * Manages all registered connectors
 */
class ConnectorRegistryService {
  private connectors: Map<string, RegisteredConnector> = new Map();
  private healthCheckInterval?: NodeJS.Timeout;

  /**
   * Register a connector
   */
  register(connector: BaseConnector): void {
    const id = connector.getId();
    
    if (this.connectors.has(id)) {
      throw new Error(`Connector with ID "${id}" is already registered`);
    }

    this.connectors.set(id, {
      connector,
      config: connector['config'], // Access protected config
    });

    console.log(`[ConnectorRegistry] Registered connector: ${connector.getName()}`);
    
    EventBus.publish({
      type: 'connector.registered',
      source: 'ConnectorRegistry',
      target: '*',
      data: {
        connectorId: id,
        connectorName: connector.getName(),
      },
      metadata: {
        timestamp: new Date().toISOString(),
        severity: 'info' as const,
        description: `Registered connector: ${connector.getName()}`,
      } as any,
    });
  }

  /**
   * Unregister a connector
   */
  async unregister(connectorId: string): Promise<void> {
    const registered = this.connectors.get(connectorId);
    
    if (!registered) {
      throw new Error(`Connector with ID "${connectorId}" not found`);
    }

    // Disconnect if connected
    if (registered.connector.getStatus() === 'connected') {
      await registered.connector.disconnect();
    }

    this.connectors.delete(connectorId);
    console.log(`[ConnectorRegistry] Unregistered connector: ${registered.connector.getName()}`);
    
    EventBus.publish({
      type: 'connector.unregistered',
      source: 'ConnectorRegistry',
      target: '*',
      data: {
        connectorId,
        connectorName: registered.connector.getName(),
      },
      metadata: {
        timestamp: new Date().toISOString(),
        severity: 'info' as const,
        description: `Unregistered connector: ${registered.connector.getName()}`,
      } as any,
    });
  }

  /**
   * Get a connector by ID
   */
  get(connectorId: string): BaseConnector | undefined {
    return this.connectors.get(connectorId)?.connector;
  }

  /**
   * Get all registered connectors
   */
  getAll(): BaseConnector[] {
    return Array.from(this.connectors.values()).map(r => r.connector);
  }

  /**
   * Get connectors by status
   */
  getByStatus(status: ConnectorStatus): BaseConnector[] {
    return this.getAll().filter(c => c.getStatus() === status);
  }

  /**
   * Connect a connector
   */
  async connect(connectorId: string): Promise<void> {
    const registered = this.connectors.get(connectorId);
    
    if (!registered) {
      throw new Error(`Connector with ID "${connectorId}" not found`);
    }

    await registered.connector.connect();
  }

  /**
   * Disconnect a connector
   */
  async disconnect(connectorId: string): Promise<void> {
    const registered = this.connectors.get(connectorId);
    
    if (!registered) {
      throw new Error(`Connector with ID "${connectorId}" not found`);
    }

    await registered.connector.disconnect();
  }

  /**
   * Connect all connectors
   */
  async connectAll(): Promise<void> {
    const promises = this.getAll().map(c => c.connect().catch(err => {
      console.error(`[ConnectorRegistry] Failed to connect ${c.getName()}:`, err);
    }));
    
    await Promise.all(promises);
  }

  /**
   * Disconnect all connectors
   */
  async disconnectAll(): Promise<void> {
    const promises = this.getAll().map(c => c.disconnect().catch(err => {
      console.error(`[ConnectorRegistry] Failed to disconnect ${c.getName()}:`, err);
    }));
    
    await Promise.all(promises);
  }

  /**
   * Health check for a specific connector
   */
  async healthCheck(connectorId: string): Promise<ConnectorHealth> {
    const registered = this.connectors.get(connectorId);
    
    if (!registered) {
      throw new Error(`Connector with ID "${connectorId}" not found`);
    }

    const health = await registered.connector.healthCheck();
    registered.health = health;
    registered.lastHealthCheck = new Date();
    
    return health;
  }

  /**
   * Health check for all connectors
   */
  async healthCheckAll(): Promise<Map<string, ConnectorHealth>> {
    const results = new Map<string, ConnectorHealth>();
    
    for (const [id, registered] of Array.from(this.connectors.entries())) {
      try {
        const health = await registered.connector.healthCheck();
        registered.health = health;
        registered.lastHealthCheck = new Date();
        results.set(id, health);
      } catch (error) {
        console.error(`[ConnectorRegistry] Health check failed for ${registered.connector.getName()}:`, error);
        results.set(id, {
          status: 'error',
          lastCheck: new Date(),
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    }
    
    return results;
  }

  /**
   * Start periodic health checks
   */
  startHealthChecks(intervalMs: number = 60000): void {
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
    }

    this.healthCheckInterval = setInterval(() => {
      this.healthCheckAll().catch(err => {
        console.error('[ConnectorRegistry] Health check error:', err);
      });
    }, intervalMs);

    console.log(`[ConnectorRegistry] Started health checks (interval: ${intervalMs}ms)`);
  }

  /**
   * Stop periodic health checks
   */
  stopHealthChecks(): void {
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = undefined;
      console.log('[ConnectorRegistry] Stopped health checks');
    }
  }

  /**
   * Get connector statistics
   */
  getStats() {
    const all = this.getAll();
    const stats = {
      total: all.length,
      connected: 0,
      disconnected: 0,
      error: 0,
      rateLimited: 0,
      byType: {} as Record<string, number>,
    };

    for (const connector of all) {
      const status = connector.getStatus();
      
      switch (status) {
        case 'connected':
          stats.connected++;
          break;
        case 'disconnected':
          stats.disconnected++;
          break;
        case 'error':
          stats.error++;
          break;
        case 'rate_limited':
          stats.rateLimited++;
          break;
      }

      // Count by connector name (type)
      const name = connector.getName();
      stats.byType[name] = (stats.byType[name] || 0) + 1;
    }

    return stats;
  }

  /**
   * Get connector info
   */
  getConnectorInfo(connectorId: string) {
    const registered = this.connectors.get(connectorId);
    
    if (!registered) {
      return null;
    }

    return {
      id: connectorId,
      name: registered.connector.getName(),
      status: registered.connector.getStatus(),
      capabilities: registered.connector.getCapabilities(),
      config: registered.config,
      health: registered.health,
      lastHealthCheck: registered.lastHealthCheck,
    };
  }

  /**
   * Get all connector info
   */
  getAllConnectorInfo() {
    return Array.from(this.connectors.keys()).map(id => this.getConnectorInfo(id));
  }
}

export const ConnectorRegistry = new ConnectorRegistryService();
