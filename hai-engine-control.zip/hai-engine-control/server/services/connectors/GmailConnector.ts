import { google } from 'googleapis';
import { OAuth2Client } from 'google-auth-library';
import { getDb } from '../../db';
import { connectors } from '../../../drizzle/schema';
import { eq } from 'drizzle-orm';

/**
 * Gmail Connector - Real Google Gmail API Integration
 * 
 * Provides email sending, reading, and monitoring capabilities
 * using the official Google Gmail API.
 */

export interface GmailMessage {
  id: string;
  threadId: string;
  from: string;
  to: string[];
  subject: string;
  body: string;
  snippet: string;
  date: Date;
  isUnread: boolean;
  labels: string[];
  isUrgent?: boolean;
}

export interface SendEmailParams {
  to: string | string[];
  subject: string;
  body: string;
  cc?: string | string[];
  bcc?: string | string[];
  html?: boolean;
}

export class GmailConnector {
  private static oauth2Client: OAuth2Client | null = null;
  private static gmail: any = null;

  /**
   * Initialize Gmail connector with OAuth credentials
   */
  static async initialize(connectorId: number): Promise<void> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    // Get connector credentials from database
    const connector = await db
      .select()
      .from(connectors)
      .where(eq(connectors.id, connectorId))
      .limit(1);

    if (connector.length === 0) {
      throw new Error('Gmail connector not found');
    }

    const metadata = connector[0].metadata as any;
    const credentials = JSON.parse(connector[0].credentials || '{}');

    if (!credentials?.access_token) {
      throw new Error('Gmail connector not authenticated. Please connect via OAuth.');
    }

    // Create OAuth2 client
    this.oauth2Client = new google.auth.OAuth2(
      metadata.client_id,
      metadata.client_secret,
      metadata.redirect_uri
    );

    // Set credentials
    this.oauth2Client.setCredentials({
      access_token: credentials.access_token,
      refresh_token: credentials.refresh_token,
      expiry_date: credentials.expiry_date,
    });

    // Initialize Gmail API
    this.gmail = google.gmail({ version: 'v1', auth: this.oauth2Client });

    console.log('[GmailConnector] Initialized successfully');
  }

  /**
   * Get OAuth2 authorization URL
   */
  static getAuthUrl(clientId: string, clientSecret: string, redirectUri: string): string {
    const oauth2Client = new google.auth.OAuth2(clientId, clientSecret, redirectUri);

    const scopes = [
      'https://www.googleapis.com/auth/gmail.send',
      'https://www.googleapis.com/auth/gmail.readonly',
      'https://www.googleapis.com/auth/gmail.modify',
    ];

    return oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: scopes,
      prompt: 'consent', // Force consent to get refresh token
    });
  }

  /**
   * Exchange authorization code for tokens
   */
  static async getTokensFromCode(
    code: string,
    clientId: string,
    clientSecret: string,
    redirectUri: string
  ): Promise<any> {
    const oauth2Client = new google.auth.OAuth2(clientId, clientSecret, redirectUri);
    const { tokens } = await oauth2Client.getToken(code);
    return tokens;
  }

  /**
   * Refresh access token if expired
   */
  private static async refreshTokenIfNeeded(): Promise<void> {
    if (!this.oauth2Client) {
      throw new Error('Gmail connector not initialized');
    }

    const credentials = this.oauth2Client.credentials;
    if (credentials.expiry_date && credentials.expiry_date < Date.now()) {
      console.log('[GmailConnector] Access token expired, refreshing...');
      const { credentials: newCredentials } = await this.oauth2Client.refreshAccessToken();
      this.oauth2Client.setCredentials(newCredentials);

      // TODO: Update credentials in database
      console.log('[GmailConnector] Access token refreshed');
    }
  }

  /**
   * Send an email via Gmail API
   */
  static async sendEmail(params: SendEmailParams): Promise<{ id: string; threadId: string }> {
    await this.refreshTokenIfNeeded();

    if (!this.gmail) {
      throw new Error('Gmail connector not initialized');
    }

    const { to, subject, body, cc, bcc, html = false } = params;

    // Construct email message
    const toAddresses = Array.isArray(to) ? to.join(', ') : to;
    const ccAddresses = cc ? (Array.isArray(cc) ? cc.join(', ') : cc) : '';
    const bccAddresses = bcc ? (Array.isArray(bcc) ? bcc.join(', ') : bcc) : '';

    const messageParts = [
      `To: ${toAddresses}`,
      cc ? `Cc: ${ccAddresses}` : '',
      bcc ? `Bcc: ${bccAddresses}` : '',
      `Subject: ${subject}`,
      html ? 'Content-Type: text/html; charset=utf-8' : 'Content-Type: text/plain; charset=utf-8',
      '',
      body,
    ].filter(Boolean);

    const message = messageParts.join('\n');

    // Encode message in base64url
    const encodedMessage = Buffer.from(message)
      .toString('base64')
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');

    // Send email
    const response = await this.gmail.users.messages.send({
      userId: 'me',
      requestBody: {
        raw: encodedMessage,
      },
    });

    console.log('[GmailConnector] Email sent:', response.data.id);

    return {
      id: response.data.id,
      threadId: response.data.threadId,
    };
  }

  /**
   * Get unread emails
   */
  static async getUnreadEmails(maxResults: number = 10): Promise<GmailMessage[]> {
    await this.refreshTokenIfNeeded();

    if (!this.gmail) {
      throw new Error('Gmail connector not initialized');
    }

    // List unread messages
    const response = await this.gmail.users.messages.list({
      userId: 'me',
      q: 'is:unread',
      maxResults,
    });

    const messages = response.data.messages || [];
    const emails: GmailMessage[] = [];

    // Fetch full message details
    for (const message of messages) {
      const fullMessage = await this.gmail.users.messages.get({
        userId: 'me',
        id: message.id,
        format: 'full',
      });

      const email = this.parseGmailMessage(fullMessage.data);
      emails.push(email);
    }

    return emails;
  }

  /**
   * Get email by ID
   */
  static async getEmail(messageId: string): Promise<GmailMessage> {
    await this.refreshTokenIfNeeded();

    if (!this.gmail) {
      throw new Error('Gmail connector not initialized');
    }

    const response = await this.gmail.users.messages.get({
      userId: 'me',
      id: messageId,
      format: 'full',
    });

    return this.parseGmailMessage(response.data);
  }

  /**
   * Mark email as read
   */
  static async markAsRead(messageId: string): Promise<void> {
    await this.refreshTokenIfNeeded();

    if (!this.gmail) {
      throw new Error('Gmail connector not initialized');
    }

    await this.gmail.users.messages.modify({
      userId: 'me',
      id: messageId,
      requestBody: {
        removeLabelIds: ['UNREAD'],
      },
    });

    console.log('[GmailConnector] Marked email as read:', messageId);
  }

  /**
   * Parse Gmail API message to GmailMessage format
   */
  private static parseGmailMessage(data: any): GmailMessage {
    const headers = data.payload.headers;
    const getHeader = (name: string) => headers.find((h: any) => h.name === name)?.value || '';

    // Extract body
    let body = '';
    if (data.payload.body.data) {
      body = Buffer.from(data.payload.body.data, 'base64').toString('utf-8');
    } else if (data.payload.parts) {
      // Multi-part message
      const textPart = data.payload.parts.find((p: any) => p.mimeType === 'text/plain');
      if (textPart && textPart.body.data) {
        body = Buffer.from(textPart.body.data, 'base64').toString('utf-8');
      }
    }

    // Check if urgent (based on subject or priority headers)
    const subject = getHeader('Subject');
    const priority = getHeader('X-Priority');
    const importance = getHeader('Importance');
    const isUrgent =
      subject.toLowerCase().includes('urgent') ||
      subject.toLowerCase().includes('asap') ||
      priority === '1' ||
      importance === 'high';

    return {
      id: data.id,
      threadId: data.threadId,
      from: getHeader('From'),
      to: getHeader('To').split(',').map((e: string) => e.trim()),
      subject,
      body,
      snippet: data.snippet,
      date: new Date(parseInt(data.internalDate)),
      isUnread: data.labelIds?.includes('UNREAD') || false,
      labels: data.labelIds || [],
      isUrgent,
    };
  }

  /**
   * Search emails by query
   */
  static async searchEmails(query: string, maxResults: number = 10): Promise<GmailMessage[]> {
    await this.refreshTokenIfNeeded();

    if (!this.gmail) {
      throw new Error('Gmail connector not initialized');
    }

    const response = await this.gmail.users.messages.list({
      userId: 'me',
      q: query,
      maxResults,
    });

    const messages = response.data.messages || [];
    const emails: GmailMessage[] = [];

    for (const message of messages) {
      const fullMessage = await this.gmail.users.messages.get({
        userId: 'me',
        id: message.id,
        format: 'full',
      });

      const email = this.parseGmailMessage(fullMessage.data);
      emails.push(email);
    }

    return emails;
  }
}
