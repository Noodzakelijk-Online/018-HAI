import { google } from 'googleapis';
import { OAuth2Client } from 'google-auth-library';
import { getDb } from '../../db';
import { connectors } from '../../../drizzle/schema';
import { eq } from 'drizzle-orm';

/**
 * Google Calendar Connector - Real Google Calendar API Integration
 * 
 * Provides event creation, reading, updating, and conflict detection
 * using the official Google Calendar API.
 */

export interface CalendarEvent {
  id: string;
  summary: string;
  description?: string;
  location?: string;
  start: Date;
  end: Date;
  attendees?: string[];
  status: 'confirmed' | 'tentative' | 'cancelled';
  creator?: string;
  organizer?: string;
  htmlLink?: string;
}

export interface CreateEventParams {
  summary: string;
  description?: string;
  location?: string;
  start: Date;
  end: Date;
  attendees?: string[];
  sendNotifications?: boolean;
}

export interface FindFreeSlotParams {
  duration: number; // minutes
  startDate: Date;
  endDate: Date;
  workingHours?: { start: number; end: number }; // 9-17 for 9am-5pm
}

export class GoogleCalendarConnector {
  private static oauth2Client: OAuth2Client | null = null;
  private static calendar: any = null;

  /**
   * Initialize Calendar connector with OAuth credentials
   */
  static async initialize(connectorId: number): Promise<void> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const connector = await db
      .select()
      .from(connectors)
      .where(eq(connectors.id, connectorId))
      .limit(1);

    if (connector.length === 0) {
      throw new Error('Calendar connector not found');
    }

    const metadata = connector[0].metadata as any;
    const credentials = JSON.parse(connector[0].credentials || '{}');

    if (!credentials?.access_token) {
      throw new Error('Calendar connector not authenticated. Please connect via OAuth.');
    }

    this.oauth2Client = new google.auth.OAuth2(
      metadata.client_id,
      metadata.client_secret,
      metadata.redirect_uri
    );

    this.oauth2Client.setCredentials({
      access_token: credentials.access_token,
      refresh_token: credentials.refresh_token,
      expiry_date: credentials.expiry_date,
    });

    this.calendar = google.calendar({ version: 'v3', auth: this.oauth2Client });

    console.log('[GoogleCalendarConnector] Initialized successfully');
  }

  /**
   * Get OAuth2 authorization URL
   */
  static getAuthUrl(clientId: string, clientSecret: string, redirectUri: string): string {
    const oauth2Client = new google.auth.OAuth2(clientId, clientSecret, redirectUri);

    const scopes = [
      'https://www.googleapis.com/auth/calendar',
      'https://www.googleapis.com/auth/calendar.events',
    ];

    return oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: scopes,
      prompt: 'consent',
    });
  }

  /**
   * Exchange authorization code for tokens
   */
  static async getTokensFromCode(
    code: string,
    clientId: string,
    clientSecret: string,
    redirectUri: string
  ): Promise<any> {
    const oauth2Client = new google.auth.OAuth2(clientId, clientSecret, redirectUri);
    const { tokens } = await oauth2Client.getToken(code);
    return tokens;
  }

  /**
   * Refresh access token if expired
   */
  private static async refreshTokenIfNeeded(): Promise<void> {
    if (!this.oauth2Client) {
      throw new Error('Calendar connector not initialized');
    }

    const credentials = this.oauth2Client.credentials;
    if (credentials.expiry_date && credentials.expiry_date < Date.now()) {
      console.log('[GoogleCalendarConnector] Access token expired, refreshing...');
      const { credentials: newCredentials } = await this.oauth2Client.refreshAccessToken();
      this.oauth2Client.setCredentials(newCredentials);
      console.log('[GoogleCalendarConnector] Access token refreshed');
    }
  }

  /**
   * Create a calendar event
   */
  static async createEvent(params: CreateEventParams): Promise<CalendarEvent> {
    await this.refreshTokenIfNeeded();

    if (!this.calendar) {
      throw new Error('Calendar connector not initialized');
    }

    const { summary, description, location, start, end, attendees, sendNotifications = false } = params;

    const event = {
      summary,
      description,
      location,
      start: {
        dateTime: start.toISOString(),
        timeZone: 'UTC',
      },
      end: {
        dateTime: end.toISOString(),
        timeZone: 'UTC',
      },
      attendees: attendees?.map(email => ({ email })),
    };

    const response = await this.calendar.events.insert({
      calendarId: 'primary',
      requestBody: event,
      sendUpdates: sendNotifications ? 'all' : 'none',
    });

    console.log('[GoogleCalendarConnector] Event created:', response.data.id);

    return this.parseCalendarEvent(response.data);
  }

  /**
   * Get upcoming events
   */
  static async getUpcomingEvents(
    maxResults: number = 10,
    timeMin?: Date,
    timeMax?: Date
  ): Promise<CalendarEvent[]> {
    await this.refreshTokenIfNeeded();

    if (!this.calendar) {
      throw new Error('Calendar connector not initialized');
    }

    const response = await this.calendar.events.list({
      calendarId: 'primary',
      timeMin: (timeMin || new Date()).toISOString(),
      timeMax: timeMax?.toISOString(),
      maxResults,
      singleEvents: true,
      orderBy: 'startTime',
    });

    const events = response.data.items || [];
    return events.map((event: any) => this.parseCalendarEvent(event));
  }

  /**
   * Get event by ID
   */
  static async getEvent(eventId: string): Promise<CalendarEvent> {
    await this.refreshTokenIfNeeded();

    if (!this.calendar) {
      throw new Error('Calendar connector not initialized');
    }

    const response = await this.calendar.events.get({
      calendarId: 'primary',
      eventId,
    });

    return this.parseCalendarEvent(response.data);
  }

  /**
   * Update an event
   */
  static async updateEvent(eventId: string, updates: Partial<CreateEventParams>): Promise<CalendarEvent> {
    await this.refreshTokenIfNeeded();

    if (!this.calendar) {
      throw new Error('Calendar connector not initialized');
    }

    const event: any = {};
    if (updates.summary) event.summary = updates.summary;
    if (updates.description) event.description = updates.description;
    if (updates.location) event.location = updates.location;
    if (updates.start) {
      event.start = {
        dateTime: updates.start.toISOString(),
        timeZone: 'UTC',
      };
    }
    if (updates.end) {
      event.end = {
        dateTime: updates.end.toISOString(),
        timeZone: 'UTC',
      };
    }
    if (updates.attendees) {
      event.attendees = updates.attendees.map(email => ({ email }));
    }

    const response = await this.calendar.events.patch({
      calendarId: 'primary',
      eventId,
      requestBody: event,
      sendUpdates: updates.sendNotifications ? 'all' : 'none',
    });

    console.log('[GoogleCalendarConnector] Event updated:', eventId);

    return this.parseCalendarEvent(response.data);
  }

  /**
   * Delete an event
   */
  static async deleteEvent(eventId: string, sendNotifications: boolean = false): Promise<void> {
    await this.refreshTokenIfNeeded();

    if (!this.calendar) {
      throw new Error('Calendar connector not initialized');
    }

    await this.calendar.events.delete({
      calendarId: 'primary',
      eventId,
      sendUpdates: sendNotifications ? 'all' : 'none',
    });

    console.log('[GoogleCalendarConnector] Event deleted:', eventId);
  }

  /**
   * Detect scheduling conflicts
   */
  static async detectConflicts(start: Date, end: Date): Promise<CalendarEvent[]> {
    const events = await this.getUpcomingEvents(100, start, end);

    // Find events that overlap with the proposed time
    const conflicts = events.filter(event => {
      const eventStart = event.start.getTime();
      const eventEnd = event.end.getTime();
      const proposedStart = start.getTime();
      const proposedEnd = end.getTime();

      // Check for overlap
      return (
        (proposedStart >= eventStart && proposedStart < eventEnd) ||
        (proposedEnd > eventStart && proposedEnd <= eventEnd) ||
        (proposedStart <= eventStart && proposedEnd >= eventEnd)
      );
    });

    return conflicts;
  }

  /**
   * Find free time slots
   */
  static async findFreeSlots(params: FindFreeSlotParams): Promise<Array<{ start: Date; end: Date }>> {
    const { duration, startDate, endDate, workingHours = { start: 9, end: 17 } } = params;

    // Get all events in the date range
    const events = await this.getUpcomingEvents(1000, startDate, endDate);

    const freeSlots: Array<{ start: Date; end: Date }> = [];
    const durationMs = duration * 60 * 1000;

    // Iterate through each day
    let currentDate = new Date(startDate);
    while (currentDate < endDate) {
      // Set to start of working hours
      const dayStart = new Date(currentDate);
      dayStart.setHours(workingHours.start, 0, 0, 0);

      const dayEnd = new Date(currentDate);
      dayEnd.setHours(workingHours.end, 0, 0, 0);

      // Find free slots in this day
      let slotStart = dayStart;

      while (slotStart.getTime() + durationMs <= dayEnd.getTime()) {
        const slotEnd = new Date(slotStart.getTime() + durationMs);

        // Check if this slot conflicts with any event
        const hasConflict = events.some(event => {
          const eventStart = event.start.getTime();
          const eventEnd = event.end.getTime();
          const proposedStart = slotStart.getTime();
          const proposedEnd = slotEnd.getTime();

          return (
            (proposedStart >= eventStart && proposedStart < eventEnd) ||
            (proposedEnd > eventStart && proposedEnd <= eventEnd) ||
            (proposedStart <= eventStart && proposedEnd >= eventEnd)
          );
        });

        if (!hasConflict) {
          freeSlots.push({ start: new Date(slotStart), end: new Date(slotEnd) });
        }

        // Move to next 30-minute slot
        slotStart = new Date(slotStart.getTime() + 30 * 60 * 1000);
      }

      // Move to next day
      currentDate.setDate(currentDate.getDate() + 1);
    }

    return freeSlots;
  }

  /**
   * Parse Google Calendar event to CalendarEvent format
   */
  private static parseCalendarEvent(data: any): CalendarEvent {
    return {
      id: data.id,
      summary: data.summary || 'Untitled Event',
      description: data.description,
      location: data.location,
      start: new Date(data.start.dateTime || data.start.date),
      end: new Date(data.end.dateTime || data.end.date),
      attendees: data.attendees?.map((a: any) => a.email) || [],
      status: data.status,
      creator: data.creator?.email,
      organizer: data.organizer?.email,
      htmlLink: data.htmlLink,
    };
  }
}
