import { EventBus } from "../EventBus";

/**
 * Connector status
 */
export type ConnectorStatus = 'disconnected' | 'connecting' | 'connected' | 'error' | 'rate_limited';

/**
 * Authentication type
 */
export type AuthType = 'oauth2' | 'api_key' | 'bearer_token' | 'basic_auth' | 'none';

/**
 * Connector configuration
 */
export interface ConnectorConfig {
  /** Unique connector ID */
  id: string;
  /** Connector name */
  name: string;
  /** Connector description */
  description: string;
  /** Authentication type */
  authType: AuthType;
  /** Authentication credentials */
  credentials?: Record<string, string>;
  /** Rate limit (requests per minute) */
  rateLimit?: number;
  /** Retry configuration */
  retry?: {
    maxAttempts: number;
    backoffMs: number;
  };
  /** Custom configuration */
  config?: Record<string, unknown>;
}

/**
 * Connector capability
 */
export interface ConnectorCapability {
  /** Capability name */
  name: string;
  /** Capability description */
  description: string;
  /** Required parameters */
  parameters?: Array<{
    name: string;
    type: string;
    required: boolean;
    description: string;
  }>;
}

/**
 * Connector health status
 */
export interface ConnectorHealth {
  status: ConnectorStatus;
  lastCheck: Date;
  latencyMs?: number;
  error?: string;
  metrics?: {
    requestCount: number;
    errorCount: number;
    rateLimitHits: number;
  };
}

/**
 * Rate limiter
 */
class RateLimiter {
  private requests: number[] = [];
  private limit: number;
  private windowMs: number = 60000; // 1 minute

  constructor(requestsPerMinute: number) {
    this.limit = requestsPerMinute;
  }

  /**
   * Check if request is allowed
   */
  async checkLimit(): Promise<boolean> {
    const now = Date.now();
    // Remove old requests outside the window
    this.requests = this.requests.filter(time => now - time < this.windowMs);
    
    if (this.requests.length >= this.limit) {
      return false;
    }
    
    this.requests.push(now);
    return true;
  }

  /**
   * Get time until next available slot
   */
  getWaitTimeMs(): number {
    if (this.requests.length < this.limit) {
      return 0;
    }
    const oldestRequest = this.requests[0];
    const waitTime = this.windowMs - (Date.now() - oldestRequest);
    return Math.max(0, waitTime);
  }

  /**
   * Reset rate limiter
   */
  reset(): void {
    this.requests = [];
  }
}

/**
 * Base connector class
 * All connectors should extend this class
 */
export abstract class BaseConnector {
  protected config: ConnectorConfig;
  protected status: ConnectorStatus = 'disconnected';
  protected rateLimiter?: RateLimiter;
  protected metrics = {
    requestCount: 0,
    errorCount: 0,
    rateLimitHits: 0,
  };

  constructor(config: ConnectorConfig) {
    this.config = config;
    
    // Initialize rate limiter if configured
    if (config.rateLimit) {
      this.rateLimiter = new RateLimiter(config.rateLimit);
    }
  }

  /**
   * Get connector ID
   */
  getId(): string {
    return this.config.id;
  }

  /**
   * Get connector name
   */
  getName(): string {
    return this.config.name;
  }

  /**
   * Get connector status
   */
  getStatus(): ConnectorStatus {
    return this.status;
  }

  /**
   * Get connector capabilities
   */
  abstract getCapabilities(): ConnectorCapability[];

  /**
   * Connect to the service
   */
  async connect(): Promise<void> {
    this.status = 'connecting';
    
    try {
      await this.publishEvent('connector.connecting', {
        connectorId: this.config.id,
        connectorName: this.config.name,
      });

      await this.doConnect();
      
      this.status = 'connected';
      await this.publishEvent('connector.connected', {
        connectorId: this.config.id,
        connectorName: this.config.name,
      });
    } catch (error) {
      this.status = 'error';
      await this.publishEvent('connector.error', {
        connectorId: this.config.id,
        connectorName: this.config.name,
        error: error instanceof Error ? error.message : 'Unknown error',
      });
      throw error;
    }
  }

  /**
   * Disconnect from the service
   */
  async disconnect(): Promise<void> {
    try {
      await this.doDisconnect();
      this.status = 'disconnected';
      
      await this.publishEvent('connector.disconnected', {
        connectorId: this.config.id,
        connectorName: this.config.name,
      });
    } catch (error) {
      console.error(`[${this.config.name}] Error disconnecting:`, error);
      throw error;
    }
  }

  /**
   * Check connector health
   */
  async healthCheck(): Promise<ConnectorHealth> {
    const startTime = Date.now();
    
    try {
      await this.doHealthCheck();
      const latencyMs = Date.now() - startTime;
      
      return {
        status: this.status,
        lastCheck: new Date(),
        latencyMs,
        metrics: { ...this.metrics },
      };
    } catch (error) {
      return {
        status: 'error',
        lastCheck: new Date(),
        error: error instanceof Error ? error.message : 'Unknown error',
        metrics: { ...this.metrics },
      };
    }
  }

  /**
   * Execute a request with rate limiting and retry logic
   */
  protected async executeRequest<T>(
    operation: () => Promise<T>,
    operationName: string
  ): Promise<T> {
    // Check rate limit
    if (this.rateLimiter) {
      const allowed = await this.rateLimiter.checkLimit();
      if (!allowed) {
        this.metrics.rateLimitHits++;
        this.status = 'rate_limited';
        
        const waitTimeMs = this.rateLimiter.getWaitTimeMs();
        throw new Error(`Rate limit exceeded. Wait ${Math.ceil(waitTimeMs / 1000)}s`);
      }
    }

    // Execute with retry logic
    const maxAttempts = this.config.retry?.maxAttempts || 3;
    const backoffMs = this.config.retry?.backoffMs || 1000;
    
    let lastError: Error | undefined;
    
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        this.metrics.requestCount++;
        const result = await operation();
        
        // Reset status if it was rate_limited
        if (this.status === 'rate_limited') {
          this.status = 'connected';
        }
        
        return result;
      } catch (error) {
        lastError = error instanceof Error ? error : new Error('Unknown error');
        this.metrics.errorCount++;
        
        // Don't retry on authentication errors
        if (lastError.message.includes('auth') || lastError.message.includes('unauthorized')) {
          break;
        }
        
        // Wait before retry (exponential backoff)
        if (attempt < maxAttempts) {
          await new Promise(resolve => setTimeout(resolve, backoffMs * attempt));
        }
      }
    }

    // All attempts failed
    await this.publishEvent('connector.request_failed', {
      connectorId: this.config.id,
      operation: operationName,
      error: lastError?.message,
      attempts: maxAttempts,
    });

    throw lastError || new Error('Operation failed');
  }

  /**
   * Publish event to EventBus
   */
  protected async publishEvent(type: string, data: Record<string, unknown>): Promise<void> {
    try {
      await EventBus.publish({
        type,
        source: `Connector:${this.config.name}`,
        target: '*',
        data,
        metadata: {
          timestamp: new Date().toISOString(),
          severity: type.includes('error') ? ('error' as const) : ('info' as const),
          description: `Connector ${this.config.name}: ${type}`,
        } as any,
      });
    } catch (error) {
      console.error(`[${this.config.name}] Error publishing event:`, error);
    }
  }

  /**
   * Abstract methods to be implemented by concrete connectors
   */
  protected abstract doConnect(): Promise<void>;
  protected abstract doDisconnect(): Promise<void>;
  protected abstract doHealthCheck(): Promise<void>;
}
