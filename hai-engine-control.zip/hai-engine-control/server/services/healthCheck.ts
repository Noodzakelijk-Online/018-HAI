/**
 * Health Check Service
 * Implements P1 #48: Health check endpoints for all services
 * Implements P1 #85: Database health checks
 */

import { getDb } from '../db';
import { sql } from 'drizzle-orm';
import EventBus from './EventBus';

export type HealthStatus = 'healthy' | 'degraded' | 'unhealthy';

export interface ComponentHealth {
  name: string;
  status: HealthStatus;
  latency?: number;
  message?: string;
  lastChecked: Date;
  details?: Record<string, unknown>;
}

export interface SystemHealth {
  status: HealthStatus;
  timestamp: Date;
  uptime: number;
  version: string;
  components: ComponentHealth[];
  metrics: {
    memoryUsage: NodeJS.MemoryUsage;
    cpuUsage: NodeJS.CpuUsage;
    activeConnections: number;
  };
}

const startTime = Date.now();

// ============================================================================
// Individual Health Checks
// ============================================================================

/**
 * Check database health
 */
async function checkDatabase(): Promise<ComponentHealth> {
  const start = Date.now();
  
  try {
    const db = await getDb();
    if (!db) {
      return {
        name: 'database',
        status: 'unhealthy',
        message: 'Database not available',
        lastChecked: new Date(),
      };
    }
    
    // Execute simple query to check connection
    await db.execute(sql`SELECT 1`);
    
    const latency = Date.now() - start;
    
    return {
      name: 'database',
      status: latency < 100 ? 'healthy' : latency < 500 ? 'degraded' : 'unhealthy',
      latency,
      lastChecked: new Date(),
      details: {
        connectionPool: 'active',
      },
    };
  } catch (error) {
    return {
      name: 'database',
      status: 'unhealthy',
      latency: Date.now() - start,
      message: error instanceof Error ? error.message : 'Unknown error',
      lastChecked: new Date(),
    };
  }
}

/**
 * Check EventBus health
 */
async function checkEventBus(): Promise<ComponentHealth> {
  const start = Date.now();
  
  try {
    const isConnected = EventBus.isConnected();
    const latency = Date.now() - start;
    
    return {
      name: 'eventBus',
      status: isConnected ? 'healthy' : 'degraded',
      latency,
      message: isConnected ? 'Connected' : 'Running in memory mode (Redis unavailable)',
      lastChecked: new Date(),
    };
  } catch (error) {
    return {
      name: 'eventBus',
      status: 'unhealthy',
      latency: Date.now() - start,
      message: error instanceof Error ? error.message : 'Unknown error',
      lastChecked: new Date(),
    };
  }
}

/**
 * Check memory health
 */
function checkMemory(): ComponentHealth {
  const memUsage = process.memoryUsage();
  const heapUsedPercent = (memUsage.heapUsed / memUsage.heapTotal) * 100;
  
  let status: HealthStatus = 'healthy';
  if (heapUsedPercent > 90) {
    status = 'unhealthy';
  } else if (heapUsedPercent > 75) {
    status = 'degraded';
  }
  
  return {
    name: 'memory',
    status,
    lastChecked: new Date(),
    details: {
      heapUsed: Math.round(memUsage.heapUsed / 1024 / 1024),
      heapTotal: Math.round(memUsage.heapTotal / 1024 / 1024),
      heapUsedPercent: Math.round(heapUsedPercent),
      rss: Math.round(memUsage.rss / 1024 / 1024),
      external: Math.round(memUsage.external / 1024 / 1024),
    },
  };
}

/**
 * Check external services health
 */
async function checkExternalServices(): Promise<ComponentHealth> {
  const start = Date.now();
  const services: Record<string, boolean> = {};
  
  // Check LLM API
  try {
    const llmUrl = process.env.BUILT_IN_FORGE_API_URL;
    if (llmUrl) {
      const response = await fetch(`${llmUrl}/health`, { 
        method: 'GET',
        signal: AbortSignal.timeout(5000),
      }).catch(() => null);
      services['llm'] = response?.ok ?? false;
    }
  } catch {
    services['llm'] = false;
  }
  
  const latency = Date.now() - start;
  const healthyCount = Object.values(services).filter(Boolean).length;
  const totalCount = Object.keys(services).length;
  
  let status: HealthStatus = 'healthy';
  if (healthyCount === 0 && totalCount > 0) {
    status = 'unhealthy';
  } else if (healthyCount < totalCount) {
    status = 'degraded';
  }
  
  return {
    name: 'externalServices',
    status,
    latency,
    lastChecked: new Date(),
    details: services,
  };
}

/**
 * Check file storage health
 */
async function checkStorage(): Promise<ComponentHealth> {
  const start = Date.now();
  
  try {
    // Check if S3 credentials are configured
    const hasS3Config = !!(process.env.BUILT_IN_FORGE_API_URL && process.env.BUILT_IN_FORGE_API_KEY);
    
    return {
      name: 'storage',
      status: hasS3Config ? 'healthy' : 'degraded',
      latency: Date.now() - start,
      message: hasS3Config ? 'S3 configured' : 'S3 not configured',
      lastChecked: new Date(),
    };
  } catch (error) {
    return {
      name: 'storage',
      status: 'unhealthy',
      latency: Date.now() - start,
      message: error instanceof Error ? error.message : 'Unknown error',
      lastChecked: new Date(),
    };
  }
}

// ============================================================================
// Main Health Check Functions
// ============================================================================

/**
 * Perform full system health check
 */
export async function getSystemHealth(): Promise<SystemHealth> {
  const components = await Promise.all([
    checkDatabase(),
    checkEventBus(),
    Promise.resolve(checkMemory()),
    checkExternalServices(),
    checkStorage(),
  ]);
  
  // Determine overall status
  const hasUnhealthy = components.some(c => c.status === 'unhealthy');
  const hasDegraded = components.some(c => c.status === 'degraded');
  
  let overallStatus: HealthStatus = 'healthy';
  if (hasUnhealthy) {
    overallStatus = 'unhealthy';
  } else if (hasDegraded) {
    overallStatus = 'degraded';
  }
  
  return {
    status: overallStatus,
    timestamp: new Date(),
    uptime: Date.now() - startTime,
    version: process.env.npm_package_version || '1.0.0',
    components,
    metrics: {
      memoryUsage: process.memoryUsage(),
      cpuUsage: process.cpuUsage(),
      activeConnections: 0, // Would need to track this
    },
  };
}

/**
 * Quick liveness check (is the service running?)
 */
export function getLivenessCheck(): { status: 'ok'; timestamp: Date } {
  return {
    status: 'ok',
    timestamp: new Date(),
  };
}

/**
 * Readiness check (is the service ready to accept traffic?)
 */
export async function getReadinessCheck(): Promise<{
  ready: boolean;
  timestamp: Date;
  checks: Record<string, boolean>;
}> {
  const dbHealth = await checkDatabase();
  
  const checks = {
    database: dbHealth.status !== 'unhealthy',
  };
  
  return {
    ready: Object.values(checks).every(Boolean),
    timestamp: new Date(),
    checks,
  };
}

/**
 * Get specific component health
 */
export async function getComponentHealth(component: string): Promise<ComponentHealth | null> {
  switch (component) {
    case 'database':
      return checkDatabase();
    case 'eventBus':
      return checkEventBus();
    case 'memory':
      return checkMemory();
    case 'externalServices':
      return checkExternalServices();
    case 'storage':
      return checkStorage();
    default:
      return null;
  }
}

/**
 * Start periodic health monitoring
 */
let healthMonitorInterval: NodeJS.Timeout | null = null;
const healthHistory: SystemHealth[] = [];
const MAX_HISTORY = 100;

export function startHealthMonitoring(intervalMs: number = 60000): void {
  if (healthMonitorInterval) {
    clearInterval(healthMonitorInterval);
  }
  
  healthMonitorInterval = setInterval(async () => {
    const health = await getSystemHealth();
    healthHistory.push(health);
    
    if (healthHistory.length > MAX_HISTORY) {
      healthHistory.shift();
    }
    
    // Log if unhealthy
    if (health.status === 'unhealthy') {
      console.error('[HealthCheck] System unhealthy:', health.components.filter(c => c.status === 'unhealthy'));
    }
  }, intervalMs);
  
  console.log(`[HealthCheck] Health monitoring started (interval: ${intervalMs / 1000}s)`);
}

export function stopHealthMonitoring(): void {
  if (healthMonitorInterval) {
    clearInterval(healthMonitorInterval);
    healthMonitorInterval = null;
    console.log('[HealthCheck] Health monitoring stopped');
  }
}

export function getHealthHistory(): SystemHealth[] {
  return [...healthHistory];
}

export default {
  getSystemHealth,
  getLivenessCheck,
  getReadinessCheck,
  getComponentHealth,
  startHealthMonitoring,
  stopHealthMonitoring,
  getHealthHistory,
};
