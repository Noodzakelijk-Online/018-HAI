/**
 * Idempotency Service
 * Implements P2 #52: Implement idempotency for mutations
 */

export interface IdempotencyRecord {
  key: string;
  response: any;
  statusCode: number;
  createdAt: Date;
  expiresAt: Date;
}

export interface IdempotencyOptions {
  ttlMs: number;
  headerName: string;
  keyPrefix: string;
}

const DEFAULT_OPTIONS: IdempotencyOptions = {
  ttlMs: 24 * 60 * 60 * 1000, // 24 hours
  headerName: 'idempotency-key',
  keyPrefix: 'idem:',
};

// In-memory store (would use Redis in production)
const idempotencyStore: Map<string, IdempotencyRecord> = new Map();

/**
 * Generate idempotency key from request
 */
export function generateIdempotencyKey(
  userId: number | string,
  operation: string,
  params?: Record<string, unknown>
): string {
  const paramsHash = params ? hashObject(params) : '';
  return `${userId}:${operation}:${paramsHash}`;
}

/**
 * Simple object hash for key generation
 */
function hashObject(obj: Record<string, unknown>): string {
  const str = JSON.stringify(obj, Object.keys(obj).sort());
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(36);
}

/**
 * Check if request is idempotent (already processed)
 */
export function checkIdempotency(key: string): IdempotencyRecord | null {
  const fullKey = DEFAULT_OPTIONS.keyPrefix + key;
  const record = idempotencyStore.get(fullKey);
  
  if (!record) return null;
  
  // Check if expired
  if (record.expiresAt < new Date()) {
    idempotencyStore.delete(fullKey);
    return null;
  }
  
  return record;
}

/**
 * Store idempotency record
 */
export function storeIdempotency(
  key: string,
  response: any,
  statusCode: number = 200,
  options: Partial<IdempotencyOptions> = {}
): void {
  const opts = { ...DEFAULT_OPTIONS, ...options };
  const fullKey = opts.keyPrefix + key;
  const now = new Date();
  
  idempotencyStore.set(fullKey, {
    key: fullKey,
    response,
    statusCode,
    createdAt: now,
    expiresAt: new Date(now.getTime() + opts.ttlMs),
  });
}

/**
 * Delete idempotency record
 */
export function deleteIdempotency(key: string): boolean {
  return idempotencyStore.delete(DEFAULT_OPTIONS.keyPrefix + key);
}

/**
 * Clear expired records
 */
export function cleanupExpiredRecords(): number {
  const now = new Date();
  let deleted = 0;
  
  for (const [key, record] of idempotencyStore.entries()) {
    if (record.expiresAt < now) {
      idempotencyStore.delete(key);
      deleted++;
    }
  }
  
  return deleted;
}

/**
 * Idempotent operation wrapper
 */
export async function withIdempotency<T>(
  key: string,
  operation: () => Promise<T>,
  options: Partial<IdempotencyOptions> = {}
): Promise<{ result: T; cached: boolean }> {
  // Check for existing record
  const existing = checkIdempotency(key);
  if (existing) {
    return { result: existing.response as T, cached: true };
  }
  
  // Execute operation
  const result = await operation();
  
  // Store result
  storeIdempotency(key, result, 200, options);
  
  return { result, cached: false };
}

/**
 * Express middleware for idempotency
 */
export function idempotencyMiddleware(options: Partial<IdempotencyOptions> = {}) {
  const opts = { ...DEFAULT_OPTIONS, ...options };
  
  return async (req: any, res: any, next: any) => {
    // Only apply to mutations
    if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
      return next();
    }
    
    // Get idempotency key from header
    const idempotencyKey = req.headers[opts.headerName];
    if (!idempotencyKey) {
      return next();
    }
    
    // Check for existing record
    const existing = checkIdempotency(idempotencyKey);
    if (existing) {
      res.setHeader('X-Idempotent-Replayed', 'true');
      return res.status(existing.statusCode).json(existing.response);
    }
    
    // Store original json method
    const originalJson = res.json.bind(res);
    
    // Override json to capture response
    res.json = function(body: any) {
      storeIdempotency(idempotencyKey, body, res.statusCode, opts);
      return originalJson(body);
    };
    
    next();
  };
}

/**
 * tRPC middleware for idempotency
 */
export function idempotentProcedure(keyGenerator: (input: any, ctx: any) => string) {
  return async ({ ctx, input, next }: { ctx: any; input: any; next: () => Promise<any> }) => {
    const key = keyGenerator(input, ctx);
    
    // Check for existing record
    const existing = checkIdempotency(key);
    if (existing) {
      return existing.response;
    }
    
    // Execute procedure
    const result = await next();
    
    // Store result
    storeIdempotency(key, result);
    
    return result;
  };
}

/**
 * Decorator for idempotent methods
 */
export function Idempotent(keyGenerator?: (args: any[]) => string) {
  return function (
    target: any,
    propertyKey: string,
    descriptor: PropertyDescriptor
  ) {
    const originalMethod = descriptor.value;
    
    descriptor.value = async function (...args: any[]) {
      const key = keyGenerator 
        ? keyGenerator(args)
        : `${target.constructor.name}.${propertyKey}:${JSON.stringify(args)}`;
      
      const { result } = await withIdempotency(key, () => originalMethod.apply(this, args));
      return result;
    };
    
    return descriptor;
  };
}

/**
 * Get store statistics
 */
export function getIdempotencyStats(): {
  size: number;
  oldestRecord: Date | null;
  newestRecord: Date | null;
} {
  let oldest: Date | null = null;
  let newest: Date | null = null;
  
  for (const record of idempotencyStore.values()) {
    if (!oldest || record.createdAt < oldest) {
      oldest = record.createdAt;
    }
    if (!newest || record.createdAt > newest) {
      newest = record.createdAt;
    }
  }
  
  return {
    size: idempotencyStore.size,
    oldestRecord: oldest,
    newestRecord: newest,
  };
}

// Start cleanup interval
let cleanupInterval: NodeJS.Timeout | null = null;

export function startCleanup(intervalMs: number = 60000): void {
  if (cleanupInterval) {
    clearInterval(cleanupInterval);
  }
  
  cleanupInterval = setInterval(() => {
    const deleted = cleanupExpiredRecords();
    if (deleted > 0) {
      console.log(`[Idempotency] Cleaned up ${deleted} expired records`);
    }
  }, intervalMs);
}

export function stopCleanup(): void {
  if (cleanupInterval) {
    clearInterval(cleanupInterval);
    cleanupInterval = null;
  }
}

export default {
  generateIdempotencyKey,
  checkIdempotency,
  storeIdempotency,
  deleteIdempotency,
  cleanupExpiredRecords,
  withIdempotency,
  idempotencyMiddleware,
  idempotentProcedure,
  Idempotent,
  getIdempotencyStats,
  startCleanup,
  stopCleanup,
};
