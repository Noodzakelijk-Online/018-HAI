import { getDb } from "../db";
import { connectorAnalytics, type InsertConnectorAnalytics } from "../../drizzle/schema";
import { eq, and, gte, sql, desc } from "drizzle-orm";

/**
 * Track connector usage analytics
 */
export async function trackConnectorUsage(data: {
  connectorId: number;
  action: string;
  status: "success" | "failed";
  duration?: number;
  errorMessage?: string;
  requestData?: any;
  responseData?: any;
  metadata?: any;
}): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Analytics] Cannot track usage: database not available");
    return;
  }

  try {
    await db.insert(connectorAnalytics).values({
      connectorId: data.connectorId,
      action: data.action,
      status: data.status,
      duration: data.duration,
      errorMessage: data.errorMessage,
      requestData: data.requestData,
      responseData: data.responseData,
      metadata: data.metadata,
    });
  } catch (error) {
    console.error("[Analytics] Failed to track usage:", error);
    // Don't throw - analytics failure shouldn't break the main operation
  }
}

/**
 * Get analytics statistics for a connector
 */
export async function getConnectorAnalytics(connectorId: number, days: number = 30) {
  const db = await getDb();
  if (!db) {
    console.warn("[Analytics] Cannot get analytics: database not available");
    return null;
  }

  try {
    const since = new Date();
    since.setDate(since.getDate() - days);

    const analytics = await db
      .select()
      .from(connectorAnalytics)
      .where(
        and(
          eq(connectorAnalytics.connectorId, connectorId),
          gte(connectorAnalytics.createdAt, since)
        )
      )
      .orderBy(desc(connectorAnalytics.createdAt));

    // Calculate statistics
    const totalCalls = analytics.length;
    const successfulCalls = analytics.filter((a) => a.status === "success").length;
    const failedCalls = analytics.filter((a) => a.status === "failed").length;
    const successRate = totalCalls > 0 ? (successfulCalls / totalCalls) * 100 : 0;

    const durationsWithValues = analytics.filter((a) => a.duration !== null).map((a) => a.duration!);
    const avgDuration =
      durationsWithValues.length > 0
        ? durationsWithValues.reduce((sum, d) => sum + d, 0) / durationsWithValues.length
        : 0;

    // Group by action
    const actionStats = analytics.reduce((acc, a) => {
      if (!acc[a.action]) {
        acc[a.action] = { total: 0, success: 0, failed: 0 };
      }
      acc[a.action].total++;
      if (a.status === "success") {
        acc[a.action].success++;
      } else {
        acc[a.action].failed++;
      }
      return acc;
    }, {} as Record<string, { total: number; success: number; failed: number }>);

    // Group by date
    const dailyStats = analytics.reduce((acc, a) => {
      const date = a.createdAt.toISOString().split("T")[0];
      if (!acc[date]) {
        acc[date] = { total: 0, success: 0, failed: 0 };
      }
      acc[date].total++;
      if (a.status === "success") {
        acc[date].success++;
      } else {
        acc[date].failed++;
      }
      return acc;
    }, {} as Record<string, { total: number; success: number; failed: number }>);

    return {
      totalCalls,
      successfulCalls,
      failedCalls,
      successRate,
      avgDuration,
      actionStats,
      dailyStats,
      recentCalls: analytics.slice(0, 10), // Last 10 calls
    };
  } catch (error) {
    console.error("[Analytics] Failed to get analytics:", error);
    return null;
  }
}

/**
 * Get overall analytics for all connectors
 */
export async function getAllConnectorsAnalytics(days: number = 30) {
  const db = await getDb();
  if (!db) {
    console.warn("[Analytics] Cannot get analytics: database not available");
    return null;
  }

  try {
    const since = new Date();
    since.setDate(since.getDate() - days);

    const analytics = await db
      .select()
      .from(connectorAnalytics)
      .where(gte(connectorAnalytics.createdAt, since))
      .orderBy(desc(connectorAnalytics.createdAt));

    // Calculate overall statistics
    const totalCalls = analytics.length;
    const successfulCalls = analytics.filter((a) => a.status === "success").length;
    const failedCalls = analytics.filter((a) => a.status === "failed").length;
    const successRate = totalCalls > 0 ? (successfulCalls / totalCalls) * 100 : 0;

    // Group by connector
    const connectorStats = analytics.reduce((acc, a) => {
      if (!acc[a.connectorId]) {
        acc[a.connectorId] = { total: 0, success: 0, failed: 0 };
      }
      acc[a.connectorId].total++;
      if (a.status === "success") {
        acc[a.connectorId].success++;
      } else {
        acc[a.connectorId].failed++;
      }
      return acc;
    }, {} as Record<number, { total: number; success: number; failed: number }>);

    return {
      totalCalls,
      successfulCalls,
      failedCalls,
      successRate,
      connectorStats,
    };
  } catch (error) {
    console.error("[Analytics] Failed to get overall analytics:", error);
    return null;
  }
}

/**
 * Get detailed logs with pagination
 */
export async function getConnectorLogs(filters: {
  connectorId?: number;
  action?: string;
  status?: "success" | "failed";
  searchQuery?: string;
  limit?: number;
  offset?: number;
}) {
  const db = await getDb();
  if (!db) {
    console.warn("[Analytics] Cannot get logs: database not available");
    return { logs: [], total: 0 };
  }

  try {
    const conditions = [];

    if (filters.connectorId) {
      conditions.push(eq(connectorAnalytics.connectorId, filters.connectorId));
    }

    if (filters.action) {
      conditions.push(eq(connectorAnalytics.action, filters.action));
    }

    if (filters.status) {
      conditions.push(eq(connectorAnalytics.status, filters.status));
    }

    if (filters.searchQuery && filters.searchQuery.trim()) {
      conditions.push(sql`${connectorAnalytics.errorMessage} LIKE ${`%${filters.searchQuery}%`}`);
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    // Get total count
    const countResult = await db
      .select({ count: sql<number>`count(*)` })
      .from(connectorAnalytics)
      .where(whereClause);

    const total = countResult[0]?.count || 0;

    // Get logs
    const logs = await db
      .select()
      .from(connectorAnalytics)
      .where(whereClause)
      .orderBy(desc(connectorAnalytics.createdAt))
      .limit(filters.limit || 50)
      .offset(filters.offset || 0);

    return { logs, total };
  } catch (error) {
    console.error("[Analytics] Failed to get logs:", error);
    return { logs: [], total: 0 };
  }
}
