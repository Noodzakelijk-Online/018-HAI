import { EventBus } from './EventBus';

/**
 * Enhanced Frontier Engine - Peak Performance
 * 
 * Features:
 * - Capability discovery and cataloging
 * - Experimentation framework with A/B testing
 * - Feature flags and gradual rollouts
 * - Capability versioning and deprecation
 * - Integration marketplace
 * - Capability health monitoring
 * - Usage analytics and recommendations
 * - Auto-discovery of new capabilities
 */

export interface Capability {
  id: string;
  name: string;
  description: string;
  category: 'integration' | 'feature' | 'tool' | 'api' | 'service';
  version: string;
  status: 'experimental' | 'beta' | 'stable' | 'deprecated';
  provider: string;
  endpoints?: string[];
  requiredPermissions: string[];
  dependencies: string[];
  healthStatus: 'healthy' | 'degraded' | 'down' | 'unknown';
  lastChecked?: Date;
  metadata: Record<string, any>;
}

export interface Experiment {
  id: string;
  name: string;
  hypothesis: string;
  variants: Array<{
    id: string;
    name: string;
    description: string;
    config: Record<string, any>;
    allocation: number; // 0-100 percentage
  }>;
  metrics: Array<{
    name: string;
    type: 'conversion' | 'engagement' | 'performance' | 'revenue';
    goal: 'increase' | 'decrease';
  }>;
  status: 'draft' | 'running' | 'paused' | 'completed';
  startDate?: Date;
  endDate?: Date;
  results?: ExperimentResults;
}

export interface ExperimentResults {
  experimentId: string;
  variantResults: Array<{
    variantId: string;
    sampleSize: number;
    metrics: Record<string, number>;
    confidenceLevel: number; // 0-1
  }>;
  winner?: string; // variant ID
  statisticalSignificance: boolean;
  recommendations: string[];
}

export interface FeatureFlag {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  rolloutPercentage: number; // 0-100
  targetUsers?: string[];
  targetGroups?: string[];
  conditions?: Array<{
    field: string;
    operator: '==' | '!=' | '>' | '<' | 'in';
    value: any;
  }>;
  createdAt: Date;
  updatedAt: Date;
}

export interface CapabilityVersion {
  capabilityId: string;
  version: string;
  releaseDate: Date;
  changes: string[];
  breakingChanges: boolean;
  deprecationDate?: Date;
  sunsetDate?: Date;
  migrationGuide?: string;
}

export interface IntegrationListing {
  id: string;
  name: string;
  provider: string;
  category: string;
  description: string;
  logo?: string;
  screenshots: string[];
  pricing: {
    model: 'free' | 'freemium' | 'paid' | 'enterprise';
    tiers?: Array<{
      name: string;
      price: number;
      features: string[];
    }>;
  };
  rating: number;
  reviews: number;
  installs: number;
  verified: boolean;
  capabilities: Capability[];
}

export interface HealthCheck {
  capabilityId: string;
  timestamp: Date;
  status: 'healthy' | 'degraded' | 'down';
  responseTime: number; // milliseconds
  errorRate: number; // 0-1
  uptime: number; // percentage
  issues: Array<{
    severity: 'low' | 'medium' | 'high' | 'critical';
    message: string;
    detectedAt: Date;
  }>;
}

export interface UsageAnalytics {
  capabilityId: string;
  period: { start: Date; end: Date };
  totalCalls: number;
  uniqueUsers: number;
  averageLatency: number;
  errorRate: number;
  topUsers: Array<{ userId: string; callCount: number }>;
  topEndpoints: Array<{ endpoint: string; callCount: number }>;
  trends: {
    callsChange: number; // % change
    latencyChange: number;
    errorRateChange: number;
  };
}

export interface CapabilityRecommendation {
  id: string;
  capabilityId: string;
  reason: string;
  confidence: number; // 0-1
  basedOn: Array<'usage_pattern' | 'similar_users' | 'complementary' | 'trending'>;
  estimatedValue: string;
}

export class FrontierEngineEnhanced {
  private eventBus: typeof EventBus;
  private capabilities: Map<string, Capability> = new Map();
  private experiments: Map<string, Experiment> = new Map();
  private featureFlags: Map<string, FeatureFlag> = new Map();
  private versions: Map<string, CapabilityVersion[]> = new Map();
  private marketplace: Map<string, IntegrationListing> = new Map();
  private healthChecks: Map<string, HealthCheck[]> = new Map();
  private analytics: Map<string, UsageAnalytics> = new Map();

  constructor(eventBus: typeof EventBus) {
    this.eventBus = eventBus;
  }

  /**
   * Discover and register capability
   */
  async discoverCapability(capability: Omit<Capability, 'id' | 'healthStatus' | 'lastChecked'>): Promise<Capability> {
    const newCapability: Capability = {
      ...capability,
      id: `cap_${Date.now()}`,
      healthStatus: 'unknown',
    };

    this.capabilities.set(newCapability.id, newCapability);

    await this.eventBus.publish({
      type: 'frontier.capability.discovered',
      source: 'FrontierEngine',
      target: 'system',
      data: { capabilityId: newCapability.id, name: newCapability.name },
    });

    // Trigger initial health check
    await this.checkHealth(newCapability.id);

    return newCapability;
  }

  /**
   * Auto-discover capabilities from environment
   */
  async autoDiscover(): Promise<Capability[]> {
    // Mock auto-discovery
    const discovered: Capability[] = [];

    // Simulate discovering environment variables, APIs, etc.
    const mockCapabilities = [
      { name: 'Email Service', category: 'integration' as const, provider: 'SendGrid' },
      { name: 'Storage API', category: 'api' as const, provider: 'AWS S3' },
      { name: 'Analytics', category: 'service' as const, provider: 'Google Analytics' },
    ];

    for (const mock of mockCapabilities) {
      const capability = await this.discoverCapability({
        name: mock.name,
        description: `Auto-discovered ${mock.name}`,
        category: mock.category,
        version: '1.0.0',
        status: 'stable',
        provider: mock.provider,
        requiredPermissions: [],
        dependencies: [],
        metadata: { autoDiscovered: true },
      });
      discovered.push(capability);
    }

    return discovered;
  }

  /**
   * Create experiment
   */
  async createExperiment(experiment: Omit<Experiment, 'id' | 'status' | 'results'>): Promise<Experiment> {
    // Validate allocations sum to 100
    const totalAllocation = experiment.variants.reduce((sum, v) => sum + v.allocation, 0);
    if (Math.abs(totalAllocation - 100) > 0.01) {
      throw new Error('Variant allocations must sum to 100%');
    }

    const newExperiment: Experiment = {
      ...experiment,
      id: `exp_${Date.now()}`,
      status: 'draft',
    };

    this.experiments.set(newExperiment.id, newExperiment);

    await this.eventBus.publish({
      type: 'frontier.experiment.created',
      source: 'FrontierEngine',
      target: 'system',
      data: { experimentId: newExperiment.id, variantsCount: newExperiment.variants.length },
    });

    return newExperiment;
  }

  /**
   * Start experiment
   */
  async startExperiment(experimentId: string): Promise<void> {
    const experiment = this.experiments.get(experimentId);
    if (!experiment) {
      throw new Error('Experiment not found');
    }

    experiment.status = 'running';
    experiment.startDate = new Date();

    await this.eventBus.publish({
      type: 'frontier.experiment.started',
      source: 'FrontierEngine',
      target: 'system',
      data: { experimentId },
    });
  }

  /**
   * Assign user to experiment variant
   */
  async assignVariant(experimentId: string, userId: string): Promise<string> {
    const experiment = this.experiments.get(experimentId);
    if (!experiment || experiment.status !== 'running') {
      throw new Error('Experiment not running');
    }

    // Deterministic assignment based on user ID
    const hash = this.hashString(userId + experimentId);
    const bucket = hash % 100;

    let cumulative = 0;
    for (const variant of experiment.variants) {
      cumulative += variant.allocation;
      if (bucket < cumulative) {
        return variant.id;
      }
    }

    return experiment.variants[0].id; // Fallback
  }

  private hashString(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return Math.abs(hash);
  }

  /**
   * Complete experiment and analyze results
   */
  async completeExperiment(experimentId: string): Promise<ExperimentResults> {
    const experiment = this.experiments.get(experimentId);
    if (!experiment) {
      throw new Error('Experiment not found');
    }

    // Mock results
    const results: ExperimentResults = {
      experimentId,
      variantResults: experiment.variants.map(variant => ({
        variantId: variant.id,
        sampleSize: Math.floor(Math.random() * 1000) + 500,
        metrics: {
          conversion: 0.05 + Math.random() * 0.1,
          engagement: 0.3 + Math.random() * 0.2,
        },
        confidenceLevel: 0.85 + Math.random() * 0.1,
      })),
      statisticalSignificance: Math.random() > 0.3,
      recommendations: [],
    };

    // Determine winner
    const bestVariant = results.variantResults.reduce((best, current) => 
      current.metrics.conversion > best.metrics.conversion ? current : best
    );
    results.winner = bestVariant.variantId;

    if (results.statisticalSignificance) {
      results.recommendations.push(`Roll out variant ${bestVariant.variantId} to all users`);
    } else {
      results.recommendations.push('Continue experiment to gather more data');
    }

    experiment.status = 'completed';
    experiment.endDate = new Date();
    experiment.results = results;

    await this.eventBus.publish({
      type: 'frontier.experiment.completed',
      source: 'FrontierEngine',
      target: 'system',
      data: { experimentId, winner: results.winner },
    });

    return results;
  }

  /**
   * Create feature flag
   */
  async createFeatureFlag(flag: Omit<FeatureFlag, 'id' | 'createdAt' | 'updatedAt'>): Promise<FeatureFlag> {
    const newFlag: FeatureFlag = {
      ...flag,
      id: `flag_${Date.now()}`,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    this.featureFlags.set(newFlag.id, newFlag);

    await this.eventBus.publish({
      type: 'frontier.feature_flag.created',
      source: 'FrontierEngine',
      target: 'system',
      data: { flagId: newFlag.id, name: newFlag.name },
    });

    return newFlag;
  }

  /**
   * Check if feature is enabled for user
   */
  async isFeatureEnabled(flagId: string, userId: string, context?: Record<string, any>): Promise<boolean> {
    const flag = this.featureFlags.get(flagId);
    if (!flag) return false;

    if (!flag.enabled) return false;

    // Check target users
    if (flag.targetUsers && !flag.targetUsers.includes(userId)) {
      return false;
    }

    // Check conditions
    if (flag.conditions && context) {
      for (const condition of flag.conditions) {
        const value = context[condition.field];
        if (!this.evaluateCondition(value, condition.operator, condition.value)) {
          return false;
        }
      }
    }

    // Check rollout percentage
    const hash = this.hashString(userId + flagId);
    const bucket = hash % 100;
    return bucket < flag.rolloutPercentage;
  }

  private evaluateCondition(value: any, operator: string, expected: any): boolean {
    switch (operator) {
      case '==': return value === expected;
      case '!=': return value !== expected;
      case '>': return value > expected;
      case '<': return value < expected;
      case 'in': return Array.isArray(expected) && expected.includes(value);
      default: return false;
    }
  }

  /**
   * Gradual rollout of feature
   */
  async rolloutFeature(flagId: string, targetPercentage: number, incrementPerDay: number): Promise<void> {
    const flag = this.featureFlags.get(flagId);
    if (!flag) {
      throw new Error('Feature flag not found');
    }

    const daysNeeded = Math.ceil((targetPercentage - flag.rolloutPercentage) / incrementPerDay);

    // Simulate gradual rollout
    for (let day = 0; day < daysNeeded; day++) {
      flag.rolloutPercentage = Math.min(flag.rolloutPercentage + incrementPerDay, targetPercentage);
      flag.updatedAt = new Date();

      await this.eventBus.publish({
        type: 'frontier.feature_flag.updated',
        source: 'FrontierEngine',
        target: 'system',
        data: { flagId, rolloutPercentage: flag.rolloutPercentage },
      });

      // In production, this would be scheduled over actual days
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }

  /**
   * Register capability version
   */
  async registerVersion(version: CapabilityVersion): Promise<void> {
    if (!this.versions.has(version.capabilityId)) {
      this.versions.set(version.capabilityId, []);
    }

    this.versions.get(version.capabilityId)!.push(version);

    await this.eventBus.publish({
      type: 'frontier.version.registered',
      source: 'FrontierEngine',
      target: 'system',
      data: { capabilityId: version.capabilityId, version: version.version },
    });
  }

  /**
   * Add integration to marketplace
   */
  async addToMarketplace(listing: Omit<IntegrationListing, 'id' | 'rating' | 'reviews' | 'installs'>): Promise<IntegrationListing> {
    const newListing: IntegrationListing = {
      ...listing,
      id: `int_${Date.now()}`,
      rating: 0,
      reviews: 0,
      installs: 0,
    };

    this.marketplace.set(newListing.id, newListing);

    return newListing;
  }

  /**
   * Check capability health
   */
  async checkHealth(capabilityId: string): Promise<HealthCheck> {
    const capability = this.capabilities.get(capabilityId);
    if (!capability) {
      throw new Error('Capability not found');
    }

    // Mock health check
    const healthCheck: HealthCheck = {
      capabilityId,
      timestamp: new Date(),
      status: Math.random() > 0.1 ? 'healthy' : 'degraded',
      responseTime: Math.random() * 500 + 50,
      errorRate: Math.random() * 0.05,
      uptime: 95 + Math.random() * 5,
      issues: [],
    };

    if (healthCheck.status === 'degraded') {
      healthCheck.issues.push({
        severity: 'medium',
        message: 'Higher than normal response time',
        detectedAt: new Date(),
      });
    }

    capability.healthStatus = healthCheck.status;
    capability.lastChecked = healthCheck.timestamp;

    if (!this.healthChecks.has(capabilityId)) {
      this.healthChecks.set(capabilityId, []);
    }
    this.healthChecks.get(capabilityId)!.push(healthCheck);

    await this.eventBus.publish({
      type: 'frontier.health.checked',
      source: 'FrontierEngine',
      target: 'system',
      data: { capabilityId, status: healthCheck.status },
    });

    return healthCheck;
  }

  /**
   * Generate usage analytics
   */
  async generateAnalytics(capabilityId: string, period: { start: Date; end: Date }): Promise<UsageAnalytics> {
    // Mock analytics
    const analytics: UsageAnalytics = {
      capabilityId,
      period,
      totalCalls: Math.floor(Math.random() * 10000) + 1000,
      uniqueUsers: Math.floor(Math.random() * 500) + 50,
      averageLatency: Math.random() * 200 + 50,
      errorRate: Math.random() * 0.05,
      topUsers: [],
      topEndpoints: [],
      trends: {
        callsChange: (Math.random() - 0.5) * 40,
        latencyChange: (Math.random() - 0.5) * 20,
        errorRateChange: (Math.random() - 0.5) * 10,
      },
    };

    this.analytics.set(capabilityId, analytics);

    return analytics;
  }

  /**
   * Get capability recommendations
   */
  async getRecommendations(userId: string): Promise<CapabilityRecommendation[]> {
    const recommendations: CapabilityRecommendation[] = [];

    // Mock recommendations based on trending capabilities
    const capabilities = Array.from(this.capabilities.values());
    const trending = capabilities.filter(c => c.status === 'stable').slice(0, 3);

    trending.forEach(cap => {
      recommendations.push({
        id: `rec_${Date.now()}_${cap.id}`,
        capabilityId: cap.id,
        reason: `Popular among users with similar usage patterns`,
        confidence: 0.7 + Math.random() * 0.2,
        basedOn: ['trending', 'similar_users'],
        estimatedValue: 'High - could improve productivity by 20%',
      });
    });

    return recommendations;
  }

  /**
   * Get capabilities
   */
  getCapabilities(category?: Capability['category']): Capability[] {
    const capabilities = Array.from(this.capabilities.values());
    return category ? capabilities.filter(c => c.category === category) : capabilities;
  }

  /**
   * Get experiments
   */
  getExperiments(status?: Experiment['status']): Experiment[] {
    const experiments = Array.from(this.experiments.values());
    return status ? experiments.filter(e => e.status === status) : experiments;
  }

  /**
   * Get feature flags
   */
  getFeatureFlags(): FeatureFlag[] {
    return Array.from(this.featureFlags.values());
  }

  /**
   * Get marketplace listings
   */
  getMarketplace(category?: string): IntegrationListing[] {
    const listings = Array.from(this.marketplace.values());
    return category ? listings.filter(l => l.category === category) : listings;
  }
}
