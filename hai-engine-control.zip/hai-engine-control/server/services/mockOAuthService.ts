/**
 * Mock OAuth Service
 * Simulates OAuth2 authentication flow for development/testing
 * Replace with real OAuth implementation when ready
 */

import crypto from 'crypto';

export interface MockOAuthToken {
  accessToken: string;
  refreshToken: string;
  expiresAt: Date;
  scope: string[];
}

/**
 * Generate mock OAuth token
 */
export function generateMockToken(connectorType: string): MockOAuthToken {
  const scopes = {
    gmail: ['https://www.googleapis.com/auth/gmail.send'],
    calendar: ['https://www.googleapis.com/auth/calendar.events'],
    google_drive: ['https://www.googleapis.com/auth/drive.file'],
    slack: ['chat:write', 'channels:read'],
    trello: ['read', 'write'],
    github: ['repo', 'user'],
  };

  return {
    accessToken: `mock_access_${crypto.randomBytes(16).toString('hex')}`,
    refreshToken: `mock_refresh_${crypto.randomBytes(16).toString('hex')}`,
    expiresAt: new Date(Date.now() + 3600 * 1000), // 1 hour from now
    scope: scopes[connectorType as keyof typeof scopes] || ['basic'],
  };
}

/**
 * Simulate OAuth authorization URL
 */
export function getMockAuthorizationUrl(connectorType: string, state: string): string {
  // In real OAuth, this would redirect to Google/Slack/etc.
  // For mock, we return a fake URL that the frontend can handle
  return `/api/oauth/mock-authorize?type=${connectorType}&state=${state}`;
}

/**
 * Simulate OAuth token exchange
 */
export async function exchangeMockAuthorizationCode(
  code: string,
  connectorType: string
): Promise<MockOAuthToken> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Validate mock code format
  if (!code.startsWith('mock_code_')) {
    throw new Error('Invalid authorization code');
  }

  return generateMockToken(connectorType);
}

/**
 * Simulate token refresh
 */
export async function refreshMockToken(refreshToken: string, connectorType: string): Promise<MockOAuthToken> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  // Validate refresh token
  if (!refreshToken.startsWith('mock_refresh_')) {
    throw new Error('Invalid refresh token');
  }

  return generateMockToken(connectorType);
}

/**
 * Encrypt credentials for storage
 */
export function encryptCredentials(credentials: any): string {
  // Simple base64 encoding for mock (use proper encryption in production)
  return Buffer.from(JSON.stringify(credentials)).toString('base64');
}

/**
 * Decrypt credentials from storage
 */
export function decryptCredentials(encrypted: string): any {
  // Simple base64 decoding for mock (use proper decryption in production)
  try {
    return JSON.parse(Buffer.from(encrypted, 'base64').toString());
  } catch (error) {
    throw new Error('Failed to decrypt credentials');
  }
}

/**
 * Check if token is expired
 */
export function isTokenExpired(expiresAt: Date): boolean {
  return new Date() >= expiresAt;
}

/**
 * Mock Gmail: Send email
 */
export async function mockGmailSendEmail(
  token: string,
  to: string[],
  subject: string,
  body: string,
  html?: string
): Promise<{ success: boolean; messageId: string }> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  console.log('[Mock Gmail] Sending email:', {
    to,
    subject,
    body: body.substring(0, 50) + '...',
  });

  return {
    success: true,
    messageId: `mock_msg_${crypto.randomBytes(8).toString('hex')}`,
  };
}

/**
 * Mock Calendar: Create event
 */
export async function mockCalendarCreateEvent(
  token: string,
  title: string,
  start: Date,
  end: Date,
  description?: string,
  location?: string
): Promise<{ success: boolean; eventId: string; eventUrl: string }> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 800));
  
  console.log('[Mock Calendar] Creating event:', {
    title,
    start,
    end,
    location,
  });

  const eventId = `mock_event_${crypto.randomBytes(8).toString('hex')}`;
  
  return {
    success: true,
    eventId,
    eventUrl: `https://calendar.google.com/calendar/event?eid=${eventId}`,
  };
}

/**
 * Mock Slack: Send message
 */
export async function mockSlackSendMessage(
  token: string,
  channel: string,
  text: string
): Promise<{ success: boolean; ts: string }> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 600));
  
  console.log('[Mock Slack] Sending message:', {
    channel,
    text: text.substring(0, 50) + '...',
  });

  return {
    success: true,
    ts: Date.now().toString(),
  };
}
