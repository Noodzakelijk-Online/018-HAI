/**
 * Database Connection Pool Monitor
 * Implements P1 #72: Connection pool monitoring
 * Implements P1 #84: Database connection retry
 */

export interface PoolStats {
  totalConnections: number;
  activeConnections: number;
  idleConnections: number;
  waitingRequests: number;
  maxConnections: number;
  minConnections: number;
  acquireTimeout: number;
  idleTimeout: number;
}

export interface PoolHealth {
  status: 'healthy' | 'degraded' | 'critical';
  utilizationPercent: number;
  stats: PoolStats;
  lastChecked: Date;
  warnings: string[];
}

// Mock pool stats for monitoring
let poolStats: PoolStats = {
  totalConnections: 10,
  activeConnections: 2,
  idleConnections: 8,
  waitingRequests: 0,
  maxConnections: 10,
  minConnections: 2,
  acquireTimeout: 30000,
  idleTimeout: 600000,
};

const poolHistory: PoolHealth[] = [];
const MAX_HISTORY = 100;

/**
 * Get current pool statistics
 */
export function getPoolStats(): PoolStats {
  return { ...poolStats };
}

/**
 * Update pool stats (called by connection events)
 */
export function updatePoolStats(updates: Partial<PoolStats>): void {
  poolStats = { ...poolStats, ...updates };
}

/**
 * Check pool health
 */
export function checkPoolHealth(): PoolHealth {
  const stats = getPoolStats();
  const utilizationPercent = (stats.activeConnections / stats.maxConnections) * 100;
  
  const warnings: string[] = [];
  let status: 'healthy' | 'degraded' | 'critical' = 'healthy';
  
  // Check utilization
  if (utilizationPercent >= 90) {
    status = 'critical';
    warnings.push('Connection pool nearly exhausted (>90% utilization)');
  } else if (utilizationPercent >= 75) {
    status = 'degraded';
    warnings.push('High connection pool utilization (>75%)');
  }
  
  // Check waiting requests
  if (stats.waitingRequests > 10) {
    status = 'critical';
    warnings.push(`High number of waiting requests: ${stats.waitingRequests}`);
  } else if (stats.waitingRequests > 5) {
    if (status === 'healthy') status = 'degraded';
    warnings.push(`Requests waiting for connections: ${stats.waitingRequests}`);
  }
  
  // Check idle connections
  if (stats.idleConnections === 0 && stats.activeConnections === stats.maxConnections) {
    status = 'critical';
    warnings.push('No idle connections available');
  }
  
  const health: PoolHealth = {
    status,
    utilizationPercent,
    stats,
    lastChecked: new Date(),
    warnings,
  };
  
  // Store in history
  poolHistory.push(health);
  if (poolHistory.length > MAX_HISTORY) {
    poolHistory.shift();
  }
  
  return health;
}

/**
 * Get pool health history
 */
export function getPoolHistory(): PoolHealth[] {
  return [...poolHistory];
}

/**
 * Connection retry configuration
 */
export interface RetryConfig {
  maxAttempts: number;
  initialDelayMs: number;
  maxDelayMs: number;
  backoffMultiplier: number;
}

const DEFAULT_RETRY_CONFIG: RetryConfig = {
  maxAttempts: 5,
  initialDelayMs: 1000,
  maxDelayMs: 30000,
  backoffMultiplier: 2,
};

/**
 * Retry database connection with exponential backoff
 */
export async function retryConnection<T>(
  connectFn: () => Promise<T>,
  config: Partial<RetryConfig> = {}
): Promise<T> {
  const { maxAttempts, initialDelayMs, maxDelayMs, backoffMultiplier } = {
    ...DEFAULT_RETRY_CONFIG,
    ...config,
  };
  
  let lastError: Error | undefined;
  
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      console.log(`[DBPool] Connection attempt ${attempt}/${maxAttempts}`);
      const result = await connectFn();
      console.log(`[DBPool] Connection successful on attempt ${attempt}`);
      return result;
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      console.warn(`[DBPool] Connection attempt ${attempt} failed:`, lastError.message);
      
      if (attempt < maxAttempts) {
        const delay = Math.min(
          initialDelayMs * Math.pow(backoffMultiplier, attempt - 1),
          maxDelayMs
        );
        console.log(`[DBPool] Retrying in ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }
  
  throw new Error(`Failed to connect after ${maxAttempts} attempts: ${lastError?.message}`);
}

/**
 * Monitor pool and emit warnings
 */
let monitorInterval: NodeJS.Timeout | null = null;

export function startPoolMonitoring(intervalMs: number = 30000): void {
  if (monitorInterval) {
    clearInterval(monitorInterval);
  }
  
  monitorInterval = setInterval(() => {
    const health = checkPoolHealth();
    
    if (health.status === 'critical') {
      console.error('[DBPool] CRITICAL: Pool health is critical', health.warnings);
    } else if (health.status === 'degraded') {
      console.warn('[DBPool] WARNING: Pool health is degraded', health.warnings);
    }
  }, intervalMs);
  
  console.log(`[DBPool] Pool monitoring started (interval: ${intervalMs / 1000}s)`);
}

export function stopPoolMonitoring(): void {
  if (monitorInterval) {
    clearInterval(monitorInterval);
    monitorInterval = null;
    console.log('[DBPool] Pool monitoring stopped');
  }
}

/**
 * Simulate connection events for testing
 */
export function simulateConnectionAcquire(): void {
  poolStats.activeConnections = Math.min(poolStats.activeConnections + 1, poolStats.maxConnections);
  poolStats.idleConnections = Math.max(poolStats.idleConnections - 1, 0);
}

export function simulateConnectionRelease(): void {
  poolStats.activeConnections = Math.max(poolStats.activeConnections - 1, 0);
  poolStats.idleConnections = Math.min(poolStats.idleConnections + 1, poolStats.maxConnections);
}

export default {
  getPoolStats,
  updatePoolStats,
  checkPoolHealth,
  getPoolHistory,
  retryConnection,
  startPoolMonitoring,
  stopPoolMonitoring,
};
