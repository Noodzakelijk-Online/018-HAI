import { spawn } from 'child_process';

/**
 * OpenAGI Lux Agent Service
 * 
 * Wrapper around the `oagi` CLI for executing computer-use tasks with Lux models.
 * Lux operates in three modes:
 * - lux-actor-1: Fast, immediate tasks (seconds)
 * - lux-tasker-1: Stable, step-by-step workflows (minutes)
 * - lux-thinker-1: Complex, autonomous goals (hours)
 */

export type LuxModel = 'lux-actor-1' | 'lux-tasker-1' | 'lux-thinker-1';

export interface LuxTask {
  goal: string;
  model: LuxModel;
  timeout?: number; // Optional timeout in seconds
}

export interface LuxAction {
  type: string;
  target?: string;
  value?: string;
  timestamp: string;
}

export interface LuxResult {
  success: boolean;
  output: string;
  screenshots: string[];
  actions: LuxAction[];
  duration: number; // in seconds
  cost: number; // estimated cost in USD
  error?: string;
}

/**
 * Execute a task using OpenAGI Lux
 * 
 * @param task - The task to execute
 * @returns Promise<LuxResult> - The execution result
 * 
 * @example
 * ```typescript
 * const result = await executeLuxTask({
 *   goal: "Go to Google and search for OpenAGI",
 *   model: "lux-actor-1"
 * });
 * ```
 */
export async function executeLuxTask(task: LuxTask): Promise<LuxResult> {
  const startTime = Date.now();
  
  return new Promise((resolve, reject) => {
    // Check if API key is configured
    if (!process.env.OAGI_API_KEY) {
      reject({
        success: false,
        output: '',
        screenshots: [],
        actions: [],
        duration: 0,
        cost: 0,
        error: 'OAGI_API_KEY environment variable not set. Get your API key from https://developer.agiopen.org/'
      });
      return;
    }

    // Spawn oagi CLI process
    const args = [
      'agent',
      'run',
      task.goal,
      '--model',
      task.model
    ];

    const childProcess = spawn('oagi', args, {
      env: {
        ...process.env,
        OAGI_API_KEY: process.env.OAGI_API_KEY,
        OAGI_BASE_URL: process.env.OAGI_BASE_URL || 'https://api.agiopen.org'
      }
    });
    
    let stdout = '';
    let stderr = '';
    
    childProcess.stdout?.on('data', (data) => {
      stdout += data.toString();
      // TODO: Stream progress updates via WebSocket
    });
    
    childProcess.stderr?.on('data', (data) => {
      stderr += data.toString();
    });

    // Set timeout if specified
    let timeoutHandle: NodeJS.Timeout | null = null;
    if (task.timeout) {
      timeoutHandle = setTimeout(() => {
        childProcess.kill('SIGTERM');
        reject({
          success: false,
          output: stdout,
          screenshots: [],
          actions: [],
          duration: (Date.now() - startTime) / 1000,
          cost: 0,
          error: `Task timeout after ${task.timeout} seconds`
        });
      }, task.timeout * 1000);
    }
    
    childProcess.on('close', (code) => {
      if (timeoutHandle) {
        clearTimeout(timeoutHandle);
      }

      const duration = (Date.now() - startTime) / 1000;
      
      if (code === 0) {
        // Try to parse JSON output
        try {
          const result = JSON.parse(stdout);
          resolve({
            success: true,
            output: result.output || stdout,
            screenshots: result.screenshots || [],
            actions: result.actions || [],
            duration,
            cost: result.cost || estimateCost(task.model, duration)
          });
        } catch (error) {
          // If not JSON, return raw output
          resolve({
            success: true,
            output: stdout,
            screenshots: [],
            actions: [],
            duration,
            cost: estimateCost(task.model, duration)
          });
        }
      } else {
        reject({
          success: false,
          output: stdout,
          screenshots: [],
          actions: [],
          duration,
          cost: 0,
          error: stderr || `Process exited with code ${code}`
        });
      }
    });

    childProcess.on('error', (error) => {
      if (timeoutHandle) {
        clearTimeout(timeoutHandle);
      }

      reject({
        success: false,
        output: '',
        screenshots: [],
        actions: [],
        duration: (Date.now() - startTime) / 1000,
        cost: 0,
        error: `Failed to spawn oagi process: ${error.message}. Make sure 'oagi' is installed (pip install oagi).`
      });
    });
  });
}

/**
 * Estimate the cost of a Lux task based on model and duration
 * 
 * Note: These are rough estimates. Actual costs may vary.
 * Lux is approximately 10x cheaper than OpenAI/Anthropic.
 * 
 * @param model - The Lux model used
 * @param duration - Task duration in seconds
 * @returns Estimated cost in USD
 */
function estimateCost(model: LuxModel, duration: number): number {
  // Rough cost estimates (per minute)
  const costPerMinute: Record<LuxModel, number> = {
    'lux-actor-1': 0.05,    // Fast tasks, minimal processing
    'lux-tasker-1': 0.10,   // Moderate processing
    'lux-thinker-1': 0.20   // Complex reasoning
  };

  const minutes = duration / 60;
  return Number((costPerMinute[model] * minutes).toFixed(4));
}

/**
 * Check if Lux is available and properly configured
 * 
 * @returns Promise<boolean> - True if Lux is available
 */
export async function checkLuxStatus(): Promise<{
  available: boolean;
  error?: string;
}> {
  // Check if API key is set
  if (!process.env.OAGI_API_KEY) {
    return {
      available: false,
      error: 'OAGI_API_KEY not configured. Get your API key from https://developer.agiopen.org/'
    };
  }

  // Check if oagi CLI is installed
  return new Promise((resolve) => {
    const childProcess = spawn('oagi', ['--help']);
    
    childProcess.on('close', (code) => {
      if (code === 0) {
        resolve({ available: true });
      } else {
        resolve({
          available: false,
          error: 'oagi CLI not found. Install with: pip install oagi'
        });
      }
    });

    childProcess.on('error', () => {
      resolve({
        available: false,
        error: 'oagi CLI not found. Install with: pip install oagi'
      });
    });
  });
}

/**
 * Get Lux model information
 * 
 * @returns Model descriptions and use cases
 */
export function getLuxModels() {
  return [
    {
      id: 'lux-actor-1' as LuxModel,
      name: 'Lux Actor',
      description: 'Fast, immediate tasks completed in seconds',
      useCases: ['Quick lookups', 'Simple navigation', 'Urgent actions'],
      estimatedSpeed: 'seconds',
      costPerMinute: 0.05
    },
    {
      id: 'lux-tasker-1' as LuxModel,
      name: 'Lux Tasker',
      description: 'Stable, step-by-step workflows with ultra-reliable execution',
      useCases: ['Form filling', 'Data entry', 'QA testing', 'High-stakes actions'],
      estimatedSpeed: 'minutes',
      costPerMinute: 0.10
    },
    {
      id: 'lux-thinker-1' as LuxModel,
      name: 'Lux Thinker',
      description: 'Complex, autonomous goals requiring deep reasoning',
      useCases: ['Research projects', 'Multi-step workflows', 'Vague goals'],
      estimatedSpeed: 'hours',
      costPerMinute: 0.20
    }
  ];
}
