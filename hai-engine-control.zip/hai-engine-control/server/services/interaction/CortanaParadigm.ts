/**
 * HUMAN INTERACTION LAYER: Cortana Paradigm
 * 
 * HAI's personality and communication style:
 * - Proactive but not intrusive
 * - Helpful but respects autonomy
 * - Learns communication preferences
 * - Adapts tone to context and member
 */

// ============================================================================
// TYPES
// ============================================================================

export type PersonalityTrait = 
  | 'proactive'
  | 'helpful'
  | 'respectful'
  | 'efficient'
  | 'warm'
  | 'professional'
  | 'casual';

export type CommunicationTone = 'formal' | 'professional' | 'friendly' | 'casual';
export type UrgencyLevel = 'critical' | 'high' | 'normal' | 'low' | 'info';
export type MessageChannel = 'dashboard' | 'notification' | 'email' | 'sms' | 'voice';

export interface HAIPersona {
  name: string;
  traits: PersonalityTrait[];
  defaultTone: CommunicationTone;
  greeting: string;
  signoff: string;
  avatarUrl?: string;
}

export interface CommunicationPreference {
  memberId: number;
  preferredTone: CommunicationTone;
  preferredChannels: MessageChannel[];
  quietHours: { start: string; end: string } | null;
  notificationFrequency: 'immediate' | 'batched' | 'digest';
  verbosityLevel: 'minimal' | 'standard' | 'detailed';
}

export interface HAIMessage {
  id: number;
  householdId: number;
  memberId?: number;
  
  // Content
  type: 'notification' | 'suggestion' | 'question' | 'confirmation' | 'update' | 'alert';
  title: string;
  body: string;
  
  // Styling
  tone: CommunicationTone;
  urgency: UrgencyLevel;
  
  // Context
  context?: {
    actionId?: number;
    relatedEntity?: string;
    relatedEntityId?: number;
  };
  
  // Actions
  actions?: Array<{
    label: string;
    action: string;
    primary?: boolean;
  }>;
  
  // Status
  channel: MessageChannel;
  sentAt: Date;
  readAt?: Date;
  respondedAt?: Date;
  response?: string;
  
  // Metadata
  createdAt: Date;
}

export interface ConversationContext {
  householdId: number;
  memberId: number;
  recentMessages: HAIMessage[];
  currentTopic?: string;
  pendingQuestions: string[];
  lastInteractionAt: Date;
}

// ============================================================================
// DEFAULT PERSONA
// ============================================================================

const DEFAULT_PERSONA: HAIPersona = {
  name: 'HAI',
  traits: ['proactive', 'helpful', 'respectful', 'efficient'],
  defaultTone: 'professional',
  greeting: "Hello! I'm HAI, your household assistant.",
  signoff: "Let me know if you need anything else.",
  avatarUrl: undefined,
};

// ============================================================================
// IN-MEMORY STORES
// ============================================================================

const messageStore: Map<number, HAIMessage> = new Map();
const preferenceStore: Map<number, CommunicationPreference> = new Map(); // memberId -> prefs
const contextStore: Map<string, ConversationContext> = new Map(); // `${householdId}-${memberId}` -> context
let messageIdCounter = 1;

// ============================================================================
// CORTANA PARADIGM SERVICE
// ============================================================================

export class CortanaParadigmService {
  private static instance: CortanaParadigmService;
  private persona: HAIPersona = DEFAULT_PERSONA;

  private constructor() {}

  static getInstance(): CortanaParadigmService {
    if (!CortanaParadigmService.instance) {
      CortanaParadigmService.instance = new CortanaParadigmService();
    }
    return CortanaParadigmService.instance;
  }

  // ============================================================================
  // PERSONA MANAGEMENT
  // ============================================================================

  /**
   * Get current persona
   */
  getPersona(): HAIPersona {
    return { ...this.persona };
  }

  /**
   * Update persona
   */
  updatePersona(updates: Partial<HAIPersona>): HAIPersona {
    this.persona = { ...this.persona, ...updates };
    return this.persona;
  }

  // ============================================================================
  // MESSAGE GENERATION
  // ============================================================================

  /**
   * Generate a message with appropriate tone and style
   */
  async generateMessage(
    householdId: number,
    data: {
      type: HAIMessage['type'];
      title: string;
      body: string;
      memberId?: number;
      urgency?: UrgencyLevel;
      context?: HAIMessage['context'];
      actions?: HAIMessage['actions'];
      channel?: MessageChannel;
    }
  ): Promise<HAIMessage> {
    // Get member preferences if targeting specific member
    const prefs = data.memberId ? preferenceStore.get(data.memberId) : undefined;
    const tone = prefs?.preferredTone || this.persona.defaultTone;
    const channel = data.channel || prefs?.preferredChannels?.[0] || 'dashboard';

    // Adapt message based on tone
    const adaptedBody = this.adaptMessageTone(data.body, tone);

    const message: HAIMessage = {
      id: messageIdCounter++,
      householdId,
      memberId: data.memberId,
      type: data.type,
      title: data.title,
      body: adaptedBody,
      tone,
      urgency: data.urgency || 'normal',
      context: data.context,
      actions: data.actions,
      channel,
      sentAt: new Date(),
      createdAt: new Date(),
    };

    messageStore.set(message.id, message);

    // Update conversation context
    if (data.memberId) {
      this.updateContext(householdId, data.memberId, message);
    }

    return message;
  }

  /**
   * Adapt message tone
   */
  private adaptMessageTone(body: string, tone: CommunicationTone): string {
    // Simple tone adaptation - in production, this would use LLM
    switch (tone) {
      case 'formal':
        return body.replace(/Hey/g, 'Hello').replace(/!/g, '.');
      case 'casual':
        return body.replace(/Hello/g, 'Hey').replace(/\./g, '!');
      case 'friendly':
        return body + ' 😊';
      default:
        return body;
    }
  }

  // ============================================================================
  // PROACTIVE NOTIFICATIONS
  // ============================================================================

  /**
   * Send a proactive notification
   */
  async sendNotification(
    householdId: number,
    data: {
      title: string;
      body: string;
      memberId?: number;
      urgency?: UrgencyLevel;
      actions?: HAIMessage['actions'];
    }
  ): Promise<HAIMessage> {
    return this.generateMessage(householdId, {
      type: 'notification',
      ...data,
      channel: 'notification',
    });
  }

  /**
   * Send a suggestion
   */
  async sendSuggestion(
    householdId: number,
    data: {
      title: string;
      body: string;
      memberId?: number;
      actions?: HAIMessage['actions'];
      context?: HAIMessage['context'];
    }
  ): Promise<HAIMessage> {
    return this.generateMessage(householdId, {
      type: 'suggestion',
      urgency: 'low',
      ...data,
    });
  }

  /**
   * Ask a question
   */
  async askQuestion(
    householdId: number,
    data: {
      title: string;
      body: string;
      memberId: number;
      options?: string[];
    }
  ): Promise<HAIMessage> {
    const actions = data.options?.map(opt => ({
      label: opt,
      action: `respond:${opt}`,
    }));

    return this.generateMessage(householdId, {
      type: 'question',
      title: data.title,
      body: data.body,
      memberId: data.memberId,
      urgency: 'normal',
      actions,
    });
  }

  /**
   * Send an alert
   */
  async sendAlert(
    householdId: number,
    data: {
      title: string;
      body: string;
      urgency: UrgencyLevel;
      memberId?: number;
      actions?: HAIMessage['actions'];
    }
  ): Promise<HAIMessage> {
    return this.generateMessage(householdId, {
      type: 'alert',
      ...data,
    });
  }

  // ============================================================================
  // PREFERENCE MANAGEMENT
  // ============================================================================

  /**
   * Set communication preferences for a member
   */
  setPreferences(memberId: number, prefs: Partial<CommunicationPreference>): CommunicationPreference {
    const existing = preferenceStore.get(memberId);
    const updated: CommunicationPreference = {
      memberId,
      preferredTone: prefs.preferredTone || existing?.preferredTone || 'professional',
      preferredChannels: prefs.preferredChannels || existing?.preferredChannels || ['dashboard'],
      quietHours: prefs.quietHours !== undefined ? prefs.quietHours : existing?.quietHours || null,
      notificationFrequency: prefs.notificationFrequency || existing?.notificationFrequency || 'immediate',
      verbosityLevel: prefs.verbosityLevel || existing?.verbosityLevel || 'standard',
    };

    preferenceStore.set(memberId, updated);
    return updated;
  }

  /**
   * Get communication preferences for a member
   */
  getPreferences(memberId: number): CommunicationPreference | undefined {
    return preferenceStore.get(memberId);
  }

  // ============================================================================
  // CONTEXT MANAGEMENT
  // ============================================================================

  /**
   * Update conversation context
   */
  private updateContext(householdId: number, memberId: number, message: HAIMessage): void {
    const key = `${householdId}-${memberId}`;
    const existing = contextStore.get(key);

    const context: ConversationContext = {
      householdId,
      memberId,
      recentMessages: [...(existing?.recentMessages || []).slice(-9), message],
      currentTopic: existing?.currentTopic,
      pendingQuestions: message.type === 'question'
        ? [...(existing?.pendingQuestions || []), message.title]
        : existing?.pendingQuestions || [],
      lastInteractionAt: new Date(),
    };

    contextStore.set(key, context);
  }

  /**
   * Get conversation context
   */
  getContext(householdId: number, memberId: number): ConversationContext | undefined {
    return contextStore.get(`${householdId}-${memberId}`);
  }

  // ============================================================================
  // MESSAGE MANAGEMENT
  // ============================================================================

  /**
   * Mark message as read
   */
  async markAsRead(messageId: number): Promise<void> {
    const message = messageStore.get(messageId);
    if (message) {
      message.readAt = new Date();
    }
  }

  /**
   * Record response to message
   */
  async recordResponse(messageId: number, response: string): Promise<void> {
    const message = messageStore.get(messageId);
    if (message) {
      message.respondedAt = new Date();
      message.response = response;

      // Remove from pending questions if applicable
      if (message.memberId) {
        const context = contextStore.get(`${message.householdId}-${message.memberId}`);
        if (context) {
          context.pendingQuestions = context.pendingQuestions.filter(q => q !== message.title);
        }
      }
    }
  }

  /**
   * Get messages for a household
   */
  async getMessages(
    householdId: number,
    options?: {
      memberId?: number;
      type?: HAIMessage['type'];
      unreadOnly?: boolean;
      limit?: number;
    }
  ): Promise<HAIMessage[]> {
    let messages = Array.from(messageStore.values())
      .filter(m => m.householdId === householdId);

    if (options?.memberId) {
      messages = messages.filter(m => m.memberId === options.memberId || !m.memberId);
    }

    if (options?.type) {
      messages = messages.filter(m => m.type === options.type);
    }

    if (options?.unreadOnly) {
      messages = messages.filter(m => !m.readAt);
    }

    messages.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());

    return options?.limit ? messages.slice(0, options.limit) : messages;
  }

  /**
   * Get message by ID
   */
  async getMessage(messageId: number): Promise<HAIMessage | undefined> {
    return messageStore.get(messageId);
  }

  // ============================================================================
  // STATISTICS
  // ============================================================================

  /**
   * Get interaction statistics
   */
  async getStatistics(householdId: number): Promise<{
    totalMessages: number;
    unreadCount: number;
    byType: Record<HAIMessage['type'], number>;
    byUrgency: Record<UrgencyLevel, number>;
    responseRate: number;
    avgResponseTime: number;
  }> {
    const messages = Array.from(messageStore.values())
      .filter(m => m.householdId === householdId);

    const byType: Record<HAIMessage['type'], number> = {
      notification: 0,
      suggestion: 0,
      question: 0,
      confirmation: 0,
      update: 0,
      alert: 0,
    };

    const byUrgency: Record<UrgencyLevel, number> = {
      critical: 0,
      high: 0,
      normal: 0,
      low: 0,
      info: 0,
    };

    let respondedCount = 0;
    let totalResponseTime = 0;

    for (const msg of messages) {
      byType[msg.type]++;
      byUrgency[msg.urgency]++;

      if (msg.respondedAt && msg.sentAt) {
        respondedCount++;
        totalResponseTime += msg.respondedAt.getTime() - msg.sentAt.getTime();
      }
    }

    const questionsAsked = messages.filter(m => m.type === 'question').length;

    return {
      totalMessages: messages.length,
      unreadCount: messages.filter(m => !m.readAt).length,
      byType,
      byUrgency,
      responseRate: questionsAsked > 0 ? respondedCount / questionsAsked : 1,
      avgResponseTime: respondedCount > 0 ? totalResponseTime / respondedCount : 0,
    };
  }
}

// Export singleton instance
export const cortanaParadigmService = CortanaParadigmService.getInstance();
