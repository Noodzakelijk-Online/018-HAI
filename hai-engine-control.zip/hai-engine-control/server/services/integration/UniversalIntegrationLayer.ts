/**
 * Universal Integration Layer
 * 
 * Connects to ANY service, API, or protocol. HAI can integrate with
 * everything from smart home devices to financial institutions to
 * healthcare providers.
 */

import { EventEmitter } from 'events';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

export interface Integration {
  id: string;
  type: IntegrationType;
  category: IntegrationCategory;
  name: string;
  description: string;
  provider: string;
  status: IntegrationStatus;
  config: IntegrationConfig;
  capabilities: IntegrationCapability[];
  authentication: AuthConfig;
  rateLimits: RateLimitConfig;
  healthStatus: HealthStatus;
  lastSync: Date | null;
  createdAt: Date;
  householdId: number;
}

export type IntegrationType =
  | 'oauth2' | 'api_key' | 'basic_auth' | 'webhook'
  | 'mqtt' | 'websocket' | 'polling' | 'push'
  | 'sdk' | 'scraping' | 'email' | 'sms';

export type IntegrationCategory =
  | 'smart_home' | 'financial' | 'calendar' | 'email'
  | 'health' | 'shopping' | 'entertainment' | 'travel'
  | 'communication' | 'security' | 'energy' | 'vehicle'
  | 'education' | 'work' | 'social' | 'government'
  | 'utilities' | 'insurance' | 'real_estate' | 'custom';

export type IntegrationStatus =
  | 'active' | 'inactive' | 'pending' | 'error'
  | 'rate_limited' | 'expired' | 'revoked';

export interface IntegrationConfig {
  baseUrl?: string;
  endpoints: Record<string, string>;
  headers?: Record<string, string>;
  timeout: number;
  retryPolicy: RetryPolicy;
  transformations?: DataTransformation[];
}

export interface IntegrationCapability {
  name: string;
  description: string;
  permissions: string[];
  dataTypes: string[];
  operations: ('read' | 'write' | 'delete' | 'subscribe')[];
}

export interface AuthConfig {
  type: IntegrationType;
  credentials: Record<string, string>;
  tokenEndpoint?: string;
  refreshToken?: string;
  expiresAt?: Date;
  scopes?: string[];
}

export interface RateLimitConfig {
  requestsPerMinute: number;
  requestsPerHour: number;
  requestsPerDay: number;
  currentUsage: {
    minute: number;
    hour: number;
    day: number;
  };
  resetTimes: {
    minute: Date;
    hour: Date;
    day: Date;
  };
}

export interface RetryPolicy {
  maxRetries: number;
  backoffMultiplier: number;
  initialDelay: number;
  maxDelay: number;
  retryableErrors: string[];
}

export interface DataTransformation {
  source: string;
  target: string;
  transform: 'map' | 'filter' | 'reduce' | 'custom';
  config: Record<string, any>;
}

export interface HealthStatus {
  status: 'healthy' | 'degraded' | 'unhealthy' | 'unknown';
  lastCheck: Date;
  latency: number;
  errorRate: number;
  uptime: number;
}

export interface IntegrationRequest {
  integrationId: string;
  operation: string;
  endpoint: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  data?: any;
  headers?: Record<string, string>;
  timeout?: number;
}

export interface IntegrationResponse {
  success: boolean;
  data?: any;
  error?: string;
  statusCode: number;
  latency: number;
  cached: boolean;
}

// ============================================================================
// INTEGRATION TEMPLATES
// ============================================================================

export const INTEGRATION_TEMPLATES: Record<string, Partial<Integration>> = {
  // Smart Home
  'google_home': {
    type: 'oauth2',
    category: 'smart_home',
    name: 'Google Home',
    provider: 'Google',
    capabilities: [
      { name: 'device_control', description: 'Control smart devices', permissions: ['devices.read', 'devices.write'], dataTypes: ['device_state'], operations: ['read', 'write'] },
      { name: 'routines', description: 'Manage routines', permissions: ['routines.read', 'routines.write'], dataTypes: ['routine'], operations: ['read', 'write'] },
    ],
  },
  'amazon_alexa': {
    type: 'oauth2',
    category: 'smart_home',
    name: 'Amazon Alexa',
    provider: 'Amazon',
    capabilities: [
      { name: 'device_control', description: 'Control Alexa devices', permissions: ['alexa:devices:read', 'alexa:devices:write'], dataTypes: ['device_state'], operations: ['read', 'write'] },
    ],
  },
  'apple_homekit': {
    type: 'sdk',
    category: 'smart_home',
    name: 'Apple HomeKit',
    provider: 'Apple',
    capabilities: [
      { name: 'device_control', description: 'Control HomeKit devices', permissions: ['homekit.read', 'homekit.write'], dataTypes: ['device_state'], operations: ['read', 'write'] },
    ],
  },
  'smartthings': {
    type: 'oauth2',
    category: 'smart_home',
    name: 'Samsung SmartThings',
    provider: 'Samsung',
    capabilities: [
      { name: 'device_control', description: 'Control SmartThings devices', permissions: ['devices:read', 'devices:write'], dataTypes: ['device_state'], operations: ['read', 'write'] },
    ],
  },

  // Financial
  'plaid': {
    type: 'api_key',
    category: 'financial',
    name: 'Plaid',
    provider: 'Plaid',
    capabilities: [
      { name: 'accounts', description: 'Access bank accounts', permissions: ['accounts'], dataTypes: ['account', 'balance'], operations: ['read'] },
      { name: 'transactions', description: 'Access transactions', permissions: ['transactions'], dataTypes: ['transaction'], operations: ['read'] },
    ],
  },
  'stripe': {
    type: 'api_key',
    category: 'financial',
    name: 'Stripe',
    provider: 'Stripe',
    capabilities: [
      { name: 'payments', description: 'Process payments', permissions: ['payments:read', 'payments:write'], dataTypes: ['payment', 'invoice'], operations: ['read', 'write'] },
    ],
  },

  // Calendar
  'google_calendar': {
    type: 'oauth2',
    category: 'calendar',
    name: 'Google Calendar',
    provider: 'Google',
    capabilities: [
      { name: 'events', description: 'Manage calendar events', permissions: ['calendar.events'], dataTypes: ['event'], operations: ['read', 'write', 'delete'] },
      { name: 'calendars', description: 'Manage calendars', permissions: ['calendar.calendars'], dataTypes: ['calendar'], operations: ['read', 'write'] },
    ],
  },
  'outlook_calendar': {
    type: 'oauth2',
    category: 'calendar',
    name: 'Outlook Calendar',
    provider: 'Microsoft',
    capabilities: [
      { name: 'events', description: 'Manage calendar events', permissions: ['Calendars.ReadWrite'], dataTypes: ['event'], operations: ['read', 'write', 'delete'] },
    ],
  },

  // Email
  'gmail': {
    type: 'oauth2',
    category: 'email',
    name: 'Gmail',
    provider: 'Google',
    capabilities: [
      { name: 'read', description: 'Read emails', permissions: ['gmail.readonly'], dataTypes: ['email'], operations: ['read'] },
      { name: 'send', description: 'Send emails', permissions: ['gmail.send'], dataTypes: ['email'], operations: ['write'] },
      { name: 'labels', description: 'Manage labels', permissions: ['gmail.labels'], dataTypes: ['label'], operations: ['read', 'write'] },
    ],
  },
  'outlook_mail': {
    type: 'oauth2',
    category: 'email',
    name: 'Outlook Mail',
    provider: 'Microsoft',
    capabilities: [
      { name: 'read', description: 'Read emails', permissions: ['Mail.Read'], dataTypes: ['email'], operations: ['read'] },
      { name: 'send', description: 'Send emails', permissions: ['Mail.Send'], dataTypes: ['email'], operations: ['write'] },
    ],
  },

  // Health
  'apple_health': {
    type: 'sdk',
    category: 'health',
    name: 'Apple Health',
    provider: 'Apple',
    capabilities: [
      { name: 'health_data', description: 'Access health data', permissions: ['health.read'], dataTypes: ['health_record'], operations: ['read'] },
    ],
  },
  'fitbit': {
    type: 'oauth2',
    category: 'health',
    name: 'Fitbit',
    provider: 'Google',
    capabilities: [
      { name: 'activity', description: 'Access activity data', permissions: ['activity'], dataTypes: ['activity'], operations: ['read'] },
      { name: 'sleep', description: 'Access sleep data', permissions: ['sleep'], dataTypes: ['sleep'], operations: ['read'] },
    ],
  },

  // Shopping
  'amazon': {
    type: 'oauth2',
    category: 'shopping',
    name: 'Amazon',
    provider: 'Amazon',
    capabilities: [
      { name: 'orders', description: 'Access order history', permissions: ['orders:read'], dataTypes: ['order'], operations: ['read'] },
      { name: 'lists', description: 'Manage shopping lists', permissions: ['lists:read', 'lists:write'], dataTypes: ['list'], operations: ['read', 'write'] },
    ],
  },
  'instacart': {
    type: 'oauth2',
    category: 'shopping',
    name: 'Instacart',
    provider: 'Instacart',
    capabilities: [
      { name: 'orders', description: 'Place grocery orders', permissions: ['orders:read', 'orders:write'], dataTypes: ['order'], operations: ['read', 'write'] },
    ],
  },

  // Security
  'ring': {
    type: 'oauth2',
    category: 'security',
    name: 'Ring',
    provider: 'Amazon',
    capabilities: [
      { name: 'devices', description: 'Access Ring devices', permissions: ['devices:read'], dataTypes: ['device_state', 'video'], operations: ['read'] },
      { name: 'alerts', description: 'Receive alerts', permissions: ['alerts:read'], dataTypes: ['alert'], operations: ['read', 'subscribe'] },
    ],
  },
  'nest': {
    type: 'oauth2',
    category: 'security',
    name: 'Google Nest',
    provider: 'Google',
    capabilities: [
      { name: 'cameras', description: 'Access Nest cameras', permissions: ['cameras:read'], dataTypes: ['video', 'alert'], operations: ['read', 'subscribe'] },
      { name: 'thermostat', description: 'Control thermostat', permissions: ['thermostat:read', 'thermostat:write'], dataTypes: ['temperature'], operations: ['read', 'write'] },
    ],
  },

  // Vehicle
  'tesla': {
    type: 'oauth2',
    category: 'vehicle',
    name: 'Tesla',
    provider: 'Tesla',
    capabilities: [
      { name: 'vehicle_state', description: 'Access vehicle state', permissions: ['vehicle:read'], dataTypes: ['vehicle_state'], operations: ['read'] },
      { name: 'commands', description: 'Send vehicle commands', permissions: ['vehicle:write'], dataTypes: ['command'], operations: ['write'] },
    ],
  },

  // Utilities
  'utility_api': {
    type: 'api_key',
    category: 'utilities',
    name: 'Utility API',
    provider: 'Various',
    capabilities: [
      { name: 'usage', description: 'Access utility usage', permissions: ['usage:read'], dataTypes: ['usage'], operations: ['read'] },
      { name: 'bills', description: 'Access utility bills', permissions: ['bills:read'], dataTypes: ['bill'], operations: ['read'] },
    ],
  },
};

// ============================================================================
// UNIVERSAL INTEGRATION LAYER
// ============================================================================

export class UniversalIntegrationLayer extends EventEmitter {
  private integrations: Map<string, Integration> = new Map();
  private requestQueue: Map<string, IntegrationRequest[]> = new Map();
  private cache: Map<string, { data: any; expiresAt: Date }> = new Map();

  constructor() {
    super();
    this.startHealthMonitor();
    this.startRateLimitReset();
  }

  // -------------------------------------------------------------------------
  // INTEGRATION MANAGEMENT
  // -------------------------------------------------------------------------

  async createIntegration(
    templateId: string,
    householdId: number,
    authConfig: AuthConfig,
    customConfig?: Partial<IntegrationConfig>
  ): Promise<Integration> {
    const template = INTEGRATION_TEMPLATES[templateId];
    if (!template) {
      throw new Error(`Unknown integration template: ${templateId}`);
    }

    const integration: Integration = {
      id: this.generateId('int'),
      type: template.type || 'api_key',
      category: template.category || 'custom',
      name: template.name || templateId,
      description: template.description || '',
      provider: template.provider || 'Unknown',
      status: 'pending',
      config: {
        endpoints: {},
        timeout: 30000,
        retryPolicy: {
          maxRetries: 3,
          backoffMultiplier: 2,
          initialDelay: 1000,
          maxDelay: 30000,
          retryableErrors: ['ETIMEDOUT', 'ECONNRESET', '429', '503'],
        },
        ...customConfig,
      },
      capabilities: template.capabilities || [],
      authentication: authConfig,
      rateLimits: {
        requestsPerMinute: 60,
        requestsPerHour: 1000,
        requestsPerDay: 10000,
        currentUsage: { minute: 0, hour: 0, day: 0 },
        resetTimes: {
          minute: new Date(Date.now() + 60000),
          hour: new Date(Date.now() + 3600000),
          day: new Date(Date.now() + 86400000),
        },
      },
      healthStatus: {
        status: 'unknown',
        lastCheck: new Date(),
        latency: 0,
        errorRate: 0,
        uptime: 100,
      },
      lastSync: null,
      createdAt: new Date(),
      householdId,
    };

    // Validate authentication
    const authValid = await this.validateAuthentication(integration);
    if (authValid) {
      integration.status = 'active';
    } else {
      integration.status = 'error';
    }

    this.integrations.set(integration.id, integration);
    this.emit('integration_created', integration);

    return integration;
  }

  async updateIntegration(
    integrationId: string,
    updates: Partial<Integration>
  ): Promise<Integration | null> {
    const integration = this.integrations.get(integrationId);
    if (!integration) return null;

    Object.assign(integration, updates);
    this.emit('integration_updated', integration);

    return integration;
  }

  async deleteIntegration(integrationId: string): Promise<boolean> {
    const integration = this.integrations.get(integrationId);
    if (!integration) return false;

    // Revoke tokens if OAuth
    if (integration.type === 'oauth2') {
      await this.revokeOAuthTokens(integration);
    }

    this.integrations.delete(integrationId);
    this.emit('integration_deleted', integration);

    return true;
  }

  // -------------------------------------------------------------------------
  // AUTHENTICATION
  // -------------------------------------------------------------------------

  private async validateAuthentication(integration: Integration): Promise<boolean> {
    try {
      switch (integration.type) {
        case 'oauth2':
          return await this.validateOAuth2(integration);
        case 'api_key':
          return await this.validateApiKey(integration);
        case 'basic_auth':
          return await this.validateBasicAuth(integration);
        default:
          return true;
      }
    } catch (error) {
      console.error(`[Integration] Auth validation failed for ${integration.id}:`, error);
      return false;
    }
  }

  private async validateOAuth2(integration: Integration): Promise<boolean> {
    // Check if token is expired
    if (integration.authentication.expiresAt && 
        integration.authentication.expiresAt < new Date()) {
      // Try to refresh
      return await this.refreshOAuthToken(integration);
    }
    return !!integration.authentication.credentials.access_token;
  }

  private async refreshOAuthToken(integration: Integration): Promise<boolean> {
    if (!integration.authentication.refreshToken) return false;

    try {
      // Simulate token refresh
      console.log(`[Integration] Refreshing OAuth token for ${integration.id}`);
      integration.authentication.expiresAt = new Date(Date.now() + 3600000);
      return true;
    } catch (error) {
      console.error(`[Integration] Token refresh failed for ${integration.id}:`, error);
      return false;
    }
  }

  private async revokeOAuthTokens(integration: Integration): Promise<void> {
    console.log(`[Integration] Revoking OAuth tokens for ${integration.id}`);
  }

  private async validateApiKey(integration: Integration): Promise<boolean> {
    return !!integration.authentication.credentials.api_key;
  }

  private async validateBasicAuth(integration: Integration): Promise<boolean> {
    return !!(integration.authentication.credentials.username && 
              integration.authentication.credentials.password);
  }

  // -------------------------------------------------------------------------
  // REQUEST EXECUTION
  // -------------------------------------------------------------------------

  async executeRequest(request: IntegrationRequest): Promise<IntegrationResponse> {
    const integration = this.integrations.get(request.integrationId);
    if (!integration) {
      return {
        success: false,
        error: 'Integration not found',
        statusCode: 404,
        latency: 0,
        cached: false,
      };
    }

    // Check rate limits
    if (!this.checkRateLimits(integration)) {
      return {
        success: false,
        error: 'Rate limit exceeded',
        statusCode: 429,
        latency: 0,
        cached: false,
      };
    }

    // Check cache
    const cacheKey = this.getCacheKey(request);
    const cached = this.cache.get(cacheKey);
    if (cached && cached.expiresAt > new Date() && request.method === 'GET') {
      return {
        success: true,
        data: cached.data,
        statusCode: 200,
        latency: 0,
        cached: true,
      };
    }

    // Execute request with retry
    const startTime = Date.now();
    let lastError: string | undefined;
    let attempts = 0;

    while (attempts <= integration.config.retryPolicy.maxRetries) {
      try {
        const response = await this.makeRequest(integration, request);
        const latency = Date.now() - startTime;

        // Update rate limits
        this.updateRateLimits(integration);

        // Cache successful GET requests
        if (request.method === 'GET' && response.success) {
          this.cache.set(cacheKey, {
            data: response.data,
            expiresAt: new Date(Date.now() + 300000), // 5 minute cache
          });
        }

        return { ...response, latency, cached: false };
      } catch (error: any) {
        lastError = error.message;
        attempts++;

        if (attempts <= integration.config.retryPolicy.maxRetries) {
          const delay = Math.min(
            integration.config.retryPolicy.initialDelay * 
            Math.pow(integration.config.retryPolicy.backoffMultiplier, attempts - 1),
            integration.config.retryPolicy.maxDelay
          );
          await this.sleep(delay);
        }
      }
    }

    return {
      success: false,
      error: lastError || 'Request failed after retries',
      statusCode: 500,
      latency: Date.now() - startTime,
      cached: false,
    };
  }

  private async makeRequest(
    integration: Integration,
    request: IntegrationRequest
  ): Promise<IntegrationResponse> {
    // Simulate API request
    console.log(`[Integration] Making request to ${integration.name}: ${request.method} ${request.endpoint}`);

    // Add authentication headers
    const headers = { ...request.headers };
    switch (integration.type) {
      case 'oauth2':
        headers['Authorization'] = `Bearer ${integration.authentication.credentials.access_token}`;
        break;
      case 'api_key':
        headers['X-API-Key'] = integration.authentication.credentials.api_key;
        break;
      case 'basic_auth':
        const credentials = Buffer.from(
          `${integration.authentication.credentials.username}:${integration.authentication.credentials.password}`
        ).toString('base64');
        headers['Authorization'] = `Basic ${credentials}`;
        break;
    }

    // Simulate successful response
    return {
      success: true,
      data: { message: 'Request successful', timestamp: new Date() },
      statusCode: 200,
      latency: 0,
      cached: false,
    };
  }

  // -------------------------------------------------------------------------
  // RATE LIMITING
  // -------------------------------------------------------------------------

  private checkRateLimits(integration: Integration): boolean {
    const limits = integration.rateLimits;
    return (
      limits.currentUsage.minute < limits.requestsPerMinute &&
      limits.currentUsage.hour < limits.requestsPerHour &&
      limits.currentUsage.day < limits.requestsPerDay
    );
  }

  private updateRateLimits(integration: Integration): void {
    integration.rateLimits.currentUsage.minute++;
    integration.rateLimits.currentUsage.hour++;
    integration.rateLimits.currentUsage.day++;
  }

  private startRateLimitReset(): void {
    // Reset minute counters
    setInterval(() => {
      for (const integration of this.integrations.values()) {
        integration.rateLimits.currentUsage.minute = 0;
        integration.rateLimits.resetTimes.minute = new Date(Date.now() + 60000);
      }
    }, 60000);

    // Reset hour counters
    setInterval(() => {
      for (const integration of this.integrations.values()) {
        integration.rateLimits.currentUsage.hour = 0;
        integration.rateLimits.resetTimes.hour = new Date(Date.now() + 3600000);
      }
    }, 3600000);

    // Reset day counters
    setInterval(() => {
      for (const integration of this.integrations.values()) {
        integration.rateLimits.currentUsage.day = 0;
        integration.rateLimits.resetTimes.day = new Date(Date.now() + 86400000);
      }
    }, 86400000);
  }

  // -------------------------------------------------------------------------
  // HEALTH MONITORING
  // -------------------------------------------------------------------------

  private startHealthMonitor(): void {
    setInterval(() => {
      this.checkAllIntegrationHealth();
    }, 300000); // Every 5 minutes
  }

  private async checkAllIntegrationHealth(): Promise<void> {
    for (const integration of this.integrations.values()) {
      await this.checkIntegrationHealth(integration);
    }
  }

  private async checkIntegrationHealth(integration: Integration): Promise<void> {
    const startTime = Date.now();

    try {
      // Simulate health check
      const latency = Date.now() - startTime;
      
      integration.healthStatus = {
        status: 'healthy',
        lastCheck: new Date(),
        latency,
        errorRate: 0,
        uptime: 100,
      };
    } catch (error) {
      integration.healthStatus = {
        status: 'unhealthy',
        lastCheck: new Date(),
        latency: Date.now() - startTime,
        errorRate: 100,
        uptime: integration.healthStatus.uptime * 0.9,
      };
    }
  }

  // -------------------------------------------------------------------------
  // DATA SYNC
  // -------------------------------------------------------------------------

  async syncIntegration(integrationId: string): Promise<boolean> {
    const integration = this.integrations.get(integrationId);
    if (!integration || integration.status !== 'active') return false;

    console.log(`[Integration] Syncing ${integration.name}`);

    try {
      // Sync each capability
      for (const capability of integration.capabilities) {
        if (capability.operations.includes('read')) {
          await this.syncCapability(integration, capability);
        }
      }

      integration.lastSync = new Date();
      this.emit('integration_synced', integration);

      return true;
    } catch (error) {
      console.error(`[Integration] Sync failed for ${integration.id}:`, error);
      return false;
    }
  }

  private async syncCapability(
    integration: Integration,
    capability: IntegrationCapability
  ): Promise<void> {
    console.log(`[Integration] Syncing capability: ${capability.name}`);
    // Capability-specific sync logic would go here
  }

  // -------------------------------------------------------------------------
  // QUERIES
  // -------------------------------------------------------------------------

  getIntegrations(householdId: number): Integration[] {
    return Array.from(this.integrations.values())
      .filter(i => i.householdId === householdId);
  }

  getIntegrationsByCategory(
    householdId: number,
    category: IntegrationCategory
  ): Integration[] {
    return this.getIntegrations(householdId)
      .filter(i => i.category === category);
  }

  getActiveIntegrations(householdId: number): Integration[] {
    return this.getIntegrations(householdId)
      .filter(i => i.status === 'active');
  }

  getAvailableTemplates(): string[] {
    return Object.keys(INTEGRATION_TEMPLATES);
  }

  getTemplateInfo(templateId: string): Partial<Integration> | undefined {
    return INTEGRATION_TEMPLATES[templateId];
  }

  getIntegrationHealth(householdId: number): {
    total: number;
    healthy: number;
    degraded: number;
    unhealthy: number;
    integrations: Array<{ id: string; name: string; status: string; health: string }>;
  } {
    const integrations = this.getIntegrations(householdId);
    
    return {
      total: integrations.length,
      healthy: integrations.filter(i => i.healthStatus.status === 'healthy').length,
      degraded: integrations.filter(i => i.healthStatus.status === 'degraded').length,
      unhealthy: integrations.filter(i => i.healthStatus.status === 'unhealthy').length,
      integrations: integrations.map(i => ({
        id: i.id,
        name: i.name,
        status: i.status,
        health: i.healthStatus.status,
      })),
    };
  }

  // -------------------------------------------------------------------------
  // HELPERS
  // -------------------------------------------------------------------------

  private generateId(prefix: string): string {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private getCacheKey(request: IntegrationRequest): string {
    return `${request.integrationId}:${request.method}:${request.endpoint}:${JSON.stringify(request.data || {})}`;
  }

  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

export const universalIntegrationLayer = new UniversalIntegrationLayer();
