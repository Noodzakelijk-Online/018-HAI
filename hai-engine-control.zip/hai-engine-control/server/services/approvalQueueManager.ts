/**
 * Approval Queue Manager
 * 
 * Manages pending decisions that require human approval
 */

import { getDb } from '../db';
import { approvalQueue, type ApprovalQueueItem, type InsertApprovalQueueItem } from '../../drizzle/schema';
import { eq, and, desc } from 'drizzle-orm';

export class ApprovalQueueManager {
  /**
   * Create a new approval queue item
   */
  async createItem(item: Omit<InsertApprovalQueueItem, 'id' | 'createdAt'>): Promise<ApprovalQueueItem> {
    const db = await getDb();
    if (!db) {
      throw new Error('Database not available');
    }

    const [created] = await db.insert(approvalQueue).values(item as InsertApprovalQueueItem).$returningId();
    
    const [newItem] = await db.select().from(approvalQueue).where(eq(approvalQueue.id, created.id));
    
    console.log(`[ApprovalQueue] Created item: ${item.title}`);
    
    return newItem;
  }

  /**
   * Get pending items for a household
   */
  async getPendingItems(householdId: number): Promise<ApprovalQueueItem[]> {
    const db = await getDb();
    if (!db) {
      return [];
    }

    const items = await db
      .select()
      .from(approvalQueue)
      .where(
        and(
          eq(approvalQueue.householdId, householdId),
          eq(approvalQueue.status, 'pending')
        )
      )
      .orderBy(desc(approvalQueue.createdAt));

    return items;
  }

  /**
   * Get all items for a household (with status filter)
   */
  async getItems(householdId: number, status?: string): Promise<ApprovalQueueItem[]> {
    const db = await getDb();
    if (!db) {
      return [];
    }

    const conditions = [eq(approvalQueue.householdId, householdId)];
    
    if (status) {
      conditions.push(eq(approvalQueue.status, status as any));
    }

    const items = await db
      .select()
      .from(approvalQueue)
      .where(and(...conditions))
      .orderBy(desc(approvalQueue.createdAt));

    return items;
  }

  /**
   * Approve an item
   */
  async approveItem(itemId: number, userId: number): Promise<ApprovalQueueItem> {
    const db = await getDb();
    if (!db) {
      throw new Error('Database not available');
    }

    await db
      .update(approvalQueue)
      .set({
        status: 'approved',
        reviewedBy: userId,
        reviewedAt: new Date(),
      })
      .where(eq(approvalQueue.id, itemId));

    const [updated] = await db.select().from(approvalQueue).where(eq(approvalQueue.id, itemId));
    
    console.log(`[ApprovalQueue] Approved item ${itemId} by user ${userId}`);
    
    return updated;
  }

  /**
   * Reject an item
   */
  async rejectItem(itemId: number, userId: number): Promise<ApprovalQueueItem> {
    const db = await getDb();
    if (!db) {
      throw new Error('Database not available');
    }

    await db
      .update(approvalQueue)
      .set({
        status: 'rejected',
        reviewedBy: userId,
        reviewedAt: new Date(),
      })
      .where(eq(approvalQueue.id, itemId));

    const [updated] = await db.select().from(approvalQueue).where(eq(approvalQueue.id, itemId));
    
    console.log(`[ApprovalQueue] Rejected item ${itemId} by user ${userId}`);
    
    return updated;
  }

  /**
   * Get item by ID
   */
  async getItem(itemId: number): Promise<ApprovalQueueItem | undefined> {
    const db = await getDb();
    if (!db) {
      return undefined;
    }

    const [item] = await db.select().from(approvalQueue).where(eq(approvalQueue.id, itemId));
    
    return item;
  }

  /**
   * Delete expired items
   */
  async cleanupExpired(): Promise<number> {
    const db = await getDb();
    if (!db) {
      return 0;
    }

    const now = new Date();
    
    // Update expired items to 'expired' status
    const result = await db
      .update(approvalQueue)
      .set({ status: 'expired' })
      .where(
        and(
          eq(approvalQueue.status, 'pending'),
          // expiresAt < now
        )
      );

    console.log(`[ApprovalQueue] Marked ${result.rowsAffected} items as expired`);
    
    return result.rowsAffected || 0;
  }
}

// Export singleton instance
export const approvalQueueManager = new ApprovalQueueManager();
