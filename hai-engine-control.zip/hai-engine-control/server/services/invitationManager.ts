import { eq, and } from "drizzle-orm";
import { getDb } from "../db";
import { householdInvitations, householdMembers, households, users } from "../../drizzle/schema";
import type { InsertHouseholdInvitation } from "../../drizzle/schema";
import { randomBytes } from "crypto";

/**
 * Generate a unique invitation token
 */
function generateInvitationToken(): string {
  return randomBytes(32).toString("hex");
}

/**
 * Create a new household invitation
 */
export async function createInvitation(params: {
  householdId: number;
  invitedBy: number;
  invitedEmail?: string;
  expiresInDays?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const { householdId, invitedBy, invitedEmail, expiresInDays = 7 } = params;

  // Generate unique token
  const token = generateInvitationToken();

  // Calculate expiration date
  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + expiresInDays);

  const invitation: InsertHouseholdInvitation = {
    householdId,
    invitedBy,
    invitedEmail: invitedEmail || null,
    token,
    status: "pending",
    expiresAt,
  };

  const result = await db.insert(householdInvitations).values(invitation);
  const invitationId = result[0].insertId;

  return {
    id: invitationId,
    token,
    expiresAt,
  };
}

/**
 * Get invitation by token
 */
export async function getInvitationByToken(token: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select({
      invitation: householdInvitations,
      household: households,
      inviter: users,
    })
    .from(householdInvitations)
    .leftJoin(households, eq(householdInvitations.householdId, households.id))
    .leftJoin(users, eq(householdInvitations.invitedBy, users.id))
    .where(eq(householdInvitations.token, token))
    .limit(1);

  if (result.length === 0) return null;

  return result[0];
}

/**
 * Accept an invitation
 */
export async function acceptInvitation(params: {
  token: string;
  userId: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const { token, userId } = params;

  // Get invitation
  const invitationData = await getInvitationByToken(token);
  if (!invitationData || !invitationData.invitation) {
    throw new Error("Invitation not found");
  }

  const invitation = invitationData.invitation;

  // Check if invitation is still valid
  if (invitation.status !== "pending") {
    throw new Error(`Invitation is ${invitation.status}`);
  }

  // Check if expired
  if (new Date() > new Date(invitation.expiresAt)) {
    // Mark as expired
    await db
      .update(householdInvitations)
      .set({ status: "expired" })
      .where(eq(householdInvitations.id, invitation.id));
    throw new Error("Invitation has expired");
  }

  // Check if user is already a member
  const existingMember = await db
    .select()
    .from(householdMembers)
    .where(
      and(
        eq(householdMembers.householdId, invitation.householdId),
        eq(householdMembers.userId, userId)
      )
    )
    .limit(1);

  if (existingMember.length > 0) {
    throw new Error("You are already a member of this household");
  }

  // Add user as household member
  await db.insert(householdMembers).values({
    householdId: invitation.householdId,
    userId,
    role: "member",
  });

  // Mark invitation as accepted
  await db
    .update(householdInvitations)
    .set({
      status: "accepted",
      acceptedAt: new Date(),
      acceptedBy: userId,
    })
    .where(eq(householdInvitations.id, invitation.id));

  return {
    householdId: invitation.householdId,
    householdName: invitationData.household?.name,
  };
}

/**
 * List pending invitations for a household
 */
export async function listInvitations(householdId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select({
      invitation: householdInvitations,
      inviter: users,
    })
    .from(householdInvitations)
    .leftJoin(users, eq(householdInvitations.invitedBy, users.id))
    .where(
      and(
        eq(householdInvitations.householdId, householdId),
        eq(householdInvitations.status, "pending")
      )
    );

  return result.map((row) => ({
    ...row.invitation,
    inviterName: row.inviter?.name || "Unknown",
  }));
}

/**
 * Revoke an invitation
 */
export async function revokeInvitation(invitationId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .update(householdInvitations)
    .set({ status: "revoked" })
    .where(eq(householdInvitations.id, invitationId));
}
