/**
 * Complete SME (Subject Matter Expert) Agents System
 * 
 * 47 specialized AI agents covering every aspect of household management.
 * Each agent has deep domain expertise and can handle complex scenarios.
 */

import { EventEmitter } from 'events';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

export interface SMEAgent {
  id: string;
  name: string;
  domain: AgentDomain;
  specializations: string[];
  capabilities: AgentCapability[];
  status: 'active' | 'idle' | 'busy' | 'offline';
  currentTasks: number;
  totalTasksCompleted: number;
  successRate: number;
  averageResponseTime: number; // ms
  lastActive: Date;
}

export type AgentDomain =
  | 'financial' | 'health' | 'home' | 'family' | 'career'
  | 'education' | 'social' | 'travel' | 'legal' | 'technology'
  | 'wellness' | 'security' | 'entertainment' | 'shopping'
  | 'communication' | 'planning' | 'emergency' | 'lifestyle';

export interface AgentCapability {
  name: string;
  description: string;
  complexity: 'basic' | 'intermediate' | 'advanced' | 'expert';
  requiredData: string[];
  outputTypes: string[];
}

export interface AgentTask {
  id: string;
  agentId: string;
  type: string;
  input: Record<string, any>;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  result?: any;
  error?: string;
  startedAt?: Date;
  completedAt?: Date;
  householdId: number;
  memberId?: number;
}

export interface AgentCollaboration {
  id: string;
  primaryAgentId: string;
  collaboratingAgentIds: string[];
  task: string;
  status: 'active' | 'completed';
  contributions: Map<string, any>;
  finalResult?: any;
}

// ============================================================================
// AGENT DEFINITIONS - ALL 47 SME AGENTS
// ============================================================================

export const SME_AGENT_DEFINITIONS: Omit<SMEAgent, 'status' | 'currentTasks' | 'totalTasksCompleted' | 'successRate' | 'averageResponseTime' | 'lastActive'>[] = [
  // =========================================================================
  // FINANCIAL AGENTS (1-8)
  // =========================================================================
  {
    id: 'fin_budget',
    name: 'Budget Master',
    domain: 'financial',
    specializations: ['budgeting', 'expense tracking', 'savings goals', 'cash flow'],
    capabilities: [
      { name: 'Create Budget', description: 'Create comprehensive household budget', complexity: 'intermediate', requiredData: ['income', 'expenses'], outputTypes: ['budget_plan'] },
      { name: 'Track Expenses', description: 'Categorize and track all expenses', complexity: 'basic', requiredData: ['transactions'], outputTypes: ['expense_report'] },
      { name: 'Savings Analysis', description: 'Analyze savings potential', complexity: 'intermediate', requiredData: ['income', 'expenses', 'goals'], outputTypes: ['savings_plan'] },
      { name: 'Cash Flow Forecast', description: 'Predict future cash flow', complexity: 'advanced', requiredData: ['income', 'expenses', 'bills'], outputTypes: ['forecast'] },
    ],
  },
  {
    id: 'fin_invest',
    name: 'Investment Advisor',
    domain: 'financial',
    specializations: ['investments', 'portfolio management', 'risk assessment', 'retirement'],
    capabilities: [
      { name: 'Portfolio Analysis', description: 'Analyze investment portfolio', complexity: 'advanced', requiredData: ['holdings', 'goals'], outputTypes: ['analysis_report'] },
      { name: 'Risk Assessment', description: 'Assess investment risk tolerance', complexity: 'intermediate', requiredData: ['profile', 'goals'], outputTypes: ['risk_profile'] },
      { name: 'Retirement Planning', description: 'Create retirement savings plan', complexity: 'expert', requiredData: ['age', 'income', 'savings', 'goals'], outputTypes: ['retirement_plan'] },
      { name: 'Rebalancing Recommendations', description: 'Suggest portfolio rebalancing', complexity: 'advanced', requiredData: ['portfolio', 'targets'], outputTypes: ['recommendations'] },
    ],
  },
  {
    id: 'fin_tax',
    name: 'Tax Strategist',
    domain: 'financial',
    specializations: ['tax planning', 'deductions', 'tax-efficient strategies', 'filing'],
    capabilities: [
      { name: 'Tax Optimization', description: 'Identify tax-saving opportunities', complexity: 'expert', requiredData: ['income', 'deductions', 'investments'], outputTypes: ['tax_strategy'] },
      { name: 'Deduction Finder', description: 'Find eligible deductions', complexity: 'intermediate', requiredData: ['expenses', 'receipts'], outputTypes: ['deduction_list'] },
      { name: 'Estimated Tax', description: 'Calculate estimated taxes', complexity: 'intermediate', requiredData: ['income', 'withholdings'], outputTypes: ['tax_estimate'] },
      { name: 'Year-End Planning', description: 'Year-end tax planning strategies', complexity: 'advanced', requiredData: ['ytd_data', 'projections'], outputTypes: ['action_plan'] },
    ],
  },
  {
    id: 'fin_debt',
    name: 'Debt Strategist',
    domain: 'financial',
    specializations: ['debt management', 'payoff strategies', 'consolidation', 'credit'],
    capabilities: [
      { name: 'Debt Analysis', description: 'Analyze all debts and interest', complexity: 'intermediate', requiredData: ['debts'], outputTypes: ['debt_report'] },
      { name: 'Payoff Strategy', description: 'Create optimal payoff plan', complexity: 'advanced', requiredData: ['debts', 'income', 'budget'], outputTypes: ['payoff_plan'] },
      { name: 'Consolidation Analysis', description: 'Evaluate consolidation options', complexity: 'advanced', requiredData: ['debts', 'credit_score'], outputTypes: ['consolidation_options'] },
      { name: 'Credit Improvement', description: 'Strategies to improve credit', complexity: 'intermediate', requiredData: ['credit_report'], outputTypes: ['improvement_plan'] },
    ],
  },
  {
    id: 'fin_insurance',
    name: 'Insurance Advisor',
    domain: 'financial',
    specializations: ['insurance coverage', 'policy analysis', 'claims', 'risk protection'],
    capabilities: [
      { name: 'Coverage Analysis', description: 'Analyze insurance coverage gaps', complexity: 'advanced', requiredData: ['policies', 'assets', 'family'], outputTypes: ['coverage_report'] },
      { name: 'Policy Comparison', description: 'Compare insurance options', complexity: 'intermediate', requiredData: ['needs', 'quotes'], outputTypes: ['comparison'] },
      { name: 'Claims Assistance', description: 'Guide through claims process', complexity: 'intermediate', requiredData: ['policy', 'incident'], outputTypes: ['claims_guide'] },
      { name: 'Premium Optimization', description: 'Find ways to reduce premiums', complexity: 'intermediate', requiredData: ['policies', 'profile'], outputTypes: ['recommendations'] },
    ],
  },
  {
    id: 'fin_bills',
    name: 'Bill Manager',
    domain: 'financial',
    specializations: ['bill tracking', 'payment scheduling', 'subscription management', 'negotiation'],
    capabilities: [
      { name: 'Bill Tracking', description: 'Track all recurring bills', complexity: 'basic', requiredData: ['bills'], outputTypes: ['bill_calendar'] },
      { name: 'Payment Scheduling', description: 'Optimize payment timing', complexity: 'intermediate', requiredData: ['bills', 'cash_flow'], outputTypes: ['payment_schedule'] },
      { name: 'Subscription Audit', description: 'Review all subscriptions', complexity: 'basic', requiredData: ['subscriptions'], outputTypes: ['subscription_report'] },
      { name: 'Bill Negotiation', description: 'Strategies to lower bills', complexity: 'advanced', requiredData: ['bills', 'history'], outputTypes: ['negotiation_scripts'] },
    ],
  },
  {
    id: 'fin_estate',
    name: 'Estate Planner',
    domain: 'financial',
    specializations: ['estate planning', 'wills', 'trusts', 'inheritance'],
    capabilities: [
      { name: 'Estate Overview', description: 'Create estate inventory', complexity: 'intermediate', requiredData: ['assets', 'liabilities'], outputTypes: ['estate_report'] },
      { name: 'Will Guidance', description: 'Guide will creation', complexity: 'advanced', requiredData: ['family', 'assets', 'wishes'], outputTypes: ['will_outline'] },
      { name: 'Trust Analysis', description: 'Evaluate trust options', complexity: 'expert', requiredData: ['estate', 'goals'], outputTypes: ['trust_recommendations'] },
      { name: 'Beneficiary Review', description: 'Review beneficiary designations', complexity: 'intermediate', requiredData: ['accounts', 'policies'], outputTypes: ['beneficiary_report'] },
    ],
  },
  {
    id: 'fin_fraud',
    name: 'Fraud Protector',
    domain: 'financial',
    specializations: ['fraud detection', 'identity protection', 'security monitoring', 'recovery'],
    capabilities: [
      { name: 'Transaction Monitoring', description: 'Monitor for suspicious activity', complexity: 'advanced', requiredData: ['transactions', 'patterns'], outputTypes: ['alerts'] },
      { name: 'Identity Protection', description: 'Protect against identity theft', complexity: 'intermediate', requiredData: ['personal_info'], outputTypes: ['protection_plan'] },
      { name: 'Fraud Response', description: 'Guide fraud recovery', complexity: 'advanced', requiredData: ['incident'], outputTypes: ['recovery_plan'] },
      { name: 'Security Audit', description: 'Audit financial security', complexity: 'intermediate', requiredData: ['accounts', 'practices'], outputTypes: ['security_report'] },
    ],
  },

  // =========================================================================
  // HEALTH AGENTS (9-16)
  // =========================================================================
  {
    id: 'health_primary',
    name: 'Health Coordinator',
    domain: 'health',
    specializations: ['health tracking', 'appointments', 'medical records', 'preventive care'],
    capabilities: [
      { name: 'Health Dashboard', description: 'Unified health overview', complexity: 'intermediate', requiredData: ['health_data'], outputTypes: ['dashboard'] },
      { name: 'Appointment Management', description: 'Manage medical appointments', complexity: 'basic', requiredData: ['appointments', 'providers'], outputTypes: ['schedule'] },
      { name: 'Preventive Care', description: 'Track preventive care needs', complexity: 'intermediate', requiredData: ['age', 'gender', 'history'], outputTypes: ['care_schedule'] },
      { name: 'Medical Records', description: 'Organize medical records', complexity: 'intermediate', requiredData: ['records'], outputTypes: ['organized_records'] },
    ],
  },
  {
    id: 'health_nutrition',
    name: 'Nutrition Expert',
    domain: 'health',
    specializations: ['nutrition', 'meal planning', 'dietary needs', 'supplements'],
    capabilities: [
      { name: 'Meal Planning', description: 'Create personalized meal plans', complexity: 'intermediate', requiredData: ['preferences', 'restrictions', 'goals'], outputTypes: ['meal_plan'] },
      { name: 'Nutrition Analysis', description: 'Analyze nutritional intake', complexity: 'intermediate', requiredData: ['food_log'], outputTypes: ['nutrition_report'] },
      { name: 'Dietary Guidance', description: 'Guidance for special diets', complexity: 'advanced', requiredData: ['conditions', 'restrictions'], outputTypes: ['diet_plan'] },
      { name: 'Supplement Review', description: 'Review supplement needs', complexity: 'intermediate', requiredData: ['diet', 'health'], outputTypes: ['supplement_recommendations'] },
    ],
  },
  {
    id: 'health_fitness',
    name: 'Fitness Coach',
    domain: 'health',
    specializations: ['exercise', 'workout planning', 'activity tracking', 'recovery'],
    capabilities: [
      { name: 'Workout Planning', description: 'Create personalized workouts', complexity: 'intermediate', requiredData: ['fitness_level', 'goals', 'equipment'], outputTypes: ['workout_plan'] },
      { name: 'Activity Tracking', description: 'Track physical activity', complexity: 'basic', requiredData: ['activity_data'], outputTypes: ['activity_report'] },
      { name: 'Progress Analysis', description: 'Analyze fitness progress', complexity: 'intermediate', requiredData: ['history', 'goals'], outputTypes: ['progress_report'] },
      { name: 'Recovery Planning', description: 'Plan recovery and rest', complexity: 'intermediate', requiredData: ['activity', 'sleep'], outputTypes: ['recovery_plan'] },
    ],
  },
  {
    id: 'health_mental',
    name: 'Mental Wellness Guide',
    domain: 'health',
    specializations: ['mental health', 'stress management', 'mindfulness', 'emotional support'],
    capabilities: [
      { name: 'Mood Tracking', description: 'Track mood patterns', complexity: 'basic', requiredData: ['mood_entries'], outputTypes: ['mood_report'] },
      { name: 'Stress Management', description: 'Stress reduction strategies', complexity: 'intermediate', requiredData: ['stress_factors'], outputTypes: ['stress_plan'] },
      { name: 'Mindfulness Guidance', description: 'Guide mindfulness practice', complexity: 'intermediate', requiredData: ['preferences'], outputTypes: ['mindfulness_program'] },
      { name: 'Resource Connection', description: 'Connect to mental health resources', complexity: 'intermediate', requiredData: ['needs', 'location'], outputTypes: ['resource_list'] },
    ],
  },
  {
    id: 'health_sleep',
    name: 'Sleep Specialist',
    domain: 'health',
    specializations: ['sleep optimization', 'sleep tracking', 'circadian rhythm', 'sleep disorders'],
    capabilities: [
      { name: 'Sleep Analysis', description: 'Analyze sleep patterns', complexity: 'intermediate', requiredData: ['sleep_data'], outputTypes: ['sleep_report'] },
      { name: 'Sleep Optimization', description: 'Optimize sleep quality', complexity: 'intermediate', requiredData: ['sleep_data', 'lifestyle'], outputTypes: ['optimization_plan'] },
      { name: 'Routine Creation', description: 'Create bedtime routine', complexity: 'basic', requiredData: ['schedule', 'preferences'], outputTypes: ['routine'] },
      { name: 'Environment Assessment', description: 'Assess sleep environment', complexity: 'intermediate', requiredData: ['bedroom_info'], outputTypes: ['environment_recommendations'] },
    ],
  },
  {
    id: 'health_medication',
    name: 'Medication Manager',
    domain: 'health',
    specializations: ['medication tracking', 'interactions', 'reminders', 'refills'],
    capabilities: [
      { name: 'Medication Tracking', description: 'Track all medications', complexity: 'basic', requiredData: ['medications'], outputTypes: ['medication_list'] },
      { name: 'Interaction Check', description: 'Check drug interactions', complexity: 'advanced', requiredData: ['medications', 'supplements'], outputTypes: ['interaction_report'] },
      { name: 'Reminder System', description: 'Set medication reminders', complexity: 'basic', requiredData: ['schedule'], outputTypes: ['reminders'] },
      { name: 'Refill Management', description: 'Manage prescription refills', complexity: 'intermediate', requiredData: ['prescriptions'], outputTypes: ['refill_schedule'] },
    ],
  },
  {
    id: 'health_pediatric',
    name: 'Pediatric Care Guide',
    domain: 'health',
    specializations: ['child health', 'development', 'vaccinations', 'pediatric care'],
    capabilities: [
      { name: 'Development Tracking', description: 'Track child development', complexity: 'intermediate', requiredData: ['age', 'milestones'], outputTypes: ['development_report'] },
      { name: 'Vaccination Schedule', description: 'Manage vaccination schedule', complexity: 'intermediate', requiredData: ['age', 'history'], outputTypes: ['vaccine_schedule'] },
      { name: 'Growth Monitoring', description: 'Monitor growth patterns', complexity: 'intermediate', requiredData: ['measurements'], outputTypes: ['growth_chart'] },
      { name: 'Illness Guidance', description: 'Guidance for common illnesses', complexity: 'intermediate', requiredData: ['symptoms'], outputTypes: ['care_guidance'] },
    ],
  },
  {
    id: 'health_senior',
    name: 'Senior Care Specialist',
    domain: 'health',
    specializations: ['elderly care', 'aging in place', 'cognitive health', 'mobility'],
    capabilities: [
      { name: 'Care Coordination', description: 'Coordinate senior care', complexity: 'advanced', requiredData: ['needs', 'providers'], outputTypes: ['care_plan'] },
      { name: 'Safety Assessment', description: 'Assess home safety for seniors', complexity: 'intermediate', requiredData: ['home_info', 'mobility'], outputTypes: ['safety_report'] },
      { name: 'Cognitive Monitoring', description: 'Monitor cognitive health', complexity: 'advanced', requiredData: ['assessments'], outputTypes: ['cognitive_report'] },
      { name: 'Caregiver Support', description: 'Support for caregivers', complexity: 'intermediate', requiredData: ['caregiver_needs'], outputTypes: ['support_resources'] },
    ],
  },

  // =========================================================================
  // HOME AGENTS (17-24)
  // =========================================================================
  {
    id: 'home_maintenance',
    name: 'Home Maintenance Expert',
    domain: 'home',
    specializations: ['maintenance scheduling', 'repairs', 'seasonal tasks', 'contractors'],
    capabilities: [
      { name: 'Maintenance Schedule', description: 'Create maintenance calendar', complexity: 'intermediate', requiredData: ['home_info', 'systems'], outputTypes: ['maintenance_schedule'] },
      { name: 'Repair Guidance', description: 'DIY repair instructions', complexity: 'intermediate', requiredData: ['issue'], outputTypes: ['repair_guide'] },
      { name: 'Contractor Finding', description: 'Find qualified contractors', complexity: 'intermediate', requiredData: ['service_needed', 'location'], outputTypes: ['contractor_list'] },
      { name: 'Cost Estimation', description: 'Estimate repair costs', complexity: 'intermediate', requiredData: ['repair_type'], outputTypes: ['cost_estimate'] },
    ],
  },
  {
    id: 'home_cleaning',
    name: 'Cleaning Coordinator',
    domain: 'home',
    specializations: ['cleaning schedules', 'deep cleaning', 'organization', 'supplies'],
    capabilities: [
      { name: 'Cleaning Schedule', description: 'Create cleaning routine', complexity: 'basic', requiredData: ['home_size', 'preferences'], outputTypes: ['cleaning_schedule'] },
      { name: 'Deep Clean Planning', description: 'Plan deep cleaning sessions', complexity: 'intermediate', requiredData: ['areas', 'frequency'], outputTypes: ['deep_clean_plan'] },
      { name: 'Organization Tips', description: 'Home organization strategies', complexity: 'intermediate', requiredData: ['problem_areas'], outputTypes: ['organization_plan'] },
      { name: 'Supply Management', description: 'Manage cleaning supplies', complexity: 'basic', requiredData: ['inventory'], outputTypes: ['supply_list'] },
    ],
  },
  {
    id: 'home_energy',
    name: 'Energy Efficiency Expert',
    domain: 'home',
    specializations: ['energy savings', 'utility optimization', 'smart home', 'sustainability'],
    capabilities: [
      { name: 'Energy Audit', description: 'Analyze energy usage', complexity: 'intermediate', requiredData: ['utility_data', 'home_info'], outputTypes: ['energy_report'] },
      { name: 'Savings Recommendations', description: 'Identify energy savings', complexity: 'intermediate', requiredData: ['usage_patterns'], outputTypes: ['savings_plan'] },
      { name: 'Smart Home Optimization', description: 'Optimize smart devices', complexity: 'advanced', requiredData: ['devices', 'preferences'], outputTypes: ['automation_plan'] },
      { name: 'Solar Analysis', description: 'Evaluate solar potential', complexity: 'advanced', requiredData: ['location', 'usage'], outputTypes: ['solar_report'] },
    ],
  },
  {
    id: 'home_security',
    name: 'Home Security Advisor',
    domain: 'home',
    specializations: ['security systems', 'monitoring', 'access control', 'safety'],
    capabilities: [
      { name: 'Security Assessment', description: 'Assess home security', complexity: 'intermediate', requiredData: ['home_info', 'current_security'], outputTypes: ['security_report'] },
      { name: 'System Recommendations', description: 'Recommend security systems', complexity: 'intermediate', requiredData: ['needs', 'budget'], outputTypes: ['system_recommendations'] },
      { name: 'Monitoring Setup', description: 'Configure monitoring', complexity: 'intermediate', requiredData: ['devices'], outputTypes: ['monitoring_plan'] },
      { name: 'Emergency Planning', description: 'Create emergency plans', complexity: 'intermediate', requiredData: ['family', 'home'], outputTypes: ['emergency_plan'] },
    ],
  },
  {
    id: 'home_garden',
    name: 'Garden & Landscape Expert',
    domain: 'home',
    specializations: ['gardening', 'landscaping', 'lawn care', 'outdoor spaces'],
    capabilities: [
      { name: 'Garden Planning', description: 'Plan garden layout', complexity: 'intermediate', requiredData: ['space', 'climate', 'preferences'], outputTypes: ['garden_plan'] },
      { name: 'Plant Care', description: 'Plant care guidance', complexity: 'intermediate', requiredData: ['plants'], outputTypes: ['care_schedule'] },
      { name: 'Lawn Maintenance', description: 'Lawn care schedule', complexity: 'basic', requiredData: ['lawn_type', 'climate'], outputTypes: ['lawn_schedule'] },
      { name: 'Seasonal Tasks', description: 'Seasonal outdoor tasks', complexity: 'intermediate', requiredData: ['season', 'property'], outputTypes: ['task_list'] },
    ],
  },
  {
    id: 'home_renovation',
    name: 'Renovation Planner',
    domain: 'home',
    specializations: ['renovations', 'remodeling', 'permits', 'project management'],
    capabilities: [
      { name: 'Project Planning', description: 'Plan renovation projects', complexity: 'advanced', requiredData: ['project_scope', 'budget'], outputTypes: ['project_plan'] },
      { name: 'Budget Estimation', description: 'Estimate renovation costs', complexity: 'advanced', requiredData: ['project_details'], outputTypes: ['budget_estimate'] },
      { name: 'Contractor Management', description: 'Manage contractors', complexity: 'intermediate', requiredData: ['project', 'contractors'], outputTypes: ['management_plan'] },
      { name: 'Permit Guidance', description: 'Navigate permit requirements', complexity: 'advanced', requiredData: ['project', 'location'], outputTypes: ['permit_guide'] },
    ],
  },
  {
    id: 'home_inventory',
    name: 'Home Inventory Manager',
    domain: 'home',
    specializations: ['inventory tracking', 'warranties', 'valuables', 'insurance documentation'],
    capabilities: [
      { name: 'Inventory Tracking', description: 'Track home inventory', complexity: 'intermediate', requiredData: ['items'], outputTypes: ['inventory_list'] },
      { name: 'Warranty Management', description: 'Track warranties', complexity: 'basic', requiredData: ['purchases'], outputTypes: ['warranty_tracker'] },
      { name: 'Valuation', description: 'Estimate item values', complexity: 'intermediate', requiredData: ['items'], outputTypes: ['valuation_report'] },
      { name: 'Insurance Documentation', description: 'Document for insurance', complexity: 'intermediate', requiredData: ['inventory'], outputTypes: ['insurance_docs'] },
    ],
  },
  {
    id: 'home_moving',
    name: 'Moving Coordinator',
    domain: 'home',
    specializations: ['moving planning', 'packing', 'logistics', 'settling in'],
    capabilities: [
      { name: 'Move Planning', description: 'Plan entire move', complexity: 'advanced', requiredData: ['origin', 'destination', 'timeline'], outputTypes: ['move_plan'] },
      { name: 'Packing Guide', description: 'Create packing strategy', complexity: 'intermediate', requiredData: ['inventory', 'timeline'], outputTypes: ['packing_plan'] },
      { name: 'Service Transfer', description: 'Transfer utilities and services', complexity: 'intermediate', requiredData: ['services', 'addresses'], outputTypes: ['transfer_checklist'] },
      { name: 'Settling In', description: 'New home setup guide', complexity: 'intermediate', requiredData: ['new_home'], outputTypes: ['setup_guide'] },
    ],
  },

  // =========================================================================
  // FAMILY AGENTS (25-30)
  // =========================================================================
  {
    id: 'family_calendar',
    name: 'Family Calendar Coordinator',
    domain: 'family',
    specializations: ['scheduling', 'coordination', 'conflicts', 'family events'],
    capabilities: [
      { name: 'Schedule Coordination', description: 'Coordinate family schedules', complexity: 'intermediate', requiredData: ['calendars'], outputTypes: ['unified_calendar'] },
      { name: 'Conflict Resolution', description: 'Resolve scheduling conflicts', complexity: 'intermediate', requiredData: ['conflicts'], outputTypes: ['resolution_options'] },
      { name: 'Event Planning', description: 'Plan family events', complexity: 'intermediate', requiredData: ['event_type', 'participants'], outputTypes: ['event_plan'] },
      { name: 'Activity Suggestions', description: 'Suggest family activities', complexity: 'basic', requiredData: ['preferences', 'availability'], outputTypes: ['activity_list'] },
    ],
  },
  {
    id: 'family_childcare',
    name: 'Childcare Coordinator',
    domain: 'family',
    specializations: ['childcare', 'babysitting', 'activities', 'education'],
    capabilities: [
      { name: 'Childcare Management', description: 'Manage childcare arrangements', complexity: 'intermediate', requiredData: ['children', 'schedule'], outputTypes: ['childcare_plan'] },
      { name: 'Activity Planning', description: 'Plan children\'s activities', complexity: 'intermediate', requiredData: ['ages', 'interests'], outputTypes: ['activity_schedule'] },
      { name: 'School Coordination', description: 'Coordinate school activities', complexity: 'intermediate', requiredData: ['school_info'], outputTypes: ['school_calendar'] },
      { name: 'Homework Help', description: 'Homework assistance strategies', complexity: 'intermediate', requiredData: ['subjects', 'level'], outputTypes: ['homework_plan'] },
    ],
  },
  {
    id: 'family_pet',
    name: 'Pet Care Specialist',
    domain: 'family',
    specializations: ['pet care', 'veterinary', 'training', 'nutrition'],
    capabilities: [
      { name: 'Care Schedule', description: 'Create pet care routine', complexity: 'basic', requiredData: ['pets'], outputTypes: ['care_schedule'] },
      { name: 'Vet Management', description: 'Manage vet appointments', complexity: 'basic', requiredData: ['pets', 'vet_info'], outputTypes: ['vet_schedule'] },
      { name: 'Training Guidance', description: 'Pet training tips', complexity: 'intermediate', requiredData: ['pet_type', 'issues'], outputTypes: ['training_plan'] },
      { name: 'Nutrition Planning', description: 'Plan pet nutrition', complexity: 'intermediate', requiredData: ['pet_info'], outputTypes: ['nutrition_plan'] },
    ],
  },
  {
    id: 'family_elder',
    name: 'Elder Care Coordinator',
    domain: 'family',
    specializations: ['elder care', 'assisted living', 'family support', 'medical coordination'],
    capabilities: [
      { name: 'Care Planning', description: 'Plan elder care', complexity: 'advanced', requiredData: ['elder_needs', 'family_resources'], outputTypes: ['care_plan'] },
      { name: 'Facility Research', description: 'Research care facilities', complexity: 'intermediate', requiredData: ['needs', 'location', 'budget'], outputTypes: ['facility_list'] },
      { name: 'Family Coordination', description: 'Coordinate family caregiving', complexity: 'intermediate', requiredData: ['family_members', 'schedule'], outputTypes: ['coordination_plan'] },
      { name: 'Resource Finding', description: 'Find elder care resources', complexity: 'intermediate', requiredData: ['needs', 'location'], outputTypes: ['resource_list'] },
    ],
  },
  {
    id: 'family_relationship',
    name: 'Relationship Advisor',
    domain: 'family',
    specializations: ['relationships', 'communication', 'conflict resolution', 'bonding'],
    capabilities: [
      { name: 'Communication Tips', description: 'Improve family communication', complexity: 'intermediate', requiredData: ['family_dynamics'], outputTypes: ['communication_guide'] },
      { name: 'Conflict Mediation', description: 'Help resolve conflicts', complexity: 'advanced', requiredData: ['conflict_details'], outputTypes: ['mediation_approach'] },
      { name: 'Bonding Activities', description: 'Suggest bonding activities', complexity: 'basic', requiredData: ['family_members'], outputTypes: ['activity_suggestions'] },
      { name: 'Milestone Recognition', description: 'Track family milestones', complexity: 'basic', requiredData: ['family_info'], outputTypes: ['milestone_calendar'] },
    ],
  },
  {
    id: 'family_meal',
    name: 'Family Meal Planner',
    domain: 'family',
    specializations: ['meal planning', 'grocery shopping', 'dietary needs', 'cooking'],
    capabilities: [
      { name: 'Meal Planning', description: 'Plan family meals', complexity: 'intermediate', requiredData: ['preferences', 'restrictions', 'budget'], outputTypes: ['meal_plan'] },
      { name: 'Grocery Lists', description: 'Create shopping lists', complexity: 'basic', requiredData: ['meal_plan'], outputTypes: ['grocery_list'] },
      { name: 'Recipe Suggestions', description: 'Suggest recipes', complexity: 'basic', requiredData: ['ingredients', 'preferences'], outputTypes: ['recipe_list'] },
      { name: 'Batch Cooking', description: 'Plan batch cooking', complexity: 'intermediate', requiredData: ['schedule', 'storage'], outputTypes: ['batch_plan'] },
    ],
  },

  // =========================================================================
  // CAREER & EDUCATION AGENTS (31-35)
  // =========================================================================
  {
    id: 'career_development',
    name: 'Career Development Coach',
    domain: 'career',
    specializations: ['career planning', 'skill development', 'job search', 'networking'],
    capabilities: [
      { name: 'Career Planning', description: 'Create career roadmap', complexity: 'advanced', requiredData: ['current_role', 'goals'], outputTypes: ['career_plan'] },
      { name: 'Skill Assessment', description: 'Assess and develop skills', complexity: 'intermediate', requiredData: ['skills', 'goals'], outputTypes: ['skill_plan'] },
      { name: 'Job Search Strategy', description: 'Optimize job search', complexity: 'intermediate', requiredData: ['target_roles', 'experience'], outputTypes: ['search_strategy'] },
      { name: 'Resume Review', description: 'Review and improve resume', complexity: 'intermediate', requiredData: ['resume'], outputTypes: ['resume_feedback'] },
    ],
  },
  {
    id: 'career_worklife',
    name: 'Work-Life Balance Coach',
    domain: 'career',
    specializations: ['work-life balance', 'boundaries', 'productivity', 'burnout prevention'],
    capabilities: [
      { name: 'Balance Assessment', description: 'Assess work-life balance', complexity: 'intermediate', requiredData: ['schedule', 'priorities'], outputTypes: ['balance_report'] },
      { name: 'Boundary Setting', description: 'Help set boundaries', complexity: 'intermediate', requiredData: ['work_situation'], outputTypes: ['boundary_plan'] },
      { name: 'Productivity Tips', description: 'Improve productivity', complexity: 'intermediate', requiredData: ['work_style'], outputTypes: ['productivity_plan'] },
      { name: 'Burnout Prevention', description: 'Prevent and recover from burnout', complexity: 'advanced', requiredData: ['stress_indicators'], outputTypes: ['prevention_plan'] },
    ],
  },
  {
    id: 'education_learning',
    name: 'Learning Facilitator',
    domain: 'education',
    specializations: ['learning plans', 'courses', 'certifications', 'skill building'],
    capabilities: [
      { name: 'Learning Path', description: 'Create learning roadmap', complexity: 'intermediate', requiredData: ['goals', 'current_skills'], outputTypes: ['learning_plan'] },
      { name: 'Course Recommendations', description: 'Recommend courses', complexity: 'intermediate', requiredData: ['topic', 'level'], outputTypes: ['course_list'] },
      { name: 'Certification Guidance', description: 'Guide certification pursuit', complexity: 'intermediate', requiredData: ['field', 'goals'], outputTypes: ['certification_plan'] },
      { name: 'Study Planning', description: 'Create study schedule', complexity: 'basic', requiredData: ['material', 'deadline'], outputTypes: ['study_schedule'] },
    ],
  },
  {
    id: 'education_children',
    name: 'Children\'s Education Advisor',
    domain: 'education',
    specializations: ['school selection', 'tutoring', 'enrichment', 'college prep'],
    capabilities: [
      { name: 'School Research', description: 'Research schools', complexity: 'intermediate', requiredData: ['location', 'criteria'], outputTypes: ['school_list'] },
      { name: 'Academic Support', description: 'Plan academic support', complexity: 'intermediate', requiredData: ['student_needs'], outputTypes: ['support_plan'] },
      { name: 'Enrichment Activities', description: 'Find enrichment programs', complexity: 'basic', requiredData: ['interests', 'age'], outputTypes: ['program_list'] },
      { name: 'College Planning', description: 'College preparation', complexity: 'advanced', requiredData: ['student_profile'], outputTypes: ['college_plan'] },
    ],
  },
  {
    id: 'education_financial',
    name: 'Education Finance Advisor',
    domain: 'education',
    specializations: ['education savings', 'financial aid', 'scholarships', 'student loans'],
    capabilities: [
      { name: '529 Planning', description: 'Plan education savings', complexity: 'advanced', requiredData: ['children', 'timeline'], outputTypes: ['savings_plan'] },
      { name: 'Financial Aid', description: 'Navigate financial aid', complexity: 'advanced', requiredData: ['financial_info'], outputTypes: ['aid_strategy'] },
      { name: 'Scholarship Search', description: 'Find scholarships', complexity: 'intermediate', requiredData: ['student_profile'], outputTypes: ['scholarship_list'] },
      { name: 'Loan Management', description: 'Manage student loans', complexity: 'intermediate', requiredData: ['loans'], outputTypes: ['loan_plan'] },
    ],
  },

  // =========================================================================
  // SOCIAL & LIFESTYLE AGENTS (36-40)
  // =========================================================================
  {
    id: 'social_events',
    name: 'Social Events Coordinator',
    domain: 'social',
    specializations: ['event planning', 'hosting', 'RSVPs', 'celebrations'],
    capabilities: [
      { name: 'Event Planning', description: 'Plan social events', complexity: 'intermediate', requiredData: ['event_type', 'guests', 'budget'], outputTypes: ['event_plan'] },
      { name: 'Guest Management', description: 'Manage invitations and RSVPs', complexity: 'basic', requiredData: ['guest_list'], outputTypes: ['rsvp_tracker'] },
      { name: 'Venue Finding', description: 'Find event venues', complexity: 'intermediate', requiredData: ['requirements', 'location'], outputTypes: ['venue_list'] },
      { name: 'Party Planning', description: 'Plan parties and celebrations', complexity: 'intermediate', requiredData: ['occasion', 'preferences'], outputTypes: ['party_plan'] },
    ],
  },
  {
    id: 'social_gifts',
    name: 'Gift Advisor',
    domain: 'social',
    specializations: ['gift selection', 'occasions', 'budgeting', 'personalization'],
    capabilities: [
      { name: 'Gift Suggestions', description: 'Suggest appropriate gifts', complexity: 'intermediate', requiredData: ['recipient', 'occasion', 'budget'], outputTypes: ['gift_list'] },
      { name: 'Occasion Tracking', description: 'Track gift-giving occasions', complexity: 'basic', requiredData: ['contacts'], outputTypes: ['occasion_calendar'] },
      { name: 'Gift History', description: 'Track past gifts', complexity: 'basic', requiredData: ['gift_history'], outputTypes: ['gift_tracker'] },
      { name: 'Registry Management', description: 'Manage gift registries', complexity: 'basic', requiredData: ['registries'], outputTypes: ['registry_list'] },
    ],
  },
  {
    id: 'travel_planner',
    name: 'Travel Planner',
    domain: 'travel',
    specializations: ['trip planning', 'bookings', 'itineraries', 'travel logistics'],
    capabilities: [
      { name: 'Trip Planning', description: 'Plan complete trips', complexity: 'advanced', requiredData: ['destination', 'dates', 'preferences', 'budget'], outputTypes: ['trip_plan'] },
      { name: 'Itinerary Creation', description: 'Create detailed itineraries', complexity: 'intermediate', requiredData: ['destination', 'interests'], outputTypes: ['itinerary'] },
      { name: 'Booking Assistance', description: 'Help with bookings', complexity: 'intermediate', requiredData: ['requirements'], outputTypes: ['booking_options'] },
      { name: 'Travel Documents', description: 'Manage travel documents', complexity: 'intermediate', requiredData: ['travelers', 'destination'], outputTypes: ['document_checklist'] },
    ],
  },
  {
    id: 'entertainment_curator',
    name: 'Entertainment Curator',
    domain: 'entertainment',
    specializations: ['movies', 'shows', 'music', 'books', 'games'],
    capabilities: [
      { name: 'Recommendations', description: 'Personalized entertainment recommendations', complexity: 'intermediate', requiredData: ['preferences', 'history'], outputTypes: ['recommendation_list'] },
      { name: 'Watch Lists', description: 'Manage watch/read lists', complexity: 'basic', requiredData: ['lists'], outputTypes: ['curated_list'] },
      { name: 'Event Finding', description: 'Find local entertainment events', complexity: 'intermediate', requiredData: ['location', 'interests'], outputTypes: ['event_list'] },
      { name: 'Subscription Management', description: 'Manage streaming subscriptions', complexity: 'basic', requiredData: ['subscriptions'], outputTypes: ['subscription_report'] },
    ],
  },
  {
    id: 'shopping_assistant',
    name: 'Shopping Assistant',
    domain: 'shopping',
    specializations: ['product research', 'price comparison', 'deals', 'reviews'],
    capabilities: [
      { name: 'Product Research', description: 'Research products', complexity: 'intermediate', requiredData: ['product_type', 'requirements'], outputTypes: ['product_comparison'] },
      { name: 'Price Tracking', description: 'Track prices and deals', complexity: 'intermediate', requiredData: ['products'], outputTypes: ['price_alerts'] },
      { name: 'Review Analysis', description: 'Analyze product reviews', complexity: 'intermediate', requiredData: ['product'], outputTypes: ['review_summary'] },
      { name: 'Shopping Lists', description: 'Manage shopping lists', complexity: 'basic', requiredData: ['items'], outputTypes: ['shopping_list'] },
    ],
  },

  // =========================================================================
  // TECHNOLOGY & LEGAL AGENTS (41-45)
  // =========================================================================
  {
    id: 'tech_support',
    name: 'Tech Support Specialist',
    domain: 'technology',
    specializations: ['troubleshooting', 'setup', 'security', 'optimization'],
    capabilities: [
      { name: 'Troubleshooting', description: 'Diagnose tech issues', complexity: 'intermediate', requiredData: ['issue_description'], outputTypes: ['solution_steps'] },
      { name: 'Device Setup', description: 'Guide device setup', complexity: 'basic', requiredData: ['device_type'], outputTypes: ['setup_guide'] },
      { name: 'Security Setup', description: 'Configure security settings', complexity: 'intermediate', requiredData: ['devices'], outputTypes: ['security_guide'] },
      { name: 'Performance Optimization', description: 'Optimize device performance', complexity: 'intermediate', requiredData: ['device_info'], outputTypes: ['optimization_tips'] },
    ],
  },
  {
    id: 'tech_smart_home',
    name: 'Smart Home Expert',
    domain: 'technology',
    specializations: ['smart devices', 'automation', 'integration', 'voice assistants'],
    capabilities: [
      { name: 'Device Integration', description: 'Integrate smart devices', complexity: 'intermediate', requiredData: ['devices'], outputTypes: ['integration_plan'] },
      { name: 'Automation Setup', description: 'Create automations', complexity: 'intermediate', requiredData: ['devices', 'scenarios'], outputTypes: ['automation_rules'] },
      { name: 'Voice Control', description: 'Set up voice control', complexity: 'intermediate', requiredData: ['assistant', 'devices'], outputTypes: ['voice_commands'] },
      { name: 'Troubleshooting', description: 'Fix smart home issues', complexity: 'intermediate', requiredData: ['issue'], outputTypes: ['solution'] },
    ],
  },
  {
    id: 'legal_general',
    name: 'Legal Information Guide',
    domain: 'legal',
    specializations: ['legal information', 'documents', 'rights', 'procedures'],
    capabilities: [
      { name: 'Legal Information', description: 'Provide legal information', complexity: 'intermediate', requiredData: ['topic'], outputTypes: ['legal_info'] },
      { name: 'Document Templates', description: 'Provide document templates', complexity: 'intermediate', requiredData: ['document_type'], outputTypes: ['template'] },
      { name: 'Rights Information', description: 'Explain legal rights', complexity: 'intermediate', requiredData: ['situation'], outputTypes: ['rights_info'] },
      { name: 'Attorney Finding', description: 'Help find attorneys', complexity: 'intermediate', requiredData: ['specialty', 'location'], outputTypes: ['attorney_list'] },
    ],
  },
  {
    id: 'legal_contracts',
    name: 'Contract Reviewer',
    domain: 'legal',
    specializations: ['contract review', 'terms analysis', 'negotiation points'],
    capabilities: [
      { name: 'Contract Analysis', description: 'Analyze contract terms', complexity: 'advanced', requiredData: ['contract'], outputTypes: ['analysis_report'] },
      { name: 'Red Flag Detection', description: 'Identify concerning terms', complexity: 'advanced', requiredData: ['contract'], outputTypes: ['red_flags'] },
      { name: 'Negotiation Points', description: 'Suggest negotiation points', complexity: 'advanced', requiredData: ['contract', 'priorities'], outputTypes: ['negotiation_guide'] },
      { name: 'Plain Language', description: 'Explain in plain language', complexity: 'intermediate', requiredData: ['legal_text'], outputTypes: ['plain_explanation'] },
    ],
  },
  {
    id: 'communication_manager',
    name: 'Communication Manager',
    domain: 'communication',
    specializations: ['email management', 'message drafting', 'correspondence', 'templates'],
    capabilities: [
      { name: 'Email Management', description: 'Organize and prioritize emails', complexity: 'intermediate', requiredData: ['emails'], outputTypes: ['organized_inbox'] },
      { name: 'Message Drafting', description: 'Draft professional messages', complexity: 'intermediate', requiredData: ['context', 'tone'], outputTypes: ['draft'] },
      { name: 'Template Creation', description: 'Create message templates', complexity: 'basic', requiredData: ['use_case'], outputTypes: ['template'] },
      { name: 'Follow-up Tracking', description: 'Track follow-ups needed', complexity: 'basic', requiredData: ['correspondence'], outputTypes: ['follow_up_list'] },
    ],
  },

  // =========================================================================
  // EMERGENCY & PLANNING AGENTS (46-47)
  // =========================================================================
  {
    id: 'emergency_coordinator',
    name: 'Emergency Coordinator',
    domain: 'emergency',
    specializations: ['emergency planning', 'crisis response', 'safety protocols', 'recovery'],
    capabilities: [
      { name: 'Emergency Planning', description: 'Create emergency plans', complexity: 'advanced', requiredData: ['family', 'home', 'location'], outputTypes: ['emergency_plan'] },
      { name: 'Crisis Response', description: 'Guide crisis response', complexity: 'advanced', requiredData: ['emergency_type'], outputTypes: ['response_guide'] },
      { name: 'Safety Drills', description: 'Plan safety drills', complexity: 'intermediate', requiredData: ['family', 'scenarios'], outputTypes: ['drill_plan'] },
      { name: 'Recovery Planning', description: 'Plan post-emergency recovery', complexity: 'advanced', requiredData: ['emergency', 'damage'], outputTypes: ['recovery_plan'] },
    ],
  },
  {
    id: 'life_planner',
    name: 'Life Planning Advisor',
    domain: 'planning',
    specializations: ['life planning', 'goal setting', 'major decisions', 'transitions'],
    capabilities: [
      { name: 'Life Planning', description: 'Create comprehensive life plan', complexity: 'expert', requiredData: ['values', 'goals', 'situation'], outputTypes: ['life_plan'] },
      { name: 'Goal Setting', description: 'Help set meaningful goals', complexity: 'intermediate', requiredData: ['areas', 'values'], outputTypes: ['goal_framework'] },
      { name: 'Decision Support', description: 'Support major decisions', complexity: 'advanced', requiredData: ['decision', 'factors'], outputTypes: ['decision_analysis'] },
      { name: 'Transition Planning', description: 'Plan life transitions', complexity: 'advanced', requiredData: ['transition_type'], outputTypes: ['transition_plan'] },
    ],
  },
];

// ============================================================================
// COMPLETE SME AGENTS SYSTEM
// ============================================================================

export class CompleteSMEAgents extends EventEmitter {
  private agents: Map<string, SMEAgent> = new Map();
  private tasks: Map<string, AgentTask> = new Map();
  private collaborations: Map<string, AgentCollaboration> = new Map();

  constructor() {
    super();
    this.initializeAgents();
  }

  private initializeAgents(): void {
    for (const def of SME_AGENT_DEFINITIONS) {
      const agent: SMEAgent = {
        ...def,
        status: 'idle',
        currentTasks: 0,
        totalTasksCompleted: 0,
        successRate: 100,
        averageResponseTime: 0,
        lastActive: new Date(),
      };
      this.agents.set(agent.id, agent);
    }
    console.log(`[SME Agents] Initialized ${this.agents.size} specialized agents`);
  }

  // -------------------------------------------------------------------------
  // AGENT SELECTION
  // -------------------------------------------------------------------------

  findBestAgent(taskType: string, domain?: AgentDomain): SMEAgent | undefined {
    const candidates = Array.from(this.agents.values())
      .filter(a => {
        if (domain && a.domain !== domain) return false;
        return a.capabilities.some(c => 
          c.name.toLowerCase().includes(taskType.toLowerCase()) ||
          taskType.toLowerCase().includes(c.name.toLowerCase())
        );
      })
      .sort((a, b) => {
        // Prefer agents with higher success rate and lower current load
        const scoreA = a.successRate - (a.currentTasks * 10);
        const scoreB = b.successRate - (b.currentTasks * 10);
        return scoreB - scoreA;
      });

    return candidates[0];
  }

  findAgentsByDomain(domain: AgentDomain): SMEAgent[] {
    return Array.from(this.agents.values())
      .filter(a => a.domain === domain);
  }

  findAgentsByCapability(capabilityName: string): SMEAgent[] {
    return Array.from(this.agents.values())
      .filter(a => a.capabilities.some(c => 
        c.name.toLowerCase().includes(capabilityName.toLowerCase())
      ));
  }

  // -------------------------------------------------------------------------
  // TASK EXECUTION
  // -------------------------------------------------------------------------

  async executeTask(
    agentId: string,
    taskType: string,
    input: Record<string, any>,
    householdId: number,
    memberId?: number
  ): Promise<AgentTask> {
    const agent = this.agents.get(agentId);
    if (!agent) {
      throw new Error(`Agent not found: ${agentId}`);
    }

    const capability = agent.capabilities.find(c => 
      c.name.toLowerCase() === taskType.toLowerCase()
    );
    if (!capability) {
      throw new Error(`Agent ${agentId} does not have capability: ${taskType}`);
    }

    const task: AgentTask = {
      id: this.generateId('task'),
      agentId,
      type: taskType,
      input,
      status: 'pending',
      householdId,
      memberId,
    };

    this.tasks.set(task.id, task);
    agent.currentTasks++;
    agent.status = 'busy';

    // Execute the task
    task.status = 'processing';
    task.startedAt = new Date();
    this.emit('task_started', { agent, task });

    try {
      // Simulate task execution based on complexity
      const executionTime = this.getExecutionTime(capability.complexity);
      await this.delay(executionTime);

      // Generate result based on capability
      task.result = await this.generateTaskResult(agent, capability, input);
      task.status = 'completed';
      task.completedAt = new Date();

      // Update agent stats
      agent.totalTasksCompleted++;
      agent.lastActive = new Date();
      const responseTime = task.completedAt.getTime() - task.startedAt.getTime();
      agent.averageResponseTime = (agent.averageResponseTime + responseTime) / 2;

      this.emit('task_completed', { agent, task });
    } catch (error: any) {
      task.status = 'failed';
      task.error = error.message;
      task.completedAt = new Date();

      // Update success rate
      const totalTasks = agent.totalTasksCompleted + 1;
      agent.successRate = ((agent.successRate * agent.totalTasksCompleted) / totalTasks);

      this.emit('task_failed', { agent, task, error });
    } finally {
      agent.currentTasks--;
      if (agent.currentTasks === 0) {
        agent.status = 'idle';
      }
    }

    return task;
  }

  private getExecutionTime(complexity: string): number {
    const times: Record<string, number> = {
      basic: 100,
      intermediate: 250,
      advanced: 500,
      expert: 1000,
    };
    return times[complexity] || 250;
  }

  private async generateTaskResult(
    agent: SMEAgent,
    capability: AgentCapability,
    input: Record<string, any>
  ): Promise<any> {
    // Generate appropriate result based on agent domain and capability
    const resultGenerators: Record<string, () => any> = {
      'Budget Master': () => ({
        budget: {
          income: input.income || 5000,
          expenses: input.expenses || 3500,
          savings: (input.income || 5000) - (input.expenses || 3500),
          categories: [
            { name: 'Housing', amount: 1500, percentage: 43 },
            { name: 'Food', amount: 600, percentage: 17 },
            { name: 'Transportation', amount: 400, percentage: 11 },
            { name: 'Utilities', amount: 200, percentage: 6 },
            { name: 'Other', amount: 800, percentage: 23 },
          ],
        },
        recommendations: [
          'Consider reducing dining out expenses',
          'Look into refinancing options for housing',
          'Set up automatic savings transfers',
        ],
      }),
      'Health Coordinator': () => ({
        healthSummary: {
          overallScore: 75,
          areas: [
            { name: 'Physical', score: 70 },
            { name: 'Mental', score: 80 },
            { name: 'Sleep', score: 65 },
            { name: 'Nutrition', score: 85 },
          ],
        },
        upcomingAppointments: [],
        preventiveCareNeeded: ['Annual physical', 'Dental cleaning'],
      }),
      'Home Maintenance Expert': () => ({
        maintenanceSchedule: [
          { task: 'HVAC filter change', frequency: 'Monthly', nextDue: new Date() },
          { task: 'Gutter cleaning', frequency: 'Bi-annual', nextDue: new Date() },
          { task: 'Smoke detector test', frequency: 'Monthly', nextDue: new Date() },
        ],
        urgentItems: [],
        estimatedAnnualCost: 2500,
      }),
      'Family Calendar Coordinator': () => ({
        unifiedSchedule: {
          today: [],
          thisWeek: [],
          conflicts: [],
        },
        suggestions: [
          'Schedule family dinner for Sunday',
          'Block time for homework help',
        ],
      }),
    };

    const generator = resultGenerators[agent.name];
    if (generator) {
      return generator();
    }

    // Default result structure
    return {
      success: true,
      agentId: agent.id,
      capability: capability.name,
      analysis: `Analysis completed by ${agent.name}`,
      recommendations: ['Recommendation 1', 'Recommendation 2'],
      data: input,
      timestamp: new Date(),
    };
  }

  // -------------------------------------------------------------------------
  // AGENT COLLABORATION
  // -------------------------------------------------------------------------

  async initiateCollaboration(
    taskDescription: string,
    primaryAgentId: string,
    collaboratorIds: string[],
    householdId: number
  ): Promise<AgentCollaboration> {
    const collaboration: AgentCollaboration = {
      id: this.generateId('collab'),
      primaryAgentId,
      collaboratingAgentIds: collaboratorIds,
      task: taskDescription,
      status: 'active',
      contributions: new Map(),
    };

    this.collaborations.set(collaboration.id, collaboration);
    this.emit('collaboration_started', collaboration);

    // Execute tasks for each collaborating agent
    const allAgentIds = [primaryAgentId, ...collaboratorIds];
    const results = await Promise.all(
      allAgentIds.map(async (agentId) => {
        const agent = this.agents.get(agentId);
        if (!agent) return null;

        const task = await this.executeTask(
          agentId,
          'Collaboration Contribution',
          { task: taskDescription },
          householdId
        );

        collaboration.contributions.set(agentId, task.result);
        return task;
      })
    );

    // Synthesize final result
    collaboration.finalResult = this.synthesizeCollaborationResults(collaboration);
    collaboration.status = 'completed';

    this.emit('collaboration_completed', collaboration);
    return collaboration;
  }

  private synthesizeCollaborationResults(collaboration: AgentCollaboration): any {
    const contributions = Array.from(collaboration.contributions.entries());
    
    return {
      task: collaboration.task,
      contributingAgents: contributions.map(([id]) => id),
      synthesizedResult: {
        summary: `Collaborative analysis completed by ${contributions.length} agents`,
        insights: contributions.map(([id, result]) => ({
          agent: id,
          contribution: result,
        })),
        recommendations: [
          'Combined recommendation based on multi-agent analysis',
        ],
      },
      completedAt: new Date(),
    };
  }

  // -------------------------------------------------------------------------
  // QUERIES
  // -------------------------------------------------------------------------

  getAllAgents(): SMEAgent[] {
    return Array.from(this.agents.values());
  }

  getAgentById(agentId: string): SMEAgent | undefined {
    return this.agents.get(agentId);
  }

  getAgentsByStatus(status: SMEAgent['status']): SMEAgent[] {
    return Array.from(this.agents.values())
      .filter(a => a.status === status);
  }

  getTaskHistory(householdId: number, limit: number = 50): AgentTask[] {
    return Array.from(this.tasks.values())
      .filter(t => t.householdId === householdId)
      .sort((a, b) => {
        const timeA = a.completedAt?.getTime() || a.startedAt?.getTime() || 0;
        const timeB = b.completedAt?.getTime() || b.startedAt?.getTime() || 0;
        return timeB - timeA;
      })
      .slice(0, limit);
  }

  getAgentStats(): {
    total: number;
    byDomain: Record<AgentDomain, number>;
    byStatus: Record<SMEAgent['status'], number>;
    totalTasksCompleted: number;
    averageSuccessRate: number;
  } {
    const agents = Array.from(this.agents.values());
    
    const byDomain: Record<string, number> = {};
    const byStatus: Record<string, number> = { active: 0, idle: 0, busy: 0, offline: 0 };
    let totalTasks = 0;
    let totalSuccessRate = 0;

    for (const agent of agents) {
      byDomain[agent.domain] = (byDomain[agent.domain] || 0) + 1;
      byStatus[agent.status]++;
      totalTasks += agent.totalTasksCompleted;
      totalSuccessRate += agent.successRate;
    }

    return {
      total: agents.length,
      byDomain: byDomain as Record<AgentDomain, number>,
      byStatus: byStatus as Record<SMEAgent['status'], number>,
      totalTasksCompleted: totalTasks,
      averageSuccessRate: agents.length > 0 ? totalSuccessRate / agents.length : 0,
    };
  }

  // -------------------------------------------------------------------------
  // HELPERS
  // -------------------------------------------------------------------------

  private generateId(prefix: string): string {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

export const completeSMEAgents = new CompleteSMEAgents();
