import { getDb } from "../db";
import { entities, relationships, InsertEntity, InsertRelationship, Entity, Relationship } from "../../drizzle/schema";
import { eq, and, or, like, desc } from "drizzle-orm";
import { EventBus } from "./EventBus";
import { LLMService } from "./LLMService";

/**
 * Entity with relationships
 */
export interface EntityWithRelationships extends Entity {
  outgoingRelationships: Array<Relationship & { targetEntity: Entity }>;
  incomingRelationships: Array<Relationship & { sourceEntity: Entity }>;
}

/**
 * Knowledge Graph Service
 * 
 * This service provides:
 * - Entity extraction from text
 * - Relationship mapping between entities
 * - Temporal tracking (past, present, future)
 * - Pattern discovery
 * - Fragment connection
 */
class KnowledgeGraphService {
  /**
   * Extract entities from text and store in knowledge graph
   */
  async extractAndStore(params: {
    text: string;
    userId?: number;
    sourceEventId?: number;
    context?: string;
  }): Promise<Entity[]> {
    const { text, userId, sourceEventId, context } = params;

    // Use LLM to extract entities
    const extractedEntities = await LLMService.extractEntities(text);

    if (extractedEntities.length === 0) {
      return [];
    }

    const db = await getDb();
    if (!db) {
      console.warn('[KnowledgeGraph] Database not available');
      return [];
    }

    const storedEntities: Entity[] = [];

    // Store each entity
    for (const extracted of extractedEntities) {
      try {
        // Check if entity already exists
        const existing = await db
          .select()
          .from(entities)
          .where(
            and(
              eq(entities.entityType, extracted.type),
              eq(entities.name, extracted.value)
            )
          )
          .limit(1);

        let entity: Entity;

        if (existing.length > 0) {
          // Update existing entity
          entity = existing[0];
          await db
            .update(entities)
            .set({
              properties: {
                ...entity.properties as Record<string, unknown>,
                lastMentioned: new Date().toISOString(),
                mentionCount: ((entity.properties as any)?.mentionCount || 0) + 1,
                context: extracted.context || context,
              },
              updatedAt: new Date(),
            })
            .where(eq(entities.id, entity.id));
        } else {
          // Create new entity
          await db.insert(entities).values({
            entityType: extracted.type,
            name: extracted.value,
            properties: {
              context: extracted.context || context,
              firstMentioned: new Date().toISOString(),
              mentionCount: 1,
            },
            confidence: 80, // Default confidence
            sourceEventId,
          });

          // Fetch the created entity
          const created = await db
            .select()
            .from(entities)
            .where(
              and(
                eq(entities.entityType, extracted.type),
                eq(entities.name, extracted.value)
              )
            )
            .orderBy(desc(entities.id))
            .limit(1);

          entity = created[0];
        }

        storedEntities.push(entity);
      } catch (error) {
        console.error('[KnowledgeGraph] Error storing entity:', error);
      }
    }

    // Publish event
    await EventBus.publish({
      type: 'knowledge.entities_extracted',
      source: 'KnowledgeGraph',
      target: '*',
      data: {
        text,
        entityCount: storedEntities.length,
        entities: storedEntities,
      },
    });

    return storedEntities;
  }

  /**
   * Create a relationship between two entities
   */
  async createRelationship(params: {
    sourceEntityId: number;
    targetEntityId: number;
    relationshipType: string;
    properties?: Record<string, unknown>;
    confidence?: number;
  }): Promise<Relationship | null> {
    const { sourceEntityId, targetEntityId, relationshipType, properties, confidence } = params;

    const db = await getDb();
    if (!db) return null;

    try {
      // Check if relationship already exists
      const existing = await db
        .select()
        .from(relationships)
        .where(
          and(
            eq(relationships.sourceEntityId, sourceEntityId),
            eq(relationships.targetEntityId, targetEntityId),
            eq(relationships.relationshipType, relationshipType)
          )
        )
        .limit(1);

      if (existing.length > 0) {
        // Update existing relationship
        await db
          .update(relationships)
          .set({
            properties: {
              ...existing[0].properties as Record<string, unknown>,
              ...properties,
              lastUpdated: new Date().toISOString(),
            },
            confidence: confidence || existing[0].confidence,
          })
          .where(eq(relationships.id, existing[0].id));

        return existing[0];
      }

      // Create new relationship
      await db.insert(relationships).values({
        sourceEntityId,
        targetEntityId,
        relationshipType,
        properties: {
          ...properties,
          created: new Date().toISOString(),
        },
        confidence: confidence || 100,
      });

      // Fetch the created relationship
      const created = await db
        .select()
        .from(relationships)
        .where(
          and(
            eq(relationships.sourceEntityId, sourceEntityId),
            eq(relationships.targetEntityId, targetEntityId),
            eq(relationships.relationshipType, relationshipType)
          )
        )
        .orderBy(desc(relationships.id))
        .limit(1);

      // Publish event
      await EventBus.publish({
        type: 'knowledge.relationship_created',
        source: 'KnowledgeGraph',
        target: '*',
        data: {
          relationship: created[0],
        },
      });

      return created[0];
    } catch (error) {
      console.error('[KnowledgeGraph] Error creating relationship:', error);
      return null;
    }
  }

  /**
   * Get entity by ID with relationships
   */
  async getEntityWithRelationships(entityId: number): Promise<EntityWithRelationships | null> {
    const db = await getDb();
    if (!db) return null;

    try {
      // Get entity
      const entityResult = await db
        .select()
        .from(entities)
        .where(eq(entities.id, entityId))
        .limit(1);

      if (entityResult.length === 0) return null;

      const entity = entityResult[0];

      // Get outgoing relationships
      const outgoing = await db
        .select()
        .from(relationships)
        .where(eq(relationships.sourceEntityId, entityId));

      // Get target entities for outgoing relationships
      const outgoingWithTargets = await Promise.all(
        outgoing.map(async (rel) => {
          const target = await db
            .select()
            .from(entities)
            .where(eq(entities.id, rel.targetEntityId))
            .limit(1);
          return { ...rel, targetEntity: target[0] };
        })
      );

      // Get incoming relationships
      const incoming = await db
        .select()
        .from(relationships)
        .where(eq(relationships.targetEntityId, entityId));

      // Get source entities for incoming relationships
      const incomingWithSources = await Promise.all(
        incoming.map(async (rel) => {
          const source = await db
            .select()
            .from(entities)
            .where(eq(entities.id, rel.sourceEntityId))
            .limit(1);
          return { ...rel, sourceEntity: source[0] };
        })
      );

      return {
        ...entity,
        outgoingRelationships: outgoingWithTargets,
        incomingRelationships: incomingWithSources,
      };
    } catch (error) {
      console.error('[KnowledgeGraph] Error getting entity with relationships:', error);
      return null;
    }
  }

  /**
   * Search entities by name or type
   */
  async searchEntities(params: {
    query?: string;
    entityType?: string;
    limit?: number;
  }): Promise<Entity[]> {
    const { query, entityType, limit = 50 } = params;

    const db = await getDb();
    if (!db) return [];

    try {
      let queryBuilder = db.select().from(entities);

      const conditions = [];

      if (query) {
        conditions.push(like(entities.name, `%${query}%`));
      }

      if (entityType) {
        conditions.push(eq(entities.entityType, entityType));
      }

      if (conditions.length > 0) {
        queryBuilder = queryBuilder.where(and(...conditions)) as any;
      }

      const results = await queryBuilder
        .orderBy(desc(entities.updatedAt))
        .limit(limit);

      return results;
    } catch (error) {
      console.error('[KnowledgeGraph] Error searching entities:', error);
      return [];
    }
  }

  /**
   * Find patterns - entities that frequently appear together
   */
  async findPatterns(params: {
    entityId?: number;
    entityType?: string;
    minConfidence?: number;
  }): Promise<Array<{ entity: Entity; relationshipCount: number; relationshipTypes: string[] }>> {
    const { entityId, entityType, minConfidence = 50 } = params;

    const db = await getDb();
    if (!db) return [];

    try {
      // Get all relationships for the entity or entity type
      let relQuery = db.select().from(relationships);

      if (entityId) {
        relQuery = relQuery.where(
          or(
            eq(relationships.sourceEntityId, entityId),
            eq(relationships.targetEntityId, entityId)
          )
        ) as any;
      }

      const rels = await relQuery;

      // Count relationships per entity
      const entityCounts = new Map<number, { count: number; types: Set<string> }>();

      for (const rel of rels) {
        const otherEntityId = rel.sourceEntityId === entityId ? rel.targetEntityId : rel.sourceEntityId;

        if (!entityCounts.has(otherEntityId)) {
          entityCounts.set(otherEntityId, { count: 0, types: new Set() });
        }

        const entry = entityCounts.get(otherEntityId)!;
        entry.count++;
        entry.types.add(rel.relationshipType);
      }

      // Get entities with most relationships
      const topEntities = Array.from(entityCounts.entries())
        .sort((a, b) => b[1].count - a[1].count)
        .slice(0, 20);

      // Fetch entity details
      const patterns = await Promise.all(
        topEntities.map(async ([id, data]) => {
          const entityResult = await db
            .select()
            .from(entities)
            .where(eq(entities.id, id))
            .limit(1);

          return {
            entity: entityResult[0],
            relationshipCount: data.count,
            relationshipTypes: Array.from(data.types),
          };
        })
      );

      return patterns.filter(p => p.entity);
    } catch (error) {
      console.error('[KnowledgeGraph] Error finding patterns:', error);
      return [];
    }
  }

  /**
   * Connect fragments - find relationships between disconnected entities
   */
  async connectFragments(params: {
    entityIds: number[];
  }): Promise<Array<{ source: Entity; target: Entity; inferredRelationship: string; confidence: number }>> {
    const { entityIds } = params;

    const db = await getDb();
    if (!db) return [];

    try {
      // Get all entities
      const entitiesResult = await db
        .select()
        .from(entities)
        .where(
          or(...entityIds.map(id => eq(entities.id, id)))
        );

      // Use LLM to infer relationships
      const connections: Array<{ source: Entity; target: Entity; inferredRelationship: string; confidence: number }> = [];

      for (let i = 0; i < entitiesResult.length; i++) {
        for (let j = i + 1; j < entitiesResult.length; j++) {
          const source = entitiesResult[i];
          const target = entitiesResult[j];

          // Check if relationship already exists
          const existing = await db
            .select()
            .from(relationships)
            .where(
              or(
                and(
                  eq(relationships.sourceEntityId, source.id),
                  eq(relationships.targetEntityId, target.id)
                ),
                and(
                  eq(relationships.sourceEntityId, target.id),
                  eq(relationships.targetEntityId, source.id)
                )
              )
            )
            .limit(1);

          if (existing.length === 0) {
            // Infer relationship using LLM
            const analysis = await LLMService.analyze({
              text: `Entity 1: ${source.entityType} - ${source.name}
Entity 2: ${target.entityType} - ${target.name}

What is the likely relationship between these two entities? Consider their types and names.`,
              engineType: 'knowledge',
            });

            if (analysis.confidence > 0.5) {
              connections.push({
                source,
                target,
                inferredRelationship: analysis.response,
                confidence: analysis.confidence,
              });
            }
          }
        }
      }

      return connections;
    } catch (error) {
      console.error('[KnowledgeGraph] Error connecting fragments:', error);
      return [];
    }
  }

  /**
   * Get entity timeline - temporal view of entity mentions
   */
  async getEntityTimeline(entityId: number): Promise<Array<{ timestamp: string; context: string; eventId?: number }>> {
    const db = await getDb();
    if (!db) return [];

    try {
      const entity = await db
        .select()
        .from(entities)
        .where(eq(entities.id, entityId))
        .limit(1);

      if (entity.length === 0) return [];

      const properties = entity[0].properties as any;

      const timeline: Array<{ timestamp: string; context: string; eventId?: number }> = [];

      if (properties.firstMentioned) {
        timeline.push({
          timestamp: properties.firstMentioned,
          context: 'First mentioned',
          eventId: entity[0].sourceEventId || undefined,
        });
      }

      if (properties.lastMentioned) {
        timeline.push({
          timestamp: properties.lastMentioned,
          context: 'Last mentioned',
        });
      }

      return timeline.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    } catch (error) {
      console.error('[KnowledgeGraph] Error getting entity timeline:', error);
      return [];
    }
  }
}

// Export singleton instance
export const KnowledgeGraph = new KnowledgeGraphService();
