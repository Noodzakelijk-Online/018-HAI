import { getDb } from "../db";
import { households, householdMembers, users, Household, HouseholdMember, InsertHousehold, InsertHouseholdMember } from "../../drizzle/schema";
import { eq, and } from "drizzle-orm";

/**
 * Household Manager Service
 * 
 * Manages household entities, members, and pooled resources.
 * In HAI, households are the primary container - all agents, connectors,
 * and resources belong to the household, not individual users.
 */

export interface CreateHouseholdParams {
  name: string;
  ownerId: number; // User who creates the household becomes owner
  settings?: Record<string, any>;
}

export interface AddMemberParams {
  householdId: number;
  userId: number;
  role?: "owner" | "member";
}

export interface HouseholdWithMembers extends Household {
  members: Array<HouseholdMember & { user: { id: number; name: string | null; email: string | null } }>;
  memberCount: number;
}

/**
 * Create a new household
 */
export async function createHousehold(params: CreateHouseholdParams): Promise<Household> {
  const { name, ownerId, settings } = params;
  
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  // Create household
  const result = await db.insert(households).values({
    name,
    settings: settings ? JSON.stringify(settings) : null,
  });

  const householdId = Number(result[0].insertId);

  // Add owner as first member
  await db.insert(householdMembers).values({
    householdId,
    userId: ownerId,
    role: "owner",
  });

  // Fetch and return created household
  const created = await db
    .select()
    .from(households)
    .where(eq(households.id, householdId))
    .limit(1);

  if (created.length === 0) {
    throw new Error("Failed to create household");
  }

  return created[0] as Household;
}

/**
 * Add a member to a household
 */
export async function addHouseholdMember(params: AddMemberParams): Promise<HouseholdMember> {
  const { householdId, userId, role = "member" } = params;
  
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  // Check if user is already a member
  const existing = await db
    .select()
    .from(householdMembers)
    .where(and(
      eq(householdMembers.householdId, householdId),
      eq(householdMembers.userId, userId)
    ))
    .limit(1);

  if (existing.length > 0) {
    throw new Error("User is already a member of this household");
  }

  // Add member
  const result = await db.insert(householdMembers).values({
    householdId,
    userId,
    role,
  });

  const memberId = Number(result[0].insertId);

  // Fetch and return created member
  const created = await db
    .select()
    .from(householdMembers)
    .where(eq(householdMembers.id, memberId))
    .limit(1);

  if (created.length === 0) {
    throw new Error("Failed to add household member");
  }

  return created[0] as HouseholdMember;
}

/**
 * Remove a member from a household
 */
export async function removeHouseholdMember(householdId: number, userId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;

  try {
    await db
      .delete(householdMembers)
      .where(and(
        eq(householdMembers.householdId, householdId),
        eq(householdMembers.userId, userId)
      ));

    return true;
  } catch (error) {
    console.error("[HouseholdManager] Error removing member:", error);
    return false;
  }
}

/**
 * Get household by ID with members
 */
export async function getHouseholdWithMembers(householdId: number): Promise<HouseholdWithMembers | null> {
  const db = await getDb();
  if (!db) return null;

  // Get household
  const household = await db
    .select()
    .from(households)
    .where(eq(households.id, householdId))
    .limit(1);

  if (household.length === 0) return null;

  // Get members with user info
  const members = await db
    .select({
      id: householdMembers.id,
      householdId: householdMembers.householdId,
      userId: householdMembers.userId,
      role: householdMembers.role,
      joinedAt: householdMembers.joinedAt,
      user: {
        id: users.id,
        name: users.name,
        email: users.email,
      },
    })
    .from(householdMembers)
    .leftJoin(users, eq(householdMembers.userId, users.id))
    .where(eq(householdMembers.householdId, householdId));

  return {
    ...household[0],
    members: members as any,
    memberCount: members.length,
  } as HouseholdWithMembers;
}

/**
 * Get all households for a user
 */
export async function getUserHouseholds(userId: number): Promise<Household[]> {
  const db = await getDb();
  if (!db) return [];

  const result = await db
    .select({
      id: households.id,
      name: households.name,
      createdAt: households.createdAt,
      settings: households.settings,
    })
    .from(households)
    .innerJoin(householdMembers, eq(households.id, householdMembers.householdId))
    .where(eq(householdMembers.userId, userId));

  return result as Household[];
}

/**
 * Check if user is member of household
 */
export async function isHouseholdMember(householdId: number, userId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;

  const result = await db
    .select()
    .from(householdMembers)
    .where(and(
      eq(householdMembers.householdId, householdId),
      eq(householdMembers.userId, userId)
    ))
    .limit(1);

  return result.length > 0;
}

/**
 * Check if user is owner of household
 */
export async function isHouseholdOwner(householdId: number, userId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;

  const result = await db
    .select()
    .from(householdMembers)
    .where(and(
      eq(householdMembers.householdId, householdId),
      eq(householdMembers.userId, userId),
      eq(householdMembers.role, "owner")
    ))
    .limit(1);

  return result.length > 0;
}

/**
 * Update household settings
 */
export async function updateHouseholdSettings(
  householdId: number,
  settings: Record<string, any>
): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;

  try {
    await db
      .update(households)
      .set({ settings: JSON.stringify(settings) })
      .where(eq(households.id, householdId));

    return true;
  } catch (error) {
    console.error("[HouseholdManager] Error updating settings:", error);
    return false;
  }
}

/**
 * Delete a household (and all members via CASCADE)
 */
export async function deleteHousehold(householdId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;

  try {
    await db
      .delete(households)
      .where(eq(households.id, householdId));

    return true;
  } catch (error) {
    console.error("[HouseholdManager] Error deleting household:", error);
    return false;
  }
}
