/**
 * API Key Rotation Service
 * Implements P1 #61: Add API key rotation mechanism
 */

import { randomBytes } from 'crypto';

export interface APIKey {
  id: string;
  key: string;
  name: string;
  userId: number;
  scopes: string[];
  createdAt: Date;
  expiresAt: Date | null;
  lastUsedAt: Date | null;
  rotatedAt: Date | null;
  previousKeyHash?: string;
  status: 'active' | 'rotated' | 'revoked' | 'expired';
}

export interface APIKeyCreateOptions {
  name: string;
  userId: number;
  scopes?: string[];
  expiresInDays?: number;
}

// In-memory store (would use database in production)
const apiKeys: Map<string, APIKey> = new Map();
const keyLookup: Map<string, string> = new Map(); // key -> id

/**
 * Generate a secure API key
 */
export function generateAPIKey(prefix: string = 'hai'): string {
  const random = randomBytes(24).toString('base64url');
  return `${prefix}_${random}`;
}

/**
 * Hash API key for storage
 */
function hashKey(key: string): string {
  const crypto = require('crypto');
  return crypto.createHash('sha256').update(key).digest('hex');
}

/**
 * Create a new API key
 */
export function createAPIKey(options: APIKeyCreateOptions): { apiKey: APIKey; rawKey: string } {
  const id = `key_${Date.now()}_${randomBytes(4).toString('hex')}`;
  const rawKey = generateAPIKey();
  const keyHash = hashKey(rawKey);
  
  const apiKey: APIKey = {
    id,
    key: keyHash, // Store hash, not raw key
    name: options.name,
    userId: options.userId,
    scopes: options.scopes || ['*'],
    createdAt: new Date(),
    expiresAt: options.expiresInDays 
      ? new Date(Date.now() + options.expiresInDays * 24 * 60 * 60 * 1000)
      : null,
    lastUsedAt: null,
    rotatedAt: null,
    status: 'active',
  };
  
  apiKeys.set(id, apiKey);
  keyLookup.set(keyHash, id);
  
  return { apiKey, rawKey };
}

/**
 * Validate an API key
 */
export function validateAPIKey(rawKey: string): APIKey | null {
  const keyHash = hashKey(rawKey);
  const keyId = keyLookup.get(keyHash);
  
  if (!keyId) return null;
  
  const apiKey = apiKeys.get(keyId);
  if (!apiKey) return null;
  
  // Check status
  if (apiKey.status !== 'active') return null;
  
  // Check expiration
  if (apiKey.expiresAt && apiKey.expiresAt < new Date()) {
    apiKey.status = 'expired';
    return null;
  }
  
  // Update last used
  apiKey.lastUsedAt = new Date();
  
  return apiKey;
}

/**
 * Rotate an API key
 */
export function rotateAPIKey(keyId: string): { newKey: APIKey; rawKey: string } | null {
  const oldKey = apiKeys.get(keyId);
  if (!oldKey || oldKey.status !== 'active') return null;
  
  // Generate new key
  const rawKey = generateAPIKey();
  const newKeyHash = hashKey(rawKey);
  
  // Store old key hash for grace period
  const previousKeyHash = oldKey.key;
  
  // Update key
  oldKey.key = newKeyHash;
  oldKey.previousKeyHash = previousKeyHash;
  oldKey.rotatedAt = new Date();
  
  // Update lookup
  keyLookup.delete(previousKeyHash);
  keyLookup.set(newKeyHash, keyId);
  
  // Keep old key valid for grace period (24 hours)
  setTimeout(() => {
    const key = apiKeys.get(keyId);
    if (key) {
      delete key.previousKeyHash;
    }
  }, 24 * 60 * 60 * 1000);
  
  return { newKey: oldKey, rawKey };
}

/**
 * Revoke an API key
 */
export function revokeAPIKey(keyId: string): boolean {
  const apiKey = apiKeys.get(keyId);
  if (!apiKey) return false;
  
  apiKey.status = 'revoked';
  keyLookup.delete(apiKey.key);
  if (apiKey.previousKeyHash) {
    keyLookup.delete(apiKey.previousKeyHash);
  }
  
  return true;
}

/**
 * Get API keys for a user
 */
export function getUserAPIKeys(userId: number): APIKey[] {
  return Array.from(apiKeys.values())
    .filter(key => key.userId === userId)
    .map(key => ({
      ...key,
      key: key.key.slice(0, 8) + '...' + key.key.slice(-8), // Mask key
    }));
}

/**
 * Check if key has scope
 */
export function hasScope(apiKey: APIKey, requiredScope: string): boolean {
  if (apiKey.scopes.includes('*')) return true;
  return apiKey.scopes.includes(requiredScope);
}

/**
 * Schedule automatic key rotation
 */
export function scheduleKeyRotation(
  keyId: string,
  intervalDays: number,
  onRotate: (newKey: string) => void
): NodeJS.Timeout {
  const intervalMs = intervalDays * 24 * 60 * 60 * 1000;
  
  return setInterval(() => {
    const result = rotateAPIKey(keyId);
    if (result) {
      console.log(`[APIKey] Auto-rotated key ${keyId}`);
      onRotate(result.rawKey);
    }
  }, intervalMs);
}

/**
 * Get keys expiring soon
 */
export function getExpiringKeys(withinDays: number = 7): APIKey[] {
  const threshold = new Date(Date.now() + withinDays * 24 * 60 * 60 * 1000);
  
  return Array.from(apiKeys.values()).filter(key => 
    key.status === 'active' && 
    key.expiresAt && 
    key.expiresAt <= threshold
  );
}

/**
 * Clean up expired keys
 */
export function cleanupExpiredKeys(): number {
  let cleaned = 0;
  const now = new Date();
  
  for (const [id, key] of apiKeys.entries()) {
    if (key.expiresAt && key.expiresAt < now && key.status === 'active') {
      key.status = 'expired';
      keyLookup.delete(key.key);
      cleaned++;
    }
  }
  
  return cleaned;
}

/**
 * API key statistics
 */
export function getAPIKeyStats(): {
  total: number;
  active: number;
  expired: number;
  revoked: number;
  rotated: number;
} {
  const keys = Array.from(apiKeys.values());
  
  return {
    total: keys.length,
    active: keys.filter(k => k.status === 'active').length,
    expired: keys.filter(k => k.status === 'expired').length,
    revoked: keys.filter(k => k.status === 'revoked').length,
    rotated: keys.filter(k => k.rotatedAt !== null).length,
  };
}

/**
 * Express middleware for API key authentication
 */
export function apiKeyAuthMiddleware(requiredScope?: string) {
  return (req: any, res: any, next: any) => {
    const authHeader = req.headers.authorization;
    
    if (!authHeader?.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'API key required' });
    }
    
    const rawKey = authHeader.slice(7);
    const apiKey = validateAPIKey(rawKey);
    
    if (!apiKey) {
      return res.status(401).json({ error: 'Invalid or expired API key' });
    }
    
    if (requiredScope && !hasScope(apiKey, requiredScope)) {
      return res.status(403).json({ error: 'Insufficient scope' });
    }
    
    req.apiKey = apiKey;
    next();
  };
}

export default {
  generateAPIKey,
  createAPIKey,
  validateAPIKey,
  rotateAPIKey,
  revokeAPIKey,
  getUserAPIKeys,
  hasScope,
  scheduleKeyRotation,
  getExpiringKeys,
  cleanupExpiredKeys,
  getAPIKeyStats,
  apiKeyAuthMiddleware,
};
