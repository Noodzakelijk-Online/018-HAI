/**
 * API Versioning Service
 * Implements P1 #50: Add API versioning support
 */

import type { Request, Response, NextFunction } from 'express';

export type APIVersion = 'v1' | 'v2' | 'v3';

export interface VersionConfig {
  current: APIVersion;
  supported: APIVersion[];
  deprecated: APIVersion[];
  sunset: Record<APIVersion, Date>;
}

const VERSION_CONFIG: VersionConfig = {
  current: 'v1',
  supported: ['v1'],
  deprecated: [],
  sunset: {},
};

/**
 * Extract version from request
 */
export function extractVersion(req: Request): APIVersion {
  // Check URL path: /api/v1/...
  const pathMatch = req.path.match(/\/api\/(v\d+)\//);
  if (pathMatch) {
    return pathMatch[1] as APIVersion;
  }
  
  // Check header: X-API-Version
  const headerVersion = req.headers['x-api-version'] as string;
  if (headerVersion && VERSION_CONFIG.supported.includes(headerVersion as APIVersion)) {
    return headerVersion as APIVersion;
  }
  
  // Check query param: ?version=v1
  const queryVersion = req.query.version as string;
  if (queryVersion && VERSION_CONFIG.supported.includes(queryVersion as APIVersion)) {
    return queryVersion as APIVersion;
  }
  
  // Check Accept header: application/vnd.api+json;version=1
  const accept = req.headers.accept;
  if (accept) {
    const versionMatch = accept.match(/version=(\d+)/);
    if (versionMatch) {
      const version = `v${versionMatch[1]}` as APIVersion;
      if (VERSION_CONFIG.supported.includes(version)) {
        return version;
      }
    }
  }
  
  // Default to current version
  return VERSION_CONFIG.current;
}

/**
 * Version validation middleware
 */
export function versionMiddleware() {
  return (req: Request, res: Response, next: NextFunction) => {
    const version = extractVersion(req);
    
    // Check if version is supported
    if (!VERSION_CONFIG.supported.includes(version)) {
      return res.status(400).json({
        error: 'Unsupported API Version',
        message: `Version ${version} is not supported. Supported versions: ${VERSION_CONFIG.supported.join(', ')}`,
        supportedVersions: VERSION_CONFIG.supported,
      });
    }
    
    // Check if version is deprecated
    if (VERSION_CONFIG.deprecated.includes(version)) {
      const sunsetDate = VERSION_CONFIG.sunset[version];
      res.setHeader('Deprecation', 'true');
      res.setHeader('X-API-Deprecated', 'true');
      if (sunsetDate) {
        res.setHeader('Sunset', sunsetDate.toUTCString());
      }
      console.warn(`[API] Deprecated version ${version} used by ${req.ip}`);
    }
    
    // Store version in request
    (req as any).apiVersion = version;
    
    // Set response header
    res.setHeader('X-API-Version', version);
    
    next();
  };
}

/**
 * Version-specific response transformer
 */
export type ResponseTransformer<T> = (data: T, version: APIVersion) => any;

export function transformResponse<T>(
  data: T,
  version: APIVersion,
  transformers: Partial<Record<APIVersion, ResponseTransformer<T>>>
): any {
  const transformer = transformers[version];
  if (transformer) {
    return transformer(data, version);
  }
  return data;
}

/**
 * Version-aware route handler
 */
export function versionedHandler<T>(
  handlers: Partial<Record<APIVersion, (req: Request, res: Response) => Promise<T>>>
) {
  return async (req: Request, res: Response) => {
    const version = (req as any).apiVersion || VERSION_CONFIG.current;
    const handler = handlers[version] || handlers[VERSION_CONFIG.current];
    
    if (!handler) {
      return res.status(501).json({
        error: 'Not Implemented',
        message: `This endpoint is not implemented for version ${version}`,
      });
    }
    
    return handler(req, res);
  };
}

/**
 * Check if a feature is available in a version
 */
export function isFeatureAvailable(feature: string, version: APIVersion): boolean {
  const featureVersions: Record<string, APIVersion[]> = {
    'autonomous-tasks': ['v1'],
    'ai-chat': ['v1'],
    'connectors': ['v1'],
    'level5-ai': ['v1'],
    'batch-operations': ['v1'],
  };
  
  const supportedVersions = featureVersions[feature];
  return supportedVersions ? supportedVersions.includes(version) : false;
}

/**
 * Get version configuration
 */
export function getVersionConfig(): VersionConfig {
  return { ...VERSION_CONFIG };
}

/**
 * Update version configuration
 */
export function updateVersionConfig(updates: Partial<VersionConfig>): void {
  Object.assign(VERSION_CONFIG, updates);
}

/**
 * Deprecate a version
 */
export function deprecateVersion(version: APIVersion, sunsetDate: Date): void {
  if (!VERSION_CONFIG.deprecated.includes(version)) {
    VERSION_CONFIG.deprecated.push(version);
  }
  VERSION_CONFIG.sunset[version] = sunsetDate;
  console.log(`[API] Version ${version} deprecated. Sunset: ${sunsetDate.toISOString()}`);
}

/**
 * Remove a version from supported list
 */
export function removeVersion(version: APIVersion): void {
  VERSION_CONFIG.supported = VERSION_CONFIG.supported.filter(v => v !== version);
  VERSION_CONFIG.deprecated = VERSION_CONFIG.deprecated.filter(v => v !== version);
  delete VERSION_CONFIG.sunset[version];
  console.log(`[API] Version ${version} removed from supported versions`);
}

export default {
  extractVersion,
  versionMiddleware,
  transformResponse,
  versionedHandler,
  isFeatureAvailable,
  getVersionConfig,
  updateVersionConfig,
  deprecateVersion,
  removeVersion,
  VERSION_CONFIG,
};
