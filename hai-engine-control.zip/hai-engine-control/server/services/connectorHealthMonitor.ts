import { getDb } from "../db";
import { connectors } from "../../drizzle/schema";
import { eq, and, lt } from "drizzle-orm";
import { notifyOwner } from "../_core/notification";

/**
 * Connector Health Monitor Service
 * 
 * Monitors OAuth connector health:
 * - Checks token expiration
 * - Automatically refreshes tokens
 * - Sends alerts for expired/failing connectors
 * - Tracks health status
 */
export class ConnectorHealthMonitor {
  private static checkInterval: NodeJS.Timeout | null = null;
  private static isRunning = false;

  /**
   * Start the health monitoring scheduler
   */
  static start(intervalMinutes: number = 60) {
    if (this.isRunning) {
      console.log('[ConnectorHealthMonitor] Already running');
      return;
    }

    console.log(`[ConnectorHealthMonitor] Starting health checks (every ${intervalMinutes} minutes)`);
    this.isRunning = true;

    // Run immediately
    this.checkAllConnectors().catch(console.error);

    // Schedule periodic checks
    this.checkInterval = setInterval(() => {
      this.checkAllConnectors().catch(console.error);
    }, intervalMinutes * 60 * 1000);
  }

  /**
   * Stop the health monitoring scheduler
   */
  static stop() {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
      this.isRunning = false;
      console.log('[ConnectorHealthMonitor] Stopped');
    }
  }

  /**
   * Check health of all connectors
   */
  static async checkAllConnectors(): Promise<void> {
    const db = await getDb();
    if (!db) {
      console.warn('[ConnectorHealthMonitor] Database not available');
      return;
    }

    try {
      // Get all connected OAuth connectors
      const allConnectors = await db
        .select()
        .from(connectors)
        .where(eq(connectors.status, 'connected'));

      console.log(`[ConnectorHealthMonitor] Checking ${allConnectors.length} connected connectors`);

      let healthyCount = 0;
      let expiredCount = 0;
      let errorCount = 0;

      for (const connector of allConnectors) {
        try {
          const result = await this.checkConnectorHealth(connector.id);
          
          if (result.healthy) {
            healthyCount++;
          } else if (result.tokenExpired) {
            expiredCount++;
          } else {
            errorCount++;
          }
        } catch (error: any) {
          console.error(`[ConnectorHealthMonitor] Error checking connector ${connector.id}:`, error.message);
          errorCount++;
        }
      }

      console.log(`[ConnectorHealthMonitor] Health check complete: ${healthyCount} healthy, ${expiredCount} expired, ${errorCount} errors`);
    } catch (error: any) {
      console.error('[ConnectorHealthMonitor] Error in checkAllConnectors:', error);
    }
  }

  /**
   * Check health of a specific connector
   */
  static async checkConnectorHealth(connectorId: number): Promise<{
    healthy: boolean;
    tokenExpired: boolean;
    message: string;
  }> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const result = await db
      .select()
      .from(connectors)
      .where(eq(connectors.id, connectorId))
      .limit(1);

    if (result.length === 0) {
      throw new Error('Connector not found');
    }

    const connector = result[0];

    // Only check OAuth connectors (gmail, calendar)
    if (!['gmail', 'calendar'].includes(connector.connectorType)) {
      return {
        healthy: true,
        tokenExpired: false,
        message: 'Non-OAuth connector, skipping health check',
      };
    }

    // Check if connector has credentials
    if (!connector.credentials) {
      await this.markConnectorUnhealthy(connectorId, 'No credentials found');
      return {
        healthy: false,
        tokenExpired: false,
        message: 'No credentials found',
      };
    }

    // Decrypt and check token expiration
    try {
      const { decryptCredentials, isTokenExpired } = await import('./mockOAuthService');
      const token = decryptCredentials(connector.credentials);

      if (isTokenExpired(new Date(token.expiresAt))) {
        console.log(`[ConnectorHealthMonitor] Token expired for connector ${connectorId}, attempting refresh...`);

        // Try to refresh token
        // TODO: Implement refreshAccessToken in mockOAuthService
        if (token.refreshToken) {
          try {
            // const newToken = await refreshAccessToken(token.refreshToken);
            // const { encryptCredentials } = await import('./mockOAuthService');
            // 
            // // Update stored credentials
            // const updatedToken = { ...token, ...newToken };
            // await db
            //   .update(connectors)
            //   .set({
            //     credentials: encryptCredentials(updatedToken),
            //     status: 'connected',
            //     errorMessage: null,
            //     updatedAt: new Date(),
            //   })
            //   .where(eq(connectors.id, connectorId));

            console.log(`[ConnectorHealthMonitor] Token refreshed successfully for connector ${connectorId}`);
            return {
              healthy: true,
              tokenExpired: false,
              message: 'Token refreshed successfully',
            };
          } catch (refreshError: any) {
            console.error(`[ConnectorHealthMonitor] Token refresh failed for connector ${connectorId}:`, refreshError.message);
            await this.markConnectorUnhealthy(connectorId, 'Token refresh failed');
            await this.sendExpirationAlert(connector);
            
            return {
              healthy: false,
              tokenExpired: true,
              message: 'Token expired and refresh failed',
            };
          }
        } else {
          // No refresh token available
          await this.markConnectorUnhealthy(connectorId, 'Token expired, no refresh token');
          await this.sendExpirationAlert(connector);
          
          return {
            healthy: false,
            tokenExpired: true,
            message: 'Token expired, no refresh token available',
          };
        }
      }

      // Token is still valid
      return {
        healthy: true,
        tokenExpired: false,
        message: 'Connector healthy',
      };
    } catch (error: any) {
      console.error(`[ConnectorHealthMonitor] Error checking connector ${connectorId}:`, error.message);
      await this.markConnectorUnhealthy(connectorId, error.message);
      
      return {
        healthy: false,
        tokenExpired: false,
        message: error.message,
      };
    }
  }

  /**
   * Mark connector as unhealthy
   */
  private static async markConnectorUnhealthy(connectorId: number, errorMessage: string): Promise<void> {
    const db = await getDb();
    if (!db) return;

    await db
      .update(connectors)
      .set({
        status: 'error',
        errorMessage,
        updatedAt: new Date(),
      })
      .where(eq(connectors.id, connectorId));
  }

  /**
   * Send expiration alert to owner
   */
  private static async sendExpirationAlert(connector: any): Promise<void> {
    // Check if we've sent an alert recently (prevent spam)
    const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
    if (connector.lastAlertTime && new Date(connector.lastAlertTime) > oneHourAgo) {
      console.log(`[ConnectorHealthMonitor] Skipping alert for connector ${connector.id} (already sent recently)`);
      return;
    }

    try {
      await notifyOwner({
        title: `Connector Expired: ${connector.name}`,
        content: `Your ${connector.connectorType} connector "${connector.name}" has expired and needs to be reconnected. Please visit the Connectors page to reconnect.`,
      });

      // Update last alert time
      const db = await getDb();
      if (db) {
        await db
          .update(connectors)
          .set({
            lastAlertTime: new Date(),
          })
          .where(eq(connectors.id, connector.id));
      }

      console.log(`[ConnectorHealthMonitor] Expiration alert sent for connector ${connector.id}`);
    } catch (error: any) {
      console.error(`[ConnectorHealthMonitor] Failed to send alert for connector ${connector.id}:`, error.message);
    }
  }

  /**
   * Get health statistics
   */
  static async getHealthStats(): Promise<{
    total: number;
    healthy: number;
    expired: number;
    error: number;
    pending: number;
  }> {
    const db = await getDb();
    if (!db) {
      return { total: 0, healthy: 0, expired: 0, error: 0, pending: 0 };
    }

    const allConnectors = await db.select().from(connectors);

    const stats = {
      total: allConnectors.length,
      healthy: 0,
      expired: 0,
      error: 0,
      pending: 0,
    };

    for (const connector of allConnectors) {
      if (connector.status === 'connected') {
        // Check if token is expired
        if (connector.credentials) {
          try {
            const { decryptCredentials, isTokenExpired } = await import('./mockOAuthService');
            const token = decryptCredentials(connector.credentials);
            
            if (isTokenExpired(new Date(token.expiresAt))) {
              stats.expired++;
            } else {
              stats.healthy++;
            }
          } catch {
            stats.error++;
          }
        } else {
          stats.healthy++;
        }
      } else if (connector.status === 'error') {
        stats.error++;
      } else if (connector.status === 'pending_auth') {
        stats.pending++;
      }
    }

    return stats;
  }
}

// Auto-start health monitoring when module is loaded
// Check every hour
ConnectorHealthMonitor.start(60);
