export async function globalSearch(query: string, filters?: {
  types?: string[];
  dateRange?: { start: Date; end: Date };
  userId?: number;
}) {
  // TODO: Implement full-text search across all entities
  // Tasks, emails, events, agents, connectors, etc.
  return {
    tasks: [],
    activities: [],
    connectors: [],
    agents: []
  };
}
