/**
 * Database Transaction Helper
 * Implements P0 #71: Database transaction support for critical operations
 */

import { getDb } from '../db';
import { sql } from 'drizzle-orm';

export interface TransactionContext {
  execute: <T>(operation: () => Promise<T>) => Promise<T>;
  commit: () => Promise<void>;
  rollback: () => Promise<void>;
}

/**
 * Execute a function within a database transaction
 * Automatically commits on success, rolls back on error
 */
export async function withTransaction<T>(
  operation: (db: Awaited<ReturnType<typeof getDb>>) => Promise<T>
): Promise<T> {
  const db = await getDb();
  if (!db) {
    throw new Error('Database not available');
  }
  
  try {
    // Start transaction
    await db.execute(sql`START TRANSACTION`);
    
    // Execute operation
    const result = await operation(db);
    
    // Commit on success
    await db.execute(sql`COMMIT`);
    
    return result;
  } catch (error) {
    // Rollback on error
    try {
      await db.execute(sql`ROLLBACK`);
    } catch (rollbackError) {
      console.error('[Transaction] Rollback failed:', rollbackError);
    }
    throw error;
  }
}

/**
 * Execute multiple operations atomically
 */
export async function atomicOperations<T>(
  operations: Array<() => Promise<T>>
): Promise<T[]> {
  return withTransaction(async () => {
    const results: T[] = [];
    for (const operation of operations) {
      results.push(await operation());
    }
    return results;
  });
}

/**
 * Retry a transaction with exponential backoff on deadlock
 */
export async function withRetryTransaction<T>(
  operation: (db: Awaited<ReturnType<typeof getDb>>) => Promise<T>,
  maxRetries: number = 3,
  baseDelayMs: number = 100
): Promise<T> {
  let lastError: Error | null = null;
  
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await withTransaction(operation);
    } catch (error) {
      lastError = error as Error;
      
      // Check if it's a deadlock error
      const isDeadlock = lastError.message?.includes('Deadlock') || 
                         lastError.message?.includes('Lock wait timeout');
      
      if (!isDeadlock || attempt === maxRetries - 1) {
        throw error;
      }
      
      // Exponential backoff
      const delay = baseDelayMs * Math.pow(2, attempt);
      console.warn(`[Transaction] Deadlock detected, retrying in ${delay}ms (attempt ${attempt + 1}/${maxRetries})`);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  
  throw lastError;
}

/**
 * Optimistic locking helper
 * Checks version before update, throws if version mismatch
 */
export async function withOptimisticLock<T>(
  tableName: string,
  id: number,
  expectedVersion: number,
  updateOperation: () => Promise<T>
): Promise<T> {
  const db = await getDb();
  if (!db) {
    throw new Error('Database not available');
  }
  
  return withTransaction(async () => {
    // Check current version
    const [current] = await db.execute(
      sql`SELECT version FROM ${sql.identifier(tableName)} WHERE id = ${id} FOR UPDATE`
    ) as any[];
    
    if (!current || current.version !== expectedVersion) {
      throw new Error(`Optimistic lock failed: expected version ${expectedVersion}, got ${current?.version}`);
    }
    
    // Execute update
    const result = await updateOperation();
    
    // Increment version
    await db.execute(
      sql`UPDATE ${sql.identifier(tableName)} SET version = version + 1 WHERE id = ${id}`
    );
    
    return result;
  });
}

/**
 * Batch insert with transaction
 */
export async function batchInsert<T>(
  insertFn: (items: T[]) => Promise<void>,
  items: T[],
  batchSize: number = 100
): Promise<void> {
  return withTransaction(async () => {
    for (let i = 0; i < items.length; i += batchSize) {
      const batch = items.slice(i, i + batchSize);
      await insertFn(batch);
    }
  });
}

/**
 * Savepoint support for nested transactions
 */
export async function withSavepoint<T>(
  name: string,
  operation: () => Promise<T>
): Promise<T> {
  const db = await getDb();
  if (!db) {
    throw new Error('Database not available');
  }
  
  try {
    await db.execute(sql`SAVEPOINT ${sql.identifier(name)}`);
    const result = await operation();
    await db.execute(sql`RELEASE SAVEPOINT ${sql.identifier(name)}`);
    return result;
  } catch (error) {
    await db.execute(sql`ROLLBACK TO SAVEPOINT ${sql.identifier(name)}`);
    throw error;
  }
}

export default {
  withTransaction,
  atomicOperations,
  withRetryTransaction,
  withOptimisticLock,
  batchInsert,
  withSavepoint,
};
