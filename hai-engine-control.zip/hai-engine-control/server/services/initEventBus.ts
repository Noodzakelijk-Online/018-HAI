import { EventBus } from './EventBus';
import { householdLedger } from './HouseholdLedgerEngine';

/**
 * Initialize EventBus on server startup
 */
export async function initEventBus(): Promise<void> {
  try {
    await EventBus.connect();
    console.log('[HAI] EventBus initialized successfully');
    
    // Set up global event handlers for logging all events to HLE
    await EventBus.subscribe('*', async (event) => {
      try {
        await householdLedger.appendEvent(event);
      } catch (error) {
        console.error('[HLE] Failed to append event to ledger:', error);
      }
    });
    
  } catch (error) {
    console.error('[HAI] Failed to initialize EventBus:', error);
    // Don't throw - allow server to start even if Redis is unavailable
  }
}

/**
 * Cleanup EventBus on server shutdown
 */
export async function cleanupEventBus(): Promise<void> {
  try {
    await EventBus.disconnect();
    console.log('[HAI] EventBus cleaned up');
  } catch (error) {
    console.error('[HAI] Error cleaning up EventBus:', error);
  }
}
