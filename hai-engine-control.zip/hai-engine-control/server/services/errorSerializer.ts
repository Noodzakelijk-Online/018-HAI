/**
 * Error Serialization Utilities
 * Implements P1 #55: Implement proper error serialization
 */

export interface SerializedError {
  name: string;
  message: string;
  code?: string;
  statusCode?: number;
  details?: Record<string, unknown>;
  stack?: string;
  timestamp: string;
  requestId?: string;
  path?: string;
}

export interface ErrorResponse {
  success: false;
  error: SerializedError;
}

/**
 * Base application error
 */
export class AppError extends Error {
  public readonly code: string;
  public readonly statusCode: number;
  public readonly details?: Record<string, unknown>;
  public readonly isOperational: boolean;

  constructor(
    message: string,
    options: {
      code?: string;
      statusCode?: number;
      details?: Record<string, unknown>;
      isOperational?: boolean;
      cause?: Error;
    } = {}
  ) {
    super(message);
    this.name = this.constructor.name;
    this.code = options.code || 'INTERNAL_ERROR';
    this.statusCode = options.statusCode || 500;
    this.details = options.details;
    this.isOperational = options.isOperational ?? true;
    
    if (options.cause) {
      this.cause = options.cause;
    }
    
    Error.captureStackTrace(this, this.constructor);
  }
}

/**
 * Common error types
 */
export class ValidationError extends AppError {
  constructor(message: string, details?: Record<string, unknown>) {
    super(message, { code: 'VALIDATION_ERROR', statusCode: 400, details });
  }
}

export class AuthenticationError extends AppError {
  constructor(message: string = 'Authentication required') {
    super(message, { code: 'AUTHENTICATION_ERROR', statusCode: 401 });
  }
}

export class AuthorizationError extends AppError {
  constructor(message: string = 'Access denied') {
    super(message, { code: 'AUTHORIZATION_ERROR', statusCode: 403 });
  }
}

export class NotFoundError extends AppError {
  constructor(resource: string, id?: string | number) {
    const message = id ? `${resource} with id ${id} not found` : `${resource} not found`;
    super(message, { code: 'NOT_FOUND', statusCode: 404, details: { resource, id } });
  }
}

export class ConflictError extends AppError {
  constructor(message: string, details?: Record<string, unknown>) {
    super(message, { code: 'CONFLICT', statusCode: 409, details });
  }
}

export class RateLimitError extends AppError {
  constructor(retryAfter?: number) {
    super('Too many requests', {
      code: 'RATE_LIMIT_EXCEEDED',
      statusCode: 429,
      details: retryAfter ? { retryAfter } : undefined,
    });
  }
}

export class ExternalServiceError extends AppError {
  constructor(service: string, originalError?: Error) {
    super(`External service error: ${service}`, {
      code: 'EXTERNAL_SERVICE_ERROR',
      statusCode: 502,
      details: { service },
      cause: originalError,
    });
  }
}

export class TimeoutError extends AppError {
  constructor(operation: string, timeoutMs: number) {
    super(`Operation timed out: ${operation}`, {
      code: 'TIMEOUT',
      statusCode: 504,
      details: { operation, timeoutMs },
    });
  }
}

/**
 * Serialize error for response
 */
export function serializeError(
  error: Error | AppError,
  options: {
    includeStack?: boolean;
    requestId?: string;
    path?: string;
  } = {}
): SerializedError {
  const { includeStack = process.env.NODE_ENV !== 'production', requestId, path } = options;
  
  const serialized: SerializedError = {
    name: error.name,
    message: error.message,
    timestamp: new Date().toISOString(),
  };
  
  if (error instanceof AppError) {
    serialized.code = error.code;
    serialized.statusCode = error.statusCode;
    if (error.details) {
      serialized.details = error.details;
    }
  }
  
  if (includeStack && error.stack) {
    serialized.stack = error.stack;
  }
  
  if (requestId) {
    serialized.requestId = requestId;
  }
  
  if (path) {
    serialized.path = path;
  }
  
  return serialized;
}

/**
 * Create error response
 */
export function createErrorResponse(
  error: Error | AppError,
  options: {
    includeStack?: boolean;
    requestId?: string;
    path?: string;
  } = {}
): ErrorResponse {
  return {
    success: false,
    error: serializeError(error, options),
  };
}

/**
 * Get HTTP status code from error
 */
export function getStatusCode(error: Error): number {
  if (error instanceof AppError) {
    return error.statusCode;
  }
  
  // Map common error names to status codes
  const errorStatusMap: Record<string, number> = {
    ValidationError: 400,
    SyntaxError: 400,
    TypeError: 400,
    RangeError: 400,
    UnauthorizedError: 401,
    ForbiddenError: 403,
    NotFoundError: 404,
  };
  
  return errorStatusMap[error.name] || 500;
}

/**
 * Check if error is operational (expected) vs programming error
 */
export function isOperationalError(error: Error): boolean {
  if (error instanceof AppError) {
    return error.isOperational;
  }
  return false;
}

/**
 * Sanitize error message for client
 */
export function sanitizeErrorMessage(error: Error): string {
  // Don't expose internal error details in production
  if (process.env.NODE_ENV === 'production' && !isOperationalError(error)) {
    return 'An unexpected error occurred';
  }
  return error.message;
}

/**
 * Express error handler middleware
 */
export function errorHandlerMiddleware() {
  return (error: Error, req: any, res: any, next: any) => {
    // Log error
    console.error('[Error]', {
      name: error.name,
      message: error.message,
      stack: error.stack,
      path: req.path,
      method: req.method,
    });
    
    const statusCode = getStatusCode(error);
    const response = createErrorResponse(error, {
      requestId: req.correlationId,
      path: req.path,
    });
    
    res.status(statusCode).json(response);
  };
}

/**
 * Wrap async handler to catch errors
 */
export function asyncHandler(fn: (req: any, res: any, next: any) => Promise<any>) {
  return (req: any, res: any, next: any) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

/**
 * Convert unknown error to AppError
 */
export function normalizeError(error: unknown): AppError {
  if (error instanceof AppError) {
    return error;
  }
  
  if (error instanceof Error) {
    return new AppError(error.message, {
      cause: error,
      isOperational: false,
    });
  }
  
  return new AppError(String(error), { isOperational: false });
}

export default {
  AppError,
  ValidationError,
  AuthenticationError,
  AuthorizationError,
  NotFoundError,
  ConflictError,
  RateLimitError,
  ExternalServiceError,
  TimeoutError,
  serializeError,
  createErrorResponse,
  getStatusCode,
  isOperationalError,
  sanitizeErrorMessage,
  errorHandlerMiddleware,
  asyncHandler,
  normalizeError,
};
