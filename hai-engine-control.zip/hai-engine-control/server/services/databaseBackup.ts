/**
 * Database Backup Service
 * Automated database backups with S3 storage and retention management
 */

import { storagePut, storageGet } from '../storage';
import { getDb } from '../db';
import { getBackupConfig } from '../config/production';
import { createLogger } from './logger';
import { sql } from 'drizzle-orm';

const logger = createLogger('DatabaseBackup');

export interface BackupMetadata {
  id: string;
  timestamp: Date;
  size: number;
  tables: string[];
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  s3Key?: string;
  s3Url?: string;
  error?: string;
  duration?: number;
  compressed: boolean;
}

export interface BackupSchedule {
  enabled: boolean;
  intervalMs: number;
  retentionDays: number;
  lastBackup?: Date;
  nextBackup?: Date;
}

class DatabaseBackupService {
  private backups: BackupMetadata[] = [];
  private schedule: BackupSchedule;
  private scheduleTimer: NodeJS.Timeout | null = null;
  private maxBackupHistory = 100;

  constructor() {
    const config = getBackupConfig();
    this.schedule = {
      enabled: config.enabled,
      intervalMs: config.intervalMs,
      retentionDays: config.retentionDays,
    };
  }

  /**
   * Start scheduled backups
   */
  startScheduledBackups(): void {
    if (!this.schedule.enabled) {
      logger.info('Scheduled backups are disabled');
      return;
    }

    if (this.scheduleTimer) {
      clearInterval(this.scheduleTimer);
    }

    logger.info(`Starting scheduled backups (interval: ${this.schedule.intervalMs}ms)`);

    // Schedule next backup
    this.schedule.nextBackup = new Date(Date.now() + this.schedule.intervalMs);

    this.scheduleTimer = setInterval(async () => {
      try {
        await this.createBackup();
        await this.cleanupOldBackups();
      } catch (error) {
        logger.error('Scheduled backup failed', error as Error);
      }
    }, this.schedule.intervalMs);
  }

  /**
   * Stop scheduled backups
   */
  stopScheduledBackups(): void {
    if (this.scheduleTimer) {
      clearInterval(this.scheduleTimer);
      this.scheduleTimer = null;
      logger.info('Stopped scheduled backups');
    }
  }

  /**
   * Create a database backup
   */
  async createBackup(): Promise<BackupMetadata> {
    const backupId = `backup-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const startTime = Date.now();

    const backup: BackupMetadata = {
      id: backupId,
      timestamp: new Date(),
      size: 0,
      tables: [],
      status: 'pending',
      compressed: getBackupConfig().compressionEnabled,
    };

    this.backups.push(backup);
    logger.info(`Starting backup ${backupId}`);

    try {
      backup.status = 'in_progress';

      const db = await getDb();
      if (!db) {
        throw new Error('Database not available');
      }

      // Get list of tables
      const tablesResult = await db.execute(sql`SHOW TABLES`);
      const tables = (tablesResult as any[]).map((row: any) => Object.values(row)[0] as string);
      backup.tables = tables;

      // Export each table's data
      const backupData: Record<string, any[]> = {};
      
      for (const table of tables) {
        try {
          const tableData = await db.execute(sql.raw(`SELECT * FROM \`${table}\``));
          backupData[table] = tableData as any[];
          logger.debug(`Exported table ${table}: ${(tableData as any[]).length} rows`);
        } catch (error) {
          logger.warn(`Failed to export table ${table}`, error as Error);
        }
      }

      // Convert to JSON
      let backupContent = JSON.stringify({
        metadata: {
          backupId,
          timestamp: backup.timestamp.toISOString(),
          tables: backup.tables,
        },
        data: backupData,
      }, null, 2);

      // Compress if enabled
      if (backup.compressed) {
        const { gzipSync } = await import('zlib');
        const compressed = gzipSync(Buffer.from(backupContent));
        backupContent = compressed.toString('base64');
      }

      backup.size = Buffer.byteLength(backupContent, 'utf8');

      // Upload to S3
      const s3Key = `backups/${backup.timestamp.toISOString().split('T')[0]}/${backupId}${backup.compressed ? '.json.gz' : '.json'}`;
      
      const { key, url } = await storagePut(
        s3Key,
        Buffer.from(backupContent),
        backup.compressed ? 'application/gzip' : 'application/json'
      );

      backup.s3Key = key;
      backup.s3Url = url;
      backup.status = 'completed';
      backup.duration = Date.now() - startTime;

      this.schedule.lastBackup = new Date();
      this.schedule.nextBackup = new Date(Date.now() + this.schedule.intervalMs);

      logger.info(`Backup completed: ${backupId}`, {
        size: backup.size,
        tables: backup.tables.length,
        duration: backup.duration,
        s3Key: backup.s3Key,
      });

      // Trim backup history
      if (this.backups.length > this.maxBackupHistory) {
        this.backups = this.backups.slice(-this.maxBackupHistory);
      }

      return backup;
    } catch (error) {
      backup.status = 'failed';
      backup.error = error instanceof Error ? error.message : 'Unknown error';
      backup.duration = Date.now() - startTime;
      logger.error(`Backup failed: ${backupId}`, error as Error);
      throw error;
    }
  }

  /**
   * Restore from a backup
   */
  async restoreBackup(backupId: string): Promise<boolean> {
    const backup = this.backups.find(b => b.id === backupId);
    if (!backup || !backup.s3Key) {
      throw new Error(`Backup not found: ${backupId}`);
    }

    logger.info(`Starting restore from backup ${backupId}`);

    try {
      // Download from S3
      const { url } = await storageGet(backup.s3Key);
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`Failed to download backup: ${response.status}`);
      }

      let backupContent = await response.text();

      // Decompress if needed
      if (backup.compressed) {
        const { gunzipSync } = await import('zlib');
        const decompressed = gunzipSync(Buffer.from(backupContent, 'base64'));
        backupContent = decompressed.toString('utf8');
      }

      const backupData = JSON.parse(backupContent);
      const db = await getDb();
      
      if (!db) {
        throw new Error('Database not available');
      }

      // Restore each table
      for (const [table, rows] of Object.entries(backupData.data)) {
        if (!Array.isArray(rows) || rows.length === 0) continue;

        logger.info(`Restoring table ${table}: ${rows.length} rows`);

        // Clear existing data (careful!)
        await db.execute(sql.raw(`DELETE FROM \`${table}\``));

        // Insert rows in batches
        const batchSize = 100;
        for (let i = 0; i < rows.length; i += batchSize) {
          const batch = rows.slice(i, i + batchSize);
          for (const row of batch) {
            const columns = Object.keys(row).map(k => `\`${k}\``).join(', ');
            const values = Object.values(row).map(v => 
              v === null ? 'NULL' : typeof v === 'string' ? `'${v.replace(/'/g, "''")}'` : v
            ).join(', ');
            
            try {
              await db.execute(sql.raw(`INSERT INTO \`${table}\` (${columns}) VALUES (${values})`));
            } catch (error) {
              logger.warn(`Failed to insert row in ${table}`, error as Error);
            }
          }
        }
      }

      logger.info(`Restore completed from backup ${backupId}`);
      return true;
    } catch (error) {
      logger.error(`Restore failed from backup ${backupId}`, error as Error);
      throw error;
    }
  }

  /**
   * Clean up old backups based on retention policy
   */
  async cleanupOldBackups(): Promise<number> {
    const retentionMs = this.schedule.retentionDays * 24 * 60 * 60 * 1000;
    const cutoffDate = new Date(Date.now() - retentionMs);
    
    let deletedCount = 0;

    const oldBackups = this.backups.filter(b => 
      b.timestamp < cutoffDate && b.status === 'completed'
    );

    for (const backup of oldBackups) {
      try {
        // Note: S3 deletion would require additional implementation
        // For now, just remove from local tracking
        const index = this.backups.indexOf(backup);
        if (index > -1) {
          this.backups.splice(index, 1);
          deletedCount++;
          logger.info(`Removed old backup: ${backup.id}`);
        }
      } catch (error) {
        logger.error(`Failed to cleanup backup ${backup.id}`, error as Error);
      }
    }

    if (deletedCount > 0) {
      logger.info(`Cleaned up ${deletedCount} old backups`);
    }

    return deletedCount;
  }

  /**
   * Get backup history
   */
  getBackups(options?: {
    status?: BackupMetadata['status'];
    limit?: number;
  }): BackupMetadata[] {
    let backups = [...this.backups];

    if (options?.status) {
      backups = backups.filter(b => b.status === options.status);
    }

    backups.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

    if (options?.limit) {
      backups = backups.slice(0, options.limit);
    }

    return backups;
  }

  /**
   * Get backup by ID
   */
  getBackup(backupId: string): BackupMetadata | undefined {
    return this.backups.find(b => b.id === backupId);
  }

  /**
   * Get current schedule
   */
  getSchedule(): BackupSchedule {
    return { ...this.schedule };
  }

  /**
   * Update schedule
   */
  updateSchedule(updates: Partial<BackupSchedule>): void {
    Object.assign(this.schedule, updates);
    
    if (updates.enabled !== undefined || updates.intervalMs !== undefined) {
      this.stopScheduledBackups();
      if (this.schedule.enabled) {
        this.startScheduledBackups();
      }
    }

    logger.info('Backup schedule updated', this.schedule);
  }

  /**
   * Get backup statistics
   */
  getStats(): {
    totalBackups: number;
    completedBackups: number;
    failedBackups: number;
    totalSize: number;
    lastBackup?: Date;
    nextBackup?: Date;
  } {
    const completed = this.backups.filter(b => b.status === 'completed');
    const failed = this.backups.filter(b => b.status === 'failed');
    const totalSize = completed.reduce((sum, b) => sum + b.size, 0);

    return {
      totalBackups: this.backups.length,
      completedBackups: completed.length,
      failedBackups: failed.length,
      totalSize,
      lastBackup: this.schedule.lastBackup,
      nextBackup: this.schedule.nextBackup,
    };
  }
}

// Singleton instance
export const databaseBackup = new DatabaseBackupService();

// Auto-start scheduled backups in production
if (process.env.NODE_ENV === 'production') {
  databaseBackup.startScheduledBackups();
}

export default databaseBackup;
