import { invokeLLM } from "../_core/llm";

export type EmailCategory = 'urgent' | 'routine' | 'important' | 'spam' | 'personal';
export type ResponseAction = 'reply' | 'forward' | 'archive' | 'flag' | 'ignore';

export interface EmailClassification {
  category: EmailCategory;
  priority: number;
  sentiment: 'positive' | 'neutral' | 'negative';
  requiresResponse: boolean;
  suggestedAction: ResponseAction;
  reasoning: string;
  confidence: number;
}

export interface EmailResponse {
  subject: string;
  body: string;
  tone: 'formal' | 'casual' | 'friendly' | 'professional';
  confidence: number;
  requiresApproval: boolean;
}

export async function classifyEmail(email: {
  from: string;
  subject: string;
  body: string;
}): Promise<EmailClassification> {
  try {
    const response = await invokeLLM({
      messages: [
        { role: "system", content: "You are an email classification expert." },
        { role: "user", content: `Classify: From: ${email.from}, Subject: ${email.subject}` }
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "email_classification",
          strict: true,
          schema: {
            type: "object",
            properties: {
              category: { type: "string", enum: ["urgent", "routine", "important", "spam", "personal"] },
              priority: { type: "number" },
              sentiment: { type: "string", enum: ["positive", "neutral", "negative"] },
              requiresResponse: { type: "boolean" },
              suggestedAction: { type: "string", enum: ["reply", "forward", "archive", "flag", "ignore"] },
              reasoning: { type: "string" },
              confidence: { type: "number" }
            },
            required: ["category", "priority", "sentiment", "requiresResponse", "suggestedAction", "reasoning", "confidence"],
            additionalProperties: false
          }
        }
      }
    });
    return JSON.parse(response.choices[0].message.content);
  } catch (error) {
    return {
      category: 'routine',
      priority: 3,
      sentiment: 'neutral',
      requiresResponse: true,
      suggestedAction: 'reply',
      reasoning: 'Fallback',
      confidence: 50
    };
  }
}

export async function generateResponse(email: any, userPreferences: any): Promise<EmailResponse> {
  try {
    const response = await invokeLLM({
      messages: [
        { role: "system", content: "You are a professional email writer." },
        { role: "user", content: `Write a reply to: ${email.subject}` }
      ]
    });
    return {
      subject: `Re: ${email.subject}`,
      body: response.choices[0].message.content,
      tone: 'professional',
      confidence: 85,
      requiresApproval: true
    };
  } catch (error) {
    return {
      subject: `Re: ${email.subject}`,
      body: 'Thank you for your email.',
      tone: 'professional',
      confidence: 50,
      requiresApproval: true
    };
  }
}
