/**
 * Memory Management Utilities
 * Implements P1 #45: Fix memory leaks in long-running processes
 * Implements P1 #47: Add memory usage monitoring
 */

export interface MemoryStats {
  heapUsed: number;
  heapTotal: number;
  external: number;
  rss: number;
  arrayBuffers: number;
  heapUsedMB: number;
  heapTotalMB: number;
  rssMB: number;
  heapUsagePercent: number;
}

export interface MemoryThresholds {
  warningMB: number;
  criticalMB: number;
  maxHeapPercent: number;
}

const DEFAULT_THRESHOLDS: MemoryThresholds = {
  warningMB: 512,
  criticalMB: 1024,
  maxHeapPercent: 85,
};

// Memory history for trend analysis
const memoryHistory: MemoryStats[] = [];
const MAX_HISTORY = 100;

/**
 * Get current memory statistics
 */
export function getMemoryStats(): MemoryStats {
  const mem = process.memoryUsage();
  
  return {
    heapUsed: mem.heapUsed,
    heapTotal: mem.heapTotal,
    external: mem.external,
    rss: mem.rss,
    arrayBuffers: mem.arrayBuffers,
    heapUsedMB: Math.round(mem.heapUsed / 1024 / 1024),
    heapTotalMB: Math.round(mem.heapTotal / 1024 / 1024),
    rssMB: Math.round(mem.rss / 1024 / 1024),
    heapUsagePercent: Math.round((mem.heapUsed / mem.heapTotal) * 100),
  };
}

/**
 * Check memory health
 */
export function checkMemoryHealth(thresholds: Partial<MemoryThresholds> = {}): {
  status: 'healthy' | 'warning' | 'critical';
  stats: MemoryStats;
  warnings: string[];
} {
  const t = { ...DEFAULT_THRESHOLDS, ...thresholds };
  const stats = getMemoryStats();
  const warnings: string[] = [];
  let status: 'healthy' | 'warning' | 'critical' = 'healthy';
  
  // Check heap usage percentage
  if (stats.heapUsagePercent >= t.maxHeapPercent) {
    status = 'critical';
    warnings.push(`Heap usage at ${stats.heapUsagePercent}% (threshold: ${t.maxHeapPercent}%)`);
  }
  
  // Check absolute heap size
  if (stats.heapUsedMB >= t.criticalMB) {
    status = 'critical';
    warnings.push(`Heap used ${stats.heapUsedMB}MB exceeds critical threshold ${t.criticalMB}MB`);
  } else if (stats.heapUsedMB >= t.warningMB) {
    if (status === 'healthy') status = 'warning';
    warnings.push(`Heap used ${stats.heapUsedMB}MB exceeds warning threshold ${t.warningMB}MB`);
  }
  
  // Check for memory growth trend
  if (memoryHistory.length >= 10) {
    const recent = memoryHistory.slice(-10);
    const growth = recent[recent.length - 1].heapUsedMB - recent[0].heapUsedMB;
    if (growth > 100) {
      if (status === 'healthy') status = 'warning';
      warnings.push(`Memory grew ${growth}MB in recent samples (possible leak)`);
    }
  }
  
  // Store in history
  memoryHistory.push(stats);
  if (memoryHistory.length > MAX_HISTORY) {
    memoryHistory.shift();
  }
  
  return { status, stats, warnings };
}

/**
 * Get memory history
 */
export function getMemoryHistory(): MemoryStats[] {
  return [...memoryHistory];
}

/**
 * Force garbage collection (if exposed)
 */
export function forceGC(): boolean {
  if (global.gc) {
    global.gc();
    console.log('[Memory] Forced garbage collection');
    return true;
  }
  console.warn('[Memory] Garbage collection not exposed. Run with --expose-gc flag.');
  return false;
}

/**
 * Weak reference cache to prevent memory leaks
 */
export class WeakCache<K extends object, V> {
  private cache = new WeakMap<K, V>();
  private keys: Set<WeakRef<K>> = new Set();
  
  set(key: K, value: V): void {
    this.cache.set(key, value);
    this.keys.add(new WeakRef(key));
  }
  
  get(key: K): V | undefined {
    return this.cache.get(key);
  }
  
  has(key: K): boolean {
    return this.cache.has(key);
  }
  
  delete(key: K): boolean {
    return this.cache.delete(key);
  }
  
  cleanup(): void {
    for (const ref of this.keys) {
      if (ref.deref() === undefined) {
        this.keys.delete(ref);
      }
    }
  }
}

/**
 * Bounded array that automatically removes old items
 */
export class BoundedArray<T> {
  private items: T[] = [];
  
  constructor(private maxSize: number) {}
  
  push(item: T): void {
    this.items.push(item);
    while (this.items.length > this.maxSize) {
      this.items.shift();
    }
  }
  
  get length(): number {
    return this.items.length;
  }
  
  toArray(): T[] {
    return [...this.items];
  }
  
  clear(): void {
    this.items = [];
  }
}

/**
 * Timer manager to prevent timer leaks
 */
class TimerManager {
  private timers: Set<NodeJS.Timeout> = new Set();
  private intervals: Set<NodeJS.Timeout> = new Set();
  
  setTimeout(callback: () => void, ms: number): NodeJS.Timeout {
    const timer = setTimeout(() => {
      this.timers.delete(timer);
      callback();
    }, ms);
    this.timers.add(timer);
    return timer;
  }
  
  setInterval(callback: () => void, ms: number): NodeJS.Timeout {
    const interval = setInterval(callback, ms);
    this.intervals.add(interval);
    return interval;
  }
  
  clearTimeout(timer: NodeJS.Timeout): void {
    clearTimeout(timer);
    this.timers.delete(timer);
  }
  
  clearInterval(interval: NodeJS.Timeout): void {
    clearInterval(interval);
    this.intervals.delete(interval);
  }
  
  clearAll(): void {
    for (const timer of this.timers) {
      clearTimeout(timer);
    }
    for (const interval of this.intervals) {
      clearInterval(interval);
    }
    this.timers.clear();
    this.intervals.clear();
  }
  
  getActiveCount(): { timers: number; intervals: number } {
    return {
      timers: this.timers.size,
      intervals: this.intervals.size,
    };
  }
}

export const timerManager = new TimerManager();

/**
 * Event listener tracker to prevent listener leaks
 */
class ListenerTracker {
  private listeners: Map<EventTarget | NodeJS.EventEmitter, Map<string, Set<Function>>> = new Map();
  
  track(
    target: EventTarget | NodeJS.EventEmitter,
    event: string,
    listener: Function
  ): void {
    if (!this.listeners.has(target)) {
      this.listeners.set(target, new Map());
    }
    
    const targetListeners = this.listeners.get(target)!;
    if (!targetListeners.has(event)) {
      targetListeners.set(event, new Set());
    }
    
    targetListeners.get(event)!.add(listener);
  }
  
  untrack(
    target: EventTarget | NodeJS.EventEmitter,
    event: string,
    listener: Function
  ): void {
    const targetListeners = this.listeners.get(target);
    if (targetListeners) {
      const eventListeners = targetListeners.get(event);
      if (eventListeners) {
        eventListeners.delete(listener);
      }
    }
  }
  
  getCount(target?: EventTarget | NodeJS.EventEmitter): number {
    if (target) {
      const targetListeners = this.listeners.get(target);
      if (!targetListeners) return 0;
      
      let count = 0;
      for (const listeners of targetListeners.values()) {
        count += listeners.size;
      }
      return count;
    }
    
    let total = 0;
    for (const targetListeners of this.listeners.values()) {
      for (const listeners of targetListeners.values()) {
        total += listeners.size;
      }
    }
    return total;
  }
  
  cleanup(target: EventTarget | NodeJS.EventEmitter): void {
    const targetListeners = this.listeners.get(target);
    if (targetListeners) {
      for (const [event, listeners] of targetListeners.entries()) {
        for (const listener of listeners) {
          if ('removeEventListener' in target) {
            (target as EventTarget).removeEventListener(event, listener as EventListener);
          } else {
            (target as NodeJS.EventEmitter).removeListener(event, listener as (...args: any[]) => void);
          }
        }
      }
      this.listeners.delete(target);
    }
  }
}

export const listenerTracker = new ListenerTracker();

/**
 * Memory monitoring interval
 */
let monitorInterval: NodeJS.Timeout | null = null;

export function startMemoryMonitoring(intervalMs: number = 60000): void {
  if (monitorInterval) {
    clearInterval(monitorInterval);
  }
  
  monitorInterval = setInterval(() => {
    const health = checkMemoryHealth();
    
    if (health.status === 'critical') {
      console.error('[Memory] CRITICAL:', health.warnings);
      // Attempt GC if available
      forceGC();
    } else if (health.status === 'warning') {
      console.warn('[Memory] WARNING:', health.warnings);
    }
  }, intervalMs);
  
  console.log(`[Memory] Monitoring started (interval: ${intervalMs / 1000}s)`);
}

export function stopMemoryMonitoring(): void {
  if (monitorInterval) {
    clearInterval(monitorInterval);
    monitorInterval = null;
    console.log('[Memory] Monitoring stopped');
  }
}

export default {
  getMemoryStats,
  checkMemoryHealth,
  getMemoryHistory,
  forceGC,
  WeakCache,
  BoundedArray,
  timerManager,
  listenerTracker,
  startMemoryMonitoring,
  stopMemoryMonitoring,
};
