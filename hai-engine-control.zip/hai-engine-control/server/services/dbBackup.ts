/**
 * Database Backup Automation
 * Implements P1 #77: Add database backup automation
 */

import { storagePut } from '../storage';

export interface BackupConfig {
  enabled: boolean;
  schedule: string; // cron expression
  retention: number; // days to keep backups
  compression: boolean;
  encryption: boolean;
  notifyOnFailure: boolean;
  maxBackups: number;
}

export interface BackupRecord {
  id: string;
  filename: string;
  size: number;
  tables: string[];
  createdAt: Date;
  expiresAt: Date;
  status: 'pending' | 'completed' | 'failed' | 'expired';
  url?: string;
  error?: string;
}

const DEFAULT_CONFIG: BackupConfig = {
  enabled: true,
  schedule: '0 0 2 * * *', // 2 AM daily
  retention: 30,
  compression: true,
  encryption: true,
  notifyOnFailure: true,
  maxBackups: 30,
};

// Backup history
const backupHistory: BackupRecord[] = [];
let config = { ...DEFAULT_CONFIG };

/**
 * Generate backup ID
 */
function generateBackupId(): string {
  const date = new Date().toISOString().split('T')[0];
  const random = Math.random().toString(36).substring(2, 8);
  return `backup_${date}_${random}`;
}

/**
 * Create a database backup
 */
export async function createBackup(
  db: any,
  tables?: string[]
): Promise<BackupRecord> {
  const backupId = generateBackupId();
  const filename = `${backupId}.sql${config.compression ? '.gz' : ''}`;
  
  const record: BackupRecord = {
    id: backupId,
    filename,
    size: 0,
    tables: tables || [],
    createdAt: new Date(),
    expiresAt: new Date(Date.now() + config.retention * 24 * 60 * 60 * 1000),
    status: 'pending',
  };
  
  backupHistory.push(record);
  
  try {
    // Get all tables if not specified
    if (!tables || tables.length === 0) {
      const tablesResult = await db.execute(`SHOW TABLES`);
      record.tables = tablesResult.rows?.map((r: any) => Object.values(r)[0]) || [];
    }
    
    // Generate SQL dump for each table
    const dumpParts: string[] = [];
    
    for (const table of record.tables) {
      // Get table structure
      const createResult = await db.execute(`SHOW CREATE TABLE ${table}`);
      const createStatement = createResult.rows?.[0]?.['Create Table'] || '';
      
      dumpParts.push(`-- Table: ${table}`);
      dumpParts.push(`DROP TABLE IF EXISTS \`${table}\`;`);
      dumpParts.push(createStatement + ';');
      dumpParts.push('');
      
      // Get table data
      const dataResult = await db.execute(`SELECT * FROM ${table}`);
      const rows = dataResult.rows || [];
      
      if (rows.length > 0) {
        const columns = Object.keys(rows[0]);
        const values = rows.map((row: any) => {
          const vals = columns.map(col => {
            const val = row[col];
            if (val === null) return 'NULL';
            if (typeof val === 'number') return val;
            if (val instanceof Date) return `'${val.toISOString()}'`;
            return `'${String(val).replace(/'/g, "''")}'`;
          });
          return `(${vals.join(', ')})`;
        });
        
        dumpParts.push(`INSERT INTO \`${table}\` (\`${columns.join('`, `')}\`) VALUES`);
        dumpParts.push(values.join(',\n') + ';');
        dumpParts.push('');
      }
    }
    
    const dumpContent = dumpParts.join('\n');
    const buffer = Buffer.from(dumpContent, 'utf8');
    
    // Upload to S3
    const { url } = await storagePut(
      `backups/${filename}`,
      buffer,
      'application/sql'
    );
    
    record.size = buffer.length;
    record.url = url;
    record.status = 'completed';
    
    console.log(`[Backup] Created backup ${backupId} (${record.size} bytes)`);
    
    // Cleanup old backups
    await cleanupOldBackups();
    
    return record;
  } catch (error) {
    record.status = 'failed';
    record.error = error instanceof Error ? error.message : String(error);
    
    console.error(`[Backup] Failed to create backup ${backupId}:`, error);
    
    if (config.notifyOnFailure) {
      // Would integrate with notification service
      console.error(`[Backup] Notification: Backup ${backupId} failed`);
    }
    
    throw error;
  }
}

/**
 * Restore from backup
 */
export async function restoreBackup(
  db: any,
  backupId: string
): Promise<{ success: boolean; tablesRestored: number }> {
  const record = backupHistory.find(b => b.id === backupId);
  
  if (!record) {
    throw new Error(`Backup ${backupId} not found`);
  }
  
  if (!record.url) {
    throw new Error(`Backup ${backupId} has no URL`);
  }
  
  try {
    // Fetch backup content
    const response = await fetch(record.url);
    const content = await response.text();
    
    // Split into statements
    const statements = content
      .split(';')
      .map(s => s.trim())
      .filter(s => s && !s.startsWith('--'));
    
    let tablesRestored = 0;
    
    for (const statement of statements) {
      if (statement) {
        await db.execute(statement);
        if (statement.toUpperCase().startsWith('CREATE TABLE')) {
          tablesRestored++;
        }
      }
    }
    
    console.log(`[Backup] Restored backup ${backupId} (${tablesRestored} tables)`);
    
    return { success: true, tablesRestored };
  } catch (error) {
    console.error(`[Backup] Failed to restore backup ${backupId}:`, error);
    throw error;
  }
}

/**
 * Clean up old backups
 */
export async function cleanupOldBackups(): Promise<number> {
  const now = new Date();
  let cleaned = 0;
  
  for (const record of backupHistory) {
    if (record.expiresAt < now && record.status === 'completed') {
      record.status = 'expired';
      cleaned++;
    }
  }
  
  // Keep only maxBackups
  const completed = backupHistory.filter(b => b.status === 'completed');
  if (completed.length > config.maxBackups) {
    const toRemove = completed
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime())
      .slice(0, completed.length - config.maxBackups);
    
    for (const record of toRemove) {
      record.status = 'expired';
      cleaned++;
    }
  }
  
  if (cleaned > 0) {
    console.log(`[Backup] Cleaned up ${cleaned} old backups`);
  }
  
  return cleaned;
}

/**
 * Get backup history
 */
export function getBackupHistory(limit: number = 10): BackupRecord[] {
  return backupHistory
    .filter(b => b.status !== 'expired')
    .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
    .slice(0, limit);
}

/**
 * Get backup by ID
 */
export function getBackup(backupId: string): BackupRecord | undefined {
  return backupHistory.find(b => b.id === backupId);
}

/**
 * Update backup configuration
 */
export function updateConfig(updates: Partial<BackupConfig>): void {
  config = { ...config, ...updates };
}

/**
 * Get current configuration
 */
export function getConfig(): BackupConfig {
  return { ...config };
}

/**
 * Get backup statistics
 */
export function getBackupStats(): {
  total: number;
  completed: number;
  failed: number;
  totalSize: number;
  lastBackup?: Date;
} {
  const completed = backupHistory.filter(b => b.status === 'completed');
  const failed = backupHistory.filter(b => b.status === 'failed');
  const totalSize = completed.reduce((sum, b) => sum + b.size, 0);
  const lastBackup = completed.length > 0
    ? completed.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())[0].createdAt
    : undefined;
  
  return {
    total: backupHistory.length,
    completed: completed.length,
    failed: failed.length,
    totalSize,
    lastBackup,
  };
}

/**
 * Schedule automatic backups
 */
export function scheduleBackups(db: any): NodeJS.Timeout {
  // Run daily at 2 AM (simplified - in production use proper cron)
  const interval = 24 * 60 * 60 * 1000; // 24 hours
  
  return setInterval(async () => {
    if (config.enabled) {
      try {
        await createBackup(db);
      } catch (error) {
        console.error('[Backup] Scheduled backup failed:', error);
      }
    }
  }, interval);
}

export default {
  createBackup,
  restoreBackup,
  cleanupOldBackups,
  getBackupHistory,
  getBackup,
  updateConfig,
  getConfig,
  getBackupStats,
  scheduleBackups,
};
