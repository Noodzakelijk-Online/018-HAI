/**
 * Input Pipeline
 * 
 * Orchestrates the complete input processing flow:
 * 1. Receive raw input from any source
 * 2. Normalize format
 * 3. Extract entities
 * 4. Classify intent
 * 5. Build context
 * 6. Route to appropriate handler
 * 7. Track and audit
 */

import { EventEmitter } from 'events';
import { UniversalInputProcessor, RawInput, ProcessedInput, InputSource, InputFormat } from './UniversalInputProcessor';
import { FormatNormalizer, NormalizedContent } from './FormatNormalizer';
import { EntityExtractor, ExtractedEntities } from './EntityExtractor';
import { IntentClassifier, ClassifiedIntent } from './IntentClassifier';
import { ContextBuilder, InputContext } from './ContextBuilder';
import { ConnectorManager, BaseConnector, ConnectorConfig } from './SourceConnectors';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

export interface PipelineInput {
  // Raw input data
  raw: RawInput;
  
  // Normalized content
  normalized: NormalizedContent;
  
  // Extracted entities
  entities: ExtractedEntities;
  
  // Classified intent
  intent: ClassifiedIntent;
  
  // Built context
  context: InputContext;
  
  // Processing metadata
  pipeline: {
    id: string;
    startedAt: Date;
    completedAt?: Date;
    stages: PipelineStage[];
    errors: PipelineError[];
    confidence: number;
  };
}

export interface PipelineStage {
  name: string;
  startedAt: Date;
  completedAt: Date;
  duration: number;
  success: boolean;
  error?: string;
}

export interface PipelineError {
  stage: string;
  error: string;
  recoverable: boolean;
  timestamp: Date;
}

export interface PipelineConfig {
  // Processing options
  enableParallelProcessing: boolean;
  maxConcurrentInputs: number;
  processingTimeout: number;
  
  // Stage options
  skipNormalization: boolean;
  skipEntityExtraction: boolean;
  skipIntentClassification: boolean;
  skipContextBuilding: boolean;
  
  // Routing options
  defaultHouseholdId: number;
  autoRoute: boolean;
  
  // Audit options
  enableAuditLog: boolean;
  retainProcessedInputs: boolean;
  retentionDays: number;
}

export interface RouteDecision {
  handler: string;
  priority: number;
  reason: string;
  confidence: number;
  metadata?: Record<string, any>;
}

export type InputHandler = (input: PipelineInput) => Promise<void>;

// ============================================================================
// INPUT PIPELINE
// ============================================================================

export class InputPipeline extends EventEmitter {
  private config: PipelineConfig;
  private inputProcessor: UniversalInputProcessor;
  private formatNormalizer: FormatNormalizer;
  private entityExtractor: EntityExtractor;
  private intentClassifier: IntentClassifier;
  private contextBuilder: ContextBuilder;
  private connectorManager: ConnectorManager;
  
  private handlers: Map<string, InputHandler> = new Map();
  private processingQueue: RawInput[] = [];
  private isProcessing: boolean = false;
  private activeProcessing: number = 0;
  
  // Audit log
  private auditLog: PipelineInput[] = [];
  private maxAuditLogSize: number = 10000;

  constructor(config?: Partial<PipelineConfig>) {
    super();
    
    this.config = {
      enableParallelProcessing: true,
      maxConcurrentInputs: 10,
      processingTimeout: 30000,
      skipNormalization: false,
      skipEntityExtraction: false,
      skipIntentClassification: false,
      skipContextBuilding: false,
      defaultHouseholdId: 1,
      autoRoute: true,
      enableAuditLog: true,
      retainProcessedInputs: true,
      retentionDays: 30,
      ...config,
    };

    // Initialize components
    this.inputProcessor = new UniversalInputProcessor();
    this.formatNormalizer = new FormatNormalizer();
    this.entityExtractor = new EntityExtractor();
    this.intentClassifier = new IntentClassifier();
    this.contextBuilder = new ContextBuilder();
    this.connectorManager = new ConnectorManager();

    // Set up connector event handling
    this.connectorManager.on('item', ({ connectorId, item }) => {
      this.enqueue(item);
    });

    // Register default handlers
    this.registerDefaultHandlers();
  }

  // -------------------------------------------------------------------------
  // HANDLER REGISTRATION
  // -------------------------------------------------------------------------

  registerHandler(name: string, handler: InputHandler): void {
    this.handlers.set(name, handler);
    console.log(`[InputPipeline] Registered handler: ${name}`);
  }

  unregisterHandler(name: string): void {
    this.handlers.delete(name);
  }

  private registerDefaultHandlers(): void {
    // Emergency handler - highest priority
    this.registerHandler('emergency', async (input) => {
      if (input.intent.primary === 'emergency' || input.intent.primary === 'urgent') {
        console.log(`[EMERGENCY] Processing emergency input: ${input.pipeline.id}`);
        this.emit('emergency', input);
      }
    });

    // Financial handler
    this.registerHandler('financial', async (input) => {
      if (input.intent.domain.primary === 'financial' || input.entities.money.length > 0) {
        console.log(`[Financial] Processing financial input: ${input.pipeline.id}`);
        this.emit('financial', input);
      }
    });

    // Scheduling handler
    this.registerHandler('scheduling', async (input) => {
      if (input.intent.domain.primary === 'scheduling' || input.entities.events.length > 0) {
        console.log(`[Scheduling] Processing scheduling input: ${input.pipeline.id}`);
        this.emit('scheduling', input);
      }
    });

    // Communication handler
    this.registerHandler('communication', async (input) => {
      if (input.intent.response.requiresResponse) {
        console.log(`[Communication] Processing communication input: ${input.pipeline.id}`);
        this.emit('communication', input);
      }
    });

    // Task handler
    this.registerHandler('task', async (input) => {
      if (input.entities.tasks.length > 0) {
        console.log(`[Task] Processing task input: ${input.pipeline.id}`);
        this.emit('task', input);
      }
    });

    // Default handler - catch all
    this.registerHandler('default', async (input) => {
      console.log(`[Default] Processing input: ${input.pipeline.id}`);
      this.emit('processed', input);
    });
  }

  // -------------------------------------------------------------------------
  // CONNECTOR MANAGEMENT
  // -------------------------------------------------------------------------

  addConnector(config: ConnectorConfig): BaseConnector | null {
    return this.connectorManager.createConnector(config);
  }

  removeConnector(id: string): Promise<void> {
    return this.connectorManager.removeConnector(id);
  }

  getConnector(id: string): BaseConnector | undefined {
    return this.connectorManager.getConnector(id);
  }

  startConnectors(): void {
    this.connectorManager.startAllPolling();
  }

  stopConnectors(): void {
    this.connectorManager.stopAllPolling();
  }

  // -------------------------------------------------------------------------
  // INPUT PROCESSING
  // -------------------------------------------------------------------------

  async process(raw: RawInput, householdId?: number): Promise<PipelineInput> {
    const pipelineId = this.generatePipelineId();
    const startTime = new Date();
    const stages: PipelineStage[] = [];
    const errors: PipelineError[] = [];

    let normalized: NormalizedContent | undefined;
    let entities: ExtractedEntities | undefined;
    let intent: ClassifiedIntent | undefined;
    let context: InputContext | undefined;

    try {
      // Stage 1: Normalize format
      if (!this.config.skipNormalization) {
        const stageStart = new Date();
        try {
          normalized = await this.formatNormalizer.normalize(raw.rawData, raw.format);
          stages.push({
            name: 'normalization',
            startedAt: stageStart,
            completedAt: new Date(),
            duration: Date.now() - stageStart.getTime(),
            success: true,
          });
        } catch (error) {
          stages.push({
            name: 'normalization',
            startedAt: stageStart,
            completedAt: new Date(),
            duration: Date.now() - stageStart.getTime(),
            success: false,
            error: String(error),
          });
          errors.push({
            stage: 'normalization',
            error: String(error),
            recoverable: true,
            timestamp: new Date(),
          });
          // Use fallback normalization
          normalized = {
            text: typeof raw.rawData === 'string' ? raw.rawData : JSON.stringify(raw.rawData),
            metadata: {
              originalFormat: raw.format,
              normalizedAt: new Date(),
              processingTime: 0,
              confidence: 0.3,
              warnings: ['Fallback normalization used'],
            },
          };
        }
      } else {
        normalized = {
          text: typeof raw.rawData === 'string' ? raw.rawData : JSON.stringify(raw.rawData),
          metadata: {
            originalFormat: raw.format,
            normalizedAt: new Date(),
            processingTime: 0,
            confidence: 1,
            warnings: [],
          },
        };
      }

      // Stage 2: Extract entities
      if (!this.config.skipEntityExtraction) {
        const stageStart = new Date();
        try {
          entities = await this.entityExtractor.extract(normalized.text);
          stages.push({
            name: 'entity_extraction',
            startedAt: stageStart,
            completedAt: new Date(),
            duration: Date.now() - stageStart.getTime(),
            success: true,
          });
        } catch (error) {
          stages.push({
            name: 'entity_extraction',
            startedAt: stageStart,
            completedAt: new Date(),
            duration: Date.now() - stageStart.getTime(),
            success: false,
            error: String(error),
          });
          errors.push({
            stage: 'entity_extraction',
            error: String(error),
            recoverable: true,
            timestamp: new Date(),
          });
          entities = this.getEmptyEntities();
        }
      } else {
        entities = this.getEmptyEntities();
      }

      // Stage 3: Classify intent
      if (!this.config.skipIntentClassification) {
        const stageStart = new Date();
        try {
          intent = await this.intentClassifier.classify(normalized.text, {
            source: raw.source,
            format: raw.format,
          });
          stages.push({
            name: 'intent_classification',
            startedAt: stageStart,
            completedAt: new Date(),
            duration: Date.now() - stageStart.getTime(),
            success: true,
          });
        } catch (error) {
          stages.push({
            name: 'intent_classification',
            startedAt: stageStart,
            completedAt: new Date(),
            duration: Date.now() - stageStart.getTime(),
            success: false,
            error: String(error),
          });
          errors.push({
            stage: 'intent_classification',
            error: String(error),
            recoverable: true,
            timestamp: new Date(),
          });
          intent = this.getDefaultIntent();
        }
      } else {
        intent = this.getDefaultIntent();
      }

      // Stage 4: Build context
      const effectiveHouseholdId = householdId || this.config.defaultHouseholdId;
      if (!this.config.skipContextBuilding) {
        const stageStart = new Date();
        try {
          // Create a minimal ProcessedInput for context building
          const processedInput: ProcessedInput = {
            id: pipelineId,
            originalInputId: raw.id,
            source: raw.source,
            format: raw.format,
            priority: 'normal',
            category: 'communication',
            content: {
              text: normalized.text,
              html: normalized.html,
              structured: normalized.structured,
            },
            entities: {
              people: entities.people.map(p => ({
                name: p.name,
                email: p.email,
                phone: p.phone,
                confidence: p.confidence,
              })),
              organizations: entities.organizations.map(o => ({
                name: o.name,
                type: o.type,
                confidence: o.confidence,
              })),
              locations: entities.locations.map(l => ({
                name: l.name,
                address: l.address?.street,
                coordinates: l.coordinates,
                confidence: l.confidence,
              })),
              dates: entities.dates.map(d => ({
                text: d.text,
                parsed: d.parsed!,
                isRange: d.isRange || false,
                isRecurring: d.isRecurring || false,
                confidence: d.confidence,
              })),
              money: entities.money.map(m => ({
                amount: m.amount,
                currency: m.currency,
                text: m.text,
                type: m.type,
                confidence: m.confidence,
              })),
              contacts: entities.contacts.map(c => ({
                type: c.type,
                value: c.value,
                label: c.label,
                confidence: c.confidence,
              })),
              events: entities.events.map(e => ({
                title: e.title,
                startDate: e.startDate,
                endDate: e.endDate,
                location: e.location,
                confidence: e.confidence,
              })),
              tasks: entities.tasks.map(t => ({
                description: t.description,
                dueDate: t.dueDate,
                priority: t.priority,
                confidence: t.confidence,
              })),
            },
            context: {
              urgency: intent.sentiment.urgency > 0.7 ? 'immediate' : 
                       intent.sentiment.urgency > 0.4 ? 'today' : 'no_deadline',
              sentiment: {
                overall: intent.sentiment.overall,
                score: intent.sentiment.score,
                emotions: intent.sentiment.emotions,
              },
              intent: {
                primary: intent.primary,
                confidence: intent.primaryConfidence,
                requiresAction: intent.action.requiresAction,
                requiresResponse: intent.response.requiresResponse,
                isQuestion: intent.primary === 'ask' || intent.primary === 'inquire',
                isRequest: intent.primary === 'request',
                isInformational: intent.primary === 'inform' || intent.primary === 'notify',
              },
            },
            processing: {
              startedAt: startTime,
              completedAt: new Date(),
              processors: ['pipeline'],
              confidence: 0.8,
              warnings: [],
              errors: [],
            },
          };

          context = await this.contextBuilder.buildContext(
            processedInput,
            entities,
            effectiveHouseholdId
          );
          stages.push({
            name: 'context_building',
            startedAt: stageStart,
            completedAt: new Date(),
            duration: Date.now() - stageStart.getTime(),
            success: true,
          });
        } catch (error) {
          stages.push({
            name: 'context_building',
            startedAt: stageStart,
            completedAt: new Date(),
            duration: Date.now() - stageStart.getTime(),
            success: false,
            error: String(error),
          });
          errors.push({
            stage: 'context_building',
            error: String(error),
            recoverable: true,
            timestamp: new Date(),
          });
          context = this.getDefaultContext(pipelineId, effectiveHouseholdId);
        }
      } else {
        context = this.getDefaultContext(pipelineId, effectiveHouseholdId);
      }

      // Calculate overall confidence
      const confidence = this.calculatePipelineConfidence(
        normalized,
        entities,
        intent,
        context,
        errors
      );

      // Assemble pipeline input
      const pipelineInput: PipelineInput = {
        raw,
        normalized: normalized!,
        entities: entities!,
        intent: intent!,
        context: context!,
        pipeline: {
          id: pipelineId,
          startedAt: startTime,
          completedAt: new Date(),
          stages,
          errors,
          confidence,
        },
      };

      // Route to handlers
      if (this.config.autoRoute) {
        await this.route(pipelineInput);
      }

      // Audit log
      if (this.config.enableAuditLog) {
        this.addToAuditLog(pipelineInput);
      }

      // Emit completion event
      this.emit('complete', pipelineInput);

      return pipelineInput;
    } catch (error) {
      // Fatal error - create minimal pipeline input
      const fatalInput: PipelineInput = {
        raw,
        normalized: normalized || {
          text: '',
          metadata: {
            originalFormat: raw.format,
            normalizedAt: new Date(),
            processingTime: 0,
            confidence: 0,
            warnings: ['Fatal error during processing'],
          },
        },
        entities: entities || this.getEmptyEntities(),
        intent: intent || this.getDefaultIntent(),
        context: context || this.getDefaultContext(pipelineId, this.config.defaultHouseholdId),
        pipeline: {
          id: pipelineId,
          startedAt: startTime,
          completedAt: new Date(),
          stages,
          errors: [
            ...errors,
            {
              stage: 'pipeline',
              error: String(error),
              recoverable: false,
              timestamp: new Date(),
            },
          ],
          confidence: 0,
        },
      };

      this.emit('error', { input: fatalInput, error });
      return fatalInput;
    }
  }

  // -------------------------------------------------------------------------
  // ROUTING
  // -------------------------------------------------------------------------

  private async route(input: PipelineInput): Promise<void> {
    const decisions = this.makeRouteDecisions(input);
    
    // Sort by priority
    decisions.sort((a, b) => b.priority - a.priority);

    // Execute handlers
    for (const decision of decisions) {
      const handler = this.handlers.get(decision.handler);
      if (handler) {
        try {
          await handler(input);
        } catch (error) {
          console.error(`[InputPipeline] Handler ${decision.handler} failed:`, error);
        }
      }
    }
  }

  private makeRouteDecisions(input: PipelineInput): RouteDecision[] {
    const decisions: RouteDecision[] = [];

    // Emergency routing
    if (input.intent.primary === 'emergency' || input.intent.primary === 'urgent') {
      decisions.push({
        handler: 'emergency',
        priority: 100,
        reason: 'Emergency or urgent intent detected',
        confidence: input.intent.primaryConfidence,
      });
    }

    // Financial routing
    if (input.intent.domain.primary === 'financial' || input.entities.money.length > 0) {
      decisions.push({
        handler: 'financial',
        priority: 80,
        reason: 'Financial content detected',
        confidence: input.intent.domain.confidence,
      });
    }

    // Scheduling routing
    if (input.intent.domain.primary === 'scheduling' || 
        input.entities.events.length > 0 ||
        input.intent.primary === 'schedule') {
      decisions.push({
        handler: 'scheduling',
        priority: 70,
        reason: 'Scheduling content detected',
        confidence: input.intent.domain.confidence,
      });
    }

    // Communication routing
    if (input.intent.response.requiresResponse) {
      decisions.push({
        handler: 'communication',
        priority: 60,
        reason: 'Response required',
        confidence: 0.8,
      });
    }

    // Task routing
    if (input.entities.tasks.length > 0 || input.intent.action.requiresAction) {
      decisions.push({
        handler: 'task',
        priority: 50,
        reason: 'Tasks or actions detected',
        confidence: 0.7,
      });
    }

    // Always include default handler
    decisions.push({
      handler: 'default',
      priority: 0,
      reason: 'Default processing',
      confidence: 1,
    });

    return decisions;
  }

  // -------------------------------------------------------------------------
  // QUEUE MANAGEMENT
  // -------------------------------------------------------------------------

  enqueue(raw: RawInput): void {
    this.processingQueue.push(raw);
    this.emit('enqueued', raw);
    
    if (!this.isProcessing) {
      this.startProcessing();
    }
  }

  private async startProcessing(): Promise<void> {
    if (this.isProcessing) return;
    
    this.isProcessing = true;
    
    while (this.processingQueue.length > 0) {
      // Check concurrent limit
      if (this.activeProcessing >= this.config.maxConcurrentInputs) {
        await new Promise(resolve => setTimeout(resolve, 100));
        continue;
      }

      const raw = this.processingQueue.shift();
      if (!raw) continue;

      this.activeProcessing++;

      // Process with timeout
      const timeoutPromise = new Promise<never>((_, reject) => {
        setTimeout(() => reject(new Error('Processing timeout')), this.config.processingTimeout);
      });

      Promise.race([
        this.process(raw),
        timeoutPromise,
      ])
        .catch(error => {
          console.error(`[InputPipeline] Processing failed:`, error);
          this.emit('error', { raw, error });
        })
        .finally(() => {
          this.activeProcessing--;
        });
    }

    this.isProcessing = false;
  }

  getQueueLength(): number {
    return this.processingQueue.length;
  }

  getActiveProcessingCount(): number {
    return this.activeProcessing;
  }

  // -------------------------------------------------------------------------
  // AUDIT LOG
  // -------------------------------------------------------------------------

  private addToAuditLog(input: PipelineInput): void {
    if (!this.config.retainProcessedInputs) return;

    this.auditLog.push(input);

    // Trim if over max size
    if (this.auditLog.length > this.maxAuditLogSize) {
      this.auditLog = this.auditLog.slice(-this.maxAuditLogSize / 2);
    }
  }

  getAuditLog(limit?: number): PipelineInput[] {
    const log = [...this.auditLog].reverse();
    return limit ? log.slice(0, limit) : log;
  }

  searchAuditLog(query: {
    source?: InputSource;
    intent?: string;
    domain?: string;
    startDate?: Date;
    endDate?: Date;
  }): PipelineInput[] {
    return this.auditLog.filter(input => {
      if (query.source && input.raw.source !== query.source) return false;
      if (query.intent && input.intent.primary !== query.intent) return false;
      if (query.domain && input.intent.domain.primary !== query.domain) return false;
      if (query.startDate && input.pipeline.startedAt < query.startDate) return false;
      if (query.endDate && input.pipeline.startedAt > query.endDate) return false;
      return true;
    });
  }

  // -------------------------------------------------------------------------
  // HELPERS
  // -------------------------------------------------------------------------

  private generatePipelineId(): string {
    return `pipeline_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private getEmptyEntities(): ExtractedEntities {
    return {
      people: [],
      organizations: [],
      locations: [],
      dates: [],
      money: [],
      contacts: [],
      events: [],
      tasks: [],
      products: [],
      references: [],
      quantities: [],
      custom: [],
    };
  }

  private getDefaultIntent(): ClassifiedIntent {
    return {
      primary: 'unknown',
      primaryConfidence: 0.3,
      secondary: [],
      action: {
        requiresAction: false,
        actionUrgency: 'none',
        canBeAutomated: false,
        requiresApproval: false,
        requiresConfirmation: false,
      },
      response: {
        requiresResponse: false,
        responseUrgency: 'none',
        templateAvailable: false,
      },
      automation: {
        canAutomate: false,
        automationLevel: 'manual',
        automationConfidence: 0,
        blockers: [],
        suggestedAutomations: [],
      },
      sentiment: {
        overall: 'neutral',
        score: 0,
        urgency: 0,
        formality: 0.5,
        emotions: {},
        tone: {
          primary: 'neutral',
          characteristics: [],
        },
      },
      domain: {
        primary: 'general',
        secondary: [],
        confidence: 0.3,
        keywords: [],
      },
      overallConfidence: 0.3,
    };
  }

  private getDefaultContext(inputId: string, householdId: number): InputContext {
    return {
      inputId,
      timestamp: new Date(),
      household: {
        householdId,
        affectedMembers: [],
        relevantRules: [],
        activeScenarios: [],
        currentMode: 'normal',
      },
      participants: {
        recipients: [],
        mentioned: [],
        inferred: [],
      },
      temporal: {
        receivedAt: new Date(),
        timeOfDay: 'morning',
        dayOfWeek: new Date().toLocaleDateString('en-US', { weekday: 'long' }),
        isWeekend: [0, 6].includes(new Date().getDay()),
        isHoliday: false,
        hasDeadline: false,
        isRecurring: false,
        householdTimezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      },
      history: {
        relatedInputs: [],
        similarSituations: [],
        pastActions: [],
        learnedPatterns: [],
      },
      state: {
        householdState: {
          occupancy: 'home',
          presentMembers: [],
          activeDevices: [],
          securityStatus: 'disarmed',
          environmentalAlerts: [],
        },
        financialState: {
          recentTransactions: 0,
          unusualActivity: false,
          upcomingBills: 0,
          budgetStatus: 'on_track',
        },
        calendarState: {
          currentEvents: [],
          upcomingEvents: 0,
          conflicts: 0,
          busyLevel: 'light',
        },
        communicationState: {
          unreadMessages: 0,
          pendingResponses: 0,
          urgentItems: 0,
          averageResponseTime: 0,
        },
        systemState: {
          activeAutomations: [],
          pendingActions: 0,
          recentErrors: 0,
          healthStatus: 'healthy',
        },
      },
      predictions: {
        likelyActions: [],
        expectedFollowups: [],
        potentialIssues: [],
        recommendedResponses: [],
        overallConfidence: 0.3,
      },
      priority: {
        priority: 'low',
        urgency: 'no_deadline',
        factors: [],
      },
      confidence: 0.3,
    };
  }

  private calculatePipelineConfidence(
    normalized: NormalizedContent,
    entities: ExtractedEntities,
    intent: ClassifiedIntent,
    context: InputContext,
    errors: PipelineError[]
  ): number {
    let confidence = 0.5;

    // Normalization confidence
    confidence += normalized.metadata.confidence * 0.15;

    // Entity extraction (more entities = more confident)
    const entityCount = Object.values(entities).reduce((sum, arr) => sum + arr.length, 0);
    confidence += Math.min(entityCount * 0.02, 0.15);

    // Intent confidence
    confidence += intent.overallConfidence * 0.2;

    // Context confidence
    confidence += context.confidence * 0.15;

    // Penalty for errors
    confidence -= errors.length * 0.1;

    return Math.max(0, Math.min(1, confidence));
  }

  // -------------------------------------------------------------------------
  // STATISTICS
  // -------------------------------------------------------------------------

  getStatistics(): {
    totalProcessed: number;
    queueLength: number;
    activeProcessing: number;
    averageProcessingTime: number;
    errorRate: number;
    intentDistribution: Record<string, number>;
    domainDistribution: Record<string, number>;
    sourceDistribution: Record<string, number>;
  } {
    const totalProcessed = this.auditLog.length;
    const queueLength = this.processingQueue.length;
    const activeProcessing = this.activeProcessing;

    // Calculate average processing time
    const processingTimes = this.auditLog
      .filter(i => i.pipeline.completedAt)
      .map(i => i.pipeline.completedAt!.getTime() - i.pipeline.startedAt.getTime());
    const averageProcessingTime = processingTimes.length > 0
      ? processingTimes.reduce((a, b) => a + b, 0) / processingTimes.length
      : 0;

    // Calculate error rate
    const errorCount = this.auditLog.filter(i => i.pipeline.errors.length > 0).length;
    const errorRate = totalProcessed > 0 ? errorCount / totalProcessed : 0;

    // Calculate distributions
    const intentDistribution: Record<string, number> = {};
    const domainDistribution: Record<string, number> = {};
    const sourceDistribution: Record<string, number> = {};

    for (const input of this.auditLog) {
      // Intent
      const intent = input.intent.primary;
      intentDistribution[intent] = (intentDistribution[intent] || 0) + 1;

      // Domain
      const domain = input.intent.domain.primary;
      domainDistribution[domain] = (domainDistribution[domain] || 0) + 1;

      // Source
      const source = input.raw.source;
      sourceDistribution[source] = (sourceDistribution[source] || 0) + 1;
    }

    return {
      totalProcessed,
      queueLength,
      activeProcessing,
      averageProcessingTime,
      errorRate,
      intentDistribution,
      domainDistribution,
      sourceDistribution,
    };
  }
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

export const inputPipeline = new InputPipeline();
