/**
 * Entity Extractor
 * 
 * Extracts all meaningful entities from any text input:
 * - People, organizations, locations
 * - Dates, times, durations
 * - Money, quantities, measurements
 * - Contacts (email, phone, address)
 * - Events, tasks, deadlines
 * - Products, services, references
 */

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

export interface ExtractedEntities {
  people: PersonEntity[];
  organizations: OrganizationEntity[];
  locations: LocationEntity[];
  dates: DateTimeEntity[];
  money: MoneyEntity[];
  contacts: ContactEntity[];
  events: EventEntity[];
  tasks: TaskEntity[];
  products: ProductEntity[];
  references: ReferenceEntity[];
  quantities: QuantityEntity[];
  custom: CustomEntity[];
}

export interface PersonEntity {
  name: string;
  firstName?: string;
  lastName?: string;
  title?: string;
  role?: string;
  email?: string;
  phone?: string;
  relationship?: string;
  confidence: number;
  source: string;
  position: { start: number; end: number };
}

export interface OrganizationEntity {
  name: string;
  type?: 'company' | 'government' | 'nonprofit' | 'school' | 'hospital' | 'other';
  industry?: string;
  website?: string;
  confidence: number;
  source: string;
  position: { start: number; end: number };
}

export interface LocationEntity {
  name: string;
  type?: 'address' | 'city' | 'state' | 'country' | 'landmark' | 'business' | 'other';
  address?: {
    street?: string;
    city?: string;
    state?: string;
    zip?: string;
    country?: string;
  };
  coordinates?: { lat: number; lng: number };
  confidence: number;
  source: string;
  position: { start: number; end: number };
}

export interface DateTimeEntity {
  text: string;
  type: 'date' | 'time' | 'datetime' | 'duration' | 'range' | 'relative' | 'recurring';
  parsed?: Date;
  endDate?: Date;
  duration?: number; // milliseconds
  recurrence?: {
    frequency: 'daily' | 'weekly' | 'monthly' | 'yearly';
    interval: number;
    until?: Date;
    count?: number;
  };
  timezone?: string;
  isAllDay?: boolean;
  confidence: number;
  source: string;
  position: { start: number; end: number };
}

export interface MoneyEntity {
  amount: number;
  currency: string;
  text: string;
  type?: 'price' | 'payment' | 'bill' | 'income' | 'expense' | 'transfer' | 'fee' | 'tip';
  isEstimate?: boolean;
  isRange?: boolean;
  minAmount?: number;
  maxAmount?: number;
  confidence: number;
  source: string;
  position: { start: number; end: number };
}

export interface ContactEntity {
  type: 'email' | 'phone' | 'address' | 'url' | 'social' | 'fax';
  value: string;
  label?: string;
  isPrimary?: boolean;
  isVerified?: boolean;
  confidence: number;
  source: string;
  position: { start: number; end: number };
}

export interface EventEntity {
  title: string;
  type?: 'meeting' | 'appointment' | 'deadline' | 'reminder' | 'birthday' | 'holiday' | 'travel' | 'social' | 'other';
  startDate?: Date;
  endDate?: Date;
  isAllDay?: boolean;
  location?: string;
  attendees?: string[];
  organizer?: string;
  description?: string;
  confidence: number;
  source: string;
  position: { start: number; end: number };
}

export interface TaskEntity {
  description: string;
  type?: 'todo' | 'action' | 'follow-up' | 'request' | 'reminder';
  dueDate?: Date;
  assignee?: string;
  assigner?: string;
  priority?: 'high' | 'medium' | 'low';
  status?: 'pending' | 'in-progress' | 'completed' | 'cancelled';
  confidence: number;
  source: string;
  position: { start: number; end: number };
}

export interface ProductEntity {
  name: string;
  type?: 'product' | 'service' | 'subscription';
  brand?: string;
  model?: string;
  sku?: string;
  price?: number;
  currency?: string;
  confidence: number;
  source: string;
  position: { start: number; end: number };
}

export interface ReferenceEntity {
  type: 'order' | 'invoice' | 'ticket' | 'confirmation' | 'tracking' | 'account' | 'case' | 'other';
  value: string;
  label?: string;
  confidence: number;
  source: string;
  position: { start: number; end: number };
}

export interface QuantityEntity {
  value: number;
  unit: string;
  type?: 'count' | 'weight' | 'volume' | 'length' | 'area' | 'temperature' | 'percentage' | 'other';
  text: string;
  confidence: number;
  source: string;
  position: { start: number; end: number };
}

export interface CustomEntity {
  type: string;
  value: string;
  metadata?: Record<string, any>;
  confidence: number;
  source: string;
  position: { start: number; end: number };
}

// ============================================================================
// ENTITY EXTRACTOR
// ============================================================================

export class EntityExtractor {
  private extractors: EntityExtractorFunction[] = [];

  constructor() {
    this.registerDefaultExtractors();
  }

  private registerDefaultExtractors(): void {
    this.extractors.push(
      this.extractEmails.bind(this),
      this.extractPhones.bind(this),
      this.extractUrls.bind(this),
      this.extractMoney.bind(this),
      this.extractDates.bind(this),
      this.extractTimes.bind(this),
      this.extractAddresses.bind(this),
      this.extractPeople.bind(this),
      this.extractOrganizations.bind(this),
      this.extractTasks.bind(this),
      this.extractEvents.bind(this),
      this.extractReferences.bind(this),
      this.extractQuantities.bind(this),
    );
  }

  async extract(text: string): Promise<ExtractedEntities> {
    const entities: ExtractedEntities = {
      people: [],
      organizations: [],
      locations: [],
      dates: [],
      money: [],
      contacts: [],
      events: [],
      tasks: [],
      products: [],
      references: [],
      quantities: [],
      custom: [],
    };

    // Run all extractors
    for (const extractor of this.extractors) {
      try {
        const extracted = await extractor(text);
        this.mergeEntities(entities, extracted);
      } catch (error) {
        console.error(`[EntityExtractor] Extractor failed:`, error);
      }
    }

    // Deduplicate and resolve conflicts
    this.deduplicateEntities(entities);

    // Link related entities
    this.linkEntities(entities);

    return entities;
  }

  private mergeEntities(target: ExtractedEntities, source: Partial<ExtractedEntities>): void {
    for (const key of Object.keys(source) as (keyof ExtractedEntities)[]) {
      if (source[key]) {
        (target[key] as any[]).push(...(source[key] as any[]));
      }
    }
  }

  private deduplicateEntities(entities: ExtractedEntities): void {
    // Deduplicate contacts by value
    entities.contacts = this.deduplicateByField(entities.contacts, 'value');
    
    // Deduplicate people by name (case-insensitive)
    entities.people = this.deduplicateByField(entities.people, 'name', true);
    
    // Deduplicate organizations by name
    entities.organizations = this.deduplicateByField(entities.organizations, 'name', true);
    
    // Deduplicate money by position (same text shouldn't be extracted twice)
    entities.money = this.deduplicateByPosition(entities.money);
    
    // Deduplicate dates by position
    entities.dates = this.deduplicateByPosition(entities.dates);
  }

  private deduplicateByField<T extends { confidence: number }>(
    items: T[],
    field: keyof T,
    caseInsensitive: boolean = false
  ): T[] {
    const seen = new Map<string, T>();
    
    for (const item of items) {
      let key = String(item[field]);
      if (caseInsensitive) key = key.toLowerCase();
      
      const existing = seen.get(key);
      if (!existing || item.confidence > existing.confidence) {
        seen.set(key, item);
      }
    }
    
    return Array.from(seen.values());
  }

  private deduplicateByPosition<T extends { position: { start: number; end: number }; confidence: number }>(
    items: T[]
  ): T[] {
    const seen = new Map<string, T>();
    
    for (const item of items) {
      const key = `${item.position.start}-${item.position.end}`;
      const existing = seen.get(key);
      if (!existing || item.confidence > existing.confidence) {
        seen.set(key, item);
      }
    }
    
    return Array.from(seen.values());
  }

  private linkEntities(entities: ExtractedEntities): void {
    // Link emails to people
    for (const contact of entities.contacts) {
      if (contact.type === 'email') {
        const emailName = contact.value.split('@')[0].replace(/[._]/g, ' ');
        for (const person of entities.people) {
          if (person.name.toLowerCase().includes(emailName.toLowerCase()) ||
              emailName.toLowerCase().includes(person.name.toLowerCase().split(' ')[0])) {
            person.email = contact.value;
          }
        }
      }
    }

    // Link phones to people (if mentioned near each other)
    // This would require more sophisticated proximity analysis
  }

  // -------------------------------------------------------------------------
  // INDIVIDUAL EXTRACTORS
  // -------------------------------------------------------------------------

  private async extractEmails(text: string): Promise<Partial<ExtractedEntities>> {
    const contacts: ContactEntity[] = [];
    const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g;
    
    let match;
    while ((match = emailRegex.exec(text)) !== null) {
      contacts.push({
        type: 'email',
        value: match[0].toLowerCase(),
        confidence: 0.95,
        source: 'regex',
        position: { start: match.index, end: match.index + match[0].length },
      });
    }
    
    return { contacts };
  }

  private async extractPhones(text: string): Promise<Partial<ExtractedEntities>> {
    const contacts: ContactEntity[] = [];
    
    // Various phone formats
    const phonePatterns = [
      /\b\+?1?[-.\s]?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}\b/g,
      /\b\+?[0-9]{1,3}[-.\s]?[0-9]{2,4}[-.\s]?[0-9]{3,4}[-.\s]?[0-9]{3,4}\b/g,
    ];
    
    for (const pattern of phonePatterns) {
      let match;
      while ((match = pattern.exec(text)) !== null) {
        const cleaned = match[0].replace(/[^\d+]/g, '');
        if (cleaned.length >= 10 && cleaned.length <= 15) {
          contacts.push({
            type: 'phone',
            value: match[0],
            confidence: 0.85,
            source: 'regex',
            position: { start: match.index, end: match.index + match[0].length },
          });
        }
      }
    }
    
    return { contacts };
  }

  private async extractUrls(text: string): Promise<Partial<ExtractedEntities>> {
    const contacts: ContactEntity[] = [];
    const urlRegex = /https?:\/\/[^\s<>"{}|\\^`\[\]]+/gi;
    
    let match;
    while ((match = urlRegex.exec(text)) !== null) {
      contacts.push({
        type: 'url',
        value: match[0],
        confidence: 0.95,
        source: 'regex',
        position: { start: match.index, end: match.index + match[0].length },
      });
    }
    
    return { contacts };
  }

  private async extractMoney(text: string): Promise<Partial<ExtractedEntities>> {
    const money: MoneyEntity[] = [];
    
    // Currency patterns
    const patterns = [
      // $1,234.56 or $1234.56 or $1,234
      { regex: /\$\s?[\d,]+\.?\d*/g, currency: 'USD' },
      // USD 1,234.56
      { regex: /USD\s?[\d,]+\.?\d*/gi, currency: 'USD' },
      // €1,234.56
      { regex: /€\s?[\d,]+\.?\d*/g, currency: 'EUR' },
      // £1,234.56
      { regex: /£\s?[\d,]+\.?\d*/g, currency: 'GBP' },
      // ¥1,234
      { regex: /¥\s?[\d,]+\.?\d*/g, currency: 'JPY' },
      // 1,234.56 USD/EUR/GBP
      { regex: /[\d,]+\.?\d*\s?(USD|EUR|GBP|CAD|AUD)/gi, currency: 'DETECT' },
    ];
    
    for (const { regex, currency } of patterns) {
      let match;
      while ((match = regex.exec(text)) !== null) {
        const amountStr = match[0].replace(/[^\d.]/g, '');
        const amount = parseFloat(amountStr);
        
        if (!isNaN(amount) && amount > 0) {
          let detectedCurrency = currency;
          if (currency === 'DETECT') {
            const currMatch = match[0].match(/USD|EUR|GBP|CAD|AUD/i);
            detectedCurrency = currMatch ? currMatch[0].toUpperCase() : 'USD';
          }
          
          money.push({
            amount,
            currency: detectedCurrency,
            text: match[0],
            confidence: 0.9,
            source: 'regex',
            position: { start: match.index, end: match.index + match[0].length },
          });
        }
      }
    }
    
    return { money };
  }

  private async extractDates(text: string): Promise<Partial<ExtractedEntities>> {
    const dates: DateTimeEntity[] = [];
    
    // Various date patterns
    const patterns = [
      // MM/DD/YYYY or MM-DD-YYYY
      { regex: /\b(0?[1-9]|1[0-2])[\/\-](0?[1-9]|[12]\d|3[01])[\/\-](\d{2,4})\b/g, type: 'date' as const },
      // YYYY-MM-DD (ISO)
      { regex: /\b(\d{4})-(0?[1-9]|1[0-2])-(0?[1-9]|[12]\d|3[01])\b/g, type: 'date' as const },
      // Month DD, YYYY
      { regex: /\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{1,2})(?:st|nd|rd|th)?,?\s*(\d{4})?\b/gi, type: 'date' as const },
      // DD Month YYYY
      { regex: /\b(\d{1,2})(?:st|nd|rd|th)?\s+(January|February|March|April|May|June|July|August|September|October|November|December),?\s*(\d{4})?\b/gi, type: 'date' as const },
      // Relative dates
      { regex: /\b(today|tomorrow|yesterday|next\s+(?:week|month|year)|last\s+(?:week|month|year))\b/gi, type: 'relative' as const },
      // Day of week
      { regex: /\b(next\s+)?(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\b/gi, type: 'relative' as const },
      // In X days/weeks/months
      { regex: /\bin\s+(\d+)\s+(day|week|month|year)s?\b/gi, type: 'relative' as const },
    ];
    
    for (const { regex, type } of patterns) {
      let match;
      while ((match = regex.exec(text)) !== null) {
        const parsed = this.parseDate(match[0]);
        
        dates.push({
          text: match[0],
          type,
          parsed,
          confidence: parsed ? 0.85 : 0.6,
          source: 'regex',
          position: { start: match.index, end: match.index + match[0].length },
        });
      }
    }
    
    return { dates };
  }

  private parseDate(text: string): Date | undefined {
    const now = new Date();
    const lowerText = text.toLowerCase();
    
    // Handle relative dates
    if (lowerText === 'today') return now;
    if (lowerText === 'tomorrow') {
      const d = new Date(now);
      d.setDate(d.getDate() + 1);
      return d;
    }
    if (lowerText === 'yesterday') {
      const d = new Date(now);
      d.setDate(d.getDate() - 1);
      return d;
    }
    
    // Handle "next week/month/year"
    if (lowerText.includes('next week')) {
      const d = new Date(now);
      d.setDate(d.getDate() + 7);
      return d;
    }
    if (lowerText.includes('next month')) {
      const d = new Date(now);
      d.setMonth(d.getMonth() + 1);
      return d;
    }
    
    // Handle "in X days/weeks/months"
    const inMatch = lowerText.match(/in\s+(\d+)\s+(day|week|month|year)s?/);
    if (inMatch) {
      const num = parseInt(inMatch[1]);
      const unit = inMatch[2];
      const d = new Date(now);
      
      switch (unit) {
        case 'day': d.setDate(d.getDate() + num); break;
        case 'week': d.setDate(d.getDate() + num * 7); break;
        case 'month': d.setMonth(d.getMonth() + num); break;
        case 'year': d.setFullYear(d.getFullYear() + num); break;
      }
      return d;
    }
    
    // Try standard date parsing
    const parsed = new Date(text);
    if (!isNaN(parsed.getTime())) {
      return parsed;
    }
    
    return undefined;
  }

  private async extractTimes(text: string): Promise<Partial<ExtractedEntities>> {
    const dates: DateTimeEntity[] = [];
    
    // Time patterns
    const patterns = [
      // 12-hour format: 3:30 PM, 3:30pm, 3pm
      /\b(1[0-2]|0?[1-9])(?::([0-5]\d))?\s*(am|pm|AM|PM)\b/g,
      // 24-hour format: 15:30, 08:00
      /\b([01]?\d|2[0-3]):([0-5]\d)(?::([0-5]\d))?\b/g,
    ];
    
    for (const pattern of patterns) {
      let match;
      while ((match = pattern.exec(text)) !== null) {
        dates.push({
          text: match[0],
          type: 'time',
          confidence: 0.9,
          source: 'regex',
          position: { start: match.index, end: match.index + match[0].length },
        });
      }
    }
    
    return { dates };
  }

  private async extractAddresses(text: string): Promise<Partial<ExtractedEntities>> {
    const locations: LocationEntity[] = [];
    
    // US address pattern (simplified)
    const addressPattern = /\b\d+\s+[\w\s]+(?:Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Drive|Dr|Lane|Ln|Way|Court|Ct|Circle|Cir)\.?,?\s*(?:(?:Apt|Suite|Unit|#)\s*[\w\d-]+)?,?\s*[\w\s]+,?\s*[A-Z]{2}\s*\d{5}(?:-\d{4})?\b/gi;
    
    let match;
    while ((match = addressPattern.exec(text)) !== null) {
      locations.push({
        name: match[0],
        type: 'address',
        confidence: 0.8,
        source: 'regex',
        position: { start: match.index, end: match.index + match[0].length },
      });
    }
    
    // ZIP code only
    const zipPattern = /\b\d{5}(?:-\d{4})?\b/g;
    while ((match = zipPattern.exec(text)) !== null) {
      // Check if this ZIP isn't already part of a full address
      const isPartOfAddress = locations.some(loc => 
        match!.index >= loc.position.start && match!.index <= loc.position.end
      );
      
      if (!isPartOfAddress) {
        locations.push({
          name: match[0],
          type: 'address',
          address: { zip: match[0] },
          confidence: 0.5,
          source: 'regex',
          position: { start: match.index, end: match.index + match[0].length },
        });
      }
    }
    
    return { locations };
  }

  private async extractPeople(text: string): Promise<Partial<ExtractedEntities>> {
    const people: PersonEntity[] = [];
    
    // Common name patterns
    // Title + Name
    const titlePattern = /\b(Mr|Mrs|Ms|Miss|Dr|Prof|Sir|Madam)\.?\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b/g;
    
    let match;
    while ((match = titlePattern.exec(text)) !== null) {
      const nameParts = match[2].split(/\s+/);
      people.push({
        name: match[2],
        title: match[1],
        firstName: nameParts[0],
        lastName: nameParts.length > 1 ? nameParts[nameParts.length - 1] : undefined,
        confidence: 0.85,
        source: 'regex',
        position: { start: match.index, end: match.index + match[0].length },
      });
    }
    
    // Capitalized names (two or more words)
    const namePattern = /\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\b/g;
    while ((match = namePattern.exec(text)) !== null) {
      // Skip if already captured with title
      const alreadyCaptured = people.some(p => 
        match!.index >= p.position.start && match!.index <= p.position.end
      );
      
      if (!alreadyCaptured) {
        const nameParts = match[1].split(/\s+/);
        // Filter out common non-name phrases
        const nonNames = ['The', 'This', 'That', 'These', 'Those', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        if (!nonNames.includes(nameParts[0])) {
          people.push({
            name: match[1],
            firstName: nameParts[0],
            lastName: nameParts.length > 1 ? nameParts[nameParts.length - 1] : undefined,
            confidence: 0.6,
            source: 'regex',
            position: { start: match.index, end: match.index + match[0].length },
          });
        }
      }
    }
    
    return { people };
  }

  private async extractOrganizations(text: string): Promise<Partial<ExtractedEntities>> {
    const organizations: OrganizationEntity[] = [];
    
    // Company suffixes
    const companyPattern = /\b([A-Z][\w\s&]+(?:Inc|LLC|Ltd|Corp|Corporation|Company|Co|Group|Holdings|Partners|Associates|Services|Solutions|Technologies|Tech|Labs|Studio|Agency|Consulting))\.?\b/g;
    
    let match;
    while ((match = companyPattern.exec(text)) !== null) {
      organizations.push({
        name: match[1],
        type: 'company',
        confidence: 0.85,
        source: 'regex',
        position: { start: match.index, end: match.index + match[0].length },
      });
    }
    
    // Known organization patterns
    const knownPatterns = [
      { regex: /\b(University of [\w\s]+|[\w\s]+ University)\b/gi, type: 'school' as const },
      { regex: /\b([\w\s]+ Hospital|[\w\s]+ Medical Center)\b/gi, type: 'hospital' as const },
      { regex: /\b(Department of [\w\s]+)\b/gi, type: 'government' as const },
    ];
    
    for (const { regex, type } of knownPatterns) {
      while ((match = regex.exec(text)) !== null) {
        organizations.push({
          name: match[1],
          type,
          confidence: 0.8,
          source: 'regex',
          position: { start: match.index, end: match.index + match[0].length },
        });
      }
    }
    
    return { organizations };
  }

  private async extractTasks(text: string): Promise<Partial<ExtractedEntities>> {
    const tasks: TaskEntity[] = [];
    
    // Task indicators
    const patterns = [
      { regex: /\bplease\s+(.+?)(?:\.|$)/gi, type: 'request' as const },
      { regex: /\bcould you\s+(.+?)(?:\.|$)/gi, type: 'request' as const },
      { regex: /\bcan you\s+(.+?)(?:\.|$)/gi, type: 'request' as const },
      { regex: /\bwould you\s+(.+?)(?:\.|$)/gi, type: 'request' as const },
      { regex: /\bneed to\s+(.+?)(?:\.|$)/gi, type: 'todo' as const },
      { regex: /\bhave to\s+(.+?)(?:\.|$)/gi, type: 'todo' as const },
      { regex: /\bmust\s+(.+?)(?:\.|$)/gi, type: 'todo' as const },
      { regex: /\breminder:\s*(.+?)(?:\.|$)/gi, type: 'reminder' as const },
      { regex: /\btodo:\s*(.+?)(?:\.|$)/gi, type: 'todo' as const },
      { regex: /\baction item:\s*(.+?)(?:\.|$)/gi, type: 'action' as const },
      { regex: /\bfollow up\s+(?:on\s+)?(.+?)(?:\.|$)/gi, type: 'follow-up' as const },
    ];
    
    for (const { regex, type } of patterns) {
      let match;
      while ((match = regex.exec(text)) !== null) {
        tasks.push({
          description: match[1].trim(),
          type,
          confidence: 0.7,
          source: 'regex',
          position: { start: match.index, end: match.index + match[0].length },
        });
      }
    }
    
    return { tasks };
  }

  private async extractEvents(text: string): Promise<Partial<ExtractedEntities>> {
    const events: EventEntity[] = [];
    
    // Event patterns
    const patterns = [
      { regex: /\bmeeting\s+(?:with\s+)?(.+?)(?:\s+(?:at|on)\s+.+)?(?:\.|$)/gi, type: 'meeting' as const },
      { regex: /\bappointment\s+(?:with\s+)?(.+?)(?:\s+(?:at|on)\s+.+)?(?:\.|$)/gi, type: 'appointment' as const },
      { regex: /\bcall\s+(?:with\s+)?(.+?)(?:\s+(?:at|on)\s+.+)?(?:\.|$)/gi, type: 'meeting' as const },
      { regex: /\bdeadline\s+(?:for\s+)?(.+?)(?:\s+(?:is|on)\s+.+)?(?:\.|$)/gi, type: 'deadline' as const },
      { regex: /\bbirthday\s+(?:of\s+|for\s+)?(.+?)(?:\s+(?:is|on)\s+.+)?(?:\.|$)/gi, type: 'birthday' as const },
    ];
    
    for (const { regex, type } of patterns) {
      let match;
      while ((match = regex.exec(text)) !== null) {
        events.push({
          title: match[1].trim(),
          type,
          confidence: 0.65,
          source: 'regex',
          position: { start: match.index, end: match.index + match[0].length },
        });
      }
    }
    
    return { events };
  }

  private async extractReferences(text: string): Promise<Partial<ExtractedEntities>> {
    const references: ReferenceEntity[] = [];
    
    // Reference number patterns
    const patterns = [
      { regex: /\border\s*#?\s*([A-Z0-9-]+)/gi, type: 'order' as const },
      { regex: /\binvoice\s*#?\s*([A-Z0-9-]+)/gi, type: 'invoice' as const },
      { regex: /\bticket\s*#?\s*([A-Z0-9-]+)/gi, type: 'ticket' as const },
      { regex: /\bconfirmation\s*#?\s*([A-Z0-9-]+)/gi, type: 'confirmation' as const },
      { regex: /\btracking\s*#?\s*([A-Z0-9-]+)/gi, type: 'tracking' as const },
      { regex: /\baccount\s*#?\s*([A-Z0-9-]+)/gi, type: 'account' as const },
      { regex: /\bcase\s*#?\s*([A-Z0-9-]+)/gi, type: 'case' as const },
      { regex: /\breference\s*#?\s*([A-Z0-9-]+)/gi, type: 'other' as const },
      { regex: /\b#([A-Z0-9-]{6,})\b/gi, type: 'other' as const },
    ];
    
    for (const { regex, type } of patterns) {
      let match;
      while ((match = regex.exec(text)) !== null) {
        references.push({
          type,
          value: match[1],
          confidence: 0.8,
          source: 'regex',
          position: { start: match.index, end: match.index + match[0].length },
        });
      }
    }
    
    return { references };
  }

  private async extractQuantities(text: string): Promise<Partial<ExtractedEntities>> {
    const quantities: QuantityEntity[] = [];
    
    // Quantity patterns
    const patterns = [
      { regex: /\b(\d+(?:\.\d+)?)\s*(lb|lbs|pound|pounds|kg|kilogram|kilograms|g|gram|grams|oz|ounce|ounces)\b/gi, type: 'weight' as const },
      { regex: /\b(\d+(?:\.\d+)?)\s*(ml|milliliter|milliliters|l|liter|liters|gal|gallon|gallons|fl oz|fluid ounce|fluid ounces)\b/gi, type: 'volume' as const },
      { regex: /\b(\d+(?:\.\d+)?)\s*(in|inch|inches|ft|foot|feet|m|meter|meters|cm|centimeter|centimeters|mm|millimeter|millimeters|mi|mile|miles|km|kilometer|kilometers)\b/gi, type: 'length' as const },
      { regex: /\b(\d+(?:\.\d+)?)\s*(sq ft|square feet|sq m|square meters|acres?)\b/gi, type: 'area' as const },
      { regex: /\b(\d+(?:\.\d+)?)\s*°?\s*(F|C|fahrenheit|celsius)\b/gi, type: 'temperature' as const },
      { regex: /\b(\d+(?:\.\d+)?)\s*%/g, type: 'percentage' as const },
    ];
    
    for (const { regex, type } of patterns) {
      let match;
      while ((match = regex.exec(text)) !== null) {
        quantities.push({
          value: parseFloat(match[1]),
          unit: match[2] || '%',
          type,
          text: match[0],
          confidence: 0.9,
          source: 'regex',
          position: { start: match.index, end: match.index + match[0].length },
        });
      }
    }
    
    return { quantities };
  }
}

type EntityExtractorFunction = (text: string) => Promise<Partial<ExtractedEntities>>;

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

export const entityExtractor = new EntityExtractor();
