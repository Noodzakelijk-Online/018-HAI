/**
 * Format Normalizer
 * 
 * Converts ANY input format into HAI's standardized internal format.
 * Handles text, documents, images, audio, video, structured data, and more.
 */

import { InputFormat } from './UniversalInputProcessor';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

export interface NormalizedContent {
  // Primary text content
  text: string;
  
  // HTML representation (if applicable)
  html?: string;
  
  // Structured data extracted
  structured?: {
    type: string;
    data: Record<string, any>;
    schema?: string;
  };
  
  // Metadata about the normalization
  metadata: {
    originalFormat: InputFormat;
    normalizedAt: Date;
    processingTime: number;
    confidence: number;
    warnings: string[];
  };
  
  // Extracted components
  components?: {
    headers?: Record<string, string>;
    body?: string;
    attachments?: NormalizedAttachment[];
    tables?: NormalizedTable[];
    images?: NormalizedImage[];
    links?: NormalizedLink[];
  };
}

export interface NormalizedAttachment {
  id: string;
  filename: string;
  mimeType: string;
  size: number;
  content?: NormalizedContent;
  url?: string;
}

export interface NormalizedTable {
  headers: string[];
  rows: string[][];
  caption?: string;
}

export interface NormalizedImage {
  id: string;
  alt?: string;
  caption?: string;
  ocrText?: string;
  objects?: string[];
  faces?: number;
}

export interface NormalizedLink {
  url: string;
  text: string;
  type: 'internal' | 'external' | 'email' | 'phone' | 'file';
}

// ============================================================================
// FORMAT NORMALIZER
// ============================================================================

export class FormatNormalizer {
  private normalizers: Map<InputFormat, FormatHandler> = new Map();

  constructor() {
    this.registerDefaultNormalizers();
  }

  private registerDefaultNormalizers(): void {
    // Text formats
    this.normalizers.set('plain_text', new PlainTextHandler());
    this.normalizers.set('html', new HTMLHandler());
    this.normalizers.set('markdown', new MarkdownHandler());
    this.normalizers.set('json', new JSONHandler());
    this.normalizers.set('xml', new XMLHandler());
    this.normalizers.set('yaml', new YAMLHandler());
    this.normalizers.set('csv', new CSVHandler());
    
    // Document formats
    this.normalizers.set('pdf', new PDFHandler());
    this.normalizers.set('docx', new DOCXHandler());
    this.normalizers.set('xlsx', new XLSXHandler());
    this.normalizers.set('pptx', new PPTXHandler());
    this.normalizers.set('rtf', new RTFHandler());
    
    // Image formats
    this.normalizers.set('jpeg', new ImageHandler());
    this.normalizers.set('png', new ImageHandler());
    this.normalizers.set('gif', new ImageHandler());
    this.normalizers.set('webp', new ImageHandler());
    this.normalizers.set('heic', new ImageHandler());
    this.normalizers.set('svg', new SVGHandler());
    
    // Audio formats
    this.normalizers.set('mp3', new AudioHandler());
    this.normalizers.set('wav', new AudioHandler());
    this.normalizers.set('aac', new AudioHandler());
    this.normalizers.set('ogg', new AudioHandler());
    this.normalizers.set('m4a', new AudioHandler());
    
    // Video formats
    this.normalizers.set('mp4', new VideoHandler());
    this.normalizers.set('mov', new VideoHandler());
    this.normalizers.set('avi', new VideoHandler());
    this.normalizers.set('webm', new VideoHandler());
    
    // Structured formats
    this.normalizers.set('vcard', new VCardHandler());
    this.normalizers.set('ical', new ICalHandler());
    this.normalizers.set('mime', new MIMEHandler());
    this.normalizers.set('qrcode', new QRCodeHandler());
    this.normalizers.set('barcode', new BarcodeHandler());
    
    // Financial formats
    this.normalizers.set('ofx', new OFXHandler());
    this.normalizers.set('qfx', new QFXHandler());
    this.normalizers.set('qif', new QIFHandler());
    
    // Fallback
    this.normalizers.set('binary', new BinaryHandler());
    this.normalizers.set('unknown', new UnknownHandler());
  }

  async normalize(data: Buffer | string | object, format: InputFormat): Promise<NormalizedContent> {
    const startTime = Date.now();
    const handler = this.normalizers.get(format) || this.normalizers.get('unknown')!;
    
    try {
      const result = await handler.normalize(data);
      result.metadata = {
        originalFormat: format,
        normalizedAt: new Date(),
        processingTime: Date.now() - startTime,
        confidence: result.metadata?.confidence || 0.8,
        warnings: result.metadata?.warnings || [],
      };
      return result;
    } catch (error) {
      return {
        text: typeof data === 'string' ? data : data.toString(),
        metadata: {
          originalFormat: format,
          normalizedAt: new Date(),
          processingTime: Date.now() - startTime,
          confidence: 0.3,
          warnings: [`Normalization failed: ${error}`],
        },
      };
    }
  }

  detectFormat(data: Buffer | string, filename?: string, mimeType?: string): InputFormat {
    // Check by MIME type first
    if (mimeType) {
      const mimeFormats: Record<string, InputFormat> = {
        'text/plain': 'plain_text',
        'text/html': 'html',
        'text/markdown': 'markdown',
        'application/json': 'json',
        'application/xml': 'xml',
        'text/xml': 'xml',
        'text/yaml': 'yaml',
        'text/csv': 'csv',
        'application/pdf': 'pdf',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx',
        'application/rtf': 'rtf',
        'image/jpeg': 'jpeg',
        'image/png': 'png',
        'image/gif': 'gif',
        'image/webp': 'webp',
        'image/heic': 'heic',
        'image/svg+xml': 'svg',
        'audio/mpeg': 'mp3',
        'audio/wav': 'wav',
        'audio/aac': 'aac',
        'audio/ogg': 'ogg',
        'audio/mp4': 'm4a',
        'video/mp4': 'mp4',
        'video/quicktime': 'mov',
        'video/x-msvideo': 'avi',
        'video/webm': 'webm',
        'text/vcard': 'vcard',
        'text/calendar': 'ical',
      };
      
      if (mimeFormats[mimeType]) {
        return mimeFormats[mimeType];
      }
    }

    // Check by file extension
    if (filename) {
      const ext = filename.split('.').pop()?.toLowerCase();
      const extFormats: Record<string, InputFormat> = {
        'txt': 'plain_text',
        'html': 'html',
        'htm': 'html',
        'md': 'markdown',
        'json': 'json',
        'xml': 'xml',
        'yaml': 'yaml',
        'yml': 'yaml',
        'csv': 'csv',
        'pdf': 'pdf',
        'docx': 'docx',
        'doc': 'docx',
        'xlsx': 'xlsx',
        'xls': 'xlsx',
        'pptx': 'pptx',
        'ppt': 'pptx',
        'rtf': 'rtf',
        'jpg': 'jpeg',
        'jpeg': 'jpeg',
        'png': 'png',
        'gif': 'gif',
        'webp': 'webp',
        'heic': 'heic',
        'svg': 'svg',
        'mp3': 'mp3',
        'wav': 'wav',
        'aac': 'aac',
        'ogg': 'ogg',
        'm4a': 'm4a',
        'mp4': 'mp4',
        'mov': 'mov',
        'avi': 'avi',
        'webm': 'webm',
        'vcf': 'vcard',
        'ics': 'ical',
        'ofx': 'ofx',
        'qfx': 'qfx',
        'qif': 'qif',
      };
      
      if (ext && extFormats[ext]) {
        return extFormats[ext];
      }
    }

    // Try to detect from content
    if (typeof data === 'string') {
      // Check for JSON
      if (data.trim().startsWith('{') || data.trim().startsWith('[')) {
        try {
          JSON.parse(data);
          return 'json';
        } catch {}
      }
      
      // Check for XML
      if (data.trim().startsWith('<?xml') || data.trim().startsWith('<')) {
        return 'xml';
      }
      
      // Check for HTML
      if (data.toLowerCase().includes('<!doctype html') || data.toLowerCase().includes('<html')) {
        return 'html';
      }
      
      // Check for Markdown
      if (data.includes('# ') || data.includes('## ') || data.includes('**') || data.includes('```')) {
        return 'markdown';
      }
      
      // Check for CSV
      if (data.includes(',') && data.split('\n').every(line => line.split(',').length > 1)) {
        return 'csv';
      }
      
      return 'plain_text';
    }

    // Check magic bytes for binary data
    if (Buffer.isBuffer(data)) {
      const magicBytes: Array<{ bytes: number[]; format: InputFormat }> = [
        { bytes: [0x25, 0x50, 0x44, 0x46], format: 'pdf' }, // %PDF
        { bytes: [0x50, 0x4B, 0x03, 0x04], format: 'docx' }, // ZIP (Office docs)
        { bytes: [0xFF, 0xD8, 0xFF], format: 'jpeg' },
        { bytes: [0x89, 0x50, 0x4E, 0x47], format: 'png' },
        { bytes: [0x47, 0x49, 0x46], format: 'gif' },
        { bytes: [0x52, 0x49, 0x46, 0x46], format: 'wav' }, // RIFF
        { bytes: [0x49, 0x44, 0x33], format: 'mp3' }, // ID3
        { bytes: [0xFF, 0xFB], format: 'mp3' },
        { bytes: [0x00, 0x00, 0x00, 0x1C, 0x66, 0x74, 0x79, 0x70], format: 'mp4' },
      ];

      for (const magic of magicBytes) {
        if (magic.bytes.every((byte, i) => data[i] === byte)) {
          return magic.format;
        }
      }
    }

    return 'unknown';
  }
}

// ============================================================================
// FORMAT HANDLERS
// ============================================================================

interface FormatHandler {
  normalize(data: Buffer | string | object): Promise<NormalizedContent>;
}

class PlainTextHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    const text = typeof data === 'string' ? data : data.toString();
    return {
      text,
      metadata: {
        originalFormat: 'plain_text',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 1.0,
        warnings: [],
      },
    };
  }
}

class HTMLHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    const html = typeof data === 'string' ? data : data.toString();
    
    // Strip HTML tags for plain text
    const text = html
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
      .replace(/<[^>]+>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    
    // Extract links
    const linkRegex = /<a[^>]+href=["']([^"']+)["'][^>]*>([^<]*)<\/a>/gi;
    const links: NormalizedLink[] = [];
    let match;
    while ((match = linkRegex.exec(html)) !== null) {
      const url = match[1];
      links.push({
        url,
        text: match[2],
        type: url.startsWith('mailto:') ? 'email' : 
              url.startsWith('tel:') ? 'phone' :
              url.startsWith('http') ? 'external' : 'internal',
      });
    }

    return {
      text,
      html,
      components: { links },
      metadata: {
        originalFormat: 'html',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.9,
        warnings: [],
      },
    };
  }
}

class MarkdownHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    const markdown = typeof data === 'string' ? data : data.toString();
    
    // Convert markdown to plain text (basic)
    const text = markdown
      .replace(/#{1,6}\s+/g, '')
      .replace(/\*\*([^*]+)\*\*/g, '$1')
      .replace(/\*([^*]+)\*/g, '$1')
      .replace(/`([^`]+)`/g, '$1')
      .replace(/```[\s\S]*?```/g, '')
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      .replace(/!\[([^\]]*)\]\([^)]+\)/g, '$1')
      .trim();

    return {
      text,
      metadata: {
        originalFormat: 'markdown',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.95,
        warnings: [],
      },
    };
  }
}

class JSONHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    let parsed: object;
    
    if (typeof data === 'object' && !Buffer.isBuffer(data)) {
      parsed = data;
    } else {
      const str = typeof data === 'string' ? data : data.toString();
      parsed = JSON.parse(str);
    }

    return {
      text: JSON.stringify(parsed, null, 2),
      structured: {
        type: 'json',
        data: parsed as Record<string, any>,
      },
      metadata: {
        originalFormat: 'json',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 1.0,
        warnings: [],
      },
    };
  }
}

class XMLHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    const xml = typeof data === 'string' ? data : data.toString();
    
    // Basic XML to text conversion
    const text = xml
      .replace(/<[^>]+>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    return {
      text,
      structured: {
        type: 'xml',
        data: { raw: xml },
      },
      metadata: {
        originalFormat: 'xml',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.8,
        warnings: [],
      },
    };
  }
}

class YAMLHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    const yaml = typeof data === 'string' ? data : data.toString();
    
    // Basic YAML parsing (in production, use js-yaml)
    return {
      text: yaml,
      structured: {
        type: 'yaml',
        data: { raw: yaml },
      },
      metadata: {
        originalFormat: 'yaml',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.7,
        warnings: ['Full YAML parsing requires js-yaml library'],
      },
    };
  }
}

class CSVHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    const csv = typeof data === 'string' ? data : data.toString();
    const lines = csv.split('\n').filter(line => line.trim());
    
    if (lines.length === 0) {
      return {
        text: '',
        metadata: {
          originalFormat: 'csv',
          normalizedAt: new Date(),
          processingTime: 0,
          confidence: 0.5,
          warnings: ['Empty CSV'],
        },
      };
    }

    const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
    const rows = lines.slice(1).map(line => 
      line.split(',').map(cell => cell.trim().replace(/^"|"$/g, ''))
    );

    const tables: NormalizedTable[] = [{
      headers,
      rows,
    }];

    return {
      text: csv,
      components: { tables },
      structured: {
        type: 'csv',
        data: { headers, rows },
      },
      metadata: {
        originalFormat: 'csv',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.9,
        warnings: [],
      },
    };
  }
}

class PDFHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    // In production, use pdf-parse or similar
    return {
      text: '[PDF content - requires pdf-parse library for extraction]',
      metadata: {
        originalFormat: 'pdf',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.5,
        warnings: ['PDF parsing requires pdf-parse library'],
      },
    };
  }
}

class DOCXHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    // In production, use mammoth or similar
    return {
      text: '[DOCX content - requires mammoth library for extraction]',
      metadata: {
        originalFormat: 'docx',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.5,
        warnings: ['DOCX parsing requires mammoth library'],
      },
    };
  }
}

class XLSXHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    // In production, use xlsx or exceljs
    return {
      text: '[XLSX content - requires xlsx library for extraction]',
      metadata: {
        originalFormat: 'xlsx',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.5,
        warnings: ['XLSX parsing requires xlsx library'],
      },
    };
  }
}

class PPTXHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    return {
      text: '[PPTX content - requires specialized library for extraction]',
      metadata: {
        originalFormat: 'pptx',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.5,
        warnings: ['PPTX parsing requires specialized library'],
      },
    };
  }
}

class RTFHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    const rtf = typeof data === 'string' ? data : data.toString();
    
    // Basic RTF stripping
    const text = rtf
      .replace(/\\[a-z]+\d*\s?/gi, '')
      .replace(/[{}]/g, '')
      .trim();

    return {
      text,
      metadata: {
        originalFormat: 'rtf',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.6,
        warnings: [],
      },
    };
  }
}

class ImageHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    // In production, use OCR (tesseract.js) and image analysis
    return {
      text: '[Image content - requires OCR for text extraction]',
      components: {
        images: [{
          id: `img_${Date.now()}`,
          ocrText: undefined,
        }],
      },
      metadata: {
        originalFormat: 'jpeg',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.5,
        warnings: ['Image OCR requires tesseract.js library'],
      },
    };
  }
}

class SVGHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    const svg = typeof data === 'string' ? data : data.toString();
    
    // Extract text elements from SVG
    const textRegex = /<text[^>]*>([^<]*)<\/text>/gi;
    const texts: string[] = [];
    let match;
    while ((match = textRegex.exec(svg)) !== null) {
      texts.push(match[1]);
    }

    return {
      text: texts.join(' '),
      metadata: {
        originalFormat: 'svg',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.8,
        warnings: [],
      },
    };
  }
}

class AudioHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    // In production, use speech-to-text API
    return {
      text: '[Audio content - requires speech-to-text for transcription]',
      metadata: {
        originalFormat: 'mp3',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.5,
        warnings: ['Audio transcription requires speech-to-text API'],
      },
    };
  }
}

class VideoHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    // In production, extract audio and use speech-to-text
    return {
      text: '[Video content - requires audio extraction and speech-to-text]',
      metadata: {
        originalFormat: 'mp4',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.5,
        warnings: ['Video transcription requires ffmpeg and speech-to-text API'],
      },
    };
  }
}

class VCardHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    const vcard = typeof data === 'string' ? data : data.toString();
    
    // Parse vCard fields
    const fields: Record<string, string> = {};
    const lines = vcard.split('\n');
    
    for (const line of lines) {
      const [key, ...valueParts] = line.split(':');
      if (key && valueParts.length) {
        const cleanKey = key.split(';')[0].toUpperCase();
        fields[cleanKey] = valueParts.join(':').trim();
      }
    }

    const text = [
      fields.FN || fields.N,
      fields.EMAIL,
      fields.TEL,
      fields.ADR,
    ].filter(Boolean).join('\n');

    return {
      text,
      structured: {
        type: 'vcard',
        data: fields,
      },
      metadata: {
        originalFormat: 'vcard',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.9,
        warnings: [],
      },
    };
  }
}

class ICalHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    const ical = typeof data === 'string' ? data : data.toString();
    
    // Basic iCal parsing
    const events: Array<Record<string, string>> = [];
    let currentEvent: Record<string, string> | null = null;
    
    const lines = ical.split('\n');
    for (const line of lines) {
      if (line.startsWith('BEGIN:VEVENT')) {
        currentEvent = {};
      } else if (line.startsWith('END:VEVENT') && currentEvent) {
        events.push(currentEvent);
        currentEvent = null;
      } else if (currentEvent) {
        const [key, ...valueParts] = line.split(':');
        if (key && valueParts.length) {
          currentEvent[key.split(';')[0]] = valueParts.join(':').trim();
        }
      }
    }

    const text = events.map(e => 
      `${e.SUMMARY || 'Event'} - ${e.DTSTART || ''}`
    ).join('\n');

    return {
      text,
      structured: {
        type: 'ical',
        data: { events },
      },
      metadata: {
        originalFormat: 'ical',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.85,
        warnings: [],
      },
    };
  }
}

class MIMEHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    const mime = typeof data === 'string' ? data : data.toString();
    
    // Basic MIME parsing
    const headerEnd = mime.indexOf('\n\n');
    const headers: Record<string, string> = {};
    const headerSection = mime.substring(0, headerEnd);
    const body = mime.substring(headerEnd + 2);
    
    for (const line of headerSection.split('\n')) {
      const colonIndex = line.indexOf(':');
      if (colonIndex > 0) {
        const key = line.substring(0, colonIndex).trim();
        const value = line.substring(colonIndex + 1).trim();
        headers[key] = value;
      }
    }

    return {
      text: body,
      components: {
        headers,
        body,
      },
      metadata: {
        originalFormat: 'mime',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.8,
        warnings: [],
      },
    };
  }
}

class QRCodeHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    // In production, use qrcode-reader or similar
    return {
      text: '[QR Code - requires qrcode-reader library for decoding]',
      metadata: {
        originalFormat: 'qrcode',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.5,
        warnings: ['QR code decoding requires qrcode-reader library'],
      },
    };
  }
}

class BarcodeHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    // In production, use quagga or similar
    return {
      text: '[Barcode - requires barcode reader library for decoding]',
      metadata: {
        originalFormat: 'barcode',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.5,
        warnings: ['Barcode decoding requires quagga library'],
      },
    };
  }
}

class OFXHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    const ofx = typeof data === 'string' ? data : data.toString();
    
    // Basic OFX parsing
    const transactions: Array<Record<string, string>> = [];
    const transactionRegex = /<STMTTRN>([\s\S]*?)<\/STMTTRN>/gi;
    let match;
    
    while ((match = transactionRegex.exec(ofx)) !== null) {
      const tx: Record<string, string> = {};
      const content = match[1];
      
      const fields = ['TRNTYPE', 'DTPOSTED', 'TRNAMT', 'NAME', 'MEMO'];
      for (const field of fields) {
        const fieldMatch = content.match(new RegExp(`<${field}>([^<]+)`, 'i'));
        if (fieldMatch) {
          tx[field] = fieldMatch[1].trim();
        }
      }
      
      transactions.push(tx);
    }

    const text = transactions.map(tx => 
      `${tx.DTPOSTED || ''} ${tx.NAME || ''} ${tx.TRNAMT || ''}`
    ).join('\n');

    return {
      text,
      structured: {
        type: 'ofx',
        data: { transactions },
      },
      metadata: {
        originalFormat: 'ofx',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.85,
        warnings: [],
      },
    };
  }
}

class QFXHandler extends OFXHandler {
  // QFX is essentially OFX with Quicken extensions
}

class QIFHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    const qif = typeof data === 'string' ? data : data.toString();
    
    // Basic QIF parsing
    const transactions: Array<Record<string, string>> = [];
    let currentTx: Record<string, string> = {};
    
    for (const line of qif.split('\n')) {
      if (line.startsWith('^')) {
        if (Object.keys(currentTx).length > 0) {
          transactions.push(currentTx);
          currentTx = {};
        }
      } else if (line.length > 1) {
        const type = line[0];
        const value = line.substring(1).trim();
        
        const fieldMap: Record<string, string> = {
          'D': 'date',
          'T': 'amount',
          'P': 'payee',
          'M': 'memo',
          'L': 'category',
        };
        
        if (fieldMap[type]) {
          currentTx[fieldMap[type]] = value;
        }
      }
    }

    const text = transactions.map(tx => 
      `${tx.date || ''} ${tx.payee || ''} ${tx.amount || ''}`
    ).join('\n');

    return {
      text,
      structured: {
        type: 'qif',
        data: { transactions },
      },
      metadata: {
        originalFormat: 'qif',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.85,
        warnings: [],
      },
    };
  }
}

class BinaryHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    const size = Buffer.isBuffer(data) ? data.length : 
                 typeof data === 'string' ? data.length : 
                 JSON.stringify(data).length;

    return {
      text: `[Binary data: ${size} bytes]`,
      metadata: {
        originalFormat: 'binary',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.3,
        warnings: ['Binary data cannot be converted to text'],
      },
    };
  }
}

class UnknownHandler implements FormatHandler {
  async normalize(data: Buffer | string | object): Promise<NormalizedContent> {
    let text: string;
    
    if (typeof data === 'string') {
      text = data;
    } else if (Buffer.isBuffer(data)) {
      // Try to convert to string
      text = data.toString('utf-8');
      // Check if it looks like valid text
      if (text.includes('\ufffd')) {
        text = `[Unknown binary format: ${data.length} bytes]`;
      }
    } else {
      text = JSON.stringify(data);
    }

    return {
      text,
      metadata: {
        originalFormat: 'unknown',
        normalizedAt: new Date(),
        processingTime: 0,
        confidence: 0.4,
        warnings: ['Format could not be determined'],
      },
    };
  }
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

export const formatNormalizer = new FormatNormalizer();
