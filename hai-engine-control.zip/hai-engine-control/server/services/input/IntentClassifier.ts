/**
 * Intent Classifier
 * 
 * Classifies the intent of any input to determine:
 * - What the user/sender wants
 * - What action HAI should take
 * - How urgent the response needs to be
 * - Whether automation is appropriate
 */

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

export interface ClassifiedIntent {
  // Primary intent
  primary: IntentType;
  primaryConfidence: number;
  
  // Secondary intents (multi-intent messages)
  secondary: SecondaryIntent[];
  
  // Action requirements
  action: ActionRequirement;
  
  // Response requirements
  response: ResponseRequirement;
  
  // Automation eligibility
  automation: AutomationEligibility;
  
  // Sentiment and tone
  sentiment: SentimentAnalysis;
  
  // Domain classification
  domain: DomainClassification;
  
  // Overall confidence
  overallConfidence: number;
}

export type IntentType =
  // Information intents
  | 'inform' | 'notify' | 'update' | 'report' | 'share' | 'announce'
  // Request intents
  | 'request' | 'ask' | 'inquire' | 'seek' | 'demand'
  // Action intents
  | 'schedule' | 'remind' | 'book' | 'order' | 'purchase' | 'pay' | 'transfer'
  | 'cancel' | 'modify' | 'confirm' | 'approve' | 'reject'
  // Communication intents
  | 'reply' | 'forward' | 'delegate' | 'escalate' | 'acknowledge'
  // Social intents
  | 'greet' | 'thank' | 'apologize' | 'congratulate' | 'sympathize'
  // Emergency intents
  | 'alert' | 'warn' | 'emergency' | 'urgent'
  // System intents
  | 'configure' | 'enable' | 'disable' | 'status' | 'help'
  // Unknown
  | 'unknown';

export interface SecondaryIntent {
  type: IntentType;
  confidence: number;
  context?: string;
}

export interface ActionRequirement {
  requiresAction: boolean;
  actionType?: ActionType;
  actionUrgency: 'immediate' | 'soon' | 'scheduled' | 'whenever' | 'none';
  actionTarget?: string;
  actionDeadline?: Date;
  canBeAutomated: boolean;
  requiresApproval: boolean;
  requiresConfirmation: boolean;
}

export type ActionType =
  | 'create' | 'read' | 'update' | 'delete'
  | 'send' | 'receive' | 'forward' | 'reply'
  | 'schedule' | 'reschedule' | 'cancel'
  | 'pay' | 'transfer' | 'purchase' | 'refund'
  | 'notify' | 'remind' | 'alert'
  | 'approve' | 'reject' | 'escalate'
  | 'configure' | 'enable' | 'disable'
  | 'research' | 'analyze' | 'summarize'
  | 'none';

export interface ResponseRequirement {
  requiresResponse: boolean;
  responseType?: ResponseType;
  responseUrgency: 'immediate' | 'within_hour' | 'within_day' | 'within_week' | 'none';
  suggestedChannel?: string;
  suggestedTone?: 'formal' | 'casual' | 'professional' | 'friendly';
  templateAvailable: boolean;
  templateId?: string;
}

export type ResponseType =
  | 'answer' | 'confirmation' | 'acknowledgment' | 'clarification'
  | 'approval' | 'rejection' | 'delegation' | 'escalation'
  | 'information' | 'recommendation' | 'warning'
  | 'none';

export interface AutomationEligibility {
  canAutomate: boolean;
  automationLevel: 'full' | 'partial' | 'assisted' | 'manual';
  automationConfidence: number;
  blockers: AutomationBlocker[];
  suggestedAutomations: SuggestedAutomation[];
}

export interface AutomationBlocker {
  type: 'approval_required' | 'ambiguous' | 'high_risk' | 'missing_info' | 'policy' | 'preference';
  description: string;
  resolvable: boolean;
  resolution?: string;
}

export interface SuggestedAutomation {
  automationId: string;
  name: string;
  description: string;
  confidence: number;
  impact: 'low' | 'medium' | 'high';
}

export interface SentimentAnalysis {
  overall: 'positive' | 'negative' | 'neutral' | 'mixed';
  score: number; // -1 to 1
  urgency: number; // 0 to 1
  formality: number; // 0 to 1
  emotions: EmotionScores;
  tone: ToneAnalysis;
}

export interface EmotionScores {
  joy?: number;
  sadness?: number;
  anger?: number;
  fear?: number;
  surprise?: number;
  disgust?: number;
  trust?: number;
  anticipation?: number;
}

export interface ToneAnalysis {
  primary: 'assertive' | 'tentative' | 'confident' | 'anxious' | 'friendly' | 'hostile' | 'neutral';
  characteristics: string[];
}

export interface DomainClassification {
  primary: DomainType;
  secondary: DomainType[];
  confidence: number;
  keywords: string[];
}

export type DomainType =
  | 'financial' | 'scheduling' | 'communication' | 'shopping' | 'travel'
  | 'health' | 'home' | 'family' | 'work' | 'social' | 'entertainment'
  | 'legal' | 'education' | 'government' | 'emergency' | 'general';

// ============================================================================
// INTENT CLASSIFIER
// ============================================================================

export class IntentClassifier {
  private intentPatterns: Map<IntentType, RegExp[]> = new Map();
  private domainKeywords: Map<DomainType, string[]> = new Map();
  private actionKeywords: Map<ActionType, string[]> = new Map();

  constructor() {
    this.initializePatterns();
  }

  private initializePatterns(): void {
    // Intent patterns
    this.intentPatterns.set('request', [
      /\bplease\b/i,
      /\bcould you\b/i,
      /\bcan you\b/i,
      /\bwould you\b/i,
      /\bi need\b/i,
      /\bi want\b/i,
      /\bi'd like\b/i,
    ]);

    this.intentPatterns.set('ask', [
      /\?$/,
      /\bwhat\b/i,
      /\bwhen\b/i,
      /\bwhere\b/i,
      /\bwho\b/i,
      /\bwhy\b/i,
      /\bhow\b/i,
      /\bdo you know\b/i,
      /\bis there\b/i,
    ]);

    this.intentPatterns.set('inform', [
      /\bfyi\b/i,
      /\bjust letting you know\b/i,
      /\bfor your information\b/i,
      /\bheads up\b/i,
      /\bupdate:\b/i,
    ]);

    this.intentPatterns.set('schedule', [
      /\bschedule\b/i,
      /\bbook\b/i,
      /\bappointment\b/i,
      /\bmeeting\b/i,
      /\bcalendar\b/i,
      /\breservation\b/i,
    ]);

    this.intentPatterns.set('remind', [
      /\bremind\b/i,
      /\breminder\b/i,
      /\bdon't forget\b/i,
      /\bremember to\b/i,
    ]);

    this.intentPatterns.set('purchase', [
      /\bbuy\b/i,
      /\bpurchase\b/i,
      /\border\b/i,
      /\bget me\b/i,
    ]);

    this.intentPatterns.set('pay', [
      /\bpay\b/i,
      /\bpayment\b/i,
      /\bbill\b/i,
      /\binvoice\b/i,
      /\btransfer\b/i,
    ]);

    this.intentPatterns.set('cancel', [
      /\bcancel\b/i,
      /\bcancellation\b/i,
      /\bstop\b/i,
      /\bend\b/i,
    ]);

    this.intentPatterns.set('confirm', [
      /\bconfirm\b/i,
      /\bconfirmation\b/i,
      /\bverify\b/i,
      /\byes\b/i,
      /\bapproved\b/i,
    ]);

    this.intentPatterns.set('urgent', [
      /\burgent\b/i,
      /\basap\b/i,
      /\bimmediately\b/i,
      /\bemergency\b/i,
      /\bcritical\b/i,
      /\btime.?sensitive\b/i,
    ]);

    this.intentPatterns.set('greet', [
      /\bhello\b/i,
      /\bhi\b/i,
      /\bhey\b/i,
      /\bgood morning\b/i,
      /\bgood afternoon\b/i,
      /\bgood evening\b/i,
    ]);

    this.intentPatterns.set('thank', [
      /\bthank\b/i,
      /\bthanks\b/i,
      /\bappreciate\b/i,
      /\bgrateful\b/i,
    ]);

    // Domain keywords
    this.domainKeywords.set('financial', [
      'money', 'payment', 'bill', 'invoice', 'bank', 'account', 'transfer',
      'credit', 'debit', 'balance', 'transaction', 'budget', 'expense',
      'income', 'tax', 'investment', 'savings', 'loan', 'mortgage',
    ]);

    this.domainKeywords.set('scheduling', [
      'calendar', 'schedule', 'appointment', 'meeting', 'event', 'reminder',
      'deadline', 'date', 'time', 'book', 'reserve', 'availability',
    ]);

    this.domainKeywords.set('shopping', [
      'buy', 'purchase', 'order', 'shop', 'cart', 'checkout', 'delivery',
      'shipping', 'product', 'item', 'price', 'discount', 'sale', 'coupon',
    ]);

    this.domainKeywords.set('travel', [
      'flight', 'hotel', 'booking', 'reservation', 'trip', 'vacation',
      'travel', 'airport', 'ticket', 'itinerary', 'destination', 'passport',
    ]);

    this.domainKeywords.set('health', [
      'doctor', 'appointment', 'medical', 'health', 'prescription', 'pharmacy',
      'hospital', 'clinic', 'symptom', 'medication', 'insurance', 'wellness',
    ]);

    this.domainKeywords.set('home', [
      'house', 'home', 'apartment', 'maintenance', 'repair', 'utility',
      'electricity', 'water', 'gas', 'internet', 'appliance', 'cleaning',
    ]);

    this.domainKeywords.set('work', [
      'work', 'office', 'meeting', 'project', 'deadline', 'report',
      'presentation', 'colleague', 'boss', 'client', 'business', 'professional',
    ]);

    this.domainKeywords.set('emergency', [
      'emergency', 'urgent', 'help', 'danger', 'accident', 'fire',
      'police', 'ambulance', '911', 'crisis', 'alert', 'warning',
    ]);

    // Action keywords
    this.actionKeywords.set('create', ['create', 'make', 'add', 'new', 'set up']);
    this.actionKeywords.set('read', ['read', 'view', 'show', 'display', 'get', 'find']);
    this.actionKeywords.set('update', ['update', 'change', 'modify', 'edit', 'revise']);
    this.actionKeywords.set('delete', ['delete', 'remove', 'cancel', 'clear']);
    this.actionKeywords.set('send', ['send', 'email', 'message', 'text', 'forward']);
    this.actionKeywords.set('schedule', ['schedule', 'book', 'reserve', 'plan']);
    this.actionKeywords.set('pay', ['pay', 'transfer', 'send money', 'wire']);
    this.actionKeywords.set('purchase', ['buy', 'purchase', 'order', 'get']);
    this.actionKeywords.set('notify', ['notify', 'alert', 'inform', 'tell']);
    this.actionKeywords.set('remind', ['remind', 'reminder', 'don\'t forget']);
    this.actionKeywords.set('approve', ['approve', 'accept', 'confirm', 'yes']);
    this.actionKeywords.set('reject', ['reject', 'decline', 'deny', 'no']);
  }

  async classify(text: string, metadata?: Record<string, any>): Promise<ClassifiedIntent> {
    const lowerText = text.toLowerCase();

    // Classify primary intent
    const { primary, primaryConfidence } = this.classifyPrimaryIntent(lowerText);

    // Find secondary intents
    const secondary = this.findSecondaryIntents(lowerText, primary);

    // Determine action requirements
    const action = this.determineActionRequirements(lowerText, primary, metadata);

    // Determine response requirements
    const response = this.determineResponseRequirements(lowerText, primary, metadata);

    // Assess automation eligibility
    const automation = this.assessAutomationEligibility(primary, action, response, metadata);

    // Analyze sentiment
    const sentiment = this.analyzeSentiment(text);

    // Classify domain
    const domain = this.classifyDomain(lowerText);

    // Calculate overall confidence
    const overallConfidence = this.calculateOverallConfidence(
      primaryConfidence,
      secondary,
      action,
      sentiment
    );

    return {
      primary,
      primaryConfidence,
      secondary,
      action,
      response,
      automation,
      sentiment,
      domain,
      overallConfidence,
    };
  }

  // -------------------------------------------------------------------------
  // PRIMARY INTENT CLASSIFICATION
  // -------------------------------------------------------------------------

  private classifyPrimaryIntent(text: string): { primary: IntentType; primaryConfidence: number } {
    const scores: Map<IntentType, number> = new Map();

    // Check each intent pattern
    for (const [intent, patterns] of this.intentPatterns) {
      let score = 0;
      for (const pattern of patterns) {
        if (pattern.test(text)) {
          score += 1;
        }
      }
      if (score > 0) {
        scores.set(intent, score / patterns.length);
      }
    }

    // Find highest scoring intent
    let maxScore = 0;
    let primary: IntentType = 'unknown';

    for (const [intent, score] of scores) {
      if (score > maxScore) {
        maxScore = score;
        primary = intent;
      }
    }

    // Adjust confidence based on clarity
    const primaryConfidence = maxScore > 0 ? Math.min(maxScore + 0.3, 1) : 0.3;

    return { primary, primaryConfidence };
  }

  // -------------------------------------------------------------------------
  // SECONDARY INTENTS
  // -------------------------------------------------------------------------

  private findSecondaryIntents(text: string, primary: IntentType): SecondaryIntent[] {
    const secondary: SecondaryIntent[] = [];

    for (const [intent, patterns] of this.intentPatterns) {
      if (intent === primary) continue;

      let matchCount = 0;
      for (const pattern of patterns) {
        if (pattern.test(text)) {
          matchCount++;
        }
      }

      if (matchCount > 0) {
        const confidence = matchCount / patterns.length;
        if (confidence > 0.3) {
          secondary.push({
            type: intent,
            confidence,
          });
        }
      }
    }

    // Sort by confidence
    return secondary.sort((a, b) => b.confidence - a.confidence).slice(0, 3);
  }

  // -------------------------------------------------------------------------
  // ACTION REQUIREMENTS
  // -------------------------------------------------------------------------

  private determineActionRequirements(
    text: string,
    intent: IntentType,
    metadata?: Record<string, any>
  ): ActionRequirement {
    // Determine if action is required
    const actionIntents: IntentType[] = [
      'request', 'schedule', 'remind', 'book', 'order', 'purchase', 'pay',
      'transfer', 'cancel', 'modify', 'confirm', 'approve', 'reject',
      'configure', 'enable', 'disable', 'urgent', 'emergency',
    ];

    const requiresAction = actionIntents.includes(intent);

    // Determine action type
    let actionType: ActionType = 'none';
    for (const [type, keywords] of this.actionKeywords) {
      if (keywords.some(kw => text.includes(kw))) {
        actionType = type;
        break;
      }
    }

    // Determine urgency
    let actionUrgency: ActionRequirement['actionUrgency'] = 'whenever';
    if (intent === 'urgent' || intent === 'emergency') {
      actionUrgency = 'immediate';
    } else if (intent === 'schedule' || intent === 'remind') {
      actionUrgency = 'scheduled';
    } else if (requiresAction) {
      actionUrgency = 'soon';
    } else {
      actionUrgency = 'none';
    }

    // Determine automation eligibility
    const highRiskActions: ActionType[] = ['pay', 'transfer', 'purchase', 'delete'];
    const canBeAutomated = !highRiskActions.includes(actionType);
    const requiresApproval = highRiskActions.includes(actionType);
    const requiresConfirmation = ['schedule', 'send', 'notify'].includes(actionType);

    return {
      requiresAction,
      actionType: requiresAction ? actionType : undefined,
      actionUrgency,
      canBeAutomated,
      requiresApproval,
      requiresConfirmation,
    };
  }

  // -------------------------------------------------------------------------
  // RESPONSE REQUIREMENTS
  // -------------------------------------------------------------------------

  private determineResponseRequirements(
    text: string,
    intent: IntentType,
    metadata?: Record<string, any>
  ): ResponseRequirement {
    // Determine if response is required
    const responseIntents: IntentType[] = [
      'ask', 'inquire', 'seek', 'request', 'urgent', 'emergency',
    ];

    const requiresResponse = responseIntents.includes(intent) || text.includes('?');

    // Determine response type
    let responseType: ResponseType = 'none';
    if (intent === 'ask' || intent === 'inquire') {
      responseType = 'answer';
    } else if (intent === 'request') {
      responseType = 'confirmation';
    } else if (intent === 'inform' || intent === 'notify') {
      responseType = 'acknowledgment';
    }

    // Determine urgency
    let responseUrgency: ResponseRequirement['responseUrgency'] = 'none';
    if (intent === 'urgent' || intent === 'emergency') {
      responseUrgency = 'immediate';
    } else if (requiresResponse) {
      responseUrgency = 'within_day';
    }

    // Determine tone
    const suggestedTone = this.determineSuggestedTone(text);

    return {
      requiresResponse,
      responseType: requiresResponse ? responseType : undefined,
      responseUrgency,
      suggestedTone,
      templateAvailable: false,
    };
  }

  private determineSuggestedTone(text: string): ResponseRequirement['suggestedTone'] {
    const formalIndicators = ['dear', 'sincerely', 'regards', 'respectfully', 'hereby'];
    const casualIndicators = ['hey', 'hi', 'thanks', 'cool', 'awesome', 'great'];

    const hasFormal = formalIndicators.some(i => text.toLowerCase().includes(i));
    const hasCasual = casualIndicators.some(i => text.toLowerCase().includes(i));

    if (hasFormal && !hasCasual) return 'formal';
    if (hasCasual && !hasFormal) return 'casual';
    return 'professional';
  }

  // -------------------------------------------------------------------------
  // AUTOMATION ELIGIBILITY
  // -------------------------------------------------------------------------

  private assessAutomationEligibility(
    intent: IntentType,
    action: ActionRequirement,
    response: ResponseRequirement,
    metadata?: Record<string, any>
  ): AutomationEligibility {
    const blockers: AutomationBlocker[] = [];
    const suggestedAutomations: SuggestedAutomation[] = [];

    // Check for blockers
    if (action.requiresApproval) {
      blockers.push({
        type: 'approval_required',
        description: 'This action requires explicit approval',
        resolvable: true,
        resolution: 'Request approval from authorized user',
      });
    }

    if (intent === 'unknown') {
      blockers.push({
        type: 'ambiguous',
        description: 'Intent could not be clearly determined',
        resolvable: true,
        resolution: 'Ask for clarification',
      });
    }

    const highRiskIntents: IntentType[] = ['pay', 'transfer', 'purchase', 'emergency'];
    if (highRiskIntents.includes(intent)) {
      blockers.push({
        type: 'high_risk',
        description: 'This is a high-risk action',
        resolvable: false,
      });
    }

    // Determine automation level
    let automationLevel: AutomationEligibility['automationLevel'];
    let canAutomate: boolean;
    let automationConfidence: number;

    if (blockers.length === 0) {
      automationLevel = 'full';
      canAutomate = true;
      automationConfidence = 0.9;
    } else if (blockers.every(b => b.resolvable)) {
      automationLevel = 'partial';
      canAutomate = true;
      automationConfidence = 0.6;
    } else if (blockers.some(b => b.type === 'high_risk')) {
      automationLevel = 'manual';
      canAutomate = false;
      automationConfidence = 0.1;
    } else {
      automationLevel = 'assisted';
      canAutomate = true;
      automationConfidence = 0.4;
    }

    // Suggest automations
    if (intent === 'schedule') {
      suggestedAutomations.push({
        automationId: 'auto_calendar',
        name: 'Auto-add to calendar',
        description: 'Automatically create calendar event',
        confidence: 0.8,
        impact: 'low',
      });
    }

    if (intent === 'remind') {
      suggestedAutomations.push({
        automationId: 'auto_reminder',
        name: 'Auto-create reminder',
        description: 'Automatically set up reminder',
        confidence: 0.85,
        impact: 'low',
      });
    }

    if (response.requiresResponse && response.responseType === 'acknowledgment') {
      suggestedAutomations.push({
        automationId: 'auto_ack',
        name: 'Auto-acknowledge',
        description: 'Send automatic acknowledgment',
        confidence: 0.7,
        impact: 'low',
      });
    }

    return {
      canAutomate,
      automationLevel,
      automationConfidence,
      blockers,
      suggestedAutomations,
    };
  }

  // -------------------------------------------------------------------------
  // SENTIMENT ANALYSIS
  // -------------------------------------------------------------------------

  private analyzeSentiment(text: string): SentimentAnalysis {
    const lowerText = text.toLowerCase();

    // Positive indicators
    const positiveWords = [
      'good', 'great', 'excellent', 'amazing', 'wonderful', 'fantastic',
      'happy', 'pleased', 'delighted', 'love', 'like', 'appreciate',
      'thank', 'thanks', 'grateful', 'perfect', 'awesome', 'beautiful',
    ];

    // Negative indicators
    const negativeWords = [
      'bad', 'terrible', 'awful', 'horrible', 'poor', 'disappointing',
      'sad', 'angry', 'frustrated', 'annoyed', 'upset', 'hate',
      'dislike', 'problem', 'issue', 'wrong', 'error', 'fail',
    ];

    // Urgency indicators
    const urgencyWords = [
      'urgent', 'asap', 'immediately', 'now', 'quickly', 'hurry',
      'deadline', 'critical', 'important', 'priority', 'emergency',
    ];

    // Count matches
    let positiveCount = 0;
    let negativeCount = 0;
    let urgencyCount = 0;

    for (const word of positiveWords) {
      if (lowerText.includes(word)) positiveCount++;
    }
    for (const word of negativeWords) {
      if (lowerText.includes(word)) negativeCount++;
    }
    for (const word of urgencyWords) {
      if (lowerText.includes(word)) urgencyCount++;
    }

    // Calculate scores
    const score = (positiveCount - negativeCount) / Math.max(positiveCount + negativeCount, 1);
    const urgency = Math.min(urgencyCount / 3, 1);

    // Determine overall sentiment
    let overall: SentimentAnalysis['overall'];
    if (score > 0.3) overall = 'positive';
    else if (score < -0.3) overall = 'negative';
    else if (positiveCount > 0 && negativeCount > 0) overall = 'mixed';
    else overall = 'neutral';

    // Analyze formality
    const formalIndicators = ['dear', 'sincerely', 'regards', 'hereby', 'pursuant'];
    const informalIndicators = ['hey', 'hi', 'gonna', 'wanna', 'lol', 'btw'];
    
    const formalCount = formalIndicators.filter(i => lowerText.includes(i)).length;
    const informalCount = informalIndicators.filter(i => lowerText.includes(i)).length;
    const formality = (formalCount - informalCount + 1) / 2; // Normalize to 0-1

    // Detect emotions
    const emotions: EmotionScores = {};
    if (lowerText.includes('happy') || lowerText.includes('joy')) emotions.joy = 0.7;
    if (lowerText.includes('sad') || lowerText.includes('sorry')) emotions.sadness = 0.6;
    if (lowerText.includes('angry') || lowerText.includes('furious')) emotions.anger = 0.7;
    if (lowerText.includes('worried') || lowerText.includes('afraid')) emotions.fear = 0.6;
    if (lowerText.includes('surprised') || lowerText.includes('unexpected')) emotions.surprise = 0.5;

    // Analyze tone
    let tonePrimary: ToneAnalysis['primary'] = 'neutral';
    const characteristics: string[] = [];

    if (urgency > 0.5) {
      tonePrimary = 'anxious';
      characteristics.push('urgent');
    } else if (score > 0.3) {
      tonePrimary = 'friendly';
      characteristics.push('positive');
    } else if (score < -0.3) {
      tonePrimary = 'hostile';
      characteristics.push('negative');
    }

    if (formality > 0.6) characteristics.push('formal');
    if (formality < 0.4) characteristics.push('casual');

    return {
      overall,
      score,
      urgency,
      formality,
      emotions,
      tone: {
        primary: tonePrimary,
        characteristics,
      },
    };
  }

  // -------------------------------------------------------------------------
  // DOMAIN CLASSIFICATION
  // -------------------------------------------------------------------------

  private classifyDomain(text: string): DomainClassification {
    const scores: Map<DomainType, number> = new Map();

    for (const [domain, keywords] of this.domainKeywords) {
      let matchCount = 0;
      const matchedKeywords: string[] = [];

      for (const keyword of keywords) {
        if (text.includes(keyword)) {
          matchCount++;
          matchedKeywords.push(keyword);
        }
      }

      if (matchCount > 0) {
        scores.set(domain, matchCount / keywords.length);
      }
    }

    // Find primary domain
    let maxScore = 0;
    let primary: DomainType = 'general';
    const secondary: DomainType[] = [];
    const keywords: string[] = [];

    for (const [domain, score] of scores) {
      if (score > maxScore) {
        if (primary !== 'general') {
          secondary.push(primary);
        }
        maxScore = score;
        primary = domain;
      } else if (score > 0.2) {
        secondary.push(domain);
      }
    }

    // Get matched keywords for primary domain
    if (primary !== 'general') {
      const domainKws = this.domainKeywords.get(primary) || [];
      for (const kw of domainKws) {
        if (text.includes(kw)) {
          keywords.push(kw);
        }
      }
    }

    return {
      primary,
      secondary: secondary.slice(0, 3),
      confidence: maxScore > 0 ? Math.min(maxScore + 0.3, 1) : 0.3,
      keywords,
    };
  }

  // -------------------------------------------------------------------------
  // CONFIDENCE CALCULATION
  // -------------------------------------------------------------------------

  private calculateOverallConfidence(
    primaryConfidence: number,
    secondary: SecondaryIntent[],
    action: ActionRequirement,
    sentiment: SentimentAnalysis
  ): number {
    let confidence = primaryConfidence * 0.5;

    // Clear action requirements increase confidence
    if (action.requiresAction && action.actionType !== 'none') {
      confidence += 0.2;
    }

    // Clear sentiment increases confidence
    if (sentiment.overall !== 'mixed') {
      confidence += 0.1;
    }

    // Few secondary intents = clearer message
    if (secondary.length <= 1) {
      confidence += 0.1;
    }

    // High urgency = clearer priority
    if (sentiment.urgency > 0.5) {
      confidence += 0.1;
    }

    return Math.min(confidence, 1);
  }
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

export const intentClassifier = new IntentClassifier();
