/**
 * Universal Input Processor
 * 
 * HAI's core input handling system that can process ANY input from ANY source
 * in ANY format at ANY time. This is the foundation of HAI's ability to
 * handle every reality, circumstance, and situation.
 */

import { EventEmitter } from 'events';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

export type InputSource = 
  // Email Sources
  | 'gmail' | 'outlook' | 'yahoo' | 'protonmail' | 'icloud_mail' | 'generic_imap' | 'generic_smtp'
  // SMS/Messaging Sources
  | 'sms_twilio' | 'whatsapp' | 'telegram' | 'signal' | 'imessage' | 'facebook_messenger' | 'slack' | 'discord' | 'teams'
  // Voice Sources
  | 'phone_call' | 'voicemail' | 'voice_command' | 'alexa' | 'google_home' | 'siri' | 'intercom'
  // Calendar Sources
  | 'google_calendar' | 'outlook_calendar' | 'apple_calendar' | 'calendly' | 'generic_caldav'
  // Financial Sources
  | 'plaid' | 'stripe' | 'paypal' | 'venmo' | 'bank_webhook' | 'credit_card' | 'crypto_wallet'
  // Smart Home Sources
  | 'smartthings' | 'home_assistant' | 'homekit' | 'google_home_devices' | 'alexa_devices' | 'ring' | 'nest' | 'ecobee'
  // Location Sources
  | 'gps' | 'geofence' | 'tile' | 'airtag' | 'life360' | 'vehicle_gps'
  // Health Sources
  | 'apple_health' | 'google_fit' | 'fitbit' | 'garmin' | 'whoop' | 'oura'
  // Document Sources
  | 'google_drive' | 'dropbox' | 'onedrive' | 'icloud_drive' | 'file_upload'
  // Social Sources
  | 'facebook' | 'instagram' | 'twitter' | 'linkedin' | 'nextdoor'
  // IoT/Sensor Sources
  | 'motion_sensor' | 'door_sensor' | 'water_sensor' | 'smoke_detector' | 'camera' | 'doorbell'
  // System Sources
  | 'webhook' | 'api' | 'manual' | 'scheduled' | 'internal';

export type InputFormat = 
  // Text Formats
  | 'plain_text' | 'html' | 'markdown' | 'json' | 'xml' | 'yaml' | 'csv'
  // Document Formats
  | 'pdf' | 'docx' | 'xlsx' | 'pptx' | 'rtf'
  // Image Formats
  | 'jpeg' | 'png' | 'gif' | 'webp' | 'heic' | 'svg'
  // Audio Formats
  | 'mp3' | 'wav' | 'aac' | 'ogg' | 'm4a'
  // Video Formats
  | 'mp4' | 'mov' | 'avi' | 'webm'
  // Structured Formats
  | 'vcard' | 'ical' | 'mime' | 'qrcode' | 'barcode'
  // Financial Formats
  | 'ofx' | 'qfx' | 'qif'
  // Binary/Other
  | 'binary' | 'unknown';

export type InputPriority = 'critical' | 'high' | 'normal' | 'low' | 'background';

export type InputCategory = 
  | 'communication' | 'financial' | 'scheduling' | 'health' | 'safety'
  | 'home' | 'family' | 'work' | 'social' | 'shopping' | 'travel'
  | 'entertainment' | 'maintenance' | 'emergency' | 'system';

export interface RawInput {
  id: string;
  source: InputSource;
  format: InputFormat;
  rawData: Buffer | string | object;
  metadata: {
    receivedAt: Date;
    sourceId?: string;
    sourceAccount?: string;
    ipAddress?: string;
    userAgent?: string;
    headers?: Record<string, string>;
    attachments?: AttachmentInfo[];
  };
}

export interface AttachmentInfo {
  id: string;
  filename: string;
  mimeType: string;
  size: number;
  url?: string;
  data?: Buffer;
}

export interface ProcessedInput {
  id: string;
  originalInputId: string;
  source: InputSource;
  format: InputFormat;
  priority: InputPriority;
  category: InputCategory;
  
  // Extracted content
  content: {
    text?: string;
    html?: string;
    structured?: object;
    summary?: string;
  };
  
  // Extracted entities
  entities: {
    people: PersonEntity[];
    organizations: OrganizationEntity[];
    locations: LocationEntity[];
    dates: DateEntity[];
    money: MoneyEntity[];
    contacts: ContactEntity[];
    events: EventEntity[];
    tasks: TaskEntity[];
  };
  
  // Context
  context: {
    sender?: PersonEntity;
    recipients?: PersonEntity[];
    thread?: ThreadContext;
    relatedInputs?: string[];
    householdMembers?: number[];
    urgency: UrgencyLevel;
    sentiment: SentimentAnalysis;
    intent: IntentClassification;
  };
  
  // Processing metadata
  processing: {
    startedAt: Date;
    completedAt: Date;
    processors: string[];
    confidence: number;
    warnings: string[];
    errors: string[];
  };
}

export interface PersonEntity {
  name: string;
  email?: string;
  phone?: string;
  relationship?: string;
  householdMemberId?: number;
  confidence: number;
}

export interface OrganizationEntity {
  name: string;
  type?: string;
  website?: string;
  confidence: number;
}

export interface LocationEntity {
  name: string;
  address?: string;
  coordinates?: { lat: number; lng: number };
  type?: 'home' | 'work' | 'school' | 'business' | 'other';
  confidence: number;
}

export interface DateEntity {
  text: string;
  parsed: Date;
  isRange: boolean;
  endDate?: Date;
  isRecurring: boolean;
  recurrencePattern?: string;
  timezone?: string;
  confidence: number;
}

export interface MoneyEntity {
  amount: number;
  currency: string;
  text: string;
  type?: 'payment' | 'bill' | 'income' | 'expense' | 'transfer';
  confidence: number;
}

export interface ContactEntity {
  type: 'email' | 'phone' | 'address' | 'url' | 'social';
  value: string;
  label?: string;
  confidence: number;
}

export interface EventEntity {
  title: string;
  startDate?: Date;
  endDate?: Date;
  location?: string;
  attendees?: string[];
  type?: 'meeting' | 'appointment' | 'deadline' | 'reminder' | 'social';
  confidence: number;
}

export interface TaskEntity {
  description: string;
  dueDate?: Date;
  assignee?: string;
  priority?: 'high' | 'medium' | 'low';
  confidence: number;
}

export interface ThreadContext {
  threadId: string;
  messageCount: number;
  participants: string[];
  subject?: string;
  lastActivity: Date;
}

export type UrgencyLevel = 'immediate' | 'today' | 'this_week' | 'this_month' | 'no_deadline';

export interface SentimentAnalysis {
  overall: 'positive' | 'negative' | 'neutral' | 'mixed';
  score: number; // -1 to 1
  emotions: {
    joy?: number;
    sadness?: number;
    anger?: number;
    fear?: number;
    surprise?: number;
    trust?: number;
  };
}

export interface IntentClassification {
  primary: string;
  secondary?: string[];
  confidence: number;
  requiresAction: boolean;
  requiresResponse: boolean;
  isQuestion: boolean;
  isRequest: boolean;
  isInformational: boolean;
}

// ============================================================================
// INPUT PROCESSOR INTERFACE
// ============================================================================

export interface IInputProcessor {
  name: string;
  supportedSources: InputSource[];
  supportedFormats: InputFormat[];
  priority: number;
  
  canProcess(input: RawInput): boolean;
  process(input: RawInput): Promise<Partial<ProcessedInput>>;
}

// ============================================================================
// UNIVERSAL INPUT PROCESSOR
// ============================================================================

export class UniversalInputProcessor extends EventEmitter {
  private processors: Map<string, IInputProcessor> = new Map();
  private processingQueue: RawInput[] = [];
  private isProcessing: boolean = false;
  private maxConcurrent: number = 10;
  private activeProcessing: number = 0;

  constructor() {
    super();
    this.registerDefaultProcessors();
  }

  // -------------------------------------------------------------------------
  // PROCESSOR REGISTRATION
  // -------------------------------------------------------------------------

  registerProcessor(processor: IInputProcessor): void {
    this.processors.set(processor.name, processor);
    console.log(`[UniversalInputProcessor] Registered processor: ${processor.name}`);
  }

  private registerDefaultProcessors(): void {
    // Register all built-in processors
    this.registerProcessor(new EmailProcessor());
    this.registerProcessor(new SMSProcessor());
    this.registerProcessor(new CalendarProcessor());
    this.registerProcessor(new FinancialProcessor());
    this.registerProcessor(new SmartHomeProcessor());
    this.registerProcessor(new DocumentProcessor());
    this.registerProcessor(new ImageProcessor());
    this.registerProcessor(new AudioProcessor());
    this.registerProcessor(new LocationProcessor());
    this.registerProcessor(new HealthProcessor());
    this.registerProcessor(new SocialProcessor());
    this.registerProcessor(new WebhookProcessor());
    this.registerProcessor(new GenericTextProcessor());
  }

  // -------------------------------------------------------------------------
  // INPUT PROCESSING
  // -------------------------------------------------------------------------

  async processInput(input: RawInput): Promise<ProcessedInput> {
    const startTime = new Date();
    const processorsUsed: string[] = [];
    const warnings: string[] = [];
    const errors: string[] = [];

    // Find applicable processors
    const applicableProcessors = this.findApplicableProcessors(input);
    
    if (applicableProcessors.length === 0) {
      warnings.push('No specific processor found, using generic processor');
      applicableProcessors.push(this.processors.get('generic_text')!);
    }

    // Initialize processed input
    let processed: Partial<ProcessedInput> = {
      id: this.generateId(),
      originalInputId: input.id,
      source: input.source,
      format: input.format,
      entities: {
        people: [],
        organizations: [],
        locations: [],
        dates: [],
        money: [],
        contacts: [],
        events: [],
        tasks: [],
      },
      context: {
        urgency: 'no_deadline',
        sentiment: { overall: 'neutral', score: 0, emotions: {} },
        intent: {
          primary: 'unknown',
          confidence: 0,
          requiresAction: false,
          requiresResponse: false,
          isQuestion: false,
          isRequest: false,
          isInformational: true,
        },
      },
    };

    // Run each applicable processor
    for (const processor of applicableProcessors) {
      try {
        const result = await processor.process(input);
        processed = this.mergeResults(processed, result);
        processorsUsed.push(processor.name);
      } catch (error) {
        errors.push(`Processor ${processor.name} failed: ${error}`);
      }
    }

    // Determine priority and category
    processed.priority = this.determinePriority(processed);
    processed.category = this.determineCategory(processed);

    // Calculate overall confidence
    const confidence = this.calculateConfidence(processed, processorsUsed.length);

    // Complete the processed input
    const finalProcessed: ProcessedInput = {
      ...processed as ProcessedInput,
      processing: {
        startedAt: startTime,
        completedAt: new Date(),
        processors: processorsUsed,
        confidence,
        warnings,
        errors,
      },
    };

    // Emit event for downstream processing
    this.emit('input_processed', finalProcessed);

    return finalProcessed;
  }

  private findApplicableProcessors(input: RawInput): IInputProcessor[] {
    const applicable: IInputProcessor[] = [];
    
    for (const processor of this.processors.values()) {
      if (processor.canProcess(input)) {
        applicable.push(processor);
      }
    }

    // Sort by priority (lower number = higher priority)
    return applicable.sort((a, b) => a.priority - b.priority);
  }

  private mergeResults(
    existing: Partial<ProcessedInput>,
    newResult: Partial<ProcessedInput>
  ): Partial<ProcessedInput> {
    return {
      ...existing,
      ...newResult,
      content: {
        ...existing.content,
        ...newResult.content,
      },
      entities: {
        people: [...(existing.entities?.people || []), ...(newResult.entities?.people || [])],
        organizations: [...(existing.entities?.organizations || []), ...(newResult.entities?.organizations || [])],
        locations: [...(existing.entities?.locations || []), ...(newResult.entities?.locations || [])],
        dates: [...(existing.entities?.dates || []), ...(newResult.entities?.dates || [])],
        money: [...(existing.entities?.money || []), ...(newResult.entities?.money || [])],
        contacts: [...(existing.entities?.contacts || []), ...(newResult.entities?.contacts || [])],
        events: [...(existing.entities?.events || []), ...(newResult.entities?.events || [])],
        tasks: [...(existing.entities?.tasks || []), ...(newResult.entities?.tasks || [])],
      },
      context: {
        ...existing.context,
        ...newResult.context,
      },
    };
  }

  private determinePriority(processed: Partial<ProcessedInput>): InputPriority {
    // Emergency keywords
    const emergencyKeywords = ['emergency', 'urgent', 'asap', 'immediately', '911', 'help', 'danger'];
    const text = processed.content?.text?.toLowerCase() || '';
    
    if (emergencyKeywords.some(kw => text.includes(kw))) {
      return 'critical';
    }

    // Check urgency from context
    if (processed.context?.urgency === 'immediate') {
      return 'critical';
    }
    if (processed.context?.urgency === 'today') {
      return 'high';
    }

    // Check sentiment
    if (processed.context?.sentiment?.overall === 'negative' && 
        processed.context?.sentiment?.score < -0.7) {
      return 'high';
    }

    // Check if requires action
    if (processed.context?.intent?.requiresAction) {
      return 'normal';
    }

    return 'low';
  }

  private determineCategory(processed: Partial<ProcessedInput>): InputCategory {
    const source = processed.source;
    
    // Source-based categorization
    const sourceCategories: Record<string, InputCategory> = {
      gmail: 'communication',
      outlook: 'communication',
      sms_twilio: 'communication',
      whatsapp: 'communication',
      plaid: 'financial',
      stripe: 'financial',
      google_calendar: 'scheduling',
      apple_health: 'health',
      ring: 'safety',
      nest: 'home',
      smartthings: 'home',
    };

    if (source && sourceCategories[source]) {
      return sourceCategories[source];
    }

    // Content-based categorization
    const text = processed.content?.text?.toLowerCase() || '';
    
    if (processed.entities?.money?.length) {
      return 'financial';
    }
    if (processed.entities?.events?.length) {
      return 'scheduling';
    }
    if (text.includes('doctor') || text.includes('health') || text.includes('medical')) {
      return 'health';
    }
    if (text.includes('emergency') || text.includes('alarm') || text.includes('security')) {
      return 'safety';
    }

    return 'communication';
  }

  private calculateConfidence(processed: Partial<ProcessedInput>, processorCount: number): number {
    let confidence = 0.5; // Base confidence

    // More processors = higher confidence
    confidence += Math.min(processorCount * 0.1, 0.3);

    // Content extracted = higher confidence
    if (processed.content?.text) confidence += 0.1;
    if (processed.content?.structured) confidence += 0.1;

    // Entities extracted = higher confidence
    const entityCount = Object.values(processed.entities || {})
      .reduce((sum, arr) => sum + arr.length, 0);
    confidence += Math.min(entityCount * 0.02, 0.2);

    return Math.min(confidence, 1);
  }

  private generateId(): string {
    return `input_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // -------------------------------------------------------------------------
  // BATCH PROCESSING
  // -------------------------------------------------------------------------

  async processBatch(inputs: RawInput[]): Promise<ProcessedInput[]> {
    const results: ProcessedInput[] = [];
    
    for (const input of inputs) {
      try {
        const processed = await this.processInput(input);
        results.push(processed);
      } catch (error) {
        console.error(`[UniversalInputProcessor] Failed to process input ${input.id}:`, error);
      }
    }

    return results;
  }

  // -------------------------------------------------------------------------
  // REAL-TIME PROCESSING
  // -------------------------------------------------------------------------

  async startRealtimeProcessing(): Promise<void> {
    this.isProcessing = true;
    console.log('[UniversalInputProcessor] Started real-time processing');
    
    while (this.isProcessing) {
      if (this.processingQueue.length > 0 && this.activeProcessing < this.maxConcurrent) {
        const input = this.processingQueue.shift()!;
        this.activeProcessing++;
        
        this.processInput(input)
          .then(processed => {
            this.emit('processed', processed);
          })
          .catch(error => {
            this.emit('error', { input, error });
          })
          .finally(() => {
            this.activeProcessing--;
          });
      }
      
      await new Promise(resolve => setTimeout(resolve, 10));
    }
  }

  stopRealtimeProcessing(): void {
    this.isProcessing = false;
    console.log('[UniversalInputProcessor] Stopped real-time processing');
  }

  enqueue(input: RawInput): void {
    this.processingQueue.push(input);
    this.emit('enqueued', input);
  }

  getQueueLength(): number {
    return this.processingQueue.length;
  }
}

// ============================================================================
// BUILT-IN PROCESSORS
// ============================================================================

class EmailProcessor implements IInputProcessor {
  name = 'email';
  supportedSources: InputSource[] = ['gmail', 'outlook', 'yahoo', 'protonmail', 'icloud_mail', 'generic_imap'];
  supportedFormats: InputFormat[] = ['mime', 'html', 'plain_text'];
  priority = 1;

  canProcess(input: RawInput): boolean {
    return this.supportedSources.includes(input.source) || 
           this.supportedFormats.includes(input.format);
  }

  async process(input: RawInput): Promise<Partial<ProcessedInput>> {
    const data = typeof input.rawData === 'string' ? input.rawData : input.rawData.toString();
    
    // Extract email-specific information
    const emailRegex = /[\w.-]+@[\w.-]+\.\w+/g;
    const emails = data.match(emailRegex) || [];
    
    // Extract subject if present
    const subjectMatch = data.match(/Subject:\s*(.+)/i);
    const subject = subjectMatch ? subjectMatch[1].trim() : undefined;

    // Extract sender
    const fromMatch = data.match(/From:\s*(.+)/i);
    const from = fromMatch ? fromMatch[1].trim() : undefined;

    return {
      content: {
        text: data,
        summary: subject,
      },
      entities: {
        people: from ? [{ name: from, confidence: 0.8 }] : [],
        organizations: [],
        locations: [],
        dates: this.extractDates(data),
        money: this.extractMoney(data),
        contacts: emails.map(e => ({ type: 'email' as const, value: e, confidence: 0.9 })),
        events: [],
        tasks: this.extractTasks(data),
      },
      context: {
        sender: from ? { name: from, confidence: 0.8 } : undefined,
        intent: this.classifyIntent(data),
      },
    };
  }

  private extractDates(text: string): DateEntity[] {
    const dates: DateEntity[] = [];
    // Simple date patterns
    const datePatterns = [
      /(\d{1,2}\/\d{1,2}\/\d{2,4})/g,
      /(\d{4}-\d{2}-\d{2})/g,
      /(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s*\d{4}/gi,
    ];

    for (const pattern of datePatterns) {
      const matches = text.match(pattern) || [];
      for (const match of matches) {
        const parsed = new Date(match);
        if (!isNaN(parsed.getTime())) {
          dates.push({
            text: match,
            parsed,
            isRange: false,
            isRecurring: false,
            confidence: 0.7,
          });
        }
      }
    }

    return dates;
  }

  private extractMoney(text: string): MoneyEntity[] {
    const money: MoneyEntity[] = [];
    const moneyPattern = /\$[\d,]+\.?\d*/g;
    const matches = text.match(moneyPattern) || [];

    for (const match of matches) {
      const amount = parseFloat(match.replace(/[$,]/g, ''));
      money.push({
        amount,
        currency: 'USD',
        text: match,
        confidence: 0.8,
      });
    }

    return money;
  }

  private extractTasks(text: string): TaskEntity[] {
    const tasks: TaskEntity[] = [];
    const taskPatterns = [
      /please\s+(.+?)(?:\.|$)/gi,
      /could you\s+(.+?)(?:\.|$)/gi,
      /need to\s+(.+?)(?:\.|$)/gi,
      /reminder:\s*(.+?)(?:\.|$)/gi,
    ];

    for (const pattern of taskPatterns) {
      let match;
      while ((match = pattern.exec(text)) !== null) {
        tasks.push({
          description: match[1].trim(),
          confidence: 0.6,
        });
      }
    }

    return tasks;
  }

  private classifyIntent(text: string): IntentClassification {
    const lowerText = text.toLowerCase();
    
    const isQuestion = lowerText.includes('?') || 
                       lowerText.startsWith('what') ||
                       lowerText.startsWith('when') ||
                       lowerText.startsWith('where') ||
                       lowerText.startsWith('how') ||
                       lowerText.startsWith('why');

    const isRequest = lowerText.includes('please') ||
                      lowerText.includes('could you') ||
                      lowerText.includes('would you') ||
                      lowerText.includes('can you');

    return {
      primary: isQuestion ? 'question' : isRequest ? 'request' : 'information',
      confidence: 0.7,
      requiresAction: isRequest,
      requiresResponse: isQuestion || isRequest,
      isQuestion,
      isRequest,
      isInformational: !isQuestion && !isRequest,
    };
  }
}

class SMSProcessor implements IInputProcessor {
  name = 'sms';
  supportedSources: InputSource[] = ['sms_twilio', 'whatsapp', 'telegram', 'signal', 'imessage', 'facebook_messenger'];
  supportedFormats: InputFormat[] = ['plain_text'];
  priority = 1;

  canProcess(input: RawInput): boolean {
    return this.supportedSources.includes(input.source);
  }

  async process(input: RawInput): Promise<Partial<ProcessedInput>> {
    const text = typeof input.rawData === 'string' ? input.rawData : input.rawData.toString();
    
    return {
      content: { text },
      context: {
        urgency: this.detectUrgency(text),
        sentiment: this.analyzeSentiment(text),
      },
    };
  }

  private detectUrgency(text: string): UrgencyLevel {
    const urgentKeywords = ['urgent', 'asap', 'emergency', 'now', 'immediately'];
    const lowerText = text.toLowerCase();
    
    if (urgentKeywords.some(kw => lowerText.includes(kw))) {
      return 'immediate';
    }
    if (lowerText.includes('today')) {
      return 'today';
    }
    return 'no_deadline';
  }

  private analyzeSentiment(text: string): SentimentAnalysis {
    // Simple sentiment analysis
    const positiveWords = ['thanks', 'great', 'awesome', 'love', 'happy', 'good'];
    const negativeWords = ['sorry', 'bad', 'sad', 'angry', 'hate', 'terrible'];
    
    const lowerText = text.toLowerCase();
    let score = 0;
    
    for (const word of positiveWords) {
      if (lowerText.includes(word)) score += 0.2;
    }
    for (const word of negativeWords) {
      if (lowerText.includes(word)) score -= 0.2;
    }
    
    score = Math.max(-1, Math.min(1, score));
    
    return {
      overall: score > 0.1 ? 'positive' : score < -0.1 ? 'negative' : 'neutral',
      score,
      emotions: {},
    };
  }
}

class CalendarProcessor implements IInputProcessor {
  name = 'calendar';
  supportedSources: InputSource[] = ['google_calendar', 'outlook_calendar', 'apple_calendar', 'calendly', 'generic_caldav'];
  supportedFormats: InputFormat[] = ['ical', 'json'];
  priority = 1;

  canProcess(input: RawInput): boolean {
    return this.supportedSources.includes(input.source) || input.format === 'ical';
  }

  async process(input: RawInput): Promise<Partial<ProcessedInput>> {
    const data = input.rawData;
    
    // Parse iCal or JSON calendar data
    const events: EventEntity[] = [];
    
    if (typeof data === 'object' && !Buffer.isBuffer(data)) {
      // JSON format
      const calData = data as any;
      if (calData.events) {
        for (const event of calData.events) {
          events.push({
            title: event.summary || event.title,
            startDate: new Date(event.start),
            endDate: event.end ? new Date(event.end) : undefined,
            location: event.location,
            attendees: event.attendees,
            confidence: 0.9,
          });
        }
      }
    }

    return {
      entities: {
        people: [],
        organizations: [],
        locations: [],
        dates: [],
        money: [],
        contacts: [],
        events,
        tasks: [],
      },
      context: {
        urgency: events.some(e => e.startDate && e.startDate < new Date(Date.now() + 86400000)) 
          ? 'today' : 'this_week',
      },
    };
  }
}

class FinancialProcessor implements IInputProcessor {
  name = 'financial';
  supportedSources: InputSource[] = ['plaid', 'stripe', 'paypal', 'venmo', 'bank_webhook', 'credit_card', 'crypto_wallet'];
  supportedFormats: InputFormat[] = ['json', 'ofx', 'qfx', 'qif', 'csv'];
  priority = 1;

  canProcess(input: RawInput): boolean {
    return this.supportedSources.includes(input.source) || 
           ['ofx', 'qfx', 'qif'].includes(input.format);
  }

  async process(input: RawInput): Promise<Partial<ProcessedInput>> {
    const money: MoneyEntity[] = [];
    
    if (typeof input.rawData === 'object' && !Buffer.isBuffer(input.rawData)) {
      const data = input.rawData as any;
      
      // Handle transaction data
      if (data.amount) {
        money.push({
          amount: Math.abs(data.amount),
          currency: data.currency || 'USD',
          text: `${data.currency || '$'}${Math.abs(data.amount)}`,
          type: data.amount < 0 ? 'expense' : 'income',
          confidence: 0.95,
        });
      }
      
      // Handle multiple transactions
      if (data.transactions) {
        for (const tx of data.transactions) {
          money.push({
            amount: Math.abs(tx.amount),
            currency: tx.currency || 'USD',
            text: `${tx.currency || '$'}${Math.abs(tx.amount)}`,
            type: tx.amount < 0 ? 'expense' : 'income',
            confidence: 0.95,
          });
        }
      }
    }

    return {
      entities: {
        people: [],
        organizations: [],
        locations: [],
        dates: [],
        money,
        contacts: [],
        events: [],
        tasks: [],
      },
      context: {
        urgency: money.some(m => m.amount > 1000) ? 'today' : 'no_deadline',
      },
    };
  }
}

class SmartHomeProcessor implements IInputProcessor {
  name = 'smart_home';
  supportedSources: InputSource[] = [
    'smartthings', 'home_assistant', 'homekit', 'google_home_devices', 
    'alexa_devices', 'ring', 'nest', 'ecobee', 'motion_sensor', 
    'door_sensor', 'water_sensor', 'smoke_detector', 'camera', 'doorbell'
  ];
  supportedFormats: InputFormat[] = ['json'];
  priority = 1;

  canProcess(input: RawInput): boolean {
    return this.supportedSources.includes(input.source);
  }

  async process(input: RawInput): Promise<Partial<ProcessedInput>> {
    const data = input.rawData as any;
    
    // Determine urgency based on device type and event
    let urgency: UrgencyLevel = 'no_deadline';
    let priority: InputPriority = 'low';
    
    const emergencyDevices = ['smoke_detector', 'water_sensor', 'camera', 'doorbell'];
    if (emergencyDevices.includes(input.source)) {
      if (data.alert || data.triggered || data.motion) {
        urgency = 'immediate';
        priority = 'critical';
      }
    }

    return {
      priority,
      content: {
        structured: data,
        summary: `${input.source} event: ${JSON.stringify(data).substring(0, 100)}`,
      },
      context: {
        urgency,
      },
    };
  }
}

class DocumentProcessor implements IInputProcessor {
  name = 'document';
  supportedSources: InputSource[] = ['google_drive', 'dropbox', 'onedrive', 'icloud_drive', 'file_upload'];
  supportedFormats: InputFormat[] = ['pdf', 'docx', 'xlsx', 'pptx', 'rtf'];
  priority = 2;

  canProcess(input: RawInput): boolean {
    return this.supportedFormats.includes(input.format);
  }

  async process(input: RawInput): Promise<Partial<ProcessedInput>> {
    // In a real implementation, this would use document parsing libraries
    return {
      content: {
        text: `Document received: ${input.format}`,
        summary: `Document from ${input.source}`,
      },
    };
  }
}

class ImageProcessor implements IInputProcessor {
  name = 'image';
  supportedSources: InputSource[] = ['file_upload', 'camera', 'manual'];
  supportedFormats: InputFormat[] = ['jpeg', 'png', 'gif', 'webp', 'heic', 'svg'];
  priority = 2;

  canProcess(input: RawInput): boolean {
    return this.supportedFormats.includes(input.format);
  }

  async process(input: RawInput): Promise<Partial<ProcessedInput>> {
    // In a real implementation, this would use OCR and image analysis
    return {
      content: {
        summary: `Image received: ${input.format}`,
      },
    };
  }
}

class AudioProcessor implements IInputProcessor {
  name = 'audio';
  supportedSources: InputSource[] = ['phone_call', 'voicemail', 'voice_command', 'alexa', 'google_home', 'siri'];
  supportedFormats: InputFormat[] = ['mp3', 'wav', 'aac', 'ogg', 'm4a'];
  priority = 2;

  canProcess(input: RawInput): boolean {
    return this.supportedSources.includes(input.source) || this.supportedFormats.includes(input.format);
  }

  async process(input: RawInput): Promise<Partial<ProcessedInput>> {
    // In a real implementation, this would use speech-to-text
    return {
      content: {
        summary: `Audio received from ${input.source}`,
      },
    };
  }
}

class LocationProcessor implements IInputProcessor {
  name = 'location';
  supportedSources: InputSource[] = ['gps', 'geofence', 'tile', 'airtag', 'life360', 'vehicle_gps'];
  supportedFormats: InputFormat[] = ['json'];
  priority = 1;

  canProcess(input: RawInput): boolean {
    return this.supportedSources.includes(input.source);
  }

  async process(input: RawInput): Promise<Partial<ProcessedInput>> {
    const data = input.rawData as any;
    const locations: LocationEntity[] = [];

    if (data.lat && data.lng) {
      locations.push({
        name: data.name || 'Current Location',
        coordinates: { lat: data.lat, lng: data.lng },
        confidence: 0.95,
      });
    }

    return {
      entities: {
        people: [],
        organizations: [],
        locations,
        dates: [],
        money: [],
        contacts: [],
        events: [],
        tasks: [],
      },
    };
  }
}

class HealthProcessor implements IInputProcessor {
  name = 'health';
  supportedSources: InputSource[] = ['apple_health', 'google_fit', 'fitbit', 'garmin', 'whoop', 'oura'];
  supportedFormats: InputFormat[] = ['json'];
  priority = 1;

  canProcess(input: RawInput): boolean {
    return this.supportedSources.includes(input.source);
  }

  async process(input: RawInput): Promise<Partial<ProcessedInput>> {
    const data = input.rawData as any;
    
    // Check for concerning health metrics
    let urgency: UrgencyLevel = 'no_deadline';
    
    if (data.heartRate && (data.heartRate > 150 || data.heartRate < 40)) {
      urgency = 'immediate';
    }
    if (data.bloodOxygen && data.bloodOxygen < 90) {
      urgency = 'immediate';
    }

    return {
      content: {
        structured: data,
        summary: `Health data from ${input.source}`,
      },
      context: {
        urgency,
      },
    };
  }
}

class SocialProcessor implements IInputProcessor {
  name = 'social';
  supportedSources: InputSource[] = ['facebook', 'instagram', 'twitter', 'linkedin', 'nextdoor'];
  supportedFormats: InputFormat[] = ['json', 'html'];
  priority = 3;

  canProcess(input: RawInput): boolean {
    return this.supportedSources.includes(input.source);
  }

  async process(input: RawInput): Promise<Partial<ProcessedInput>> {
    return {
      content: {
        summary: `Social media update from ${input.source}`,
      },
      context: {
        urgency: 'no_deadline',
      },
    };
  }
}

class WebhookProcessor implements IInputProcessor {
  name = 'webhook';
  supportedSources: InputSource[] = ['webhook', 'api'];
  supportedFormats: InputFormat[] = ['json', 'xml'];
  priority = 2;

  canProcess(input: RawInput): boolean {
    return this.supportedSources.includes(input.source);
  }

  async process(input: RawInput): Promise<Partial<ProcessedInput>> {
    const data = input.rawData;
    
    return {
      content: {
        structured: typeof data === 'object' ? data : undefined,
        text: typeof data === 'string' ? data : JSON.stringify(data),
      },
    };
  }
}

class GenericTextProcessor implements IInputProcessor {
  name = 'generic_text';
  supportedSources: InputSource[] = ['manual', 'internal'];
  supportedFormats: InputFormat[] = ['plain_text', 'html', 'markdown', 'unknown'];
  priority = 100; // Lowest priority - fallback processor

  canProcess(input: RawInput): boolean {
    return true; // Can process anything as fallback
  }

  async process(input: RawInput): Promise<Partial<ProcessedInput>> {
    const text = typeof input.rawData === 'string' 
      ? input.rawData 
      : Buffer.isBuffer(input.rawData) 
        ? input.rawData.toString() 
        : JSON.stringify(input.rawData);

    return {
      content: {
        text,
        summary: text.substring(0, 200),
      },
    };
  }
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

export const universalInputProcessor = new UniversalInputProcessor();
