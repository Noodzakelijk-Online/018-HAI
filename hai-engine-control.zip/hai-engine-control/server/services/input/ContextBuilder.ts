/**
 * Context Builder
 * 
 * Builds comprehensive context for any input by:
 * - Analyzing the input's relationship to household members
 * - Determining urgency and priority
 * - Identifying related past interactions
 * - Understanding the current household state
 * - Predicting likely follow-up actions
 */

import { ProcessedInput, InputPriority, UrgencyLevel } from './UniversalInputProcessor';
import { ExtractedEntities } from './EntityExtractor';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

export interface InputContext {
  // Core identification
  inputId: string;
  timestamp: Date;
  
  // Household context
  household: HouseholdContext;
  
  // Participant context
  participants: ParticipantContext;
  
  // Temporal context
  temporal: TemporalContext;
  
  // Relationship to past interactions
  history: HistoryContext;
  
  // Current state awareness
  state: StateContext;
  
  // Predicted outcomes
  predictions: PredictionContext;
  
  // Priority and urgency
  priority: PriorityContext;
  
  // Confidence in context accuracy
  confidence: number;
}

export interface HouseholdContext {
  householdId: number;
  affectedMembers: AffectedMember[];
  relevantRules: RelevantRule[];
  activeScenarios: string[];
  currentMode: 'normal' | 'vacation' | 'away' | 'sleep' | 'work' | 'emergency';
}

export interface AffectedMember {
  memberId: number;
  name: string;
  role: string;
  tier: number;
  relevance: 'primary' | 'secondary' | 'informed' | 'none';
  notificationPreference?: string;
  currentLocation?: string;
  currentActivity?: string;
}

export interface RelevantRule {
  ruleId: string;
  name: string;
  type: 'explicit' | 'implicit' | 'default';
  priority: number;
  applies: boolean;
  conditions: string[];
}

export interface ParticipantContext {
  sender?: ParticipantInfo;
  recipients: ParticipantInfo[];
  mentioned: ParticipantInfo[];
  inferred: ParticipantInfo[];
}

export interface ParticipantInfo {
  identifier: string;
  type: 'household_member' | 'known_contact' | 'organization' | 'unknown';
  memberId?: number;
  contactId?: string;
  name?: string;
  relationship?: string;
  trustLevel: number;
  communicationHistory: {
    totalInteractions: number;
    lastInteraction?: Date;
    sentiment: 'positive' | 'neutral' | 'negative';
  };
}

export interface TemporalContext {
  // When the input was received
  receivedAt: Date;
  
  // Time-based analysis
  timeOfDay: 'morning' | 'afternoon' | 'evening' | 'night';
  dayOfWeek: string;
  isWeekend: boolean;
  isHoliday: boolean;
  holidayName?: string;
  
  // Deadlines and time sensitivity
  hasDeadline: boolean;
  deadline?: Date;
  timeUntilDeadline?: number; // milliseconds
  
  // Recurring patterns
  isRecurring: boolean;
  recurrencePattern?: string;
  lastOccurrence?: Date;
  nextOccurrence?: Date;
  
  // Time zone awareness
  senderTimezone?: string;
  householdTimezone: string;
  timezoneOffset?: number;
}

export interface HistoryContext {
  // Related past inputs
  relatedInputs: RelatedInput[];
  
  // Thread/conversation context
  thread?: ThreadInfo;
  
  // Similar past situations
  similarSituations: SimilarSituation[];
  
  // Past actions taken
  pastActions: PastAction[];
  
  // Learning from history
  learnedPatterns: LearnedPattern[];
}

export interface RelatedInput {
  inputId: string;
  timestamp: Date;
  type: string;
  summary: string;
  relevance: number;
  relationship: 'reply' | 'forward' | 'reference' | 'similar' | 'followup';
}

export interface ThreadInfo {
  threadId: string;
  subject?: string;
  messageCount: number;
  participants: string[];
  startDate: Date;
  lastActivity: Date;
  summary?: string;
}

export interface SimilarSituation {
  situationId: string;
  timestamp: Date;
  description: string;
  similarity: number;
  outcome: string;
  actionsTaken: string[];
  wasSuccessful: boolean;
}

export interface PastAction {
  actionId: string;
  timestamp: Date;
  type: string;
  description: string;
  outcome: 'success' | 'partial' | 'failed' | 'pending';
  relatedTo: string;
}

export interface LearnedPattern {
  patternId: string;
  description: string;
  confidence: number;
  applicability: number;
  suggestedAction?: string;
}

export interface StateContext {
  // Household state
  householdState: {
    occupancy: 'home' | 'away' | 'partial';
    presentMembers: number[];
    activeDevices: string[];
    securityStatus: 'armed' | 'disarmed' | 'partial';
    environmentalAlerts: string[];
  };
  
  // Financial state
  financialState: {
    recentTransactions: number;
    unusualActivity: boolean;
    upcomingBills: number;
    budgetStatus: 'on_track' | 'over_budget' | 'under_budget';
  };
  
  // Calendar state
  calendarState: {
    currentEvents: string[];
    upcomingEvents: number;
    conflicts: number;
    busyLevel: 'free' | 'light' | 'moderate' | 'busy' | 'overloaded';
  };
  
  // Communication state
  communicationState: {
    unreadMessages: number;
    pendingResponses: number;
    urgentItems: number;
    averageResponseTime: number;
  };
  
  // System state
  systemState: {
    activeAutomations: string[];
    pendingActions: number;
    recentErrors: number;
    healthStatus: 'healthy' | 'degraded' | 'critical';
  };
}

export interface PredictionContext {
  // Likely required actions
  likelyActions: PredictedAction[];
  
  // Expected follow-ups
  expectedFollowups: ExpectedFollowup[];
  
  // Potential issues
  potentialIssues: PotentialIssue[];
  
  // Recommended responses
  recommendedResponses: RecommendedResponse[];
  
  // Confidence in predictions
  overallConfidence: number;
}

export interface PredictedAction {
  actionType: string;
  description: string;
  probability: number;
  urgency: UrgencyLevel;
  automatable: boolean;
  requiresApproval: boolean;
  estimatedDuration?: number;
}

export interface ExpectedFollowup {
  type: string;
  description: string;
  probability: number;
  expectedTimeframe: string;
  from?: string;
}

export interface PotentialIssue {
  type: string;
  description: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  probability: number;
  mitigation?: string;
}

export interface RecommendedResponse {
  type: 'auto' | 'draft' | 'suggest' | 'escalate';
  content?: string;
  recipient?: string;
  channel?: string;
  timing?: string;
  confidence: number;
}

export interface PriorityContext {
  // Calculated priority
  priority: InputPriority;
  urgency: UrgencyLevel;
  
  // Priority factors
  factors: PriorityFactor[];
  
  // Override information
  manualOverride?: {
    by: string;
    reason: string;
    timestamp: Date;
  };
  
  // SLA information
  sla?: {
    responseTime: number;
    deadline: Date;
    status: 'within' | 'approaching' | 'breached';
  };
}

export interface PriorityFactor {
  factor: string;
  weight: number;
  value: number;
  contribution: number;
  description: string;
}

// ============================================================================
// CONTEXT BUILDER
// ============================================================================

export class ContextBuilder {
  private householdCache: Map<number, any> = new Map();
  private memberCache: Map<number, any> = new Map();
  private ruleCache: Map<string, any> = new Map();

  async buildContext(
    input: ProcessedInput,
    entities: ExtractedEntities,
    householdId: number
  ): Promise<InputContext> {
    const startTime = Date.now();

    // Build all context components in parallel where possible
    const [
      householdContext,
      participantContext,
      temporalContext,
      historyContext,
      stateContext,
    ] = await Promise.all([
      this.buildHouseholdContext(input, entities, householdId),
      this.buildParticipantContext(input, entities, householdId),
      this.buildTemporalContext(input, entities),
      this.buildHistoryContext(input, entities, householdId),
      this.buildStateContext(householdId),
    ]);

    // Build predictions based on other context
    const predictionContext = await this.buildPredictionContext(
      input,
      entities,
      householdContext,
      historyContext,
      stateContext
    );

    // Calculate priority
    const priorityContext = this.buildPriorityContext(
      input,
      entities,
      householdContext,
      temporalContext,
      stateContext
    );

    // Calculate overall confidence
    const confidence = this.calculateOverallConfidence(
      householdContext,
      participantContext,
      historyContext,
      predictionContext
    );

    return {
      inputId: input.id,
      timestamp: new Date(),
      household: householdContext,
      participants: participantContext,
      temporal: temporalContext,
      history: historyContext,
      state: stateContext,
      predictions: predictionContext,
      priority: priorityContext,
      confidence,
    };
  }

  // -------------------------------------------------------------------------
  // HOUSEHOLD CONTEXT
  // -------------------------------------------------------------------------

  private async buildHouseholdContext(
    input: ProcessedInput,
    entities: ExtractedEntities,
    householdId: number
  ): Promise<HouseholdContext> {
    // Get household data (would come from database in production)
    const household = await this.getHousehold(householdId);
    
    // Identify affected members
    const affectedMembers = await this.identifyAffectedMembers(
      input,
      entities,
      householdId
    );

    // Find relevant rules
    const relevantRules = await this.findRelevantRules(
      input,
      entities,
      householdId
    );

    // Detect active scenarios
    const activeScenarios = this.detectActiveScenarios(input, entities);

    // Determine current mode
    const currentMode = await this.determineHouseholdMode(householdId);

    return {
      householdId,
      affectedMembers,
      relevantRules,
      activeScenarios,
      currentMode,
    };
  }

  private async getHousehold(householdId: number): Promise<any> {
    if (this.householdCache.has(householdId)) {
      return this.householdCache.get(householdId);
    }

    // In production, fetch from database
    const household = {
      id: householdId,
      name: 'Default Household',
      members: [],
      settings: {},
    };

    this.householdCache.set(householdId, household);
    return household;
  }

  private async identifyAffectedMembers(
    input: ProcessedInput,
    entities: ExtractedEntities,
    householdId: number
  ): Promise<AffectedMember[]> {
    const affected: AffectedMember[] = [];

    // Check sender
    if (input.context?.sender) {
      const member = await this.findMemberByIdentifier(
        input.context.sender.name || input.context.sender.email || '',
        householdId
      );
      if (member) {
        affected.push({
          ...member,
          relevance: 'primary',
        });
      }
    }

    // Check mentioned people
    for (const person of entities.people) {
      const member = await this.findMemberByIdentifier(person.name, householdId);
      if (member && !affected.find(a => a.memberId === member.memberId)) {
        affected.push({
          ...member,
          relevance: 'secondary',
        });
      }
    }

    // If no specific members identified, consider all members informed
    if (affected.length === 0) {
      // In production, add all household members with 'informed' relevance
    }

    return affected;
  }

  private async findMemberByIdentifier(
    identifier: string,
    householdId: number
  ): Promise<AffectedMember | null> {
    // In production, search database for matching member
    return null;
  }

  private async findRelevantRules(
    input: ProcessedInput,
    entities: ExtractedEntities,
    householdId: number
  ): Promise<RelevantRule[]> {
    const rules: RelevantRule[] = [];

    // In production, query rules database based on:
    // - Input category
    // - Entities present
    // - Current household state
    // - Time of day
    // - Affected members

    return rules;
  }

  private detectActiveScenarios(
    input: ProcessedInput,
    entities: ExtractedEntities
  ): string[] {
    const scenarios: string[] = [];

    // Detect based on content
    const text = input.content?.text?.toLowerCase() || '';

    if (text.includes('emergency') || text.includes('urgent')) {
      scenarios.push('emergency');
    }
    if (entities.money.length > 0) {
      scenarios.push('financial');
    }
    if (entities.events.length > 0) {
      scenarios.push('scheduling');
    }
    if (text.includes('doctor') || text.includes('health') || text.includes('medical')) {
      scenarios.push('health');
    }
    if (text.includes('travel') || text.includes('flight') || text.includes('hotel')) {
      scenarios.push('travel');
    }

    return scenarios;
  }

  private async determineHouseholdMode(householdId: number): Promise<HouseholdContext['currentMode']> {
    // In production, check:
    // - Location of members
    // - Time of day
    // - Calendar events
    // - Smart home state
    // - Manual mode settings

    const hour = new Date().getHours();
    if (hour >= 23 || hour < 6) return 'sleep';
    if (hour >= 9 && hour < 17) return 'work';
    return 'normal';
  }

  // -------------------------------------------------------------------------
  // PARTICIPANT CONTEXT
  // -------------------------------------------------------------------------

  private async buildParticipantContext(
    input: ProcessedInput,
    entities: ExtractedEntities,
    householdId: number
  ): Promise<ParticipantContext> {
    const sender = input.context?.sender
      ? await this.resolveParticipant(input.context.sender, householdId)
      : undefined;

    const recipients = await Promise.all(
      (input.context?.recipients || []).map(r => this.resolveParticipant(r, householdId))
    );

    const mentioned = await Promise.all(
      entities.people.map(p => this.resolveParticipant(p, householdId))
    );

    // Infer additional participants from context
    const inferred = await this.inferParticipants(input, entities, householdId);

    return {
      sender,
      recipients,
      mentioned,
      inferred,
    };
  }

  private async resolveParticipant(
    person: { name?: string; email?: string; phone?: string },
    householdId: number
  ): Promise<ParticipantInfo> {
    // Try to match to household member
    const identifier = person.email || person.phone || person.name || 'unknown';

    // In production, search database for matching contact
    return {
      identifier,
      type: 'unknown',
      name: person.name,
      trustLevel: 0.5,
      communicationHistory: {
        totalInteractions: 0,
        sentiment: 'neutral',
      },
    };
  }

  private async inferParticipants(
    input: ProcessedInput,
    entities: ExtractedEntities,
    householdId: number
  ): Promise<ParticipantInfo[]> {
    const inferred: ParticipantInfo[] = [];

    // Infer from organizations
    for (const org of entities.organizations) {
      inferred.push({
        identifier: org.name,
        type: 'organization',
        name: org.name,
        trustLevel: 0.6,
        communicationHistory: {
          totalInteractions: 0,
          sentiment: 'neutral',
        },
      });
    }

    return inferred;
  }

  // -------------------------------------------------------------------------
  // TEMPORAL CONTEXT
  // -------------------------------------------------------------------------

  private async buildTemporalContext(
    input: ProcessedInput,
    entities: ExtractedEntities
  ): Promise<TemporalContext> {
    const now = new Date();
    const hour = now.getHours();
    const day = now.getDay();
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    // Determine time of day
    let timeOfDay: TemporalContext['timeOfDay'];
    if (hour >= 5 && hour < 12) timeOfDay = 'morning';
    else if (hour >= 12 && hour < 17) timeOfDay = 'afternoon';
    else if (hour >= 17 && hour < 21) timeOfDay = 'evening';
    else timeOfDay = 'night';

    // Check for deadlines in entities
    const deadlines = entities.dates.filter(d => 
      d.type === 'date' || d.type === 'datetime'
    );
    const hasDeadline = deadlines.length > 0;
    const deadline = deadlines[0]?.parsed;

    // Check for recurring patterns
    const recurring = entities.dates.find(d => d.type === 'recurring');

    return {
      receivedAt: input.processing?.completedAt || now,
      timeOfDay,
      dayOfWeek: dayNames[day],
      isWeekend: day === 0 || day === 6,
      isHoliday: this.isHoliday(now),
      holidayName: this.getHolidayName(now),
      hasDeadline,
      deadline,
      timeUntilDeadline: deadline ? deadline.getTime() - now.getTime() : undefined,
      isRecurring: !!recurring,
      recurrencePattern: recurring?.recurrence?.frequency,
      householdTimezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    };
  }

  private isHoliday(date: Date): boolean {
    // Check against known holidays
    const holidays = this.getHolidays(date.getFullYear());
    const dateStr = `${date.getMonth() + 1}-${date.getDate()}`;
    return holidays.has(dateStr);
  }

  private getHolidayName(date: Date): string | undefined {
    const holidays = this.getHolidays(date.getFullYear());
    const dateStr = `${date.getMonth() + 1}-${date.getDate()}`;
    return holidays.get(dateStr);
  }

  private getHolidays(year: number): Map<string, string> {
    // US Federal Holidays (simplified - fixed dates only)
    return new Map([
      ['1-1', "New Year's Day"],
      ['7-4', 'Independence Day'],
      ['12-25', 'Christmas Day'],
      ['11-11', "Veterans Day"],
    ]);
  }

  // -------------------------------------------------------------------------
  // HISTORY CONTEXT
  // -------------------------------------------------------------------------

  private async buildHistoryContext(
    input: ProcessedInput,
    entities: ExtractedEntities,
    householdId: number
  ): Promise<HistoryContext> {
    // Find related past inputs
    const relatedInputs = await this.findRelatedInputs(input, householdId);

    // Get thread context if applicable
    const thread = input.context?.thread
      ? await this.getThreadInfo(input.context.thread.threadId)
      : undefined;

    // Find similar past situations
    const similarSituations = await this.findSimilarSituations(
      input,
      entities,
      householdId
    );

    // Get past actions related to this type of input
    const pastActions = await this.getPastActions(input, householdId);

    // Get learned patterns
    const learnedPatterns = await this.getLearnedPatterns(input, entities, householdId);

    return {
      relatedInputs,
      thread,
      similarSituations,
      pastActions,
      learnedPatterns,
    };
  }

  private async findRelatedInputs(
    input: ProcessedInput,
    householdId: number
  ): Promise<RelatedInput[]> {
    // In production, search input history for:
    // - Same thread/conversation
    // - Same sender
    // - Similar content
    // - Same entities mentioned
    return [];
  }

  private async getThreadInfo(threadId: string): Promise<ThreadInfo | undefined> {
    // In production, fetch thread from database
    return undefined;
  }

  private async findSimilarSituations(
    input: ProcessedInput,
    entities: ExtractedEntities,
    householdId: number
  ): Promise<SimilarSituation[]> {
    // In production, use ML to find similar past situations
    return [];
  }

  private async getPastActions(
    input: ProcessedInput,
    householdId: number
  ): Promise<PastAction[]> {
    // In production, query action history
    return [];
  }

  private async getLearnedPatterns(
    input: ProcessedInput,
    entities: ExtractedEntities,
    householdId: number
  ): Promise<LearnedPattern[]> {
    // In production, query pattern database
    return [];
  }

  // -------------------------------------------------------------------------
  // STATE CONTEXT
  // -------------------------------------------------------------------------

  private async buildStateContext(householdId: number): Promise<StateContext> {
    // In production, aggregate state from various sources
    return {
      householdState: {
        occupancy: 'home',
        presentMembers: [],
        activeDevices: [],
        securityStatus: 'disarmed',
        environmentalAlerts: [],
      },
      financialState: {
        recentTransactions: 0,
        unusualActivity: false,
        upcomingBills: 0,
        budgetStatus: 'on_track',
      },
      calendarState: {
        currentEvents: [],
        upcomingEvents: 0,
        conflicts: 0,
        busyLevel: 'light',
      },
      communicationState: {
        unreadMessages: 0,
        pendingResponses: 0,
        urgentItems: 0,
        averageResponseTime: 0,
      },
      systemState: {
        activeAutomations: [],
        pendingActions: 0,
        recentErrors: 0,
        healthStatus: 'healthy',
      },
    };
  }

  // -------------------------------------------------------------------------
  // PREDICTION CONTEXT
  // -------------------------------------------------------------------------

  private async buildPredictionContext(
    input: ProcessedInput,
    entities: ExtractedEntities,
    household: HouseholdContext,
    history: HistoryContext,
    state: StateContext
  ): Promise<PredictionContext> {
    const likelyActions = this.predictActions(input, entities, history);
    const expectedFollowups = this.predictFollowups(input, entities, history);
    const potentialIssues = this.identifyPotentialIssues(input, entities, state);
    const recommendedResponses = this.generateRecommendedResponses(
      input,
      entities,
      household,
      history
    );

    const overallConfidence = this.calculatePredictionConfidence(
      likelyActions,
      expectedFollowups,
      history
    );

    return {
      likelyActions,
      expectedFollowups,
      potentialIssues,
      recommendedResponses,
      overallConfidence,
    };
  }

  private predictActions(
    input: ProcessedInput,
    entities: ExtractedEntities,
    history: HistoryContext
  ): PredictedAction[] {
    const actions: PredictedAction[] = [];

    // Based on intent
    if (input.context?.intent?.requiresResponse) {
      actions.push({
        actionType: 'respond',
        description: 'Send a response to this message',
        probability: 0.9,
        urgency: input.context.urgency,
        automatable: false,
        requiresApproval: true,
      });
    }

    // Based on tasks extracted
    for (const task of entities.tasks) {
      actions.push({
        actionType: 'task',
        description: task.description,
        probability: 0.7,
        urgency: task.dueDate ? 'today' : 'this_week',
        automatable: false,
        requiresApproval: true,
      });
    }

    // Based on events
    for (const event of entities.events) {
      actions.push({
        actionType: 'calendar',
        description: `Add event: ${event.title}`,
        probability: 0.8,
        urgency: 'today',
        automatable: true,
        requiresApproval: false,
      });
    }

    // Based on money
    if (entities.money.length > 0) {
      actions.push({
        actionType: 'financial',
        description: 'Review financial transaction',
        probability: 0.6,
        urgency: 'today',
        automatable: false,
        requiresApproval: true,
      });
    }

    return actions;
  }

  private predictFollowups(
    input: ProcessedInput,
    entities: ExtractedEntities,
    history: HistoryContext
  ): ExpectedFollowup[] {
    const followups: ExpectedFollowup[] = [];

    // If this is a question, expect an answer
    if (input.context?.intent?.isQuestion) {
      followups.push({
        type: 'response',
        description: 'Response to question',
        probability: 0.8,
        expectedTimeframe: '24 hours',
      });
    }

    // If this mentions a deadline, expect reminder
    if (entities.dates.some(d => d.type === 'date')) {
      followups.push({
        type: 'reminder',
        description: 'Deadline reminder',
        probability: 0.7,
        expectedTimeframe: 'before deadline',
      });
    }

    return followups;
  }

  private identifyPotentialIssues(
    input: ProcessedInput,
    entities: ExtractedEntities,
    state: StateContext
  ): PotentialIssue[] {
    const issues: PotentialIssue[] = [];

    // Calendar conflicts
    if (entities.events.length > 0 && state.calendarState.conflicts > 0) {
      issues.push({
        type: 'scheduling_conflict',
        description: 'Potential calendar conflict detected',
        severity: 'medium',
        probability: 0.6,
        mitigation: 'Review calendar before confirming',
      });
    }

    // Budget concerns
    if (entities.money.some(m => m.amount > 500) && state.financialState.budgetStatus === 'over_budget') {
      issues.push({
        type: 'budget_concern',
        description: 'Large expense while over budget',
        severity: 'high',
        probability: 0.7,
        mitigation: 'Review budget before approving',
      });
    }

    return issues;
  }

  private generateRecommendedResponses(
    input: ProcessedInput,
    entities: ExtractedEntities,
    household: HouseholdContext,
    history: HistoryContext
  ): RecommendedResponse[] {
    const responses: RecommendedResponse[] = [];

    // Based on similar past situations
    for (const situation of history.similarSituations) {
      if (situation.wasSuccessful && situation.similarity > 0.8) {
        responses.push({
          type: 'suggest',
          content: `Based on past experience: ${situation.outcome}`,
          confidence: situation.similarity,
        });
      }
    }

    // Auto-response for simple acknowledgments
    if (input.context?.intent?.isInformational && !input.context?.intent?.requiresAction) {
      responses.push({
        type: 'auto',
        content: 'Acknowledged. I\'ve noted this information.',
        confidence: 0.9,
      });
    }

    return responses;
  }

  private calculatePredictionConfidence(
    actions: PredictedAction[],
    followups: ExpectedFollowup[],
    history: HistoryContext
  ): number {
    let confidence = 0.5;

    // More history = higher confidence
    if (history.similarSituations.length > 0) {
      confidence += 0.2;
    }
    if (history.learnedPatterns.length > 0) {
      confidence += 0.1;
    }

    // High probability predictions increase confidence
    const avgActionProb = actions.length > 0
      ? actions.reduce((sum, a) => sum + a.probability, 0) / actions.length
      : 0;
    confidence += avgActionProb * 0.2;

    return Math.min(confidence, 1);
  }

  // -------------------------------------------------------------------------
  // PRIORITY CONTEXT
  // -------------------------------------------------------------------------

  private buildPriorityContext(
    input: ProcessedInput,
    entities: ExtractedEntities,
    household: HouseholdContext,
    temporal: TemporalContext,
    state: StateContext
  ): PriorityContext {
    const factors: PriorityFactor[] = [];

    // Factor: Urgency keywords
    const urgencyScore = this.calculateUrgencyScore(input);
    factors.push({
      factor: 'urgency_keywords',
      weight: 0.3,
      value: urgencyScore,
      contribution: urgencyScore * 0.3,
      description: 'Based on urgent language in content',
    });

    // Factor: Deadline proximity
    const deadlineScore = temporal.hasDeadline
      ? Math.max(0, 1 - (temporal.timeUntilDeadline || 0) / (7 * 24 * 60 * 60 * 1000))
      : 0;
    factors.push({
      factor: 'deadline_proximity',
      weight: 0.25,
      value: deadlineScore,
      contribution: deadlineScore * 0.25,
      description: 'Based on how close the deadline is',
    });

    // Factor: Financial amount
    const maxAmount = Math.max(...entities.money.map(m => m.amount), 0);
    const financialScore = Math.min(maxAmount / 1000, 1);
    factors.push({
      factor: 'financial_impact',
      weight: 0.2,
      value: financialScore,
      contribution: financialScore * 0.2,
      description: 'Based on financial amounts involved',
    });

    // Factor: Sender importance
    const senderScore = this.calculateSenderImportance(input, household);
    factors.push({
      factor: 'sender_importance',
      weight: 0.15,
      value: senderScore,
      contribution: senderScore * 0.15,
      description: 'Based on sender relationship and tier',
    });

    // Factor: System state
    const stateScore = state.systemState.healthStatus === 'critical' ? 1 :
                       state.systemState.healthStatus === 'degraded' ? 0.5 : 0;
    factors.push({
      factor: 'system_state',
      weight: 0.1,
      value: stateScore,
      contribution: stateScore * 0.1,
      description: 'Based on current system health',
    });

    // Calculate total score
    const totalScore = factors.reduce((sum, f) => sum + f.contribution, 0);

    // Determine priority
    let priority: InputPriority;
    if (totalScore > 0.8) priority = 'critical';
    else if (totalScore > 0.6) priority = 'high';
    else if (totalScore > 0.3) priority = 'normal';
    else priority = 'low';

    // Determine urgency
    let urgency: UrgencyLevel;
    if (temporal.hasDeadline && temporal.timeUntilDeadline! < 24 * 60 * 60 * 1000) {
      urgency = 'today';
    } else if (temporal.hasDeadline && temporal.timeUntilDeadline! < 7 * 24 * 60 * 60 * 1000) {
      urgency = 'this_week';
    } else if (urgencyScore > 0.7) {
      urgency = 'immediate';
    } else {
      urgency = 'no_deadline';
    }

    return {
      priority,
      urgency,
      factors,
    };
  }

  private calculateUrgencyScore(input: ProcessedInput): number {
    const text = input.content?.text?.toLowerCase() || '';
    const urgentKeywords = [
      'urgent', 'asap', 'immediately', 'emergency', 'critical',
      'time-sensitive', 'deadline', 'overdue', 'final notice',
    ];

    let score = 0;
    for (const keyword of urgentKeywords) {
      if (text.includes(keyword)) {
        score += 0.2;
      }
    }

    return Math.min(score, 1);
  }

  private calculateSenderImportance(
    input: ProcessedInput,
    household: HouseholdContext
  ): number {
    // Check if sender is a household member
    const senderMember = household.affectedMembers.find(
      m => m.relevance === 'primary'
    );

    if (senderMember) {
      // Higher tier = more important
      return 1 - (senderMember.tier - 1) * 0.2;
    }

    // Unknown sender
    return 0.3;
  }

  // -------------------------------------------------------------------------
  // CONFIDENCE CALCULATION
  // -------------------------------------------------------------------------

  private calculateOverallConfidence(
    household: HouseholdContext,
    participants: ParticipantContext,
    history: HistoryContext,
    predictions: PredictionContext
  ): number {
    let confidence = 0.5;

    // More identified members = higher confidence
    if (household.affectedMembers.length > 0) {
      confidence += 0.1;
    }

    // Known sender = higher confidence
    if (participants.sender?.type === 'household_member') {
      confidence += 0.15;
    } else if (participants.sender?.type === 'known_contact') {
      confidence += 0.1;
    }

    // Historical data = higher confidence
    if (history.relatedInputs.length > 0) {
      confidence += 0.1;
    }
    if (history.similarSituations.length > 0) {
      confidence += 0.1;
    }

    // Prediction confidence
    confidence += predictions.overallConfidence * 0.1;

    return Math.min(confidence, 1);
  }
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

export const contextBuilder = new ContextBuilder();
