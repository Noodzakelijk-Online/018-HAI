/**
 * Source Connectors
 * 
 * Unified interface for connecting to ANY input source:
 * - Email (Gmail, Outlook, Yahoo, etc.)
 * - Messaging (SMS, WhatsApp, Telegram, etc.)
 * - Calendar (Google, Outlook, Apple, etc.)
 * - Financial (Banks, Credit Cards, Payment Services)
 * - Smart Home (SmartThings, HomeKit, etc.)
 * - Health (Apple Health, Fitbit, etc.)
 * - Location (GPS, Geofencing, etc.)
 * - And many more...
 */

import { EventEmitter } from 'events';
import { InputSource, RawInput, InputFormat } from './UniversalInputProcessor';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

export interface ConnectorConfig {
  id: string;
  type: InputSource;
  name: string;
  enabled: boolean;
  credentials?: ConnectorCredentials;
  settings: ConnectorSettings;
  polling?: PollingConfig;
  webhook?: WebhookConfig;
  rateLimit?: RateLimitConfig;
}

export interface ConnectorCredentials {
  type: 'oauth2' | 'api_key' | 'basic' | 'bearer' | 'custom';
  accessToken?: string;
  refreshToken?: string;
  apiKey?: string;
  username?: string;
  password?: string;
  expiresAt?: Date;
  scopes?: string[];
  customData?: Record<string, any>;
}

export interface ConnectorSettings {
  syncInterval?: number; // milliseconds
  batchSize?: number;
  filters?: Record<string, any>;
  transformations?: TransformationRule[];
  retryPolicy?: RetryPolicy;
}

export interface TransformationRule {
  field: string;
  operation: 'map' | 'filter' | 'transform' | 'extract';
  config: Record<string, any>;
}

export interface RetryPolicy {
  maxRetries: number;
  initialDelay: number;
  maxDelay: number;
  backoffMultiplier: number;
}

export interface PollingConfig {
  enabled: boolean;
  interval: number;
  lastPoll?: Date;
  cursor?: string;
}

export interface WebhookConfig {
  enabled: boolean;
  url: string;
  secret?: string;
  events: string[];
}

export interface RateLimitConfig {
  requestsPerMinute: number;
  requestsPerHour: number;
  requestsPerDay: number;
}

export interface ConnectorStatus {
  connectorId: string;
  status: 'connected' | 'disconnected' | 'error' | 'rate_limited' | 'expired';
  lastSync?: Date;
  lastError?: string;
  itemsProcessed: number;
  health: {
    latency: number;
    errorRate: number;
    uptime: number;
  };
}

export interface SyncResult {
  connectorId: string;
  success: boolean;
  itemsReceived: number;
  itemsProcessed: number;
  errors: SyncError[];
  duration: number;
  nextCursor?: string;
}

export interface SyncError {
  itemId?: string;
  error: string;
  recoverable: boolean;
}

// ============================================================================
// BASE CONNECTOR
// ============================================================================

export abstract class BaseConnector extends EventEmitter {
  protected config: ConnectorConfig;
  protected status: ConnectorStatus;
  protected isPolling: boolean = false;
  protected pollInterval?: NodeJS.Timeout;

  constructor(config: ConnectorConfig) {
    super();
    this.config = config;
    this.status = {
      connectorId: config.id,
      status: 'disconnected',
      itemsProcessed: 0,
      health: {
        latency: 0,
        errorRate: 0,
        uptime: 0,
      },
    };
  }

  // Abstract methods to be implemented by specific connectors
  abstract connect(): Promise<boolean>;
  abstract disconnect(): Promise<void>;
  abstract fetchItems(cursor?: string): Promise<{ items: RawInput[]; nextCursor?: string }>;
  abstract validateCredentials(): Promise<boolean>;
  abstract refreshCredentials(): Promise<ConnectorCredentials | null>;

  // Common methods
  async sync(): Promise<SyncResult> {
    const startTime = Date.now();
    const errors: SyncError[] = [];
    let itemsReceived = 0;
    let itemsProcessed = 0;

    try {
      // Validate connection
      if (this.status.status !== 'connected') {
        const connected = await this.connect();
        if (!connected) {
          return {
            connectorId: this.config.id,
            success: false,
            itemsReceived: 0,
            itemsProcessed: 0,
            errors: [{ error: 'Failed to connect', recoverable: true }],
            duration: Date.now() - startTime,
          };
        }
      }

      // Fetch items
      const cursor = this.config.polling?.cursor;
      const { items, nextCursor } = await this.fetchItems(cursor);
      itemsReceived = items.length;

      // Process each item
      for (const item of items) {
        try {
          this.emit('item', item);
          itemsProcessed++;
          this.status.itemsProcessed++;
        } catch (error) {
          errors.push({
            itemId: item.id,
            error: String(error),
            recoverable: true,
          });
        }
      }

      // Update cursor
      if (nextCursor && this.config.polling) {
        this.config.polling.cursor = nextCursor;
      }

      this.status.lastSync = new Date();
      this.updateHealth(errors.length, itemsProcessed, Date.now() - startTime);

      return {
        connectorId: this.config.id,
        success: errors.length === 0,
        itemsReceived,
        itemsProcessed,
        errors,
        duration: Date.now() - startTime,
        nextCursor,
      };
    } catch (error) {
      this.status.status = 'error';
      this.status.lastError = String(error);

      return {
        connectorId: this.config.id,
        success: false,
        itemsReceived,
        itemsProcessed,
        errors: [{ error: String(error), recoverable: false }],
        duration: Date.now() - startTime,
      };
    }
  }

  startPolling(): void {
    if (this.isPolling || !this.config.polling?.enabled) return;

    this.isPolling = true;
    const interval = this.config.polling?.interval || 60000;

    this.pollInterval = setInterval(async () => {
      await this.sync();
    }, interval);

    // Initial sync
    this.sync();
  }

  stopPolling(): void {
    this.isPolling = false;
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
      this.pollInterval = undefined;
    }
  }

  getStatus(): ConnectorStatus {
    return { ...this.status };
  }

  getConfig(): ConnectorConfig {
    return { ...this.config };
  }

  updateConfig(updates: Partial<ConnectorConfig>): void {
    this.config = { ...this.config, ...updates };
  }

  protected updateHealth(errors: number, processed: number, latency: number): void {
    const errorRate = processed > 0 ? errors / processed : 0;
    this.status.health = {
      latency,
      errorRate,
      uptime: this.status.status === 'connected' ? 100 : 0,
    };
  }

  protected generateInputId(): string {
    return `${this.config.type}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

// ============================================================================
// EMAIL CONNECTORS
// ============================================================================

export class GmailConnector extends BaseConnector {
  async connect(): Promise<boolean> {
    if (!this.config.credentials?.accessToken) {
      this.status.status = 'disconnected';
      return false;
    }

    // In production, validate token with Gmail API
    this.status.status = 'connected';
    return true;
  }

  async disconnect(): Promise<void> {
    this.status.status = 'disconnected';
  }

  async fetchItems(cursor?: string): Promise<{ items: RawInput[]; nextCursor?: string }> {
    // In production, call Gmail API
    // GET https://gmail.googleapis.com/gmail/v1/users/me/messages
    
    const items: RawInput[] = [];
    // Simulated response
    return { items, nextCursor: undefined };
  }

  async validateCredentials(): Promise<boolean> {
    if (!this.config.credentials?.accessToken) return false;
    // In production, call Gmail API to validate
    return true;
  }

  async refreshCredentials(): Promise<ConnectorCredentials | null> {
    if (!this.config.credentials?.refreshToken) return null;
    // In production, use OAuth2 refresh flow
    return this.config.credentials;
  }
}

export class OutlookConnector extends BaseConnector {
  async connect(): Promise<boolean> {
    if (!this.config.credentials?.accessToken) {
      this.status.status = 'disconnected';
      return false;
    }
    this.status.status = 'connected';
    return true;
  }

  async disconnect(): Promise<void> {
    this.status.status = 'disconnected';
  }

  async fetchItems(cursor?: string): Promise<{ items: RawInput[]; nextCursor?: string }> {
    // In production, call Microsoft Graph API
    // GET https://graph.microsoft.com/v1.0/me/messages
    return { items: [], nextCursor: undefined };
  }

  async validateCredentials(): Promise<boolean> {
    return !!this.config.credentials?.accessToken;
  }

  async refreshCredentials(): Promise<ConnectorCredentials | null> {
    return this.config.credentials || null;
  }
}

// ============================================================================
// MESSAGING CONNECTORS
// ============================================================================

export class TwilioSMSConnector extends BaseConnector {
  async connect(): Promise<boolean> {
    if (!this.config.credentials?.apiKey) {
      this.status.status = 'disconnected';
      return false;
    }
    this.status.status = 'connected';
    return true;
  }

  async disconnect(): Promise<void> {
    this.status.status = 'disconnected';
  }

  async fetchItems(cursor?: string): Promise<{ items: RawInput[]; nextCursor?: string }> {
    // In production, call Twilio API
    return { items: [], nextCursor: undefined };
  }

  async validateCredentials(): Promise<boolean> {
    return !!this.config.credentials?.apiKey;
  }

  async refreshCredentials(): Promise<ConnectorCredentials | null> {
    return this.config.credentials || null;
  }

  async sendMessage(to: string, body: string): Promise<boolean> {
    // In production, call Twilio API to send SMS
    console.log(`[TwilioSMS] Sending to ${to}: ${body}`);
    return true;
  }
}

export class WhatsAppConnector extends BaseConnector {
  async connect(): Promise<boolean> {
    if (!this.config.credentials?.accessToken) {
      this.status.status = 'disconnected';
      return false;
    }
    this.status.status = 'connected';
    return true;
  }

  async disconnect(): Promise<void> {
    this.status.status = 'disconnected';
  }

  async fetchItems(cursor?: string): Promise<{ items: RawInput[]; nextCursor?: string }> {
    // In production, use WhatsApp Business API
    return { items: [], nextCursor: undefined };
  }

  async validateCredentials(): Promise<boolean> {
    return !!this.config.credentials?.accessToken;
  }

  async refreshCredentials(): Promise<ConnectorCredentials | null> {
    return this.config.credentials || null;
  }
}

// ============================================================================
// CALENDAR CONNECTORS
// ============================================================================

export class GoogleCalendarConnector extends BaseConnector {
  async connect(): Promise<boolean> {
    if (!this.config.credentials?.accessToken) {
      this.status.status = 'disconnected';
      return false;
    }
    this.status.status = 'connected';
    return true;
  }

  async disconnect(): Promise<void> {
    this.status.status = 'disconnected';
  }

  async fetchItems(cursor?: string): Promise<{ items: RawInput[]; nextCursor?: string }> {
    // In production, call Google Calendar API
    // GET https://www.googleapis.com/calendar/v3/calendars/primary/events
    return { items: [], nextCursor: undefined };
  }

  async validateCredentials(): Promise<boolean> {
    return !!this.config.credentials?.accessToken;
  }

  async refreshCredentials(): Promise<ConnectorCredentials | null> {
    return this.config.credentials || null;
  }

  async createEvent(event: any): Promise<string | null> {
    // In production, call Google Calendar API
    console.log(`[GoogleCalendar] Creating event: ${event.summary}`);
    return `event_${Date.now()}`;
  }
}

// ============================================================================
// FINANCIAL CONNECTORS
// ============================================================================

export class PlaidConnector extends BaseConnector {
  async connect(): Promise<boolean> {
    if (!this.config.credentials?.accessToken) {
      this.status.status = 'disconnected';
      return false;
    }
    this.status.status = 'connected';
    return true;
  }

  async disconnect(): Promise<void> {
    this.status.status = 'disconnected';
  }

  async fetchItems(cursor?: string): Promise<{ items: RawInput[]; nextCursor?: string }> {
    // In production, call Plaid API for transactions
    return { items: [], nextCursor: undefined };
  }

  async validateCredentials(): Promise<boolean> {
    return !!this.config.credentials?.accessToken;
  }

  async refreshCredentials(): Promise<ConnectorCredentials | null> {
    return this.config.credentials || null;
  }

  async getAccounts(): Promise<any[]> {
    // In production, call Plaid API
    return [];
  }

  async getTransactions(startDate: Date, endDate: Date): Promise<any[]> {
    // In production, call Plaid API
    return [];
  }
}

export class StripeConnector extends BaseConnector {
  async connect(): Promise<boolean> {
    if (!this.config.credentials?.apiKey) {
      this.status.status = 'disconnected';
      return false;
    }
    this.status.status = 'connected';
    return true;
  }

  async disconnect(): Promise<void> {
    this.status.status = 'disconnected';
  }

  async fetchItems(cursor?: string): Promise<{ items: RawInput[]; nextCursor?: string }> {
    // In production, call Stripe API for events
    return { items: [], nextCursor: undefined };
  }

  async validateCredentials(): Promise<boolean> {
    return !!this.config.credentials?.apiKey;
  }

  async refreshCredentials(): Promise<ConnectorCredentials | null> {
    return this.config.credentials || null;
  }
}

// ============================================================================
// SMART HOME CONNECTORS
// ============================================================================

export class SmartThingsConnector extends BaseConnector {
  async connect(): Promise<boolean> {
    if (!this.config.credentials?.accessToken) {
      this.status.status = 'disconnected';
      return false;
    }
    this.status.status = 'connected';
    return true;
  }

  async disconnect(): Promise<void> {
    this.status.status = 'disconnected';
  }

  async fetchItems(cursor?: string): Promise<{ items: RawInput[]; nextCursor?: string }> {
    // In production, call SmartThings API
    return { items: [], nextCursor: undefined };
  }

  async validateCredentials(): Promise<boolean> {
    return !!this.config.credentials?.accessToken;
  }

  async refreshCredentials(): Promise<ConnectorCredentials | null> {
    return this.config.credentials || null;
  }

  async getDevices(): Promise<any[]> {
    // In production, call SmartThings API
    return [];
  }

  async executeCommand(deviceId: string, command: string, args?: any): Promise<boolean> {
    // In production, call SmartThings API
    console.log(`[SmartThings] Executing ${command} on ${deviceId}`);
    return true;
  }
}

export class HomeAssistantConnector extends BaseConnector {
  private baseUrl: string = '';

  async connect(): Promise<boolean> {
    if (!this.config.credentials?.accessToken) {
      this.status.status = 'disconnected';
      return false;
    }
    this.baseUrl = this.config.settings.filters?.baseUrl || 'http://homeassistant.local:8123';
    this.status.status = 'connected';
    return true;
  }

  async disconnect(): Promise<void> {
    this.status.status = 'disconnected';
  }

  async fetchItems(cursor?: string): Promise<{ items: RawInput[]; nextCursor?: string }> {
    // In production, call Home Assistant API
    return { items: [], nextCursor: undefined };
  }

  async validateCredentials(): Promise<boolean> {
    return !!this.config.credentials?.accessToken;
  }

  async refreshCredentials(): Promise<ConnectorCredentials | null> {
    return this.config.credentials || null;
  }

  async callService(domain: string, service: string, data?: any): Promise<boolean> {
    // In production, call Home Assistant API
    console.log(`[HomeAssistant] Calling ${domain}.${service}`);
    return true;
  }
}

// ============================================================================
// HEALTH CONNECTORS
// ============================================================================

export class AppleHealthConnector extends BaseConnector {
  async connect(): Promise<boolean> {
    // Apple Health requires HealthKit integration on iOS
    this.status.status = 'connected';
    return true;
  }

  async disconnect(): Promise<void> {
    this.status.status = 'disconnected';
  }

  async fetchItems(cursor?: string): Promise<{ items: RawInput[]; nextCursor?: string }> {
    // In production, receive data from iOS app via webhook
    return { items: [], nextCursor: undefined };
  }

  async validateCredentials(): Promise<boolean> {
    return true;
  }

  async refreshCredentials(): Promise<ConnectorCredentials | null> {
    return null;
  }
}

export class FitbitConnector extends BaseConnector {
  async connect(): Promise<boolean> {
    if (!this.config.credentials?.accessToken) {
      this.status.status = 'disconnected';
      return false;
    }
    this.status.status = 'connected';
    return true;
  }

  async disconnect(): Promise<void> {
    this.status.status = 'disconnected';
  }

  async fetchItems(cursor?: string): Promise<{ items: RawInput[]; nextCursor?: string }> {
    // In production, call Fitbit API
    return { items: [], nextCursor: undefined };
  }

  async validateCredentials(): Promise<boolean> {
    return !!this.config.credentials?.accessToken;
  }

  async refreshCredentials(): Promise<ConnectorCredentials | null> {
    return this.config.credentials || null;
  }
}

// ============================================================================
// LOCATION CONNECTORS
// ============================================================================

export class Life360Connector extends BaseConnector {
  async connect(): Promise<boolean> {
    if (!this.config.credentials?.accessToken) {
      this.status.status = 'disconnected';
      return false;
    }
    this.status.status = 'connected';
    return true;
  }

  async disconnect(): Promise<void> {
    this.status.status = 'disconnected';
  }

  async fetchItems(cursor?: string): Promise<{ items: RawInput[]; nextCursor?: string }> {
    // In production, call Life360 API
    return { items: [], nextCursor: undefined };
  }

  async validateCredentials(): Promise<boolean> {
    return !!this.config.credentials?.accessToken;
  }

  async refreshCredentials(): Promise<ConnectorCredentials | null> {
    return this.config.credentials || null;
  }

  async getMemberLocations(): Promise<any[]> {
    // In production, call Life360 API
    return [];
  }
}

// ============================================================================
// WEBHOOK CONNECTOR
// ============================================================================

export class WebhookConnector extends BaseConnector {
  private receivedItems: RawInput[] = [];

  async connect(): Promise<boolean> {
    this.status.status = 'connected';
    return true;
  }

  async disconnect(): Promise<void> {
    this.status.status = 'disconnected';
  }

  async fetchItems(cursor?: string): Promise<{ items: RawInput[]; nextCursor?: string }> {
    const items = [...this.receivedItems];
    this.receivedItems = [];
    return { items, nextCursor: undefined };
  }

  async validateCredentials(): Promise<boolean> {
    return true;
  }

  async refreshCredentials(): Promise<ConnectorCredentials | null> {
    return null;
  }

  // Called when webhook receives data
  receiveWebhook(data: any, headers?: Record<string, string>): void {
    const input: RawInput = {
      id: this.generateInputId(),
      source: 'webhook',
      format: 'json',
      rawData: data,
      metadata: {
        receivedAt: new Date(),
        headers,
      },
    };

    this.receivedItems.push(input);
    this.emit('item', input);
  }

  // Validate webhook signature
  validateSignature(payload: string, signature: string): boolean {
    if (!this.config.webhook?.secret) return true;
    
    // In production, validate HMAC signature
    // const expectedSignature = crypto.createHmac('sha256', this.config.webhook.secret)
    //   .update(payload)
    //   .digest('hex');
    // return signature === expectedSignature;
    
    return true;
  }
}

// ============================================================================
// CONNECTOR MANAGER
// ============================================================================

export class ConnectorManager extends EventEmitter {
  private connectors: Map<string, BaseConnector> = new Map();
  private connectorTypes: Map<InputSource, new (config: ConnectorConfig) => BaseConnector> = new Map();

  constructor() {
    super();
    this.registerDefaultConnectorTypes();
  }

  private registerDefaultConnectorTypes(): void {
    this.connectorTypes.set('gmail', GmailConnector);
    this.connectorTypes.set('outlook', OutlookConnector);
    this.connectorTypes.set('sms_twilio', TwilioSMSConnector);
    this.connectorTypes.set('whatsapp', WhatsAppConnector);
    this.connectorTypes.set('google_calendar', GoogleCalendarConnector);
    this.connectorTypes.set('plaid', PlaidConnector);
    this.connectorTypes.set('stripe', StripeConnector);
    this.connectorTypes.set('smartthings', SmartThingsConnector);
    this.connectorTypes.set('home_assistant', HomeAssistantConnector);
    this.connectorTypes.set('apple_health', AppleHealthConnector);
    this.connectorTypes.set('fitbit', FitbitConnector);
    this.connectorTypes.set('life360', Life360Connector);
    this.connectorTypes.set('webhook', WebhookConnector);
  }

  createConnector(config: ConnectorConfig): BaseConnector | null {
    const ConnectorClass = this.connectorTypes.get(config.type);
    if (!ConnectorClass) {
      console.error(`[ConnectorManager] Unknown connector type: ${config.type}`);
      return null;
    }

    const connector = new ConnectorClass(config);
    
    // Forward events
    connector.on('item', (item: RawInput) => {
      this.emit('item', { connectorId: config.id, item });
    });

    this.connectors.set(config.id, connector);
    return connector;
  }

  getConnector(id: string): BaseConnector | undefined {
    return this.connectors.get(id);
  }

  getAllConnectors(): BaseConnector[] {
    return Array.from(this.connectors.values());
  }

  async removeConnector(id: string): Promise<void> {
    const connector = this.connectors.get(id);
    if (connector) {
      connector.stopPolling();
      await connector.disconnect();
      this.connectors.delete(id);
    }
  }

  async syncAll(): Promise<Map<string, SyncResult>> {
    const results = new Map<string, SyncResult>();
    
    for (const [id, connector] of this.connectors) {
      if (connector.getConfig().enabled) {
        const result = await connector.sync();
        results.set(id, result);
      }
    }

    return results;
  }

  startAllPolling(): void {
    for (const connector of this.connectors.values()) {
      if (connector.getConfig().enabled && connector.getConfig().polling?.enabled) {
        connector.startPolling();
      }
    }
  }

  stopAllPolling(): void {
    for (const connector of this.connectors.values()) {
      connector.stopPolling();
    }
  }

  getStatuses(): Map<string, ConnectorStatus> {
    const statuses = new Map<string, ConnectorStatus>();
    for (const [id, connector] of this.connectors) {
      statuses.set(id, connector.getStatus());
    }
    return statuses;
  }
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

export const connectorManager = new ConnectorManager();
