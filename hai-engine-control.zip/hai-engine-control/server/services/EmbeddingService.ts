/**
 * Embedding Service
 * 
 * Generates text embeddings for semantic search.
 */

class EmbeddingServiceClass {
  private cache = new Map<string, number[]>();
  private cacheMaxSize = 1000;

  /**
   * Generate embedding for text
   */
  async generateEmbedding(text: string): Promise<number[]> {
    const cacheKey = text.substring(0, 200);
    if (this.cache.has(cacheKey)) {
      return this.cache.get(cacheKey)!;
    }

    const embedding = this.simpleTextEmbedding(text);
    
    if (this.cache.size >= this.cacheMaxSize) {
      const firstKey = this.cache.keys().next().value;
      if (firstKey) this.cache.delete(firstKey);
    }
    this.cache.set(cacheKey, embedding);
    
    return embedding;
  }

  /**
   * Simple text embedding using TF-IDF-like approach
   */
  private simpleTextEmbedding(text: string): number[] {
    const dimensions = 128;
    const embedding = new Array(dimensions).fill(0);
    
    const normalized = text.toLowerCase().replace(/[^\w\s]/g, '');
    const words = normalized.split(/\s+/).filter(w => w.length > 2);
    
    for (const word of words) {
      const hash = this.hashString(word);
      const index = Math.abs(hash) % dimensions;
      embedding[index] += 1 / Math.sqrt(words.length || 1);
    }
    
    for (let i = 0; i < normalized.length - 2; i++) {
      const ngram = normalized.substring(i, i + 3);
      const hash = this.hashString(ngram);
      const index = Math.abs(hash) % dimensions;
      embedding[index] += 0.1 / Math.sqrt(normalized.length || 1);
    }
    
    const magnitude = Math.sqrt(embedding.reduce((sum, val) => sum + val * val, 0));
    if (magnitude > 0) {
      for (let i = 0; i < dimensions; i++) {
        embedding[i] /= magnitude;
      }
    }
    
    return embedding;
  }

  private hashString(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return hash;
  }

  cosineSimilarity(a: number[], b: number[]): number {
    if (a.length !== b.length) return 0;
    
    let dotProduct = 0;
    let magnitudeA = 0;
    let magnitudeB = 0;
    
    for (let i = 0; i < a.length; i++) {
      dotProduct += a[i] * b[i];
      magnitudeA += a[i] * a[i];
      magnitudeB += b[i] * b[i];
    }
    
    magnitudeA = Math.sqrt(magnitudeA);
    magnitudeB = Math.sqrt(magnitudeB);
    
    if (magnitudeA === 0 || magnitudeB === 0) return 0;
    
    return dotProduct / (magnitudeA * magnitudeB);
  }

  clearCache(): void {
    this.cache.clear();
  }
}

export const EmbeddingService = new EmbeddingServiceClass();
