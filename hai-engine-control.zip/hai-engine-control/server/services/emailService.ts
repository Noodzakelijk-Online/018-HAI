import nodemailer from 'nodemailer';
import { ENV } from '../_core/env';

/**
 * Email Notification Service
 * Handles sending emails for authentication events and security alerts
 */

// Email configuration from environment variables
const EMAIL_HOST = process.env.EMAIL_HOST || 'smtp.gmail.com';
const EMAIL_PORT = parseInt(process.env.EMAIL_PORT || '587');
const EMAIL_USER = process.env.EMAIL_USER;
const EMAIL_PASSWORD = process.env.EMAIL_PASSWORD;
const EMAIL_FROM = process.env.EMAIL_FROM || EMAIL_USER;
const APP_URL = process.env.APP_URL || 'http://localhost:3000';

let transporter: nodemailer.Transporter | null = null;

/**
 * Initialize email transporter
 */
function getTransporter(): nodemailer.Transporter | null {
  if (!EMAIL_USER || !EMAIL_PASSWORD) {
    console.warn('[Email] Email credentials not configured. Emails will be logged to console.');
    return null;
  }

  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: EMAIL_HOST,
      port: EMAIL_PORT,
      secure: EMAIL_PORT === 465, // true for 465, false for other ports
      auth: {
        user: EMAIL_USER,
        pass: EMAIL_PASSWORD,
      },
    });
  }

  return transporter;
}

/**
 * Send an email (or log to console if not configured)
 */
export async function sendEmail(options: {
  to: string;
  subject: string;
  html: string;
}): Promise<boolean> {
  const { to, subject, html } = options;

  const transport = getTransporter();

  if (!transport) {
    // Log to console if email is not configured
    console.log('\n=== EMAIL NOTIFICATION ===');
    console.log(`To: ${to}`);
    console.log(`Subject: ${subject}`);
    console.log(`Body:\n${html}`);
    console.log('=========================\n');
    return true;
  }

  try {
    await transport.sendMail({
      from: EMAIL_FROM,
      to,
      subject,
      html,
    });
    console.log(`[Email] Sent to ${to}: ${subject}`);
    return true;
  } catch (error) {
    console.error('[Email] Failed to send email:', error);
    return false;
  }
}

/**
 * Send password reset email
 */
export async function sendPasswordResetEmail(
  email: string,
  name: string,
  resetToken: string
): Promise<boolean> {
  const resetUrl = `${APP_URL}/reset-password?token=${resetToken}`;

  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #0066cc; color: white; padding: 20px; text-align: center; }
        .content { background: #f9f9f9; padding: 30px; border: 1px solid #ddd; }
        .button { display: inline-block; padding: 12px 30px; background: #0066cc; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
        .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
        .warning { background: #fff3cd; border: 1px solid #ffc107; padding: 15px; margin: 20px 0; border-radius: 5px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Password Reset Request</h1>
        </div>
        <div class="content">
          <p>Hello ${name || 'there'},</p>
          <p>We received a request to reset your password for your HAI Engine Control Center account.</p>
          <p>Click the button below to reset your password:</p>
          <p style="text-align: center;">
            <a href="${resetUrl}" class="button">Reset Password</a>
          </p>
          <p>Or copy and paste this link into your browser:</p>
          <p style="word-break: break-all; color: #0066cc;">${resetUrl}</p>
          <div class="warning">
            <strong>⚠️ Security Notice:</strong>
            <ul>
              <li>This link will expire in 1 hour</li>
              <li>If you didn't request this reset, please ignore this email</li>
              <li>Your password will not change unless you click the link above</li>
            </ul>
          </div>
        </div>
        <div class="footer">
          <p>This is an automated message from HAI Engine Control Center</p>
          <p>Please do not reply to this email</p>
        </div>
      </div>
    </body>
    </html>
  `;

  return await sendEmail({ to: email, subject: 'Password Reset Request - HAI Engine Control Center', html });
}

/**
 * Send account lockout notification
 */
export async function sendAccountLockoutEmail(
  email: string,
  name: string,
  lockedUntil: Date
): Promise<boolean> {
  const unlockTime = lockedUntil.toLocaleString();

  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #dc3545; color: white; padding: 20px; text-align: center; }
        .content { background: #f9f9f9; padding: 30px; border: 1px solid #ddd; }
        .alert { background: #f8d7da; border: 1px solid #dc3545; padding: 15px; margin: 20px 0; border-radius: 5px; color: #721c24; }
        .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🔒 Account Temporarily Locked</h1>
        </div>
        <div class="content">
          <p>Hello ${name || 'there'},</p>
          <div class="alert">
            <strong>⚠️ Security Alert:</strong>
            <p>Your account has been temporarily locked due to multiple failed login attempts.</p>
          </div>
          <p><strong>Lockout Details:</strong></p>
          <ul>
            <li>Your account will be automatically unlocked at: <strong>${unlockTime}</strong></li>
            <li>This is a security measure to protect your account</li>
            <li>After the lockout period, you can try logging in again</li>
          </ul>
          <p><strong>What to do:</strong></p>
          <ul>
            <li>If this was you, please wait until the lockout expires</li>
            <li>If this wasn't you, someone may be trying to access your account</li>
            <li>Consider changing your password after the lockout expires</li>
          </ul>
          <p>If you need immediate assistance, please contact support.</p>
        </div>
        <div class="footer">
          <p>This is an automated security notification from HAI Engine Control Center</p>
          <p>Please do not reply to this email</p>
        </div>
      </div>
    </body>
    </html>
  `;

  return await sendEmail({ to: email, subject: '🔒 Account Locked - Security Alert', html });
}

/**
 * Send password change confirmation
 */
export async function sendPasswordChangeConfirmationEmail(
  email: string,
  name: string
): Promise<boolean> {
  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #28a745; color: white; padding: 20px; text-align: center; }
        .content { background: #f9f9f9; padding: 30px; border: 1px solid #ddd; }
        .success { background: #d4edda; border: 1px solid #28a745; padding: 15px; margin: 20px 0; border-radius: 5px; color: #155724; }
        .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>✅ Password Changed Successfully</h1>
        </div>
        <div class="content">
          <p>Hello ${name || 'there'},</p>
          <div class="success">
            <strong>✅ Confirmation:</strong>
            <p>Your password has been successfully changed.</p>
          </div>
          <p><strong>Details:</strong></p>
          <ul>
            <li>Time: ${new Date().toLocaleString()}</li>
            <li>Your account is secure</li>
            <li>You can now use your new password to log in</li>
          </ul>
          <p><strong>⚠️ If you didn't make this change:</strong></p>
          <ul>
            <li>Your account may be compromised</li>
            <li>Contact support immediately</li>
            <li>Reset your password as soon as possible</li>
          </ul>
        </div>
        <div class="footer">
          <p>This is an automated security notification from HAI Engine Control Center</p>
          <p>Please do not reply to this email</p>
        </div>
      </div>
    </body>
    </html>
  `;

  return await sendEmail({ to: email, subject: '✅ Password Changed - HAI Engine Control Center', html });
}

/**
 * Send 2FA setup confirmation
 */
export async function send2FAEnabledEmail(
  email: string,
  name: string
): Promise<boolean> {
  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #28a745; color: white; padding: 20px; text-align: center; }
        .content { background: #f9f9f9; padding: 30px; border: 1px solid #ddd; }
        .success { background: #d4edda; border: 1px solid #28a745; padding: 15px; margin: 20px 0; border-radius: 5px; color: #155724; }
        .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🔐 Two-Factor Authentication Enabled</h1>
        </div>
        <div class="content">
          <p>Hello ${name || 'there'},</p>
          <div class="success">
            <strong>✅ Enhanced Security:</strong>
            <p>Two-factor authentication (2FA) has been successfully enabled on your account.</p>
          </div>
          <p><strong>What this means:</strong></p>
          <ul>
            <li>Your account is now more secure</li>
            <li>You'll need your authenticator app to log in</li>
            <li>Keep your backup codes in a safe place</li>
          </ul>
          <p><strong>⚠️ If you didn't enable 2FA:</strong></p>
          <ul>
            <li>Your account may be compromised</li>
            <li>Contact support immediately</li>
            <li>Change your password as soon as possible</li>
          </ul>
        </div>
        <div class="footer">
          <p>This is an automated security notification from HAI Engine Control Center</p>
          <p>Please do not reply to this email</p>
        </div>
      </div>
    </body>
    </html>
  `;

  return await sendEmail({ to: email, subject: '🔐 2FA Enabled - HAI Engine Control Center', html });
}
