/**
 * Correlation ID Middleware
 * Implements P1 #53: Add correlation IDs for request tracing
 */

import type { Request, Response, NextFunction } from 'express';
import { AsyncLocalStorage } from 'async_hooks';

// Async local storage for correlation ID propagation
const correlationStorage = new AsyncLocalStorage<string>();

const CORRELATION_HEADER = 'x-correlation-id';
const REQUEST_ID_HEADER = 'x-request-id';

/**
 * Generate a unique correlation ID
 */
export function generateCorrelationId(): string {
  const timestamp = Date.now().toString(36);
  const random = Math.random().toString(36).substring(2, 10);
  return `${timestamp}-${random}`;
}

/**
 * Get current correlation ID from async context
 */
export function getCorrelationId(): string | undefined {
  return correlationStorage.getStore();
}

/**
 * Run a function with a specific correlation ID
 */
export function withCorrelationId<T>(correlationId: string, fn: () => T): T {
  return correlationStorage.run(correlationId, fn);
}

/**
 * Express middleware to extract or generate correlation ID
 */
export function correlationIdMiddleware() {
  return (req: Request, res: Response, next: NextFunction) => {
    // Get correlation ID from header or generate new one
    const correlationId = 
      req.headers[CORRELATION_HEADER] as string ||
      req.headers[REQUEST_ID_HEADER] as string ||
      generateCorrelationId();
    
    // Store in request object for easy access
    (req as any).correlationId = correlationId;
    
    // Set response header
    res.setHeader(CORRELATION_HEADER, correlationId);
    
    // Run the rest of the middleware chain with correlation context
    correlationStorage.run(correlationId, () => {
      next();
    });
  };
}

/**
 * Create a logger that includes correlation ID
 */
export function createCorrelatedLogger(baseLogger?: Console) {
  const logger = baseLogger || console;
  
  const addCorrelation = (args: any[]) => {
    const correlationId = getCorrelationId();
    if (correlationId) {
      return [`[${correlationId}]`, ...args];
    }
    return args;
  };
  
  return {
    log: (...args: any[]) => logger.log(...addCorrelation(args)),
    info: (...args: any[]) => logger.info(...addCorrelation(args)),
    warn: (...args: any[]) => logger.warn(...addCorrelation(args)),
    error: (...args: any[]) => logger.error(...addCorrelation(args)),
    debug: (...args: any[]) => logger.debug(...addCorrelation(args)),
  };
}

/**
 * Propagate correlation ID to outgoing HTTP requests
 */
export function getCorrelationHeaders(): Record<string, string> {
  const correlationId = getCorrelationId();
  if (correlationId) {
    return { [CORRELATION_HEADER]: correlationId };
  }
  return {};
}

/**
 * Wrap fetch to automatically include correlation ID
 */
export function correlatedFetch(
  input: RequestInfo | URL,
  init?: RequestInit
): Promise<Response> {
  const headers = new Headers(init?.headers);
  const correlationId = getCorrelationId();
  
  if (correlationId && !headers.has(CORRELATION_HEADER)) {
    headers.set(CORRELATION_HEADER, correlationId);
  }
  
  return fetch(input, { ...init, headers });
}

/**
 * Request context with correlation ID and metadata
 */
export interface RequestContext {
  correlationId: string;
  requestId: string;
  startTime: number;
  userId?: number;
  path: string;
  method: string;
}

const requestContextStorage = new AsyncLocalStorage<RequestContext>();

/**
 * Get current request context
 */
export function getRequestContext(): RequestContext | undefined {
  return requestContextStorage.getStore();
}

/**
 * Enhanced middleware that stores full request context
 */
export function requestContextMiddleware() {
  return (req: Request, res: Response, next: NextFunction) => {
    const correlationId = 
      req.headers[CORRELATION_HEADER] as string ||
      generateCorrelationId();
    
    const context: RequestContext = {
      correlationId,
      requestId: generateCorrelationId(),
      startTime: Date.now(),
      userId: (req as any).user?.id,
      path: req.path,
      method: req.method,
    };
    
    (req as any).context = context;
    res.setHeader(CORRELATION_HEADER, correlationId);
    res.setHeader(REQUEST_ID_HEADER, context.requestId);
    
    // Log request start
    console.log(`[${correlationId}] ${req.method} ${req.path} started`);
    
    // Log request end
    res.on('finish', () => {
      const duration = Date.now() - context.startTime;
      console.log(`[${correlationId}] ${req.method} ${req.path} completed in ${duration}ms (${res.statusCode})`);
    });
    
    requestContextStorage.run(context, () => {
      correlationStorage.run(correlationId, () => {
        next();
      });
    });
  };
}

export default {
  generateCorrelationId,
  getCorrelationId,
  withCorrelationId,
  correlationIdMiddleware,
  createCorrelatedLogger,
  getCorrelationHeaders,
  correlatedFetch,
  getRequestContext,
  requestContextMiddleware,
  CORRELATION_HEADER,
  REQUEST_ID_HEADER,
};
