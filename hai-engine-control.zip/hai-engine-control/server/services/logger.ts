/**
 * Structured Logger Service
 * Implements P2 #97: Replace console.log with structured logging
 */

export type LogLevel = 'debug' | 'info' | 'warn' | 'error' | 'fatal';

export interface LogEntry {
  timestamp: string;
  level: LogLevel;
  service: string;
  message: string;
  data?: Record<string, unknown>;
  error?: {
    name: string;
    message: string;
    stack?: string;
  };
  correlationId?: string;
  userId?: number;
  requestId?: string;
}

interface LoggerConfig {
  minLevel: LogLevel;
  includeTimestamp: boolean;
  includeStack: boolean;
  prettyPrint: boolean;
  outputToConsole: boolean;
  outputToFile: boolean;
  filePath?: string;
}

const LOG_LEVELS: Record<LogLevel, number> = {
  debug: 0,
  info: 1,
  warn: 2,
  error: 3,
  fatal: 4,
};

const LOG_COLORS: Record<LogLevel, string> = {
  debug: '\x1b[36m', // Cyan
  info: '\x1b[32m',  // Green
  warn: '\x1b[33m',  // Yellow
  error: '\x1b[31m', // Red
  fatal: '\x1b[35m', // Magenta
};

const RESET_COLOR = '\x1b[0m';

let config: LoggerConfig = {
  minLevel: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
  includeTimestamp: true,
  includeStack: process.env.NODE_ENV !== 'production',
  prettyPrint: process.env.NODE_ENV !== 'production',
  outputToConsole: true,
  outputToFile: false,
};

// In-memory log buffer for recent logs
const logBuffer: LogEntry[] = [];
const MAX_BUFFER_SIZE = 1000;

/**
 * Configure the logger
 */
export function configure(newConfig: Partial<LoggerConfig>): void {
  config = { ...config, ...newConfig };
}

/**
 * Create a log entry
 */
function createLogEntry(
  level: LogLevel,
  service: string,
  message: string,
  data?: Record<string, unknown>,
  error?: Error
): LogEntry {
  const entry: LogEntry = {
    timestamp: new Date().toISOString(),
    level,
    service,
    message,
  };
  
  if (data) {
    entry.data = data;
  }
  
  if (error) {
    entry.error = {
      name: error.name,
      message: error.message,
      stack: config.includeStack ? error.stack : undefined,
    };
  }
  
  return entry;
}

/**
 * Format log entry for output
 */
function formatLogEntry(entry: LogEntry): string {
  if (config.prettyPrint) {
    const color = LOG_COLORS[entry.level];
    const levelStr = entry.level.toUpperCase().padEnd(5);
    const timestamp = entry.timestamp.split('T')[1].split('.')[0];
    
    let output = `${color}[${timestamp}] [${levelStr}] [${entry.service}]${RESET_COLOR} ${entry.message}`;
    
    if (entry.data && Object.keys(entry.data).length > 0) {
      output += `\n  Data: ${JSON.stringify(entry.data, null, 2).replace(/\n/g, '\n  ')}`;
    }
    
    if (entry.error) {
      output += `\n  Error: ${entry.error.name}: ${entry.error.message}`;
      if (entry.error.stack) {
        output += `\n  Stack: ${entry.error.stack.split('\n').slice(1, 4).join('\n  ')}`;
      }
    }
    
    return output;
  }
  
  return JSON.stringify(entry);
}

/**
 * Output log entry
 */
function outputLog(entry: LogEntry): void {
  // Check log level
  if (LOG_LEVELS[entry.level] < LOG_LEVELS[config.minLevel]) {
    return;
  }
  
  // Add to buffer
  logBuffer.push(entry);
  if (logBuffer.length > MAX_BUFFER_SIZE) {
    logBuffer.shift();
  }
  
  const formatted = formatLogEntry(entry);
  
  // Output to console
  if (config.outputToConsole) {
    switch (entry.level) {
      case 'debug':
        console.debug(formatted);
        break;
      case 'info':
        console.info(formatted);
        break;
      case 'warn':
        console.warn(formatted);
        break;
      case 'error':
      case 'fatal':
        console.error(formatted);
        break;
    }
  }
}

/**
 * Create a scoped logger for a specific service
 */
export function createLogger(service: string) {
  return {
    debug: (message: string, data?: Record<string, unknown>) => {
      outputLog(createLogEntry('debug', service, message, data));
    },
    
    info: (message: string, data?: Record<string, unknown>) => {
      outputLog(createLogEntry('info', service, message, data));
    },
    
    warn: (message: string, data?: Record<string, unknown>, error?: Error) => {
      outputLog(createLogEntry('warn', service, message, data, error));
    },
    
    error: (message: string, error?: Error, data?: Record<string, unknown>) => {
      outputLog(createLogEntry('error', service, message, data, error));
    },
    
    fatal: (message: string, error?: Error, data?: Record<string, unknown>) => {
      outputLog(createLogEntry('fatal', service, message, data, error));
    },
    
    // Log with correlation ID for request tracing
    withCorrelation: (correlationId: string) => ({
      debug: (message: string, data?: Record<string, unknown>) => {
        const entry = createLogEntry('debug', service, message, data);
        entry.correlationId = correlationId;
        outputLog(entry);
      },
      info: (message: string, data?: Record<string, unknown>) => {
        const entry = createLogEntry('info', service, message, data);
        entry.correlationId = correlationId;
        outputLog(entry);
      },
      warn: (message: string, data?: Record<string, unknown>, error?: Error) => {
        const entry = createLogEntry('warn', service, message, data, error);
        entry.correlationId = correlationId;
        outputLog(entry);
      },
      error: (message: string, error?: Error, data?: Record<string, unknown>) => {
        const entry = createLogEntry('error', service, message, data, error);
        entry.correlationId = correlationId;
        outputLog(entry);
      },
    }),
  };
}

/**
 * Get recent logs from buffer
 */
export function getRecentLogs(
  count: number = 100,
  filter?: { level?: LogLevel; service?: string }
): LogEntry[] {
  let logs = [...logBuffer].reverse();
  
  if (filter?.level) {
    const minLevel = LOG_LEVELS[filter.level];
    logs = logs.filter(log => LOG_LEVELS[log.level] >= minLevel);
  }
  
  if (filter?.service) {
    logs = logs.filter(log => log.service === filter.service);
  }
  
  return logs.slice(0, count);
}

/**
 * Clear log buffer
 */
export function clearLogBuffer(): void {
  logBuffer.length = 0;
}

/**
 * Get log statistics
 */
export function getLogStats(): Record<LogLevel, number> {
  const stats: Record<LogLevel, number> = {
    debug: 0,
    info: 0,
    warn: 0,
    error: 0,
    fatal: 0,
  };
  
  for (const entry of logBuffer) {
    stats[entry.level]++;
  }
  
  return stats;
}

// Default logger instance
export const logger = createLogger('HAI');

export default {
  configure,
  createLogger,
  getRecentLogs,
  clearLogBuffer,
  getLogStats,
  logger,
};
