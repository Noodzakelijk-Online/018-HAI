/**
 * Knowledge Base Service
 * Comprehensive service for collecting, storing, and searching knowledge.
 */

import { getDb } from "../db";
import { sql } from "drizzle-orm";
import { EmbeddingService } from "./EmbeddingService";
import { invokeLLM } from "../_core/llm";

export type KnowledgeType = 'fact' | 'preference' | 'routine' | 'relationship' | 'event' | 'emotion' | 'skill' | 'context' | 'insight';

export interface KnowledgeEntry {
  id: number;
  householdId: number;
  type: KnowledgeType;
  content: string;
  context?: string;
  summary?: string;
  source: string;
  sourceId?: string;
  importance: string;
  confidence: string;
  embedding?: number[];
  tags?: string[];
  relatedMembers?: string[];
  metadata?: Record<string, unknown>;
  status: string;
  accessCount: number;
  lastAccessed?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface KnowledgeSearchResult {
  entry: KnowledgeEntry;
  similarity: number;
  matchType: 'semantic' | 'keyword' | 'exact';
}

class KnowledgeBaseServiceClass {
  async addKnowledge(params: {
    householdId: number;
    type: KnowledgeType;
    content: string;
    context?: string;
    source: string;
    sourceId?: string;
    importance?: number;
    tags?: string[];
    relatedMembers?: string[];
    metadata?: Record<string, unknown>;
  }): Promise<KnowledgeEntry | null> {
    const db = await getDb();
    if (!db) return null;

    try {
      const summary = params.content.length > 100 
        ? params.content.substring(0, 97) + '...'
        : params.content;

      const embedding = await EmbeddingService.generateEmbedding(
        params.content + ' ' + (params.context || '')
      );

      await db.execute(sql`
        INSERT INTO knowledge_base 
        (householdId, type, content, context, summary, source, sourceId, importance, embedding, tags, relatedMembers, metadata)
        VALUES (
          ${params.householdId},
          ${params.type},
          ${params.content},
          ${params.context || null},
          ${summary},
          ${params.source},
          ${params.sourceId || null},
          ${params.importance || 0.5},
          ${JSON.stringify(embedding)},
          ${params.tags ? JSON.stringify(params.tags) : null},
          ${params.relatedMembers ? JSON.stringify(params.relatedMembers) : null},
          ${params.metadata ? JSON.stringify(params.metadata) : null}
        )
      `);

      const result = await db.execute(sql`
        SELECT * FROM knowledge_base 
        WHERE householdId = ${params.householdId} 
        ORDER BY id DESC LIMIT 1
      `);

      return this.mapRow((result as any)[0]?.[0]);
    } catch (error) {
      console.error('[KnowledgeBase] Error adding knowledge:', error);
      return null;
    }
  }

  async search(params: {
    query: string;
    householdId: number;
    types?: KnowledgeType[];
    limit?: number;
    minSimilarity?: number;
  }): Promise<KnowledgeSearchResult[]> {
    const db = await getDb();
    if (!db) return [];

    const { query, householdId, limit = 20, minSimilarity = 0.2 } = params;

    try {
      const queryEmbedding = await EmbeddingService.generateEmbedding(query);

      const result = await db.execute(sql`
        SELECT * FROM knowledge_base 
        WHERE householdId = ${householdId} AND status = 'active'
      `);

      const entries = ((result as any)[0] || []).map((row: any) => this.mapRow(row));

      const results: KnowledgeSearchResult[] = [];
      const queryLower = query.toLowerCase();

      for (const entry of entries) {
        if (!entry) continue;
        
        let similarity = 0;
        let matchType: 'semantic' | 'keyword' | 'exact' = 'keyword';

        if (entry.content.toLowerCase().includes(queryLower)) {
          similarity = 0.9;
          matchType = 'exact';
        } else if (entry.embedding && Array.isArray(entry.embedding)) {
          similarity = EmbeddingService.cosineSimilarity(queryEmbedding, entry.embedding);
          matchType = 'semantic';
        } else {
          const contentLower = entry.content.toLowerCase();
          const queryWords = queryLower.split(/\s+/);
          const matchedWords = queryWords.filter(w => contentLower.includes(w));
          similarity = matchedWords.length / queryWords.length * 0.7;
        }

        if (similarity >= minSimilarity) {
          results.push({ entry, similarity, matchType });
        }
      }

      results.sort((a, b) => b.similarity - a.similarity);
      return results.slice(0, limit);
    } catch (error) {
      console.error('[KnowledgeBase] Error searching:', error);
      return [];
    }
  }

  async getStats(householdId: number): Promise<{
    totalEntries: number;
    byType: Record<string, number>;
    bySource: Record<string, number>;
    recentlyAdded: number;
    recentlyAccessed: number;
  }> {
    const db = await getDb();
    if (!db) {
      return { totalEntries: 0, byType: {}, bySource: {}, recentlyAdded: 0, recentlyAccessed: 0 };
    }

    try {
      const totalResult = await db.execute(sql`
        SELECT COUNT(*) as count FROM knowledge_base WHERE householdId = ${householdId}
      `);
      const total = (totalResult as any)[0]?.[0]?.count || 0;

      const byTypeResult = await db.execute(sql`
        SELECT type, COUNT(*) as count FROM knowledge_base 
        WHERE householdId = ${householdId} GROUP BY type
      `);
      const byType: Record<string, number> = {};
      for (const row of (byTypeResult as any)[0] || []) {
        byType[row.type] = row.count;
      }

      const bySourceResult = await db.execute(sql`
        SELECT source, COUNT(*) as count FROM knowledge_base 
        WHERE householdId = ${householdId} GROUP BY source
      `);
      const bySource: Record<string, number> = {};
      for (const row of (bySourceResult as any)[0] || []) {
        bySource[row.source] = row.count;
      }

      const recentResult = await db.execute(sql`
        SELECT COUNT(*) as count FROM knowledge_base 
        WHERE householdId = ${householdId} 
        AND createdAt > DATE_SUB(NOW(), INTERVAL 1 DAY)
      `);
      const recentlyAdded = (recentResult as any)[0]?.[0]?.count || 0;

      return { totalEntries: total, byType, bySource, recentlyAdded, recentlyAccessed: 0 };
    } catch (error) {
      console.error('[KnowledgeBase] Error getting stats:', error);
      return { totalEntries: 0, byType: {}, bySource: {}, recentlyAdded: 0, recentlyAccessed: 0 };
    }
  }

  async getRecent(householdId: number, limit: number = 20): Promise<KnowledgeEntry[]> {
    const db = await getDb();
    if (!db) return [];

    try {
      const result = await db.execute(sql`
        SELECT * FROM knowledge_base 
        WHERE householdId = ${householdId} AND status = 'active'
        ORDER BY createdAt DESC LIMIT ${limit}
      `);
      return ((result as any)[0] || []).map((row: any) => this.mapRow(row)).filter(Boolean);
    } catch (error) {
      console.error('[KnowledgeBase] Error getting recent:', error);
      return [];
    }
  }

  async getByType(householdId: number, type: KnowledgeType, limit: number = 50): Promise<KnowledgeEntry[]> {
    const db = await getDb();
    if (!db) return [];

    try {
      const result = await db.execute(sql`
        SELECT * FROM knowledge_base 
        WHERE householdId = ${householdId} AND type = ${type} AND status = 'active'
        ORDER BY importance DESC, createdAt DESC LIMIT ${limit}
      `);
      return ((result as any)[0] || []).map((row: any) => this.mapRow(row)).filter(Boolean);
    } catch (error) {
      console.error('[KnowledgeBase] Error getting by type:', error);
      return [];
    }
  }

  async archive(knowledgeId: number): Promise<boolean> {
    const db = await getDb();
    if (!db) return false;

    try {
      await db.execute(sql`
        UPDATE knowledge_base SET status = 'archived' WHERE id = ${knowledgeId}
      `);
      return true;
    } catch (error) {
      console.error('[KnowledgeBase] Error archiving:', error);
      return false;
    }
  }

  async getRelated(knowledgeId: number): Promise<Array<{ entry: KnowledgeEntry; relationType: string; strength: number }>> {
    const db = await getDb();
    if (!db) return [];

    try {
      const result = await db.execute(sql`
        SELECT kr.relationType, kr.strength, kb.* FROM knowledge_relations kr
        JOIN knowledge_base kb ON kr.targetKnowledgeId = kb.id
        WHERE kr.sourceKnowledgeId = ${knowledgeId}
      `);
      
      return ((result as any)[0] || []).map((row: any) => ({
        entry: this.mapRow(row),
        relationType: row.relationType,
        strength: Number(row.strength)
      })).filter((r: any) => r.entry);
    } catch (error) {
      console.error('[KnowledgeBase] Error getting related:', error);
      return [];
    }
  }

  async consolidate(householdId: number): Promise<{ merged: number; archived: number }> {
    return { merged: 0, archived: 0 };
  }

  async extractKnowledge(params: {
    text: string;
    source: string;
    householdId: number;
    context?: string;
  }): Promise<Array<{ type: KnowledgeType; content: string; summary: string; importance: number; tags: string[]; relatedMembers: string[] }>> {
    try {
      const response = await invokeLLM({
        messages: [
          {
            role: 'system',
            content: 'Extract knowledge from text. Return JSON array with items having: type (fact/preference/routine/relationship/event/emotion/skill/context/insight), content, summary, importance (0-1), tags (array), relatedMembers (array). Return empty array if no knowledge found.'
          },
          { role: 'user', content: params.text }
        ],
        response_format: {
          type: 'json_schema',
          json_schema: {
            name: 'knowledge_extraction',
            strict: true,
            schema: {
              type: 'object',
              properties: {
                knowledge: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      type: { type: 'string' },
                      content: { type: 'string' },
                      summary: { type: 'string' },
                      importance: { type: 'number' },
                      tags: { type: 'array', items: { type: 'string' } },
                      relatedMembers: { type: 'array', items: { type: 'string' } }
                    },
                    required: ['type', 'content', 'summary', 'importance', 'tags', 'relatedMembers'],
                    additionalProperties: false
                  }
                }
              },
              required: ['knowledge'],
              additionalProperties: false
            }
          }
        }
      });

      const content = response.choices[0]?.message?.content;
      if (!content) return [];
      const parsed = JSON.parse(content);
      return parsed.knowledge || [];
    } catch (error) {
      console.error('[KnowledgeBase] Error extracting knowledge:', error);
      return [];
    }
  }

  /**
   * Process chat message for conversational knowledge entry
   * Extracts knowledge from natural language and returns structured response
   */
  async processChat(params: {
    message: string;
    householdId: number;
    conversationHistory?: Array<{ role: string; content: string }>;
  }): Promise<{
    message: string;
    extractedKnowledge?: Array<{
      type: KnowledgeType;
      content: string;
      confidence: number;
      entities?: string[];
    }>;
  }> {
    try {
      const systemPrompt = `You are HAI's knowledge extraction assistant. Your job is to:
1. Understand what the user is telling you
2. Extract any facts, preferences, routines, relationships, events, skills, or insights
3. Respond conversationally while showing what you understood

For each piece of knowledge you extract, classify it as one of:
- fact: Objective information (birthdays, allergies, addresses)
- preference: Likes, dislikes, favorites
- routine: Regular habits, schedules, patterns
- relationship: Connections between people
- event: Past or future events, appointments
- skill: Abilities, expertise, knowledge areas
- insight: Observations, learnings, conclusions

Respond in JSON format:
{
  "message": "Your conversational response acknowledging what you learned",
  "extractedKnowledge": [
    {
      "type": "fact|preference|routine|relationship|event|skill|insight",
      "content": "The extracted knowledge statement",
      "confidence": 0.0-1.0,
      "entities": ["relevant", "entities"]
    }
  ]
}

If the user is just chatting or asking questions without providing knowledge, respond with an empty extractedKnowledge array.
Be warm and helpful. Confirm what you understood.`;

      const messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }> = [
        { role: 'system', content: systemPrompt },
      ];

      // Add conversation history
      if (params.conversationHistory) {
        for (const msg of params.conversationHistory.slice(-6)) {
          if (msg.role === 'user' || msg.role === 'assistant') {
            messages.push({ role: msg.role, content: msg.content });
          }
        }
      }

      // Add current message
      messages.push({ role: 'user', content: params.message });

      const response = await invokeLLM({
        messages,
        response_format: {
          type: 'json_schema',
          json_schema: {
            name: 'chat_response',
            strict: true,
            schema: {
              type: 'object',
              properties: {
                message: { type: 'string', description: 'Conversational response' },
                extractedKnowledge: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      type: { 
                        type: 'string', 
                        enum: ['fact', 'preference', 'routine', 'relationship', 'event', 'skill', 'insight'] 
                      },
                      content: { type: 'string' },
                      confidence: { type: 'number' },
                      entities: { 
                        type: 'array', 
                        items: { type: 'string' } 
                      }
                    },
                    required: ['type', 'content', 'confidence', 'entities'],
                    additionalProperties: false
                  }
                }
              },
              required: ['message', 'extractedKnowledge'],
              additionalProperties: false
            }
          }
        }
      });

      const content = response.choices[0]?.message?.content;
      if (!content) {
        return {
          message: "I'm sorry, I couldn't process that. Could you try again?",
          extractedKnowledge: []
        };
      }

      const parsed = JSON.parse(content);
      return {
        message: parsed.message || "I understood what you said.",
        extractedKnowledge: parsed.extractedKnowledge || []
      };
    } catch (error) {
      console.error('[KnowledgeBase] Error processing chat:', error);
      return {
        message: "I had trouble processing that. Could you rephrase it?",
        extractedKnowledge: []
      };
    }
  }

  private mapRow(row: any): KnowledgeEntry | null {
    if (!row) return null;
    return {
      id: row.id,
      householdId: row.householdId,
      type: row.type,
      content: row.content,
      context: row.context,
      summary: row.summary,
      source: row.source,
      sourceId: row.sourceId,
      importance: row.importance,
      confidence: row.confidence,
      embedding: row.embedding ? (typeof row.embedding === 'string' ? JSON.parse(row.embedding) : row.embedding) : undefined,
      tags: row.tags ? (typeof row.tags === 'string' ? JSON.parse(row.tags) : row.tags) : undefined,
      relatedMembers: row.relatedMembers ? (typeof row.relatedMembers === 'string' ? JSON.parse(row.relatedMembers) : row.relatedMembers) : undefined,
      metadata: row.metadata ? (typeof row.metadata === 'string' ? JSON.parse(row.metadata) : row.metadata) : undefined,
      status: row.status,
      accessCount: row.accessCount,
      lastAccessed: row.lastAccessed,
      createdAt: row.createdAt,
      updatedAt: row.updatedAt
    };
  }
}

export const KnowledgeBaseService = new KnowledgeBaseServiceClass();
