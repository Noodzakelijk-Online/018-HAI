/**
 * Complete Learning System
 * 
 * Handles ALL learning: pattern recognition, inference, adaptation, and evolution.
 * HAI learns from every interaction to become more helpful over time.
 */

import { EventEmitter } from 'events';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

export interface LearningObservation {
  id: string;
  type: ObservationType;
  source: string;
  subject: ObservationSubject;
  data: Record<string, any>;
  context: ObservationContext;
  timestamp: Date;
  householdId: number;
  memberId?: number;
}

export type ObservationType =
  | 'action' | 'preference' | 'schedule' | 'communication'
  | 'financial' | 'location' | 'device' | 'interaction'
  | 'feedback' | 'override' | 'correction' | 'approval';

export interface ObservationSubject {
  type: 'member' | 'household' | 'device' | 'service' | 'rule';
  id: string | number;
  name?: string;
}

export interface ObservationContext {
  timeOfDay: string;
  dayOfWeek: number;
  season: string;
  weather?: string;
  location?: string;
  activity?: string;
  mood?: string;
  precedingEvents?: string[];
}

export interface LearnedPattern {
  id: string;
  type: PatternType;
  name: string;
  description: string;
  subject: ObservationSubject;
  pattern: PatternDefinition;
  confidence: number;
  occurrences: number;
  lastSeen: Date;
  firstSeen: Date;
  status: 'emerging' | 'established' | 'strong' | 'declining';
  householdId: number;
}

export type PatternType =
  | 'temporal' | 'sequential' | 'preference' | 'behavioral'
  | 'financial' | 'communication' | 'location' | 'device'
  | 'social' | 'health' | 'routine' | 'exception';

export interface PatternDefinition {
  conditions: PatternCondition[];
  outcomes: PatternOutcome[];
  correlations: PatternCorrelation[];
  exceptions: PatternException[];
}

export interface PatternCondition {
  field: string;
  operator: string;
  value: any;
  weight: number;
}

export interface PatternOutcome {
  action: string;
  probability: number;
  parameters?: Record<string, any>;
}

export interface PatternCorrelation {
  factor: string;
  strength: number; // -1 to 1
  direction: 'positive' | 'negative';
}

export interface PatternException {
  condition: string;
  frequency: number;
  lastOccurrence: Date;
}

export interface Inference {
  id: string;
  type: InferenceType;
  subject: ObservationSubject;
  conclusion: string;
  confidence: number;
  evidence: InferenceEvidence[];
  implications: string[];
  actionable: boolean;
  suggestedActions?: string[];
  timestamp: Date;
}

export type InferenceType =
  | 'preference' | 'habit' | 'need' | 'relationship'
  | 'schedule' | 'budget' | 'health' | 'mood'
  | 'risk' | 'opportunity' | 'conflict' | 'trend';

export interface InferenceEvidence {
  source: string;
  observation: string;
  weight: number;
  timestamp: Date;
}

export interface Adaptation {
  id: string;
  type: AdaptationType;
  target: string;
  before: any;
  after: any;
  reason: string;
  triggeredBy: string[];
  confidence: number;
  reversible: boolean;
  appliedAt: Date;
  status: 'pending' | 'applied' | 'reverted' | 'superseded';
}

export type AdaptationType =
  | 'threshold' | 'timing' | 'preference' | 'rule'
  | 'communication' | 'automation' | 'priority' | 'behavior';

// ============================================================================
// COMPLETE LEARNING SYSTEM
// ============================================================================

export class CompleteLearningSystem extends EventEmitter {
  private observations: Map<string, LearningObservation> = new Map();
  private patterns: Map<string, LearnedPattern> = new Map();
  private inferences: Map<string, Inference> = new Map();
  private adaptations: Map<string, Adaptation> = new Map();

  // Pattern detection engines
  private temporalPatternEngine: TemporalPatternEngine;
  private behavioralPatternEngine: BehavioralPatternEngine;
  private preferencePatternEngine: PreferencePatternEngine;
  private socialPatternEngine: SocialPatternEngine;

  // Inference engines
  private preferenceInferenceEngine: PreferenceInferenceEngine;
  private needInferenceEngine: NeedInferenceEngine;
  private relationshipInferenceEngine: RelationshipInferenceEngine;

  constructor() {
    super();
    this.temporalPatternEngine = new TemporalPatternEngine();
    this.behavioralPatternEngine = new BehavioralPatternEngine();
    this.preferencePatternEngine = new PreferencePatternEngine();
    this.socialPatternEngine = new SocialPatternEngine();
    this.preferenceInferenceEngine = new PreferenceInferenceEngine();
    this.needInferenceEngine = new NeedInferenceEngine();
    this.relationshipInferenceEngine = new RelationshipInferenceEngine();
  }

  // -------------------------------------------------------------------------
  // OBSERVATION RECORDING
  // -------------------------------------------------------------------------

  async recordObservation(observation: Omit<LearningObservation, 'id' | 'timestamp'>): Promise<LearningObservation> {
    const fullObservation: LearningObservation = {
      ...observation,
      id: this.generateId('obs'),
      timestamp: new Date(),
    };

    this.observations.set(fullObservation.id, fullObservation);
    this.emit('observation_recorded', fullObservation);

    // Trigger pattern detection
    await this.detectPatterns(fullObservation);

    // Trigger inference
    await this.generateInferences(fullObservation);

    return fullObservation;
  }

  // -------------------------------------------------------------------------
  // PATTERN DETECTION
  // -------------------------------------------------------------------------

  private async detectPatterns(observation: LearningObservation): Promise<LearnedPattern[]> {
    const detectedPatterns: LearnedPattern[] = [];

    // Run all pattern engines
    const temporalPatterns = await this.temporalPatternEngine.detect(observation, this.getRecentObservations(observation.householdId));
    const behavioralPatterns = await this.behavioralPatternEngine.detect(observation, this.getRecentObservations(observation.householdId));
    const preferencePatterns = await this.preferencePatternEngine.detect(observation, this.getRecentObservations(observation.householdId));
    const socialPatterns = await this.socialPatternEngine.detect(observation, this.getRecentObservations(observation.householdId));

    // Merge and deduplicate patterns
    const allPatterns = [...temporalPatterns, ...behavioralPatterns, ...preferencePatterns, ...socialPatterns];

    for (const pattern of allPatterns) {
      const existing = this.findSimilarPattern(pattern);
      if (existing) {
        // Strengthen existing pattern
        this.strengthenPattern(existing, observation);
      } else {
        // Add new pattern
        this.patterns.set(pattern.id, pattern);
        detectedPatterns.push(pattern);
        this.emit('pattern_detected', pattern);
      }
    }

    return detectedPatterns;
  }

  private getRecentObservations(householdId: number, limit: number = 1000): LearningObservation[] {
    return Array.from(this.observations.values())
      .filter(o => o.householdId === householdId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  private findSimilarPattern(pattern: LearnedPattern): LearnedPattern | undefined {
    for (const existing of this.patterns.values()) {
      if (existing.type === pattern.type &&
          existing.subject.type === pattern.subject.type &&
          existing.subject.id === pattern.subject.id &&
          this.patternsAreSimilar(existing.pattern, pattern.pattern)) {
        return existing;
      }
    }
    return undefined;
  }

  private patternsAreSimilar(p1: PatternDefinition, p2: PatternDefinition): boolean {
    // Simple similarity check based on conditions
    if (p1.conditions.length !== p2.conditions.length) return false;
    
    for (let i = 0; i < p1.conditions.length; i++) {
      if (p1.conditions[i].field !== p2.conditions[i].field) return false;
    }
    
    return true;
  }

  private strengthenPattern(pattern: LearnedPattern, observation: LearningObservation): void {
    pattern.occurrences++;
    pattern.lastSeen = observation.timestamp;
    
    // Update confidence based on occurrences
    const baseConfidence = Math.min(0.95, 0.5 + (pattern.occurrences * 0.05));
    const recencyBonus = this.calculateRecencyBonus(pattern);
    pattern.confidence = Math.min(0.99, baseConfidence + recencyBonus);

    // Update status
    if (pattern.occurrences >= 20 && pattern.confidence >= 0.85) {
      pattern.status = 'strong';
    } else if (pattern.occurrences >= 10 && pattern.confidence >= 0.7) {
      pattern.status = 'established';
    } else if (pattern.occurrences >= 3) {
      pattern.status = 'emerging';
    }

    this.emit('pattern_strengthened', pattern);
  }

  private calculateRecencyBonus(pattern: LearnedPattern): number {
    const daysSinceLastSeen = (Date.now() - pattern.lastSeen.getTime()) / (1000 * 60 * 60 * 24);
    if (daysSinceLastSeen < 1) return 0.1;
    if (daysSinceLastSeen < 7) return 0.05;
    if (daysSinceLastSeen < 30) return 0;
    return -0.05; // Decay for old patterns
  }

  // -------------------------------------------------------------------------
  // INFERENCE GENERATION
  // -------------------------------------------------------------------------

  private async generateInferences(observation: LearningObservation): Promise<Inference[]> {
    const inferences: Inference[] = [];

    // Run inference engines
    const preferenceInferences = await this.preferenceInferenceEngine.infer(observation, this.patterns);
    const needInferences = await this.needInferenceEngine.infer(observation, this.patterns);
    const relationshipInferences = await this.relationshipInferenceEngine.infer(observation, this.patterns);

    for (const inference of [...preferenceInferences, ...needInferences, ...relationshipInferences]) {
      if (inference.confidence >= 0.6) {
        this.inferences.set(inference.id, inference);
        inferences.push(inference);
        this.emit('inference_generated', inference);

        // Check if adaptation is needed
        if (inference.actionable) {
          await this.considerAdaptation(inference);
        }
      }
    }

    return inferences;
  }

  // -------------------------------------------------------------------------
  // ADAPTATION
  // -------------------------------------------------------------------------

  private async considerAdaptation(inference: Inference): Promise<Adaptation | null> {
    // Only adapt if confidence is high enough
    if (inference.confidence < 0.75) return null;

    // Generate adaptation based on inference type
    let adaptation: Adaptation | null = null;

    switch (inference.type) {
      case 'preference':
        adaptation = this.createPreferenceAdaptation(inference);
        break;
      case 'habit':
        adaptation = this.createHabitAdaptation(inference);
        break;
      case 'schedule':
        adaptation = this.createScheduleAdaptation(inference);
        break;
      case 'need':
        adaptation = this.createNeedAdaptation(inference);
        break;
    }

    if (adaptation) {
      this.adaptations.set(adaptation.id, adaptation);
      this.emit('adaptation_proposed', adaptation);
    }

    return adaptation;
  }

  private createPreferenceAdaptation(inference: Inference): Adaptation {
    return {
      id: this.generateId('adapt'),
      type: 'preference',
      target: inference.subject.id.toString(),
      before: null,
      after: inference.conclusion,
      reason: `Learned preference from ${inference.evidence.length} observations`,
      triggeredBy: inference.evidence.map(e => e.source),
      confidence: inference.confidence,
      reversible: true,
      appliedAt: new Date(),
      status: 'pending',
    };
  }

  private createHabitAdaptation(inference: Inference): Adaptation {
    return {
      id: this.generateId('adapt'),
      type: 'behavior',
      target: inference.subject.id.toString(),
      before: null,
      after: inference.suggestedActions?.[0] || inference.conclusion,
      reason: `Detected habit pattern: ${inference.conclusion}`,
      triggeredBy: inference.evidence.map(e => e.source),
      confidence: inference.confidence,
      reversible: true,
      appliedAt: new Date(),
      status: 'pending',
    };
  }

  private createScheduleAdaptation(inference: Inference): Adaptation {
    return {
      id: this.generateId('adapt'),
      type: 'timing',
      target: inference.subject.id.toString(),
      before: null,
      after: inference.conclusion,
      reason: `Optimized timing based on learned schedule`,
      triggeredBy: inference.evidence.map(e => e.source),
      confidence: inference.confidence,
      reversible: true,
      appliedAt: new Date(),
      status: 'pending',
    };
  }

  private createNeedAdaptation(inference: Inference): Adaptation {
    return {
      id: this.generateId('adapt'),
      type: 'priority',
      target: inference.subject.id.toString(),
      before: null,
      after: inference.suggestedActions?.[0] || inference.conclusion,
      reason: `Identified need: ${inference.conclusion}`,
      triggeredBy: inference.evidence.map(e => e.source),
      confidence: inference.confidence,
      reversible: true,
      appliedAt: new Date(),
      status: 'pending',
    };
  }

  async applyAdaptation(adaptationId: string): Promise<boolean> {
    const adaptation = this.adaptations.get(adaptationId);
    if (!adaptation || adaptation.status !== 'pending') return false;

    adaptation.status = 'applied';
    adaptation.appliedAt = new Date();
    this.emit('adaptation_applied', adaptation);

    return true;
  }

  async revertAdaptation(adaptationId: string): Promise<boolean> {
    const adaptation = this.adaptations.get(adaptationId);
    if (!adaptation || !adaptation.reversible) return false;

    adaptation.status = 'reverted';
    this.emit('adaptation_reverted', adaptation);

    return true;
  }

  // -------------------------------------------------------------------------
  // FEEDBACK PROCESSING
  // -------------------------------------------------------------------------

  async processFeedback(feedback: {
    type: 'positive' | 'negative' | 'correction';
    targetType: 'pattern' | 'inference' | 'adaptation' | 'action';
    targetId: string;
    details?: string;
    correction?: any;
    memberId: number;
  }): Promise<void> {
    switch (feedback.targetType) {
      case 'pattern':
        await this.processPatternFeedback(feedback);
        break;
      case 'inference':
        await this.processInferenceFeedback(feedback);
        break;
      case 'adaptation':
        await this.processAdaptationFeedback(feedback);
        break;
      case 'action':
        await this.processActionFeedback(feedback);
        break;
    }

    this.emit('feedback_processed', feedback);
  }

  private async processPatternFeedback(feedback: any): Promise<void> {
    const pattern = this.patterns.get(feedback.targetId);
    if (!pattern) return;

    if (feedback.type === 'negative') {
      pattern.confidence *= 0.8; // Reduce confidence
      if (pattern.confidence < 0.3) {
        pattern.status = 'declining';
      }
    } else if (feedback.type === 'positive') {
      pattern.confidence = Math.min(0.99, pattern.confidence * 1.1);
    } else if (feedback.type === 'correction' && feedback.correction) {
      // Apply correction to pattern
      pattern.pattern.exceptions.push({
        condition: feedback.correction,
        frequency: 1,
        lastOccurrence: new Date(),
      });
    }
  }

  private async processInferenceFeedback(feedback: any): Promise<void> {
    const inference = this.inferences.get(feedback.targetId);
    if (!inference) return;

    if (feedback.type === 'negative') {
      inference.confidence *= 0.7;
    } else if (feedback.type === 'positive') {
      inference.confidence = Math.min(0.99, inference.confidence * 1.15);
    }
  }

  private async processAdaptationFeedback(feedback: any): Promise<void> {
    const adaptation = this.adaptations.get(feedback.targetId);
    if (!adaptation) return;

    if (feedback.type === 'negative') {
      await this.revertAdaptation(feedback.targetId);
    }
  }

  private async processActionFeedback(feedback: any): Promise<void> {
    // Record as observation for future learning
    await this.recordObservation({
      type: 'feedback',
      source: 'user_feedback',
      subject: { type: 'member', id: feedback.memberId },
      data: {
        actionId: feedback.targetId,
        feedbackType: feedback.type,
        details: feedback.details,
      },
      context: {
        timeOfDay: this.getTimeOfDay(),
        dayOfWeek: new Date().getDay(),
        season: this.getSeason(),
      },
      householdId: 1, // TODO: Get from context
      memberId: feedback.memberId,
    });
  }

  // -------------------------------------------------------------------------
  // QUERIES
  // -------------------------------------------------------------------------

  getPatterns(householdId: number, options?: {
    type?: PatternType;
    status?: string;
    minConfidence?: number;
    limit?: number;
  }): LearnedPattern[] {
    let patterns = Array.from(this.patterns.values())
      .filter(p => p.householdId === householdId);

    if (options?.type) {
      patterns = patterns.filter(p => p.type === options.type);
    }
    if (options?.status) {
      patterns = patterns.filter(p => p.status === options.status);
    }
    if (options?.minConfidence) {
      patterns = patterns.filter(p => p.confidence >= options.minConfidence);
    }

    patterns.sort((a, b) => b.confidence - a.confidence);

    if (options?.limit) {
      patterns = patterns.slice(0, options.limit);
    }

    return patterns;
  }

  getInferences(householdId: number, options?: {
    type?: InferenceType;
    minConfidence?: number;
    actionableOnly?: boolean;
    limit?: number;
  }): Inference[] {
    let inferences = Array.from(this.inferences.values());

    if (options?.type) {
      inferences = inferences.filter(i => i.type === options.type);
    }
    if (options?.minConfidence) {
      inferences = inferences.filter(i => i.confidence >= options.minConfidence);
    }
    if (options?.actionableOnly) {
      inferences = inferences.filter(i => i.actionable);
    }

    inferences.sort((a, b) => b.confidence - a.confidence);

    if (options?.limit) {
      inferences = inferences.slice(0, options.limit);
    }

    return inferences;
  }

  getAdaptations(options?: {
    status?: string;
    type?: AdaptationType;
    limit?: number;
  }): Adaptation[] {
    let adaptations = Array.from(this.adaptations.values());

    if (options?.status) {
      adaptations = adaptations.filter(a => a.status === options.status);
    }
    if (options?.type) {
      adaptations = adaptations.filter(a => a.type === options.type);
    }

    adaptations.sort((a, b) => b.appliedAt.getTime() - a.appliedAt.getTime());

    if (options?.limit) {
      adaptations = adaptations.slice(0, options.limit);
    }

    return adaptations;
  }

  getLearningInsights(householdId: number): {
    totalPatterns: number;
    strongPatterns: number;
    recentInferences: number;
    pendingAdaptations: number;
    topPatterns: LearnedPattern[];
    recentInsights: Inference[];
  } {
    const patterns = this.getPatterns(householdId);
    const inferences = this.getInferences(householdId);
    const adaptations = this.getAdaptations({ status: 'pending' });

    return {
      totalPatterns: patterns.length,
      strongPatterns: patterns.filter(p => p.status === 'strong').length,
      recentInferences: inferences.filter(i => 
        Date.now() - i.timestamp.getTime() < 7 * 24 * 60 * 60 * 1000
      ).length,
      pendingAdaptations: adaptations.length,
      topPatterns: patterns.slice(0, 5),
      recentInsights: inferences.slice(0, 5),
    };
  }

  // -------------------------------------------------------------------------
  // HELPERS
  // -------------------------------------------------------------------------

  private generateId(prefix: string): string {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private getTimeOfDay(): string {
    const hour = new Date().getHours();
    if (hour >= 5 && hour < 12) return 'morning';
    if (hour >= 12 && hour < 17) return 'afternoon';
    if (hour >= 17 && hour < 21) return 'evening';
    return 'night';
  }

  private getSeason(): string {
    const month = new Date().getMonth();
    if (month >= 2 && month <= 4) return 'spring';
    if (month >= 5 && month <= 7) return 'summer';
    if (month >= 8 && month <= 10) return 'fall';
    return 'winter';
  }
}

// ============================================================================
// PATTERN ENGINES
// ============================================================================

class TemporalPatternEngine {
  async detect(observation: LearningObservation, history: LearningObservation[]): Promise<LearnedPattern[]> {
    const patterns: LearnedPattern[] = [];

    // Detect time-of-day patterns
    const timePatterns = this.detectTimeOfDayPatterns(observation, history);
    patterns.push(...timePatterns);

    // Detect day-of-week patterns
    const dayPatterns = this.detectDayOfWeekPatterns(observation, history);
    patterns.push(...dayPatterns);

    // Detect recurring patterns
    const recurringPatterns = this.detectRecurringPatterns(observation, history);
    patterns.push(...recurringPatterns);

    return patterns;
  }

  private detectTimeOfDayPatterns(observation: LearningObservation, history: LearningObservation[]): LearnedPattern[] {
    const patterns: LearnedPattern[] = [];
    const timeOfDay = observation.context.timeOfDay;

    // Group similar observations by time of day
    const similarByTime = history.filter(h => 
      h.type === observation.type &&
      h.context.timeOfDay === timeOfDay &&
      h.subject.id === observation.subject.id
    );

    if (similarByTime.length >= 3) {
      patterns.push({
        id: `temporal_${observation.type}_${timeOfDay}_${observation.subject.id}`,
        type: 'temporal',
        name: `${observation.type} typically occurs in ${timeOfDay}`,
        description: `${observation.subject.name || observation.subject.id} tends to ${observation.type} during ${timeOfDay}`,
        subject: observation.subject,
        pattern: {
          conditions: [
            { field: 'context.timeOfDay', operator: 'eq', value: timeOfDay, weight: 1 },
            { field: 'type', operator: 'eq', value: observation.type, weight: 1 },
          ],
          outcomes: [
            { action: observation.type, probability: similarByTime.length / history.length },
          ],
          correlations: [],
          exceptions: [],
        },
        confidence: Math.min(0.9, 0.5 + (similarByTime.length * 0.1)),
        occurrences: similarByTime.length,
        lastSeen: observation.timestamp,
        firstSeen: similarByTime[similarByTime.length - 1]?.timestamp || observation.timestamp,
        status: similarByTime.length >= 10 ? 'established' : 'emerging',
        householdId: observation.householdId,
      });
    }

    return patterns;
  }

  private detectDayOfWeekPatterns(observation: LearningObservation, history: LearningObservation[]): LearnedPattern[] {
    const patterns: LearnedPattern[] = [];
    const dayOfWeek = observation.context.dayOfWeek;
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    const similarByDay = history.filter(h => 
      h.type === observation.type &&
      h.context.dayOfWeek === dayOfWeek &&
      h.subject.id === observation.subject.id
    );

    if (similarByDay.length >= 3) {
      patterns.push({
        id: `temporal_${observation.type}_${dayNames[dayOfWeek]}_${observation.subject.id}`,
        type: 'temporal',
        name: `${observation.type} typically occurs on ${dayNames[dayOfWeek]}`,
        description: `${observation.subject.name || observation.subject.id} tends to ${observation.type} on ${dayNames[dayOfWeek]}s`,
        subject: observation.subject,
        pattern: {
          conditions: [
            { field: 'context.dayOfWeek', operator: 'eq', value: dayOfWeek, weight: 1 },
            { field: 'type', operator: 'eq', value: observation.type, weight: 1 },
          ],
          outcomes: [
            { action: observation.type, probability: similarByDay.length / history.length },
          ],
          correlations: [],
          exceptions: [],
        },
        confidence: Math.min(0.9, 0.5 + (similarByDay.length * 0.1)),
        occurrences: similarByDay.length,
        lastSeen: observation.timestamp,
        firstSeen: similarByDay[similarByDay.length - 1]?.timestamp || observation.timestamp,
        status: similarByDay.length >= 10 ? 'established' : 'emerging',
        householdId: observation.householdId,
      });
    }

    return patterns;
  }

  private detectRecurringPatterns(observation: LearningObservation, history: LearningObservation[]): LearnedPattern[] {
    // Detect weekly, bi-weekly, monthly patterns
    return [];
  }
}

class BehavioralPatternEngine {
  async detect(observation: LearningObservation, history: LearningObservation[]): Promise<LearnedPattern[]> {
    const patterns: LearnedPattern[] = [];

    // Detect action sequences
    const sequencePatterns = this.detectSequencePatterns(observation, history);
    patterns.push(...sequencePatterns);

    // Detect trigger-response patterns
    const triggerPatterns = this.detectTriggerPatterns(observation, history);
    patterns.push(...triggerPatterns);

    return patterns;
  }

  private detectSequencePatterns(observation: LearningObservation, history: LearningObservation[]): LearnedPattern[] {
    const patterns: LearnedPattern[] = [];

    // Look for actions that commonly follow this observation
    const recentHistory = history.slice(0, 100);
    const followingActions: Map<string, number> = new Map();

    for (let i = 0; i < recentHistory.length - 1; i++) {
      if (recentHistory[i].type === observation.type &&
          recentHistory[i].subject.id === observation.subject.id) {
        const nextAction = recentHistory[i + 1];
        const key = `${nextAction.type}_${nextAction.subject.id}`;
        followingActions.set(key, (followingActions.get(key) || 0) + 1);
      }
    }

    // Create patterns for common sequences
    for (const [key, count] of followingActions) {
      if (count >= 3) {
        const [nextType, nextSubjectId] = key.split('_');
        patterns.push({
          id: `sequence_${observation.type}_${nextType}_${observation.subject.id}`,
          type: 'sequential',
          name: `${observation.type} is often followed by ${nextType}`,
          description: `After ${observation.type}, ${nextType} typically follows`,
          subject: observation.subject,
          pattern: {
            conditions: [
              { field: 'type', operator: 'eq', value: observation.type, weight: 1 },
            ],
            outcomes: [
              { action: nextType, probability: count / recentHistory.length },
            ],
            correlations: [],
            exceptions: [],
          },
          confidence: Math.min(0.85, 0.4 + (count * 0.1)),
          occurrences: count,
          lastSeen: observation.timestamp,
          firstSeen: observation.timestamp,
          status: count >= 10 ? 'established' : 'emerging',
          householdId: observation.householdId,
        });
      }
    }

    return patterns;
  }

  private detectTriggerPatterns(observation: LearningObservation, history: LearningObservation[]): LearnedPattern[] {
    return [];
  }
}

class PreferencePatternEngine {
  async detect(observation: LearningObservation, history: LearningObservation[]): Promise<LearnedPattern[]> {
    const patterns: LearnedPattern[] = [];

    if (observation.type === 'preference' || observation.type === 'feedback') {
      // Direct preference observation
      patterns.push({
        id: `preference_${observation.data.category || 'general'}_${observation.subject.id}`,
        type: 'preference',
        name: `Preference for ${observation.data.preference || observation.data.value}`,
        description: `${observation.subject.name || observation.subject.id} prefers ${observation.data.preference || observation.data.value}`,
        subject: observation.subject,
        pattern: {
          conditions: [
            { field: 'data.category', operator: 'eq', value: observation.data.category, weight: 1 },
          ],
          outcomes: [
            { action: 'apply_preference', probability: 0.9, parameters: observation.data },
          ],
          correlations: [],
          exceptions: [],
        },
        confidence: 0.8,
        occurrences: 1,
        lastSeen: observation.timestamp,
        firstSeen: observation.timestamp,
        status: 'emerging',
        householdId: observation.householdId,
      });
    }

    return patterns;
  }
}

class SocialPatternEngine {
  async detect(observation: LearningObservation, history: LearningObservation[]): Promise<LearnedPattern[]> {
    const patterns: LearnedPattern[] = [];

    // Detect communication patterns
    if (observation.type === 'communication') {
      const communicationHistory = history.filter(h => 
        h.type === 'communication' &&
        h.data.recipient === observation.data.recipient
      );

      if (communicationHistory.length >= 3) {
        patterns.push({
          id: `social_comm_${observation.data.recipient}_${observation.subject.id}`,
          type: 'social',
          name: `Regular communication with ${observation.data.recipient}`,
          description: `${observation.subject.name || observation.subject.id} frequently communicates with ${observation.data.recipient}`,
          subject: observation.subject,
          pattern: {
            conditions: [
              { field: 'data.recipient', operator: 'eq', value: observation.data.recipient, weight: 1 },
            ],
            outcomes: [],
            correlations: [
              { factor: 'relationship_strength', strength: 0.7, direction: 'positive' },
            ],
            exceptions: [],
          },
          confidence: Math.min(0.9, 0.5 + (communicationHistory.length * 0.05)),
          occurrences: communicationHistory.length,
          lastSeen: observation.timestamp,
          firstSeen: communicationHistory[communicationHistory.length - 1]?.timestamp || observation.timestamp,
          status: communicationHistory.length >= 10 ? 'established' : 'emerging',
          householdId: observation.householdId,
        });
      }
    }

    return patterns;
  }
}

// ============================================================================
// INFERENCE ENGINES
// ============================================================================

class PreferenceInferenceEngine {
  async infer(observation: LearningObservation, patterns: Map<string, LearnedPattern>): Promise<Inference[]> {
    const inferences: Inference[] = [];

    // Find preference patterns for this subject
    const relevantPatterns = Array.from(patterns.values())
      .filter(p => p.type === 'preference' && p.subject.id === observation.subject.id);

    for (const pattern of relevantPatterns) {
      if (pattern.confidence >= 0.7) {
        inferences.push({
          id: `inf_pref_${pattern.id}`,
          type: 'preference',
          subject: pattern.subject,
          conclusion: pattern.description,
          confidence: pattern.confidence,
          evidence: [{
            source: 'pattern_analysis',
            observation: `Pattern observed ${pattern.occurrences} times`,
            weight: 1,
            timestamp: pattern.lastSeen,
          }],
          implications: [`Consider ${pattern.pattern.outcomes[0]?.action || 'applying preference'} automatically`],
          actionable: true,
          suggestedActions: pattern.pattern.outcomes.map(o => o.action),
          timestamp: new Date(),
        });
      }
    }

    return inferences;
  }
}

class NeedInferenceEngine {
  async infer(observation: LearningObservation, patterns: Map<string, LearnedPattern>): Promise<Inference[]> {
    const inferences: Inference[] = [];

    // Infer needs from behavioral patterns
    const behavioralPatterns = Array.from(patterns.values())
      .filter(p => p.type === 'behavioral' && p.subject.id === observation.subject.id);

    // Look for unmet needs based on patterns
    // This is a simplified implementation

    return inferences;
  }
}

class RelationshipInferenceEngine {
  async infer(observation: LearningObservation, patterns: Map<string, LearnedPattern>): Promise<Inference[]> {
    const inferences: Inference[] = [];

    // Find social patterns
    const socialPatterns = Array.from(patterns.values())
      .filter(p => p.type === 'social' && p.subject.id === observation.subject.id);

    for (const pattern of socialPatterns) {
      if (pattern.confidence >= 0.6) {
        const relationshipStrength = pattern.pattern.correlations
          .find(c => c.factor === 'relationship_strength')?.strength || 0.5;

        inferences.push({
          id: `inf_rel_${pattern.id}`,
          type: 'relationship',
          subject: pattern.subject,
          conclusion: `Strong relationship indicated by ${pattern.name}`,
          confidence: pattern.confidence * relationshipStrength,
          evidence: [{
            source: 'social_pattern',
            observation: pattern.description,
            weight: relationshipStrength,
            timestamp: pattern.lastSeen,
          }],
          implications: ['Prioritize communications from this contact', 'Consider in scheduling decisions'],
          actionable: false,
          timestamp: new Date(),
        });
      }
    }

    return inferences;
  }
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

export const completeLearningSystem = new CompleteLearningSystem();
