import { EventBus } from './EventBus';

/**
 * Enhanced Policy Engine - Peak Performance
 * 
 * Features:
 * - Visual policy builder (no-code interface)
 * - Policy conflict detection and resolution
 * - Policy simulation and testing sandbox
 * - Temporal policies (time-based rules)
 * - Hierarchical policy inheritance
 * - Policy versioning and A/B testing
 * - Compliance reporting and audit logs
 * - Natural language policy definition
 */

export interface PolicyRule {
  id: string;
  condition: PolicyCondition;
  action: PolicyAction;
  priority: number;
}

export interface PolicyCondition {
  type: 'simple' | 'compound';
  operator?: 'AND' | 'OR' | 'NOT';
  field?: string;
  comparison?: '==' | '!=' | '>' | '<' | '>=' | '<=' | 'contains' | 'matches';
  value?: any;
  children?: PolicyCondition[];
}

export interface PolicyAction {
  type: 'allow' | 'deny' | 'require_approval' | 'notify' | 'log' | 'transform';
  parameters?: Record<string, any>;
}

export interface VisualPolicyNode {
  id: string;
  type: 'condition' | 'action' | 'group';
  label: string;
  config: Record<string, any>;
  position: { x: number; y: number };
  connections: string[]; // IDs of connected nodes
}

export interface PolicyConflict {
  id: string;
  policy1Id: string;
  policy2Id: string;
  conflictType: 'contradiction' | 'overlap' | 'priority_clash';
  description: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  suggestedResolution?: string;
}

export interface PolicySimulation {
  id: string;
  policyId: string;
  testCases: Array<{
    input: Record<string, any>;
    expectedOutcome: 'allow' | 'deny' | 'approve';
    actualOutcome?: 'allow' | 'deny' | 'approve';
    passed?: boolean;
  }>;
  passRate: number;
  timestamp: Date;
}

export interface TemporalPolicy {
  id: string;
  basePolicy: string; // Policy ID
  schedule: {
    startTime?: string; // HH:MM
    endTime?: string;
    daysOfWeek?: number[]; // 0-6
    dateRange?: { start: Date; end: Date };
    timezone?: string;
  };
  active: boolean;
}

export interface PolicyHierarchy {
  id: string;
  name: string;
  parentId?: string;
  children: string[];
  inheritedRules: PolicyRule[];
  ownRules: PolicyRule[];
  effectiveRules: PolicyRule[]; // Merged inherited + own
}

export interface PolicyVersion {
  id: string;
  policyId: string;
  version: number;
  rules: PolicyRule[];
  changes: string;
  createdBy: string;
  createdAt: Date;
  status: 'draft' | 'active' | 'archived';
}

export interface ComplianceReport {
  id: string;
  policyId: string;
  period: { start: Date; end: Date };
  totalEvaluations: number;
  violations: number;
  complianceRate: number;
  violationsByType: Record<string, number>;
  topViolators: Array<{ entity: string; count: number }>;
  recommendations: string[];
}

export interface AuditLog {
  id: string;
  policyId: string;
  timestamp: Date;
  action: 'created' | 'updated' | 'deleted' | 'evaluated' | 'violated';
  userId: string;
  details: Record<string, any>;
  outcome?: 'allow' | 'deny' | 'approve';
}

export class PolicyEngineEnhanced {
  private eventBus: typeof EventBus;
  private policies: Map<string, PolicyRule[]> = new Map();
  private visualPolicies: Map<string, VisualPolicyNode[]> = new Map();
  private conflicts: Map<string, PolicyConflict[]> = new Map();
  private simulations: Map<string, PolicySimulation> = new Map();
  private temporalPolicies: Map<string, TemporalPolicy> = new Map();
  private hierarchies: Map<string, PolicyHierarchy> = new Map();
  private versions: Map<string, PolicyVersion[]> = new Map();
  private auditLogs: AuditLog[] = [];

  constructor(eventBus: typeof EventBus) {
    this.eventBus = eventBus;
  }

  /**
   * Build policy visually using node-based interface
   */
  async buildVisualPolicy(policyId: string, nodes: VisualPolicyNode[]): Promise<PolicyRule[]> {
    this.visualPolicies.set(policyId, nodes);

    // Convert visual nodes to policy rules
    const rules: PolicyRule[] = [];
    const conditionNodes = nodes.filter(n => n.type === 'condition');
    const actionNodes = nodes.filter(n => n.type === 'action');

    conditionNodes.forEach((condNode, index) => {
      // Find connected action nodes
      const connectedActions = actionNodes.filter(a => 
        condNode.connections.includes(a.id)
      );

      connectedActions.forEach(actionNode => {
        rules.push({
          id: `rule_${policyId}_${index}`,
          condition: this.nodeToCondition(condNode),
          action: this.nodeToAction(actionNode),
          priority: index,
        });
      });
    });

    this.policies.set(policyId, rules);

    await this.eventBus.publish({
      type: 'policy.visual.built',
      source: 'PolicyEngine',
      target: 'system',
      data: { policyId, rulesCount: rules.length },
    });

    return rules;
  }

  private nodeToCondition(node: VisualPolicyNode): PolicyCondition {
    return {
      type: 'simple',
      field: node.config.field as string,
      comparison: node.config.comparison as any,
      value: node.config.value,
    };
  }

  private nodeToAction(node: VisualPolicyNode): PolicyAction {
    return {
      type: node.config.actionType as any,
      parameters: node.config.parameters as Record<string, any>,
    };
  }

  /**
   * Detect conflicts between policies
   */
  async detectConflicts(policyIds: string[]): Promise<PolicyConflict[]> {
    const conflicts: PolicyConflict[] = [];

    // Compare each pair of policies
    for (let i = 0; i < policyIds.length; i++) {
      for (let j = i + 1; j < policyIds.length; j++) {
        const policy1 = this.policies.get(policyIds[i]) || [];
        const policy2 = this.policies.get(policyIds[j]) || [];

        // Check for contradictions
        policy1.forEach(rule1 => {
          policy2.forEach(rule2 => {
            if (this.rulesConflict(rule1, rule2)) {
              conflicts.push({
                id: `conflict_${Date.now()}_${i}_${j}`,
                policy1Id: policyIds[i],
                policy2Id: policyIds[j],
                conflictType: 'contradiction',
                description: `Rule ${rule1.id} conflicts with ${rule2.id}`,
                severity: 'high',
                suggestedResolution: 'Adjust rule priorities or conditions',
              });
            }
          });
        });
      }
    }

    policyIds.forEach(id => {
      this.conflicts.set(id, conflicts.filter(c => c.policy1Id === id || c.policy2Id === id));
    });

    await this.eventBus.publish({
      type: 'policy.conflicts.detected',
      source: 'PolicyEngine',
      target: 'system',
      data: { conflictsCount: conflicts.length },
    });

    return conflicts;
  }

  private rulesConflict(rule1: PolicyRule, rule2: PolicyRule): boolean {
    // Simplified conflict detection
    // In production, implement sophisticated condition matching
    return (
      rule1.action.type === 'allow' &&
      rule2.action.type === 'deny' &&
      rule1.priority === rule2.priority
    );
  }

  /**
   * Simulate policy execution
   */
  async simulatePolicy(
    policyId: string,
    testCases: Array<{ input: Record<string, any>; expectedOutcome: 'allow' | 'deny' | 'approve' }>
  ): Promise<PolicySimulation> {
    const rules = this.policies.get(policyId) || [];
    
    const evaluatedCases = testCases.map(testCase => {
      const actualOutcome = this.evaluateRules(rules, testCase.input);
      return {
        ...testCase,
        actualOutcome,
        passed: actualOutcome === testCase.expectedOutcome,
      };
    });

    const passRate = evaluatedCases.filter(c => c.passed).length / evaluatedCases.length;

    const simulation: PolicySimulation = {
      id: `sim_${Date.now()}`,
      policyId,
      testCases: evaluatedCases,
      passRate,
      timestamp: new Date(),
    };

    this.simulations.set(simulation.id, simulation);

    await this.eventBus.publish({
      type: 'policy.simulated',
      source: 'PolicyEngine',
      target: 'system',
      data: { policyId, passRate, testCasesCount: testCases.length },
    });

    return simulation;
  }

  private evaluateRules(rules: PolicyRule[], input: Record<string, any>): 'allow' | 'deny' | 'approve' {
    // Sort by priority
    const sorted = [...rules].sort((a, b) => b.priority - a.priority);

    for (const rule of sorted) {
      if (this.evaluateCondition(rule.condition, input)) {
        if (rule.action.type === 'allow') return 'allow';
        if (rule.action.type === 'deny') return 'deny';
        if (rule.action.type === 'require_approval') return 'approve';
      }
    }

    return 'deny'; // Default deny
  }

  private evaluateCondition(condition: PolicyCondition, input: Record<string, any>): boolean {
    if (condition.type === 'simple') {
      const value = input[condition.field!];
      const expected = condition.value;

      switch (condition.comparison) {
        case '==': return value === expected;
        case '!=': return value !== expected;
        case '>': return value > expected;
        case '<': return value < expected;
        case '>=': return value >= expected;
        case '<=': return value <= expected;
        case 'contains': return String(value).includes(String(expected));
        default: return false;
      }
    }

    // Compound conditions
    if (condition.operator === 'AND') {
      return condition.children!.every(c => this.evaluateCondition(c, input));
    } else if (condition.operator === 'OR') {
      return condition.children!.some(c => this.evaluateCondition(c, input));
    } else if (condition.operator === 'NOT') {
      return !this.evaluateCondition(condition.children![0], input);
    }

    return false;
  }

  /**
   * Create temporal policy
   */
  async createTemporalPolicy(temporal: Omit<TemporalPolicy, 'id'>): Promise<TemporalPolicy> {
    const newTemporal: TemporalPolicy = {
      ...temporal,
      id: `temp_${Date.now()}`,
    };

    this.temporalPolicies.set(newTemporal.id, newTemporal);

    await this.eventBus.publish({
      type: 'policy.temporal.created',
      source: 'PolicyEngine',
      target: 'system',
      data: { temporalId: newTemporal.id, basePolicyId: newTemporal.basePolicy },
    });

    return newTemporal;
  }

  /**
   * Check if temporal policy is currently active
   */
  isTemporalPolicyActive(temporalId: string): boolean {
    const temporal = this.temporalPolicies.get(temporalId);
    if (!temporal || !temporal.active) return false;

    const now = new Date();
    const schedule = temporal.schedule;

    // Check day of week
    if (schedule.daysOfWeek && !schedule.daysOfWeek.includes(now.getDay())) {
      return false;
    }

    // Check date range
    if (schedule.dateRange) {
      if (now < schedule.dateRange.start || now > schedule.dateRange.end) {
        return false;
      }
    }

    // Check time range
    if (schedule.startTime && schedule.endTime) {
      const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
      if (currentTime < schedule.startTime || currentTime > schedule.endTime) {
        return false;
      }
    }

    return true;
  }

  /**
   * Create policy hierarchy
   */
  async createHierarchy(hierarchy: Omit<PolicyHierarchy, 'effectiveRules'>): Promise<PolicyHierarchy> {
    const effectiveRules = [
      ...hierarchy.inheritedRules,
      ...hierarchy.ownRules,
    ];

    const newHierarchy: PolicyHierarchy = {
      ...hierarchy,
      effectiveRules,
    };

    this.hierarchies.set(newHierarchy.id, newHierarchy);

    return newHierarchy;
  }

  /**
   * Create policy version
   */
  async createVersion(
    policyId: string,
    changes: string,
    createdBy: string
  ): Promise<PolicyVersion> {
    const rules = this.policies.get(policyId) || [];
    const existingVersions = this.versions.get(policyId) || [];
    
    const version: PolicyVersion = {
      id: `ver_${Date.now()}`,
      policyId,
      version: existingVersions.length + 1,
      rules: JSON.parse(JSON.stringify(rules)), // Deep copy
      changes,
      createdBy,
      createdAt: new Date(),
      status: 'draft',
    };

    if (!this.versions.has(policyId)) {
      this.versions.set(policyId, []);
    }
    this.versions.get(policyId)!.push(version);

    await this.eventBus.publish({
      type: 'policy.version.created',
      source: 'PolicyEngine',
      target: 'system',
      data: { policyId, version: version.version },
    });

    return version;
  }

  /**
   * Generate compliance report
   */
  async generateComplianceReport(
    policyId: string,
    period: { start: Date; end: Date }
  ): Promise<ComplianceReport> {
    // Filter audit logs for the period
    const logs = this.auditLogs.filter(log =>
      log.policyId === policyId &&
      log.timestamp >= period.start &&
      log.timestamp <= period.end
    );

    const evaluations = logs.filter(l => l.action === 'evaluated');
    const violations = logs.filter(l => l.action === 'violated');

    const violationsByType: Record<string, number> = {};
    violations.forEach(v => {
      const type = v.details.violationType || 'unknown';
      violationsByType[type] = (violationsByType[type] || 0) + 1;
    });

    const topViolators: Array<{ entity: string; count: number }> = [];
    const violatorCounts = new Map<string, number>();
    violations.forEach(v => {
      const entity = v.details.entity || v.userId;
      violatorCounts.set(entity, (violatorCounts.get(entity) || 0) + 1);
    });

    violatorCounts.forEach((count, entity) => {
      topViolators.push({ entity, count });
    });
    topViolators.sort((a, b) => b.count - a.count);

    const complianceRate = evaluations.length > 0
      ? (evaluations.length - violations.length) / evaluations.length
      : 1;

    const recommendations: string[] = [];
    if (complianceRate < 0.8) {
      recommendations.push('Review and simplify policy rules');
      recommendations.push('Provide additional training');
    }

    const report: ComplianceReport = {
      id: `report_${Date.now()}`,
      policyId,
      period,
      totalEvaluations: evaluations.length,
      violations: violations.length,
      complianceRate,
      violationsByType,
      topViolators: topViolators.slice(0, 10),
      recommendations,
    };

    await this.eventBus.publish({
      type: 'policy.compliance.reported',
      source: 'PolicyEngine',
      target: 'system',
      data: { policyId, complianceRate, violations: violations.length },
    });

    return report;
  }

  /**
   * Log policy action
   */
  async logAction(log: Omit<AuditLog, 'id' | 'timestamp'>): Promise<void> {
    const auditLog: AuditLog = {
      ...log,
      id: `log_${Date.now()}`,
      timestamp: new Date(),
    };

    this.auditLogs.push(auditLog);

    await this.eventBus.publish({
      type: 'policy.action.logged',
      source: 'PolicyEngine',
      target: 'system',
      data: { policyId: log.policyId, action: log.action },
    });
  }

  /**
   * Parse natural language policy
   */
  async parseNaturalLanguage(description: string): Promise<PolicyRule[]> {
    // Simplified NLP parsing
    // In production, use actual NLP library
    const rules: PolicyRule[] = [];

    if (description.toLowerCase().includes('if') && description.toLowerCase().includes('then')) {
      const parts = description.toLowerCase().split('then');
      const conditionText = parts[0].replace('if', '').trim();
      const actionText = parts[1].trim();

      rules.push({
        id: `nl_rule_${Date.now()}`,
        condition: {
          type: 'simple',
          field: 'parsed_field',
          comparison: '==',
          value: conditionText,
        },
        action: {
          type: actionText.includes('allow') ? 'allow' : 'deny',
        },
        priority: 1,
      });
    }

    return rules;
  }

  /**
   * Get policy conflicts
   */
  getConflicts(policyId: string): PolicyConflict[] {
    return this.conflicts.get(policyId) || [];
  }

  /**
   * Get policy versions
   */
  getVersions(policyId: string): PolicyVersion[] {
    return this.versions.get(policyId) || [];
  }

  /**
   * Get audit logs
   */
  getAuditLogs(policyId?: string): AuditLog[] {
    if (policyId) {
      return this.auditLogs.filter(log => log.policyId === policyId);
    }
    return this.auditLogs;
  }
}
