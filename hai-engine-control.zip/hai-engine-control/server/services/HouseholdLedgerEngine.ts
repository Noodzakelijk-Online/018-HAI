import { EventBus, HAIEvent } from "./EventBus";
import { getDb } from "../db";
import { ledgerEvents, LedgerEvent } from "../../drizzle/schema";
import { desc, eq, and, gte, lte, sql } from "drizzle-orm";
import crypto from "crypto";

/**
 * Ledger entry with integrity verification
 */
export interface LedgerEntry {
  id: number;
  sequenceNumber: number;
  timestamp: Date;
  eventType: string;
  eventSource: string;
  actor: string;
  target?: string;
  payload: any;
  metadata: any;
  hash: string;
  previousHash?: string;
}

/**
 * State snapshot for performance
 */
export interface StateSnapshot {
  id: string;
  sequenceNumber: number;
  timestamp: Date;
  state: any;
  hash: string;
}

/**
 * Household Ledger Engine
 * 
 * Implements event sourcing pattern for complete audit trail:
 * - Immutable append-only ledger
 * - Event replay for state reconstruction
 * - Time-travel debugging
 * - Compliance tracking
 * - Tamper detection via cryptographic hashing
 */
export class HouseholdLedgerEngine {
  private static instance: HouseholdLedgerEngine;
  private isInitialized = false;
  private lastHash: string | null = null;
  private currentSequence = 0;

  private constructor() {}

  static getInstance(): HouseholdLedgerEngine {
    if (!HouseholdLedgerEngine.instance) {
      HouseholdLedgerEngine.instance = new HouseholdLedgerEngine();
    }
    return HouseholdLedgerEngine.instance;
  }

  /**
   * Initialize the ledger engine
   */
  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      console.log('[HouseholdLedger] Initializing...');

      // Load last sequence number and hash
      await this.loadLastEntry();

      // Subscribe to all events (only if EventBus is connected)
      if (EventBus.isConnected()) {
        EventBus.subscribe('*', async (event) => {
          await this.appendEvent(event);
        });
      } else {
        console.warn('[HouseholdLedger] EventBus not connected, skipping event subscription');
      }

      this.isInitialized = true;
      console.log('[HouseholdLedger] Initialized successfully');
      console.log(`[HouseholdLedger] Current sequence: ${this.currentSequence}`);
    } catch (error) {
      console.error('[HouseholdLedger] Failed to initialize:', error);
      // Don't throw - allow server to start even if ledger initialization fails
    }
  }

  /**
   * Load the last ledger entry to continue the chain
   */
  private async loadLastEntry(): Promise<void> {
    const db = await getDb();
    if (!db) return;

    const lastEntry = await db
      .select()
      .from(ledgerEvents)
      .orderBy(desc(ledgerEvents.sequenceNumber))
      .limit(1);

    if (lastEntry.length > 0) {
      this.currentSequence = lastEntry[0].sequenceNumber;
      this.lastHash = lastEntry[0].hash;
      console.log(`[HouseholdLedger] Loaded last entry: seq=${this.currentSequence}, hash=${this.lastHash?.substring(0, 8)}...`);
    } else {
      this.currentSequence = 0;
      this.lastHash = null;
      console.log('[HouseholdLedger] Starting fresh ledger');
    }
  }

  /**
   * Append an event to the immutable ledger
   */
  async appendEvent(event: HAIEvent): Promise<LedgerEntry> {
    const db = await getDb();
    if (!db) {
      throw new Error('Database not available');
    }

    this.currentSequence++;
    const sequenceNumber = this.currentSequence;

    // Calculate hash for integrity verification
    const hash = this.calculateHash(sequenceNumber, event, this.lastHash);

    const entry: Omit<LedgerEvent, 'id' | 'createdAt'> = {
      sequenceNumber,
      eventType: event.type,
      eventSource: event.source,
      actor: (event.metadata?.userId?.toString()) || 'system',
      target: typeof event.target === 'string' ? event.target : event.target.join(','),
      payload: event.data,
      metadata: event.metadata,
      hash,
      previousHash: this.lastHash,
    };

    const result = await db.insert(ledgerEvents).values(entry as any);
    
    this.lastHash = hash;

    console.log(`[HouseholdLedger] Appended event: seq=${sequenceNumber}, type=${event.type}, hash=${hash.substring(0, 8)}...`);

    return {
      id: Number(result[0].insertId),
      sequenceNumber,
      timestamp: new Date(),
      eventType: event.type,
      eventSource: event.source,
      actor: entry.actor,
      target: entry.target || undefined,
      payload: event.data,
      metadata: event.metadata,
      hash,
      previousHash: this.lastHash,
    };
  }

  /**
   * Calculate cryptographic hash for ledger entry
   */
  private calculateHash(
    sequenceNumber: number,
    event: HAIEvent,
    previousHash: string | null
  ): string {
    const data = JSON.stringify({
      sequenceNumber,
      timestamp: event.metadata.timestamp,
      type: event.type,
      source: event.source,
      data: event.data,
      previousHash,
    });

    return crypto.createHash('sha256').update(data).digest('hex');
  }

  /**
   * Verify ledger integrity
   */
  async verifyIntegrity(startSeq?: number, endSeq?: number): Promise<{
    valid: boolean;
    errors: Array<{ sequence: number; reason: string }>;
  }> {
    const db = await getDb();
    if (!db) {
      throw new Error('Database not available');
    }

    console.log('[HouseholdLedger] Verifying ledger integrity...');

    const conditions = [];
    if (startSeq !== undefined) {
      conditions.push(gte(ledgerEvents.sequenceNumber, startSeq));
    }
    if (endSeq !== undefined) {
      conditions.push(lte(ledgerEvents.sequenceNumber, endSeq));
    }

    const entries = await db
      .select()
      .from(ledgerEvents)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(ledgerEvents.sequenceNumber);

    const errors: Array<{ sequence: number; reason: string }> = [];
    let previousHash: string | null = null;

    for (const entry of entries) {
      // Check hash chain
      if (entry.previousHash !== previousHash) {
        errors.push({
          sequence: entry.sequenceNumber,
          reason: `Hash chain broken: expected previousHash=${previousHash}, got=${entry.previousHash}`,
        });
      }

      // Recalculate hash
      const expectedHash = this.calculateHash(
        entry.sequenceNumber,
        {
          id: entry.id.toString(),
          type: entry.eventType,
          source: entry.eventSource,
          target: entry.target || '*',
          data: entry.payload as Record<string, unknown>,
          metadata: {
            ...(entry.metadata as Record<string, unknown>),
            timestamp: entry.createdAt.toISOString(),
          },
        },
        entry.previousHash
      );

      if (entry.hash !== expectedHash) {
        errors.push({
          sequence: entry.sequenceNumber,
          reason: `Hash mismatch: expected=${expectedHash.substring(0, 8)}..., got=${entry.hash.substring(0, 8)}...`,
        });
      }

      previousHash = entry.hash;
    }

    const valid = errors.length === 0;
    console.log(`[HouseholdLedger] Integrity check: ${valid ? 'VALID' : 'INVALID'} (${errors.length} errors)`);

    return { valid, errors };
  }

  /**
   * Query ledger events
   */
  async queryEvents(options: {
    startSeq?: number;
    endSeq?: number;
    eventType?: string;
    actor?: string;
    startTime?: Date;
    endTime?: Date;
    limit?: number;
  } = {}): Promise<LedgerEntry[]> {
    const db = await getDb();
    if (!db) {
      throw new Error('Database not available');
    }

    const conditions = [];
    
    if (options.startSeq !== undefined) {
      conditions.push(gte(ledgerEvents.sequenceNumber, options.startSeq));
    }
    if (options.endSeq !== undefined) {
      conditions.push(lte(ledgerEvents.sequenceNumber, options.endSeq));
    }
    if (options.eventType) {
      conditions.push(eq(ledgerEvents.eventType, options.eventType));
    }
    if (options.actor) {
      conditions.push(eq(ledgerEvents.actor, options.actor));
    }
    if (options.startTime) {
      conditions.push(gte(ledgerEvents.createdAt, options.startTime));
    }
    if (options.endTime) {
      conditions.push(lte(ledgerEvents.createdAt, options.endTime));
    }

    let query = db
      .select()
      .from(ledgerEvents)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(ledgerEvents.sequenceNumber);

    if (options.limit) {
      query = query.limit(options.limit) as any;
    }

    const entries = await query;

    return entries.map(entry => ({
      id: entry.id,
      sequenceNumber: entry.sequenceNumber,
      timestamp: entry.createdAt,
      eventType: entry.eventType,
      eventSource: entry.eventSource,
      actor: entry.actor,
      target: entry.target || undefined,
      payload: entry.payload,
      metadata: entry.metadata,
      hash: entry.hash,
      previousHash: entry.previousHash || undefined,
    }));
  }

  /**
   * Replay events to reconstruct state at a specific point in time
   */
  async replayToSequence(targetSeq: number): Promise<any> {
    console.log(`[HouseholdLedger] Replaying events up to sequence ${targetSeq}...`);

    const events = await this.queryEvents({
      startSeq: 1,
      endSeq: targetSeq,
    });

    // Reconstruct state by replaying events
    const state: any = {
      users: {},
      tasks: {},
      decisions: {},
      traits: {},
      conversations: {},
      entities: {},
      relationships: {},
    };

    for (const entry of events) {
      this.applyEventToState(state, entry);
    }

    console.log(`[HouseholdLedger] Replayed ${events.length} events`);
    return state;
  }

  /**
   * Replay events to reconstruct state at a specific timestamp
   */
  async replayToTimestamp(targetTime: Date): Promise<any> {
    console.log(`[HouseholdLedger] Replaying events up to ${targetTime.toISOString()}...`);

    const events = await this.queryEvents({
      endTime: targetTime,
    });

    const state: any = {
      users: {},
      tasks: {},
      decisions: {},
      traits: {},
      conversations: {},
      entities: {},
      relationships: {},
    };

    for (const entry of events) {
      this.applyEventToState(state, entry);
    }

    console.log(`[HouseholdLedger] Replayed ${events.length} events`);
    return state;
  }

  /**
   * Apply a single event to the state
   */
  private applyEventToState(state: any, entry: LedgerEntry): void {
    const { eventType, payload } = entry;

    // Apply event based on type
    switch (eventType) {
      case 'task.created':
        state.tasks[payload.taskId] = { ...payload, status: 'created' };
        break;
      case 'task.started':
        if (state.tasks[payload.taskId]) {
          state.tasks[payload.taskId].status = 'in_progress';
        }
        break;
      case 'task.completed':
        if (state.tasks[payload.taskId]) {
          state.tasks[payload.taskId].status = 'completed';
        }
        break;
      case 'decision.created':
        state.decisions[payload.decisionId] = { ...payload, status: 'pending' };
        break;
      case 'decision.approved':
        if (state.decisions[payload.decisionId]) {
          state.decisions[payload.decisionId].status = 'approved';
        }
        break;
      case 'trait.learned':
        state.traits[payload.traitId] = payload;
        break;
      case 'entity.created':
        state.entities[payload.entityId] = payload;
        break;
      case 'relationship.created':
        state.relationships[payload.relationshipId] = payload;
        break;
      // Add more event types as needed
    }
  }

  /**
   * Get ledger statistics
   */
  async getStatistics(): Promise<{
    totalEvents: number;
    currentSequence: number;
    firstEvent?: Date;
    lastEvent?: Date;
    eventsByType: Record<string, number>;
    eventsByActor: Record<string, number>;
  }> {
    const db = await getDb();
    if (!db) {
      throw new Error('Database not available');
    }

    const totalResult = await db
      .select({ count: sql<number>`count(*)` })
      .from(ledgerEvents);
    
    const totalEvents = Number(totalResult[0]?.count || 0);

    const firstEvent = await db
      .select()
      .from(ledgerEvents)
      .orderBy(ledgerEvents.sequenceNumber)
      .limit(1);

    const lastEvent = await db
      .select()
      .from(ledgerEvents)
      .orderBy(desc(ledgerEvents.sequenceNumber))
      .limit(1);

    // Get event counts by type
    const byTypeResult = await db
      .select({
        eventType: ledgerEvents.eventType,
        count: sql<number>`count(*)`,
      })
      .from(ledgerEvents)
      .groupBy(ledgerEvents.eventType);

    const eventsByType: Record<string, number> = {};
    byTypeResult.forEach((row: any) => {
      eventsByType[row.eventType] = Number(row.count);
    });

    // Get event counts by actor
    const byActorResult = await db
      .select({
        actor: ledgerEvents.actor,
        count: sql<number>`count(*)`,
      })
      .from(ledgerEvents)
      .groupBy(ledgerEvents.actor);

    const eventsByActor: Record<string, number> = {};
    byActorResult.forEach((row: any) => {
      eventsByActor[row.actor] = Number(row.count);
    });

    return {
      totalEvents,
      currentSequence: this.currentSequence,
      firstEvent: firstEvent[0]?.createdAt,
      lastEvent: lastEvent[0]?.createdAt,
      eventsByType,
      eventsByActor,
    };
  }

  /**
   * Export ledger to JSON
   */
  async exportLedger(startSeq?: number, endSeq?: number): Promise<string> {
    const events = await this.queryEvents({ startSeq, endSeq });
    return JSON.stringify(events, null, 2);
  }
}

// Export singleton instance
export const householdLedger = HouseholdLedgerEngine.getInstance();
