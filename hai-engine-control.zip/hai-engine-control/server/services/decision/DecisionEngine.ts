/**
 * Decision Loop Engine for HAI
 * 
 * Manages autonomous decision-making with confidence-based action handling:
 * - High confidence (>90%): Act autonomously
 * - Medium confidence (60-90%): Act with easy undo
 * - Low confidence (<60%): Escalate via WhatsApp
 */

import { EventEmitter } from 'events';

// Types
export enum DecisionConfidence {
  HIGH = 'high',      // >90% - Act autonomously
  MEDIUM = 'medium',  // 60-90% - Act with undo option
  LOW = 'low',        // <60% - Ask user via WhatsApp
  UNKNOWN = 'unknown'
}

export enum DecisionStatus {
  PENDING = 'pending',
  PROCESSING = 'processing',
  AWAITING_USER = 'awaiting_user',
  APPROVED = 'approved',
  REJECTED = 'rejected',
  EXECUTED = 'executed',
  FAILED = 'failed',
  UNDONE = 'undone',
  EXPIRED = 'expired'
}

export enum DecisionCategory {
  FINANCIAL = 'financial',
  COMMUNICATION = 'communication',
  SCHEDULING = 'scheduling',
  SYSTEM = 'system',
  HOUSEHOLD = 'household',
  EMERGENCY = 'emergency',
  GENERAL = 'general'
}

export interface DecisionContext {
  screenText?: string;
  activeApp?: string;
  calendarContext?: any;
  emailContext?: any;
  recentActions?: any[];
  userLocation?: string;
  timeOfDay?: string;
  customData?: Record<string, any>;
}

export interface DecisionOption {
  id: string;
  label: string;
  description?: string;
  action: () => Promise<any>;
  undoAction?: () => Promise<any>;
}

export interface Decision {
  id: string;
  title: string;
  description: string;
  category: DecisionCategory;
  confidence: number;
  confidenceLevel: DecisionConfidence;
  status: DecisionStatus;
  options: DecisionOption[];
  selectedOption?: string;
  context: DecisionContext;
  reasoning: string[];
  createdAt: Date;
  updatedAt: Date;
  executedAt?: Date;
  userResponse?: string;
  result?: any;
  error?: string;
  expiresAt?: Date;
  whatsappMessageId?: string;
}

export interface DecisionEngineConfig {
  highConfidenceThreshold: number;  // Default: 0.9
  mediumConfidenceThreshold: number; // Default: 0.6
  autoExecuteHighConfidence: boolean;
  defaultExpirationMinutes: number;
  maxPendingDecisions: number;
  learningEnabled: boolean;
}

const DEFAULT_CONFIG: DecisionEngineConfig = {
  highConfidenceThreshold: 0.9,
  mediumConfidenceThreshold: 0.6,
  autoExecuteHighConfidence: true,
  defaultExpirationMinutes: 60,
  maxPendingDecisions: 50,
  learningEnabled: true
};

/**
 * Decision Engine - Core decision-making logic
 */
export class DecisionEngine extends EventEmitter {
  private config: DecisionEngineConfig;
  private decisions: Map<string, Decision> = new Map();
  private decisionHistory: Decision[] = [];
  private confidenceAdjustments: Map<string, number> = new Map();
  private isRunning: boolean = false;
  private processingInterval?: NodeJS.Timeout;

  constructor(config: Partial<DecisionEngineConfig> = {}) {
    super();
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  /**
   * Start the decision engine
   */
  start(): void {
    if (this.isRunning) return;
    
    this.isRunning = true;
    
    // Process pending decisions periodically
    this.processingInterval = setInterval(() => {
      this.processPendingDecisions();
    }, 5000);
    
    console.log('[DecisionEngine] Started');
    this.emit('started');
  }

  /**
   * Stop the decision engine
   */
  stop(): void {
    this.isRunning = false;
    
    if (this.processingInterval) {
      clearInterval(this.processingInterval);
    }
    
    console.log('[DecisionEngine] Stopped');
    this.emit('stopped');
  }

  /**
   * Create a new decision
   */
  createDecision(params: {
    title: string;
    description: string;
    category: DecisionCategory;
    confidence: number;
    options: DecisionOption[];
    context?: DecisionContext;
    reasoning?: string[];
    expiresInMinutes?: number;
  }): Decision {
    const id = this.generateId();
    const confidenceLevel = this.getConfidenceLevel(params.confidence);
    
    const decision: Decision = {
      id,
      title: params.title,
      description: params.description,
      category: params.category,
      confidence: params.confidence,
      confidenceLevel,
      status: DecisionStatus.PENDING,
      options: params.options,
      context: params.context || {},
      reasoning: params.reasoning || [],
      createdAt: new Date(),
      updatedAt: new Date(),
      expiresAt: new Date(Date.now() + (params.expiresInMinutes || this.config.defaultExpirationMinutes) * 60 * 1000)
    };
    
    this.decisions.set(id, decision);
    
    console.log(`[DecisionEngine] Created decision: ${id} (${confidenceLevel}, ${(params.confidence * 100).toFixed(0)}%)`);
    this.emit('decisionCreated', decision);
    
    // Auto-process based on confidence
    this.processDecision(decision);
    
    return decision;
  }

  /**
   * Process a decision based on confidence level
   */
  private async processDecision(decision: Decision): Promise<void> {
    decision.status = DecisionStatus.PROCESSING;
    decision.updatedAt = new Date();
    
    switch (decision.confidenceLevel) {
      case DecisionConfidence.HIGH:
        if (this.config.autoExecuteHighConfidence && decision.options.length > 0) {
          // Auto-execute first option
          await this.executeDecision(decision.id, decision.options[0].id);
        }
        break;
        
      case DecisionConfidence.MEDIUM:
        // Execute but notify user with undo option
        if (decision.options.length > 0) {
          await this.executeDecision(decision.id, decision.options[0].id);
          this.emit('decisionNeedsUndo', decision);
        }
        break;
        
      case DecisionConfidence.LOW:
        // Escalate to user via WhatsApp
        decision.status = DecisionStatus.AWAITING_USER;
        decision.updatedAt = new Date();
        this.emit('decisionNeedsEscalation', decision);
        break;
        
      default:
        decision.status = DecisionStatus.AWAITING_USER;
        this.emit('decisionNeedsEscalation', decision);
    }
  }

  /**
   * Execute a decision with a specific option
   */
  async executeDecision(decisionId: string, optionId: string): Promise<boolean> {
    const decision = this.decisions.get(decisionId);
    if (!decision) {
      console.error(`[DecisionEngine] Decision not found: ${decisionId}`);
      return false;
    }
    
    const option = decision.options.find(o => o.id === optionId);
    if (!option) {
      console.error(`[DecisionEngine] Option not found: ${optionId}`);
      return false;
    }
    
    try {
      decision.status = DecisionStatus.PROCESSING;
      decision.selectedOption = optionId;
      decision.updatedAt = new Date();
      
      // Execute the action
      const result = await option.action();
      
      decision.status = DecisionStatus.EXECUTED;
      decision.executedAt = new Date();
      decision.result = result;
      decision.updatedAt = new Date();
      
      console.log(`[DecisionEngine] Executed decision: ${decisionId} with option: ${optionId}`);
      this.emit('decisionExecuted', decision);
      
      // Move to history
      this.archiveDecision(decision);
      
      return true;
      
    } catch (error: any) {
      decision.status = DecisionStatus.FAILED;
      decision.error = error.message;
      decision.updatedAt = new Date();
      
      console.error(`[DecisionEngine] Decision failed: ${decisionId}`, error);
      this.emit('decisionFailed', decision, error);
      
      return false;
    }
  }

  /**
   * Undo a decision
   */
  async undoDecision(decisionId: string): Promise<boolean> {
    const decision = this.decisions.get(decisionId) || 
                     this.decisionHistory.find(d => d.id === decisionId);
    
    if (!decision) {
      console.error(`[DecisionEngine] Decision not found for undo: ${decisionId}`);
      return false;
    }
    
    if (!decision.selectedOption) {
      console.error(`[DecisionEngine] No selected option to undo: ${decisionId}`);
      return false;
    }
    
    const option = decision.options.find(o => o.id === decision.selectedOption);
    if (!option?.undoAction) {
      console.error(`[DecisionEngine] No undo action available: ${decisionId}`);
      return false;
    }
    
    try {
      await option.undoAction();
      
      decision.status = DecisionStatus.UNDONE;
      decision.updatedAt = new Date();
      
      console.log(`[DecisionEngine] Undone decision: ${decisionId}`);
      this.emit('decisionUndone', decision);
      
      // Learn from undo - reduce confidence for similar decisions
      if (this.config.learningEnabled) {
        this.adjustConfidence(decision.category, -0.05);
      }
      
      return true;
      
    } catch (error: any) {
      console.error(`[DecisionEngine] Undo failed: ${decisionId}`, error);
      return false;
    }
  }

  /**
   * Handle user response to a decision
   */
  async handleUserResponse(decisionId: string, response: string): Promise<boolean> {
    const decision = this.decisions.get(decisionId);
    if (!decision) {
      console.error(`[DecisionEngine] Decision not found: ${decisionId}`);
      return false;
    }
    
    decision.userResponse = response;
    decision.updatedAt = new Date();
    
    // Parse response to determine selected option
    const selectedOption = this.parseUserResponse(response, decision.options);
    
    if (selectedOption) {
      decision.status = DecisionStatus.APPROVED;
      
      // Learn from user choice
      if (this.config.learningEnabled) {
        this.adjustConfidence(decision.category, 0.02);
      }
      
      return await this.executeDecision(decisionId, selectedOption.id);
    } else {
      // User rejected or response unclear
      decision.status = DecisionStatus.REJECTED;
      this.emit('decisionRejected', decision);
      this.archiveDecision(decision);
      
      return false;
    }
  }

  /**
   * Parse user response to find matching option
   */
  private parseUserResponse(response: string, options: DecisionOption[]): DecisionOption | null {
    const normalized = response.toLowerCase().trim();
    
    // Check for explicit option selection (A, B, C, 1, 2, 3)
    const letterMatch = normalized.match(/^([a-c])$/);
    if (letterMatch) {
      const index = letterMatch[1].charCodeAt(0) - 'a'.charCodeAt(0);
      if (index < options.length) {
        return options[index];
      }
    }
    
    const numberMatch = normalized.match(/^([1-3])$/);
    if (numberMatch) {
      const index = parseInt(numberMatch[1]) - 1;
      if (index < options.length) {
        return options[index];
      }
    }
    
    // Check for "first", "second", "third"
    const ordinalMap: Record<string, number> = {
      'first': 0, 'second': 1, 'third': 2,
      '1st': 0, '2nd': 1, '3rd': 2
    };
    for (const [word, index] of Object.entries(ordinalMap)) {
      if (normalized.includes(word) && index < options.length) {
        return options[index];
      }
    }
    
    // Check for affirmative responses (for single option or first option)
    const affirmatives = ['yes', 'yeah', 'yep', 'sure', 'ok', 'okay', 'do it', 'go ahead', 'proceed'];
    if (affirmatives.some(a => normalized.includes(a)) && options.length > 0) {
      return options[0];
    }
    
    // Check for negative responses
    const negatives = ['no', 'nope', 'cancel', 'stop', 'don\'t', 'dont', 'nevermind'];
    if (negatives.some(n => normalized.includes(n))) {
      return null;
    }
    
    // Check for option label matches
    for (const option of options) {
      if (normalized.includes(option.label.toLowerCase())) {
        return option;
      }
    }
    
    // Default: unclear response
    return null;
  }

  /**
   * Get confidence level from numeric confidence
   */
  private getConfidenceLevel(confidence: number): DecisionConfidence {
    // Apply category adjustments
    const adjusted = confidence;
    
    if (adjusted >= this.config.highConfidenceThreshold) {
      return DecisionConfidence.HIGH;
    } else if (adjusted >= this.config.mediumConfidenceThreshold) {
      return DecisionConfidence.MEDIUM;
    } else {
      return DecisionConfidence.LOW;
    }
  }

  /**
   * Adjust confidence for a category based on learning
   */
  private adjustConfidence(category: DecisionCategory, delta: number): void {
    const current = this.confidenceAdjustments.get(category) || 0;
    const newValue = Math.max(-0.2, Math.min(0.2, current + delta));
    this.confidenceAdjustments.set(category, newValue);
    
    console.log(`[DecisionEngine] Confidence adjustment for ${category}: ${(newValue * 100).toFixed(1)}%`);
  }

  /**
   * Process pending decisions (check for expiration, etc.)
   */
  private processPendingDecisions(): void {
    const now = new Date();
    
    for (const [id, decision] of this.decisions) {
      // Check expiration
      if (decision.expiresAt && decision.expiresAt < now) {
        if (decision.status === DecisionStatus.AWAITING_USER) {
          decision.status = DecisionStatus.EXPIRED;
          decision.updatedAt = now;
          
          console.log(`[DecisionEngine] Decision expired: ${id}`);
          this.emit('decisionExpired', decision);
          this.archiveDecision(decision);
        }
      }
    }
  }

  /**
   * Archive a decision to history
   */
  private archiveDecision(decision: Decision): void {
    this.decisions.delete(decision.id);
    this.decisionHistory.push(decision);
    
    // Limit history size
    if (this.decisionHistory.length > 1000) {
      this.decisionHistory = this.decisionHistory.slice(-500);
    }
  }

  /**
   * Generate unique decision ID
   */
  private generateId(): string {
    return `dec_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Public getters

  getDecision(id: string): Decision | undefined {
    return this.decisions.get(id);
  }

  getPendingDecisions(): Decision[] {
    return Array.from(this.decisions.values())
      .filter(d => d.status === DecisionStatus.PENDING || d.status === DecisionStatus.AWAITING_USER);
  }

  getAwaitingUserDecisions(): Decision[] {
    return Array.from(this.decisions.values())
      .filter(d => d.status === DecisionStatus.AWAITING_USER);
  }

  getDecisionHistory(limit: number = 50): Decision[] {
    return this.decisionHistory.slice(-limit);
  }

  getStats(): {
    pending: number;
    awaitingUser: number;
    executed: number;
    failed: number;
    undone: number;
  } {
    const history = this.decisionHistory;
    
    return {
      pending: this.getPendingDecisions().length,
      awaitingUser: this.getAwaitingUserDecisions().length,
      executed: history.filter(d => d.status === DecisionStatus.EXECUTED).length,
      failed: history.filter(d => d.status === DecisionStatus.FAILED).length,
      undone: history.filter(d => d.status === DecisionStatus.UNDONE).length
    };
  }

  getStatus(): {
    isRunning: boolean;
    config: DecisionEngineConfig;
    stats: ReturnType<DecisionEngine['getStats']>;
    confidenceAdjustments: Record<string, number>;
  } {
    return {
      isRunning: this.isRunning,
      config: this.config,
      stats: this.getStats(),
      confidenceAdjustments: Object.fromEntries(this.confidenceAdjustments)
    };
  }
}

// Singleton instance
let decisionEngineInstance: DecisionEngine | null = null;

export function getDecisionEngine(config?: Partial<DecisionEngineConfig>): DecisionEngine {
  if (!decisionEngineInstance) {
    decisionEngineInstance = new DecisionEngine(config);
  }
  return decisionEngineInstance;
}

export default DecisionEngine;
