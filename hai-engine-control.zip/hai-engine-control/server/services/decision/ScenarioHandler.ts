/**
 * Scenario Handler
 * 
 * Handles EVERY possible household scenario with appropriate responses.
 * This is the "what if" engine - it knows how to handle any situation.
 */

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

export interface Scenario {
  id: string;
  category: ScenarioCategory;
  subcategory: string;
  name: string;
  description: string;
  triggers: ScenarioTrigger[];
  conditions: ScenarioCondition[];
  responses: ScenarioResponse[];
  priority: number;
  enabled: boolean;
}

export type ScenarioCategory =
  | 'emergency' | 'safety' | 'security'
  | 'financial' | 'scheduling' | 'communication'
  | 'home' | 'health' | 'family'
  | 'travel' | 'work' | 'social'
  | 'maintenance' | 'shopping' | 'entertainment';

export interface ScenarioTrigger {
  type: TriggerType;
  source?: string;
  condition: string;
  parameters?: Record<string, any>;
}

export type TriggerType =
  | 'event' | 'time' | 'location' | 'state_change'
  | 'threshold' | 'pattern' | 'absence' | 'combination';

export interface ScenarioCondition {
  type: ConditionType;
  field: string;
  operator: ConditionOperator;
  value: any;
  optional?: boolean;
}

export type ConditionType = 'state' | 'time' | 'member' | 'device' | 'weather' | 'custom';
export type ConditionOperator = 'eq' | 'neq' | 'gt' | 'lt' | 'gte' | 'lte' | 'contains' | 'in' | 'between';

export interface ScenarioResponse {
  order: number;
  action: string;
  parameters: Record<string, any>;
  delay?: number;
  condition?: ScenarioCondition;
  fallback?: ScenarioResponse;
}

export interface ScenarioMatch {
  scenario: Scenario;
  confidence: number;
  matchedTriggers: string[];
  matchedConditions: string[];
  suggestedResponses: ScenarioResponse[];
}

// ============================================================================
// SCENARIO HANDLER
// ============================================================================

export class ScenarioHandler {
  private scenarios: Map<string, Scenario> = new Map();
  private categoryIndex: Map<ScenarioCategory, string[]> = new Map();

  constructor() {
    this.loadBuiltInScenarios();
  }

  // -------------------------------------------------------------------------
  // SCENARIO MATCHING
  // -------------------------------------------------------------------------

  async matchScenarios(context: {
    event?: any;
    state?: any;
    time?: Date;
    location?: any;
    members?: any[];
  }): Promise<ScenarioMatch[]> {
    const matches: ScenarioMatch[] = [];

    for (const scenario of this.scenarios.values()) {
      if (!scenario.enabled) continue;

      const match = this.evaluateScenario(scenario, context);
      if (match.confidence > 0.5) {
        matches.push(match);
      }
    }

    // Sort by priority and confidence
    return matches.sort((a, b) => {
      if (a.scenario.priority !== b.scenario.priority) {
        return b.scenario.priority - a.scenario.priority;
      }
      return b.confidence - a.confidence;
    });
  }

  private evaluateScenario(scenario: Scenario, context: any): ScenarioMatch {
    const matchedTriggers: string[] = [];
    const matchedConditions: string[] = [];
    let triggerScore = 0;
    let conditionScore = 0;

    // Evaluate triggers
    for (const trigger of scenario.triggers) {
      if (this.evaluateTrigger(trigger, context)) {
        matchedTriggers.push(trigger.condition);
        triggerScore++;
      }
    }

    // Evaluate conditions
    for (const condition of scenario.conditions) {
      if (this.evaluateCondition(condition, context)) {
        matchedConditions.push(`${condition.field} ${condition.operator} ${condition.value}`);
        conditionScore++;
      } else if (!condition.optional) {
        // Required condition not met
        return {
          scenario,
          confidence: 0,
          matchedTriggers,
          matchedConditions,
          suggestedResponses: [],
        };
      }
    }

    // Calculate confidence
    const triggerConfidence = scenario.triggers.length > 0 
      ? triggerScore / scenario.triggers.length 
      : 1;
    const conditionConfidence = scenario.conditions.length > 0 
      ? conditionScore / scenario.conditions.length 
      : 1;
    const confidence = (triggerConfidence * 0.6) + (conditionConfidence * 0.4);

    return {
      scenario,
      confidence,
      matchedTriggers,
      matchedConditions,
      suggestedResponses: confidence > 0.5 ? scenario.responses : [],
    };
  }

  private evaluateTrigger(trigger: ScenarioTrigger, context: any): boolean {
    switch (trigger.type) {
      case 'event':
        return context.event?.type === trigger.parameters?.eventType;
      case 'time':
        return this.evaluateTimeTrigger(trigger, context.time);
      case 'location':
        return this.evaluateLocationTrigger(trigger, context.location);
      case 'state_change':
        return this.evaluateStateChangeTrigger(trigger, context.state);
      case 'threshold':
        return this.evaluateThresholdTrigger(trigger, context);
      default:
        return false;
    }
  }

  private evaluateTimeTrigger(trigger: ScenarioTrigger, time?: Date): boolean {
    if (!time) return false;
    const params = trigger.parameters || {};
    
    if (params.hour !== undefined) {
      if (time.getHours() !== params.hour) return false;
    }
    if (params.dayOfWeek !== undefined) {
      if (time.getDay() !== params.dayOfWeek) return false;
    }
    if (params.timeRange) {
      const hour = time.getHours();
      if (hour < params.timeRange.start || hour > params.timeRange.end) return false;
    }
    
    return true;
  }

  private evaluateLocationTrigger(trigger: ScenarioTrigger, location: any): boolean {
    if (!location) return false;
    const params = trigger.parameters || {};
    
    if (params.zone && location.zone !== params.zone) return false;
    if (params.geofence && !this.isInGeofence(location, params.geofence)) return false;
    
    return true;
  }

  private isInGeofence(location: any, geofence: any): boolean {
    // Simple distance check
    if (!location.lat || !location.lng || !geofence.lat || !geofence.lng) return false;
    const distance = this.calculateDistance(
      location.lat, location.lng,
      geofence.lat, geofence.lng
    );
    return distance <= (geofence.radius || 100);
  }

  private calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
    const R = 6371e3; // Earth's radius in meters
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }

  private evaluateStateChangeTrigger(trigger: ScenarioTrigger, state: any): boolean {
    if (!state) return false;
    const params = trigger.parameters || {};
    
    if (params.field && params.from !== undefined && params.to !== undefined) {
      return state.previous?.[params.field] === params.from && 
             state.current?.[params.field] === params.to;
    }
    
    return false;
  }

  private evaluateThresholdTrigger(trigger: ScenarioTrigger, context: any): boolean {
    const params = trigger.parameters || {};
    if (!params.field || params.threshold === undefined) return false;
    
    const value = this.getNestedValue(context, params.field);
    if (value === undefined) return false;
    
    switch (params.operator || 'gt') {
      case 'gt': return value > params.threshold;
      case 'lt': return value < params.threshold;
      case 'gte': return value >= params.threshold;
      case 'lte': return value <= params.threshold;
      case 'eq': return value === params.threshold;
      default: return false;
    }
  }

  private evaluateCondition(condition: ScenarioCondition, context: any): boolean {
    const value = this.getNestedValue(context, condition.field);
    if (value === undefined && !condition.optional) return false;
    
    switch (condition.operator) {
      case 'eq': return value === condition.value;
      case 'neq': return value !== condition.value;
      case 'gt': return value > condition.value;
      case 'lt': return value < condition.value;
      case 'gte': return value >= condition.value;
      case 'lte': return value <= condition.value;
      case 'contains': return String(value).includes(String(condition.value));
      case 'in': return Array.isArray(condition.value) && condition.value.includes(value);
      case 'between': 
        return Array.isArray(condition.value) && 
               value >= condition.value[0] && 
               value <= condition.value[1];
      default: return false;
    }
  }

  private getNestedValue(obj: any, path: string): any {
    return path.split('.').reduce((current, key) => current?.[key], obj);
  }

  // -------------------------------------------------------------------------
  // BUILT-IN SCENARIOS
  // -------------------------------------------------------------------------

  private loadBuiltInScenarios(): void {
    // EMERGENCY SCENARIOS
    this.addScenario({
      id: 'emergency_fire_detected',
      category: 'emergency',
      subcategory: 'fire',
      name: 'Fire/Smoke Detected',
      description: 'Smoke or fire detected in the home',
      triggers: [
        { type: 'event', condition: 'smoke_detected', parameters: { eventType: 'smoke_alarm' } },
        { type: 'event', condition: 'fire_detected', parameters: { eventType: 'fire_alarm' } },
      ],
      conditions: [],
      responses: [
        { order: 1, action: 'alert_all_members', parameters: { message: 'FIRE ALERT: Evacuate immediately', priority: 'critical' } },
        { order: 2, action: 'call_emergency_services', parameters: { service: '911', type: 'fire' } },
        { order: 3, action: 'unlock_all_doors', parameters: {} },
        { order: 4, action: 'turn_off_hvac', parameters: {} },
        { order: 5, action: 'notify_emergency_contacts', parameters: {} },
      ],
      priority: 100,
      enabled: true,
    });

    this.addScenario({
      id: 'emergency_intrusion',
      category: 'emergency',
      subcategory: 'security',
      name: 'Intrusion Detected',
      description: 'Unauthorized entry detected while armed',
      triggers: [
        { type: 'event', condition: 'intrusion', parameters: { eventType: 'security_breach' } },
        { type: 'combination', condition: 'door_open_while_armed', parameters: {} },
      ],
      conditions: [
        { type: 'state', field: 'security.armed', operator: 'eq', value: true },
      ],
      responses: [
        { order: 1, action: 'trigger_alarm', parameters: { type: 'intrusion' } },
        { order: 2, action: 'alert_all_members', parameters: { message: 'SECURITY ALERT: Possible intrusion', priority: 'critical' } },
        { order: 3, action: 'call_emergency_services', parameters: { service: '911', type: 'police' } },
        { order: 4, action: 'start_recording', parameters: { cameras: 'all' } },
        { order: 5, action: 'lock_interior_doors', parameters: {} },
      ],
      priority: 100,
      enabled: true,
    });

    this.addScenario({
      id: 'emergency_medical',
      category: 'emergency',
      subcategory: 'medical',
      name: 'Medical Emergency',
      description: 'Medical emergency detected or reported',
      triggers: [
        { type: 'event', condition: 'medical_alert', parameters: { eventType: 'medical_emergency' } },
        { type: 'event', condition: 'fall_detected', parameters: { eventType: 'fall_detection' } },
      ],
      conditions: [],
      responses: [
        { order: 1, action: 'call_emergency_services', parameters: { service: '911', type: 'medical' } },
        { order: 2, action: 'alert_family_members', parameters: { priority: 'critical' } },
        { order: 3, action: 'unlock_front_door', parameters: {} },
        { order: 4, action: 'turn_on_exterior_lights', parameters: {} },
        { order: 5, action: 'share_medical_info', parameters: { with: 'emergency_responders' } },
      ],
      priority: 100,
      enabled: true,
    });

    this.addScenario({
      id: 'emergency_water_leak',
      category: 'emergency',
      subcategory: 'water',
      name: 'Water Leak Detected',
      description: 'Water leak or flooding detected',
      triggers: [
        { type: 'event', condition: 'water_detected', parameters: { eventType: 'water_sensor' } },
        { type: 'threshold', condition: 'high_water_usage', parameters: { field: 'water.flowRate', threshold: 10, operator: 'gt' } },
      ],
      conditions: [],
      responses: [
        { order: 1, action: 'shut_off_water_main', parameters: {} },
        { order: 2, action: 'alert_all_members', parameters: { message: 'WATER LEAK: Main water shut off', priority: 'high' } },
        { order: 3, action: 'turn_off_water_heater', parameters: {} },
        { order: 4, action: 'schedule_plumber', parameters: { urgency: 'emergency' } },
      ],
      priority: 90,
      enabled: true,
    });

    this.addScenario({
      id: 'emergency_gas_leak',
      category: 'emergency',
      subcategory: 'gas',
      name: 'Gas Leak Detected',
      description: 'Natural gas or CO detected',
      triggers: [
        { type: 'event', condition: 'gas_detected', parameters: { eventType: 'gas_sensor' } },
        { type: 'event', condition: 'co_detected', parameters: { eventType: 'co_alarm' } },
      ],
      conditions: [],
      responses: [
        { order: 1, action: 'alert_all_members', parameters: { message: 'GAS LEAK: Evacuate immediately, do not use electronics', priority: 'critical' } },
        { order: 2, action: 'call_emergency_services', parameters: { service: '911', type: 'gas' } },
        { order: 3, action: 'call_gas_company', parameters: { type: 'emergency' } },
        { order: 4, action: 'turn_off_hvac', parameters: {} },
        { order: 5, action: 'open_windows', parameters: { if_smart: true } },
      ],
      priority: 100,
      enabled: true,
    });

    // SAFETY SCENARIOS
    this.addScenario({
      id: 'safety_child_home_alone',
      category: 'safety',
      subcategory: 'child',
      name: 'Child Home Alone',
      description: 'Minor child detected home alone',
      triggers: [
        { type: 'state_change', condition: 'adults_left', parameters: { field: 'adults_present', from: true, to: false } },
      ],
      conditions: [
        { type: 'member', field: 'minors_present', operator: 'eq', value: true },
      ],
      responses: [
        { order: 1, action: 'notify_parents', parameters: { message: 'Your child appears to be home alone' } },
        { order: 2, action: 'enable_child_safety_mode', parameters: {} },
        { order: 3, action: 'lock_certain_cabinets', parameters: { type: 'hazardous' } },
      ],
      priority: 80,
      enabled: true,
    });

    this.addScenario({
      id: 'safety_elderly_inactive',
      category: 'safety',
      subcategory: 'elderly',
      name: 'Elderly Member Inactive',
      description: 'No activity detected from elderly member for extended period',
      triggers: [
        { type: 'absence', condition: 'no_activity', parameters: { duration: 4, unit: 'hours' } },
      ],
      conditions: [
        { type: 'member', field: 'member.age', operator: 'gte', value: 65 },
        { type: 'state', field: 'member.location', operator: 'eq', value: 'home' },
      ],
      responses: [
        { order: 1, action: 'check_in_call', parameters: { type: 'wellness' } },
        { order: 2, action: 'notify_family', parameters: { message: 'No activity detected', delay: 30 } },
        { order: 3, action: 'request_neighbor_check', parameters: { delay: 60 } },
      ],
      priority: 70,
      enabled: true,
    });

    // FINANCIAL SCENARIOS
    this.addScenario({
      id: 'financial_unusual_transaction',
      category: 'financial',
      subcategory: 'fraud',
      name: 'Unusual Transaction Detected',
      description: 'Transaction outside normal patterns detected',
      triggers: [
        { type: 'event', condition: 'transaction', parameters: { eventType: 'bank_transaction' } },
        { type: 'pattern', condition: 'anomaly', parameters: { type: 'spending' } },
      ],
      conditions: [],
      responses: [
        { order: 1, action: 'alert_account_owner', parameters: { priority: 'high' } },
        { order: 2, action: 'request_verification', parameters: { method: 'push_notification' } },
        { order: 3, action: 'log_for_review', parameters: {} },
      ],
      priority: 75,
      enabled: true,
    });

    this.addScenario({
      id: 'financial_bill_due',
      category: 'financial',
      subcategory: 'bills',
      name: 'Bill Due Soon',
      description: 'Recurring bill is due within reminder window',
      triggers: [
        { type: 'time', condition: 'bill_due_window', parameters: { daysBefore: 3 } },
      ],
      conditions: [
        { type: 'state', field: 'bill.autopay', operator: 'eq', value: false },
      ],
      responses: [
        { order: 1, action: 'send_reminder', parameters: { type: 'bill_due' } },
        { order: 2, action: 'suggest_autopay', parameters: {} },
      ],
      priority: 50,
      enabled: true,
    });

    this.addScenario({
      id: 'financial_budget_exceeded',
      category: 'financial',
      subcategory: 'budget',
      name: 'Budget Category Exceeded',
      description: 'Spending in a category has exceeded budget',
      triggers: [
        { type: 'threshold', condition: 'budget_exceeded', parameters: { field: 'budget.percentUsed', threshold: 100, operator: 'gte' } },
      ],
      conditions: [],
      responses: [
        { order: 1, action: 'notify_budget_owner', parameters: { message: 'Budget exceeded' } },
        { order: 2, action: 'suggest_adjustments', parameters: {} },
        { order: 3, action: 'flag_future_transactions', parameters: { category: 'over_budget' } },
      ],
      priority: 60,
      enabled: true,
    });

    // SCHEDULING SCENARIOS
    this.addScenario({
      id: 'scheduling_conflict',
      category: 'scheduling',
      subcategory: 'conflict',
      name: 'Calendar Conflict Detected',
      description: 'Overlapping events detected on calendar',
      triggers: [
        { type: 'event', condition: 'event_created', parameters: { eventType: 'calendar_event' } },
      ],
      conditions: [
        { type: 'state', field: 'calendar.hasConflict', operator: 'eq', value: true },
      ],
      responses: [
        { order: 1, action: 'notify_conflict', parameters: {} },
        { order: 2, action: 'suggest_resolution', parameters: { options: ['reschedule', 'decline', 'delegate'] } },
      ],
      priority: 60,
      enabled: true,
    });

    this.addScenario({
      id: 'scheduling_travel_time',
      category: 'scheduling',
      subcategory: 'travel',
      name: 'Insufficient Travel Time',
      description: 'Not enough time between events for travel',
      triggers: [
        { type: 'pattern', condition: 'travel_time_check', parameters: {} },
      ],
      conditions: [
        { type: 'state', field: 'events.travelTimeShort', operator: 'eq', value: true },
      ],
      responses: [
        { order: 1, action: 'alert_travel_time', parameters: {} },
        { order: 2, action: 'suggest_departure_time', parameters: {} },
        { order: 3, action: 'offer_reschedule', parameters: {} },
      ],
      priority: 55,
      enabled: true,
    });

    // HOME SCENARIOS
    this.addScenario({
      id: 'home_everyone_left',
      category: 'home',
      subcategory: 'occupancy',
      name: 'Everyone Left Home',
      description: 'All household members have left',
      triggers: [
        { type: 'state_change', condition: 'house_empty', parameters: { field: 'occupancy', from: 'occupied', to: 'empty' } },
      ],
      conditions: [],
      responses: [
        { order: 1, action: 'arm_security', parameters: { mode: 'away' } },
        { order: 2, action: 'adjust_thermostat', parameters: { mode: 'away' } },
        { order: 3, action: 'turn_off_lights', parameters: { except: ['security'] } },
        { order: 4, action: 'check_doors_windows', parameters: {} },
        { order: 5, action: 'enable_away_mode', parameters: {} },
      ],
      priority: 65,
      enabled: true,
    });

    this.addScenario({
      id: 'home_first_arrival',
      category: 'home',
      subcategory: 'occupancy',
      name: 'First Person Arriving Home',
      description: 'First household member arriving after being empty',
      triggers: [
        { type: 'state_change', condition: 'first_arrival', parameters: { field: 'occupancy', from: 'empty', to: 'occupied' } },
      ],
      conditions: [],
      responses: [
        { order: 1, action: 'disarm_security', parameters: {} },
        { order: 2, action: 'adjust_thermostat', parameters: { mode: 'home' } },
        { order: 3, action: 'turn_on_lights', parameters: { rooms: ['entry', 'living'] } },
        { order: 4, action: 'play_welcome', parameters: { optional: true } },
      ],
      priority: 65,
      enabled: true,
    });

    this.addScenario({
      id: 'home_bedtime',
      category: 'home',
      subcategory: 'routine',
      name: 'Bedtime Routine',
      description: 'Household bedtime detected',
      triggers: [
        { type: 'time', condition: 'bedtime', parameters: { timeRange: { start: 21, end: 23 } } },
        { type: 'pattern', condition: 'bedtime_activity', parameters: {} },
      ],
      conditions: [
        { type: 'state', field: 'occupancy', operator: 'eq', value: 'occupied' },
      ],
      responses: [
        { order: 1, action: 'dim_lights', parameters: { level: 20 } },
        { order: 2, action: 'arm_security', parameters: { mode: 'night' } },
        { order: 3, action: 'lock_doors', parameters: {} },
        { order: 4, action: 'adjust_thermostat', parameters: { mode: 'sleep' } },
        { order: 5, action: 'enable_dnd', parameters: { except: ['emergency'] } },
      ],
      priority: 50,
      enabled: true,
    });

    this.addScenario({
      id: 'home_appliance_left_on',
      category: 'home',
      subcategory: 'appliance',
      name: 'Appliance Left On',
      description: 'Appliance running longer than expected',
      triggers: [
        { type: 'threshold', condition: 'appliance_runtime', parameters: { field: 'appliance.runtime', threshold: 120, operator: 'gt' } },
      ],
      conditions: [],
      responses: [
        { order: 1, action: 'notify_owner', parameters: { message: 'Appliance may have been left on' } },
        { order: 2, action: 'offer_turn_off', parameters: {} },
      ],
      priority: 40,
      enabled: true,
    });

    // WEATHER SCENARIOS
    this.addScenario({
      id: 'weather_severe',
      category: 'safety',
      subcategory: 'weather',
      name: 'Severe Weather Alert',
      description: 'Severe weather warning for area',
      triggers: [
        { type: 'event', condition: 'weather_alert', parameters: { eventType: 'severe_weather' } },
      ],
      conditions: [],
      responses: [
        { order: 1, action: 'alert_all_members', parameters: { priority: 'high' } },
        { order: 2, action: 'close_windows', parameters: { if_smart: true } },
        { order: 3, action: 'secure_outdoor_items', parameters: { reminder: true } },
        { order: 4, action: 'check_supplies', parameters: { type: 'emergency' } },
      ],
      priority: 80,
      enabled: true,
    });

    this.addScenario({
      id: 'weather_freezing',
      category: 'home',
      subcategory: 'weather',
      name: 'Freezing Temperature',
      description: 'Temperature dropping to freezing',
      triggers: [
        { type: 'threshold', condition: 'temp_freezing', parameters: { field: 'weather.temperature', threshold: 32, operator: 'lte' } },
      ],
      conditions: [],
      responses: [
        { order: 1, action: 'adjust_thermostat', parameters: { minTemp: 55 } },
        { order: 2, action: 'remind_pipes', parameters: { message: 'Consider letting faucets drip to prevent frozen pipes' } },
        { order: 3, action: 'check_pets', parameters: { outdoor: true } },
      ],
      priority: 60,
      enabled: true,
    });

    // COMMUNICATION SCENARIOS
    this.addScenario({
      id: 'communication_urgent_email',
      category: 'communication',
      subcategory: 'email',
      name: 'Urgent Email Received',
      description: 'Email marked urgent or from VIP sender',
      triggers: [
        { type: 'event', condition: 'email_received', parameters: { eventType: 'email' } },
      ],
      conditions: [
        { type: 'state', field: 'email.isUrgent', operator: 'eq', value: true },
      ],
      responses: [
        { order: 1, action: 'notify_immediately', parameters: { channel: 'push' } },
        { order: 2, action: 'summarize_email', parameters: {} },
        { order: 3, action: 'suggest_response', parameters: {} },
      ],
      priority: 70,
      enabled: true,
    });

    this.addScenario({
      id: 'communication_missed_call',
      category: 'communication',
      subcategory: 'phone',
      name: 'Missed Call from Important Contact',
      description: 'Missed call from family or VIP contact',
      triggers: [
        { type: 'event', condition: 'missed_call', parameters: { eventType: 'phone_missed' } },
      ],
      conditions: [
        { type: 'state', field: 'caller.isVIP', operator: 'eq', value: true },
      ],
      responses: [
        { order: 1, action: 'notify_missed_call', parameters: {} },
        { order: 2, action: 'offer_callback', parameters: {} },
        { order: 3, action: 'send_text', parameters: { message: 'Sorry I missed your call, I\'ll call back soon' } },
      ],
      priority: 65,
      enabled: true,
    });

    // HEALTH SCENARIOS
    this.addScenario({
      id: 'health_medication_reminder',
      category: 'health',
      subcategory: 'medication',
      name: 'Medication Reminder',
      description: 'Time to take scheduled medication',
      triggers: [
        { type: 'time', condition: 'medication_time', parameters: {} },
      ],
      conditions: [
        { type: 'state', field: 'medication.taken', operator: 'eq', value: false },
      ],
      responses: [
        { order: 1, action: 'send_reminder', parameters: { type: 'medication' } },
        { order: 2, action: 'follow_up', parameters: { delay: 30, if: 'not_acknowledged' } },
        { order: 3, action: 'notify_caregiver', parameters: { delay: 60, if: 'not_taken' } },
      ],
      priority: 75,
      enabled: true,
    });

    this.addScenario({
      id: 'health_appointment_reminder',
      category: 'health',
      subcategory: 'appointment',
      name: 'Medical Appointment Reminder',
      description: 'Upcoming medical appointment',
      triggers: [
        { type: 'time', condition: 'appointment_approaching', parameters: { hoursBefore: 24 } },
      ],
      conditions: [
        { type: 'state', field: 'event.type', operator: 'eq', value: 'medical' },
      ],
      responses: [
        { order: 1, action: 'send_reminder', parameters: { type: 'appointment' } },
        { order: 2, action: 'prepare_documents', parameters: { type: 'medical' } },
        { order: 3, action: 'check_insurance', parameters: {} },
        { order: 4, action: 'plan_route', parameters: {} },
      ],
      priority: 60,
      enabled: true,
    });

    console.log(`[ScenarioHandler] Loaded ${this.scenarios.size} built-in scenarios`);
  }

  // -------------------------------------------------------------------------
  // SCENARIO MANAGEMENT
  // -------------------------------------------------------------------------

  addScenario(scenario: Scenario): void {
    this.scenarios.set(scenario.id, scenario);
    
    // Update category index
    const categoryScenarios = this.categoryIndex.get(scenario.category) || [];
    if (!categoryScenarios.includes(scenario.id)) {
      categoryScenarios.push(scenario.id);
      this.categoryIndex.set(scenario.category, categoryScenarios);
    }
  }

  removeScenario(id: string): boolean {
    const scenario = this.scenarios.get(id);
    if (!scenario) return false;

    this.scenarios.delete(id);
    
    // Update category index
    const categoryScenarios = this.categoryIndex.get(scenario.category) || [];
    const index = categoryScenarios.indexOf(id);
    if (index > -1) {
      categoryScenarios.splice(index, 1);
      this.categoryIndex.set(scenario.category, categoryScenarios);
    }

    return true;
  }

  getScenario(id: string): Scenario | undefined {
    return this.scenarios.get(id);
  }

  getScenariosByCategory(category: ScenarioCategory): Scenario[] {
    const ids = this.categoryIndex.get(category) || [];
    return ids.map(id => this.scenarios.get(id)!).filter(Boolean);
  }

  getAllScenarios(): Scenario[] {
    return Array.from(this.scenarios.values());
  }

  enableScenario(id: string): boolean {
    const scenario = this.scenarios.get(id);
    if (!scenario) return false;
    scenario.enabled = true;
    return true;
  }

  disableScenario(id: string): boolean {
    const scenario = this.scenarios.get(id);
    if (!scenario) return false;
    scenario.enabled = false;
    return true;
  }
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

export const scenarioHandler = new ScenarioHandler();
