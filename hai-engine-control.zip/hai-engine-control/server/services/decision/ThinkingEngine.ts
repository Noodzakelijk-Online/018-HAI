/**
 * Thinking Engine for HAI
 * 
 * The cognitive core that:
 * - Observes: Gathers context from screen, calendar, emails, etc.
 * - Analyzes: Identifies what needs attention
 * - Decides: Determines actions with confidence scoring
 * - Acts or Asks: Executes or escalates based on confidence
 * - Learns: Refines based on user feedback
 */

import { EventEmitter } from 'events';
import { 
  DecisionEngine, 
  getDecisionEngine,
  Decision,
  DecisionCategory,
  DecisionOption,
  DecisionContext
} from './DecisionEngine';
import { 
  WhatsAppEscalationService, 
  getWhatsAppEscalationService 
} from './WhatsAppEscalation';

// Types
export interface ScreenContext {
  hasContent: boolean;
  timestamp: number;
  fullText: string;
  summary: string;
  detectedButtons: Array<{ text: string; position: number[] }>;
  detectedHeadings: string[];
  detectedLinks: string[];
  activeApp?: string;
}

export interface CalendarContext {
  upcomingEvents: Array<{
    title: string;
    startTime: Date;
    endTime: Date;
    location?: string;
    attendees?: string[];
  }>;
  conflicts: Array<{
    event1: string;
    event2: string;
    overlapMinutes: number;
  }>;
}

export interface EmailContext {
  unreadCount: number;
  urgentEmails: Array<{
    from: string;
    subject: string;
    receivedAt: Date;
    priority: 'high' | 'medium' | 'low';
  }>;
  pendingReplies: Array<{
    to: string;
    subject: string;
    draftAge: number;
  }>;
}

export interface ThinkingContext {
  screen: ScreenContext | null;
  calendar: CalendarContext | null;
  email: EmailContext | null;
  timeOfDay: 'morning' | 'afternoon' | 'evening' | 'night';
  dayOfWeek: string;
  userActivity: 'active' | 'idle' | 'away';
  recentActions: Array<{
    action: string;
    timestamp: Date;
    result: string;
  }>;
}

export interface Observation {
  id: string;
  type: 'opportunity' | 'problem' | 'information' | 'reminder';
  title: string;
  description: string;
  confidence: number;
  source: string;
  timestamp: Date;
  context: Partial<ThinkingContext>;
  suggestedActions?: string[];
}

export interface ThinkingEngineConfig {
  thinkingIntervalMs: number;
  maxObservationsPerCycle: number;
  proactiveMode: boolean;
  verboseLogging: boolean;
}

const DEFAULT_CONFIG: ThinkingEngineConfig = {
  thinkingIntervalMs: 5000,
  maxObservationsPerCycle: 10,
  proactiveMode: true,
  verboseLogging: false
};

/**
 * Thinking Engine - The cognitive core of HAI
 */
export class ThinkingEngine extends EventEmitter {
  private config: ThinkingEngineConfig;
  private decisionEngine: DecisionEngine;
  private escalationService: WhatsAppEscalationService;
  
  private isRunning: boolean = false;
  private thinkingInterval?: NodeJS.Timeout;
  
  private currentContext: ThinkingContext;
  private observations: Observation[] = [];
  private thoughtLog: Array<{ timestamp: Date; thought: string }> = [];
  
  // Context providers (set externally)
  private screenContextProvider?: () => Promise<ScreenContext | null>;
  private calendarContextProvider?: () => Promise<CalendarContext | null>;
  private emailContextProvider?: () => Promise<EmailContext | null>;

  constructor(config: Partial<ThinkingEngineConfig> = {}) {
    super();
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.decisionEngine = getDecisionEngine();
    this.escalationService = getWhatsAppEscalationService();
    
    this.currentContext = this.createEmptyContext();
    
    // Wire up decision engine events
    this.decisionEngine.on('decisionExecuted', (decision: Decision) => {
      this.logThought(`Executed: ${decision.title}`);
      this.emit('actionTaken', decision);
    });
    
    this.decisionEngine.on('decisionNeedsEscalation', (decision: Decision) => {
      this.logThought(`Asking user: ${decision.title}`);
    });
  }

  /**
   * Start the thinking engine
   */
  start(): void {
    if (this.isRunning) return;
    
    this.isRunning = true;
    this.decisionEngine.start();
    this.escalationService.start();
    
    // Main thinking loop
    this.thinkingInterval = setInterval(() => {
      this.thinkingCycle();
    }, this.config.thinkingIntervalMs);
    
    console.log('[ThinkingEngine] Started');
    this.logThought('HAI Thinking Engine activated');
    this.emit('started');
  }

  /**
   * Stop the thinking engine
   */
  stop(): void {
    this.isRunning = false;
    
    if (this.thinkingInterval) {
      clearInterval(this.thinkingInterval);
    }
    
    this.decisionEngine.stop();
    this.escalationService.stop();
    
    console.log('[ThinkingEngine] Stopped');
    this.logThought('HAI Thinking Engine deactivated');
    this.emit('stopped');
  }

  /**
   * Set context providers
   */
  setScreenContextProvider(provider: () => Promise<ScreenContext | null>): void {
    this.screenContextProvider = provider;
  }

  setCalendarContextProvider(provider: () => Promise<CalendarContext | null>): void {
    this.calendarContextProvider = provider;
  }

  setEmailContextProvider(provider: () => Promise<EmailContext | null>): void {
    this.emailContextProvider = provider;
  }

  /**
   * Main thinking cycle
   */
  private async thinkingCycle(): Promise<void> {
    try {
      // 1. Gather context
      await this.gatherContext();
      
      // 2. Analyze and observe
      const observations = await this.analyze();
      
      // 3. Process observations into decisions
      for (const observation of observations) {
        await this.processObservation(observation);
      }
      
      // 4. Emit thinking status
      this.emit('thinkingCycle', {
        timestamp: new Date(),
        observationCount: observations.length,
        context: this.currentContext
      });
      
    } catch (error) {
      console.error('[ThinkingEngine] Thinking cycle error:', error);
    }
  }

  /**
   * Gather context from all sources
   */
  private async gatherContext(): Promise<void> {
    // Get screen context
    if (this.screenContextProvider) {
      try {
        this.currentContext.screen = await this.screenContextProvider();
      } catch (e) {
        if (this.config.verboseLogging) console.error('[ThinkingEngine] Screen context error:', e);
      }
    }
    
    // Get calendar context
    if (this.calendarContextProvider) {
      try {
        this.currentContext.calendar = await this.calendarContextProvider();
      } catch (e) {
        if (this.config.verboseLogging) console.error('[ThinkingEngine] Calendar context error:', e);
      }
    }
    
    // Get email context
    if (this.emailContextProvider) {
      try {
        this.currentContext.email = await this.emailContextProvider();
      } catch (e) {
        if (this.config.verboseLogging) console.error('[ThinkingEngine] Email context error:', e);
      }
    }
    
    // Update time context
    const now = new Date();
    const hour = now.getHours();
    
    if (hour >= 5 && hour < 12) {
      this.currentContext.timeOfDay = 'morning';
    } else if (hour >= 12 && hour < 17) {
      this.currentContext.timeOfDay = 'afternoon';
    } else if (hour >= 17 && hour < 21) {
      this.currentContext.timeOfDay = 'evening';
    } else {
      this.currentContext.timeOfDay = 'night';
    }
    
    this.currentContext.dayOfWeek = now.toLocaleDateString('en-US', { weekday: 'long' });
  }

  /**
   * Analyze context and generate observations
   */
  private async analyze(): Promise<Observation[]> {
    const observations: Observation[] = [];
    
    // Analyze calendar for conflicts and upcoming events
    if (this.currentContext.calendar) {
      const calendarObs = this.analyzeCalendar(this.currentContext.calendar);
      observations.push(...calendarObs);
    }
    
    // Analyze email for urgent items
    if (this.currentContext.email) {
      const emailObs = this.analyzeEmail(this.currentContext.email);
      observations.push(...emailObs);
    }
    
    // Analyze screen for actionable items
    if (this.currentContext.screen) {
      const screenObs = this.analyzeScreen(this.currentContext.screen);
      observations.push(...screenObs);
    }
    
    // Store observations
    this.observations = [...observations, ...this.observations].slice(0, 100);
    
    return observations.slice(0, this.config.maxObservationsPerCycle);
  }

  /**
   * Analyze calendar context
   */
  private analyzeCalendar(calendar: CalendarContext): Observation[] {
    const observations: Observation[] = [];
    
    // Check for conflicts
    for (const conflict of calendar.conflicts) {
      observations.push({
        id: this.generateId(),
        type: 'problem',
        title: 'Calendar Conflict Detected',
        description: `"${conflict.event1}" overlaps with "${conflict.event2}" by ${conflict.overlapMinutes} minutes`,
        confidence: 0.95,
        source: 'calendar',
        timestamp: new Date(),
        context: { calendar },
        suggestedActions: [
          'Reschedule one of the events',
          'Cancel one of the events',
          'Keep as is (attend partially)'
        ]
      });
    }
    
    // Check for upcoming events needing preparation
    const now = new Date();
    for (const event of calendar.upcomingEvents) {
      const minutesUntil = (event.startTime.getTime() - now.getTime()) / 60000;
      
      if (minutesUntil > 0 && minutesUntil <= 15) {
        observations.push({
          id: this.generateId(),
          type: 'reminder',
          title: 'Upcoming Event',
          description: `"${event.title}" starts in ${Math.round(minutesUntil)} minutes`,
          confidence: 0.99,
          source: 'calendar',
          timestamp: new Date(),
          context: { calendar }
        });
      }
    }
    
    return observations;
  }

  /**
   * Analyze email context
   */
  private analyzeEmail(email: EmailContext): Observation[] {
    const observations: Observation[] = [];
    
    // Check for urgent unread emails
    for (const urgent of email.urgentEmails) {
      const ageMinutes = (Date.now() - urgent.receivedAt.getTime()) / 60000;
      
      if (ageMinutes > 30 && urgent.priority === 'high') {
        observations.push({
          id: this.generateId(),
          type: 'problem',
          title: 'Urgent Email Unread',
          description: `High priority email from ${urgent.from}: "${urgent.subject}" (${Math.round(ageMinutes)} min ago)`,
          confidence: 0.85,
          source: 'email',
          timestamp: new Date(),
          context: { email },
          suggestedActions: [
            'Open and read now',
            'Send quick acknowledgment',
            'Mark for later'
          ]
        });
      }
    }
    
    // Check for stale drafts
    for (const draft of email.pendingReplies) {
      if (draft.draftAge > 24) { // More than 24 hours
        observations.push({
          id: this.generateId(),
          type: 'reminder',
          title: 'Pending Email Reply',
          description: `Draft reply to ${draft.to} about "${draft.subject}" is ${Math.round(draft.draftAge)} hours old`,
          confidence: 0.7,
          source: 'email',
          timestamp: new Date(),
          context: { email },
          suggestedActions: [
            'Complete and send',
            'Delete draft',
            'Keep as draft'
          ]
        });
      }
    }
    
    return observations;
  }

  /**
   * Analyze screen context
   */
  private analyzeScreen(screen: ScreenContext): Observation[] {
    const observations: Observation[] = [];
    
    if (!screen.hasContent) return observations;
    
    // Look for error messages
    const errorPatterns = [
      /error/i, /failed/i, /exception/i, /could not/i, /unable to/i
    ];
    
    for (const pattern of errorPatterns) {
      if (pattern.test(screen.fullText)) {
        observations.push({
          id: this.generateId(),
          type: 'problem',
          title: 'Error Detected on Screen',
          description: `Possible error message detected: "${screen.summary.slice(0, 100)}..."`,
          confidence: 0.6,
          source: 'screen',
          timestamp: new Date(),
          context: { screen }
        });
        break;
      }
    }
    
    // Look for confirmation dialogs
    const confirmPatterns = [
      /are you sure/i, /confirm/i, /do you want to/i, /proceed\?/i
    ];
    
    for (const pattern of confirmPatterns) {
      if (pattern.test(screen.fullText)) {
        observations.push({
          id: this.generateId(),
          type: 'opportunity',
          title: 'Confirmation Dialog Detected',
          description: 'A confirmation dialog appears to be on screen',
          confidence: 0.5,
          source: 'screen',
          timestamp: new Date(),
          context: { screen },
          suggestedActions: screen.detectedButtons.map(b => b.text)
        });
        break;
      }
    }
    
    return observations;
  }

  /**
   * Process an observation into a decision
   */
  private async processObservation(observation: Observation): Promise<void> {
    if (!this.config.proactiveMode) return;
    
    // Only create decisions for problems and opportunities
    if (observation.type !== 'problem' && observation.type !== 'opportunity') {
      // Just emit as information
      this.emit('observation', observation);
      return;
    }
    
    // Create decision options from suggested actions
    const options: DecisionOption[] = (observation.suggestedActions || []).map((action, index) => ({
      id: `opt_${index}`,
      label: action,
      action: async () => {
        // This would be implemented based on the action type
        console.log(`[ThinkingEngine] Executing action: ${action}`);
        return { action, executed: true };
      }
    }));
    
    // Add a "do nothing" option
    options.push({
      id: 'opt_nothing',
      label: 'Do nothing',
      action: async () => ({ action: 'nothing', executed: false })
    });
    
    // Map observation type to decision category
    const categoryMap: Record<string, DecisionCategory> = {
      'calendar': DecisionCategory.SCHEDULING,
      'email': DecisionCategory.COMMUNICATION,
      'screen': DecisionCategory.GENERAL,
      'financial': DecisionCategory.FINANCIAL
    };
    
    // Create decision
    this.decisionEngine.createDecision({
      title: observation.title,
      description: observation.description,
      category: categoryMap[observation.source] || DecisionCategory.GENERAL,
      confidence: observation.confidence,
      options,
      context: observation.context as any,
      reasoning: [
        `Detected from: ${observation.source}`,
        `Observation type: ${observation.type}`,
        `Confidence: ${(observation.confidence * 100).toFixed(0)}%`
      ]
    });
  }

  /**
   * Log a thought
   */
  private logThought(thought: string): void {
    this.thoughtLog.push({
      timestamp: new Date(),
      thought
    });
    
    // Limit log size
    if (this.thoughtLog.length > 500) {
      this.thoughtLog = this.thoughtLog.slice(-250);
    }
    
    if (this.config.verboseLogging) {
      console.log(`[ThinkingEngine] 💭 ${thought}`);
    }
    
    this.emit('thought', { timestamp: new Date(), thought });
  }

  /**
   * Create empty context
   */
  private createEmptyContext(): ThinkingContext {
    return {
      screen: null,
      calendar: null,
      email: null,
      timeOfDay: 'morning',
      dayOfWeek: new Date().toLocaleDateString('en-US', { weekday: 'long' }),
      userActivity: 'active',
      recentActions: []
    };
  }

  /**
   * Generate unique ID
   */
  private generateId(): string {
    return `obs_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Public getters

  getContext(): ThinkingContext {
    return this.currentContext;
  }

  getObservations(limit: number = 20): Observation[] {
    return this.observations.slice(0, limit);
  }

  getThoughtLog(limit: number = 50): Array<{ timestamp: Date; thought: string }> {
    return this.thoughtLog.slice(-limit);
  }

  getStatus(): {
    isRunning: boolean;
    config: ThinkingEngineConfig;
    contextSources: {
      screen: boolean;
      calendar: boolean;
      email: boolean;
    };
    observationCount: number;
    thoughtCount: number;
    decisionStats: ReturnType<DecisionEngine['getStats']>;
  } {
    return {
      isRunning: this.isRunning,
      config: this.config,
      contextSources: {
        screen: !!this.screenContextProvider,
        calendar: !!this.calendarContextProvider,
        email: !!this.emailContextProvider
      },
      observationCount: this.observations.length,
      thoughtCount: this.thoughtLog.length,
      decisionStats: this.decisionEngine.getStats()
    };
  }
}

// Singleton instance
let thinkingEngineInstance: ThinkingEngine | null = null;

export function getThinkingEngine(config?: Partial<ThinkingEngineConfig>): ThinkingEngine {
  if (!thinkingEngineInstance) {
    thinkingEngineInstance = new ThinkingEngine(config);
  }
  return thinkingEngineInstance;
}

export default ThinkingEngine;
