/**
 * Edge Case Handler
 * 
 * Handles EVERY edge case, unusual situation, and provides fallbacks.
 * This ensures HAI never fails silently and always has a response.
 */

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

export interface EdgeCase {
  id: string;
  category: EdgeCaseCategory;
  name: string;
  description: string;
  detection: EdgeCaseDetection;
  handling: EdgeCaseHandling;
  fallbacks: Fallback[];
  priority: number;
}

export type EdgeCaseCategory =
  | 'data_quality' | 'system_failure' | 'user_error'
  | 'external_service' | 'timing' | 'conflict'
  | 'permission' | 'resource' | 'security'
  | 'communication' | 'ambiguity' | 'impossible';

export interface EdgeCaseDetection {
  conditions: DetectionCondition[];
  patterns?: string[];
  exceptions?: string[];
}

export interface DetectionCondition {
  type: 'value' | 'state' | 'error' | 'timeout' | 'pattern';
  field?: string;
  operator?: string;
  value?: any;
  errorType?: string;
  timeoutMs?: number;
}

export interface EdgeCaseHandling {
  strategy: HandlingStrategy;
  actions: HandlingAction[];
  userNotification?: NotificationConfig;
  logging: LoggingConfig;
}

export type HandlingStrategy =
  | 'retry' | 'fallback' | 'degrade' | 'queue'
  | 'escalate' | 'ignore' | 'compensate' | 'abort';

export interface HandlingAction {
  order: number;
  action: string;
  parameters: Record<string, any>;
  condition?: string;
}

export interface NotificationConfig {
  notify: boolean;
  channels: string[];
  message: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
}

export interface LoggingConfig {
  level: 'debug' | 'info' | 'warn' | 'error';
  includeContext: boolean;
  alertOnOccurrence: boolean;
}

export interface Fallback {
  order: number;
  name: string;
  condition?: string;
  action: string;
  parameters: Record<string, any>;
}

export interface EdgeCaseResult {
  edgeCase: EdgeCase;
  handled: boolean;
  strategy: HandlingStrategy;
  actionsExecuted: string[];
  fallbackUsed?: string;
  userNotified: boolean;
  resolution: string;
}

// ============================================================================
// EDGE CASE HANDLER
// ============================================================================

export class EdgeCaseHandler {
  private edgeCases: Map<string, EdgeCase> = new Map();
  private occurrenceLog: Map<string, number> = new Map();

  constructor() {
    this.loadBuiltInEdgeCases();
  }

  // -------------------------------------------------------------------------
  // EDGE CASE DETECTION & HANDLING
  // -------------------------------------------------------------------------

  async detectAndHandle(context: {
    operation: string;
    input?: any;
    state?: any;
    error?: Error;
    timeout?: boolean;
  }): Promise<EdgeCaseResult | null> {
    // Find matching edge case
    const matchedEdgeCase = this.findMatchingEdgeCase(context);
    if (!matchedEdgeCase) return null;

    // Log occurrence
    this.logOccurrence(matchedEdgeCase.id);

    // Handle the edge case
    return this.handleEdgeCase(matchedEdgeCase, context);
  }

  private findMatchingEdgeCase(context: any): EdgeCase | null {
    for (const edgeCase of this.edgeCases.values()) {
      if (this.matchesDetection(edgeCase.detection, context)) {
        return edgeCase;
      }
    }
    return null;
  }

  private matchesDetection(detection: EdgeCaseDetection, context: any): boolean {
    // Check all conditions
    for (const condition of detection.conditions) {
      if (!this.matchesCondition(condition, context)) {
        return false;
      }
    }
    return true;
  }

  private matchesCondition(condition: DetectionCondition, context: any): boolean {
    switch (condition.type) {
      case 'error':
        if (!context.error) return false;
        if (condition.errorType && context.error.name !== condition.errorType) return false;
        return true;

      case 'timeout':
        return context.timeout === true;

      case 'value':
        if (!condition.field) return false;
        const value = this.getNestedValue(context, condition.field);
        return this.compareValues(value, condition.operator || 'eq', condition.value);

      case 'state':
        if (!condition.field || !context.state) return false;
        const stateValue = this.getNestedValue(context.state, condition.field);
        return this.compareValues(stateValue, condition.operator || 'eq', condition.value);

      case 'pattern':
        // Pattern matching for complex scenarios
        return false; // TODO: Implement pattern matching

      default:
        return false;
    }
  }

  private getNestedValue(obj: any, path: string): any {
    return path.split('.').reduce((current, key) => current?.[key], obj);
  }

  private compareValues(actual: any, operator: string, expected: any): boolean {
    switch (operator) {
      case 'eq': return actual === expected;
      case 'neq': return actual !== expected;
      case 'gt': return actual > expected;
      case 'lt': return actual < expected;
      case 'gte': return actual >= expected;
      case 'lte': return actual <= expected;
      case 'contains': return String(actual).includes(String(expected));
      case 'null': return actual === null || actual === undefined;
      case 'notNull': return actual !== null && actual !== undefined;
      case 'empty': return !actual || (Array.isArray(actual) && actual.length === 0);
      case 'notEmpty': return actual && (!Array.isArray(actual) || actual.length > 0);
      default: return false;
    }
  }

  private async handleEdgeCase(edgeCase: EdgeCase, context: any): Promise<EdgeCaseResult> {
    const result: EdgeCaseResult = {
      edgeCase,
      handled: false,
      strategy: edgeCase.handling.strategy,
      actionsExecuted: [],
      userNotified: false,
      resolution: '',
    };

    try {
      // Execute handling strategy
      switch (edgeCase.handling.strategy) {
        case 'retry':
          result.resolution = await this.executeRetryStrategy(edgeCase, context);
          break;
        case 'fallback':
          result.resolution = await this.executeFallbackStrategy(edgeCase, context, result);
          break;
        case 'degrade':
          result.resolution = await this.executeDegradeStrategy(edgeCase, context);
          break;
        case 'queue':
          result.resolution = await this.executeQueueStrategy(edgeCase, context);
          break;
        case 'escalate':
          result.resolution = await this.executeEscalateStrategy(edgeCase, context);
          break;
        case 'compensate':
          result.resolution = await this.executeCompensateStrategy(edgeCase, context);
          break;
        case 'abort':
          result.resolution = await this.executeAbortStrategy(edgeCase, context);
          break;
        case 'ignore':
          result.resolution = 'Edge case acknowledged and ignored per configuration';
          break;
      }

      // Execute handling actions
      for (const action of edgeCase.handling.actions) {
        await this.executeAction(action, context);
        result.actionsExecuted.push(action.action);
      }

      // Notify user if configured
      if (edgeCase.handling.userNotification?.notify) {
        await this.notifyUser(edgeCase.handling.userNotification, context);
        result.userNotified = true;
      }

      // Log the occurrence
      this.logEdgeCase(edgeCase, context, result);

      result.handled = true;
    } catch (error) {
      result.resolution = `Failed to handle edge case: ${error}`;
      result.handled = false;
    }

    return result;
  }

  // -------------------------------------------------------------------------
  // HANDLING STRATEGIES
  // -------------------------------------------------------------------------

  private async executeRetryStrategy(edgeCase: EdgeCase, context: any): Promise<string> {
    const maxRetries = 3;
    const backoffMs = 1000;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        // Simulate retry logic
        await new Promise(resolve => setTimeout(resolve, backoffMs * attempt));
        return `Succeeded on retry attempt ${attempt}`;
      } catch (error) {
        if (attempt === maxRetries) {
          return `All ${maxRetries} retry attempts failed`;
        }
      }
    }
    return 'Retry strategy completed';
  }

  private async executeFallbackStrategy(
    edgeCase: EdgeCase,
    context: any,
    result: EdgeCaseResult
  ): Promise<string> {
    for (const fallback of edgeCase.fallbacks) {
      try {
        // Check fallback condition
        if (fallback.condition && !this.evaluateCondition(fallback.condition, context)) {
          continue;
        }

        // Execute fallback
        await this.executeFallbackAction(fallback, context);
        result.fallbackUsed = fallback.name;
        return `Used fallback: ${fallback.name}`;
      } catch (error) {
        continue; // Try next fallback
      }
    }
    return 'All fallbacks exhausted';
  }

  private async executeDegradeStrategy(edgeCase: EdgeCase, context: any): Promise<string> {
    // Provide degraded functionality
    return 'Operating in degraded mode with limited functionality';
  }

  private async executeQueueStrategy(edgeCase: EdgeCase, context: any): Promise<string> {
    // Queue for later processing
    return 'Operation queued for later processing when conditions improve';
  }

  private async executeEscalateStrategy(edgeCase: EdgeCase, context: any): Promise<string> {
    // Escalate to human
    return 'Escalated to household owner for manual resolution';
  }

  private async executeCompensateStrategy(edgeCase: EdgeCase, context: any): Promise<string> {
    // Undo partial changes
    return 'Compensating actions executed to restore consistent state';
  }

  private async executeAbortStrategy(edgeCase: EdgeCase, context: any): Promise<string> {
    // Abort operation safely
    return 'Operation aborted safely with no side effects';
  }

  private evaluateCondition(condition: string, context: any): boolean {
    // Simple condition evaluation
    return true;
  }

  private async executeFallbackAction(fallback: Fallback, context: any): Promise<void> {
    // Execute the fallback action
    console.log(`[EdgeCaseHandler] Executing fallback: ${fallback.name}`);
  }

  private async executeAction(action: HandlingAction, context: any): Promise<void> {
    console.log(`[EdgeCaseHandler] Executing action: ${action.action}`);
  }

  private async notifyUser(config: NotificationConfig, context: any): Promise<void> {
    console.log(`[EdgeCaseHandler] Notifying user: ${config.message}`);
  }

  private logEdgeCase(edgeCase: EdgeCase, context: any, result: EdgeCaseResult): void {
    const level = edgeCase.handling.logging.level;
    console.log(`[EdgeCaseHandler][${level.toUpperCase()}] ${edgeCase.name}: ${result.resolution}`);
  }

  private logOccurrence(edgeCaseId: string): void {
    const count = (this.occurrenceLog.get(edgeCaseId) || 0) + 1;
    this.occurrenceLog.set(edgeCaseId, count);
  }

  // -------------------------------------------------------------------------
  // BUILT-IN EDGE CASES
  // -------------------------------------------------------------------------

  private loadBuiltInEdgeCases(): void {
    // DATA QUALITY EDGE CASES
    this.addEdgeCase({
      id: 'missing_required_field',
      category: 'data_quality',
      name: 'Missing Required Field',
      description: 'A required field is missing from input data',
      detection: {
        conditions: [
          { type: 'value', field: 'input', operator: 'null' },
        ],
      },
      handling: {
        strategy: 'fallback',
        actions: [
          { order: 1, action: 'use_default_value', parameters: {} },
        ],
        userNotification: {
          notify: false,
          channels: [],
          message: '',
          priority: 'low',
        },
        logging: { level: 'warn', includeContext: true, alertOnOccurrence: false },
      },
      fallbacks: [
        { order: 1, name: 'use_default', action: 'apply_default', parameters: {} },
        { order: 2, name: 'request_input', action: 'prompt_user', parameters: {} },
      ],
      priority: 50,
    });

    this.addEdgeCase({
      id: 'invalid_date_format',
      category: 'data_quality',
      name: 'Invalid Date Format',
      description: 'Date could not be parsed from input',
      detection: {
        conditions: [
          { type: 'error', errorType: 'DateParseError' },
        ],
      },
      handling: {
        strategy: 'fallback',
        actions: [
          { order: 1, action: 'try_alternative_formats', parameters: { formats: ['ISO', 'US', 'EU'] } },
        ],
        logging: { level: 'info', includeContext: true, alertOnOccurrence: false },
      },
      fallbacks: [
        { order: 1, name: 'natural_language', action: 'parse_natural_date', parameters: {} },
        { order: 2, name: 'ask_user', action: 'request_clarification', parameters: {} },
      ],
      priority: 40,
    });

    this.addEdgeCase({
      id: 'duplicate_entry',
      category: 'data_quality',
      name: 'Duplicate Entry Detected',
      description: 'Attempted to create a duplicate record',
      detection: {
        conditions: [
          { type: 'error', errorType: 'DuplicateError' },
        ],
      },
      handling: {
        strategy: 'degrade',
        actions: [
          { order: 1, action: 'merge_with_existing', parameters: {} },
        ],
        userNotification: {
          notify: true,
          channels: ['in_app'],
          message: 'Similar entry already exists. Merged with existing record.',
          priority: 'low',
        },
        logging: { level: 'info', includeContext: true, alertOnOccurrence: false },
      },
      fallbacks: [],
      priority: 30,
    });

    // SYSTEM FAILURE EDGE CASES
    this.addEdgeCase({
      id: 'database_connection_lost',
      category: 'system_failure',
      name: 'Database Connection Lost',
      description: 'Lost connection to database',
      detection: {
        conditions: [
          { type: 'error', errorType: 'DatabaseConnectionError' },
        ],
      },
      handling: {
        strategy: 'retry',
        actions: [
          { order: 1, action: 'reconnect_database', parameters: { maxAttempts: 5 } },
          { order: 2, action: 'switch_to_cache', parameters: {}, condition: 'retry_failed' },
        ],
        userNotification: {
          notify: true,
          channels: ['push'],
          message: 'Experiencing temporary issues. Some features may be limited.',
          priority: 'medium',
        },
        logging: { level: 'error', includeContext: true, alertOnOccurrence: true },
      },
      fallbacks: [
        { order: 1, name: 'use_cache', action: 'serve_from_cache', parameters: {} },
        { order: 2, name: 'queue_writes', action: 'queue_for_later', parameters: {} },
      ],
      priority: 90,
    });

    this.addEdgeCase({
      id: 'service_timeout',
      category: 'system_failure',
      name: 'Service Timeout',
      description: 'External service did not respond in time',
      detection: {
        conditions: [
          { type: 'timeout' },
        ],
      },
      handling: {
        strategy: 'retry',
        actions: [
          { order: 1, action: 'retry_with_backoff', parameters: { maxRetries: 3 } },
        ],
        logging: { level: 'warn', includeContext: true, alertOnOccurrence: false },
      },
      fallbacks: [
        { order: 1, name: 'use_cached', action: 'return_cached_response', parameters: {} },
        { order: 2, name: 'skip', action: 'skip_and_continue', parameters: {} },
      ],
      priority: 70,
    });

    this.addEdgeCase({
      id: 'memory_exhausted',
      category: 'system_failure',
      name: 'Memory Exhausted',
      description: 'System running low on memory',
      detection: {
        conditions: [
          { type: 'error', errorType: 'OutOfMemoryError' },
        ],
      },
      handling: {
        strategy: 'degrade',
        actions: [
          { order: 1, action: 'clear_caches', parameters: {} },
          { order: 2, action: 'reduce_batch_size', parameters: {} },
        ],
        userNotification: {
          notify: true,
          channels: ['push'],
          message: 'System resources limited. Processing may be slower.',
          priority: 'high',
        },
        logging: { level: 'error', includeContext: true, alertOnOccurrence: true },
      },
      fallbacks: [],
      priority: 95,
    });

    // EXTERNAL SERVICE EDGE CASES
    this.addEdgeCase({
      id: 'api_rate_limited',
      category: 'external_service',
      name: 'API Rate Limited',
      description: 'External API returned rate limit error',
      detection: {
        conditions: [
          { type: 'error', errorType: 'RateLimitError' },
        ],
      },
      handling: {
        strategy: 'queue',
        actions: [
          { order: 1, action: 'queue_request', parameters: {} },
          { order: 2, action: 'schedule_retry', parameters: { delayMs: 60000 } },
        ],
        logging: { level: 'warn', includeContext: true, alertOnOccurrence: false },
      },
      fallbacks: [
        { order: 1, name: 'use_alternative_api', action: 'switch_provider', parameters: {} },
      ],
      priority: 60,
    });

    this.addEdgeCase({
      id: 'api_authentication_failed',
      category: 'external_service',
      name: 'API Authentication Failed',
      description: 'External API rejected authentication',
      detection: {
        conditions: [
          { type: 'error', errorType: 'AuthenticationError' },
        ],
      },
      handling: {
        strategy: 'escalate',
        actions: [
          { order: 1, action: 'refresh_token', parameters: {} },
          { order: 2, action: 'notify_admin', parameters: {}, condition: 'refresh_failed' },
        ],
        userNotification: {
          notify: true,
          channels: ['push', 'email'],
          message: 'Connection to external service lost. Please re-authenticate.',
          priority: 'high',
        },
        logging: { level: 'error', includeContext: true, alertOnOccurrence: true },
      },
      fallbacks: [],
      priority: 80,
    });

    this.addEdgeCase({
      id: 'api_deprecated',
      category: 'external_service',
      name: 'API Deprecated',
      description: 'External API endpoint is deprecated',
      detection: {
        conditions: [
          { type: 'value', field: 'response.headers.deprecation', operator: 'notNull' },
        ],
      },
      handling: {
        strategy: 'degrade',
        actions: [
          { order: 1, action: 'log_deprecation', parameters: {} },
          { order: 2, action: 'notify_developer', parameters: {} },
        ],
        logging: { level: 'warn', includeContext: true, alertOnOccurrence: true },
      },
      fallbacks: [],
      priority: 40,
    });

    // TIMING EDGE CASES
    this.addEdgeCase({
      id: 'timezone_mismatch',
      category: 'timing',
      name: 'Timezone Mismatch',
      description: 'Event times in different timezones causing confusion',
      detection: {
        conditions: [
          { type: 'state', field: 'event.timezone', operator: 'neq', value: 'user.timezone' },
        ],
      },
      handling: {
        strategy: 'fallback',
        actions: [
          { order: 1, action: 'convert_to_user_timezone', parameters: {} },
          { order: 2, action: 'show_both_timezones', parameters: {} },
        ],
        logging: { level: 'info', includeContext: true, alertOnOccurrence: false },
      },
      fallbacks: [],
      priority: 50,
    });

    this.addEdgeCase({
      id: 'dst_transition',
      category: 'timing',
      name: 'DST Transition',
      description: 'Event occurs during daylight saving time transition',
      detection: {
        conditions: [
          { type: 'state', field: 'event.isDSTTransition', operator: 'eq', value: true },
        ],
      },
      handling: {
        strategy: 'fallback',
        actions: [
          { order: 1, action: 'clarify_time', parameters: {} },
          { order: 2, action: 'notify_ambiguity', parameters: {} },
        ],
        userNotification: {
          notify: true,
          channels: ['in_app'],
          message: 'This event occurs during a time change. Please verify the time.',
          priority: 'medium',
        },
        logging: { level: 'info', includeContext: true, alertOnOccurrence: false },
      },
      fallbacks: [],
      priority: 55,
    });

    // CONFLICT EDGE CASES
    this.addEdgeCase({
      id: 'concurrent_modification',
      category: 'conflict',
      name: 'Concurrent Modification',
      description: 'Multiple users trying to modify same resource',
      detection: {
        conditions: [
          { type: 'error', errorType: 'ConcurrencyError' },
        ],
      },
      handling: {
        strategy: 'fallback',
        actions: [
          { order: 1, action: 'merge_changes', parameters: {} },
        ],
        userNotification: {
          notify: true,
          channels: ['in_app'],
          message: 'Someone else made changes. Your changes have been merged.',
          priority: 'medium',
        },
        logging: { level: 'warn', includeContext: true, alertOnOccurrence: false },
      },
      fallbacks: [
        { order: 1, name: 'last_write_wins', action: 'overwrite', parameters: {} },
        { order: 2, name: 'ask_user', action: 'show_conflict_resolution', parameters: {} },
      ],
      priority: 65,
    });

    this.addEdgeCase({
      id: 'rule_conflict',
      category: 'conflict',
      name: 'Rule Conflict',
      description: 'Multiple rules producing contradictory actions',
      detection: {
        conditions: [
          { type: 'state', field: 'rules.hasConflict', operator: 'eq', value: true },
        ],
      },
      handling: {
        strategy: 'escalate',
        actions: [
          { order: 1, action: 'apply_priority_rule', parameters: {} },
          { order: 2, action: 'log_conflict', parameters: {} },
        ],
        userNotification: {
          notify: true,
          channels: ['in_app'],
          message: 'Your rules have a conflict. Please review and resolve.',
          priority: 'medium',
        },
        logging: { level: 'warn', includeContext: true, alertOnOccurrence: true },
      },
      fallbacks: [],
      priority: 70,
    });

    // PERMISSION EDGE CASES
    this.addEdgeCase({
      id: 'insufficient_permissions',
      category: 'permission',
      name: 'Insufficient Permissions',
      description: 'User lacks permission for requested action',
      detection: {
        conditions: [
          { type: 'error', errorType: 'PermissionDenied' },
        ],
      },
      handling: {
        strategy: 'escalate',
        actions: [
          { order: 1, action: 'request_approval', parameters: {} },
        ],
        userNotification: {
          notify: true,
          channels: ['in_app'],
          message: 'You need approval for this action. Request sent to household owner.',
          priority: 'medium',
        },
        logging: { level: 'info', includeContext: true, alertOnOccurrence: false },
      },
      fallbacks: [],
      priority: 60,
    });

    this.addEdgeCase({
      id: 'delegation_expired',
      category: 'permission',
      name: 'Delegation Expired',
      description: 'Temporary permission delegation has expired',
      detection: {
        conditions: [
          { type: 'error', errorType: 'DelegationExpired' },
        ],
      },
      handling: {
        strategy: 'fallback',
        actions: [
          { order: 1, action: 'request_renewal', parameters: {} },
        ],
        userNotification: {
          notify: true,
          channels: ['push'],
          message: 'Your temporary access has expired. Please request renewal.',
          priority: 'medium',
        },
        logging: { level: 'info', includeContext: true, alertOnOccurrence: false },
      },
      fallbacks: [],
      priority: 55,
    });

    // AMBIGUITY EDGE CASES
    this.addEdgeCase({
      id: 'ambiguous_intent',
      category: 'ambiguity',
      name: 'Ambiguous Intent',
      description: 'Could not determine user intent from input',
      detection: {
        conditions: [
          { type: 'state', field: 'intent.confidence', operator: 'lt', value: 0.5 },
        ],
      },
      handling: {
        strategy: 'escalate',
        actions: [
          { order: 1, action: 'request_clarification', parameters: {} },
        ],
        userNotification: {
          notify: true,
          channels: ['in_app'],
          message: 'I\'m not sure what you mean. Could you please clarify?',
          priority: 'low',
        },
        logging: { level: 'info', includeContext: true, alertOnOccurrence: false },
      },
      fallbacks: [
        { order: 1, name: 'suggest_options', action: 'show_possible_intents', parameters: {} },
      ],
      priority: 45,
    });

    this.addEdgeCase({
      id: 'multiple_matches',
      category: 'ambiguity',
      name: 'Multiple Matches',
      description: 'Multiple entities match the search criteria',
      detection: {
        conditions: [
          { type: 'state', field: 'search.matchCount', operator: 'gt', value: 1 },
        ],
      },
      handling: {
        strategy: 'fallback',
        actions: [
          { order: 1, action: 'show_disambiguation', parameters: {} },
        ],
        logging: { level: 'info', includeContext: true, alertOnOccurrence: false },
      },
      fallbacks: [
        { order: 1, name: 'use_most_recent', action: 'select_most_recent', parameters: {} },
        { order: 2, name: 'use_most_relevant', action: 'select_highest_score', parameters: {} },
      ],
      priority: 40,
    });

    // IMPOSSIBLE EDGE CASES
    this.addEdgeCase({
      id: 'impossible_schedule',
      category: 'impossible',
      name: 'Impossible Schedule',
      description: 'Requested schedule is physically impossible',
      detection: {
        conditions: [
          { type: 'state', field: 'schedule.isPossible', operator: 'eq', value: false },
        ],
      },
      handling: {
        strategy: 'fallback',
        actions: [
          { order: 1, action: 'explain_impossibility', parameters: {} },
          { order: 2, action: 'suggest_alternatives', parameters: {} },
        ],
        userNotification: {
          notify: true,
          channels: ['in_app'],
          message: 'This schedule isn\'t possible. Here are some alternatives.',
          priority: 'medium',
        },
        logging: { level: 'info', includeContext: true, alertOnOccurrence: false },
      },
      fallbacks: [],
      priority: 50,
    });

    this.addEdgeCase({
      id: 'budget_exceeded',
      category: 'impossible',
      name: 'Budget Exceeded',
      description: 'Requested action exceeds available budget',
      detection: {
        conditions: [
          { type: 'state', field: 'budget.remaining', operator: 'lt', value: 0 },
        ],
      },
      handling: {
        strategy: 'escalate',
        actions: [
          { order: 1, action: 'notify_budget_exceeded', parameters: {} },
          { order: 2, action: 'suggest_alternatives', parameters: {} },
        ],
        userNotification: {
          notify: true,
          channels: ['push'],
          message: 'This would exceed your budget. Would you like to adjust?',
          priority: 'high',
        },
        logging: { level: 'warn', includeContext: true, alertOnOccurrence: false },
      },
      fallbacks: [],
      priority: 75,
    });

    // SECURITY EDGE CASES
    this.addEdgeCase({
      id: 'suspicious_activity',
      category: 'security',
      name: 'Suspicious Activity',
      description: 'Unusual activity pattern detected',
      detection: {
        conditions: [
          { type: 'state', field: 'security.anomalyScore', operator: 'gt', value: 0.8 },
        ],
      },
      handling: {
        strategy: 'escalate',
        actions: [
          { order: 1, action: 'require_verification', parameters: {} },
          { order: 2, action: 'notify_owner', parameters: {} },
        ],
        userNotification: {
          notify: true,
          channels: ['push', 'email'],
          message: 'Unusual activity detected. Please verify this is you.',
          priority: 'critical',
        },
        logging: { level: 'error', includeContext: true, alertOnOccurrence: true },
      },
      fallbacks: [],
      priority: 95,
    });

    this.addEdgeCase({
      id: 'potential_phishing',
      category: 'security',
      name: 'Potential Phishing',
      description: 'Message appears to be phishing attempt',
      detection: {
        conditions: [
          { type: 'state', field: 'message.phishingScore', operator: 'gt', value: 0.7 },
        ],
      },
      handling: {
        strategy: 'abort',
        actions: [
          { order: 1, action: 'block_message', parameters: {} },
          { order: 2, action: 'warn_user', parameters: {} },
        ],
        userNotification: {
          notify: true,
          channels: ['in_app'],
          message: 'This message appears suspicious. It has been blocked.',
          priority: 'high',
        },
        logging: { level: 'warn', includeContext: true, alertOnOccurrence: true },
      },
      fallbacks: [],
      priority: 90,
    });

    console.log(`[EdgeCaseHandler] Loaded ${this.edgeCases.size} built-in edge cases`);
  }

  // -------------------------------------------------------------------------
  // EDGE CASE MANAGEMENT
  // -------------------------------------------------------------------------

  addEdgeCase(edgeCase: EdgeCase): void {
    this.edgeCases.set(edgeCase.id, edgeCase);
  }

  removeEdgeCase(id: string): boolean {
    return this.edgeCases.delete(id);
  }

  getEdgeCase(id: string): EdgeCase | undefined {
    return this.edgeCases.get(id);
  }

  getAllEdgeCases(): EdgeCase[] {
    return Array.from(this.edgeCases.values());
  }

  getEdgeCasesByCategory(category: EdgeCaseCategory): EdgeCase[] {
    return Array.from(this.edgeCases.values())
      .filter(ec => ec.category === category);
  }

  getOccurrenceCount(edgeCaseId: string): number {
    return this.occurrenceLog.get(edgeCaseId) || 0;
  }

  getOccurrenceStats(): Map<string, number> {
    return new Map(this.occurrenceLog);
  }
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

export const edgeCaseHandler = new EdgeCaseHandler();
