/**
 * WhatsApp Escalation Service for HAI Decision Engine
 * 
 * Handles sending decision questions to user via WhatsApp
 * and parsing their responses to continue the decision flow.
 */

import { EventEmitter } from 'events';
import { 
  Decision, 
  DecisionOption, 
  DecisionStatus,
  DecisionEngine,
  getDecisionEngine 
} from './DecisionEngine';

// Types
export interface WhatsAppMessage {
  id: string;
  to: string;
  body: string;
  timestamp: Date;
  status: 'pending' | 'sent' | 'delivered' | 'read' | 'failed';
}

export interface PendingQuestion {
  decisionId: string;
  messageId: string;
  question: string;
  options: string[];
  sentAt: Date;
  expiresAt: Date;
  remindersSent: number;
}

export interface EscalationConfig {
  ownerPhoneNumber: string;
  reminderIntervalMinutes: number;
  maxReminders: number;
  questionExpirationMinutes: number;
  formatStyle: 'numbered' | 'lettered' | 'emoji';
}

const DEFAULT_CONFIG: EscalationConfig = {
  ownerPhoneNumber: '',
  reminderIntervalMinutes: 15,
  maxReminders: 3,
  questionExpirationMinutes: 60,
  formatStyle: 'lettered'
};

/**
 * WhatsApp Escalation Service
 */
export class WhatsAppEscalationService extends EventEmitter {
  private config: EscalationConfig;
  private decisionEngine: DecisionEngine;
  private pendingQuestions: Map<string, PendingQuestion> = new Map();
  private messageToDecision: Map<string, string> = new Map();
  private isRunning: boolean = false;
  private reminderInterval?: NodeJS.Timeout;

  constructor(config: Partial<EscalationConfig> = {}) {
    super();
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.decisionEngine = getDecisionEngine();
    
    // Listen for decisions that need escalation
    this.decisionEngine.on('decisionNeedsEscalation', (decision: Decision) => {
      this.escalateDecision(decision);
    });
  }

  /**
   * Start the escalation service
   */
  start(): void {
    if (this.isRunning) return;
    
    this.isRunning = true;
    
    // Check for reminders periodically
    this.reminderInterval = setInterval(() => {
      this.checkReminders();
    }, 60000); // Every minute
    
    console.log('[WhatsAppEscalation] Started');
    this.emit('started');
  }

  /**
   * Stop the escalation service
   */
  stop(): void {
    this.isRunning = false;
    
    if (this.reminderInterval) {
      clearInterval(this.reminderInterval);
    }
    
    console.log('[WhatsAppEscalation] Stopped');
    this.emit('stopped');
  }

  /**
   * Set the owner's phone number
   */
  setOwnerPhone(phoneNumber: string): void {
    this.config.ownerPhoneNumber = phoneNumber;
  }

  /**
   * Escalate a decision to the user via WhatsApp
   */
  async escalateDecision(decision: Decision): Promise<boolean> {
    if (!this.config.ownerPhoneNumber) {
      console.error('[WhatsAppEscalation] No owner phone number configured');
      return false;
    }

    try {
      // Format the question
      const message = this.formatDecisionQuestion(decision);
      
      // Send via WhatsApp
      const messageId = await this.sendWhatsAppMessage(message);
      
      if (!messageId) {
        console.error('[WhatsAppEscalation] Failed to send message');
        return false;
      }
      
      // Track the pending question
      const pendingQuestion: PendingQuestion = {
        decisionId: decision.id,
        messageId,
        question: message,
        options: decision.options.map(o => o.label),
        sentAt: new Date(),
        expiresAt: decision.expiresAt || new Date(Date.now() + this.config.questionExpirationMinutes * 60000),
        remindersSent: 0
      };
      
      this.pendingQuestions.set(decision.id, pendingQuestion);
      this.messageToDecision.set(messageId, decision.id);
      
      // Update decision with message ID
      decision.whatsappMessageId = messageId;
      
      console.log(`[WhatsAppEscalation] Escalated decision ${decision.id} via WhatsApp`);
      this.emit('decisionEscalated', decision, messageId);
      
      return true;
      
    } catch (error) {
      console.error('[WhatsAppEscalation] Escalation failed:', error);
      return false;
    }
  }

  /**
   * Format a decision into a WhatsApp message
   */
  formatDecisionQuestion(decision: Decision): string {
    const lines: string[] = [];
    
    // Header with emoji based on category
    const categoryEmoji = this.getCategoryEmoji(decision.category);
    lines.push(`${categoryEmoji} *HAI Decision Required*`);
    lines.push('');
    
    // Title and description
    lines.push(`*${decision.title}*`);
    lines.push(decision.description);
    lines.push('');
    
    // Confidence indicator
    const confidencePercent = Math.round(decision.confidence * 100);
    lines.push(`_Confidence: ${confidencePercent}%_`);
    lines.push('');
    
    // Options
    lines.push('*Options:*');
    decision.options.forEach((option, index) => {
      const prefix = this.getOptionPrefix(index);
      lines.push(`${prefix} ${option.label}`);
      if (option.description) {
        lines.push(`   _${option.description}_`);
      }
    });
    lines.push('');
    
    // Instructions
    lines.push('_Reply with A, B, C or describe your choice_');
    
    // Reasoning (if available)
    if (decision.reasoning.length > 0) {
      lines.push('');
      lines.push('*Why I\'m asking:*');
      decision.reasoning.slice(0, 3).forEach(reason => {
        lines.push(`• ${reason}`);
      });
    }
    
    return lines.join('\n');
  }

  /**
   * Get emoji for decision category
   */
  private getCategoryEmoji(category: string): string {
    const emojis: Record<string, string> = {
      'financial': '💰',
      'communication': '📧',
      'scheduling': '📅',
      'system': '⚙️',
      'household': '🏠',
      'emergency': '🚨',
      'general': '🤖'
    };
    return emojis[category] || '🤖';
  }

  /**
   * Get option prefix based on format style
   */
  private getOptionPrefix(index: number): string {
    switch (this.config.formatStyle) {
      case 'numbered':
        return `${index + 1}.`;
      case 'emoji':
        const emojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣'];
        return emojis[index] || `${index + 1}.`;
      case 'lettered':
      default:
        return `${String.fromCharCode(65 + index)})`;
    }
  }

  /**
   * Handle incoming WhatsApp message (user response)
   */
  async handleIncomingMessage(messageId: string, from: string, body: string): Promise<void> {
    console.log(`[WhatsAppEscalation] Received message from ${from}: ${body}`);
    
    // Find the decision this response is for
    const decisionId = this.findDecisionForResponse(from, body);
    
    if (!decisionId) {
      console.log('[WhatsAppEscalation] No pending decision found for this response');
      // Could be a general message, emit event for other handlers
      this.emit('unmatchedMessage', { messageId, from, body });
      return;
    }
    
    // Remove from pending
    this.pendingQuestions.delete(decisionId);
    
    // Pass to decision engine
    const success = await this.decisionEngine.handleUserResponse(decisionId, body);
    
    // Send confirmation
    const confirmMessage = success
      ? '✅ Got it! I\'ll take care of that now.'
      : '❌ Understood. I\'ve cancelled this action.';
    
    await this.sendWhatsAppMessage(confirmMessage);
    
    this.emit('responseProcessed', { decisionId, response: body, success });
  }

  /**
   * Find which decision a response is for
   */
  private findDecisionForResponse(from: string, body: string): string | null {
    // Check if from owner
    if (!this.isFromOwner(from)) {
      return null;
    }
    
    // Get pending questions
    const pending = Array.from(this.pendingQuestions.values());
    
    if (pending.length === 0) {
      return null;
    }
    
    // If only one pending question, assume it's for that
    if (pending.length === 1) {
      return pending[0].decisionId;
    }
    
    // Try to match by content
    const bodyLower = body.toLowerCase();
    
    for (const question of pending) {
      // Check if response mentions any option
      for (const option of question.options) {
        if (bodyLower.includes(option.toLowerCase())) {
          return question.decisionId;
        }
      }
    }
    
    // Default to most recent question
    const sorted = pending.sort((a, b) => b.sentAt.getTime() - a.sentAt.getTime());
    return sorted[0].decisionId;
  }

  /**
   * Check if message is from the owner
   */
  private isFromOwner(from: string): boolean {
    // Normalize phone numbers for comparison
    const normalize = (phone: string) => phone.replace(/\D/g, '');
    return normalize(from) === normalize(this.config.ownerPhoneNumber);
  }

  /**
   * Check and send reminders for pending questions
   */
  private async checkReminders(): Promise<void> {
    const now = new Date();
    
    for (const [decisionId, question] of this.pendingQuestions) {
      // Check expiration
      if (question.expiresAt < now) {
        this.pendingQuestions.delete(decisionId);
        continue;
      }
      
      // Check if reminder is due
      const timeSinceSent = now.getTime() - question.sentAt.getTime();
      const reminderDue = timeSinceSent > (question.remindersSent + 1) * this.config.reminderIntervalMinutes * 60000;
      
      if (reminderDue && question.remindersSent < this.config.maxReminders) {
        await this.sendReminder(question);
        question.remindersSent++;
      }
    }
  }

  /**
   * Send a reminder for a pending question
   */
  private async sendReminder(question: PendingQuestion): Promise<void> {
    const decision = this.decisionEngine.getDecision(question.decisionId);
    if (!decision) return;
    
    const reminderMessage = [
      '⏰ *Reminder*',
      '',
      `I\'m still waiting for your decision on: *${decision.title}*`,
      '',
      `Options: ${question.options.map((o, i) => `${String.fromCharCode(65 + i)}) ${o}`).join(', ')}`,
      '',
      '_Reply with your choice or "cancel" to dismiss_'
    ].join('\n');
    
    await this.sendWhatsAppMessage(reminderMessage);
    
    console.log(`[WhatsAppEscalation] Sent reminder ${question.remindersSent + 1} for decision ${question.decisionId}`);
  }

  /**
   * Send a WhatsApp message
   * This integrates with the existing WhatsApp service
   */
  private async sendWhatsAppMessage(body: string): Promise<string | null> {
    try {
      // Emit event for the WhatsApp service to handle
      const messageId = `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      this.emit('sendMessage', {
        id: messageId,
        to: this.config.ownerPhoneNumber,
        body,
        timestamp: new Date()
      });
      
      return messageId;
      
    } catch (error) {
      console.error('[WhatsAppEscalation] Failed to send message:', error);
      return null;
    }
  }

  /**
   * Format a quick notification (for high/medium confidence actions)
   */
  formatActionNotification(decision: Decision, isUndoable: boolean): string {
    const lines: string[] = [];
    
    const emoji = decision.status === 'executed' ? '✅' : '⚡';
    lines.push(`${emoji} *HAI Action Taken*`);
    lines.push('');
    lines.push(`*${decision.title}*`);
    lines.push(decision.description);
    
    if (decision.result) {
      lines.push('');
      lines.push(`_Result: ${JSON.stringify(decision.result).slice(0, 100)}_`);
    }
    
    if (isUndoable) {
      lines.push('');
      lines.push('_Reply "undo" within 5 minutes to reverse this action_');
    }
    
    return lines.join('\n');
  }

  /**
   * Send notification about an action taken
   */
  async notifyActionTaken(decision: Decision, isUndoable: boolean = false): Promise<void> {
    const message = this.formatActionNotification(decision, isUndoable);
    await this.sendWhatsAppMessage(message);
  }

  // Public getters

  getPendingQuestions(): PendingQuestion[] {
    return Array.from(this.pendingQuestions.values());
  }

  getStatus(): {
    isRunning: boolean;
    pendingCount: number;
    config: EscalationConfig;
  } {
    return {
      isRunning: this.isRunning,
      pendingCount: this.pendingQuestions.size,
      config: this.config
    };
  }
}

// Singleton instance
let escalationServiceInstance: WhatsAppEscalationService | null = null;

export function getWhatsAppEscalationService(config?: Partial<EscalationConfig>): WhatsAppEscalationService {
  if (!escalationServiceInstance) {
    escalationServiceInstance = new WhatsAppEscalationService(config);
  }
  return escalationServiceInstance;
}

export default WhatsAppEscalationService;
