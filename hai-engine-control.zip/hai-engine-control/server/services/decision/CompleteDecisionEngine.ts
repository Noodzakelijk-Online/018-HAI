/**
 * Complete Decision Engine
 * 
 * Handles EVERY scenario, edge case, and fallback for household decisions.
 * This is the brain of HAI - it determines what action to take for any situation.
 */

import { EventEmitter } from 'events';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

export interface DecisionRequest {
  id: string;
  type: DecisionType;
  context: DecisionContext;
  constraints: DecisionConstraints;
  preferences: DecisionPreferences;
  urgency: UrgencyLevel;
  requestedAt: Date;
  deadline?: Date;
  requestedBy?: number; // userId
  householdId: number;
}

export type DecisionType =
  // Financial decisions
  | 'payment' | 'purchase' | 'transfer' | 'budget_adjustment' | 'subscription'
  | 'investment' | 'bill_pay' | 'refund_request' | 'dispute'
  // Scheduling decisions
  | 'schedule_event' | 'reschedule' | 'cancel_event' | 'accept_invitation'
  | 'decline_invitation' | 'suggest_time' | 'book_appointment'
  // Communication decisions
  | 'send_message' | 'reply' | 'forward' | 'delegate' | 'escalate'
  | 'draft_response' | 'schedule_send' | 'follow_up'
  // Home decisions
  | 'adjust_thermostat' | 'lock_unlock' | 'arm_disarm' | 'turn_on_off'
  | 'set_scene' | 'trigger_automation' | 'maintenance_schedule'
  // Family decisions
  | 'coordinate_pickup' | 'assign_chore' | 'approve_request'
  | 'mediate_conflict' | 'allocate_resource'
  // Emergency decisions
  | 'emergency_response' | 'alert_contacts' | 'call_services'
  // System decisions
  | 'update_rule' | 'create_automation' | 'modify_preference'
  | 'grant_permission' | 'revoke_permission';

export type UrgencyLevel = 'critical' | 'high' | 'medium' | 'low' | 'whenever';

export interface DecisionContext {
  // Input that triggered this decision
  inputId?: string;
  inputSource?: string;
  inputContent?: string;

  // Current state
  householdState: HouseholdState;
  memberStates: Map<number, MemberState>;
  environmentState: EnvironmentState;

  // Historical context
  relatedDecisions: string[];
  pastOutcomes: PastOutcome[];
  learnedPatterns: LearnedPattern[];

  // Temporal context
  currentTime: Date;
  timeOfDay: 'morning' | 'afternoon' | 'evening' | 'night';
  dayType: 'weekday' | 'weekend' | 'holiday';
  season: 'spring' | 'summer' | 'fall' | 'winter';
}

export interface HouseholdState {
  occupancy: 'empty' | 'partial' | 'full';
  presentMembers: number[];
  activeMode: 'normal' | 'away' | 'vacation' | 'sleep' | 'work' | 'emergency';
  securityStatus: 'armed' | 'disarmed' | 'partial';
  energyMode: 'normal' | 'eco' | 'comfort' | 'away';
}

export interface MemberState {
  memberId: number;
  location: 'home' | 'work' | 'school' | 'transit' | 'other' | 'unknown';
  activity: 'sleeping' | 'working' | 'relaxing' | 'exercising' | 'commuting' | 'unknown';
  availability: 'available' | 'busy' | 'dnd' | 'unknown';
  mood?: 'happy' | 'stressed' | 'tired' | 'neutral';
  lastInteraction?: Date;
}

export interface EnvironmentState {
  weather: {
    condition: string;
    temperature: number;
    humidity: number;
    alerts: string[];
  };
  traffic: {
    congestionLevel: 'low' | 'moderate' | 'high' | 'severe';
    incidents: string[];
  };
  localEvents: string[];
  marketConditions?: {
    trend: 'up' | 'down' | 'stable';
    volatility: 'low' | 'moderate' | 'high';
  };
}

export interface PastOutcome {
  decisionId: string;
  decisionType: DecisionType;
  action: string;
  outcome: 'success' | 'partial' | 'failure';
  feedback?: string;
  timestamp: Date;
}

export interface LearnedPattern {
  patternId: string;
  description: string;
  confidence: number;
  applicableTypes: DecisionType[];
}

export interface DecisionConstraints {
  // Financial constraints
  maxAmount?: number;
  budgetCategory?: string;
  requiresApproval?: boolean;
  approvalThreshold?: number;

  // Time constraints
  mustCompleteBefore?: Date;
  preferredTimeWindow?: { start: Date; end: Date };
  blackoutPeriods?: { start: Date; end: Date }[];

  // Authority constraints
  requiredAuthorityLevel?: number;
  allowedMembers?: number[];
  excludedMembers?: number[];

  // Policy constraints
  applicablePolicies?: string[];
  overridablePolicies?: string[];

  // Custom constraints
  custom?: Record<string, any>;
}

export interface DecisionPreferences {
  // Communication preferences
  preferredChannel?: string;
  preferredTone?: 'formal' | 'casual' | 'professional';
  preferredLanguage?: string;

  // Timing preferences
  preferredTimeOfDay?: string;
  avoidWeekends?: boolean;
  avoidHolidays?: boolean;

  // Financial preferences
  preferCheaper?: boolean;
  preferFaster?: boolean;
  preferredVendors?: string[];
  avoidedVendors?: string[];

  // Custom preferences
  custom?: Record<string, any>;
}

export interface Decision {
  id: string;
  requestId: string;
  type: DecisionType;
  
  // The decision itself
  action: DecisionAction;
  alternatives: DecisionAction[];
  
  // Reasoning
  reasoning: DecisionReasoning;
  
  // Execution plan
  executionPlan: ExecutionPlan;
  
  // Confidence and risk
  confidence: number;
  risk: RiskAssessment;
  
  // Approval requirements
  approval: ApprovalRequirement;
  
  // Metadata
  decidedAt: Date;
  expiresAt?: Date;
  status: DecisionStatus;
}

export interface DecisionAction {
  actionId: string;
  actionType: string;
  description: string;
  parameters: Record<string, any>;
  estimatedDuration?: number;
  estimatedCost?: number;
  reversible: boolean;
  rollbackPlan?: string;
}

export interface DecisionReasoning {
  factors: ReasoningFactor[];
  rulesApplied: string[];
  patternsMatched: string[];
  constraintsConsidered: string[];
  preferencesApplied: string[];
  tradeoffs: Tradeoff[];
  explanation: string;
}

export interface ReasoningFactor {
  factor: string;
  weight: number;
  value: any;
  impact: 'positive' | 'negative' | 'neutral';
  explanation: string;
}

export interface Tradeoff {
  option1: string;
  option2: string;
  chosenOption: string;
  reason: string;
}

export interface ExecutionPlan {
  steps: ExecutionStep[];
  totalDuration: number;
  checkpoints: Checkpoint[];
  rollbackTriggers: RollbackTrigger[];
}

export interface ExecutionStep {
  stepId: string;
  order: number;
  action: string;
  parameters: Record<string, any>;
  dependencies: string[];
  timeout: number;
  retryPolicy: {
    maxRetries: number;
    backoffMs: number;
  };
  onFailure: 'abort' | 'skip' | 'retry' | 'fallback';
  fallbackAction?: string;
}

export interface Checkpoint {
  afterStep: string;
  validation: string;
  onFailure: 'abort' | 'continue' | 'rollback';
}

export interface RollbackTrigger {
  condition: string;
  rollbackToStep?: string;
  fullRollback: boolean;
}

export interface RiskAssessment {
  overallRisk: 'low' | 'medium' | 'high' | 'critical';
  financialRisk: number; // 0-1
  reputationalRisk: number; // 0-1
  operationalRisk: number; // 0-1
  safetyRisk: number; // 0-1
  reversibilityRisk: number; // 0-1
  factors: string[];
  mitigations: string[];
}

export interface ApprovalRequirement {
  required: boolean;
  level: 'none' | 'any_member' | 'adult' | 'owner' | 'unanimous';
  reason?: string;
  approvers?: number[];
  deadline?: Date;
  autoApproveAfter?: number; // minutes
  autoRejectAfter?: number; // minutes
}

export type DecisionStatus = 
  | 'pending' | 'approved' | 'rejected' | 'executing' 
  | 'completed' | 'failed' | 'rolled_back' | 'expired';

// ============================================================================
// DECISION ENGINE
// ============================================================================

export class CompleteDecisionEngine extends EventEmitter {
  private decisions: Map<string, Decision> = new Map();
  private pendingRequests: Map<string, DecisionRequest> = new Map();
  private executionQueue: Decision[] = [];
  private isProcessing: boolean = false;

  // Rule engines
  private financialRules: FinancialRuleEngine;
  private schedulingRules: SchedulingRuleEngine;
  private communicationRules: CommunicationRuleEngine;
  private homeRules: HomeRuleEngine;
  private emergencyRules: EmergencyRuleEngine;

  constructor() {
    super();
    this.financialRules = new FinancialRuleEngine();
    this.schedulingRules = new SchedulingRuleEngine();
    this.communicationRules = new CommunicationRuleEngine();
    this.homeRules = new HomeRuleEngine();
    this.emergencyRules = new EmergencyRuleEngine();
  }

  // -------------------------------------------------------------------------
  // MAIN DECISION FLOW
  // -------------------------------------------------------------------------

  async makeDecision(request: DecisionRequest): Promise<Decision> {
    console.log(`[DecisionEngine] Processing request ${request.id} of type ${request.type}`);

    // Store pending request
    this.pendingRequests.set(request.id, request);

    try {
      // 1. Validate request
      this.validateRequest(request);

      // 2. Enrich context
      const enrichedContext = await this.enrichContext(request.context);

      // 3. Apply rules to generate options
      const options = await this.generateOptions(request, enrichedContext);

      // 4. Evaluate options
      const evaluatedOptions = await this.evaluateOptions(options, request, enrichedContext);

      // 5. Select best option
      const selectedAction = this.selectBestOption(evaluatedOptions);

      // 6. Assess risk
      const risk = this.assessRisk(selectedAction, request);

      // 7. Determine approval requirements
      const approval = this.determineApprovalRequirements(selectedAction, request, risk);

      // 8. Create execution plan
      const executionPlan = this.createExecutionPlan(selectedAction, request);

      // 9. Generate reasoning
      const reasoning = this.generateReasoning(
        selectedAction,
        evaluatedOptions,
        request,
        enrichedContext
      );

      // 10. Create decision
      const decision: Decision = {
        id: this.generateDecisionId(),
        requestId: request.id,
        type: request.type,
        action: selectedAction,
        alternatives: evaluatedOptions.filter(o => o.actionId !== selectedAction.actionId),
        reasoning,
        executionPlan,
        confidence: this.calculateConfidence(selectedAction, reasoning, risk),
        risk,
        approval,
        decidedAt: new Date(),
        expiresAt: request.deadline,
        status: approval.required ? 'pending' : 'approved',
      };

      // Store decision
      this.decisions.set(decision.id, decision);
      this.pendingRequests.delete(request.id);

      // Emit event
      this.emit('decision_made', decision);

      // If no approval needed, queue for execution
      if (!approval.required) {
        this.queueForExecution(decision);
      }

      return decision;
    } catch (error) {
      this.pendingRequests.delete(request.id);
      throw error;
    }
  }

  // -------------------------------------------------------------------------
  // VALIDATION
  // -------------------------------------------------------------------------

  private validateRequest(request: DecisionRequest): void {
    if (!request.id) throw new Error('Decision request must have an ID');
    if (!request.type) throw new Error('Decision request must have a type');
    if (!request.householdId) throw new Error('Decision request must have a household ID');
    if (!request.context) throw new Error('Decision request must have context');

    // Validate deadline
    if (request.deadline && request.deadline < new Date()) {
      throw new Error('Decision deadline has already passed');
    }

    // Validate constraints
    if (request.constraints.maxAmount !== undefined && request.constraints.maxAmount < 0) {
      throw new Error('Max amount cannot be negative');
    }
  }

  // -------------------------------------------------------------------------
  // CONTEXT ENRICHMENT
  // -------------------------------------------------------------------------

  private async enrichContext(context: DecisionContext): Promise<DecisionContext> {
    // Add real-time data
    const enriched = { ...context };

    // Update time context
    enriched.currentTime = new Date();
    const hour = enriched.currentTime.getHours();
    if (hour >= 5 && hour < 12) enriched.timeOfDay = 'morning';
    else if (hour >= 12 && hour < 17) enriched.timeOfDay = 'afternoon';
    else if (hour >= 17 && hour < 21) enriched.timeOfDay = 'evening';
    else enriched.timeOfDay = 'night';

    const day = enriched.currentTime.getDay();
    enriched.dayType = (day === 0 || day === 6) ? 'weekend' : 'weekday';

    // TODO: Check for holidays
    // TODO: Fetch real-time weather
    // TODO: Fetch real-time traffic
    // TODO: Fetch market conditions

    return enriched;
  }

  // -------------------------------------------------------------------------
  // OPTION GENERATION
  // -------------------------------------------------------------------------

  private async generateOptions(
    request: DecisionRequest,
    context: DecisionContext
  ): Promise<DecisionAction[]> {
    const options: DecisionAction[] = [];

    // Route to appropriate rule engine based on decision type
    switch (request.type) {
      // Financial decisions
      case 'payment':
      case 'purchase':
      case 'transfer':
      case 'budget_adjustment':
      case 'subscription':
      case 'investment':
      case 'bill_pay':
      case 'refund_request':
      case 'dispute':
        options.push(...this.financialRules.generateOptions(request, context));
        break;

      // Scheduling decisions
      case 'schedule_event':
      case 'reschedule':
      case 'cancel_event':
      case 'accept_invitation':
      case 'decline_invitation':
      case 'suggest_time':
      case 'book_appointment':
        options.push(...this.schedulingRules.generateOptions(request, context));
        break;

      // Communication decisions
      case 'send_message':
      case 'reply':
      case 'forward':
      case 'delegate':
      case 'escalate':
      case 'draft_response':
      case 'schedule_send':
      case 'follow_up':
        options.push(...this.communicationRules.generateOptions(request, context));
        break;

      // Home decisions
      case 'adjust_thermostat':
      case 'lock_unlock':
      case 'arm_disarm':
      case 'turn_on_off':
      case 'set_scene':
      case 'trigger_automation':
      case 'maintenance_schedule':
        options.push(...this.homeRules.generateOptions(request, context));
        break;

      // Emergency decisions
      case 'emergency_response':
      case 'alert_contacts':
      case 'call_services':
        options.push(...this.emergencyRules.generateOptions(request, context));
        break;

      default:
        // Generate generic options
        options.push(this.generateGenericOption(request));
    }

    // Always add a "do nothing" option for non-emergency decisions
    if (request.urgency !== 'critical') {
      options.push({
        actionId: `${request.id}_no_action`,
        actionType: 'no_action',
        description: 'Take no action at this time',
        parameters: {},
        reversible: true,
      });
    }

    return options;
  }

  private generateGenericOption(request: DecisionRequest): DecisionAction {
    return {
      actionId: `${request.id}_generic`,
      actionType: 'generic',
      description: `Process ${request.type} request`,
      parameters: {},
      reversible: true,
    };
  }

  // -------------------------------------------------------------------------
  // OPTION EVALUATION
  // -------------------------------------------------------------------------

  private async evaluateOptions(
    options: DecisionAction[],
    request: DecisionRequest,
    context: DecisionContext
  ): Promise<DecisionAction[]> {
    // Score each option
    const scored = options.map(option => ({
      option,
      score: this.scoreOption(option, request, context),
    }));

    // Sort by score descending
    scored.sort((a, b) => b.score - a.score);

    return scored.map(s => s.option);
  }

  private scoreOption(
    option: DecisionAction,
    request: DecisionRequest,
    context: DecisionContext
  ): number {
    let score = 50; // Base score

    // Preference alignment
    if (request.preferences.preferCheaper && option.estimatedCost !== undefined) {
      score += (100 - option.estimatedCost) * 0.2;
    }
    if (request.preferences.preferFaster && option.estimatedDuration !== undefined) {
      score += (100 - option.estimatedDuration) * 0.2;
    }

    // Reversibility bonus
    if (option.reversible) {
      score += 10;
    }

    // Constraint satisfaction
    if (request.constraints.maxAmount !== undefined && option.estimatedCost !== undefined) {
      if (option.estimatedCost <= request.constraints.maxAmount) {
        score += 20;
      } else {
        score -= 50; // Penalty for exceeding budget
      }
    }

    // Time constraint satisfaction
    if (request.constraints.mustCompleteBefore && option.estimatedDuration !== undefined) {
      const completionTime = new Date(Date.now() + option.estimatedDuration * 60000);
      if (completionTime <= request.constraints.mustCompleteBefore) {
        score += 15;
      } else {
        score -= 30;
      }
    }

    // Historical success rate
    const pastOutcomes = context.pastOutcomes.filter(
      o => o.action === option.actionType
    );
    if (pastOutcomes.length > 0) {
      const successRate = pastOutcomes.filter(o => o.outcome === 'success').length / pastOutcomes.length;
      score += successRate * 20;
    }

    // Pattern matching bonus
    const matchingPatterns = context.learnedPatterns.filter(
      p => p.applicableTypes.includes(request.type)
    );
    for (const pattern of matchingPatterns) {
      score += pattern.confidence * 5;
    }

    return Math.max(0, Math.min(100, score));
  }

  private selectBestOption(evaluatedOptions: DecisionAction[]): DecisionAction {
    if (evaluatedOptions.length === 0) {
      throw new Error('No valid options available');
    }
    return evaluatedOptions[0]; // Already sorted by score
  }

  // -------------------------------------------------------------------------
  // RISK ASSESSMENT
  // -------------------------------------------------------------------------

  private assessRisk(action: DecisionAction, request: DecisionRequest): RiskAssessment {
    const factors: string[] = [];
    const mitigations: string[] = [];

    // Financial risk
    let financialRisk = 0;
    if (action.estimatedCost !== undefined) {
      if (action.estimatedCost > 1000) {
        financialRisk = 0.8;
        factors.push('High cost action');
      } else if (action.estimatedCost > 100) {
        financialRisk = 0.4;
        factors.push('Moderate cost action');
      } else {
        financialRisk = 0.1;
      }
    }

    // Reversibility risk
    let reversibilityRisk = action.reversible ? 0.1 : 0.7;
    if (!action.reversible) {
      factors.push('Action is not reversible');
      if (action.rollbackPlan) {
        reversibilityRisk = 0.4;
        mitigations.push('Rollback plan available');
      }
    }

    // Operational risk
    let operationalRisk = 0.2;
    if (request.urgency === 'critical') {
      operationalRisk = 0.5;
      factors.push('Critical urgency increases operational risk');
    }

    // Safety risk
    let safetyRisk = 0.1;
    const safetyTypes: DecisionType[] = ['emergency_response', 'lock_unlock', 'arm_disarm'];
    if (safetyTypes.includes(request.type)) {
      safetyRisk = 0.4;
      factors.push('Safety-related decision');
      mitigations.push('Additional verification recommended');
    }

    // Reputational risk
    let reputationalRisk = 0.1;
    const communicationTypes: DecisionType[] = ['send_message', 'reply', 'forward'];
    if (communicationTypes.includes(request.type)) {
      reputationalRisk = 0.3;
      factors.push('External communication involved');
    }

    // Calculate overall risk
    const riskScores = [financialRisk, reversibilityRisk, operationalRisk, safetyRisk, reputationalRisk];
    const avgRisk = riskScores.reduce((a, b) => a + b, 0) / riskScores.length;
    const maxRisk = Math.max(...riskScores);

    let overallRisk: RiskAssessment['overallRisk'];
    if (maxRisk >= 0.8 || avgRisk >= 0.6) overallRisk = 'critical';
    else if (maxRisk >= 0.6 || avgRisk >= 0.4) overallRisk = 'high';
    else if (maxRisk >= 0.4 || avgRisk >= 0.2) overallRisk = 'medium';
    else overallRisk = 'low';

    return {
      overallRisk,
      financialRisk,
      reputationalRisk,
      operationalRisk,
      safetyRisk,
      reversibilityRisk,
      factors,
      mitigations,
    };
  }

  // -------------------------------------------------------------------------
  // APPROVAL REQUIREMENTS
  // -------------------------------------------------------------------------

  private determineApprovalRequirements(
    action: DecisionAction,
    request: DecisionRequest,
    risk: RiskAssessment
  ): ApprovalRequirement {
    // Check if approval is explicitly required
    if (request.constraints.requiresApproval) {
      return {
        required: true,
        level: 'owner',
        reason: 'Approval explicitly required by constraints',
        deadline: request.deadline,
      };
    }

    // High risk decisions need approval
    if (risk.overallRisk === 'critical') {
      return {
        required: true,
        level: 'owner',
        reason: 'Critical risk level requires owner approval',
        deadline: request.deadline,
      };
    }

    if (risk.overallRisk === 'high') {
      return {
        required: true,
        level: 'adult',
        reason: 'High risk level requires adult approval',
        deadline: request.deadline,
        autoApproveAfter: 60, // Auto-approve after 1 hour if no response
      };
    }

    // Financial thresholds
    if (action.estimatedCost !== undefined) {
      const threshold = request.constraints.approvalThreshold || 100;
      if (action.estimatedCost > threshold) {
        return {
          required: true,
          level: 'adult',
          reason: `Cost ($${action.estimatedCost}) exceeds approval threshold ($${threshold})`,
          deadline: request.deadline,
        };
      }
    }

    // Irreversible actions need approval
    if (!action.reversible && risk.overallRisk !== 'low') {
      return {
        required: true,
        level: 'any_member',
        reason: 'Irreversible action requires confirmation',
        deadline: request.deadline,
        autoApproveAfter: 30,
      };
    }

    // No approval needed
    return {
      required: false,
      level: 'none',
    };
  }

  // -------------------------------------------------------------------------
  // EXECUTION PLANNING
  // -------------------------------------------------------------------------

  private createExecutionPlan(action: DecisionAction, request: DecisionRequest): ExecutionPlan {
    const steps: ExecutionStep[] = [];
    const checkpoints: Checkpoint[] = [];
    const rollbackTriggers: RollbackTrigger[] = [];

    // Create main execution step
    steps.push({
      stepId: `${action.actionId}_main`,
      order: 1,
      action: action.actionType,
      parameters: action.parameters,
      dependencies: [],
      timeout: action.estimatedDuration ? action.estimatedDuration * 60 * 1000 : 30000,
      retryPolicy: {
        maxRetries: 3,
        backoffMs: 1000,
      },
      onFailure: 'retry',
    });

    // Add verification step
    steps.push({
      stepId: `${action.actionId}_verify`,
      order: 2,
      action: 'verify_completion',
      parameters: { actionId: action.actionId },
      dependencies: [`${action.actionId}_main`],
      timeout: 10000,
      retryPolicy: {
        maxRetries: 2,
        backoffMs: 500,
      },
      onFailure: 'abort',
    });

    // Add checkpoint after main action
    checkpoints.push({
      afterStep: `${action.actionId}_main`,
      validation: 'check_action_result',
      onFailure: action.reversible ? 'rollback' : 'abort',
    });

    // Add rollback trigger for critical failures
    if (action.reversible) {
      rollbackTriggers.push({
        condition: 'critical_error',
        fullRollback: true,
      });
    }

    const totalDuration = steps.reduce((sum, step) => sum + step.timeout, 0);

    return {
      steps,
      totalDuration,
      checkpoints,
      rollbackTriggers,
    };
  }

  // -------------------------------------------------------------------------
  // REASONING GENERATION
  // -------------------------------------------------------------------------

  private generateReasoning(
    selectedAction: DecisionAction,
    allOptions: DecisionAction[],
    request: DecisionRequest,
    context: DecisionContext
  ): DecisionReasoning {
    const factors: ReasoningFactor[] = [];
    const rulesApplied: string[] = [];
    const patternsMatched: string[] = [];
    const constraintsConsidered: string[] = [];
    const preferencesApplied: string[] = [];
    const tradeoffs: Tradeoff[] = [];

    // Document factors
    factors.push({
      factor: 'urgency',
      weight: 0.3,
      value: request.urgency,
      impact: request.urgency === 'critical' ? 'positive' : 'neutral',
      explanation: `Request urgency is ${request.urgency}`,
    });

    factors.push({
      factor: 'reversibility',
      weight: 0.2,
      value: selectedAction.reversible,
      impact: selectedAction.reversible ? 'positive' : 'negative',
      explanation: selectedAction.reversible 
        ? 'Action can be reversed if needed' 
        : 'Action cannot be reversed',
    });

    if (selectedAction.estimatedCost !== undefined) {
      factors.push({
        factor: 'cost',
        weight: 0.25,
        value: selectedAction.estimatedCost,
        impact: selectedAction.estimatedCost < 50 ? 'positive' : 'negative',
        explanation: `Estimated cost is $${selectedAction.estimatedCost}`,
      });
    }

    // Document constraints
    if (request.constraints.maxAmount !== undefined) {
      constraintsConsidered.push(`Maximum amount: $${request.constraints.maxAmount}`);
    }
    if (request.constraints.mustCompleteBefore) {
      constraintsConsidered.push(`Must complete before: ${request.constraints.mustCompleteBefore.toISOString()}`);
    }

    // Document preferences
    if (request.preferences.preferCheaper) {
      preferencesApplied.push('Preference for lower cost options');
    }
    if (request.preferences.preferFaster) {
      preferencesApplied.push('Preference for faster completion');
    }

    // Document tradeoffs
    if (allOptions.length > 1) {
      const alternative = allOptions[1];
      if (alternative.actionType !== 'no_action') {
        tradeoffs.push({
          option1: selectedAction.description,
          option2: alternative.description,
          chosenOption: selectedAction.description,
          reason: 'Higher overall score based on constraints and preferences',
        });
      }
    }

    // Generate explanation
    const explanation = this.generateExplanation(selectedAction, factors, request);

    return {
      factors,
      rulesApplied,
      patternsMatched,
      constraintsConsidered,
      preferencesApplied,
      tradeoffs,
      explanation,
    };
  }

  private generateExplanation(
    action: DecisionAction,
    factors: ReasoningFactor[],
    request: DecisionRequest
  ): string {
    let explanation = `Decision: ${action.description}. `;

    const positiveFactors = factors.filter(f => f.impact === 'positive');
    const negativeFactors = factors.filter(f => f.impact === 'negative');

    if (positiveFactors.length > 0) {
      explanation += `This option was chosen because: ${positiveFactors.map(f => f.explanation).join('; ')}. `;
    }

    if (negativeFactors.length > 0) {
      explanation += `Considerations: ${negativeFactors.map(f => f.explanation).join('; ')}. `;
    }

    if (request.urgency === 'critical') {
      explanation += 'Due to critical urgency, immediate action is recommended. ';
    }

    return explanation;
  }

  // -------------------------------------------------------------------------
  // CONFIDENCE CALCULATION
  // -------------------------------------------------------------------------

  private calculateConfidence(
    action: DecisionAction,
    reasoning: DecisionReasoning,
    risk: RiskAssessment
  ): number {
    let confidence = 0.7; // Base confidence

    // Adjust based on factors
    const positiveFactors = reasoning.factors.filter(f => f.impact === 'positive').length;
    const negativeFactors = reasoning.factors.filter(f => f.impact === 'negative').length;
    confidence += (positiveFactors - negativeFactors) * 0.05;

    // Adjust based on risk
    switch (risk.overallRisk) {
      case 'low': confidence += 0.1; break;
      case 'medium': confidence += 0; break;
      case 'high': confidence -= 0.1; break;
      case 'critical': confidence -= 0.2; break;
    }

    // Adjust based on patterns matched
    confidence += reasoning.patternsMatched.length * 0.02;

    // Adjust based on reversibility
    if (action.reversible) {
      confidence += 0.05;
    }

    return Math.max(0.1, Math.min(0.99, confidence));
  }

  // -------------------------------------------------------------------------
  // EXECUTION
  // -------------------------------------------------------------------------

  private queueForExecution(decision: Decision): void {
    this.executionQueue.push(decision);
    if (!this.isProcessing) {
      this.processExecutionQueue();
    }
  }

  private async processExecutionQueue(): Promise<void> {
    if (this.isProcessing) return;
    this.isProcessing = true;

    while (this.executionQueue.length > 0) {
      const decision = this.executionQueue.shift()!;
      await this.executeDecision(decision);
    }

    this.isProcessing = false;
  }

  async executeDecision(decision: Decision): Promise<void> {
    console.log(`[DecisionEngine] Executing decision ${decision.id}`);
    
    decision.status = 'executing';
    this.emit('decision_executing', decision);

    try {
      for (const step of decision.executionPlan.steps) {
        await this.executeStep(step, decision);
      }

      decision.status = 'completed';
      this.emit('decision_completed', decision);
    } catch (error) {
      console.error(`[DecisionEngine] Decision ${decision.id} failed:`, error);
      decision.status = 'failed';
      this.emit('decision_failed', { decision, error });
    }
  }

  private async executeStep(step: ExecutionStep, decision: Decision): Promise<void> {
    console.log(`[DecisionEngine] Executing step ${step.stepId}`);
    
    // In production, this would call actual services
    // For now, simulate execution
    await new Promise(resolve => setTimeout(resolve, 100));
    
    this.emit('step_completed', { decision, step });
  }

  // -------------------------------------------------------------------------
  // APPROVAL HANDLING
  // -------------------------------------------------------------------------

  async approveDecision(decisionId: string, approverId: number): Promise<Decision> {
    const decision = this.decisions.get(decisionId);
    if (!decision) throw new Error('Decision not found');
    if (decision.status !== 'pending') throw new Error('Decision is not pending approval');

    decision.status = 'approved';
    this.emit('decision_approved', { decision, approverId });
    
    // Queue for execution
    this.queueForExecution(decision);

    return decision;
  }

  async rejectDecision(decisionId: string, rejecterId: number, reason?: string): Promise<Decision> {
    const decision = this.decisions.get(decisionId);
    if (!decision) throw new Error('Decision not found');
    if (decision.status !== 'pending') throw new Error('Decision is not pending approval');

    decision.status = 'rejected';
    this.emit('decision_rejected', { decision, rejecterId, reason });

    return decision;
  }

  // -------------------------------------------------------------------------
  // QUERIES
  // -------------------------------------------------------------------------

  getDecision(id: string): Decision | undefined {
    return this.decisions.get(id);
  }

  getPendingDecisions(householdId?: number): Decision[] {
    return Array.from(this.decisions.values())
      .filter(d => d.status === 'pending');
  }

  getDecisionHistory(limit: number = 100): Decision[] {
    return Array.from(this.decisions.values())
      .sort((a, b) => b.decidedAt.getTime() - a.decidedAt.getTime())
      .slice(0, limit);
  }

  // -------------------------------------------------------------------------
  // HELPERS
  // -------------------------------------------------------------------------

  private generateDecisionId(): string {
    return `decision_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

// ============================================================================
// RULE ENGINES
// ============================================================================

class FinancialRuleEngine {
  generateOptions(request: DecisionRequest, context: DecisionContext): DecisionAction[] {
    const options: DecisionAction[] = [];

    switch (request.type) {
      case 'payment':
        options.push({
          actionId: `${request.id}_pay_now`,
          actionType: 'pay_now',
          description: 'Process payment immediately',
          parameters: request.constraints,
          reversible: false,
          rollbackPlan: 'Request refund if payment was in error',
        });
        options.push({
          actionId: `${request.id}_schedule_payment`,
          actionType: 'schedule_payment',
          description: 'Schedule payment for optimal time',
          parameters: { ...request.constraints, scheduleFor: 'due_date' },
          reversible: true,
        });
        break;

      case 'purchase':
        options.push({
          actionId: `${request.id}_purchase_now`,
          actionType: 'purchase_now',
          description: 'Complete purchase immediately',
          parameters: request.constraints,
          estimatedCost: (request.constraints as any).amount || 0,
          reversible: false,
        });
        options.push({
          actionId: `${request.id}_add_to_cart`,
          actionType: 'add_to_cart',
          description: 'Add to cart for later review',
          parameters: request.constraints,
          reversible: true,
        });
        break;

      default:
        options.push({
          actionId: `${request.id}_financial_generic`,
          actionType: 'process_financial',
          description: `Process ${request.type} request`,
          parameters: request.constraints,
          reversible: true,
        });
    }

    return options;
  }
}

class SchedulingRuleEngine {
  generateOptions(request: DecisionRequest, context: DecisionContext): DecisionAction[] {
    const options: DecisionAction[] = [];

    switch (request.type) {
      case 'schedule_event':
        options.push({
          actionId: `${request.id}_schedule_optimal`,
          actionType: 'schedule_optimal',
          description: 'Schedule at optimal time based on availability',
          parameters: request.constraints,
          reversible: true,
        });
        options.push({
          actionId: `${request.id}_schedule_requested`,
          actionType: 'schedule_requested',
          description: 'Schedule at requested time',
          parameters: request.constraints,
          reversible: true,
        });
        break;

      case 'accept_invitation':
        options.push({
          actionId: `${request.id}_accept`,
          actionType: 'accept_invitation',
          description: 'Accept the invitation',
          parameters: request.constraints,
          reversible: true,
        });
        options.push({
          actionId: `${request.id}_tentative`,
          actionType: 'tentative_accept',
          description: 'Tentatively accept pending confirmation',
          parameters: request.constraints,
          reversible: true,
        });
        break;

      default:
        options.push({
          actionId: `${request.id}_scheduling_generic`,
          actionType: 'process_scheduling',
          description: `Process ${request.type} request`,
          parameters: request.constraints,
          reversible: true,
        });
    }

    return options;
  }
}

class CommunicationRuleEngine {
  generateOptions(request: DecisionRequest, context: DecisionContext): DecisionAction[] {
    const options: DecisionAction[] = [];

    switch (request.type) {
      case 'reply':
        options.push({
          actionId: `${request.id}_reply_now`,
          actionType: 'send_reply',
          description: 'Send reply immediately',
          parameters: request.constraints,
          reversible: false,
        });
        options.push({
          actionId: `${request.id}_draft_reply`,
          actionType: 'draft_reply',
          description: 'Create draft for review',
          parameters: request.constraints,
          reversible: true,
        });
        break;

      case 'forward':
        options.push({
          actionId: `${request.id}_forward_now`,
          actionType: 'forward_message',
          description: 'Forward message immediately',
          parameters: request.constraints,
          reversible: false,
        });
        break;

      default:
        options.push({
          actionId: `${request.id}_communication_generic`,
          actionType: 'process_communication',
          description: `Process ${request.type} request`,
          parameters: request.constraints,
          reversible: true,
        });
    }

    return options;
  }
}

class HomeRuleEngine {
  generateOptions(request: DecisionRequest, context: DecisionContext): DecisionAction[] {
    const options: DecisionAction[] = [];

    switch (request.type) {
      case 'adjust_thermostat':
        options.push({
          actionId: `${request.id}_set_temp`,
          actionType: 'set_temperature',
          description: 'Set thermostat to requested temperature',
          parameters: request.constraints,
          reversible: true,
        });
        options.push({
          actionId: `${request.id}_eco_mode`,
          actionType: 'set_eco_mode',
          description: 'Enable eco mode for energy savings',
          parameters: request.constraints,
          reversible: true,
        });
        break;

      case 'lock_unlock':
        options.push({
          actionId: `${request.id}_lock_action`,
          actionType: 'toggle_lock',
          description: 'Toggle lock state',
          parameters: request.constraints,
          reversible: true,
        });
        break;

      default:
        options.push({
          actionId: `${request.id}_home_generic`,
          actionType: 'process_home',
          description: `Process ${request.type} request`,
          parameters: request.constraints,
          reversible: true,
        });
    }

    return options;
  }
}

class EmergencyRuleEngine {
  generateOptions(request: DecisionRequest, context: DecisionContext): DecisionAction[] {
    const options: DecisionAction[] = [];

    // Emergency decisions always have immediate action options
    options.push({
      actionId: `${request.id}_emergency_response`,
      actionType: 'emergency_response',
      description: 'Initiate emergency response protocol',
      parameters: { ...request.constraints, priority: 'critical' },
      reversible: false,
      estimatedDuration: 1, // 1 minute
    });

    options.push({
      actionId: `${request.id}_alert_all`,
      actionType: 'alert_all_contacts',
      description: 'Alert all emergency contacts',
      parameters: request.constraints,
      reversible: false,
    });

    if (request.type === 'call_services') {
      options.push({
        actionId: `${request.id}_call_911`,
        actionType: 'call_emergency_services',
        description: 'Call 911 emergency services',
        parameters: request.constraints,
        reversible: false,
      });
    }

    return options;
  }
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

export const completeDecisionEngine = new CompleteDecisionEngine();
