/**
 * Data Archival Strategy
 * Implements P2 #78: Implement data archival strategy
 */

import { sql } from 'drizzle-orm';

export interface ArchivalRule {
  id: string;
  table: string;
  condition: string; // SQL WHERE condition
  retentionDays: number;
  archiveTable?: string;
  deleteAfterArchive: boolean;
  enabled: boolean;
}

export interface ArchivalResult {
  ruleId: string;
  table: string;
  archivedCount: number;
  deletedCount: number;
  timestamp: Date;
  error?: string;
}

// Default archival rules
const DEFAULT_RULES: ArchivalRule[] = [
  {
    id: 'events_90d',
    table: 'events',
    condition: 'createdAt < DATE_SUB(NOW(), INTERVAL 90 DAY)',
    retentionDays: 90,
    archiveTable: 'events_archive',
    deleteAfterArchive: true,
    enabled: true,
  },
  {
    id: 'audit_logs_365d',
    table: 'audit_logs',
    condition: 'createdAt < DATE_SUB(NOW(), INTERVAL 365 DAY)',
    retentionDays: 365,
    archiveTable: 'audit_logs_archive',
    deleteAfterArchive: true,
    enabled: true,
  },
  {
    id: 'sessions_30d',
    table: 'sessions',
    condition: 'lastActivityAt < DATE_SUB(NOW(), INTERVAL 30 DAY)',
    retentionDays: 30,
    deleteAfterArchive: true,
    enabled: true,
  },
  {
    id: 'metrics_60d',
    table: 'service_metrics',
    condition: 'timestamp < DATE_SUB(NOW(), INTERVAL 60 DAY)',
    retentionDays: 60,
    deleteAfterArchive: true,
    enabled: true,
  },
];

let rules: ArchivalRule[] = [...DEFAULT_RULES];
const archivalHistory: ArchivalResult[] = [];

/**
 * Run archival for a specific rule
 */
export async function runArchival(
  db: any,
  rule: ArchivalRule
): Promise<ArchivalResult> {
  const result: ArchivalResult = {
    ruleId: rule.id,
    table: rule.table,
    archivedCount: 0,
    deletedCount: 0,
    timestamp: new Date(),
  };
  
  try {
    // Archive to separate table if specified
    if (rule.archiveTable) {
      // Create archive table if not exists
      await db.execute(sql.raw(`
        CREATE TABLE IF NOT EXISTS ${rule.archiveTable} LIKE ${rule.table}
      `));
      
      // Copy records to archive
      const insertResult = await db.execute(sql.raw(`
        INSERT INTO ${rule.archiveTable}
        SELECT * FROM ${rule.table}
        WHERE ${rule.condition}
      `));
      
      result.archivedCount = insertResult.rowsAffected || 0;
    }
    
    // Delete from main table
    if (rule.deleteAfterArchive || !rule.archiveTable) {
      const deleteResult = await db.execute(sql.raw(`
        DELETE FROM ${rule.table}
        WHERE ${rule.condition}
      `));
      
      result.deletedCount = deleteResult.rowsAffected || 0;
    }
    
    console.log(`[Archival] Rule ${rule.id}: archived ${result.archivedCount}, deleted ${result.deletedCount}`);
    
  } catch (error) {
    result.error = error instanceof Error ? error.message : String(error);
    console.error(`[Archival] Rule ${rule.id} failed:`, error);
  }
  
  archivalHistory.push(result);
  return result;
}

/**
 * Run all enabled archival rules
 */
export async function runAllArchivals(db: any): Promise<ArchivalResult[]> {
  const results: ArchivalResult[] = [];
  
  for (const rule of rules.filter(r => r.enabled)) {
    const result = await runArchival(db, rule);
    results.push(result);
  }
  
  return results;
}

/**
 * Add archival rule
 */
export function addRule(rule: Omit<ArchivalRule, 'id'>): ArchivalRule {
  const newRule: ArchivalRule = {
    ...rule,
    id: `rule_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`,
  };
  rules.push(newRule);
  return newRule;
}

/**
 * Update archival rule
 */
export function updateRule(ruleId: string, updates: Partial<ArchivalRule>): boolean {
  const index = rules.findIndex(r => r.id === ruleId);
  if (index === -1) return false;
  
  rules[index] = { ...rules[index], ...updates };
  return true;
}

/**
 * Remove archival rule
 */
export function removeRule(ruleId: string): boolean {
  const index = rules.findIndex(r => r.id === ruleId);
  if (index === -1) return false;
  
  rules.splice(index, 1);
  return true;
}

/**
 * Get all rules
 */
export function getRules(): ArchivalRule[] {
  return [...rules];
}

/**
 * Get archival history
 */
export function getHistory(limit: number = 50): ArchivalResult[] {
  return archivalHistory
    .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
    .slice(0, limit);
}

/**
 * Get archival statistics
 */
export function getStats(): {
  totalRules: number;
  enabledRules: number;
  totalArchived: number;
  totalDeleted: number;
  lastRun?: Date;
} {
  const totalArchived = archivalHistory.reduce((sum, r) => sum + r.archivedCount, 0);
  const totalDeleted = archivalHistory.reduce((sum, r) => sum + r.deletedCount, 0);
  const lastRun = archivalHistory.length > 0
    ? archivalHistory.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())[0].timestamp
    : undefined;
  
  return {
    totalRules: rules.length,
    enabledRules: rules.filter(r => r.enabled).length,
    totalArchived,
    totalDeleted,
    lastRun,
  };
}

/**
 * Estimate records to archive
 */
export async function estimateArchival(
  db: any,
  rule: ArchivalRule
): Promise<number> {
  try {
    const result = await db.execute(sql.raw(`
      SELECT COUNT(*) as count FROM ${rule.table}
      WHERE ${rule.condition}
    `));
    return result.rows?.[0]?.count || 0;
  } catch {
    return 0;
  }
}

/**
 * Schedule automatic archival
 */
export function scheduleArchival(db: any): NodeJS.Timeout {
  // Run weekly (simplified - in production use proper cron)
  const interval = 7 * 24 * 60 * 60 * 1000; // 7 days
  
  return setInterval(async () => {
    console.log('[Archival] Running scheduled archival...');
    await runAllArchivals(db);
  }, interval);
}

export default {
  runArchival,
  runAllArchivals,
  addRule,
  updateRule,
  removeRule,
  getRules,
  getHistory,
  getStats,
  estimateArchival,
  scheduleArchival,
};
