import { getDb } from "../db";
import { entities, relationships, Entity, Relationship } from "../../drizzle/schema";
import { eq, and, or, sql, desc } from "drizzle-orm";
import { EventBus } from "./EventBus";

/**
 * Graph node for algorithms
 */
interface GraphNode {
  id: number;
  entity: Entity;
  edges: Array<{ target: number; relationship: Relationship }>;
}

/**
 * Path in the graph
 */
interface GraphPath {
  entities: Entity[];
  relationships: Relationship[];
  length: number;
  score: number;
}

/**
 * Cluster of related entities
 */
interface EntityCluster {
  id: string;
  entities: Entity[];
  cohesion: number; // 0-100
  centralEntity?: Entity;
}

/**
 * Inference rule
 */
interface InferenceRule {
  id: string;
  name: string;
  description: string;
  pattern: {
    sourceType?: string;
    relationshipType?: string;
    targetType?: string;
  };
  inference: {
    newRelationshipType: string;
    confidence: number;
  };
}

/**
 * Enhanced Knowledge Graph Service
 * 
 * Advanced features:
 * - Graph algorithms (shortest path, clustering, centrality)
 * - Temporal knowledge tracking
 * - Inference rules
 * - Graph visualization data
 */
export class KnowledgeGraphEnhanced {
  /**
   * Find shortest path between two entities (Dijkstra's algorithm)
   */
  static async findShortestPath(params: {
    sourceEntityId: number;
    targetEntityId: number;
    maxDepth?: number;
  }): Promise<GraphPath | null> {
    const { sourceEntityId, targetEntityId, maxDepth = 10 } = params;

    const db = await getDb();
    if (!db) return null;

    // Build graph
    const graph = await this.buildGraph();
    
    // Dijkstra's algorithm
    const distances = new Map<number, number>();
    const previous = new Map<number, { entityId: number; relationshipId: number }>();
    const unvisited = new Set<number>(graph.keys());

    // Initialize
    distances.set(sourceEntityId, 0);
    for (const nodeId of Array.from(graph.keys())) {
      if (nodeId !== sourceEntityId) {
        distances.set(nodeId, Infinity);
      }
    }

    while (unvisited.size > 0) {
      // Find node with minimum distance
      let current: number | null = null;
      let minDistance = Infinity;
      for (const nodeId of Array.from(unvisited)) {
        const dist = distances.get(nodeId) || Infinity;
        if (dist < minDistance) {
          minDistance = dist;
          current = nodeId;
        }
      }

      if (current === null || minDistance === Infinity) break;
      if (current === targetEntityId) break;

      unvisited.delete(current);

      // Update distances to neighbors
      const node = graph.get(current);
      if (!node) continue;

      for (const edge of node.edges) {
        if (!unvisited.has(edge.target)) continue;

        const alt = minDistance + 1; // Each edge has weight 1
        if (alt < (distances.get(edge.target) || Infinity)) {
          distances.set(edge.target, alt);
          previous.set(edge.target, {
            entityId: current,
            relationshipId: edge.relationship.id,
          });
        }
      }
    }

    // Reconstruct path
    if (!previous.has(targetEntityId)) {
      return null; // No path found
    }

    const pathEntities: Entity[] = [];
    const pathRelationships: Relationship[] = [];
    let currentId = targetEntityId;

    while (currentId !== sourceEntityId) {
      const node = graph.get(currentId);
      if (!node) break;
      
      pathEntities.unshift(node.entity);
      
      const prev = previous.get(currentId);
      if (!prev) break;

      // Find the relationship
      const rel = await db
        .select()
        .from(relationships)
        .where(eq(relationships.id, prev.relationshipId))
        .limit(1);
      
      if (rel.length > 0) {
        pathRelationships.unshift(rel[0]);
      }

      currentId = prev.entityId;
    }

    // Add source entity
    const sourceEntity = await db
      .select()
      .from(entities)
      .where(eq(entities.id, sourceEntityId))
      .limit(1);
    
    if (sourceEntity.length > 0) {
      pathEntities.unshift(sourceEntity[0]);
    }

    return {
      entities: pathEntities,
      relationships: pathRelationships,
      length: pathEntities.length - 1,
      score: 100 - (pathEntities.length - 1) * 10, // Shorter paths score higher
    };
  }

  /**
   * Detect clusters of related entities
   */
  static async detectClusters(params: {
    minClusterSize?: number;
    maxClusters?: number;
  }): Promise<EntityCluster[]> {
    const { minClusterSize = 3, maxClusters = 10 } = params;

    const db = await getDb();
    if (!db) return [];

    const graph = await this.buildGraph();
    const visited = new Set<number>();
    const clusters: EntityCluster[] = [];

    // Simple connected components algorithm
    for (const [nodeId, node] of Array.from(graph.entries())) {
      if (visited.has(nodeId)) continue;

      const cluster: Entity[] = [];
      const queue = [nodeId];
      visited.add(nodeId);

      while (queue.length > 0) {
        const current = queue.shift()!;
        const currentNode = graph.get(current);
        if (!currentNode) continue;

        cluster.push(currentNode.entity);

        for (const edge of currentNode.edges) {
          if (!visited.has(edge.target)) {
            visited.add(edge.target);
            queue.push(edge.target);
          }
        }
      }

      if (cluster.length >= minClusterSize) {
        // Calculate cohesion (average connectivity)
        const totalConnections = cluster.reduce((sum, entity) => {
          const node = graph.get(entity.id);
          return sum + (node?.edges.length || 0);
        }, 0);
        const cohesion = Math.min(100, (totalConnections / cluster.length) * 20);

        // Find central entity (highest degree)
        let centralEntity = cluster[0];
        let maxDegree = 0;
        for (const entity of cluster) {
          const node = graph.get(entity.id);
          if (node && node.edges.length > maxDegree) {
            maxDegree = node.edges.length;
            centralEntity = entity;
          }
        }

        clusters.push({
          id: `cluster_${clusters.length + 1}`,
          entities: cluster,
          cohesion,
          centralEntity,
        });
      }

      if (clusters.length >= maxClusters) break;
    }

    return clusters;
  }

  /**
   * Calculate centrality measures for entities
   */
  static async calculateCentrality(params: {
    entityId?: number;
    measure?: 'degree' | 'betweenness' | 'closeness';
  }): Promise<Array<{ entity: Entity; centrality: number }>> {
    const { entityId, measure = 'degree' } = params;

    const db = await getDb();
    if (!db) return [];

    const graph = await this.buildGraph();

    if (measure === 'degree') {
      // Degree centrality: number of connections
      const results: Array<{ entity: Entity; centrality: number }> = [];

      for (const [nodeId, node] of Array.from(graph.entries())) {
        if (entityId && nodeId !== entityId) continue;

        const degree = node.edges.length;
        results.push({
          entity: node.entity,
          centrality: degree,
        });
      }

      return results.sort((a, b) => b.centrality - a.centrality);
    }

    // For betweenness and closeness, return degree for now (simplified)
    return this.calculateCentrality({ entityId, measure: 'degree' });
  }

  /**
   * Get temporal knowledge (entities mentioned in time range)
   */
  static async getTemporalKnowledge(params: {
    startTime: Date;
    endTime: Date;
    entityType?: string;
  }): Promise<Entity[]> {
    const { startTime, endTime, entityType } = params;

    const db = await getDb();
    if (!db) return [];

    // Build query
    const allEntities = await db.select().from(entities);
    
    // Filter by time range and entity type
    const filtered = allEntities.filter(e => {
      const createdAt = new Date(e.createdAt);
      const inTimeRange = createdAt >= startTime && createdAt <= endTime;
      const matchesType = !entityType || e.entityType === entityType;
      return inTimeRange && matchesType;
    });

    return filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  /**
   * Track entity evolution over time
   */
  static async trackEntityEvolution(params: {
    entityId: number;
  }): Promise<Array<{ timestamp: Date; properties: Record<string, unknown> }>> {
    const { entityId } = params;

    const db = await getDb();
    if (!db) return [];

    // Get entity
    const entity = await db
      .select()
      .from(entities)
      .where(eq(entities.id, entityId))
      .limit(1);

    if (entity.length === 0) return [];

    // For now, return current state
    // In a full implementation, we'd have a separate entity_history table
    return [
      {
        timestamp: entity[0].createdAt,
        properties: entity[0].properties as Record<string, unknown>,
      },
    ];
  }

  /**
   * Apply inference rules to discover new relationships
   */
  static async applyInferenceRules(params: {
    rules?: InferenceRule[];
  }): Promise<{ newRelationships: number; inferred: Relationship[] }> {
    const { rules = this.getDefaultRules() } = params;

    const db = await getDb();
    if (!db) return { newRelationships: 0, inferred: [] };

    const inferred: Relationship[] = [];

    for (const rule of rules) {
      // Find relationships matching the pattern
      const allRels = await db.select().from(relationships);
      const matching = rule.pattern.relationshipType
        ? allRels.filter(r => r.relationshipType === rule.pattern.relationshipType)
        : allRels;

      for (const rel of matching) {
        // Check if inferred relationship already exists
        const existing = await db
          .select()
          .from(relationships)
          .where(
            and(
              eq(relationships.sourceEntityId, rel.sourceEntityId),
              eq(relationships.targetEntityId, rel.targetEntityId),
              eq(relationships.relationshipType, rule.inference.newRelationshipType)
            )
          )
          .limit(1);

        if (existing.length === 0) {
          // Create inferred relationship
          await db.insert(relationships).values({
            sourceEntityId: rel.sourceEntityId,
            targetEntityId: rel.targetEntityId,
            relationshipType: rule.inference.newRelationshipType,
            properties: {
              inferred: true,
              inferredFrom: rel.id,
              rule: rule.id,
            },
            confidence: rule.inference.confidence,
          });

          const created = await db
            .select()
            .from(relationships)
            .where(
              and(
                eq(relationships.sourceEntityId, rel.sourceEntityId),
                eq(relationships.targetEntityId, rel.targetEntityId),
                eq(relationships.relationshipType, rule.inference.newRelationshipType)
              )
            )
            .limit(1);

          if (created.length > 0) {
            inferred.push(created[0]);
          }
        }
      }
    }

    // Publish event
    await EventBus.publish({
      type: 'knowledge_graph.inference_applied',
      source: 'knowledge_graph',
      target: '*',
      data: {
        rulesApplied: rules.length,
        newRelationships: inferred.length,
      },
      metadata: {
        priority: 'normal',
      },
    });

    return {
      newRelationships: inferred.length,
      inferred,
    };
  }

  /**
   * Get graph visualization data
   */
  static async getVisualizationData(params: {
    maxNodes?: number;
    centerEntityId?: number;
    depth?: number;
  }): Promise<{
    nodes: Array<{ id: number; label: string; type: string; properties: Record<string, unknown> }>;
    edges: Array<{ source: number; target: number; label: string; properties: Record<string, unknown> }>;
  }> {
    const { maxNodes = 100, centerEntityId, depth = 2 } = params;

    const db = await getDb();
    if (!db) return { nodes: [], edges: [] };

    let entityList: Entity[];

    if (centerEntityId) {
      // BFS from center entity
      entityList = await this.getEntitiesWithinDepth(centerEntityId, depth);
    } else {
      // Get most connected entities
      entityList = await db
        .select()
        .from(entities)
        .limit(maxNodes);
    }

    // Get relationships between these entities
    const entityIds = entityList.map(e => e.id);
    const relationshipList: Relationship[] = [];
    
    if (entityIds.length > 0) {
      const rels = await db.select().from(relationships);
      for (const rel of rels) {
        if (entityIds.includes(rel.sourceEntityId) && entityIds.includes(rel.targetEntityId)) {
          relationshipList.push(rel);
        }
      }
    }

    return {
      nodes: entityList.map(e => ({
        id: e.id,
        label: e.name,
        type: e.entityType,
        properties: e.properties as Record<string, unknown>,
      })),
      edges: relationshipList.map(r => ({
        source: r.sourceEntityId,
        target: r.targetEntityId,
        label: r.relationshipType,
        properties: r.properties as Record<string, unknown>,
      })),
    };
  }

  /**
   * Helper: Build graph from database
   */
  private static async buildGraph(): Promise<Map<number, GraphNode>> {
    const db = await getDb();
    if (!db) return new Map();

    const allEntities = await db.select().from(entities);
    const allRelationships = await db.select().from(relationships);

    const graph = new Map<number, GraphNode>();

    // Initialize nodes
    for (const entity of allEntities) {
      graph.set(entity.id, {
        id: entity.id,
        entity,
        edges: [],
      });
    }

    // Add edges
    for (const rel of allRelationships) {
      const sourceNode = graph.get(rel.sourceEntityId);
      if (sourceNode) {
        sourceNode.edges.push({
          target: rel.targetEntityId,
          relationship: rel,
        });
      }
    }

    return graph;
  }

  /**
   * Helper: Get entities within depth from center
   */
  private static async getEntitiesWithinDepth(
    centerEntityId: number,
    depth: number
  ): Promise<Entity[]> {
    const db = await getDb();
    if (!db) return [];

    const visited = new Set<number>();
    const result: Entity[] = [];
    const queue: Array<{ id: number; currentDepth: number }> = [{ id: centerEntityId, currentDepth: 0 }];

    while (queue.length > 0) {
      const { id, currentDepth } = queue.shift()!;
      
      if (visited.has(id) || currentDepth > depth) continue;
      visited.add(id);

      // Get entity
      const entity = await db
        .select()
        .from(entities)
        .where(eq(entities.id, id))
        .limit(1);

      if (entity.length > 0) {
        result.push(entity[0]);
      }

      if (currentDepth < depth) {
        // Get connected entities
        const rels = await db
          .select()
          .from(relationships)
          .where(
            or(
              eq(relationships.sourceEntityId, id),
              eq(relationships.targetEntityId, id)
            )
          );

        for (const rel of rels) {
          const nextId = rel.sourceEntityId === id ? rel.targetEntityId : rel.sourceEntityId;
          if (!visited.has(nextId)) {
            queue.push({ id: nextId, currentDepth: currentDepth + 1 });
          }
        }
      }
    }

    return result;
  }

  /**
   * Helper: Get default inference rules
   */
  private static getDefaultRules(): InferenceRule[] {
    return [
      {
        id: 'transitive_knows',
        name: 'Transitive Knows',
        description: 'If A knows B and B knows C, then A might know C',
        pattern: {
          relationshipType: 'knows',
        },
        inference: {
          newRelationshipType: 'might_know',
          confidence: 50,
        },
      },
      {
        id: 'family_relation',
        name: 'Family Relation',
        description: 'If A is related_to B, then B is related_to A',
        pattern: {
          relationshipType: 'related_to',
        },
        inference: {
          newRelationshipType: 'related_to',
          confidence: 90,
        },
      },
      {
        id: 'work_colleague',
        name: 'Work Colleague',
        description: 'If A works_at X and B works_at X, then A is colleague_of B',
        pattern: {
          relationshipType: 'works_at',
        },
        inference: {
          newRelationshipType: 'colleague_of',
          confidence: 70,
        },
      },
    ];
  }
}


/**
 * Additional Advanced Features for Knowledge Graph
 */

/**
 * Graph embedding for semantic similarity
 */
interface GraphEmbedding {
  entityId: number;
  vector: number[]; // Embedding vector
  dimension: number;
}

/**
 * Semantic search result
 */
interface SemanticSearchResult {
  entity: Entity;
  similarity: number; // 0-1
  explanation: string;
}

/**
 * Link prediction result
 */
interface LinkPrediction {
  sourceId: number;
  targetId: number;
  predictedRelationType: string;
  confidence: number;
  reasoning: string;
}

/**
 * Graph pattern
 */
interface GraphPattern {
  id: string;
  name: string;
  nodes: Array<{
    id: string;
    type?: string;
    properties?: Record<string, any>;
  }>;
  edges: Array<{
    from: string;
    to: string;
    type?: string;
  }>;
}

/**
 * Community detection result
 */
interface Community {
  id: string;
  members: number[]; // Entity IDs
  cohesion: number;
  bridges: Array<{ entityId: number; connections: number }>;
}

/**
 * Extended Knowledge Graph Engine with GNN and Advanced Reasoning
 */
export class KnowledgeGraphAdvanced extends KnowledgeGraphEnhanced {
  private embeddings: Map<number, GraphEmbedding> = new Map();
  private patterns: Map<string, GraphPattern> = new Map();

  /**
   * Generate graph embeddings using simplified GNN approach
   */
  async generateEmbeddings(dimension: number = 128): Promise<Map<number, GraphEmbedding>> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const allEntities = await db.select().from(entities);
    const allRelationships = await db.select().from(relationships);

    // Build adjacency information
    const adjacency = new Map<number, number[]>();
    allRelationships.forEach(rel => {
      if (!adjacency.has(rel.sourceEntityId)) adjacency.set(rel.sourceEntityId, []);
      if (!adjacency.has(rel.targetEntityId)) adjacency.set(rel.targetEntityId, []);
      adjacency.get(rel.sourceEntityId)!.push(rel.targetEntityId);
      adjacency.get(rel.targetEntityId)!.push(rel.sourceEntityId);
    });

    // Simple embedding: random initialization + neighbor aggregation
    for (const entity of allEntities) {
      const vector = Array.from({ length: dimension }, () => Math.random() - 0.5);
      
      // Aggregate neighbor information
      const neighbors = adjacency.get(entity.id) || [];
      if (neighbors.length > 0) {
        // Average with neighbors (simplified GNN message passing)
        neighbors.forEach(neighborId => {
          const neighborEmb = this.embeddings.get(neighborId);
          if (neighborEmb) {
            for (let i = 0; i < dimension; i++) {
              vector[i] = (vector[i] + neighborEmb.vector[i]) / 2;
            }
          }
        });
      }

      const embedding: GraphEmbedding = {
        entityId: entity.id,
        vector,
        dimension,
      };

      this.embeddings.set(entity.id, embedding);
    }

    await EventBus.publish({
      type: 'knowledge_graph.embeddings.generated',
      source: 'KnowledgeGraph',
      target: 'system',
      data: { entitiesCount: allEntities.length, dimension },
    });

    return this.embeddings;
  }

  /**
   * Semantic search using embeddings
   */
  async semanticSearch(query: string, topK: number = 10): Promise<SemanticSearchResult[]> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    // Generate query embedding (simplified: use text similarity)
    const queryTokens = query.toLowerCase().split(' ');

    const allEntities = await db.select().from(entities);
    const results: SemanticSearchResult[] = [];

    for (const entity of allEntities) {
      // Calculate similarity based on text overlap and embedding distance
      const entityText = `${entity.name} ${JSON.stringify(entity.properties)}`.toLowerCase();
      const entityTokens = entityText.split(' ');

      const overlap = queryTokens.filter(t => entityTokens.includes(t)).length;
      const textSimilarity = overlap / Math.max(queryTokens.length, entityTokens.length);

      // If embeddings exist, use cosine similarity
      let embeddingSimilarity = 0;
      const entityEmb = this.embeddings.get(entity.id);
      if (entityEmb) {
        // Simplified: use text similarity as proxy for embedding similarity
        embeddingSimilarity = textSimilarity;
      }

      const similarity = (textSimilarity + embeddingSimilarity) / 2;

      if (similarity > 0.1) {
        results.push({
          entity,
          similarity,
          explanation: `Matched ${overlap} keywords`,
        });
      }
    }

    // Sort by similarity and return top K
    results.sort((a, b) => b.similarity - a.similarity);
    return results.slice(0, topK);
  }

  /**
   * Predict missing links using GNN
   */
  async predictLinks(sourceId: number, topK: number = 5): Promise<LinkPrediction[]> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const sourceEmb = this.embeddings.get(sourceId);
    if (!sourceEmb) {
      throw new Error('Source entity embedding not found');
    }

    const allEntities = await db.select().from(entities);
    const existingRels = await db
      .select()
      .from(relationships)
      .where(eq(relationships.sourceEntityId, sourceId));

    const existingTargets = new Set(existingRels.map(r => r.targetEntityId));

    const predictions: LinkPrediction[] = [];

    for (const target of allEntities) {
      if (target.id === sourceId || existingTargets.has(target.id)) continue;

      const targetEmb = this.embeddings.get(target.id);
      if (!targetEmb) continue;

      // Calculate cosine similarity
      const similarity = this.cosineSimilarity(sourceEmb.vector, targetEmb.vector);

      if (similarity > 0.5) {
        predictions.push({
          sourceId,
          targetId: target.id,
          predictedRelationType: 'related_to',
          confidence: similarity,
          reasoning: `High embedding similarity (${(similarity * 100).toFixed(1)}%)`,
        });
      }
    }

    predictions.sort((a, b) => b.confidence - a.confidence);
    return predictions.slice(0, topK);
  }

  private cosineSimilarity(a: number[], b: number[]): number {
    let dotProduct = 0;
    let normA = 0;
    let normB = 0;

    for (let i = 0; i < a.length; i++) {
      dotProduct += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }

    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
  }

  /**
   * Detect communities using Louvain algorithm (simplified)
   */
  async detectCommunities(): Promise<Community[]> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const allEntities = await db.select().from(entities);
    const allRelationships = await db.select().from(relationships);

    // Build adjacency list
    const adjacency = new Map<number, Set<number>>();
    allEntities.forEach(e => adjacency.set(e.id, new Set()));

    allRelationships.forEach(rel => {
      adjacency.get(rel.sourceEntityId)?.add(rel.targetEntityId);
      adjacency.get(rel.targetEntityId)?.add(rel.sourceEntityId);
    });

    // Simplified community detection: connected components
    const visited = new Set<number>();
    const communities: Community[] = [];

    for (const entity of allEntities) {
      if (visited.has(entity.id)) continue;

      const community: number[] = [];
      const queue = [entity.id];

      while (queue.length > 0) {
        const current = queue.shift()!;
        if (visited.has(current)) continue;

        visited.add(current);
        community.push(current);

        const neighbors = adjacency.get(current) || new Set();
        neighbors.forEach(neighbor => {
          if (!visited.has(neighbor)) {
            queue.push(neighbor);
          }
        });
      }

      if (community.length > 1) {
        // Calculate cohesion
        let internalEdges = 0;
        community.forEach(id => {
          const neighbors = adjacency.get(id) || new Set();
          neighbors.forEach(neighbor => {
            if (community.includes(neighbor)) internalEdges++;
          });
        });

        const maxPossibleEdges = community.length * (community.length - 1);
        const cohesion = maxPossibleEdges > 0 ? internalEdges / maxPossibleEdges : 0;

        // Find bridge nodes
        const bridges = community.map(id => {
          const neighbors = adjacency.get(id) || new Set();
          const externalConnections = Array.from(neighbors).filter(n => !community.includes(n)).length;
          return { entityId: id, connections: externalConnections };
        }).filter(b => b.connections > 0);

        communities.push({
          id: `comm_${Date.now()}_${communities.length}`,
          members: community,
          cohesion,
          bridges,
        });
      }
    }

    await EventBus.publish({
      type: 'knowledge_graph.communities.detected',
      source: 'KnowledgeGraph',
      target: 'system',
      data: { communitiesCount: communities.length },
    });

    return communities;
  }

  /**
   * Find subgraph patterns
   */
  async findPattern(pattern: GraphPattern): Promise<Array<Map<string, Entity>>> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const matches: Array<Map<string, Entity>> = [];

    // Simplified pattern matching
    // In production, use graph query language like Cypher

    const allEntities = await db.select().from(entities);
    const allRelationships = await db.select().from(relationships);

    // For each potential starting node
    for (const entity of allEntities) {
      const match = new Map<string, Entity>();
      const startNode = pattern.nodes[0];

      // Check if entity matches start node
      if (startNode.type && entity.entityType !== startNode.type) continue;

      match.set(startNode.id, entity);

      // Try to match rest of pattern (simplified)
      let patternMatches = true;

      for (const edge of pattern.edges) {
        const sourceEntity = match.get(edge.from);
        if (!sourceEntity) {
          patternMatches = false;
          break;
        }

        // Find relationships from source
        const rels = allRelationships.filter(r => r.sourceEntityId === sourceEntity.id);

        if (edge.type) {
          const matchingRel = rels.find(r => r.relationshipType === edge.type);
          if (!matchingRel) {
            patternMatches = false;
            break;
          }

          const targetEntity = allEntities.find(e => e.id === matchingRel.targetEntityId);
          if (targetEntity) {
            match.set(edge.to, targetEntity);
          }
        }
      }

      if (patternMatches && match.size === pattern.nodes.length) {
        matches.push(match);
      }
    }

    return matches;
  }

  /**
   * Knowledge graph completion using rules and GNN
   */
  async completeGraph(): Promise<{ added: number; inferred: Relationship[] }> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const inferred: Relationship[] = [];

    // Use inference rules
    const ruleInferred = await KnowledgeGraphEnhanced.applyInferenceRules({});
    inferred.push(...ruleInferred.inferred);

    // Use link prediction
    const allEntities = await db.select().from(entities);
    
    for (const entity of allEntities.slice(0, 10)) { // Limit for performance
      const predictions = await this.predictLinks(entity.id, 3);
      
      for (const pred of predictions) {
        if (pred.confidence > 0.7) {
          const newRel: Relationship = {
            id: 0, // Will be assigned by DB
            sourceEntityId: pred.sourceId,
            targetEntityId: pred.targetId,
            relationshipType: pred.predictedRelationType,
            properties: { inferred: true, confidence: pred.confidence },
            createdAt: new Date(),
            confidence: pred.confidence,
          };

          // In production, insert into database
          inferred.push(newRel);
        }
      }
    }

    await EventBus.publish({
      type: 'knowledge_graph.completed',
      source: 'KnowledgeGraph',
      target: 'system',
      data: { inferredCount: inferred.length },
    });

    return { added: inferred.length, inferred };
  }

  /**
   * Get embeddings
   */
  getEmbeddings(): Map<number, GraphEmbedding> {
    return this.embeddings;
  }

  /**
   * Register pattern
   */
  registerPattern(pattern: GraphPattern): void {
    this.patterns.set(pattern.id, pattern);
  }

  /**
   * Get patterns
   */
  getPatterns(): GraphPattern[] {
    return Array.from(this.patterns.values());
  }
}
