/**
 * Google OAuth Routes
 * Express routes for handling Google OAuth flow
 */

import { Router } from 'express';
import {
  getGoogleAuthorizationUrl,
  exchangeCodeForTokens,
  getGoogleUserInfo,
} from '../../services/googleOAuthService';
import { getConnectorById, updateConnector } from '../../db';

const router = Router();

/**
 * GET /api/oauth/google/authorize
 * Initiates Google OAuth flow by redirecting to Google's consent screen
 */
router.get('/authorize', async (req, res) => {
  try {
    const { connectorId } = req.query;

    if (!connectorId) {
      return res.status(400).send('Missing connectorId parameter');
    }

    // Verify connector exists
    const connector = await getConnectorById(Number(connectorId));
    if (!connector) {
      return res.status(404).send('Connector not found');
    }

    // Generate state parameter (includes connectorId for callback)
    const state = JSON.stringify({ connectorId: Number(connectorId) });
    
    // Build redirect URI
    const protocol = req.protocol;
    const host = req.get('host');
    const redirectUri = `${protocol}://${host}/api/oauth/google/callback`;

    // Generate authorization URL
    const authUrl = getGoogleAuthorizationUrl(state, redirectUri);

    console.log(`[GoogleOAuth] Redirecting to Google authorization for connector ${connectorId}`);
    
    // Redirect to Google
    res.redirect(authUrl);
  } catch (error: any) {
    console.error('[GoogleOAuth] Authorization error:', error);
    res.status(500).send(`OAuth error: ${error.message}`);
  }
});

/**
 * GET /api/oauth/google/callback
 * Handles OAuth callback from Google
 */
router.get('/callback', async (req, res) => {
  try {
    const { code, state, error } = req.query;

    // Handle OAuth errors
    if (error) {
      console.error('[GoogleOAuth] OAuth error from Google:', error);
      return res.redirect(`/connectors?error=${encodeURIComponent(error as string)}`);
    }

    if (!code || !state) {
      return res.status(400).send('Missing code or state parameter');
    }

    // Parse state to get connectorId
    const { connectorId } = JSON.parse(state as string);

    // Verify connector exists
    const connector = await getConnectorById(connectorId);
    if (!connector) {
      return res.status(404).send('Connector not found');
    }

    // Build redirect URI (must match the one used in authorize)
    const protocol = req.protocol;
    const host = req.get('host');
    const redirectUri = `${protocol}://${host}/api/oauth/google/callback`;

    // Exchange code for tokens
    console.log(`[GoogleOAuth] Exchanging code for tokens for connector ${connectorId}`);
    const tokens = await exchangeCodeForTokens(code as string, redirectUri);

    // Get user info
    const userInfo = await getGoogleUserInfo(tokens.access_token);
    console.log(`[GoogleOAuth] Successfully authenticated ${userInfo.email}`);

    // Update connector with tokens and user info
    await updateConnector(connectorId, {
      status: 'active',
      accessToken: tokens.access_token,
      refreshToken: tokens.refresh_token,
      tokenExpiresAt: new Date(Date.now() + tokens.expires_in * 1000),
      metadata: JSON.stringify({
        email: userInfo.email,
        name: userInfo.name,
        picture: userInfo.picture,
        scopes: tokens.scope.split(' '),
      }),
    });

    console.log(`[GoogleOAuth] Connector ${connectorId} activated successfully`);

    // Redirect back to connectors page with success message
    res.redirect('/connectors?success=true');
  } catch (error: any) {
    console.error('[GoogleOAuth] Callback error:', error);
    res.redirect(`/connectors?error=${encodeURIComponent(error.message)}`);
  }
});

export default router;
