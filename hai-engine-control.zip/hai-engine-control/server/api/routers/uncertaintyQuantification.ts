import { z } from "zod";
import { protectedProcedure, router } from "../../_core/trpc";
import { uncertaintyQuantificationService } from "../../services/UncertaintyQuantificationService";

export const uncertaintyQuantificationRouter = router({
  /**
   * 71. Bayesian uncertainty propagation
   */
  propagateUncertainty: protectedProcedure
    .input(
      z.object({
        inputUncertainties: z.array(
          z.object({
            variable: z.string(),
            distribution: z.string(),
            parameters: z.record(z.number()),
          })
        ),
        transformationFunction: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      return uncertaintyQuantificationService.propagateUncertainty(
        input.inputUncertainties,
        input.transformationFunction
      );
    }),

  /**
   * 72. Epistemic vs aleatoric uncertainty decomposition
   */
  decomposeUncertainty: protectedProcedure
    .input(
      z.object({
        predictions: z.array(
          z.object({
            predicted: z.number(),
            actual: z.number(),
            context: z.record(z.any()),
          })
        ),
      })
    )
    .query(async ({ input }) => {
      return uncertaintyQuantificationService.decomposeUncertainty(input.predictions);
    }),

  /**
   * 73. Confidence calibration
   */
  calibrateConfidence: protectedProcedure
    .input(
      z.object({
        predictions: z.array(
          z.object({
            confidence: z.number(),
            wasCorrect: z.boolean(),
          })
        ),
      })
    )
    .query(async ({ input }) => {
      return uncertaintyQuantificationService.calibrateConfidence(input.predictions);
    }),

  /**
   * 74. Worst-case scenario planning
   */
  planWorstCase: protectedProcedure
    .input(
      z.object({
        baseCase: z.record(z.number()),
        riskFactors: z.array(z.string()),
      })
    )
    .mutation(async ({ input }) => {
      return uncertaintyQuantificationService.planWorstCase(
        input.baseCase,
        input.riskFactors
      );
    }),

  /**
   * 75. Uncertainty-aware scheduling
   */
  createUncertaintyAwareSchedule: protectedProcedure
    .input(
      z.object({
        tasks: z.array(
          z.object({
            taskId: z.string(),
            estimatedDuration: z.number(),
            durationUncertainty: z.number(),
            dependencies: z.array(z.string()),
          })
        ),
      })
    )
    .mutation(async ({ input }) => {
      return uncertaintyQuantificationService.createUncertaintyAwareSchedule(input.tasks);
    }),

  /**
   * 76. Risk-adjusted prioritization
   */
  prioritizeWithRisk: protectedProcedure
    .input(
      z.object({
        items: z.array(
          z.object({
            itemId: z.string(),
            expectedValue: z.number(),
            risk: z.number(),
          })
        ),
        riskTolerance: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      return uncertaintyQuantificationService.prioritizeWithRisk(
        input.items,
        input.riskTolerance
      );
    }),

  /**
   * 77. Uncertainty reduction strategies
   */
  identifyUncertaintyReductionStrategies: protectedProcedure
    .input(
      z.object({
        currentUncertainty: z.number(),
        uncertaintySources: z.array(z.string()),
      })
    )
    .query(async ({ input }) => {
      return uncertaintyQuantificationService.identifyUncertaintyReductionStrategies(
        input.currentUncertainty,
        input.uncertaintySources
      );
    }),

  /**
   * 78. Monte Carlo simulation
   */
  runMonteCarloSimulation: protectedProcedure
    .input(
      z.object({
        model: z.string(),
        inputDistributions: z.record(
          z.object({
            distribution: z.string(),
            params: z.array(z.number()),
          })
        ),
        iterations: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return uncertaintyQuantificationService.runMonteCarloSimulation(
        input.model,
        input.inputDistributions,
        input.iterations
      );
    }),

  /**
   * 79. Value of information calculation
   */
  calculateValueOfInformation: protectedProcedure
    .input(
      z.object({
        currentDecision: z.string(),
        currentExpectedValue: z.number(),
        informationSources: z.array(
          z.object({
            source: z.string(),
            cost: z.number(),
          })
        ),
      })
    )
    .query(async ({ input }) => {
      return uncertaintyQuantificationService.calculateValueOfInformation(
        input.currentDecision,
        input.currentExpectedValue,
        input.informationSources
      );
    }),

  /**
   * 80. Robust decision making
   */
  makeRobustDecision: protectedProcedure
    .input(
      z.object({
        alternatives: z.array(
          z.object({
            alternativeId: z.string(),
            description: z.string(),
            outcomesByScenario: z.record(z.number()),
          })
        ),
        scenarios: z.array(z.string()),
        method: z.enum(["minimax", "maximin", "minimax_regret", "satisficing"]).optional(),
      })
    )
    .mutation(async ({ input }) => {
      return uncertaintyQuantificationService.makeRobustDecision(
        input.alternatives,
        input.scenarios,
        input.method
      );
    }),
});
