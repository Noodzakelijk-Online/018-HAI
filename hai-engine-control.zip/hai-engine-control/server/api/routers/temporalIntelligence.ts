import { z } from "zod";
import { protectedProcedure, router } from "../../_core/trpc";
import { temporalIntelligenceService } from "../../services/TemporalIntelligenceService";

export const temporalIntelligenceRouter = router({
  /**
   * 21. Time-series anomaly detection
   */
  detectAnomalies: protectedProcedure
    .input(
      z.object({
        lookbackDays: z.number().optional().default(30),
      })
    )
    .query(async ({ input, ctx }) => {
      return temporalIntelligenceService.detectAnomalies(
        ctx.user.id,
        input.lookbackDays
      );
    }),

  /**
   * 22. Optimal timing prediction
   */
  predictOptimalTiming: protectedProcedure
    .input(
      z.object({
        activityType: z.string(),
      })
    )
    .query(async ({ input, ctx }) => {
      return temporalIntelligenceService.predictOptimalTiming(
        input.activityType,
        ctx.user.id
      );
    }),

  /**
   * 23. Deadline propagation
   */
  propagateDeadlines: protectedProcedure
    .input(
      z.object({
        activityId: z.number(),
        deadline: z.date(),
        dependencies: z.array(
          z.object({
            activityId: z.number(),
            estimatedDuration: z.number(),
          })
        ),
      })
    )
    .mutation(async ({ input }) => {
      return temporalIntelligenceService.propagateDeadlines(
        input.activityId,
        input.deadline,
        input.dependencies
      );
    }),

  /**
   * 24. Time zone intelligence
   */
  optimizeTimeZone: protectedProcedure
    .input(
      z.object({
        recipient: z.string(),
        recipientTimezone: z.string(),
        activityType: z.string(),
      })
    )
    .query(async ({ input }) => {
      return temporalIntelligenceService.optimizeTimeZone(
        input.recipient,
        input.recipientTimezone,
        input.activityType
      );
    }),

  /**
   * 25. Seasonal pattern recognition
   */
  recognizeSeasonalPatterns: protectedProcedure
    .input(
      z.object({
        activityType: z.string(),
      })
    )
    .query(async ({ input, ctx }) => {
      return temporalIntelligenceService.recognizeSeasonalPatterns(
        ctx.user.id,
        input.activityType
      );
    }),

  /**
   * 26. Activity velocity tracking
   */
  trackVelocity: protectedProcedure
    .input(
      z.object({
        activityType: z.string(),
      })
    )
    .query(async ({ input, ctx }) => {
      return temporalIntelligenceService.trackVelocity(
        input.activityType,
        ctx.user.id
      );
    }),

  /**
   * 27. Lead time optimization
   */
  optimizeLeadTime: protectedProcedure
    .input(
      z.object({
        activityType: z.string(),
      })
    )
    .query(async ({ input, ctx }) => {
      return temporalIntelligenceService.optimizeLeadTime(
        input.activityType,
        ctx.user.id
      );
    }),

  /**
   * 28. Temporal clustering
   */
  clusterTemporally: protectedProcedure.query(async ({ ctx }) => {
    return temporalIntelligenceService.clusterTemporally(ctx.user.id);
  }),

  /**
   * 29. Time budget allocation
   */
  allocateTimeBudget: protectedProcedure
    .input(
      z.object({
        period: z.enum(["day", "week", "month"]),
      })
    )
    .query(async ({ input, ctx }) => {
      return temporalIntelligenceService.allocateTimeBudget(
        ctx.user.id,
        input.period
      );
    }),

  /**
   * 30. Historical comparison
   */
  compareHistorical: protectedProcedure
    .input(
      z.object({
        metric: z.string(),
        currentPeriodDays: z.number().optional().default(7),
      })
    )
    .query(async ({ input, ctx }) => {
      return temporalIntelligenceService.compareHistorical(
        ctx.user.id,
        input.metric,
        input.currentPeriodDays
      );
    }),
});
