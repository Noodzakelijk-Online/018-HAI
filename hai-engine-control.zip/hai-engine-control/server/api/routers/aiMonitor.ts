/**
 * AI Monitor tRPC Router
 * 
 * Provides endpoints for real-time AI health monitoring and compliance tracking
 */

import { z } from 'zod';
import { router, publicProcedure, protectedProcedure } from '../../_core/trpc';
import {
  getAllServiceHealth,
  getServiceHealth,
  getPerformanceMetrics,
  getReliabilityIndicators,
  getComplianceReport,
  getRealtimeActivity,
  getDashboardData,
  getServiceDefinitions,
  recordActivity,
  recordAuditEvent,
  recordError,
} from '../../services/aiHealthMonitor';
import { aiAlertingService } from '../../services/aiAlertingService';
import { aiMetricsHistoryService } from '../../services/aiMetricsHistoryService';

export const aiMonitorRouter = router({
  /**
   * Get aggregated dashboard data (all metrics in one call)
   */
  getDashboard: publicProcedure.query(async () => {
    return getDashboardData();
  }),

  /**
   * Get health status for all AI services
   */
  getAllServiceHealth: publicProcedure.query(async () => {
    return getAllServiceHealth();
  }),

  /**
   * Get health status for a specific service
   */
  getServiceHealth: publicProcedure
    .input(z.object({ serviceId: z.string() }))
    .query(async ({ input }) => {
      return getServiceHealth(input.serviceId);
    }),

  /**
   * Get service definitions (list of all AI services)
   */
  getServiceDefinitions: publicProcedure.query(() => {
    return getServiceDefinitions();
  }),

  /**
   * Get overall performance metrics
   */
  getPerformanceMetrics: publicProcedure.query(async () => {
    return getPerformanceMetrics();
  }),

  /**
   * Get reliability indicators
   */
  getReliabilityIndicators: publicProcedure.query(async () => {
    return getReliabilityIndicators();
  }),

  /**
   * Get compliance report
   */
  getComplianceReport: publicProcedure.query(async () => {
    return getComplianceReport();
  }),

  /**
   * Get real-time activity feed
   */
  getRealtimeActivity: publicProcedure
    .input(z.object({ limit: z.number().min(1).max(100).optional().default(20) }))
    .query(async ({ input }) => {
      return getRealtimeActivity(input.limit);
    }),

  /**
   * Record an AI activity (for internal use)
   */
  recordActivity: protectedProcedure
    .input(z.object({
      service: z.string(),
      action: z.string(),
      status: z.enum(['success', 'failure', 'pending']),
      duration: z.number(),
      details: z.string(),
      confidence: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      recordActivity({
        timestamp: new Date(),
        ...input,
      });
      return { success: true };
    }),

  /**
   * Record an audit event (for internal use)
   */
  recordAuditEvent: protectedProcedure
    .input(z.object({
      service: z.string(),
      action: z.string(),
      decision: z.string(),
      explanation: z.string(),
      confidence: z.number(),
      overridden: z.boolean().optional().default(false),
    }))
    .mutation(async ({ input, ctx }) => {
      recordAuditEvent({
        timestamp: new Date(),
        userId: ctx.user?.id,
        ...input,
      });
      return { success: true };
    }),

  /**
   * Record an error (for internal use)
   */
  recordError: protectedProcedure
    .input(z.object({
      service: z.string(),
      error: z.string(),
    }))
    .mutation(async ({ input }) => {
      recordError(input.service, input.error);
      return { success: true };
    }),

  // ============================================================================
  // Alert Management Endpoints
  // ============================================================================

  /**
   * Get all alert rules
   */
  getAlertRules: publicProcedure.query(async () => {
    return aiAlertingService.getAlertRules();
  }),

  /**
   * Create a new alert rule
   */
  createAlertRule: protectedProcedure
    .input(z.object({
      ruleId: z.string(),
      name: z.string(),
      serviceId: z.string(),
      condition: z.string(),
      threshold: z.number(),
      severity: z.enum(['info', 'warning', 'error', 'critical']),
      channels: z.array(z.string()),
      enabled: z.boolean().default(true),
      cooldownMinutes: z.number().default(15),
    }))
    .mutation(async ({ input }) => {
      return aiAlertingService.createAlertRule(input);
    }),

  /**
   * Update an alert rule
   */
  updateAlertRule: protectedProcedure
    .input(z.object({
      ruleId: z.string(),
      updates: z.object({
        name: z.string().optional(),
        serviceId: z.string().optional(),
        condition: z.string().optional(),
        threshold: z.number().optional(),
        severity: z.enum(['info', 'warning', 'error', 'critical']).optional(),
        channels: z.array(z.string()).optional(),
        enabled: z.boolean().optional(),
        cooldownMinutes: z.number().optional(),
      }),
    }))
    .mutation(async ({ input }) => {
      return aiAlertingService.updateAlertRule(input.ruleId, input.updates);
    }),

  /**
   * Delete an alert rule
   */
  deleteAlertRule: protectedProcedure
    .input(z.object({ ruleId: z.string() }))
    .mutation(async ({ input }) => {
      return aiAlertingService.deleteAlertRule(input.ruleId);
    }),

  /**
   * Get recent alerts
   */
  getRecentAlerts: publicProcedure
    .input(z.object({
      limit: z.number().min(1).max(200).optional().default(50),
      includeAcknowledged: z.boolean().optional().default(true),
    }))
    .query(async ({ input }) => {
      return aiAlertingService.getRecentAlerts(input.limit, input.includeAcknowledged);
    }),

  /**
   * Get unacknowledged alert count
   */
  getUnacknowledgedAlertCount: publicProcedure.query(async () => {
    return aiAlertingService.getUnacknowledgedCount();
  }),

  /**
   * Acknowledge an alert
   */
  acknowledgeAlert: protectedProcedure
    .input(z.object({ alertId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const acknowledgedBy = ctx.user?.name || ctx.user?.email || 'Unknown';
      return aiAlertingService.acknowledgeAlert(input.alertId, acknowledgedBy);
    }),

  /**
   * Acknowledge all alerts
   */
  acknowledgeAllAlerts: protectedProcedure
    .mutation(async ({ ctx }) => {
      const acknowledgedBy = ctx.user?.name || ctx.user?.email || 'Unknown';
      return aiAlertingService.acknowledgeAllAlerts(acknowledgedBy);
    }),

  /**
   * Get alert statistics
   */
  getAlertStats: publicProcedure.query(async () => {
    return aiAlertingService.getAlertStats();
  }),

  // ============================================================================
  // Historical Metrics Endpoints
  // ============================================================================

  /**
   * Get historical metrics for a service
   */
  getServiceHistory: publicProcedure
    .input(z.object({
      serviceId: z.string(),
      startTime: z.string().transform(s => new Date(s)),
      endTime: z.string().transform(s => new Date(s)),
      aggregationType: z.enum(['raw', 'minute', 'hour', 'day']).optional().default('raw'),
      limit: z.number().min(1).max(10000).optional().default(1000),
    }))
    .query(async ({ input }) => {
      return aiMetricsHistoryService.getServiceHistory(
        input.serviceId,
        input.startTime,
        input.endTime,
        input.aggregationType,
        input.limit
      );
    }),

  /**
   * Get trend data for a service
   */
  getServiceTrend: publicProcedure
    .input(z.object({
      serviceId: z.string(),
      hours: z.number().min(1).max(168).optional().default(24),
    }))
    .query(async ({ input }) => {
      return aiMetricsHistoryService.getServiceTrend(input.serviceId, input.hours);
    }),

  /**
   * Get aggregated metrics for all services
   */
  getAggregatedMetrics: publicProcedure
    .input(z.object({
      hours: z.number().min(1).max(720).optional().default(24),
      groupBy: z.enum(['hour', 'day']).optional().default('hour'),
    }))
    .query(async ({ input }) => {
      return aiMetricsHistoryService.getAggregatedMetrics(input.hours, input.groupBy);
    }),

  /**
   * Get system health trend
   */
  getSystemHealthTrend: publicProcedure
    .input(z.object({
      hours: z.number().min(1).max(168).optional().default(24),
    }))
    .query(async ({ input }) => {
      return aiMetricsHistoryService.getSystemHealthTrend(input.hours);
    }),

  /**
   * Get metrics summary (storage stats)
   */
  getMetricsSummary: publicProcedure.query(async () => {
    return aiMetricsHistoryService.getMetricsSummary();
  }),

  /**
   * Start metrics collection (admin only)
   */
  startMetricsCollection: protectedProcedure
    .input(z.object({
      intervalMs: z.number().min(10000).max(300000).optional().default(60000),
    }))
    .mutation(async ({ input }) => {
      aiMetricsHistoryService.startCollection(input.intervalMs);
      return { success: true, message: `Started metrics collection every ${input.intervalMs}ms` };
    }),

  /**
   * Stop metrics collection (admin only)
   */
  stopMetricsCollection: protectedProcedure
    .mutation(async () => {
      aiMetricsHistoryService.stopCollection();
      return { success: true, message: 'Stopped metrics collection' };
    }),

  /**
   * Manually trigger metrics collection
   */
  collectMetricsNow: protectedProcedure
    .mutation(async () => {
      await aiMetricsHistoryService.collectMetrics();
      return { success: true, message: 'Metrics collected' };
    }),
});
