/**
 * Input API Router
 * 
 * Exposes the Universal Input Processing system via tRPC
 */

import { z } from 'zod';
import { router, publicProcedure, protectedProcedure } from '../../_core/trpc';
import { inputPipeline } from '../../services/input/InputPipeline';
import { InputSource, InputFormat } from '../../services/input/UniversalInputProcessor';

// ============================================================================
// INPUT SCHEMAS
// ============================================================================

const RawInputSchema = z.object({
  id: z.string().optional(),
  source: z.string(),
  format: z.string(),
  rawData: z.any(),
  metadata: z.record(z.any()).optional(),
});

const ConnectorConfigSchema = z.object({
  id: z.string(),
  type: z.string(),
  name: z.string(),
  enabled: z.boolean().default(true),
  credentials: z.object({
    type: z.enum(['oauth2', 'api_key', 'basic', 'bearer', 'custom']),
    accessToken: z.string().optional(),
    refreshToken: z.string().optional(),
    apiKey: z.string().optional(),
    username: z.string().optional(),
    password: z.string().optional(),
    expiresAt: z.date().optional(),
    scopes: z.array(z.string()).optional(),
    customData: z.record(z.any()).optional(),
  }).optional(),
  settings: z.object({
    syncInterval: z.number().optional(),
    batchSize: z.number().optional(),
    filters: z.record(z.any()).optional(),
    retryPolicy: z.object({
      maxRetries: z.number(),
      initialDelay: z.number(),
      maxDelay: z.number(),
      backoffMultiplier: z.number(),
    }).optional(),
  }).default({}),
  polling: z.object({
    enabled: z.boolean(),
    interval: z.number(),
    lastPoll: z.date().optional(),
    cursor: z.string().optional(),
  }).optional(),
  webhook: z.object({
    enabled: z.boolean(),
    url: z.string(),
    secret: z.string().optional(),
    events: z.array(z.string()),
  }).optional(),
});

// ============================================================================
// ROUTER
// ============================================================================

export const inputRouter = router({
  // ---------------------------------------------------------------------------
  // INPUT PROCESSING
  // ---------------------------------------------------------------------------

  /**
   * Process a raw input through the pipeline
   */
  process: protectedProcedure
    .input(z.object({
      raw: RawInputSchema,
      householdId: z.number().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const rawInput = {
        id: input.raw.id || `input_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        source: input.raw.source as InputSource,
        format: input.raw.format as InputFormat,
        rawData: input.raw.rawData,
        metadata: {
          ...input.raw.metadata,
          receivedAt: new Date(),
          userId: ctx.user?.id,
        },
      };

      const result = await inputPipeline.process(rawInput, input.householdId);

      return {
        success: result.pipeline.errors.length === 0,
        pipelineId: result.pipeline.id,
        confidence: result.pipeline.confidence,
        intent: {
          primary: result.intent.primary,
          confidence: result.intent.primaryConfidence,
          domain: result.intent.domain.primary,
        },
        entities: {
          peopleCount: result.entities.people.length,
          datesCount: result.entities.dates.length,
          moneyCount: result.entities.money.length,
          tasksCount: result.entities.tasks.length,
          eventsCount: result.entities.events.length,
        },
        processing: {
          duration: result.pipeline.completedAt 
            ? result.pipeline.completedAt.getTime() - result.pipeline.startedAt.getTime()
            : 0,
          stages: result.pipeline.stages.length,
          errors: result.pipeline.errors.length,
        },
      };
    }),

  /**
   * Process text input (simplified)
   */
  processText: protectedProcedure
    .input(z.object({
      text: z.string(),
      source: z.string().default('manual'),
      householdId: z.number().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const rawInput = {
        id: `text_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        source: input.source as InputSource,
        format: 'text' as InputFormat,
        rawData: input.text,
        metadata: {
          receivedAt: new Date(),
          userId: ctx.user?.id,
        },
      };

      const result = await inputPipeline.process(rawInput, input.householdId);

      return {
        success: result.pipeline.errors.length === 0,
        pipelineId: result.pipeline.id,
        normalized: result.normalized.text,
        intent: result.intent,
        entities: result.entities,
        context: result.context,
        confidence: result.pipeline.confidence,
      };
    }),

  /**
   * Process email input
   */
  processEmail: protectedProcedure
    .input(z.object({
      from: z.string(),
      to: z.array(z.string()),
      cc: z.array(z.string()).optional(),
      subject: z.string(),
      body: z.string(),
      html: z.string().optional(),
      attachments: z.array(z.object({
        filename: z.string(),
        contentType: z.string(),
        size: z.number(),
        url: z.string().optional(),
      })).optional(),
      receivedAt: z.date().optional(),
      householdId: z.number().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const rawInput = {
        id: `email_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        source: 'email' as InputSource,
        format: 'email' as InputFormat,
        rawData: {
          from: input.from,
          to: input.to,
          cc: input.cc,
          subject: input.subject,
          body: input.body,
          html: input.html,
          attachments: input.attachments,
        },
        metadata: {
          receivedAt: input.receivedAt || new Date(),
          userId: ctx.user?.id,
        },
      };

      const result = await inputPipeline.process(rawInput, input.householdId);

      return {
        success: result.pipeline.errors.length === 0,
        pipelineId: result.pipeline.id,
        intent: result.intent,
        entities: result.entities,
        context: result.context,
        suggestedActions: result.intent.automation.suggestedAutomations,
        confidence: result.pipeline.confidence,
      };
    }),

  /**
   * Process webhook input
   */
  processWebhook: publicProcedure
    .input(z.object({
      source: z.string(),
      event: z.string(),
      data: z.any(),
      signature: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const rawInput = {
        id: `webhook_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        source: 'webhook' as InputSource,
        format: 'json' as InputFormat,
        rawData: {
          source: input.source,
          event: input.event,
          data: input.data,
        },
        metadata: {
          receivedAt: new Date(),
          signature: input.signature,
        },
      };

      const result = await inputPipeline.process(rawInput);

      return {
        success: result.pipeline.errors.length === 0,
        pipelineId: result.pipeline.id,
        processed: true,
      };
    }),

  // ---------------------------------------------------------------------------
  // CONNECTOR MANAGEMENT
  // ---------------------------------------------------------------------------

  /**
   * Add a new connector
   */
  addConnector: protectedProcedure
    .input(ConnectorConfigSchema)
    .mutation(async ({ input }) => {
      const connector = inputPipeline.addConnector(input as any);
      
      if (!connector) {
        return {
          success: false,
          error: `Unknown connector type: ${input.type}`,
        };
      }

      return {
        success: true,
        connectorId: input.id,
        status: connector.getStatus(),
      };
    }),

  /**
   * Remove a connector
   */
  removeConnector: protectedProcedure
    .input(z.object({
      connectorId: z.string(),
    }))
    .mutation(async ({ input }) => {
      await inputPipeline.removeConnector(input.connectorId);
      return { success: true };
    }),

  /**
   * Get connector status
   */
  getConnectorStatus: protectedProcedure
    .input(z.object({
      connectorId: z.string(),
    }))
    .query(async ({ input }) => {
      const connector = inputPipeline.getConnector(input.connectorId);
      
      if (!connector) {
        return null;
      }

      return connector.getStatus();
    }),

  /**
   * Start all connectors
   */
  startConnectors: protectedProcedure
    .mutation(async () => {
      inputPipeline.startConnectors();
      return { success: true };
    }),

  /**
   * Stop all connectors
   */
  stopConnectors: protectedProcedure
    .mutation(async () => {
      inputPipeline.stopConnectors();
      return { success: true };
    }),

  // ---------------------------------------------------------------------------
  // AUDIT & STATISTICS
  // ---------------------------------------------------------------------------

  /**
   * Get processing statistics
   */
  getStatistics: protectedProcedure
    .query(async () => {
      return inputPipeline.getStatistics();
    }),

  /**
   * Get audit log
   */
  getAuditLog: protectedProcedure
    .input(z.object({
      limit: z.number().min(1).max(1000).default(100),
    }))
    .query(async ({ input }) => {
      const log = inputPipeline.getAuditLog(input.limit);
      
      return log.map(entry => ({
        pipelineId: entry.pipeline.id,
        source: entry.raw.source,
        format: entry.raw.format,
        intent: entry.intent.primary,
        domain: entry.intent.domain.primary,
        confidence: entry.pipeline.confidence,
        processedAt: entry.pipeline.startedAt,
        duration: entry.pipeline.completedAt 
          ? entry.pipeline.completedAt.getTime() - entry.pipeline.startedAt.getTime()
          : 0,
        errors: entry.pipeline.errors.length,
      }));
    }),

  /**
   * Search audit log
   */
  searchAuditLog: protectedProcedure
    .input(z.object({
      source: z.string().optional(),
      intent: z.string().optional(),
      domain: z.string().optional(),
      startDate: z.date().optional(),
      endDate: z.date().optional(),
    }))
    .query(async ({ input }) => {
      const results = inputPipeline.searchAuditLog({
        source: input.source as InputSource | undefined,
        intent: input.intent,
        domain: input.domain,
        startDate: input.startDate,
        endDate: input.endDate,
      });

      return results.map(entry => ({
        pipelineId: entry.pipeline.id,
        source: entry.raw.source,
        intent: entry.intent.primary,
        domain: entry.intent.domain.primary,
        confidence: entry.pipeline.confidence,
        processedAt: entry.pipeline.startedAt,
      }));
    }),

  /**
   * Get queue status
   */
  getQueueStatus: protectedProcedure
    .query(async () => {
      return {
        queueLength: inputPipeline.getQueueLength(),
        activeProcessing: inputPipeline.getActiveProcessingCount(),
      };
    }),

  // ---------------------------------------------------------------------------
  // SUPPORTED SOURCES & FORMATS
  // ---------------------------------------------------------------------------

  /**
   * Get supported input sources
   */
  getSupportedSources: publicProcedure
    .query(async () => {
      return {
        email: ['gmail', 'outlook', 'yahoo', 'imap', 'smtp'],
        messaging: ['sms', 'sms_twilio', 'whatsapp', 'telegram', 'slack', 'discord'],
        calendar: ['google_calendar', 'outlook_calendar', 'apple_calendar', 'ical'],
        financial: ['plaid', 'stripe', 'bank_api', 'csv_import'],
        smartHome: ['smartthings', 'home_assistant', 'alexa', 'google_home', 'homekit'],
        health: ['apple_health', 'fitbit', 'garmin', 'oura'],
        location: ['life360', 'gps', 'geofence'],
        other: ['webhook', 'api', 'manual', 'voice', 'image', 'document'],
      };
    }),

  /**
   * Get supported input formats
   */
  getSupportedFormats: publicProcedure
    .query(async () => {
      return {
        text: ['text', 'markdown', 'html'],
        structured: ['json', 'xml', 'yaml', 'csv'],
        document: ['pdf', 'docx', 'xlsx', 'pptx'],
        media: ['image', 'audio', 'video'],
        communication: ['email', 'sms', 'chat'],
        financial: ['ofx', 'qfx', 'qif'],
        calendar: ['ical', 'vcf'],
      };
    }),
});
