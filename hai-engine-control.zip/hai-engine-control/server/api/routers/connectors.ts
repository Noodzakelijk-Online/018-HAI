import { z } from "zod";
import { protectedProcedure, router } from "../../_core/trpc";
import { checkServiceHealth, getServiceHealthStats } from "../../services/healthCheckService";
import {
  createConnector,
  getConnectorsByUserId,
  getConnectorsByHouseholdId,
  getConnectorById,
  updateConnector,
  deleteConnector,
  updateConnectorOrder,
} from "../../db";
import { storagePut } from "../../storage";
import { trackConnectorUsage, getConnectorAnalytics, getAllConnectorsAnalytics, getConnectorLogs } from "../../services/analyticsTracker";
import { ConnectorRegistry } from "../../services/connectors/ConnectorRegistry";
import { EmailConnector } from "../../services/connectors/EmailConnector";
import { CalendarConnector } from "../../services/connectors/CalendarConnector";
import { SlackConnector } from "../../services/connectors/SlackConnector";
import { cacheService, CacheKeys, CacheTTL } from "../../services/cacheService";

/**
 * Unified Connectors Router
 * Handles both:
 * 1. User-managed services (custom URLs, health monitoring, drag-drop)
 * 2. HAI runtime connectors (OAuth integrations, send emails, create events)
 */
export const connectorsRouter = router({
  // ============================================================================
  // USER SERVICE MANAGEMENT (formerly ServiceHub)
  // ============================================================================

  /**
   * List all connectors for a household (cached for 2 minutes)
   */
  list: protectedProcedure
    .input(
      z.object({
        householdId: z.number().int().positive(),
      })
    )
    .query(async ({ input, ctx }) => {
      const cacheKey = CacheKeys.connectorList(input.householdId);
      return cacheService.getOrFetch(
        cacheKey,
        () => getConnectorsByHouseholdId(input.householdId),
        { ttl: CacheTTL.MEDIUM, staleWhileRevalidate: true }
      );
    }),

  /**
   * Get a single connector by ID
   */
  get: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input, ctx }) => {
      const connector = await getConnectorById(input.id);
      if (!connector || connector.userId !== ctx.user.id) {
        throw new Error("Connector not found or access denied");
      }
      return connector;
    }),

  /**
   * Create a new user service/connector
   */
  create: protectedProcedure
    .input(
      z.object({
        name: z.string().min(1, "Name is required"),
        connectorType: z.string(), // e.g., "custom_service", "gmail", "calendar", "trello"
        householdId: z.number().int().positive(),
        url: z.string().url("Valid URL is required").optional(),
        imageUrl: z.string().optional(),
        status: z.enum(["connected", "disconnected", "error", "pending_auth"]).default("pending_auth"),
        credentials: z.string().optional(), // Encrypted credentials
        metadata: z.any().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Get current max order position for this household
      const existingServices = await getConnectorsByHouseholdId(input.householdId);
      const maxOrder = existingServices.length > 0 
        ? Math.max(...existingServices.map(s => s.orderPosition || 0))
        : -1;

      const connectorId = await createConnector({
        userId: ctx.user.id,
        householdId: input.householdId,
        name: input.name,
        connectorType: input.connectorType,
        url: input.url || null,
        imageUrl: input.imageUrl || null,
        status: input.status,
        credentials: input.credentials || null,
        metadata: input.metadata || null,
        orderPosition: maxOrder + 1,
      });

      // Invalidate connector cache for this household
      cacheService.delete(CacheKeys.connectorList(input.householdId));

      return { id: connectorId, success: true };
    }),

  /**
   * Update an existing connector
   */
  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1).optional(),
        url: z.string().url().optional(),
        imageUrl: z.string().optional(),
        status: z.enum(["connected", "disconnected", "error", "pending_auth"]).optional(),
        credentials: z.string().optional(),
        metadata: z.any().optional(),
        alertsEnabled: z.boolean().optional(),
        uptimeThreshold: z.number().min(0).max(100).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { id, ...updates } = input;
      
      // Verify ownership
      const connector = await getConnectorById(id);
      if (!connector || connector.userId !== ctx.user.id) {
        throw new Error("Connector not found or access denied");
      }

      await updateConnector(id, updates);
      
      // Invalidate connector cache for this household
      cacheService.delete(CacheKeys.connectorList(connector.householdId));
      
      return { success: true };
    }),

  /**
   * Delete a connector
   */
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      // Verify ownership
      const connector = await getConnectorById(input.id);
      if (!connector || connector.userId !== ctx.user.id) {
        throw new Error("Connector not found or access denied");
      }

      await deleteConnector(input.id);
      
      // Invalidate connector cache for this household
      cacheService.delete(CacheKeys.connectorList(connector.householdId));
      
      return { success: true };
    }),

  /**
   * Update connector order (drag-drop)
   */
  updateOrder: protectedProcedure
    .input(
      z.object({
        orderedIds: z.array(z.number()),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Verify all connectors belong to the user
      const connectors = await getConnectorsByUserId(ctx.user.id);
      const userConnectorIds = new Set(connectors.map(c => c.id));
      
      for (const id of input.orderedIds) {
        if (!userConnectorIds.has(id)) {
          throw new Error("Invalid connector ID in order list");
        }
      }

      await updateConnectorOrder(ctx.user.id, input.orderedIds);
      return { success: true };
    }),

  /**
   * Upload custom connector image
   */
  uploadImage: protectedProcedure
    .input(
      z.object({
        connectorId: z.number(),
        imageData: z.string(), // Base64 encoded image
        mimeType: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Verify ownership
      const connector = await getConnectorById(input.connectorId);
      if (!connector || connector.userId !== ctx.user.id) {
        throw new Error("Connector not found or access denied");
      }

      // Decode base64 and upload to S3
      const buffer = Buffer.from(input.imageData, 'base64');
      const fileKey = `connector-images/${ctx.user.id}/${input.connectorId}-${Date.now()}.${input.mimeType.split('/')[1]}`;
      
      const { url } = await storagePut(fileKey, buffer, input.mimeType);

      // Update connector with new image URL
      await updateConnector(input.connectorId, { imageUrl: url });

      return { url, success: true };
    }),

  // ============================================================================
  // HEALTH MONITORING
  // ============================================================================

  /**
   * Check connector health immediately
   */
  checkHealth: protectedProcedure
    .input(z.object({ connectorId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      // Verify ownership
      const connector = await getConnectorById(input.connectorId);
      if (!connector || connector.userId !== ctx.user.id) {
        throw new Error("Connector not found or access denied");
      }

      if (!connector.url) {
        throw new Error("Connector does not have a URL to check");
      }

      const result = await checkServiceHealth(connector.id, connector.url);
      return result;
    }),

  /**
   * Get health statistics for a connector
   */
  getHealthStats: protectedProcedure
    .input(z.object({ connectorId: z.number() }))
    .query(async ({ ctx, input }) => {
      // Verify ownership
      const connector = await getConnectorById(input.connectorId);
      if (!connector || connector.userId !== ctx.user.id) {
        throw new Error("Connector not found or access denied");
      }

      const stats = await getServiceHealthStats(connector.id);
      return stats;
    }),

  // ============================================================================
  // RUNTIME CONNECTOR OPERATIONS (HAI integrations)
  // ============================================================================

  /**
   * Get connector statistics from registry
   */
  stats: protectedProcedure.query(() => {
    return ConnectorRegistry.getStats();
  }),

  /**
   * Register a runtime connector (Email, Calendar, Slack)
   */
  register: protectedProcedure
    .input(
      z.object({
        type: z.enum(['email', 'calendar', 'slack']),
        config: z.object({
          id: z.string(),
          name: z.string(),
          description: z.string(),
          authType: z.enum(['oauth2', 'api_key', 'bearer_token', 'basic_auth', 'none']),
          credentials: z.record(z.string(), z.string()).optional(),
          rateLimit: z.number().optional(),
          config: z.any().optional(),
        }),
      })
    )
    .mutation(({ input }) => {
      let connector;
      
      switch (input.type) {
        case 'email':
          connector = new EmailConnector(input.config as any);
          break;
        case 'calendar':
          connector = new CalendarConnector(input.config as any);
          break;
        case 'slack':
          connector = new SlackConnector(input.config as any);
          break;
        default:
          throw new Error(`Unknown connector type: ${input.type}`);
      }

      ConnectorRegistry.register(connector);
      
      return {
        success: true,
        connectorId: input.config.id,
      };
    }),

  /**
   * Unregister a runtime connector
   */
  unregister: protectedProcedure
    .input(z.object({ connectorId: z.string() }))
    .mutation(async ({ input }) => {
      await ConnectorRegistry.unregister(input.connectorId);
      return { success: true };
    }),

  /**
   * Connect a runtime connector
   */
  connect: protectedProcedure
    .input(z.object({ connectorId: z.string() }))
    .mutation(async ({ input }) => {
      await ConnectorRegistry.connect(input.connectorId);
      return { success: true };
    }),

  /**
   * Disconnect a runtime connector
   */
  disconnect: protectedProcedure
    .input(z.object({ connectorId: z.string() }))
    .mutation(async ({ input }) => {
      await ConnectorRegistry.disconnect(input.connectorId);
      return { success: true };
    }),

  /**
   * Health check for a runtime connector
   */
  healthCheckRuntime: protectedProcedure
    .input(z.object({ connectorId: z.string() }))
    .mutation(async ({ input }) => {
      const health = await ConnectorRegistry.healthCheck(input.connectorId);
      return health;
    }),

  /**
   * Health check for all runtime connectors
   */
  healthCheckAll: protectedProcedure.mutation(async () => {
    const results = await ConnectorRegistry.healthCheckAll();
    return Object.fromEntries(results);
  }),

  // ============================================================================
  // CONNECTOR-SPECIFIC OPERATIONS
  // ============================================================================

  /**
   * Email connector: send email
   */
  emailSend: protectedProcedure
    .input(
      z.object({
        connectorId: z.string(),
        to: z.array(z.string()),
        subject: z.string(),
        body: z.string(),
        html: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const connector = ConnectorRegistry.get(input.connectorId);
      if (!connector || !(connector instanceof EmailConnector)) {
        throw new Error('Email connector not found');
      }

      return await connector.send({
        to: input.to,
        subject: input.subject,
        body: input.body,
        html: input.html,
      });
    }),

  /**
   * Calendar connector: create event
   */
  calendarCreateEvent: protectedProcedure
    .input(
      z.object({
        connectorId: z.string(),
        title: z.string(),
        description: z.string().optional(),
        start: z.string(),
        end: z.string(),
        location: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const connector = ConnectorRegistry.get(input.connectorId);
      if (!connector || !(connector instanceof CalendarConnector)) {
        throw new Error('Calendar connector not found');
      }

      return await connector.createEvent({
        title: input.title,
        description: input.description,
        start: new Date(input.start),
        end: new Date(input.end),
        location: input.location,
      });
    }),

  /**
   * Slack connector: send message
   */
  slackSendMessage: protectedProcedure
    .input(
      z.object({
        connectorId: z.string(),
        channel: z.string(),
        text: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const connector = ConnectorRegistry.get(input.connectorId);
      if (!connector || !(connector instanceof SlackConnector)) {
        throw new Error('Slack connector not found');
      }

      return await connector.sendMessage({
        channel: input.channel,
        text: input.text,
      });
    }),

  // ============================================================================
  // OAUTH AUTHENTICATION (Mock for Development)
  // ============================================================================

  /**
   * Initiate OAuth flow for a connector
   */
  initiateOAuth: protectedProcedure
    .input(z.object({
      connectorId: z.number(),
    }))
    .mutation(async ({ input, ctx }) => {
      const connector = await getConnectorById(input.connectorId);
      
      if (!connector || connector.userId !== ctx.user.id) {
        throw new Error('Connector not found or access denied');
      }

      // For Google OAuth connectors (gmail, calendar), redirect to our OAuth endpoint
      if (connector.connectorType === 'gmail' || connector.connectorType === 'calendar') {
        // Build authorization URL that points to our Express route
        const protocol = process.env.NODE_ENV === 'production' ? 'https' : 'http';
        const host = process.env.HOST || 'localhost:3000';
        const authUrl = `${protocol}://${host}/api/oauth/google/authorize?connectorId=${connector.id}`;
        
        return {
          authUrl,
          state: connector.id.toString(),
        };
      }
      
      // For other connectors, use mock OAuth
      const { getMockAuthorizationUrl } = await import('../../services/mockOAuthService');
      const state = `${connector.id}_${Date.now()}_${Math.random().toString(36).substring(7)}`;
      const authUrl = getMockAuthorizationUrl(connector.connectorType, state);
      
      return {
        authUrl,
        state,
      };
    }),

  /**
   * Complete OAuth flow (mock callback)
   */
  completeOAuth: protectedProcedure
    .input(z.object({
      connectorId: z.number(),
      code: z.string(),
      state: z.string(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { exchangeMockAuthorizationCode, encryptCredentials } = await import('../../services/mockOAuthService');
      const connector = await getConnectorById(input.connectorId);
      
      if (!connector || connector.userId !== ctx.user.id) {
        throw new Error('Connector not found or access denied');
      }

      // Exchange code for token
      const token = await exchangeMockAuthorizationCode(input.code, connector.connectorType);
      
      // Encrypt and store credentials
      const encryptedCredentials = encryptCredentials(token);
      
      // Update connector with credentials
      await updateConnector(input.connectorId, {
        credentials: encryptedCredentials,
        status: 'connected',
        lastSync: new Date(),
      });

      return {
        success: true,
        message: 'OAuth authentication successful',
      };
    }),

  /**
   * Disconnect OAuth connector
   */
  disconnectOAuth: protectedProcedure
    .input(z.object({
      connectorId: z.number(),
    }))
    .mutation(async ({ input, ctx }) => {
      const connector = await getConnectorById(input.connectorId);
      
      if (!connector || connector.userId !== ctx.user.id) {
        throw new Error('Connector not found or access denied');
      }

      // Clear credentials
      await updateConnector(input.connectorId, {
        credentials: null,
        status: 'pending_auth',
      });

      return {
        success: true,
        message: 'Connector disconnected',
      };
    }),

  // ============================================================================
  // GMAIL OPERATIONS (Mock)
  // ============================================================================

  /**
   * Send email via Gmail connector
   */
  sendEmail: protectedProcedure
    .input(z.object({
      connectorId: z.number(),
      to: z.array(z.string().email()),
      subject: z.string(),
      body: z.string(),
      html: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { mockGmailSendEmail, decryptCredentials, isTokenExpired } = await import('../../services/mockOAuthService');
      const connector = await getConnectorById(input.connectorId);
      
      if (!connector || connector.userId !== ctx.user.id) {
        throw new Error('Connector not found or access denied');
      }

      if (connector.connectorType !== 'gmail') {
        throw new Error('Not a Gmail connector');
      }

      if (!connector.credentials) {
        throw new Error('Connector not authenticated. Please connect first.');
      }

      // Decrypt credentials
      const token = decryptCredentials(connector.credentials);
      
      // Check if token is expired (in real implementation, refresh if needed)
      if (isTokenExpired(new Date(token.expiresAt))) {
        throw new Error('Token expired. Please reconnect.');
      }

      // Track analytics
      const startTime = Date.now();
      try {
        // Send email via mock Gmail API
        const result = await mockGmailSendEmail(
          token.accessToken,
          input.to,
          input.subject,
          input.body,
          input.html
        );

        // Update last sync
        await updateConnector(input.connectorId, {
          lastSync: new Date(),
        });

        // Track success
        await trackConnectorUsage({
          connectorId: input.connectorId,
          action: "send_email",
          status: "success",
          duration: Date.now() - startTime,
          requestData: { to: input.to, subject: input.subject, bodyLength: input.body.length },
          responseData: { messageId: result.messageId, success: result.success },
        });

        return result;
      } catch (error: any) {
        // Track failure
        await trackConnectorUsage({
          connectorId: input.connectorId,
          action: "send_email",
          status: "failed",
          duration: Date.now() - startTime,
          errorMessage: error.message,
          requestData: { to: input.to, subject: input.subject, bodyLength: input.body.length },
        });
        throw error;
      }
    }),

  // ============================================================================
  // CALENDAR OPERATIONS (Mock)
  // ============================================================================

  /**
   * Create calendar event via Calendar connector
   */
  /**
   * Get connector health statistics
   */
  getHealthStatistics: protectedProcedure.query(async () => {
    const { ConnectorHealthMonitor } = await import('../../services/connectorHealthMonitor');
    return await ConnectorHealthMonitor.getHealthStats();
  }),

  /**
   * Manually trigger health check for a connector
   */
  checkConnectorHealth: protectedProcedure
    .input(z.object({ connectorId: z.number() }))
    .mutation(async ({ input }) => {
      const { ConnectorHealthMonitor } = await import('../../services/connectorHealthMonitor');
      return await ConnectorHealthMonitor.checkConnectorHealth(input.connectorId);
    }),

  /**
   * Manually trigger health check for all connectors
   */
  checkAllConnectorsHealth: protectedProcedure.mutation(async () => {
    const { ConnectorHealthMonitor } = await import('../../services/connectorHealthMonitor');
    await ConnectorHealthMonitor.checkAllConnectors();
    return { success: true };
  }),

  createCalendarEvent: protectedProcedure
    .input(z.object({
      connectorId: z.number(),
      title: z.string(),
      start: z.date(),
      end: z.date(),
      description: z.string().optional(),
      location: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { mockCalendarCreateEvent, decryptCredentials, isTokenExpired } = await import('../../services/mockOAuthService');
      const connector = await getConnectorById(input.connectorId);
      
      if (!connector || connector.userId !== ctx.user.id) {
        throw new Error('Connector not found or access denied');
      }

      if (connector.connectorType !== 'calendar') {
        throw new Error('Not a Calendar connector');
      }

      if (!connector.credentials) {
        throw new Error('Connector not authenticated. Please connect first.');
      }

      // Decrypt credentials
      const token = decryptCredentials(connector.credentials);
      
      // Check if token is expired
      if (isTokenExpired(new Date(token.expiresAt))) {
        throw new Error('Token expired. Please reconnect.');
      }

      // Track analytics
      const startTime = Date.now();
      try {
        // Create event via mock Calendar API
        const result = await mockCalendarCreateEvent(
          token.accessToken,
          input.title,
          input.start,
          input.end,
          input.description,
          input.location
        );

        // Update last sync
        await updateConnector(input.connectorId, {
          lastSync: new Date(),
        });

        // Track success
        await trackConnectorUsage({
          connectorId: input.connectorId,
          action: "create_event",
          status: "success",
          duration: Date.now() - startTime,
          requestData: { title: input.title, start: input.start, end: input.end, location: input.location },
          responseData: { eventId: result.eventId, eventUrl: result.eventUrl, success: result.success },
        });

        return result;
      } catch (error: any) {
        // Track failure
        await trackConnectorUsage({
          connectorId: input.connectorId,
          action: "create_event",
          status: "failed",
          duration: Date.now() - startTime,
          errorMessage: error.message,
          requestData: { title: input.title, start: input.start, end: input.end, location: input.location },
        });
        throw error;
      }
    }),

  // ============================================================================
  // ANALYTICS
  // ============================================================================

  /**
   * Get analytics for a specific connector
   */
  getAnalytics: protectedProcedure
    .input(z.object({
      connectorId: z.number(),
      days: z.number().default(30),
    }))
    .query(async ({ input, ctx }) => {
      // Verify ownership
      const connector = await getConnectorById(input.connectorId);
      if (!connector || connector.userId !== ctx.user.id) {
        throw new Error('Connector not found or access denied');
      }

      return await getConnectorAnalytics(input.connectorId, input.days);
    }),

  /**
   * Get overall analytics for all connectors
   */
  getAllAnalytics: protectedProcedure
    .input(z.object({
      days: z.number().default(30),
    }))
    .query(async ({ input }) => {
      return await getAllConnectorsAnalytics(input.days);
    }),

  /**
   * Get detailed logs with filtering
   */
  getLogs: protectedProcedure
    .input(z.object({
      connectorId: z.number().optional(),
      action: z.string().optional(),
      status: z.enum(["success", "failed"]).optional(),
      searchQuery: z.string().optional(),
      limit: z.number().default(50),
      offset: z.number().default(0),
    }))
    .query(async ({ input }) => {
      return await getConnectorLogs(input);
    }),
});
