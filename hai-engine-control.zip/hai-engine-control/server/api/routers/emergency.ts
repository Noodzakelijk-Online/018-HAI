/**
 * EMERGENCY RESPONSE API ROUTER
 */

import { z } from 'zod';
import { router, protectedProcedure } from '../../_core/trpc';
import { emergencyResponseService, type EmergencyType, type EmergencySeverity, type EmergencyStatus } from '../../services/emergency/EmergencyResponse';

export const emergencyRouter = router({
  // Report emergency
  report: protectedProcedure
    .input(z.object({
      householdId: z.number(),
      type: z.enum(['medical', 'security', 'fire', 'flood', 'power_outage', 'gas_leak', 'intrusion', 'child_safety', 'elderly_care', 'financial_fraud', 'custom']),
      severity: z.enum(['critical', 'high', 'medium', 'low']),
      title: z.string(),
      description: z.string(),
      detectionSource: z.string(),
      detectionConfidence: z.number().optional(),
      location: z.object({ area: z.string(), device: z.string().optional() }).optional(),
    }))
    .mutation(async ({ input }) => {
      return await emergencyResponseService.reportEmergency(input.householdId, {
        type: input.type as EmergencyType,
        severity: input.severity as EmergencySeverity,
        title: input.title,
        description: input.description,
        detectionSource: input.detectionSource,
        detectionConfidence: input.detectionConfidence,
        location: input.location,
      });
    }),

  // Acknowledge emergency
  acknowledge: protectedProcedure
    .input(z.object({ eventId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      return await emergencyResponseService.acknowledgeEmergency(input.eventId, ctx.user.id);
    }),

  // Resolve emergency
  resolve: protectedProcedure
    .input(z.object({
      eventId: z.number(),
      isFalseAlarm: z.boolean().optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      return await emergencyResponseService.resolveEmergency(input.eventId, ctx.user.id, {
        isFalseAlarm: input.isFalseAlarm,
        notes: input.notes,
      });
    }),

  // Escalate emergency
  escalate: protectedProcedure
    .input(z.object({ eventId: z.number() }))
    .mutation(async ({ input }) => {
      return await emergencyResponseService.escalateEmergency(input.eventId);
    }),

  // Get emergency by ID
  get: protectedProcedure
    .input(z.object({ eventId: z.number() }))
    .query(async ({ input }) => {
      return await emergencyResponseService.getEmergency(input.eventId);
    }),

  // List emergencies
  list: protectedProcedure
    .input(z.object({
      householdId: z.number(),
      status: z.enum(['detected', 'acknowledged', 'responding', 'resolved', 'escalated', 'false_alarm']).optional(),
      type: z.enum(['medical', 'security', 'fire', 'flood', 'power_outage', 'gas_leak', 'intrusion', 'child_safety', 'elderly_care', 'financial_fraud', 'custom']).optional(),
      limit: z.number().optional(),
    }))
    .query(async ({ input }) => {
      return await emergencyResponseService.getEmergencies(input.householdId, {
        status: input.status as EmergencyStatus | undefined,
        type: input.type as EmergencyType | undefined,
        limit: input.limit,
      });
    }),

  // Protocols
  protocols: router({
    create: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        name: z.string(),
        emergencyType: z.enum(['medical', 'security', 'fire', 'flood', 'power_outage', 'gas_leak', 'intrusion', 'child_safety', 'elderly_care', 'financial_fraud', 'custom']),
        severity: z.enum(['critical', 'high', 'medium', 'low']),
        triggers: z.array(z.object({ source: z.string(), condition: z.string(), threshold: z.number().optional() })),
        actions: z.array(z.object({ order: z.number(), type: z.string(), target: z.string(), message: z.string().optional(), delay: z.number().optional() })),
        escalationRules: z.array(z.object({ afterMinutes: z.number(), action: z.string(), target: z.string() })),
        isActive: z.boolean(),
      }))
      .mutation(async ({ input }) => {
        return await emergencyResponseService.createProtocol(input.householdId, {
          name: input.name,
          emergencyType: input.emergencyType as EmergencyType,
          severity: input.severity as EmergencySeverity,
          triggers: input.triggers,
          actions: input.actions,
          escalationRules: input.escalationRules,
          isActive: input.isActive,
        });
      }),

    list: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        type: z.enum(['medical', 'security', 'fire', 'flood', 'power_outage', 'gas_leak', 'intrusion', 'child_safety', 'elderly_care', 'financial_fraud', 'custom']).optional(),
      }))
      .query(async ({ input }) => {
        return await emergencyResponseService.getActiveProtocols(input.householdId, input.type as EmergencyType | undefined);
      }),
  }),

  // Contacts
  contacts: router({
    add: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        name: z.string(),
        relationship: z.string(),
        phone: z.string(),
        email: z.string().optional(),
        priority: z.number(),
        emergencyTypes: z.array(z.enum(['medical', 'security', 'fire', 'flood', 'power_outage', 'gas_leak', 'intrusion', 'child_safety', 'elderly_care', 'financial_fraud', 'custom'])),
        isAvailable: z.boolean(),
      }))
      .mutation(async ({ input }) => {
        return await emergencyResponseService.addContact(input.householdId, {
          name: input.name,
          relationship: input.relationship,
          phone: input.phone,
          email: input.email,
          priority: input.priority,
          emergencyTypes: input.emergencyTypes as EmergencyType[],
          isAvailable: input.isAvailable,
        });
      }),

    list: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        type: z.enum(['medical', 'security', 'fire', 'flood', 'power_outage', 'gas_leak', 'intrusion', 'child_safety', 'elderly_care', 'financial_fraud', 'custom']).optional(),
      }))
      .query(async ({ input }) => {
        return await emergencyResponseService.getContacts(input.householdId, input.type as EmergencyType | undefined);
      }),
  }),

  // Statistics
  statistics: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ input }) => {
      return await emergencyResponseService.getStatistics(input.householdId);
    }),
});
