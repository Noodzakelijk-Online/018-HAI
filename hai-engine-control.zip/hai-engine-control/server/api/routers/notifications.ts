/**
 * Notifications Router
 * 
 * Provides API endpoints for managing push notifications:
 * - Get notification history
 * - Mark notifications as read
 * - Send custom notifications
 * - Get online status
 */

import { z } from 'zod';
import { router, protectedProcedure } from '../../_core/trpc';
import { webSocketNotificationService, NotificationType } from '../../services/notifications/WebSocketNotificationService';

export const notificationsRouter = router({
  /**
   * Get notification history for current user
   */
  getHistory: protectedProcedure
    .input(z.object({
      limit: z.number().min(1).max(100).default(50),
    }))
    .query(async ({ ctx, input }) => {
      return webSocketNotificationService.getNotificationHistory(ctx.user.id, input.limit);
    }),

  /**
   * Get pending (unread) notifications
   */
  getPending: protectedProcedure
    .query(async ({ ctx }) => {
      return webSocketNotificationService.getPendingNotifications(ctx.user.id);
    }),

  /**
   * Get unread count
   */
  getUnreadCount: protectedProcedure
    .query(async ({ ctx }) => {
      const pending = webSocketNotificationService.getPendingNotifications(ctx.user.id);
      return { count: pending.length };
    }),

  /**
   * Mark notification as read
   */
  markAsRead: protectedProcedure
    .input(z.object({
      notificationId: z.string(),
    }))
    .mutation(async ({ ctx, input }) => {
      const success = webSocketNotificationService.markAsRead(ctx.user.id, input.notificationId);
      return { success };
    }),

  /**
   * Mark all notifications as read
   */
  markAllAsRead: protectedProcedure
    .mutation(async ({ ctx }) => {
      const count = webSocketNotificationService.markAllAsRead(ctx.user.id);
      return { markedCount: count };
    }),

  /**
   * Send a test notification to self
   */
  sendTestNotification: protectedProcedure
    .input(z.object({
      type: z.enum(['info', 'success', 'warning', 'error', 'emergency']).default('info'),
      title: z.string().default('Test Notification'),
      message: z.string().default('This is a test notification'),
    }))
    .mutation(async ({ ctx, input }) => {
      const notificationId = webSocketNotificationService.notify({
        userId: ctx.user.id,
        type: input.type as NotificationType,
        title: input.title,
        message: input.message,
        priority: input.type === 'emergency' ? 'critical' : 'normal',
      });

      return { success: true, notificationId };
    }),

  /**
   * Get connection status
   */
  getConnectionStatus: protectedProcedure
    .query(async ({ ctx }) => {
      return {
        isOnline: webSocketNotificationService.isUserOnline(ctx.user.id),
        totalConnectedClients: webSocketNotificationService.getConnectedClientCount(),
        totalConnectedUsers: webSocketNotificationService.getConnectedUserCount(),
      };
    }),

  /**
   * Get online household members
   */
  getOnlineMembers: protectedProcedure
    .query(async () => {
      const onlineUsers = webSocketNotificationService.getOnlineUsers();
      return { onlineUserIds: onlineUsers };
    }),

  /**
   * Send notification to another user (admin only)
   */
  sendToUser: protectedProcedure
    .input(z.object({
      userId: z.number(),
      type: z.enum(['info', 'success', 'warning', 'error', 'reminder', 'message']),
      title: z.string(),
      message: z.string(),
      priority: z.enum(['low', 'normal', 'high', 'critical']).default('normal'),
    }))
    .mutation(async ({ ctx, input }) => {
      // In production, check if user has permission to send to this user
      const notificationId = webSocketNotificationService.notify({
        userId: input.userId,
        type: input.type as NotificationType,
        title: input.title,
        message: input.message,
        priority: input.priority,
        data: { sentBy: ctx.user.id },
      });

      return { success: true, notificationId };
    }),

  /**
   * Broadcast notification to all users (admin only)
   */
  broadcast: protectedProcedure
    .input(z.object({
      type: z.enum(['info', 'success', 'warning', 'system_alert']),
      title: z.string(),
      message: z.string(),
      priority: z.enum(['low', 'normal', 'high']).default('normal'),
    }))
    .mutation(async ({ ctx, input }) => {
      // In production, verify admin role
      if (ctx.user.role !== 'admin') {
        throw new Error('Only admins can broadcast notifications');
      }

      const notificationId = webSocketNotificationService.notify({
        type: input.type as NotificationType,
        title: input.title,
        message: input.message,
        priority: input.priority,
        data: { broadcastBy: ctx.user.id },
      });

      return { success: true, notificationId };
    }),
});

export default notificationsRouter;
