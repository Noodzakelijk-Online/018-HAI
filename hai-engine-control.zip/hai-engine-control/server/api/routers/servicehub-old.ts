import { z } from "zod";
import { protectedProcedure, router } from "../../_core/trpc";
import { checkServiceHealth, getServiceHealthStats } from "../../services/healthCheckService";
import {
  createConnector,
  getConnectorsByUserId,
  getConnectorById,
  updateConnector,
  deleteConnector,
  updateConnectorOrder,
} from "../../db";
import { storagePut } from "../../storage";

/**
 * ServiceHub Router - Manages user services with drag-drop ordering
 */
export const servicehubRouter = router({
  /**
   * List all services for the current user
   */
  list: protectedProcedure.query(async ({ ctx }) => {
    return await getConnectorsByUserId(ctx.user.id);
  }),

  /**
   * Get a single service by ID
   */
  get: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const service = await getConnectorById(input.id);
      if (!service) {
        throw new Error("Service not found");
      }
      return service;
    }),

  /**
   * Create a new service
   */
  create: protectedProcedure
    .input(
      z.object({
        name: z.string().min(1, "Name is required"),
        connectorType: z.string().default("custom_service"),
        url: z.string().url("Valid URL is required").optional(),
        imageUrl: z.string().optional(),
        status: z.enum(["connected", "disconnected", "error", "pending_auth"]).default("connected"),
        metadata: z.any().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Get current max order position for this user
      const existingServices = await getConnectorsByUserId(ctx.user.id);
      const maxOrder = existingServices.length > 0 
        ? Math.max(...existingServices.map(s => s.orderPosition || 0))
        : -1;

      const serviceId = await createConnector({
        userId: ctx.user.id,
        name: input.name,
        connectorType: input.connectorType,
        url: input.url || null,
        imageUrl: input.imageUrl || null,
        status: input.status,
        metadata: input.metadata || null,
        orderPosition: maxOrder + 1,
      });

      return { id: serviceId, success: true };
    }),

  /**
   * Update an existing service
   */
  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1).optional(),
        url: z.string().url().optional(),
        imageUrl: z.string().optional(),
        status: z.enum(["connected", "disconnected", "error", "pending_auth"]).optional(),
        metadata: z.any().optional(),
        alertsEnabled: z.boolean().optional(),
        uptimeThreshold: z.number().min(0).max(100).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { id, ...updates } = input;
      
      // Verify ownership
      const service = await getConnectorById(id);
      if (!service || service.userId !== ctx.user.id) {
        throw new Error("Service not found or access denied");
      }

      await updateConnector(id, updates);
      return { success: true };
    }),

  /**
   * Delete a service
   */
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      // Verify ownership
      const service = await getConnectorById(input.id);
      if (!service || service.userId !== ctx.user.id) {
        throw new Error("Service not found or access denied");
      }

      await deleteConnector(input.id);
      return { success: true };
    }),

  /**
   * Update service order (drag-drop)
   */
  updateOrder: protectedProcedure
    .input(
      z.object({
        orderedIds: z.array(z.number()),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Verify all services belong to the user
      const services = await getConnectorsByUserId(ctx.user.id);
      const userServiceIds = new Set(services.map(s => s.id));
      
      for (const id of input.orderedIds) {
        if (!userServiceIds.has(id)) {
          throw new Error("Invalid service ID in order list");
        }
      }

      await updateConnectorOrder(ctx.user.id, input.orderedIds);
      return { success: true };
    }),

  /**
   * Upload custom service image
   */
  uploadImage: protectedProcedure
    .input(
      z.object({
        serviceId: z.number(),
        imageData: z.string(), // Base64 encoded image
        mimeType: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Verify ownership
      const service = await getConnectorById(input.serviceId);
      if (!service || service.userId !== ctx.user.id) {
        throw new Error("Service not found or access denied");
      }

      // Decode base64 and upload to S3
      const buffer = Buffer.from(input.imageData, 'base64');
      const fileKey = `service-images/${ctx.user.id}/${input.serviceId}-${Date.now()}.${input.mimeType.split('/')[1]}`;
      
      const { url } = await storagePut(fileKey, buffer, input.mimeType);

      // Update service with new image URL
      await updateConnector(input.serviceId, { imageUrl: url });

      return { url, success: true };
    }),

  /**
   * Check service health immediately
   */
  checkHealth: protectedProcedure
    .input(z.object({ serviceId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      // Verify ownership
      const service = await getConnectorById(input.serviceId);
      if (!service || service.userId !== ctx.user.id) {
        throw new Error("Service not found or access denied");
      }

      if (!service.url) {
        throw new Error("Service does not have a URL to check");
      }

      const result = await checkServiceHealth(service.id, service.url);
      return result;
    }),

  /**
   * Get health statistics for a service
   */
  getHealthStats: protectedProcedure
    .input(z.object({ serviceId: z.number() }))
    .query(async ({ ctx, input }) => {
      // Verify ownership
      const service = await getConnectorById(input.serviceId);
      if (!service || service.userId !== ctx.user.id) {
        throw new Error("Service not found or access denied");
      }

      const stats = await getServiceHealthStats(service.id);
      return stats;
    }),
});
