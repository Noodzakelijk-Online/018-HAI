/**
 * PILLAR 3 API ROUTER
 * 
 * "Serves the Household, Not Just Users"
 * 
 * Exposes APIs for:
 * - Tier System (member management, permissions)
 * - Relationship Mapper (contacts, relationships)
 * - Onboarding System
 */

import { z } from 'zod';
import { router, protectedProcedure } from '../../_core/trpc';
import { tierSystem, type MemberTier } from '../../services/pillar3/TierSystem';
import { relationshipMapper, type RelationshipType, type RelationshipStrength } from '../../services/pillar3/RelationshipMapper';

// ============================================================================
// ROUTER
// ============================================================================

export const pillar3Router = router({
  // ============================================================================
  // TIER SYSTEM
  // ============================================================================
  
  tiers: router({
    // Get all tier definitions
    definitions: protectedProcedure
      .query(async () => {
        return tierSystem.getTierDefinitions();
      }),

    // Get a specific tier definition
    definition: protectedProcedure
      .input(z.object({
        tier: z.enum(['owner', 'manager', 'trusted_member', 'member', 'guest']),
      }))
      .query(async ({ input }) => {
        return tierSystem.getTierDefinition(input.tier as MemberTier);
      }),
  }),

  members: router({
    // Add a member
    add: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        userId: z.number(),
        displayName: z.string(),
        email: z.string().optional(),
        phone: z.string().optional(),
        tier: z.enum(['owner', 'manager', 'trusted_member', 'member', 'guest']).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        // Get current user's member record to use as inviter
        const currentMember = await tierSystem.getMemberByUserId(input.householdId, ctx.user.id);
        
        return await tierSystem.addMember(input.householdId, input.userId, {
          displayName: input.displayName,
          email: input.email,
          phone: input.phone,
          tier: input.tier as MemberTier | undefined,
          invitedByMemberId: currentMember?.id,
        });
      }),

    // Get a member
    get: protectedProcedure
      .input(z.object({ memberId: z.number() }))
      .query(async ({ input }) => {
        return await tierSystem.getMember(input.memberId);
      }),

    // Get current user's member record
    me: protectedProcedure
      .input(z.object({ householdId: z.number() }))
      .query(async ({ input, ctx }) => {
        return await tierSystem.getMemberByUserId(input.householdId, ctx.user.id);
      }),

    // List household members
    list: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        tier: z.enum(['owner', 'manager', 'trusted_member', 'member', 'guest']).optional(),
        activeOnly: z.boolean().optional(),
      }))
      .query(async ({ input }) => {
        return await tierSystem.getHouseholdMembers(input.householdId, {
          tier: input.tier as MemberTier | undefined,
          activeOnly: input.activeOnly,
        });
      }),

    // Update a member
    update: protectedProcedure
      .input(z.object({
        memberId: z.number(),
        displayName: z.string().optional(),
        email: z.string().optional(),
        phone: z.string().optional(),
        avatar: z.string().optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { memberId, ...updates } = input;
        return await tierSystem.updateMember(memberId, updates);
      }),

    // Remove a member
    remove: protectedProcedure
      .input(z.object({ memberId: z.number() }))
      .mutation(async ({ input }) => {
        return await tierSystem.removeMember(input.memberId);
      }),

    // Change tier directly (owner only)
    changeTier: protectedProcedure
      .input(z.object({
        memberId: z.number(),
        newTier: z.enum(['owner', 'manager', 'trusted_member', 'member', 'guest']),
        householdId: z.number(),
      }))
      .mutation(async ({ input, ctx }) => {
        const currentMember = await tierSystem.getMemberByUserId(input.householdId, ctx.user.id);
        if (!currentMember) {
          throw new Error('You are not a member of this household');
        }
        return await tierSystem.changeTier(input.memberId, input.newTier as MemberTier, currentMember.id);
      }),

    // Request tier change
    requestTierChange: protectedProcedure
      .input(z.object({
        memberId: z.number(),
        toTier: z.enum(['owner', 'manager', 'trusted_member', 'member', 'guest']),
        reason: z.string(),
        householdId: z.number(),
      }))
      .mutation(async ({ input, ctx }) => {
        const currentMember = await tierSystem.getMemberByUserId(input.householdId, ctx.user.id);
        if (!currentMember) {
          throw new Error('You are not a member of this household');
        }
        return await tierSystem.requestTierChange(
          input.memberId,
          currentMember.id,
          input.toTier as MemberTier,
          input.reason
        );
      }),

    // Get pending tier change requests
    pendingRequests: protectedProcedure
      .input(z.object({ householdId: z.number() }))
      .query(async ({ input }) => {
        return await tierSystem.getPendingRequests(input.householdId);
      }),

    // Review tier change request
    reviewRequest: protectedProcedure
      .input(z.object({
        requestId: z.number(),
        approved: z.boolean(),
        notes: z.string().optional(),
        householdId: z.number(),
      }))
      .mutation(async ({ input, ctx }) => {
        const currentMember = await tierSystem.getMemberByUserId(input.householdId, ctx.user.id);
        if (!currentMember) {
          throw new Error('You are not a member of this household');
        }
        return await tierSystem.reviewTierChangeRequest(
          input.requestId,
          currentMember.id,
          input.approved,
          input.notes
        );
      }),

    // Get effective permissions
    permissions: protectedProcedure
      .input(z.object({ memberId: z.number() }))
      .query(async ({ input }) => {
        const member = await tierSystem.getMember(input.memberId);
        if (!member) throw new Error('Member not found');
        return tierSystem.getEffectivePermissions(member);
      }),

    // Get effective limits
    limits: protectedProcedure
      .input(z.object({ memberId: z.number() }))
      .query(async ({ input }) => {
        const member = await tierSystem.getMember(input.memberId);
        if (!member) throw new Error('Member not found');
        return tierSystem.getEffectiveLimits(member);
      }),

    // Check permission
    hasPermission: protectedProcedure
      .input(z.object({
        memberId: z.number(),
        permission: z.string(),
      }))
      .query(async ({ input }) => {
        const member = await tierSystem.getMember(input.memberId);
        if (!member) return false;
        return tierSystem.hasPermission(member, input.permission as any);
      }),

    // Get statistics
    statistics: protectedProcedure
      .input(z.object({ householdId: z.number() }))
      .query(async ({ input }) => {
        return await tierSystem.getStatistics(input.householdId);
      }),
  }),

  // ============================================================================
  // RELATIONSHIPS
  // ============================================================================
  
  contacts: router({
    // Create a contact
    create: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        name: z.string(),
        email: z.string().optional(),
        phone: z.string().optional(),
        organization: z.string().optional(),
        role: z.string().optional(),
        category: z.enum(['personal', 'professional', 'service', 'other']),
        importance: z.enum(['high', 'medium', 'low']),
        preferredChannel: z.string().optional(),
        doNotContact: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { householdId, ...data } = input;
        return await relationshipMapper.createContact(householdId, data);
      }),

    // Get a contact
    get: protectedProcedure
      .input(z.object({ contactId: z.string() }))
      .query(async ({ input }) => {
        return await relationshipMapper.getContact(input.contactId);
      }),

    // List contacts
    list: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        category: z.enum(['personal', 'professional', 'service', 'other']).optional(),
        importance: z.enum(['high', 'medium', 'low']).optional(),
      }))
      .query(async ({ input }) => {
        return await relationshipMapper.getHouseholdContacts(input.householdId, {
          category: input.category,
          importance: input.importance,
        });
      }),

    // Update a contact
    update: protectedProcedure
      .input(z.object({
        contactId: z.string(),
        name: z.string().optional(),
        email: z.string().optional(),
        phone: z.string().optional(),
        organization: z.string().optional(),
        role: z.string().optional(),
        category: z.enum(['personal', 'professional', 'service', 'other']).optional(),
        importance: z.enum(['high', 'medium', 'low']).optional(),
        preferredChannel: z.string().optional(),
        doNotContact: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { contactId, ...updates } = input;
        return await relationshipMapper.updateContact(contactId, updates);
      }),

    // Record interaction
    recordInteraction: protectedProcedure
      .input(z.object({ contactId: z.string() }))
      .mutation(async ({ input }) => {
        await relationshipMapper.recordInteraction(input.contactId);
        return { success: true };
      }),
  }),

  relationships: router({
    // Create a relationship
    create: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        member1Id: z.number(),
        member2Id: z.number().optional(),
        externalContactId: z.string().optional(),
        relationshipType: z.enum([
          'spouse', 'parent', 'child', 'sibling', 'grandparent', 'grandchild',
          'extended_family', 'roommate', 'friend', 'colleague', 'service_provider',
          'healthcare', 'education', 'other'
        ]),
        strength: z.enum(['close', 'regular', 'occasional', 'distant']).optional(),
        bidirectional: z.boolean().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { householdId, ...data } = input;
        return await relationshipMapper.createRelationship(householdId, {
          ...data,
          relationshipType: data.relationshipType as RelationshipType,
          strength: data.strength as RelationshipStrength | undefined,
        });
      }),

    // Get a relationship
    get: protectedProcedure
      .input(z.object({ relationshipId: z.number() }))
      .query(async ({ input }) => {
        return await relationshipMapper.getRelationship(input.relationshipId);
      }),

    // Get member's relationships
    forMember: protectedProcedure
      .input(z.object({
        memberId: z.number(),
        type: z.enum([
          'spouse', 'parent', 'child', 'sibling', 'grandparent', 'grandchild',
          'extended_family', 'roommate', 'friend', 'colleague', 'service_provider',
          'healthcare', 'education', 'other'
        ]).optional(),
        strength: z.enum(['close', 'regular', 'occasional', 'distant']).optional(),
        includeExternal: z.boolean().optional(),
      }))
      .query(async ({ input }) => {
        return await relationshipMapper.getMemberRelationships(input.memberId, {
          type: input.type as RelationshipType | undefined,
          strength: input.strength as RelationshipStrength | undefined,
          includeExternal: input.includeExternal,
        });
      }),

    // Get all household relationships
    list: protectedProcedure
      .input(z.object({ householdId: z.number() }))
      .query(async ({ input }) => {
        return await relationshipMapper.getHouseholdRelationships(input.householdId);
      }),

    // Update a relationship
    update: protectedProcedure
      .input(z.object({
        relationshipId: z.number(),
        strength: z.enum(['close', 'regular', 'occasional', 'distant']).optional(),
        preferredChannel: z.string().optional(),
        communicationFrequency: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { relationshipId, ...updates } = input;
        return await relationshipMapper.updateRelationship(relationshipId, {
          ...updates,
          strength: updates.strength as RelationshipStrength | undefined,
        });
      }),

    // Delete a relationship
    delete: protectedProcedure
      .input(z.object({ relationshipId: z.number() }))
      .mutation(async ({ input }) => {
        return await relationshipMapper.deleteRelationship(input.relationshipId);
      }),

    // Build relationship graph
    graph: protectedProcedure
      .input(z.object({ householdId: z.number() }))
      .query(async ({ input }) => {
        const members = await tierSystem.getHouseholdMembers(input.householdId);
        return await relationshipMapper.buildRelationshipGraph(
          input.householdId,
          members.map(m => ({
            id: m.id,
            displayName: m.displayName,
            tier: m.tier,
          }))
        );
      }),

    // Get statistics
    statistics: protectedProcedure
      .input(z.object({ householdId: z.number() }))
      .query(async ({ input }) => {
        return await relationshipMapper.getStatistics(input.householdId);
      }),
  }),

  // ============================================================================
  // COMBINED STATISTICS
  // ============================================================================
  
  statistics: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ input }) => {
      const [tierStats, relationshipStats] = await Promise.all([
        tierSystem.getStatistics(input.householdId),
        relationshipMapper.getStatistics(input.householdId),
      ]);

      return {
        tiers: tierStats,
        relationships: relationshipStats,
        summary: {
          totalMembers: tierStats.totalMembers,
          activeMembers: tierStats.activeMembers,
          totalContacts: relationshipStats.totalContacts,
          totalRelationships: relationshipStats.totalRelationships,
          pendingRequests: tierStats.pendingRequests,
        },
      };
    }),
});
