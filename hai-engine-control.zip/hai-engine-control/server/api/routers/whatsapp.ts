/**
 * WhatsApp tRPC Router
 * 
 * API endpoints for WhatsApp integration
 */

import { z } from 'zod';
import { router, protectedProcedure } from '../../_core/trpc';
import { WhatsAppSyncService } from '../../services/whatsapp/WhatsAppSyncService';
import { getWhatsAppConnector } from '../../services/whatsapp/WhatsAppConnector';
import { getWhatsAppAutoResponse } from '../../services/whatsapp/WhatsAppAutoResponse';
import { getWhatsAppSearch } from '../../services/whatsapp/WhatsAppSearch';
import { getWhatsAppExport } from '../../services/whatsapp/WhatsAppExport';
import { getDb } from '../../db';
import { whatsappContacts, whatsappMessages, whatsappInsights, whatsappSyncStatus } from '../../../drizzle/whatsapp-schema';
import { eq, and, desc } from 'drizzle-orm';

export const whatsappRouter = router({
  /**
   * Get sync status
   */
  getSyncStatus: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const [status] = await db.select().from(whatsappSyncStatus)
      .where(eq(whatsappSyncStatus.userId, ctx.user.id))
      .limit(1);
    
    return status || null;
  }),
  
  /**
   * Start full sync
   */
  startSync: protectedProcedure.mutation(async ({ ctx }) => {
    const syncService = new WhatsAppSyncService(ctx.user.id, (progress) => {
      console.log('[WhatsApp] Sync progress:', progress);
      // TODO: Emit progress via WebSocket
    });
    
    // Start sync in background
    syncService.performFullSync().catch(error => {
      console.error('[WhatsApp] Sync failed:', error);
    });
    
    return { success: true, message: 'Sync started' };
  }),
  
  /**
   * Get all contacts
   */
  getContacts: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const contacts = await db.select().from(whatsappContacts)
      .where(eq(whatsappContacts.userId, ctx.user.id))
      .orderBy(desc(whatsappContacts.lastMessageAt));
    
    return contacts;
  }),
  
  /**
   * Get contact by ID
   */
  getContact: protectedProcedure
    .input(z.object({ contactId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error('Database not available');
      
      const [contact] = await db.select().from(whatsappContacts)
        .where(and(
          eq(whatsappContacts.userId, ctx.user.id),
          eq(whatsappContacts.id, input.contactId)
        ))
        .limit(1);
      
      return contact || null;
    }),
  
  /**
   * Get messages for a contact
   */
  getMessages: protectedProcedure
    .input(z.object({
      contactId: z.number(),
      limit: z.number().optional(),
      offset: z.number().optional()
    }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error('Database not available');
      
      const messages = await db.select().from(whatsappMessages)
        .where(and(
          eq(whatsappMessages.userId, ctx.user.id),
          eq(whatsappMessages.contactId, input.contactId)
        ))
        .orderBy(desc(whatsappMessages.timestamp))
        .limit(input.limit || 100)
        .offset(input.offset || 0);
      
      return messages;
    }),
  
  /**
   * Get conversation insights
   */
  getInsights: protectedProcedure
    .input(z.object({ contactId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error('Database not available');
      
      const insights = await db.select().from(whatsappInsights)
        .where(and(
          eq(whatsappInsights.userId, ctx.user.id),
          eq(whatsappInsights.contactId, input.contactId)
        ))
        .orderBy(desc(whatsappInsights.periodStart));
      
      return insights;
    }),
  
  /**
   * Search messages
   */
  searchMessages: protectedProcedure
    .input(z.object({
      query: z.string(),
      contactId: z.number().optional(),
      limit: z.number().optional()
    }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error('Database not available');
      
      // TODO: Implement full-text search
      // For now, use simple LIKE query
      const messages = await db.select().from(whatsappMessages)
        .where(and(
          eq(whatsappMessages.userId, ctx.user.id),
          input.contactId ? eq(whatsappMessages.contactId, input.contactId) : undefined
        ))
        .orderBy(desc(whatsappMessages.timestamp))
        .limit(input.limit || 50);
      
      // Filter by query
      const filtered = messages.filter(msg => 
        msg.content?.toLowerCase().includes(input.query.toLowerCase())
      );
      
      return filtered;
    }),
  
  /**
   * Get relationship insights for all contacts
   */
  getRelationshipInsights: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error('Database not available');
    
    const contacts = await db.select().from(whatsappContacts)
      .where(eq(whatsappContacts.userId, ctx.user.id))
      .orderBy(desc(whatsappContacts.relationshipScore));
    
    return contacts.map(contact => ({
      id: contact.id,
      name: contact.name,
      phone: contact.phone,
      relationshipScore: contact.relationshipScore ? parseFloat(contact.relationshipScore) : 0,
      messageCount: contact.messageCount,
      lastMessageAt: contact.lastMessageAt,
      isGroup: contact.isGroup
    }));
  }),
  
  /**
   * Send message
   */
  sendMessage: protectedProcedure
    .input(z.object({
      contactId: z.number(),
      message: z.string()
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error('Database not available');
      
      // Get contact
      const [contact] = await db.select().from(whatsappContacts)
        .where(and(
          eq(whatsappContacts.userId, ctx.user.id),
          eq(whatsappContacts.id, input.contactId)
        ))
        .limit(1);
      
      if (!contact) {
        throw new Error('Contact not found');
      }
      
      // Send message
      const connector = getWhatsAppConnector(ctx.user.id);
      await connector.sendMessage(contact.phone, input.message);
      
      return { success: true };
    }),
  
  /**
   * Disconnect WhatsApp
   */
  disconnect: protectedProcedure.mutation(async ({ ctx }) => {
    const connector = getWhatsAppConnector(ctx.user.id);
    await connector.disconnect();
    
    return { success: true };
  }),
  
  /**
   * Advanced search with filters
   */
  advancedSearch: protectedProcedure
    .input(z.object({
      query: z.string().optional(),
      contactId: z.number().optional(),
      startDate: z.date().optional(),
      endDate: z.date().optional(),
      sentiment: z.enum(['positive', 'negative', 'neutral']).optional(),
      isFromMe: z.boolean().optional(),
      hasMedia: z.boolean().optional(),
      limit: z.number().optional(),
      offset: z.number().optional()
    }))
    .query(async ({ input }) => {
      const search = getWhatsAppSearch();
      return await search.search(input);
    }),
  
  /**
   * Get search suggestions
   */
  getSearchSuggestions: protectedProcedure
    .input(z.object({ query: z.string() }))
    .query(async ({ input }) => {
      const search = getWhatsAppSearch();
      return await search.getSearchSuggestions(input.query);
    }),
  
  /**
   * Export conversation
   */
  exportConversation: protectedProcedure
    .input(z.object({
      contactId: z.number(),
      format: z.enum(['pdf', 'json']),
      includeMedia: z.boolean().optional(),
      includeInsights: z.boolean().optional()
    }))
    .mutation(async ({ input }) => {
      const exporter = getWhatsAppExport();
      return await exporter.exportConversation(input);
    }),
  
  /**
   * Configure auto-response for a contact
   */
  configureAutoResponse: protectedProcedure
    .input(z.object({
      contactId: z.number().optional(),
      enabled: z.boolean(),
      minConfidence: z.number().min(0).max(1).optional(),
      learningMode: z.boolean().optional()
    }))
    .mutation(async ({ ctx, input }) => {
      // Store config in database (TODO: create auto_response_config table)
      return { success: true, config: input };
    }),
  
  /**
   * Test auto-response (simulate without sending)
   */
  testAutoResponse: protectedProcedure
    .input(z.object({
      contactId: z.number(),
      messageContent: z.string()
    }))
    .mutation(async ({ ctx, input }) => {
      const autoResponse = getWhatsAppAutoResponse(ctx.user.id, {
        enabled: true,
        minConfidence: 0.7,
        maxResponseTime: 5000,
        learningMode: true // Test mode
      });
      
      const decision = await autoResponse.processIncomingMessage(
        input.contactId,
        input.messageContent,
        new Date()
      );
      
      return decision;
    })
});
