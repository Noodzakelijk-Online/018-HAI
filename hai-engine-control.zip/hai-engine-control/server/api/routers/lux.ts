import { z } from 'zod';
import { router, protectedProcedure } from '../../_core/trpc';
import { executeLuxTask, checkLuxStatus, getLuxModels, type LuxModel } from '../../services/luxAgent';

/**
 * Lux tRPC Router
 * 
 * API endpoints for OpenAGI Lux computer-use agent
 */

export const luxRouter = router({
  /**
   * Execute a task with Lux
   */
  execute: protectedProcedure
    .input(z.object({
      goal: z.string().min(1, 'Goal is required'),
      model: z.enum(['lux-actor-1', 'lux-tasker-1', 'lux-thinker-1']),
      timeout: z.number().optional()
    }))
    .mutation(async ({ input, ctx }) => {
      try {
        const result = await executeLuxTask({
          goal: input.goal,
          model: input.model as LuxModel,
          timeout: input.timeout
        });

        // TODO: Save execution to database (task_executions table)
        // await db.insert(taskExecutions).values({
        //   taskId: ...,
        //   agentId: ...,
        //   status: 'completed',
        //   duration: result.duration,
        //   cost: result.cost,
        //   screenshots: JSON.stringify(result.screenshots),
        //   actions: JSON.stringify(result.actions),
        //   result: result.output
        // });

        return result;
      } catch (error: any) {
        // Return error as LuxResult format
        return {
          success: false,
          output: '',
          screenshots: [],
          actions: [],
          duration: 0,
          cost: 0,
          error: error.error || error.message || 'Unknown error occurred'
        };
      }
    }),

  /**
   * Check if Lux is available
   */
  checkStatus: protectedProcedure
    .query(async () => {
      const status = await checkLuxStatus();
      return status;
    }),

  /**
   * Get available Lux models
   */
  getModels: protectedProcedure
    .query(() => {
      return getLuxModels();
    })
});
