import { z } from "zod";
import { protectedProcedure, router } from "../../_core/trpc";
import { explainabilityService } from "../../services/ExplainabilityService";

export const explainabilityRouter = router({
  /**
   * 81. Decision tree extraction
   */
  extractDecisionTree: protectedProcedure
    .input(
      z.object({
        modelDecisions: z.array(
          z.object({
            input: z.record(z.number()),
            output: z.string(),
          })
        ),
        maxDepth: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return explainabilityService.extractDecisionTree(
        input.modelDecisions,
        input.maxDepth
      );
    }),

  /**
   * 82. Feature importance ranking
   */
  rankFeatureImportance: protectedProcedure
    .input(
      z.object({
        features: z.array(z.string()),
        predictions: z.array(
          z.object({
            input: z.record(z.number()),
            output: z.number(),
          })
        ),
      })
    )
    .query(async ({ input }) => {
      return explainabilityService.rankFeatureImportance(
        input.features,
        input.predictions
      );
    }),

  /**
   * 83. Attention visualization
   */
  visualizeAttention: protectedProcedure
    .input(
      z.object({
        inputText: z.string(),
        decision: z.string(),
      })
    )
    .query(async ({ input }) => {
      return explainabilityService.visualizeAttention(
        input.inputText,
        input.decision
      );
    }),

  /**
   * 84. Counterfactual explanations
   */
  generateCounterfactualExplanation: protectedProcedure
    .input(
      z.object({
        originalInput: z.record(z.any()),
        originalDecision: z.string(),
        desiredDecision: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      return explainabilityService.generateCounterfactualExplanation(
        input.originalInput,
        input.originalDecision,
        input.desiredDecision
      );
    }),

  /**
   * 85. Example-based explanations
   */
  generateExampleBasedExplanation: protectedProcedure
    .input(
      z.object({
        queryInstance: z.record(z.any()),
        queryDecision: z.string(),
        trainingExamples: z.array(
          z.object({
            instance: z.record(z.any()),
            decision: z.string(),
          })
        ),
      })
    )
    .query(async ({ input }) => {
      return explainabilityService.generateExampleBasedExplanation(
        input.queryInstance,
        input.queryDecision,
        input.trainingExamples
      );
    }),

  /**
   * 86. Natural language justifications
   */
  generateNaturalLanguageJustification: protectedProcedure
    .input(
      z.object({
        decision: z.string(),
        context: z.record(z.any()),
        audienceLevel: z.enum(["technical", "general", "expert"]).optional(),
      })
    )
    .mutation(async ({ input }) => {
      return explainabilityService.generateNaturalLanguageJustification(
        input.decision,
        input.context,
        input.audienceLevel
      );
    }),

  /**
   * 87. Interactive explanation refinement
   */
  refineExplanation: protectedProcedure
    .input(
      z.object({
        sessionId: z.string(),
        originalExplanation: z.string(),
        followUpQuestion: z.string(),
        previousRefinements: z.array(
          z.object({
            question: z.string(),
            answer: z.string(),
          })
        ),
      })
    )
    .mutation(async ({ input }) => {
      return explainabilityService.refineExplanation(
        input.sessionId,
        input.originalExplanation,
        input.followUpQuestion,
        input.previousRefinements
      );
    }),

  /**
   * 88. Explanation consistency checking
   */
  checkExplanationConsistency: protectedProcedure
    .input(
      z.object({
        explanations: z.array(
          z.object({
            explanationId: z.string(),
            input: z.record(z.any()),
            explanation: z.string(),
          })
        ),
      })
    )
    .query(async ({ input }) => {
      return explainabilityService.checkExplanationConsistency(input.explanations);
    }),

  /**
   * 89. Contrastive explanations
   */
  generateContrastiveExplanation: protectedProcedure
    .input(
      z.object({
        chosenOption: z.string(),
        rejectedOption: z.string(),
        context: z.record(z.any()),
      })
    )
    .mutation(async ({ input }) => {
      return explainabilityService.generateContrastiveExplanation(
        input.chosenOption,
        input.rejectedOption,
        input.context
      );
    }),

  /**
   * 90. Explanation quality metrics
   */
  measureExplanationQuality: protectedProcedure
    .input(
      z.object({
        explanation: z.string(),
        originalDecision: z.string(),
        groundTruth: z.string().optional(),
      })
    )
    .query(async ({ input }) => {
      return explainabilityService.measureExplanationQuality(
        input.explanation,
        input.originalDecision,
        input.groundTruth
      );
    }),
});
