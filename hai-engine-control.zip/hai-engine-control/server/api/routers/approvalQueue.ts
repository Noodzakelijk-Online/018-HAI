/**
 * Approval Queue API Router
 */

import { z } from 'zod';
import { router, protectedProcedure } from '../../_core/trpc';
import { approvalQueueManager } from '../../services/approvalQueueManager';
import { EventBus } from '../../services/EventBus';

export const approvalQueueRouter = router({
  /**
   * Get pending approval items for user's household
   */
  getPending: protectedProcedure
    .input(z.object({
      householdId: z.number(),
    }))
    .query(async ({ input }) => {
      return await approvalQueueManager.getPendingItems(input.householdId);
    }),

  /**
   * Get all approval items (with optional status filter)
   */
  getAll: protectedProcedure
    .input(z.object({
      householdId: z.number(),
      status: z.enum(['pending', 'approved', 'rejected', 'expired']).optional(),
    }))
    .query(async ({ input }) => {
      return await approvalQueueManager.getItems(input.householdId, input.status);
    }),

  /**
   * Get single approval item
   */
  getById: protectedProcedure
    .input(z.object({
      id: z.number(),
    }))
    .query(async ({ input }) => {
      return await approvalQueueManager.getItem(input.id);
    }),

  /**
   * Approve an item
   */
  approve: protectedProcedure
    .input(z.object({
      id: z.number(),
    }))
    .mutation(async ({ input, ctx }) => {
      const item = await approvalQueueManager.approveItem(input.id, ctx.user.id);

      // Publish event for execution
      await EventBus.publish({
        type: 'approval.approved',
        source: 'ApprovalQueueRouter',
        target: '*',
        data: {
          itemId: item.id,
          type: item.type,
          metadata: item.metadata,
          approvedBy: ctx.user.id,
        },
      });

      return item;
    }),

  /**
   * Reject an item
   */
  reject: protectedProcedure
    .input(z.object({
      id: z.number(),
    }))
    .mutation(async ({ input, ctx }) => {
      const item = await approvalQueueManager.rejectItem(input.id, ctx.user.id);

      // Publish event
      await EventBus.publish({
        type: 'approval.rejected',
        source: 'ApprovalQueueRouter',
        target: '*',
        data: {
          itemId: item.id,
          type: item.type,
          rejectedBy: ctx.user.id,
        },
      });

      return item;
    }),

  /**
   * Get approval queue statistics
   */
  getStatistics: protectedProcedure
    .input(z.object({
      householdId: z.number(),
    }))
    .query(async ({ input }) => {
      const allItems = await approvalQueueManager.getItems(input.householdId);
      
      const pending = allItems.filter(i => i.status === 'pending').length;
      const approved = allItems.filter(i => i.status === 'approved').length;
      const rejected = allItems.filter(i => i.status === 'rejected').length;
      const expired = allItems.filter(i => i.status === 'expired').length;

      return {
        total: allItems.length,
        pending,
        approved,
        rejected,
        expired,
      };
    }),

  /**
   * Create a test approval item (for demo purposes)
   */
  createTestItem: protectedProcedure
    .input(z.object({
      householdId: z.number(),
    }))
    .mutation(async ({ input, ctx }) => {
      return await approvalQueueManager.createItem({
        type: 'email_response',
        title: 'Respond to urgent client email',
        description: 'Client is asking about project timeline. HAI suggests sending a status update.',
        metadata: {
          from: 'client@example.com',
          subject: 'Project Timeline Update Request',
          suggestedResponse: 'Thank you for your email. The project is on track and we expect to deliver by the end of next week.',
        },
        suggestedAction: 'Send email response',
        reasoning: 'Client has been waiting for 2 days. Quick response will maintain good relationship.',
        confidence: 85,
        priority: 'high',
        householdId: input.householdId,
        createdBy: 0, // Autonomous
      });
    }),
});
