import { z } from "zod";
import { protectedProcedure, router } from "../../_core/trpc";
import { analyzeHouseholdAccounts, executeAutonomousAction } from "../../services/orchestratorEngine";

export const orchestratorRouter = router({
  /**
   * Analyze all connected accounts for a household
   */
  analyzeAccounts: protectedProcedure
    .input(z.object({
      householdId: z.number(),
    }))
    .query(async ({ input }) => {
      return await analyzeHouseholdAccounts(input.householdId);
    }),

  /**
   * Execute an autonomous action
   */
  executeAction: protectedProcedure
    .input(z.object({
      insightId: z.string(),
      action: z.string(),
      metadata: z.record(z.any()),
    }))
    .mutation(async ({ input }) => {
      return await executeAutonomousAction(
        input.insightId,
        input.action,
        input.metadata
      );
    }),

  /**
   * Get orchestrator status
   */
  getStatus: protectedProcedure
    .input(z.object({
      householdId: z.number(),
    }))
    .query(async ({ input, ctx }) => {
      // Get basic status information
      const db = await import("../../db").then(m => m.getDb());
      if (!db) {
        throw new Error("Database not available");
      }

      const { connectors } = await import("../../../drizzle/schema");
      const { eq, and } = await import("drizzle-orm");

      const activeConnectors = await db
        .select()
        .from(connectors)
        .where(
          and(
            eq(connectors.householdId, input.householdId),
            eq(connectors.status, "active")
          )
        );

      return {
        connectedAccounts: activeConnectors.length,
        accountTypes: {
          email: activeConnectors.filter(c => c.connectorType === "gmail").length,
          calendar: activeConnectors.filter(c => c.connectorType === "google_calendar").length,
          financial: 0,
          documents: 0,
        },
        lastAnalysis: null, // TODO: Store last analysis time
        systemHealth: "operational" as const,
      };
    }),
});
