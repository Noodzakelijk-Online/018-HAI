/**
 * PILLAR 2 API ROUTER
 * 
 * "Learns Like a New Employee"
 * 
 * Exposes APIs for:
 * - Rules Engine (explicit rules)
 * - Implicit Learning (behavior patterns)
 * - Communication Adaptation
 */

import { z } from 'zod';
import { router, protectedProcedure } from '../../_core/trpc';
import { rulesEngine, type RuleCategory, type RulePriority, type RuleConditionOperator, type RuleActionType } from '../../services/pillar2/RulesEngine';
import { implicitLearningService, type PatternType } from '../../services/pillar2/ImplicitLearningService';
import { communicationAdaptationService, type CommunicationTone, type CommunicationChannel } from '../../services/pillar2/CommunicationAdaptationService';

// ============================================================================
// SCHEMAS
// ============================================================================

const ruleConditionSchema = z.object({
  field: z.string(),
  operator: z.enum(['equals', 'not_equals', 'contains', 'not_contains', 'greater_than', 'less_than', 'between', 'in_list', 'matches_pattern', 'time_is', 'day_is']),
  value: z.any(),
  valueEnd: z.any().optional(),
});

const ruleActionSchema = z.object({
  type: z.enum(['execute', 'notify', 'block', 'modify', 'escalate', 'delay', 'redirect']),
  target: z.string().optional(),
  parameters: z.record(z.any()).optional(),
});

// ============================================================================
// ROUTER
// ============================================================================

export const pillar2Router = router({
  // ============================================================================
  // RULES ENGINE
  // ============================================================================
  
  rules: router({
    // Create a new rule
    create: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        name: z.string(),
        description: z.string().optional(),
        category: z.enum(['communication', 'scheduling', 'financial', 'household', 'privacy', 'notification', 'automation']),
        priority: z.enum(['low', 'medium', 'high', 'critical']),
        memberId: z.number().optional(),
        conditions: z.array(ruleConditionSchema),
        conditionLogic: z.enum(['all', 'any']),
        actions: z.array(ruleActionSchema),
        startDate: z.date().optional(),
        endDate: z.date().optional(),
        isActive: z.boolean().default(true),
      }))
      .mutation(async ({ input, ctx }) => {
        return await rulesEngine.createRule(
          input.householdId,
          ctx.user.id,
          {
            name: input.name,
            description: input.description,
            category: input.category as RuleCategory,
            priority: input.priority as RulePriority,
            memberId: input.memberId,
            conditions: input.conditions.map(c => ({
              ...c,
              operator: c.operator as RuleConditionOperator,
            })),
            conditionLogic: input.conditionLogic,
            actions: input.actions.map(a => ({
              ...a,
              type: a.type as RuleActionType,
            })),
            startDate: input.startDate,
            endDate: input.endDate,
            isActive: input.isActive,
          }
        );
      }),

    // Update a rule
    update: protectedProcedure
      .input(z.object({
        ruleId: z.number(),
        name: z.string().optional(),
        description: z.string().optional(),
        priority: z.enum(['low', 'medium', 'high', 'critical']).optional(),
        conditions: z.array(ruleConditionSchema).optional(),
        conditionLogic: z.enum(['all', 'any']).optional(),
        actions: z.array(ruleActionSchema).optional(),
        isActive: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const updates: any = { ...input };
        delete updates.ruleId;
        
        if (updates.conditions) {
          updates.conditions = updates.conditions.map((c: any) => ({
            ...c,
            operator: c.operator as RuleConditionOperator,
          }));
        }
        if (updates.actions) {
          updates.actions = updates.actions.map((a: any) => ({
            ...a,
            type: a.type as RuleActionType,
          }));
        }
        if (updates.priority) {
          updates.priority = updates.priority as RulePriority;
        }
        
        return await rulesEngine.updateRule(input.ruleId, updates);
      }),

    // Delete a rule
    delete: protectedProcedure
      .input(z.object({ ruleId: z.number() }))
      .mutation(async ({ input }) => {
        return await rulesEngine.deleteRule(input.ruleId);
      }),

    // Get a rule by ID
    get: protectedProcedure
      .input(z.object({ ruleId: z.number() }))
      .query(async ({ input }) => {
        return await rulesEngine.getRule(input.ruleId);
      }),

    // List rules for a household
    list: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        category: z.enum(['communication', 'scheduling', 'financial', 'household', 'privacy', 'notification', 'automation']).optional(),
        memberId: z.number().optional(),
        activeOnly: z.boolean().optional(),
      }))
      .query(async ({ input }) => {
        return await rulesEngine.getHouseholdRules(input.householdId, {
          category: input.category as RuleCategory | undefined,
          memberId: input.memberId,
          activeOnly: input.activeOnly,
        });
      }),

    // Validate a rule
    validate: protectedProcedure
      .input(z.object({
        name: z.string(),
        category: z.enum(['communication', 'scheduling', 'financial', 'household', 'privacy', 'notification', 'automation']),
        conditions: z.array(ruleConditionSchema),
        actions: z.array(ruleActionSchema),
      }))
      .query(async ({ input }) => {
        return rulesEngine.validateRule({
          name: input.name,
          category: input.category as RuleCategory,
          conditions: input.conditions.map(c => ({
            ...c,
            operator: c.operator as RuleConditionOperator,
          })),
          actions: input.actions.map(a => ({
            ...a,
            type: a.type as RuleActionType,
          })),
        });
      }),

    // Evaluate rules against context
    evaluate: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        context: z.record(z.any()),
        category: z.enum(['communication', 'scheduling', 'financial', 'household', 'privacy', 'notification', 'automation']).optional(),
        memberId: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        return await rulesEngine.evaluateRules(input.householdId, input.context, {
          category: input.category as RuleCategory | undefined,
          memberId: input.memberId,
        });
      }),

    // Get rule templates
    templates: protectedProcedure
      .query(async () => {
        return rulesEngine.getRuleTemplates();
      }),

    // Get rule statistics
    statistics: protectedProcedure
      .input(z.object({ householdId: z.number() }))
      .query(async ({ input }) => {
        return await rulesEngine.getStatistics(input.householdId);
      }),
  }),

  // ============================================================================
  // IMPLICIT LEARNING
  // ============================================================================
  
  learning: router({
    // Record a behavior observation
    recordObservation: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        memberId: z.number().optional(),
        observationType: z.string(),
        observationData: z.record(z.any()),
        context: z.record(z.any()).optional(),
      }))
      .mutation(async ({ input }) => {
        return await implicitLearningService.recordObservation(
          input.householdId,
          input.memberId,
          input.observationType,
          input.observationData,
          input.context || {}
        );
      }),

    // Get patterns
    patterns: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        memberId: z.number().optional(),
        patternType: z.enum(['time_preference', 'communication_style', 'financial_habit', 'schedule_pattern', 'interaction_preference', 'priority_tendency', 'response_pattern']).optional(),
        minConfidence: z.number().optional(),
        activeOnly: z.boolean().optional(),
      }))
      .query(async ({ input }) => {
        return await implicitLearningService.getPatterns(input.householdId, {
          memberId: input.memberId,
          patternType: input.patternType as PatternType | undefined,
          minConfidence: input.minConfidence,
          activeOnly: input.activeOnly,
        });
      }),

    // Get a single pattern
    pattern: protectedProcedure
      .input(z.object({ patternId: z.number() }))
      .query(async ({ input }) => {
        return await implicitLearningService.getPattern(input.patternId);
      }),

    // Deactivate a pattern
    deactivatePattern: protectedProcedure
      .input(z.object({ patternId: z.number() }))
      .mutation(async ({ input }) => {
        return await implicitLearningService.deactivatePattern(input.patternId);
      }),

    // Get applicable patterns for context
    applicablePatterns: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        context: z.record(z.any()),
      }))
      .query(async ({ input }) => {
        return await implicitLearningService.getApplicablePatterns(input.householdId, input.context);
      }),

    // Record pattern application result
    recordApplication: protectedProcedure
      .input(z.object({
        patternId: z.number(),
        success: z.boolean(),
      }))
      .mutation(async ({ input }) => {
        await implicitLearningService.recordPatternApplication(input.patternId, input.success);
        return { success: true };
      }),

    // Generate insights
    insights: protectedProcedure
      .input(z.object({ householdId: z.number() }))
      .query(async ({ input }) => {
        return await implicitLearningService.generateInsights(input.householdId);
      }),

    // Get learning statistics
    statistics: protectedProcedure
      .input(z.object({ householdId: z.number() }))
      .query(async ({ input }) => {
        return await implicitLearningService.getStatistics(input.householdId);
      }),
  }),

  // ============================================================================
  // COMMUNICATION ADAPTATION
  // ============================================================================
  
  communication: router({
    // Get or create profile
    profile: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        memberId: z.number().optional(),
        contactId: z.string().optional(),
      }))
      .query(async ({ input }) => {
        return await communicationAdaptationService.getOrCreateProfile(
          input.householdId,
          input.memberId,
          input.contactId
        );
      }),

    // Update profile from observation
    updateProfile: protectedProcedure
      .input(z.object({
        profileId: z.number(),
        messageContent: z.string(),
        channel: z.enum(['email', 'sms', 'whatsapp', 'slack', 'in_app', 'voice']),
        context: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await communicationAdaptationService.updateProfileFromObservation(input.profileId, {
          messageContent: input.messageContent,
          channel: input.channel as CommunicationChannel,
          context: input.context,
          timestamp: new Date(),
        });
        return { success: true };
      }),

    // Adapt a message
    adaptMessage: protectedProcedure
      .input(z.object({
        content: z.string(),
        profileId: z.number(),
        channel: z.enum(['email', 'sms', 'whatsapp', 'slack', 'in_app', 'voice']).optional(),
        context: z.string().optional(),
        forceTone: z.enum(['formal', 'professional', 'casual', 'friendly', 'urgent', 'empathetic', 'direct']).optional(),
      }))
      .mutation(async ({ input }) => {
        return await communicationAdaptationService.adaptMessage(input.content, input.profileId, {
          channel: input.channel as CommunicationChannel | undefined,
          context: input.context,
          forceTone: input.forceTone as CommunicationTone | undefined,
        });
      }),

    // Generate from template
    generateFromTemplate: protectedProcedure
      .input(z.object({
        templateType: z.string(),
        variables: z.record(z.string()),
        profileId: z.number(),
      }))
      .mutation(async ({ input }) => {
        return await communicationAdaptationService.generateFromTemplate(
          input.templateType,
          input.variables,
          input.profileId
        );
      }),

    // Get all profiles
    profiles: protectedProcedure
      .input(z.object({ householdId: z.number() }))
      .query(async ({ input }) => {
        return await communicationAdaptationService.getProfiles(input.householdId);
      }),

    // Get templates
    templates: protectedProcedure
      .input(z.object({ householdId: z.number().optional() }))
      .query(async ({ input }) => {
        return await communicationAdaptationService.getTemplates(input.householdId);
      }),

    // Get statistics
    statistics: protectedProcedure
      .input(z.object({ householdId: z.number() }))
      .query(async ({ input }) => {
        return await communicationAdaptationService.getStatistics(input.householdId);
      }),
  }),

  // ============================================================================
  // COMBINED STATISTICS
  // ============================================================================
  
  statistics: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ input }) => {
      const [rulesStats, learningStats, commStats] = await Promise.all([
        rulesEngine.getStatistics(input.householdId),
        implicitLearningService.getStatistics(input.householdId),
        communicationAdaptationService.getStatistics(input.householdId),
      ]);

      return {
        rules: rulesStats,
        learning: learningStats,
        communication: commStats,
        summary: {
          totalRules: rulesStats.totalRules,
          totalPatterns: learningStats.totalPatterns,
          totalProfiles: commStats.totalProfiles,
          avgLearningConfidence: learningStats.avgConfidence,
          avgCommunicationConfidence: commStats.avgConfidence,
        },
      };
    }),
});
