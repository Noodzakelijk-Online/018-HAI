import { z } from "zod";
import { protectedProcedure, router } from "../../_core/trpc";
import { logActivity } from "../../services/activityTracker";

/**
 * Engine Test Router
 * 
 * Provides endpoints to manually trigger test activities for the HAI Dashboard
 * This allows you to see how activities appear on the dashboard
 */
export const engineTestRouter = router({
  /**
   * Test Communication Engine activity
   */
  testCommunication: protectedProcedure
    .input(
      z.object({
        recipient: z.string(),
        subject: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await logActivity({
        engine: "communication",
        action: "send_email",
        title: `Email sent to ${input.recipient}`,
        description: `Subject: ${input.subject}`,
        metadata: {
          recipient: input.recipient,
          subject: input.subject,
          testMode: true,
        },
        impact: "medium",
        status: "completed",
        userId: ctx.user.id,
      });

      return {
        success: true,
        message: "Communication activity logged successfully",
      };
    }),

  /**
   * Test Decision Engine activity
   */
  testDecision: protectedProcedure
    .input(
      z.object({
        description: z.string(),
        outcome: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await logActivity({
        engine: "decision",
        action: "autonomous_decision",
        title: "Autonomous decision made",
        description: input.description,
        metadata: {
          outcome: input.outcome,
          confidence: 0.85,
          reasoning: "Based on user preferences and historical patterns",
          testMode: true,
        },
        impact: "high",
        status: "completed",
        userId: ctx.user.id,
      });

      return {
        success: true,
        message: "Decision activity logged successfully",
      };
    }),

  /**
   * Test Task Engine activity
   */
  testTask: protectedProcedure
    .input(
      z.object({
        title: z.string(),
        description: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await logActivity({
        engine: "task",
        action: "complete_task",
        title: input.title,
        description: input.description,
        metadata: {
          taskType: "automation",
          executionTime: 45, // seconds
          testMode: true,
        },
        impact: "medium",
        status: "completed",
        userId: ctx.user.id,
      });

      return {
        success: true,
        message: "Task activity logged successfully",
      };
    }),

  /**
   * Create sample activities for all engines
   */
  createSampleActivities: protectedProcedure.mutation(async ({ ctx }) => {
    const activities = [
      // Communication activities
      {
        engine: "communication" as const,
        action: "send_email",
        title: "Email sent to john@example.com",
        description: "Subject: Monthly budget review",
        metadata: { recipient: "john@example.com", subject: "Monthly budget review" },
        impact: "medium" as const,
        status: "completed" as const,
        userId: ctx.user.id,
      },
      {
        engine: "communication" as const,
        action: "create_calendar_event",
        title: "Created calendar event: Team Meeting",
        description: "Scheduled for tomorrow at 2 PM",
        metadata: { eventTitle: "Team Meeting", date: new Date(Date.now() + 86400000).toISOString() },
        impact: "low" as const,
        status: "completed" as const,
        userId: ctx.user.id,
      },
      // Decision activities
      {
        engine: "decision" as const,
        action: "autonomous_decision",
        title: "Approved expense request",
        description: "Approved $150 software subscription based on budget policy",
        metadata: { amount: 150, category: "software", confidence: 0.92 },
        impact: "high" as const,
        status: "completed" as const,
        userId: ctx.user.id,
      },
      {
        engine: "decision" as const,
        action: "autonomous_decision",
        title: "Rescheduled low-priority meeting",
        description: "Moved meeting to next week due to conflicting high-priority task",
        metadata: { originalDate: "2024-12-01", newDate: "2024-12-08", confidence: 0.88 },
        impact: "medium" as const,
        status: "completed" as const,
        userId: ctx.user.id,
      },
      // Task activities
      {
        engine: "task" as const,
        action: "complete_task",
        title: "Completed: Backup important documents",
        description: "Backed up 250 files to cloud storage",
        metadata: { fileCount: 250, size: "1.2 GB", executionTime: 120 },
        impact: "medium" as const,
        status: "completed" as const,
        userId: ctx.user.id,
      },
      {
        engine: "task" as const,
        action: "complete_task",
        title: "Completed: Generate weekly report",
        description: "Analyzed data and created summary report",
        metadata: { reportType: "weekly", dataPoints: 500, executionTime: 60 },
        impact: "high" as const,
        status: "completed" as const,
        userId: ctx.user.id,
      },
    ];

    for (const activity of activities) {
      await logActivity(activity);
    }

    return {
      success: true,
      message: `Created ${activities.length} sample activities`,
      count: activities.length,
    };
  }),
});
