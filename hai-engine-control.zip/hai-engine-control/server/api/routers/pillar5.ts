/**
 * PILLAR 5 API ROUTER
 * 
 * "Deeply Embedded, Not Surface-Level"
 * 
 * Exposes APIs for:
 * - Universal Connectors
 * - Integration Management
 */

import { z } from 'zod';
import { router, protectedProcedure } from '../../_core/trpc';
import { universalConnectorsService, type ConnectorType, type ConnectorStatus, type AuthType } from '../../services/pillar5/UniversalConnectors';

// ============================================================================
// ROUTER
// ============================================================================

export const pillar5Router = router({
  // ============================================================================
  // CONNECTORS
  // ============================================================================
  
  connectors: router({
    // Create connector
    create: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        type: z.enum(['email', 'calendar', 'financial', 'smart_home', 'communication', 'shopping', 'health', 'transportation', 'utilities', 'custom']),
        provider: z.string(),
        name: z.string(),
        description: z.string().optional(),
        authType: z.enum(['oauth2', 'api_key', 'basic', 'token', 'custom']),
        credentials: z.object({
          accessToken: z.string().optional(),
          refreshToken: z.string().optional(),
          apiKey: z.string().optional(),
          expiresAt: z.date().optional(),
          scopes: z.array(z.string()).optional(),
        }).optional(),
        config: z.record(z.any()).optional(),
        syncInterval: z.number().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await universalConnectorsService.createConnector(input.householdId, {
          ...input,
          type: input.type as ConnectorType,
          authType: input.authType as AuthType,
          createdBy: ctx.user.id,
        });
      }),

    // Get connector by ID
    get: protectedProcedure
      .input(z.object({ connectorId: z.number() }))
      .query(async ({ input }) => {
        return await universalConnectorsService.getConnector(input.connectorId);
      }),

    // List connectors
    list: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        type: z.enum(['email', 'calendar', 'financial', 'smart_home', 'communication', 'shopping', 'health', 'transportation', 'utilities', 'custom']).optional(),
        status: z.enum(['active', 'inactive', 'error', 'pending', 'expired']).optional(),
        isEnabled: z.boolean().optional(),
      }))
      .query(async ({ input }) => {
        return await universalConnectorsService.getConnectors(input.householdId, {
          type: input.type as ConnectorType | undefined,
          status: input.status as ConnectorStatus | undefined,
          isEnabled: input.isEnabled,
        });
      }),

    // Update connector
    update: protectedProcedure
      .input(z.object({
        connectorId: z.number(),
        name: z.string().optional(),
        description: z.string().optional(),
        config: z.record(z.any()).optional(),
        syncInterval: z.number().optional(),
        isEnabled: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { connectorId, ...updates } = input;
        return await universalConnectorsService.updateConnector(connectorId, updates);
      }),

    // Update credentials
    updateCredentials: protectedProcedure
      .input(z.object({
        connectorId: z.number(),
        credentials: z.object({
          accessToken: z.string().optional(),
          refreshToken: z.string().optional(),
          apiKey: z.string().optional(),
          expiresAt: z.date().optional(),
          scopes: z.array(z.string()).optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        return await universalConnectorsService.updateCredentials(
          input.connectorId,
          input.credentials
        );
      }),

    // Delete connector
    delete: protectedProcedure
      .input(z.object({ connectorId: z.number() }))
      .mutation(async ({ input }) => {
        const success = await universalConnectorsService.deleteConnector(input.connectorId);
        return { success };
      }),

    // Sync connector
    sync: protectedProcedure
      .input(z.object({ connectorId: z.number() }))
      .mutation(async ({ input }) => {
        return await universalConnectorsService.syncConnector(input.connectorId);
      }),

    // Sync all connectors
    syncAll: protectedProcedure
      .input(z.object({ householdId: z.number() }))
      .mutation(async ({ input }) => {
        return await universalConnectorsService.syncAllConnectors(input.householdId);
      }),

    // Get events
    events: protectedProcedure
      .input(z.object({
        connectorId: z.number(),
        limit: z.number().optional(),
      }))
      .query(async ({ input }) => {
        return await universalConnectorsService.getEvents(input.connectorId, input.limit);
      }),

    // Set status
    setStatus: protectedProcedure
      .input(z.object({
        connectorId: z.number(),
        status: z.enum(['active', 'inactive', 'error', 'pending', 'expired']),
        error: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await universalConnectorsService.setStatus(
          input.connectorId,
          input.status as ConnectorStatus,
          input.error
        );
        return { success: true };
      }),
  }),

  // ============================================================================
  // TEMPLATES
  // ============================================================================
  
  templates: router({
    // List all templates
    list: protectedProcedure
      .input(z.object({
        type: z.enum(['email', 'calendar', 'financial', 'smart_home', 'communication', 'shopping', 'health', 'transportation', 'utilities', 'custom']).optional(),
      }).optional())
      .query(async ({ input }) => {
        return universalConnectorsService.getTemplates(input?.type as ConnectorType | undefined);
      }),
  }),

  // ============================================================================
  // STATISTICS
  // ============================================================================
  
  statistics: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ input }) => {
      return await universalConnectorsService.getStatistics(input.householdId);
    }),
});
