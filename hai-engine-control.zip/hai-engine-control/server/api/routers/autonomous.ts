/**
 * Autonomous Framework tRPC Router
 * 
 * Exposes autonomous system metrics, decision history, and control APIs
 */

import { z } from 'zod';
import { publicProcedure, protectedProcedure, router } from '../../_core/trpc';
import {
  makeAutonomousDecision,
  recordDecisionOutcome,
  getAutonomousMetrics,
  learnFrom,
  getLearningInsights,
  recordOptimizationMetric,
  getOptimizationStatus
} from '../../services/autonomous';

export const autonomousRouter = router({
  // Get overall autonomous system metrics
  getMetrics: protectedProcedure.query(async () => {
    return getAutonomousMetrics();
  }),
  
  // Get learning pipeline insights
  getLearningInsights: protectedProcedure.query(async () => {
    return getLearningInsights();
  }),
  
  // Get optimization status
  getOptimizationStatus: protectedProcedure.query(async () => {
    return getOptimizationStatus();
  }),
  
  // Make an autonomous decision
  makeDecision: protectedProcedure
    .input(z.object({
      type: z.string(),
      data: z.record(z.any()),
      constraints: z.record(z.any()).optional()
    }))
    .mutation(async ({ input }) => {
      return makeAutonomousDecision(input);
    }),
  
  // Record decision outcome for learning
  recordOutcome: protectedProcedure
    .input(z.object({
      decisionId: z.string(),
      success: z.boolean(),
      actualResult: z.any(),
      metrics: z.object({
        duration: z.number(),
        cost: z.number(),
        quality: z.number()
      }),
      errorMessage: z.string().optional()
    }))
    .mutation(async ({ input }) => {
      recordDecisionOutcome(input);
      return { success: true };
    }),
  
  // Feed learning event
  learnFromEvent: protectedProcedure
    .input(z.object({
      type: z.enum(['task_completed', 'error_occurred', 'user_feedback', 'performance_metric']),
      source: z.string(),
      data: z.record(z.any()),
      timestamp: z.date().optional()
    }))
    .mutation(async ({ input }) => {
      learnFrom({
        ...input,
        timestamp: input.timestamp || new Date()
      });
      return { success: true };
    }),
  
  // Record optimization metric
  recordMetric: protectedProcedure
    .input(z.object({
      name: z.string(),
      value: z.number()
    }))
    .mutation(async ({ input }) => {
      recordOptimizationMetric(input.name, input.value);
      return { success: true };
    }),
  
  // Get combined dashboard data
  getDashboard: protectedProcedure.query(async () => {
    const metrics = getAutonomousMetrics();
    const learning = getLearningInsights();
    const optimization = getOptimizationStatus();
    
    return {
      metrics,
      learning,
      optimization,
      timestamp: new Date()
    };
  })
});
