import { z } from 'zod';
import { publicProcedure, router } from '../../_core/trpc';
import { AnalyticsEngineEnhanced } from '../../services/AnalyticsEngineEnhanced';
import { EventBus } from '../../services/EventBus';

const analyticsEngine = new AnalyticsEngineEnhanced(EventBus);

export const analyticsRouter = router({
  // Time-series forecasting
  forecast: publicProcedure
    .input(z.object({
      data: z.array(z.object({
        timestamp: z.date(),
        value: z.number(),
        metadata: z.record(z.string(), z.any()).optional(),
      })),
      periods: z.number().min(1).max(365),
      method: z.enum(['sma', 'ema', 'arima']).default('ema'),
    }))
    .mutation(async ({ input, ctx }) => {
      return await analyticsEngine.forecastTimeSeries(input.data, input.periods, input.method);
    }),

  // Anomaly detection
  detectAnomalies: publicProcedure
    .input(z.object({
      data: z.array(z.object({
        timestamp: z.date(),
        value: z.number(),
        metadata: z.record(z.string(), z.any()).optional(),
      })),
      threshold: z.number().min(1).max(10).default(3),
    }))
    .mutation(async ({ input, ctx }) => {
      return await analyticsEngine.detectAnomalies(input.data, input.threshold);
    }),

  // Dashboard management
  createDashboard: publicProcedure
    .input(z.object({
      name: z.string().min(1).max(255),
      description: z.string().optional(),
      widgets: z.array(z.object({
        id: z.string(),
        type: z.enum(['chart', 'metric', 'table', 'gauge', 'heatmap']),
        title: z.string(),
        dataSource: z.string(),
        config: z.record(z.string(), z.any()),
        position: z.object({
          x: z.number(),
          y: z.number(),
          w: z.number(),
          h: z.number(),
        }),
      })),
      refreshInterval: z.number().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      return await analyticsEngine.createDashboard(input);
    }),

  updateDashboard: publicProcedure
    .input(z.object({
      id: z.string(),
      updates: z.object({
        name: z.string().optional(),
        description: z.string().optional(),
        widgets: z.array(z.any()).optional(),
        refreshInterval: z.number().optional(),
      }),
    }))
    .mutation(async ({ input, ctx }) => {
      return await analyticsEngine.updateDashboard(input.id, input.updates);
    }),

  getDashboards: publicProcedure
    .query(async () => {
      return analyticsEngine.getDashboards();
    }),

  // Export data
  exportData: publicProcedure
    .input(z.object({
      data: z.array(z.any()),
      format: z.enum(['pdf', 'excel', 'csv']),
      options: z.record(z.string(), z.any()).optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const result = await analyticsEngine.exportData(input.data, input.format, input.options);
      // Return base64 encoded buffer for client download
      return {
        ...result,
        buffer: result.buffer.toString('base64'),
      };
    }),

  // Report scheduling
  scheduleReport: publicProcedure
    .input(z.object({
      name: z.string(),
      dashboardId: z.string(),
      frequency: z.enum(['daily', 'weekly', 'monthly']),
      recipients: z.array(z.string().email()),
      format: z.enum(['pdf', 'excel', 'csv']),
      nextRun: z.date(),
    }))
    .mutation(async ({ input, ctx }) => {
      return await analyticsEngine.scheduleReport(input);
    }),

  // A/B testing
  createABTest: publicProcedure
    .input(z.object({
      name: z.string(),
      variants: z.array(z.object({
        id: z.string(),
        name: z.string(),
        weight: z.number().min(0).max(1),
      })),
      metrics: z.array(z.string()),
      startDate: z.date(),
      endDate: z.date().optional(),
      status: z.enum(['draft', 'running', 'paused', 'completed']),
    }))
    .mutation(async ({ input, ctx }) => {
      return await analyticsEngine.createABTest(input);
    }),

  getABTestResults: publicProcedure
    .input(z.object({
      testId: z.string(),
    }))
    .query(async ({ input }) => {
      return await analyticsEngine.getABTestResults(input.testId);
    }),

  // Cohort analysis
  createCohort: publicProcedure
    .input(z.object({
      name: z.string(),
      criteria: z.record(z.string(), z.any()),
    }))
    .mutation(async ({ input, ctx }) => {
      return await analyticsEngine.createCohort(input);
    }),

  analyzeCohort: publicProcedure
    .input(z.object({
      cohortId: z.string(),
    }))
    .query(async ({ input }) => {
      return await analyticsEngine.analyzeCohort(input.cohortId);
    }),
});
