import { z } from "zod";
import { protectedProcedure, router } from "../../_core/trpc";
import {
  logActivity,
  getTodaysActivities,
  getActivitiesByDateRange,
  getActivitiesByEngine,
  getTodaysStatistics,
  getActivityTimeline,
  getRecentActivities,
  getActivitiesSinceLastVisit,
} from "../../services/activityTracker";
import { updateUserDashboardVisit } from "../../db";
import { cacheService, CacheKeys, CacheTTL } from "../../services/cacheService";

export const activitiesRouter = router({
  /**
   * Get activities since last dashboard visit
   */
  getSinceLastVisit: protectedProcedure.query(async ({ ctx }) => {
    const activities = await getActivitiesSinceLastVisit(
      ctx.user.id,
      ctx.user.lastDashboardVisit
    );
    return activities;
  }),

  /**
   * Update user's last dashboard visit timestamp
   */
  updateDashboardVisit: protectedProcedure.mutation(async ({ ctx }) => {
    await updateUserDashboardVisit(ctx.user.id);
    return { success: true };
  }),

  /**
   * Get today's activities (cached for 30 seconds)
   */
  getTodays: protectedProcedure.query(async ({ ctx }) => {
    const cacheKey = CacheKeys.todaysActivities(ctx.user.id);
    return cacheService.getOrFetch(
      cacheKey,
      () => getTodaysActivities(ctx.user.id),
      { ttl: CacheTTL.SHORT, staleWhileRevalidate: true }
    );
  }),

  /**
   * Get activities by date range
   */
  getByDateRange: protectedProcedure
    .input(
      z.object({
        startDate: z.date(),
        endDate: z.date(),
      })
    )
    .query(async ({ input, ctx }) => {
      const activities = await getActivitiesByDateRange(
        ctx.user.id,
        input.startDate,
        input.endDate
      );
      return activities;
    }),

  /**
   * Get activities by engine
   */
  getByEngine: protectedProcedure
    .input(
      z.object({
        engine: z.enum(["communication", "decision", "task", "system"]),
      })
    )
    .query(async ({ input, ctx }) => {
      const activities = await getActivitiesByEngine(ctx.user.id, input.engine);
      return activities;
    }),

  /**
   * Get today's statistics (cached for 30 seconds)
   */
  getTodaysStats: protectedProcedure.query(async ({ ctx }) => {
    const cacheKey = CacheKeys.dashboardStats(ctx.user.id);
    return cacheService.getOrFetch(
      cacheKey,
      () => getTodaysStatistics(ctx.user.id),
      { ttl: CacheTTL.SHORT, staleWhileRevalidate: true }
    );
  }),

  /**
   * Get activity timeline for today
   */
  getTimeline: protectedProcedure
    .input(
      z.object({
        date: z.date().optional(),
      })
    )
    .query(async ({ input, ctx }) => {
      const date = input.date || new Date();
      const timeline = await getActivityTimeline(ctx.user.id, date);
      return timeline;
    }),

  /**
   * Get recent activities
   */
  getRecent: protectedProcedure
    .input(
      z.object({
        limit: z.number().optional().default(50),
      })
    )
    .query(async ({ input, ctx }) => {
      const activities = await getRecentActivities(ctx.user.id, input.limit);
      return activities;
    }),

  /**
   * Undo an activity
   * Marks the activity as undone and logs a new activity
   */
  undo: protectedProcedure
    .input(
      z.object({
        activityId: z.number(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // Log an undo activity
      await logActivity({
        engine: "system",
        action: "undo_activity",
        title: `Undid activity #${input.activityId}`,
        description: `User manually undid activity #${input.activityId}`,
        metadata: JSON.stringify({ originalActivityId: input.activityId }),
        impact: "low",
        status: "completed",
        userId: ctx.user.id,
      });
      
      // Invalidate activity caches
      cacheService.invalidatePattern(`activities:${ctx.user.id}`);
      cacheService.delete(CacheKeys.todaysActivities(ctx.user.id));
      cacheService.delete(CacheKeys.dashboardStats(ctx.user.id));
      
      return { success: true };
    }),

  /**
   * Modify an activity
   * Logs a modification action
   */
  modify: protectedProcedure
    .input(
      z.object({
        activityId: z.number(),
        newTitle: z.string().optional(),
        newDescription: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // Log a modify activity
      await logActivity({
        engine: "system",
        action: "modify_activity",
        title: `Modified activity #${input.activityId}`,
        description: `User manually modified activity #${input.activityId}`,
        metadata: JSON.stringify({
          originalActivityId: input.activityId,
          newTitle: input.newTitle,
          newDescription: input.newDescription,
        }),
        impact: "low",
        status: "completed",
        userId: ctx.user.id,
      });
      
      // Invalidate activity caches
      cacheService.invalidatePattern(`activities:${ctx.user.id}`);
      cacheService.delete(CacheKeys.todaysActivities(ctx.user.id));
      cacheService.delete(CacheKeys.dashboardStats(ctx.user.id));
      
      return { success: true };
    }),

  /**
   * Log a new activity (for testing/manual logging)
   * Invalidates cache on success
   */
  log: protectedProcedure
    .input(
      z.object({
        engine: z.enum(["communication", "decision", "task", "system"]),
        action: z.string(),
        title: z.string(),
        description: z.string().optional(),
        metadata: z.any().optional(),
        impact: z.string().optional(),
        status: z.enum(["completed", "in_progress", "failed"]),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const activity = await logActivity({
        ...input,
        userId: ctx.user.id,
      });
      
      // Invalidate activity caches for this user
      cacheService.invalidatePattern(`activities:${ctx.user.id}`);
      cacheService.delete(CacheKeys.todaysActivities(ctx.user.id));
      cacheService.delete(CacheKeys.dashboardStats(ctx.user.id));
      
      return { success: true, activity };
    }),
});
