import { z } from "zod";
import { protectedProcedure, router } from "../../_core/trpc";
import { LLMService } from "../../services/LLMService";
import { getDb } from "../../db";
import { conversations, InsertConversation, messages, InsertMessage } from "../../../drizzle/schema";
import { eq, and, desc } from "drizzle-orm";

export const chatRouter = router({
  /**
   * Send a message and get AI response
   */
  sendMessage: protectedProcedure
    .input(
      z.object({
        message: z.string().min(1),
        conversationId: z.string().optional(),
        engineType: z.enum(['general', 'selfModel', 'decision', 'task', 'knowledge']).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { message, conversationId, engineType } = input;
      const userId = ctx.user.id;

      // Get AI response
      const result = await LLMService.chat({
        userId,
        message,
        conversationId,
        engineType,
      });

      // Store conversation and messages in database
      const db = await getDb();
      if (db) {
        try {
          // Ensure conversation exists
          if (!conversationId) {
            await db.insert(conversations).values({
              id: result.conversationId,
              userId,
              title: message.substring(0, 100), // Use first message as title
              engineType: engineType || 'general',
            });
          }

          // Store user message
          await db.insert(messages).values({
            conversationId: result.conversationId,
            role: 'user',
            content: message,
          });

          // Store assistant response
          await db.insert(messages).values({
            conversationId: result.conversationId,
            role: 'assistant',
            content: result.response,
          });
        } catch (error) {
          console.error('[Chat] Error storing messages:', error);
          // Don't throw - allow chat to continue even if storage fails
        }
      }

      return result;
    }),

  /**
   * Get conversation history
   */
  getConversation: protectedProcedure
    .input(z.object({ conversationId: z.string() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return null;

      const conversation = await db
        .select()
        .from(conversations)
        .where(
          and(
            eq(conversations.id, input.conversationId),
            eq(conversations.userId, ctx.user.id)
          )
        )
        .limit(1);

      if (conversation.length === 0) return null;

      const conversationMessages = await db
        .select()
        .from(messages)
        .where(eq(messages.conversationId, input.conversationId))
        .orderBy(messages.createdAt);

      return {
        ...conversation[0],
        messages: conversationMessages,
      };
    }),

  /**
   * List all conversations for current user
   */
  listConversations: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];

    const userConversations = await db
      .select()
      .from(conversations)
      .where(eq(conversations.userId, ctx.user.id))
      .orderBy(desc(conversations.updatedAt))
      .limit(50);

    return userConversations;
  }),

  /**
   * Delete a conversation
   */
  deleteConversation: protectedProcedure
    .input(z.object({ conversationId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return { success: false };

      // Delete messages first (foreign key constraint)
      await db
        .delete(messages)
        .where(eq(messages.conversationId, input.conversationId));

      // Delete conversation
      await db
        .delete(conversations)
        .where(
          and(
            eq(conversations.id, input.conversationId),
            eq(conversations.userId, ctx.user.id)
          )
        );

      // Clear from LLM service memory
      LLMService.clearConversation(input.conversationId);

      return { success: true };
    }),

  /**
   * Analyze text without storing in conversation
   */
  analyze: protectedProcedure
    .input(
      z.object({
        text: z.string().min(1),
        context: z.string().optional(),
        engineType: z.enum(['general', 'selfModel', 'decision', 'task', 'knowledge']).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const result = await LLMService.analyze({
        text: input.text,
        context: input.context,
        engineType: input.engineType,
      });

      return result;
    }),
});
