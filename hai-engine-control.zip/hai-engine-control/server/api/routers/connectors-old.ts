import { z } from "zod";
import { protectedProcedure, router } from "../../_core/trpc";
import { ConnectorRegistry } from "../../services/connectors/ConnectorRegistry";
import { EmailConnector } from "../../services/connectors/EmailConnector";
import { CalendarConnector } from "../../services/connectors/CalendarConnector";
import { SlackConnector } from "../../services/connectors/SlackConnector";

export const connectorsRouter = router({
  /**
   * List all registered connectors
   */
  list: protectedProcedure.query(() => {
    return ConnectorRegistry.getAllConnectorInfo();
  }),

  /**
   * Get connector statistics
   */
  stats: protectedProcedure.query(() => {
    return ConnectorRegistry.getStats();
  }),

  /**
   * Get connector details
   */
  get: protectedProcedure
    .input(z.object({ connectorId: z.string() }))
    .query(({ input }) => {
      const info = ConnectorRegistry.getConnectorInfo(input.connectorId);
      if (!info) {
        throw new Error(`Connector not found: ${input.connectorId}`);
      }
      return info;
    }),

  /**
   * Register a new connector
   */
  register: protectedProcedure
    .input(
      z.object({
        type: z.enum(['email', 'calendar', 'slack']),
        config: z.object({
          id: z.string(),
          name: z.string(),
          description: z.string(),
          authType: z.enum(['oauth2', 'api_key', 'bearer_token', 'basic_auth', 'none']),
          credentials: z.record(z.string(), z.string()).optional(),
          rateLimit: z.number().optional(),
          config: z.any().optional(),
        }),
      })
    )
    .mutation(({ input }) => {
      let connector;
      
      switch (input.type) {
        case 'email':
          connector = new EmailConnector(input.config as any);
          break;
        case 'calendar':
          connector = new CalendarConnector(input.config as any);
          break;
        case 'slack':
          connector = new SlackConnector(input.config as any);
          break;
        default:
          throw new Error(`Unknown connector type: ${input.type}`);
      }

      ConnectorRegistry.register(connector);
      
      return {
        success: true,
        connectorId: input.config.id,
      };
    }),

  /**
   * Unregister a connector
   */
  unregister: protectedProcedure
    .input(z.object({ connectorId: z.string() }))
    .mutation(async ({ input }) => {
      await ConnectorRegistry.unregister(input.connectorId);
      return { success: true };
    }),

  /**
   * Connect a connector
   */
  connect: protectedProcedure
    .input(z.object({ connectorId: z.string() }))
    .mutation(async ({ input }) => {
      await ConnectorRegistry.connect(input.connectorId);
      return { success: true };
    }),

  /**
   * Disconnect a connector
   */
  disconnect: protectedProcedure
    .input(z.object({ connectorId: z.string() }))
    .mutation(async ({ input }) => {
      await ConnectorRegistry.disconnect(input.connectorId);
      return { success: true };
    }),

  /**
   * Health check for a connector
   */
  healthCheck: protectedProcedure
    .input(z.object({ connectorId: z.string() }))
    .mutation(async ({ input }) => {
      const health = await ConnectorRegistry.healthCheck(input.connectorId);
      return health;
    }),

  /**
   * Health check for all connectors
   */
  healthCheckAll: protectedProcedure.mutation(async () => {
    const results = await ConnectorRegistry.healthCheckAll();
    return Object.fromEntries(results);
  }),

  /**
   * Email connector: send email
   */
  emailSend: protectedProcedure
    .input(
      z.object({
        connectorId: z.string(),
        to: z.array(z.string()),
        subject: z.string(),
        body: z.string(),
        html: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const connector = ConnectorRegistry.get(input.connectorId);
      if (!connector || !(connector instanceof EmailConnector)) {
        throw new Error('Email connector not found');
      }

      return await connector.send({
        to: input.to,
        subject: input.subject,
        body: input.body,
        html: input.html,
      });
    }),

  /**
   * Calendar connector: create event
   */
  calendarCreateEvent: protectedProcedure
    .input(
      z.object({
        connectorId: z.string(),
        title: z.string(),
        description: z.string().optional(),
        start: z.string(),
        end: z.string(),
        location: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const connector = ConnectorRegistry.get(input.connectorId);
      if (!connector || !(connector instanceof CalendarConnector)) {
        throw new Error('Calendar connector not found');
      }

      return await connector.createEvent({
        title: input.title,
        description: input.description,
        start: new Date(input.start),
        end: new Date(input.end),
        location: input.location,
      });
    }),

  /**
   * Slack connector: send message
   */
  slackSendMessage: protectedProcedure
    .input(
      z.object({
        connectorId: z.string(),
        channel: z.string(),
        text: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const connector = ConnectorRegistry.get(input.connectorId);
      if (!connector || !(connector instanceof SlackConnector)) {
        throw new Error('Slack connector not found');
      }

      return await connector.sendMessage({
        channel: input.channel,
        text: input.text,
      });
    }),
});
