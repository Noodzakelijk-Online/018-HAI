import { z } from "zod";
import { protectedProcedure, router } from "../../_core/trpc";
import { CommunicationEngine } from "../../services/CommunicationEngine";

/**
 * Communication router
 */
export const communicationRouter = router({
  /**
   * Send a message
   */
  sendMessage: protectedProcedure
    .input(z.object({
      channel: z.enum(["email", "notification", "sms", "chat"]),
      recipient: z.string(),
      subject: z.string().optional(),
      body: z.string(),
      templateId: z.number().optional(),
      metadata: z.record(z.string(), z.unknown()).optional(),
    }))
    .mutation(async ({ input }) => {
      return await CommunicationEngine.sendMessage({
        channel: input.channel,
        recipient: input.recipient,
        subject: input.subject,
        body: input.body,
        templateId: input.templateId,
        metadata: input.metadata,
      });
    }),

  /**
   * Get all messages with optional filtering
   */
  getMessages: protectedProcedure
    .input(z.object({
      channel: z.string().optional(),
      status: z.string().optional(),
      limit: z.number().optional(),
    }).optional())
    .query(async ({ input }) => {
      return await CommunicationEngine.getMessages(input);
    }),

  /**
   * Get message by ID
   */
  getMessageById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return await CommunicationEngine.getMessageById(input.id);
    }),

  /**
   * Get all templates
   */
  getTemplates: protectedProcedure
    .input(z.object({
      channel: z.string().optional(),
    }).optional())
    .query(async ({ input }) => {
      return await CommunicationEngine.getTemplates(input?.channel);
    }),

  /**
   * Create a template
   */
  createTemplate: protectedProcedure
    .input(z.object({
      name: z.string(),
      description: z.string().optional(),
      channel: z.enum(["email", "notification", "sms", "chat"]),
      subject: z.string().optional(),
      body: z.string(),
      variables: z.array(z.string()).optional(),
      category: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      return await CommunicationEngine.createTemplate({
        name: input.name,
        description: input.description,
        channel: input.channel,
        subject: input.subject,
        body: input.body,
        variables: input.variables,
        category: input.category,
      });
    }),

  /**
   * Render template with variables
   */
  renderTemplate: protectedProcedure
    .input(z.object({
      templateId: z.number(),
      variables: z.record(z.string(), z.string()),
    }))
    .query(async ({ input }) => {
      return await CommunicationEngine.renderTemplate(input.templateId, input.variables);
    }),

  /**
   * Get delivery statistics
   */
  getStats: protectedProcedure.query(async () => {
    return await CommunicationEngine.getStats();
  }),
});
