import { z } from "zod";
import { protectedProcedure, router } from "../../_core/trpc";
import { PlaybookEngine } from "../../services/PlaybookEngine";

/**
 * Playbook router
 */
export const playbookRouter = router({
  /**
   * Get all playbooks
   */
  getAll: protectedProcedure.query(async () => {
    return await PlaybookEngine.getAllPlaybooks();
  }),

  /**
   * Get playbook by ID
   */
  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return await PlaybookEngine.getPlaybookById(input.id);
    }),

  /**
   * Create new playbook
   */
  create: protectedProcedure
    .input(z.object({
      name: z.string(),
      description: z.string().optional(),
      category: z.string().optional(),
      definition: z.object({
        steps: z.array(z.object({
          id: z.string(),
          name: z.string(),
          type: z.enum(['action', 'condition', 'loop', 'parallel']),
          action: z.string().optional(),
          condition: z.string().optional(),
          onSuccess: z.string().optional(),
          onFailure: z.string().optional(),
          params: z.record(z.string(), z.unknown()).optional(),
        })),
        variables: z.record(z.string(), z.unknown()).optional(),
        triggers: z.array(z.string()).optional(),
        timeout: z.number().optional(),
      }),
      metadata: z.record(z.string(), z.unknown()).optional(),
    }))
    .mutation(async ({ input }) => {
      return await PlaybookEngine.createPlaybook({
        name: input.name,
        description: input.description,
        category: input.category,
        definition: input.definition as any,
        metadata: input.metadata,
      });
    }),

  /**
   * Execute playbook
   */
  execute: protectedProcedure
    .input(z.object({
      playbookId: z.number(),
      taskId: z.number().optional(),
      initialContext: z.record(z.string(), z.unknown()).optional(),
    }))
    .mutation(async ({ input }) => {
      return await PlaybookEngine.executePlaybook({
        playbookId: input.playbookId,
        taskId: input.taskId,
        initialContext: input.initialContext,
      });
    }),

  /**
   * Get execution by ID
   */
  getExecution: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return await PlaybookEngine.getExecutionById(input.id);
    }),

  /**
   * Get executions for a playbook
   */
  getExecutions: protectedProcedure
    .input(z.object({ playbookId: z.number() }))
    .query(async ({ input }) => {
      return await PlaybookEngine.getExecutionsByPlaybookId(input.playbookId);
    }),

  /**
   * Cancel execution
   */
  cancelExecution: protectedProcedure
    .input(z.object({ executionId: z.number() }))
    .mutation(async ({ input }) => {
      await PlaybookEngine.cancelExecution(input.executionId);
      return { success: true };
    }),

  /**
   * Get playbook categories
   */
  getCategories: protectedProcedure.query(async () => {
    const playbooks = await PlaybookEngine.getAllPlaybooks();
    const categories = new Set(playbooks.map(p => p.category).filter(Boolean));
    return Array.from(categories).sort();
  }),
});
