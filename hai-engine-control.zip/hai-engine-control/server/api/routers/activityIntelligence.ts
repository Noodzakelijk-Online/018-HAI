import { z } from "zod";
import { protectedProcedure, router } from "../../_core/trpc";
import { activityIntelligenceService } from "../../services/ActivityIntelligenceService";

export const activityIntelligenceRouter = router({
  /**
   * 1. Predict activity outcome
   */
  predictOutcome: protectedProcedure
    .input(
      z.object({
        activityType: z.string(),
        activityDetails: z.any(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      return activityIntelligenceService.predictOutcome(
        input.activityType,
        input.activityDetails,
        ctx.user.id
      );
    }),

  /**
   * 2. Forecast activity impact
   */
  forecastImpact: protectedProcedure
    .input(
      z.object({
        activityId: z.number(),
      })
    )
    .query(async ({ input, ctx }) => {
      return activityIntelligenceService.forecastImpact(
        input.activityId,
        ctx.user.id
      );
    }),

  /**
   * 3. Calculate ROI for activity type
   */
  calculateROI: protectedProcedure
    .input(
      z.object({
        activityType: z.string(),
      })
    )
    .query(async ({ input, ctx }) => {
      return activityIntelligenceService.calculateROI(
        input.activityType,
        ctx.user.id
      );
    }),

  /**
   * 4. Cluster similar activities
   */
  clusterActivities: protectedProcedure
    .input(
      z.object({
        minClusterSize: z.number().optional().default(3),
      })
    )
    .query(async ({ input, ctx }) => {
      return activityIntelligenceService.clusterActivities(
        ctx.user.id,
        input.minClusterSize
      );
    }),

  /**
   * 5. Get activity recommendations
   */
  recommendActivities: protectedProcedure
    .input(
      z.object({
        context: z.any(),
        limit: z.number().optional().default(5),
      })
    )
    .query(async ({ input, ctx }) => {
      return activityIntelligenceService.recommendActivities(
        ctx.user.id,
        input.context,
        input.limit
      );
    }),

  /**
   * 6. Build dependency graph
   */
  buildDependencyGraph: protectedProcedure.query(async ({ ctx }) => {
    return activityIntelligenceService.buildDependencyGraph(ctx.user.id);
  }),

  /**
   * 7. Track sentiment for activity
   */
  trackSentiment: protectedProcedure
    .input(
      z.object({
        activityId: z.number(),
      })
    )
    .query(async ({ input }) => {
      return activityIntelligenceService.trackSentiment(input.activityId);
    }),

  /**
   * 8. Score activity quality
   */
  scoreQuality: protectedProcedure
    .input(
      z.object({
        activityId: z.number(),
      })
    )
    .query(async ({ input }) => {
      return activityIntelligenceService.scoreQuality(input.activityId);
    }),

  /**
   * 9. Replay activity with scenarios
   */
  replayActivity: protectedProcedure
    .input(
      z.object({
        activityId: z.number(),
        scenarios: z.array(
          z.object({
            name: z.string(),
            parameters: z.any(),
          })
        ),
      })
    )
    .mutation(async ({ input }) => {
      return activityIntelligenceService.replayActivity(
        input.activityId,
        input.scenarios
      );
    }),

  /**
   * 10. Compress activities into summary
   */
  compressActivities: protectedProcedure
    .input(
      z.object({
        startDate: z.date(),
        endDate: z.date(),
      })
    )
    .query(async ({ input, ctx }) => {
      return activityIntelligenceService.compressActivities(
        ctx.user.id,
        input.startDate,
        input.endDate
      );
    }),
});
