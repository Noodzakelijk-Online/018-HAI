import { z } from "zod";
import { router, publicProcedure, protectedProcedure } from "../../_core/trpc";
import { householdLedger } from "../../services/HouseholdLedgerEngine";

export const ledgerRouter = router({
  /**
   * Query ledger events with filters
   */
  query: protectedProcedure
    .input(
      z.object({
        startSeq: z.number().optional(),
        endSeq: z.number().optional(),
        eventType: z.string().optional(),
        actor: z.string().optional(),
        startTime: z.date().optional(),
        endTime: z.date().optional(),
        limit: z.number().max(1000).optional(),
      })
    )
    .query(async ({ input }) => {
      return await householdLedger.queryEvents(input);
    }),

  /**
   * Get ledger statistics
   */
  statistics: protectedProcedure.query(async () => {
    return await householdLedger.getStatistics();
  }),

  /**
   * Verify ledger integrity
   */
  verifyIntegrity: protectedProcedure
    .input(
      z.object({
        startSeq: z.number().optional(),
        endSeq: z.number().optional(),
      })
    )
    .query(async ({ input }) => {
      return await householdLedger.verifyIntegrity(input.startSeq, input.endSeq);
    }),

  /**
   * Replay events to reconstruct state at a specific sequence
   */
  replayToSequence: protectedProcedure
    .input(z.object({ targetSeq: z.number() }))
    .query(async ({ input }) => {
      return await householdLedger.replayToSequence(input.targetSeq);
    }),

  /**
   * Replay events to reconstruct state at a specific timestamp
   */
  replayToTimestamp: protectedProcedure
    .input(z.object({ targetTime: z.date() }))
    .query(async ({ input }) => {
      return await householdLedger.replayToTimestamp(input.targetTime);
    }),

  /**
   * Export ledger to JSON
   */
  export: protectedProcedure
    .input(
      z.object({
        startSeq: z.number().optional(),
        endSeq: z.number().optional(),
      })
    )
    .query(async ({ input }) => {
      return await householdLedger.exportLedger(input.startSeq, input.endSeq);
    }),
});
