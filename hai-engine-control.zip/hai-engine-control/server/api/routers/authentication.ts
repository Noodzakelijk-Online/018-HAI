import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../../_core/trpc";
import { sendPasswordResetEmail, sendAccountLockoutEmail, sendPasswordChangeConfirmationEmail, send2FAEnabledEmail } from "../../services/emailService";
import { generate2FASecret, verify2FACode, enable2FA, disable2FA, get2FAStatus, regenerateBackupCodes } from "../../services/twoFactorService";
import {
  hashPassword,
  verifyPassword,
  isAccountLocked,
  recordFailedLogin,
  resetFailedLoginAttempts,
  generatePasswordResetToken,
  verifyPasswordResetToken,
  resetPasswordWithToken,
  changePassword,
  getAccountLockoutStatus,
} from "../../services/authenticationService";
import { getUserByOpenId } from "../../db";
import { getDb } from "../../db";
import { users } from "../../../drizzle/schema";
import { eq } from "drizzle-orm";

/**
 * Authentication Router
 * Handles password management, login attempts, and account security
 */
export const authenticationRouter = router({
  /**
   * Get account security status
   */
  getSecurityStatus: protectedProcedure.query(async ({ ctx }) => {
    const status = await getAccountLockoutStatus(ctx.user.id);
    return status;
  }),

  /**
   * Request password reset (generates token and sends email)
   */
  requestPasswordReset: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Find user by email
      const result = await db
        .select()
        .from(users)
        .where(eq(users.email, input.email))
        .limit(1);

      if (result.length === 0) {
        // Don't reveal if email exists for security
        return { success: true, message: "If the email exists, a reset link has been sent" };
      }

      const user = result[0];

      // Generate reset token
      const token = await generatePasswordResetToken(user.id);

      // Send password reset email
      await sendPasswordResetEmail(input.email, user.name || 'User', token);

      return {
        success: true,
        message: "If the email exists, a reset link has been sent",
        // Remove this in production - only for development
        devToken: process.env.NODE_ENV === "development" ? token : undefined,
      };
    }),

  /**
   * Verify password reset token
   */
  verifyResetToken: publicProcedure
    .input(
      z.object({
        token: z.string(),
      })
    )
    .query(async ({ input }) => {
      const userId = await verifyPasswordResetToken(input.token);
      return { valid: userId !== null };
    }),

  /**
   * Reset password with token
   */
  resetPassword: publicProcedure
    .input(
      z.object({
        token: z.string(),
        newPassword: z.string().min(8, "Password must be at least 8 characters"),
      })
    )
    .mutation(async ({ input }) => {
      const success = await resetPasswordWithToken(input.token, input.newPassword);

      if (!success) {
        throw new Error("Invalid or expired reset token");
      }

      return { success: true, message: "Password has been reset successfully" };
    }),

  /**
   * Change password (requires current password)
   */
  changePassword: protectedProcedure
    .input(
      z.object({
        currentPassword: z.string(),
        newPassword: z.string().min(8, "Password must be at least 8 characters"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const result = await changePassword(
        ctx.user.id,
        input.currentPassword,
        input.newPassword
      );

      if (!result.success) {
        throw new Error(result.error || "Failed to change password");
      }

      // Send confirmation email
      if (ctx.user.email) {
        await sendPasswordChangeConfirmationEmail(ctx.user.email, ctx.user.name || 'User');
      }

      return { success: true, message: "Password changed successfully" };
    }),

  /**
   * Set initial password (for OAuth users who want to add password auth)
   */
  setPassword: protectedProcedure
    .input(
      z.object({
        newPassword: z.string().min(8, "Password must be at least 8 characters"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Check if user already has a password
      const result = await db
        .select()
        .from(users)
        .where(eq(users.id, ctx.user.id))
        .limit(1);

      if (result.length === 0) {
        throw new Error("User not found");
      }

      const user = result[0];

      if (user.passwordHash) {
        throw new Error("Password already set. Use change password instead.");
      }

      // Hash and save password
      const passwordHash = await hashPassword(input.newPassword);

      await db
        .update(users)
        .set({
          passwordHash,
          lastPasswordChange: new Date(),
        })
        .where(eq(users.id, ctx.user.id));

      return { success: true, message: "Password set successfully" };
    }),

  /**
   * Check if user has password authentication enabled
   */
  hasPassword: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return { hasPassword: false };

    const result = await db
      .select()
      .from(users)
      .where(eq(users.id, ctx.user.id))
      .limit(1);

    if (result.length === 0) {
      return { hasPassword: false };
    }

    return { hasPassword: !!result[0].passwordHash };
  }),

  /**
   * Unlock account (admin only)
   */
  unlockAccount: protectedProcedure
    .input(
      z.object({
        userId: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check if user is admin
      if (ctx.user.role !== "admin") {
        throw new Error("Only admins can unlock accounts");
      }

      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db
        .update(users)
        .set({
          failedLoginAttempts: 0,
          accountLockedUntil: null,
        })
        .where(eq(users.id, input.userId));

      return { success: true, message: "Account unlocked successfully" };
    }),

  /**
   * Get 2FA status
   */
  get2FAStatus: protectedProcedure.query(async ({ ctx }) => {
    return await get2FAStatus(ctx.user.id);
  }),

  /**
   * Setup 2FA - Generate secret and QR code
   */
  setup2FA: protectedProcedure.mutation(async ({ ctx }) => {
    if (!ctx.user.email) {
      throw new Error("Email is required for 2FA setup");
    }

    const { secret, qrCodeUrl, manualEntryKey } = await generate2FASecret(
      ctx.user.id,
      ctx.user.email
    );

    return {
      secret,
      qrCodeUrl,
      manualEntryKey,
    };
  }),

  /**
   * Enable 2FA - Verify token and save secret
   */
  enable2FA: protectedProcedure
    .input(
      z.object({
        secret: z.string(),
        token: z.string().length(6, "Token must be 6 digits"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Verify the token before enabling
      const { verifyTOTPToken } = await import("../../services/twoFactorService");
      const isValid = verifyTOTPToken(input.secret, input.token);

      if (!isValid) {
        throw new Error("Invalid verification code. Please try again.");
      }

      // Generate backup codes
      const { generateBackupCodes } = await import("../../services/twoFactorService");
      const backupCodes = generateBackupCodes();

      // Enable 2FA
      await enable2FA(ctx.user.id, input.secret, backupCodes);

      // Send confirmation email
      if (ctx.user.email) {
        await send2FAEnabledEmail(ctx.user.email, ctx.user.name || 'User');
      }

      return {
        success: true,
        backupCodes,
        message: "Two-factor authentication enabled successfully",
      };
    }),

  /**
   * Disable 2FA
   */
  disable2FA: protectedProcedure
    .input(
      z.object({
        password: z.string().optional(),
        token: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Verify password or 2FA token before disabling
      if (input.password) {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const result = await db
          .select()
          .from(users)
          .where(eq(users.id, ctx.user.id))
          .limit(1);

        if (result.length === 0 || !result[0].passwordHash) {
          throw new Error("Password verification required");
        }

        const isValid = await verifyPassword(input.password, result[0].passwordHash);
        if (!isValid) {
          throw new Error("Invalid password");
        }
      } else if (input.token) {
        const { valid } = await verify2FACode(ctx.user.id, input.token);
        if (!valid) {
          throw new Error("Invalid 2FA code");
        }
      } else {
        throw new Error("Password or 2FA token required to disable 2FA");
      }

      await disable2FA(ctx.user.id);

      return {
        success: true,
        message: "Two-factor authentication disabled",
      };
    }),

  /**
   * Verify 2FA code
   */
  verify2FA: protectedProcedure
    .input(
      z.object({
        code: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const result = await verify2FACode(ctx.user.id, input.code);

      if (!result.valid) {
        throw new Error("Invalid verification code");
      }

      return {
        success: true,
        usedBackupCode: result.usedBackupCode,
        message: result.usedBackupCode
          ? "Backup code verified successfully"
          : "Verification code verified successfully",
      };
    }),

  /**
   * Regenerate backup codes
   */
  regenerateBackupCodes: protectedProcedure.mutation(async ({ ctx }) => {
    const status = await get2FAStatus(ctx.user.id);

    if (!status.enabled) {
      throw new Error("2FA is not enabled");
    }

    const newCodes = await regenerateBackupCodes(ctx.user.id);

    return {
      success: true,
      backupCodes: newCodes,
      message: "Backup codes regenerated successfully",
    };
  }),
});
