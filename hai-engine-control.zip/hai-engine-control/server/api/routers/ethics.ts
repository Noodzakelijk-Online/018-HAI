/**
 * ETHICAL FRAMEWORK API ROUTER
 */

import { z } from 'zod';
import { router, protectedProcedure } from '../../_core/trpc';
import { maslowGuardianService, type MaslowLevel } from '../../services/ethics/MaslowGuardian';

export const ethicsRouter = router({
  // Need Assessment
  assessments: router({
    create: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        memberId: z.number(),
        level: z.enum(['physiological', 'safety', 'belonging', 'esteem', 'self_actualization']),
        category: z.string(),
        indicators: z.array(z.object({ name: z.string(), value: z.number(), weight: z.number() })),
      }))
      .mutation(async ({ input }) => {
        return await maslowGuardianService.assessNeed(input.householdId, input.memberId, {
          level: input.level as MaslowLevel,
          category: input.category,
          indicators: input.indicators,
        });
      }),

    list: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        memberId: z.number().optional(),
        level: z.enum(['physiological', 'safety', 'belonging', 'esteem', 'self_actualization']).optional(),
      }))
      .query(async ({ input }) => {
        return await maslowGuardianService.getAssessments(input.householdId, input.memberId, input.level as MaslowLevel | undefined);
      }),

    wellbeing: protectedProcedure
      .input(z.object({ householdId: z.number(), memberId: z.number() }))
      .query(async ({ input }) => {
        return await maslowGuardianService.getWellbeingSnapshot(input.householdId, input.memberId);
      }),
  }),

  // Pushback System
  pushback: router({
    record: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        memberId: z.number().optional(),
        requestType: z.string(),
        requestDetails: z.string(),
        pushbackReason: z.string(),
        severity: z.enum(['gentle', 'moderate', 'strong']),
        response: z.string(),
      }))
      .mutation(async ({ input }) => {
        return await maslowGuardianService.recordPushback(input.householdId, input);
      }),

    evaluate: protectedProcedure
      .input(z.object({
        type: z.string(),
        details: z.string(),
        memberId: z.number().optional(),
      }))
      .query(async ({ input }) => {
        return await maslowGuardianService.evaluateRequest(input);
      }),

    history: protectedProcedure
      .input(z.object({ householdId: z.number(), limit: z.number().optional() }))
      .query(async ({ input }) => {
        return await maslowGuardianService.getPushbackHistory(input.householdId, input.limit);
      }),
  }),

  // Behavior Goals
  goals: router({
    create: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        memberId: z.number(),
        category: z.string(),
        title: z.string(),
        description: z.string(),
        targetValue: z.number().optional(),
        unit: z.string().optional(),
        targetDate: z.date().optional(),
        milestones: z.array(z.object({ title: z.string() })).optional(),
      }))
      .mutation(async ({ input }) => {
        return await maslowGuardianService.createGoal(input.householdId, input.memberId, input);
      }),

    get: protectedProcedure
      .input(z.object({ goalId: z.number() }))
      .query(async ({ input }) => {
        return await maslowGuardianService.getGoal(input.goalId);
      }),

    list: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        memberId: z.number().optional(),
        status: z.enum(['active', 'completed', 'paused', 'abandoned']).optional(),
      }))
      .query(async ({ input }) => {
        return await maslowGuardianService.getGoals(input.householdId, input.memberId, input.status);
      }),

    updateProgress: protectedProcedure
      .input(z.object({
        goalId: z.number(),
        currentValue: z.number().optional(),
        milestoneIndex: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        return await maslowGuardianService.updateGoalProgress(input.goalId, {
          currentValue: input.currentValue,
          milestoneIndex: input.milestoneIndex,
        });
      }),
  }),

  // Statistics
  statistics: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ input }) => {
      return await maslowGuardianService.getStatistics(input.householdId);
    }),
});
