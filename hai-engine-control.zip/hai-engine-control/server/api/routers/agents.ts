import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "../../_core/trpc";
import {
  registerAgent,
  listAgents,
  listAgentsByHousehold,
  getAgentById,
  deleteAgent,
  getOnlineAgents,
  getAgentStatistics,
} from "../../services/agentManager";
import {
  createTask,
  getPendingTasks,
  distributeTasks,
  getTasksByAgent,
  cancelTask,
} from "../../services/taskQueue";
import { getConnectedAgentCount, isAgentConnected } from "../../services/agentSocket";
import { cacheService, CacheKeys, CacheTTL } from "../../services/cacheService";

export const agentsRouter = router({
  /**
   * Register a new agent
   */
  register: protectedProcedure
    .input(
      z.object({
        name: z.string().min(1).max(255),
        type: z.enum(["windows", "linux", "macos", "docker"]),
        householdId: z.number().int().positive(),
        capabilities: z.any().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const agent = await registerAgent({
        name: input.name,
        type: input.type,
        userId: ctx.user.id,
        householdId: input.householdId,
        capabilities: input.capabilities,
      });

      // Invalidate agent cache for this household
      cacheService.delete(CacheKeys.agentList(input.householdId));
      
      return {
        success: true,
        agent: {
          id: agent.id,
          name: agent.name,
          type: agent.type,
          apiKey: agent.apiKey, // Return API key only on registration
          status: agent.status,
        },
      };
    }),

  /**
   * List all agents for a household (cached for 30 seconds)
   */
  list: protectedProcedure
    .input(
      z.object({
        householdId: z.number().int().positive(),
      })
    )
    .query(async ({ input, ctx }) => {
      const cacheKey = CacheKeys.agentList(input.householdId);
      
      // Cache the base agent list, but always check connection status
      const agents = await cacheService.getOrFetch(
        cacheKey,
        () => listAgentsByHousehold(input.householdId),
        { ttl: CacheTTL.SHORT, staleWhileRevalidate: true }
      );
      
      // Add connection status (not cached - needs to be real-time)
      const agentsWithStatus = agents.map(agent => ({
        ...agent,
        isConnected: isAgentConnected(agent.id),
        apiKey: undefined, // Don't expose API key in list
      }));

      return agentsWithStatus;
    }),

  /**
   * Get online agents
   */
  getOnline: protectedProcedure.query(async ({ ctx }) => {
    const agents = await getOnlineAgents(ctx.user.id);
    return agents.map(agent => ({
      ...agent,
      isConnected: isAgentConnected(agent.id),
      apiKey: undefined,
    }));
  }),

  /**
   * Get agent by ID
   */
  getById: protectedProcedure
    .input(z.object({ agentId: z.number() }))
    .query(async ({ input, ctx }) => {
      const agent = await getAgentById(input.agentId);
      
      if (!agent || agent.userId !== ctx.user.id) {
        throw new Error("Agent not found");
      }

      return {
        ...agent,
        isConnected: isAgentConnected(agent.id),
        apiKey: undefined, // Don't expose API key
      };
    }),

  /**
   * Get agent statistics
   */
  getStatistics: protectedProcedure
    .input(z.object({ agentId: z.number() }))
    .query(async ({ input, ctx }) => {
      const agent = await getAgentById(input.agentId);
      
      if (!agent || agent.userId !== ctx.user.id) {
        throw new Error("Agent not found");
      }

      const stats = await getAgentStatistics(input.agentId);
      return stats;
    }),

  /**
   * Delete agent
   */
  delete: protectedProcedure
    .input(z.object({ agentId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      // Get agent to find householdId before deletion
      const agent = await getAgentById(input.agentId);
      
      await deleteAgent(input.agentId, ctx.user.id);
      
      // Invalidate agent cache for this household
      if (agent?.householdId) {
        cacheService.delete(CacheKeys.agentList(agent.householdId));
      }
      
      return { success: true };
    }),

  /**
   * Get connected agent count
   */
  getConnectedCount: protectedProcedure.query(() => {
    return { count: getConnectedAgentCount() };
  }),

  /**
   * Create a new task
   */
  createTask: protectedProcedure
    .input(
      z.object({
        title: z.string().min(1).max(255),
        taskType: z.enum(["email", "calendar", "finance", "research", "automation", "communication"]),
        description: z.string().optional(),
        priority: z.enum(["low", "medium", "high", "urgent"]).optional(),
        metadata: z.any().optional(),
        scheduledFor: z.date().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const task = await createTask({
        userId: ctx.user.id,
        ...input,
      });

      return { success: true, task };
    }),

  /**
   * Get pending tasks
   */
  getPendingTasks: protectedProcedure.query(async ({ ctx }) => {
    const tasks = await getPendingTasks(ctx.user.id);
    return tasks;
  }),

  /**
   * Distribute tasks to available agents
   */
  distributeTasks: protectedProcedure.mutation(async ({ ctx }) => {
    const result = await distributeTasks(ctx.user.id);
    return result;
  }),

  /**
   * Get tasks by agent
   */
  getTasksByAgent: protectedProcedure
    .input(z.object({ agentId: z.number() }))
    .query(async ({ input, ctx }) => {
      const agent = await getAgentById(input.agentId);
      
      if (!agent || agent.userId !== ctx.user.id) {
        throw new Error("Agent not found");
      }

      const tasks = await getTasksByAgent(input.agentId);
      return tasks;
    }),

  /**
   * Cancel task
   */
  cancelTask: protectedProcedure
    .input(z.object({ taskId: z.number() }))
    .mutation(async ({ input }) => {
      await cancelTask(input.taskId);
      return { success: true };
    }),
});
