/**
 * HUMAN INTERACTION LAYER API ROUTER
 * 
 * Exposes APIs for:
 * - Cortana Paradigm (HAI personality)
 * - Message management
 * - Communication preferences
 */

import { z } from 'zod';
import { router, protectedProcedure } from '../../_core/trpc';
import { cortanaParadigmService, type CommunicationTone, type UrgencyLevel, type MessageChannel } from '../../services/interaction/CortanaParadigm';

// ============================================================================
// ROUTER
// ============================================================================

export const interactionRouter = router({
  // ============================================================================
  // PERSONA
  // ============================================================================
  
  persona: router({
    // Get current persona
    get: protectedProcedure.query(async () => {
      return cortanaParadigmService.getPersona();
    }),

    // Update persona
    update: protectedProcedure
      .input(z.object({
        name: z.string().optional(),
        traits: z.array(z.enum(['proactive', 'helpful', 'respectful', 'efficient', 'warm', 'professional', 'casual'])).optional(),
        defaultTone: z.enum(['formal', 'professional', 'friendly', 'casual']).optional(),
        greeting: z.string().optional(),
        signoff: z.string().optional(),
        avatarUrl: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return cortanaParadigmService.updatePersona(input);
      }),
  }),

  // ============================================================================
  // MESSAGES
  // ============================================================================
  
  messages: router({
    // List messages
    list: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        memberId: z.number().optional(),
        type: z.enum(['notification', 'suggestion', 'question', 'confirmation', 'update', 'alert']).optional(),
        unreadOnly: z.boolean().optional(),
        limit: z.number().optional(),
      }))
      .query(async ({ input }) => {
        return await cortanaParadigmService.getMessages(input.householdId, {
          memberId: input.memberId,
          type: input.type,
          unreadOnly: input.unreadOnly,
          limit: input.limit,
        });
      }),

    // Get message by ID
    get: protectedProcedure
      .input(z.object({ messageId: z.number() }))
      .query(async ({ input }) => {
        return await cortanaParadigmService.getMessage(input.messageId);
      }),

    // Send notification
    sendNotification: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        title: z.string(),
        body: z.string(),
        memberId: z.number().optional(),
        urgency: z.enum(['critical', 'high', 'normal', 'low', 'info']).optional(),
        actions: z.array(z.object({
          label: z.string(),
          action: z.string(),
          primary: z.boolean().optional(),
        })).optional(),
      }))
      .mutation(async ({ input }) => {
        return await cortanaParadigmService.sendNotification(input.householdId, {
          title: input.title,
          body: input.body,
          memberId: input.memberId,
          urgency: input.urgency as UrgencyLevel | undefined,
          actions: input.actions,
        });
      }),

    // Send suggestion
    sendSuggestion: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        title: z.string(),
        body: z.string(),
        memberId: z.number().optional(),
        actions: z.array(z.object({
          label: z.string(),
          action: z.string(),
          primary: z.boolean().optional(),
        })).optional(),
        context: z.object({
          actionId: z.number().optional(),
          relatedEntity: z.string().optional(),
          relatedEntityId: z.number().optional(),
        }).optional(),
      }))
      .mutation(async ({ input }) => {
        return await cortanaParadigmService.sendSuggestion(input.householdId, {
          title: input.title,
          body: input.body,
          memberId: input.memberId,
          actions: input.actions,
          context: input.context,
        });
      }),

    // Ask question
    askQuestion: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        title: z.string(),
        body: z.string(),
        memberId: z.number(),
        options: z.array(z.string()).optional(),
      }))
      .mutation(async ({ input }) => {
        return await cortanaParadigmService.askQuestion(input.householdId, {
          title: input.title,
          body: input.body,
          memberId: input.memberId,
          options: input.options,
        });
      }),

    // Send alert
    sendAlert: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        title: z.string(),
        body: z.string(),
        urgency: z.enum(['critical', 'high', 'normal', 'low', 'info']),
        memberId: z.number().optional(),
        actions: z.array(z.object({
          label: z.string(),
          action: z.string(),
          primary: z.boolean().optional(),
        })).optional(),
      }))
      .mutation(async ({ input }) => {
        return await cortanaParadigmService.sendAlert(input.householdId, {
          title: input.title,
          body: input.body,
          urgency: input.urgency as UrgencyLevel,
          memberId: input.memberId,
          actions: input.actions,
        });
      }),

    // Mark as read
    markAsRead: protectedProcedure
      .input(z.object({ messageId: z.number() }))
      .mutation(async ({ input }) => {
        await cortanaParadigmService.markAsRead(input.messageId);
        return { success: true };
      }),

    // Record response
    respond: protectedProcedure
      .input(z.object({
        messageId: z.number(),
        response: z.string(),
      }))
      .mutation(async ({ input }) => {
        await cortanaParadigmService.recordResponse(input.messageId, input.response);
        return { success: true };
      }),
  }),

  // ============================================================================
  // PREFERENCES
  // ============================================================================
  
  preferences: router({
    // Get preferences
    get: protectedProcedure
      .input(z.object({ memberId: z.number() }))
      .query(async ({ input }) => {
        return cortanaParadigmService.getPreferences(input.memberId);
      }),

    // Set preferences
    set: protectedProcedure
      .input(z.object({
        memberId: z.number(),
        preferredTone: z.enum(['formal', 'professional', 'friendly', 'casual']).optional(),
        preferredChannels: z.array(z.enum(['dashboard', 'notification', 'email', 'sms', 'voice'])).optional(),
        quietHours: z.object({
          start: z.string(),
          end: z.string(),
        }).nullable().optional(),
        notificationFrequency: z.enum(['immediate', 'batched', 'digest']).optional(),
        verbosityLevel: z.enum(['minimal', 'standard', 'detailed']).optional(),
      }))
      .mutation(async ({ input }) => {
        const { memberId, ...prefs } = input;
        return cortanaParadigmService.setPreferences(memberId, prefs);
      }),
  }),

  // ============================================================================
  // CONTEXT
  // ============================================================================
  
  context: router({
    // Get conversation context
    get: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        memberId: z.number(),
      }))
      .query(async ({ input }) => {
        return cortanaParadigmService.getContext(input.householdId, input.memberId);
      }),
  }),

  // ============================================================================
  // STATISTICS
  // ============================================================================
  
  statistics: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ input }) => {
      return await cortanaParadigmService.getStatistics(input.householdId);
    }),
});
