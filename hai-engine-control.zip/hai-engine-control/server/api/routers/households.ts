import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "../../_core/trpc";
import {
  createHousehold,
  addHouseholdMember,
  removeHouseholdMember,
  getHouseholdWithMembers,
  getUserHouseholds,
  isHouseholdMember,
  isHouseholdOwner,
  updateHouseholdSettings,
  deleteHousehold,
} from "../../services/householdManager";
import {
  createInvitation,
  getInvitationByToken,
  acceptInvitation,
  listInvitations,
  revokeInvitation,
} from "../../services/invitationManager";

/**
 * Household Router
 * 
 * Manages household entities, members, and settings.
 * Households are the primary resource container in HAI.
 */

export const householdsRouter = router({
  /**
   * Create a new household
   */
  create: protectedProcedure
    .input(
      z.object({
        name: z.string().min(1).max(255),
        settings: z.record(z.string(), z.any()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const household = await createHousehold({
        name: input.name,
        ownerId: ctx.user.id,
        settings: input.settings,
      });

      return {
        success: true,
        household,
      };
    }),

  /**
   * Get all households for current user
   */
  list: protectedProcedure.query(async ({ ctx }) => {
    const households = await getUserHouseholds(ctx.user.id);
    return households;
  }),

  /**
   * Get household by ID with members
   */
  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      // Check if user is member
      const isMember = await isHouseholdMember(input.id, ctx.user.id);
      if (!isMember) {
        throw new Error("Not a member of this household");
      }

      const household = await getHouseholdWithMembers(input.id);
      if (!household) {
        throw new Error("Household not found");
      }

      return household;
    }),

  /**
   * Add member to household
   */
  addMember: protectedProcedure
    .input(
      z.object({
        householdId: z.number(),
        userId: z.number(),
        role: z.enum(["owner", "member"]).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check if current user is owner (only owners can add members)
      const isOwner = await isHouseholdOwner(input.householdId, ctx.user.id);
      if (!isOwner) {
        throw new Error("Only household owners can add members");
      }

      const member = await addHouseholdMember({
        householdId: input.householdId,
        userId: input.userId,
        role: input.role,
      });

      return {
        success: true,
        member,
      };
    }),

  /**
   * Remove member from household
   */
  removeMember: protectedProcedure
    .input(
      z.object({
        householdId: z.number(),
        userId: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check if current user is owner
      const isOwner = await isHouseholdOwner(input.householdId, ctx.user.id);
      if (!isOwner) {
        throw new Error("Only household owners can remove members");
      }

      // Prevent removing the last owner
      const household = await getHouseholdWithMembers(input.householdId);
      if (!household) {
        throw new Error("Household not found");
      }

      const owners = household.members.filter((m) => m.role === "owner");
      const targetMember = household.members.find((m) => m.userId === input.userId);

      if (targetMember?.role === "owner" && owners.length === 1) {
        throw new Error("Cannot remove the last owner");
      }

      const success = await removeHouseholdMember(input.householdId, input.userId);

      return {
        success,
      };
    }),

  /**
   * Update household settings
   */
  updateSettings: protectedProcedure
    .input(
      z.object({
        householdId: z.number(),
        settings: z.record(z.string(), z.any()),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check if user is member
      const isMember = await isHouseholdMember(input.householdId, ctx.user.id);
      if (!isMember) {
        throw new Error("Not a member of this household");
      }

      const success = await updateHouseholdSettings(input.householdId, input.settings);

      return {
        success,
      };
    }),

  /**
   * Delete household
   */
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      // Check if current user is owner
      const isOwner = await isHouseholdOwner(input.id, ctx.user.id);
      if (!isOwner) {
        throw new Error("Only household owners can delete households");
      }

      const success = await deleteHousehold(input.id);

      return {
        success,
      };
    }),

  /**
   * Check if current user is member of household
   */
  isMember: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ ctx, input }) => {
      const isMember = await isHouseholdMember(input.householdId, ctx.user.id);
      return { isMember };
    }),

  /**
   * Check if current user is owner of household
   */
  isOwner: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ ctx, input }) => {
      const isOwner = await isHouseholdOwner(input.householdId, ctx.user.id);
      return { isOwner };
    }),

  /**
   * Create invitation
   */
  createInvitation: protectedProcedure
    .input(
      z.object({
        householdId: z.number(),
        invitedEmail: z.string().email().optional(),
        expiresInDays: z.number().min(1).max(30).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Check if current user is owner
      const isOwner = await isHouseholdOwner(input.householdId, ctx.user.id);
      if (!isOwner) {
        throw new Error("Only household owners can create invitations");
      }

      const invitation = await createInvitation({
        householdId: input.householdId,
        invitedBy: ctx.user.id,
        invitedEmail: input.invitedEmail,
        expiresInDays: input.expiresInDays,
      });

      return {
        success: true,
        invitation,
      };
    }),

  /**
   * Get invitation by token (public endpoint for invitation acceptance page)
   */
  getInvitation: publicProcedure
    .input(z.object({ token: z.string() }))
    .query(async ({ input }) => {
      const invitation = await getInvitationByToken(input.token);
      if (!invitation) {
        throw new Error("Invitation not found");
      }
      return invitation;
    }),

  /**
   * Accept invitation
   */
  acceptInvitation: protectedProcedure
    .input(z.object({ token: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const result = await acceptInvitation({
        token: input.token,
        userId: ctx.user.id,
      });

      return {
        success: true,
        ...result,
      };
    }),

  /**
   * List pending invitations for household
   */
  listInvitations: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ ctx, input }) => {
      // Check if current user is member
      const isMember = await isHouseholdMember(input.householdId, ctx.user.id);
      if (!isMember) {
        throw new Error("Not a member of this household");
      }

      const invitations = await listInvitations(input.householdId);
      return invitations;
    }),

  /**
   * Revoke invitation
   */
  revokeInvitation: protectedProcedure
    .input(z.object({ invitationId: z.number(), householdId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      // Check if current user is owner
      const isOwner = await isHouseholdOwner(input.householdId, ctx.user.id);
      if (!isOwner) {
        throw new Error("Only household owners can revoke invitations");
      }

      await revokeInvitation(input.invitationId);

      return {
        success: true,
      };
    }),
});
