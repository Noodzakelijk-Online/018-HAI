import { z } from "zod";
import { protectedProcedure, router } from "../../_core/trpc";
import { DecisionEngine, AutonomyLevel, DecisionContext } from "../../services/DecisionEngine";

export const decisionRouter = router({
  /**
   * Evaluate a decision without executing it
   */
  evaluate: protectedProcedure
    .input(
      z.object({
        type: z.enum(['action', 'communication', 'scheduling', 'resource_allocation', 'policy_change', 'escalation']),
        description: z.string(),
        urgency: z.enum(['low', 'medium', 'high', 'critical']),
        impact: z.enum(['low', 'medium', 'high']),
        reversibility: z.enum(['easy', 'moderate', 'difficult', 'irreversible']),
        alternatives: z.array(z.string()).optional(),
        relatedEntities: z.array(z.string()).optional(),
        estimatedCost: z.number().optional(),
        estimatedTime: z.number().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const context: DecisionContext = {
        type: input.type,
        description: input.description,
        urgency: input.urgency,
        impact: input.impact,
        reversibility: input.reversibility,
        alternatives: input.alternatives,
        relatedEntities: input.relatedEntities,
        estimatedCost: input.estimatedCost,
        estimatedTime: input.estimatedTime,
      };

      const evaluation = await DecisionEngine.evaluateDecision({
        userId: ctx.user.id,
        context,
      });

      return evaluation;
    }),

  /**
   * Make a decision (evaluate and execute or request approval)
   */
  makeDecision: protectedProcedure
    .input(
      z.object({
        type: z.enum(['action', 'communication', 'scheduling', 'resource_allocation', 'policy_change', 'escalation']),
        description: z.string(),
        urgency: z.enum(['low', 'medium', 'high', 'critical']),
        impact: z.enum(['low', 'medium', 'high']),
        reversibility: z.enum(['easy', 'moderate', 'difficult', 'irreversible']),
        alternatives: z.array(z.string()).optional(),
        relatedEntities: z.array(z.string()).optional(),
        estimatedCost: z.number().optional(),
        estimatedTime: z.number().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const context: DecisionContext = {
        type: input.type,
        description: input.description,
        urgency: input.urgency,
        impact: input.impact,
        reversibility: input.reversibility,
        alternatives: input.alternatives,
        relatedEntities: input.relatedEntities,
        estimatedCost: input.estimatedCost,
        estimatedTime: input.estimatedTime,
      };

      const decision = await DecisionEngine.makeDecision({
        userId: ctx.user.id,
        context,
      });

      return decision;
    }),

  /**
   * Get pending decisions awaiting approval
   */
  getPending: protectedProcedure.query(async ({ ctx }) => {
    const pending = await DecisionEngine.getPendingDecisions(ctx.user.id);
    return pending;
  }),

  /**
   * Get decision history
   */
  getHistory: protectedProcedure
    .input(
      z.object({
        limit: z.number().optional(),
        status: z.string().optional(),
      }).optional()
    )
    .query(async ({ ctx, input }) => {
      const history = await DecisionEngine.getDecisionHistory({
        userId: ctx.user.id,
        limit: input?.limit,
        status: input?.status,
      });

      return history;
    }),

  /**
   * Approve a decision
   */
  approve: protectedProcedure
    .input(
      z.object({
        decisionId: z.number(),
        feedback: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const success = await DecisionEngine.approveDecision({
        decisionId: input.decisionId,
        userId: ctx.user.id,
        feedback: input.feedback,
      });

      return { success };
    }),

  /**
   * Reject a decision
   */
  reject: protectedProcedure
    .input(
      z.object({
        decisionId: z.number(),
        reason: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const success = await DecisionEngine.rejectDecision({
        decisionId: input.decisionId,
        userId: ctx.user.id,
        reason: input.reason,
      });

      return { success };
    }),

  /**
   * Get autonomy level description
   */
  getAutonomyLevels: protectedProcedure.query(() => {
    return [
      {
        level: AutonomyLevel.NOTIFY,
        name: 'Notify',
        description: 'Just inform user after decision is made',
      },
      {
        level: AutonomyLevel.SUGGEST,
        name: 'Suggest',
        description: 'Suggest options, user decides',
      },
      {
        level: AutonomyLevel.ASK,
        name: 'Ask',
        description: 'Ask for permission before acting',
      },
      {
        level: AutonomyLevel.ACT_THEN_REPORT,
        name: 'Act Then Report',
        description: 'Act first, report after',
      },
      {
        level: AutonomyLevel.AUTONOMOUS,
        name: 'Autonomous',
        description: 'Fully autonomous, no user interaction',
      },
    ];
  }),
});

// Import enhanced engine
import { DecisionEngineEnhanced } from '../../services/DecisionEngineEnhanced';
import { EventBus } from '../../services/EventBus';

const decisionEngineEnhanced = new DecisionEngineEnhanced(EventBus);

// Enhanced decision endpoints
export const decisionEnhancedRouter = router({
  // MCDA analysis
  analyzeMCDA: protectedProcedure
    .input(z.object({
      criteria: z.array(z.object({
        id: z.string(),
        name: z.string(),
        weight: z.number().min(0).max(1),
        type: z.enum(['benefit', 'cost']),
        unit: z.string().optional(),
      })),
      alternatives: z.array(z.object({
        id: z.string(),
        name: z.string(),
        description: z.string().optional(),
        scores: z.record(z.string(), z.number()),
        metadata: z.record(z.string(), z.any()).optional(),
      })),
      method: z.enum(['weighted_sum', 'topsis', 'ahp']).default('weighted_sum'),
    }))
    .mutation(async ({ ctx, input }) => {
      return await decisionEngineEnhanced.analyzeMCDA(input.criteria, input.alternatives, input.method);
    }),

  // Decision tree analysis
  analyzeDecisionTree: protectedProcedure
    .input(z.object({
      root: z.any(), // DecisionTreeNode structure
    }))
    .mutation(async ({ ctx, input }) => {
      return await decisionEngineEnhanced.analyzeDecisionTree(input.root);
    }),

  // Scenario simulation
  simulateScenario: protectedProcedure
    .input(z.object({
      baselineDecision: z.string(),
      variables: z.record(z.string(), z.number()),
      scenarios: z.array(z.object({
        name: z.string(),
        changes: z.record(z.string(), z.number()),
      })),
    }))
    .mutation(async ({ ctx, input }) => {
      return await decisionEngineEnhanced.simulateScenario(
        input.baselineDecision,
        input.variables,
        input.scenarios
      );
    }),

  // Record decision
  recordDecision: protectedProcedure
    .input(z.object({
      decisionId: z.string(),
      decision: z.string(),
      rationale: z.string(),
      alternatives: z.array(z.any()),
      selectedAlternative: z.string(),
    }))
    .mutation(async ({ ctx, input }) => {
      return await decisionEngineEnhanced.recordDecision(
        input.decisionId,
        input.decision,
        input.rationale,
        input.alternatives,
        input.selectedAlternative
      );
    }),

  // Rollback decision
  rollbackDecision: protectedProcedure
    .input(z.object({
      historyId: z.string(),
    }))
    .mutation(async ({ ctx, input }) => {
      return await decisionEngineEnhanced.rollbackDecision(input.historyId);
    }),

  // Risk assessment
  assessRisk: protectedProcedure
    .input(z.object({
      decisionId: z.string(),
      factors: z.array(z.object({
        factor: z.string(),
        likelihood: z.number().min(0).max(1),
        impact: z.number().min(0).max(10),
        mitigation: z.string().optional(),
      })),
    }))
    .mutation(async ({ ctx, input }) => {
      return await decisionEngineEnhanced.assessRisk(input.decisionId, input.factors);
    }),

  // Stakeholder voting
  submitVote: protectedProcedure
    .input(z.object({
      decisionId: z.string(),
      vote: z.object({
        stakeholderId: z.string(),
        stakeholderName: z.string(),
        vote: z.string(),
        weight: z.number().min(0).max(1),
        rationale: z.string().optional(),
        timestamp: z.date(),
      }),
    }))
    .mutation(async ({ ctx, input }) => {
      await decisionEngineEnhanced.submitVote(input.decisionId, input.vote);
      return { success: true };
    }),

  // Calculate voting results
  calculateVotingResults: protectedProcedure
    .input(z.object({
      decisionId: z.string(),
      totalStakeholders: z.number(),
    }))
    .query(async ({ input }) => {
      return await decisionEngineEnhanced.calculateVotingResults(input.decisionId, input.totalStakeholders);
    }),

  // Track impact
  trackImpact: protectedProcedure
    .input(z.object({
      decisionId: z.string(),
      predictedImpact: z.object({
        financial: z.number(),
        operational: z.number(),
        strategic: z.number(),
        risk: z.number(),
      }),
      actualImpact: z.object({
        financial: z.number(),
        operational: z.number(),
        strategic: z.number(),
        risk: z.number(),
      }).optional(),
      lessons: z.array(z.string()),
    }))
    .mutation(async ({ ctx, input }) => {
      await decisionEngineEnhanced.trackImpact({
        decisionId: input.decisionId,
        predictedImpact: input.predictedImpact,
        actualImpact: input.actualImpact,
        lessons: input.lessons,
      });
      return { success: true };
    }),

  // Get recommendations
  getRecommendations: protectedProcedure
    .input(z.object({
      context: z.record(z.string(), z.any()),
      alternatives: z.array(z.any()),
    }))
    .query(async ({ input }) => {
      return await decisionEngineEnhanced.getRecommendations(input.context, input.alternatives);
    }),

  // Get decision history (enhanced)
  getDecisionHistory: protectedProcedure
    .query(async () => {
      return decisionEngineEnhanced.getDecisionHistory();
    }),

  // Get impact tracking
  getImpactTracking: protectedProcedure
    .query(async () => {
      return decisionEngineEnhanced.getImpactTracking();
    }),
});
