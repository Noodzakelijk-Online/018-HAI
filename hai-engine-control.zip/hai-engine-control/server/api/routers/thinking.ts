/**
 * Thinking Engine tRPC Router
 * 
 * Provides API endpoints for the thinking status UI
 * Connected to real ThinkingEngine and DecisionEngine services
 */

import { z } from 'zod';
import { router, publicProcedure, protectedProcedure } from '../../_core/trpc';
import { getThinkingEngine, Observation } from '../../services/decision/ThinkingEngine';
import { getDecisionEngine, Decision, DecisionStatus } from '../../services/decision/DecisionEngine';

// Get singleton instances
const thinkingEngine = getThinkingEngine();
const decisionEngine = getDecisionEngine();

// Format observation for API response
function formatObservation(obs: Observation) {
  return {
    id: obs.id,
    type: obs.type,
    title: obs.title,
    description: obs.description,
    confidence: obs.confidence,
    source: obs.source,
    timestamp: obs.timestamp.toISOString()
  };
}

// Format decision for API response
function formatDecision(dec: Decision) {
  return {
    id: dec.id,
    title: dec.title,
    description: dec.description,
    category: dec.category,
    confidence: dec.confidence,
    confidenceLevel: dec.confidenceLevel,
    status: dec.status,
    options: dec.options.map(opt => ({
      id: opt.id,
      label: opt.label,
      description: opt.description
    })),
    createdAt: dec.createdAt.toISOString(),
    reasoning: dec.reasoning,
    selectedOption: dec.selectedOption,
    userResponse: dec.userResponse,
    executedAt: dec.executedAt?.toISOString(),
    error: dec.error
  };
}

export const thinkingRouter = router({
  // Get thinking engine status
  getStatus: publicProcedure.query(() => {
    const status = thinkingEngine.getStatus();
    return {
      isRunning: status.isRunning,
      config: status.config,
      contextSources: status.contextSources,
      observationCount: status.observationCount,
      thoughtCount: status.thoughtCount,
      decisionStats: status.decisionStats
    };
  }),
  
  // Get recent observations
  getObservations: publicProcedure
    .input(z.object({ limit: z.number().optional().default(20) }))
    .query(({ input }) => {
      const observations = thinkingEngine.getObservations(input.limit);
      return observations.map(formatObservation);
    }),
  
  // Get pending decisions
  getPendingDecisions: publicProcedure.query(() => {
    const decisions = decisionEngine.getPendingDecisions();
    return decisions.map(formatDecision);
  }),
  
  // Get thought log
  getThoughtLog: publicProcedure
    .input(z.object({ limit: z.number().optional().default(50) }))
    .query(({ input }) => {
      const log = thinkingEngine.getThoughtLog(input.limit);
      return log.map(entry => ({
        timestamp: entry.timestamp.toISOString(),
        thought: entry.thought
      }));
    }),
  
  // Get decision history
  getDecisionHistory: publicProcedure
    .input(z.object({ limit: z.number().optional().default(20) }))
    .query(({ input }) => {
      const history = decisionEngine.getDecisionHistory(input.limit);
      return history.map(formatDecision);
    }),
  
  // Respond to a decision
  respondToDecision: protectedProcedure
    .input(z.object({
      decisionId: z.string(),
      optionId: z.string()
    }))
    .mutation(async ({ input }) => {
      const success = await decisionEngine.executeDecision(input.decisionId, input.optionId);
      return { success };
    }),
  
  // Undo a decision
  undoDecision: protectedProcedure
    .input(z.object({ decisionId: z.string() }))
    .mutation(async ({ input }) => {
      const success = await decisionEngine.undoDecision(input.decisionId);
      return { success };
    }),
  
  // Start/stop thinking engine
  setRunning: protectedProcedure
    .input(z.object({ running: z.boolean() }))
    .mutation(async ({ input }) => {
      if (input.running) {
        thinkingEngine.start();
      } else {
        thinkingEngine.stop();
      }
      return { success: true, isRunning: input.running };
    }),
  
  // Update thinking config
  updateConfig: protectedProcedure
    .input(z.object({
      thinkingIntervalMs: z.number().optional(),
      proactiveMode: z.boolean().optional(),
      verboseLogging: z.boolean().optional()
    }))
    .mutation(async ({ input }) => {
      // Note: Config updates would need to be implemented in ThinkingEngine
      console.log(`[ThinkingRouter] Config update requested:`, input);
      return { success: true };
    }),
  
  // Get current context
  getContext: publicProcedure.query(() => {
    const context = thinkingEngine.getContext();
    return {
      screen: context.screen ? {
        hasContent: context.screen.hasContent,
        activeApp: context.screen.activeApp,
        summary: context.screen.summary
      } : null,
      calendar: context.calendar ? {
        upcomingEvents: context.calendar.upcomingEvents.length,
        conflicts: context.calendar.conflicts.length
      } : null,
      email: context.email ? {
        unreadCount: context.email.unreadCount,
        urgentCount: context.email.urgentEmails.length
      } : null,
      timeOfDay: context.timeOfDay,
      dayOfWeek: context.dayOfWeek,
      userActivity: context.userActivity
    };
  }),
  
  // Handle user response via text (for WhatsApp integration)
  handleUserResponse: protectedProcedure
    .input(z.object({
      decisionId: z.string(),
      response: z.string()
    }))
    .mutation(async ({ input }) => {
      const success = await decisionEngine.handleUserResponse(input.decisionId, input.response);
      return { success };
    })
});

export default thinkingRouter;
