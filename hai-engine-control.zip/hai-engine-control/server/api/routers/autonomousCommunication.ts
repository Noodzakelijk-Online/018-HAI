/**
 * Autonomous Communication tRPC Router
 * 
 * API endpoints for autonomous communication system
 */

import { z } from 'zod';
import { router, protectedProcedure } from '../../_core/trpc';
import { getAutonomousWhatsAppService, removeAutonomousWhatsAppService } from '../../services/communications/AutonomousWhatsAppService';

export const autonomousCommunicationRouter = router({
  /**
   * Start autonomous WhatsApp service
   */
  startWhatsApp: protectedProcedure
    .input(z.object({
      autoSendThreshold: z.number().min(0).max(100).optional(),
      monitoredSendThreshold: z.number().min(0).max(100).optional(),
      draftThreshold: z.number().min(0).max(100).optional(),
      enableNaturalTiming: z.boolean().optional(),
      vipContacts: z.array(z.string()).optional(),
      enabledForContacts: z.array(z.string()).optional(),
      disabledForContacts: z.array(z.string()).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const service = getAutonomousWhatsAppService(ctx.user.id, input);
      await service.start();
      
      return {
        success: true,
        message: 'Autonomous WhatsApp service started',
      };
    }),
  
  /**
   * Stop autonomous WhatsApp service
   */
  stopWhatsApp: protectedProcedure.mutation(async ({ ctx }) => {
    await removeAutonomousWhatsAppService(ctx.user.id);
    
    return {
      success: true,
      message: 'Autonomous WhatsApp service stopped',
    };
  }),
  
  /**
   * Get service status
   */
  getStatus: protectedProcedure.query(async ({ ctx }) => {
    const service = getAutonomousWhatsAppService(ctx.user.id);
    const stats = service.getStatistics();
    
    return {
      ...stats,
      config: {
        // Return current config (would need to expose this from service)
      },
    };
  }),
  
  /**
   * Get escalation queue
   */
  getEscalationQueue: protectedProcedure.query(async ({ ctx }) => {
    const service = getAutonomousWhatsAppService(ctx.user.id);
    const queue = service.getEscalationQueue();
    
    return queue.map(item => ({
      messageId: item.message.id,
      conversationId: item.message.conversationId,
      senderName: item.message.senderName,
      senderId: item.message.senderId,
      textContent: item.message.textContent,
      timestamp: item.message.timestamp,
      
      // Analysis results
      compositeConfidence: item.analysis?.compositeConfidence || 0,
      escalationReasons: item.analysis?.escalationReasons || [],
      
      // Generated response
      generatedResponse: item.response?.text || '',
      responseConfidence: item.response?.confidence || 0,
      responseReasoning: item.response?.reasoning || '',
      alternatives: item.response?.alternatives || [],
      
      // Validation details
      validationResults: item.response?.validationResults,
      
      // Decision
      decision: item.decision,
      status: item.status,
    }));
  }),
  
  /**
   * Approve escalated message
   */
  approveEscalation: protectedProcedure
    .input(z.object({
      messageId: z.string(),
      editedResponse: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const service = getAutonomousWhatsAppService(ctx.user.id);
      await service.approveEscalation(input.messageId, input.editedResponse);
      
      return {
        success: true,
        message: 'Message approved and sent',
      };
    }),
  
  /**
   * Reject escalated message
   */
  rejectEscalation: protectedProcedure
    .input(z.object({
      messageId: z.string(),
    }))
    .mutation(async ({ ctx, input }) => {
      const service = getAutonomousWhatsAppService(ctx.user.id);
      service.rejectEscalation(input.messageId);
      
      return {
        success: true,
        message: 'Message rejected',
      };
    }),
  
  /**
   * Update configuration
   */
  updateConfig: protectedProcedure
    .input(z.object({
      autoSendThreshold: z.number().min(0).max(100).optional(),
      monitoredSendThreshold: z.number().min(0).max(100).optional(),
      draftThreshold: z.number().min(0).max(100).optional(),
      enableNaturalTiming: z.boolean().optional(),
      vipContacts: z.array(z.string()).optional(),
      enabledForContacts: z.array(z.string()).optional(),
      disabledForContacts: z.array(z.string()).optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const service = getAutonomousWhatsAppService(ctx.user.id);
      service.updateConfig(input);
      
      return {
        success: true,
        message: 'Configuration updated',
      };
    }),
  
  /**
   * Send manual message
   */
  sendManualMessage: protectedProcedure
    .input(z.object({
      conversationId: z.string(),
      text: z.string(),
    }))
    .mutation(async ({ ctx, input }) => {
      const service = getAutonomousWhatsAppService(ctx.user.id);
      await service.sendMessage(input.conversationId, input.text);
      
      return {
        success: true,
        message: 'Message sent',
      };
    }),
  
  /**
   * Get statistics
   */
  getStatistics: protectedProcedure.query(async ({ ctx }) => {
    const service = getAutonomousWhatsAppService(ctx.user.id);
    return service.getStatistics();
  }),
});
