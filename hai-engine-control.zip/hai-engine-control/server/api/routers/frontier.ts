import { z } from "zod";
import { protectedProcedure, router } from "../../_core/trpc";
import { frontierEngine } from "../../services/FrontierEngine";

export const frontierRouter = router({
  /**
   * Discover a service from an API endpoint
   */
  discoverService: protectedProcedure
    .input(z.object({ endpoint: z.string().url() }))
    .mutation(async ({ input }) => {
      return await frontierEngine.discoverService(input.endpoint);
    }),

  /**
   * Register a new capability
   */
  registerCapability: protectedProcedure
    .input(
      z.object({
        name: z.string(),
        description: z.string().nullable(),
        category: z.string(),
        provider: z.string(),
        apiEndpoint: z.string().nullable().optional(),
        authType: z.enum(['none', 'api_key', 'oauth2', 'bearer']).nullable().optional(),
        schema: z.record(z.string(), z.unknown()).nullable().optional(),
        cost: z.number().nullable().optional(),
        reliability: z.number().nullable().optional(),
        confidence: z.number().nullable().optional(),
        dependencies: z.array(z.string()).nullable().optional(),
        examples: z.array(z.object({ input: z.unknown(), output: z.unknown() })).nullable().optional(),
        status: z.enum(['discovered', 'testing', 'active', 'deprecated']),
      })
    )
    .mutation(async ({ input }) => {
      return await frontierEngine.registerCapability({
        ...input,
        apiEndpoint: input.apiEndpoint ?? null,
        authType: input.authType ?? null,
        schema: input.schema ?? null,
        cost: input.cost ?? null,
        reliability: input.reliability ?? null,
        confidence: input.confidence ?? null,
        dependencies: input.dependencies ?? null,
        examples: input.examples ?? null,
      });
    }),

  /**
   * Match capabilities to a requirement
   */
  matchCapabilities: protectedProcedure
    .input(z.object({ requirement: z.string() }))
    .query(async ({ input }) => {
      return await frontierEngine.matchCapabilities(input.requirement);
    }),

  /**
   * Learn a new skill
   */
  learnSkill: protectedProcedure
    .input(
      z.object({
        name: z.string(),
        description: z.string().nullable(),
        requiredCapabilities: z.array(z.string()),
        steps: z.array(
          z.object({
            action: z.string(),
            capability: z.string(),
            input: z.record(z.string(), z.unknown()),
          })
        ),
        examples: z.array(z.object({ input: z.unknown(), output: z.unknown() })),
      })
    )
    .mutation(async ({ input }) => {
      await frontierEngine.learnSkill(input);
      return { success: true };
    }),

  /**
   * Get all capabilities
   */
  getAllCapabilities: protectedProcedure.query(async () => {
    return await frontierEngine.getAllCapabilities();
  }),

  /**
   * Get capability by ID
   */
  getCapability: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return await frontierEngine.getCapability(input.id);
    }),

  /**
   * Update capability status
   */
  updateCapabilityStatus: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        status: z.enum(['discovered', 'testing', 'active', 'deprecated']),
      })
    )
    .mutation(async ({ input }) => {
      await frontierEngine.updateCapabilityStatus(input.id, input.status);
      return { success: true };
    }),

  /**
   * Get capability statistics
   */
  getStatistics: protectedProcedure.query(async () => {
    return await frontierEngine.getStatistics();
  }),
});
