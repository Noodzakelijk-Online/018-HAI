/**
 * Screen Stream tRPC Router
 * 
 * API endpoints for screen streaming status and control
 */

import { z } from 'zod';
import { router, publicProcedure, protectedProcedure } from '../../_core/trpc';
import { screenStreamHandler } from '../../services/screenStreamHandler';

export const screenStreamRouter = router({
  /**
   * Get current stream status
   */
  getStatus: publicProcedure.query(() => {
    return screenStreamHandler.getStatus();
  }),
  
  /**
   * Get session statistics for a device
   */
  getSessionStats: publicProcedure
    .input(z.object({
      device: z.enum(['pc', 'phone'])
    }))
    .query(({ input }) => {
      const stats = screenStreamHandler.getSessionStats(input.device);
      if (!stats) {
        return null;
      }
      
      const now = Date.now();
      return {
        ...stats,
        uptime: now - stats.startTime,
        averageFps: stats.framesReceived / ((now - stats.startTime) / 1000),
        averageBytesPerFrame: stats.framesReceived > 0 
          ? stats.bytesReceived / stats.framesReceived 
          : 0,
        lastFrameAgo: now - stats.lastFrameTime
      };
    }),
  
  /**
   * Send control command to a device
   */
  sendCommand: protectedProcedure
    .input(z.object({
      device: z.enum(['pc', 'phone']),
      command: z.string(),
      params: z.record(z.unknown()).optional()
    }))
    .mutation(({ input }) => {
      const success = screenStreamHandler.sendControlCommand(
        input.device,
        input.command,
        input.params || {}
      );
      
      return {
        success,
        message: success 
          ? `Command '${input.command}' sent to ${input.device}`
          : `No agent connected for ${input.device}`
      };
    }),
  
  /**
   * PC-specific control commands
   */
  pcControl: router({
    /**
     * Click at coordinates on PC screen
     */
    click: protectedProcedure
      .input(z.object({
        x: z.number(),
        y: z.number(),
        button: z.enum(['left', 'right', 'middle']).optional()
      }))
      .mutation(({ input }) => {
        return screenStreamHandler.sendControlCommand('pc', 'click', {
          x: input.x,
          y: input.y,
          button: input.button || 'left'
        });
      }),
    
    /**
     * Double click at coordinates
     */
    doubleClick: protectedProcedure
      .input(z.object({
        x: z.number(),
        y: z.number()
      }))
      .mutation(({ input }) => {
        return screenStreamHandler.sendControlCommand('pc', 'double_click', input);
      }),
    
    /**
     * Type text on PC
     */
    type: protectedProcedure
      .input(z.object({
        text: z.string()
      }))
      .mutation(({ input }) => {
        return screenStreamHandler.sendControlCommand('pc', 'type', input);
      }),
    
    /**
     * Press key combination
     */
    pressKey: protectedProcedure
      .input(z.object({
        key: z.string(),
        modifiers: z.array(z.enum(['ctrl', 'alt', 'shift', 'win'])).optional()
      }))
      .mutation(({ input }) => {
        return screenStreamHandler.sendControlCommand('pc', 'press_key', input);
      }),
    
    /**
     * Move mouse to coordinates
     */
    moveMouse: protectedProcedure
      .input(z.object({
        x: z.number(),
        y: z.number()
      }))
      .mutation(({ input }) => {
        return screenStreamHandler.sendControlCommand('pc', 'move_mouse', input);
      }),
    
    /**
     * Scroll at current position
     */
    scroll: protectedProcedure
      .input(z.object({
        direction: z.enum(['up', 'down', 'left', 'right']),
        amount: z.number().optional()
      }))
      .mutation(({ input }) => {
        return screenStreamHandler.sendControlCommand('pc', 'scroll', input);
      }),
    
    /**
     * Take screenshot
     */
    screenshot: protectedProcedure.mutation(() => {
      return screenStreamHandler.sendControlCommand('pc', 'screenshot', {});
    }),
    
    /**
     * Start/stop recording
     */
    toggleRecording: protectedProcedure
      .input(z.object({
        action: z.enum(['start', 'stop'])
      }))
      .mutation(({ input }) => {
        return screenStreamHandler.sendControlCommand('pc', 'recording', input);
      })
  }),
  
  /**
   * Phone-specific control commands
   */
  phoneControl: router({
    /**
     * Tap at coordinates on phone screen
     */
    tap: protectedProcedure
      .input(z.object({
        x: z.number(),
        y: z.number()
      }))
      .mutation(({ input }) => {
        return screenStreamHandler.sendControlCommand('phone', 'tap', input);
      }),
    
    /**
     * Long press at coordinates
     */
    longPress: protectedProcedure
      .input(z.object({
        x: z.number(),
        y: z.number(),
        duration: z.number().optional()
      }))
      .mutation(({ input }) => {
        return screenStreamHandler.sendControlCommand('phone', 'long_press', {
          ...input,
          duration: input.duration || 1000
        });
      }),
    
    /**
     * Swipe gesture
     */
    swipe: protectedProcedure
      .input(z.object({
        startX: z.number(),
        startY: z.number(),
        endX: z.number(),
        endY: z.number(),
        duration: z.number().optional()
      }))
      .mutation(({ input }) => {
        return screenStreamHandler.sendControlCommand('phone', 'swipe', {
          start_x: input.startX,
          start_y: input.startY,
          end_x: input.endX,
          end_y: input.endY,
          duration: input.duration || 300
        });
      }),
    
    /**
     * Quick swipe in a direction
     */
    swipeDirection: protectedProcedure
      .input(z.object({
        direction: z.enum(['up', 'down', 'left', 'right'])
      }))
      .mutation(({ input }) => {
        return screenStreamHandler.sendControlCommand('phone', 'swipe_direction', input);
      }),
    
    /**
     * Type text on phone
     */
    type: protectedProcedure
      .input(z.object({
        text: z.string()
      }))
      .mutation(({ input }) => {
        return screenStreamHandler.sendControlCommand('phone', 'type', input);
      }),
    
    /**
     * Press hardware button
     */
    pressButton: protectedProcedure
      .input(z.object({
        button: z.enum(['back', 'home', 'recent', 'power', 'volume_up', 'volume_down'])
      }))
      .mutation(({ input }) => {
        return screenStreamHandler.sendControlCommand('phone', 'press_button', input);
      }),
    
    /**
     * Launch an app
     */
    launchApp: protectedProcedure
      .input(z.object({
        packageName: z.string()
      }))
      .mutation(({ input }) => {
        return screenStreamHandler.sendControlCommand('phone', 'launch_app', input);
      }),
    
    /**
     * Open URL in browser
     */
    openUrl: protectedProcedure
      .input(z.object({
        url: z.string()
      }))
      .mutation(({ input }) => {
        return screenStreamHandler.sendControlCommand('phone', 'open_url', input);
      }),
    
    /**
     * Take screenshot
     */
    screenshot: protectedProcedure.mutation(() => {
      return screenStreamHandler.sendControlCommand('phone', 'screenshot', {});
    }),
    
    /**
     * Get device info
     */
    getDeviceInfo: publicProcedure.query(() => {
      const stats = screenStreamHandler.getSessionStats('phone');
      return stats?.deviceInfo || null;
    }),
    
    /**
     * Wake/lock screen
     */
    screenControl: protectedProcedure
      .input(z.object({
        action: z.enum(['wake', 'lock'])
      }))
      .mutation(({ input }) => {
        return screenStreamHandler.sendControlCommand('phone', 'screen_control', input);
      })
  })
});

export type ScreenStreamRouter = typeof screenStreamRouter;
