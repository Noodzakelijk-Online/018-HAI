/**
 * Knowledge Base Router
 * tRPC procedures for knowledge management
 */

import { z } from "zod";
import { router, protectedProcedure } from "../../_core/trpc";
import { KnowledgeBaseService, KnowledgeType } from "../../services/KnowledgeBaseService";
import { KnowledgeIngestionService } from "../../services/KnowledgeIngestionService";

const knowledgeTypeEnum = z.enum(['fact', 'preference', 'routine', 'relationship', 'event', 'emotion', 'skill', 'context', 'insight']);

export const knowledgeBaseRouter = router({
  add: protectedProcedure
    .input(z.object({
      householdId: z.number(),
      type: knowledgeTypeEnum,
      content: z.string().min(1),
      context: z.string().optional(),
      source: z.string().default('manual'),
      sourceId: z.string().optional(),
      importance: z.number().min(0).max(1).optional(),
      tags: z.array(z.string()).optional(),
      relatedMembers: z.array(z.string()).optional(),
      metadata: z.record(z.unknown()).optional(),
    }))
    .mutation(async ({ input }) => {
      return KnowledgeBaseService.addKnowledge(input);
    }),

  search: protectedProcedure
    .input(z.object({
      query: z.string().min(1),
      householdId: z.number(),
      types: z.array(knowledgeTypeEnum).optional(),
      limit: z.number().min(1).max(100).optional(),
      minSimilarity: z.number().min(0).max(1).optional(),
    }))
    .query(async ({ input }) => {
      return KnowledgeBaseService.search(input);
    }),

  getStats: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ input }) => {
      return KnowledgeBaseService.getStats(input.householdId);
    }),

  getRecent: protectedProcedure
    .input(z.object({
      householdId: z.number(),
      limit: z.number().min(1).max(100).optional(),
    }))
    .query(async ({ input }) => {
      return KnowledgeBaseService.getRecent(input.householdId, input.limit);
    }),

  getByType: protectedProcedure
    .input(z.object({
      householdId: z.number(),
      type: knowledgeTypeEnum,
      limit: z.number().min(1).max(100).optional(),
    }))
    .query(async ({ input }) => {
      return KnowledgeBaseService.getByType(input.householdId, input.type, input.limit);
    }),

  archive: protectedProcedure
    .input(z.object({ knowledgeId: z.number() }))
    .mutation(async ({ input }) => {
      return KnowledgeBaseService.archive(input.knowledgeId);
    }),

  getRelated: protectedProcedure
    .input(z.object({ knowledgeId: z.number() }))
    .query(async ({ input }) => {
      return KnowledgeBaseService.getRelated(input.knowledgeId);
    }),

  consolidate: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .mutation(async ({ input }) => {
      return KnowledgeBaseService.consolidate(input.householdId);
    }),

  extractKnowledge: protectedProcedure
    .input(z.object({
      text: z.string().min(1),
      source: z.string(),
      householdId: z.number(),
      context: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      return KnowledgeBaseService.extractKnowledge(input);
    }),

  /**
   * Chat endpoint for conversational knowledge entry
   * Processes natural language input and extracts knowledge
   */
  chat: protectedProcedure
    .input(z.object({
      message: z.string().min(1),
      householdId: z.number(),
      conversationHistory: z.array(z.object({
        role: z.enum(['user', 'assistant', 'system']),
        content: z.string(),
      })).optional(),
    }))
    .mutation(async ({ input }) => {
      return KnowledgeBaseService.processChat(input);
    }),

  // Ingestion endpoints
  getIngestionStatus: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ input }) => {
      return KnowledgeIngestionService.getIngestionStatus(input.householdId);
    }),

  enableAutoIngestion: protectedProcedure
    .input(z.object({
      householdId: z.number(),
      sources: z.object({
        activities: z.boolean(),
        decisions: z.boolean(),
        conversations: z.boolean(),
        emails: z.boolean(),
        calendar: z.boolean(),
        whatsapp: z.boolean(),
        documents: z.boolean(),
      }),
      autoIngest: z.boolean(),
      intervalMinutes: z.number().min(5).max(1440),
    }))
    .mutation(async ({ input }) => {
      return KnowledgeIngestionService.enableAutoIngestion(input);
    }),

  disableAutoIngestion: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .mutation(async ({ input }) => {
      return KnowledgeIngestionService.disableAutoIngestion(input.householdId);
    }),

  triggerIngestion: protectedProcedure
    .input(z.object({
      householdId: z.number(),
      source: z.enum(['all', 'activities', 'decisions', 'conversations', 'emails', 'calendar', 'whatsapp', 'documents']),
    }))
    .mutation(async ({ input }) => {
      return KnowledgeIngestionService.triggerIngestion(input.householdId, input.source);
    }),
});
