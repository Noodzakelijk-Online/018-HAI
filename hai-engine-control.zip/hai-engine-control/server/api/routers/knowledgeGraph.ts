import { z } from "zod";
import { protectedProcedure, router } from "../../_core/trpc";
import { KnowledgeGraphEnhanced } from "../../services/KnowledgeGraphEnhanced";
import { getDb } from "../../db";
import { entities, relationships } from "../../../drizzle/schema";
import { eq, desc, like, or } from "drizzle-orm";

/**
 * Knowledge Graph router with enhanced features
 */
export const knowledgeGraphRouter = router({
  /**
   * Get all entities with optional filtering
   */
  getEntities: protectedProcedure
    .input(z.object({
      entityType: z.string().optional(),
      search: z.string().optional(),
      limit: z.number().optional().default(100),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];

      let results;

      if (input.entityType) {
        results = await db.select().from(entities)
          .where(eq(entities.entityType, input.entityType))
          .orderBy(desc(entities.createdAt))
          .limit(input.limit);
      } else {
        results = await db.select().from(entities)
          .orderBy(desc(entities.createdAt))
          .limit(input.limit);
      }

      // Apply search filter if provided
      if (input.search) {
        const searchLower = input.search.toLowerCase();
        return results.filter(e => 
          e.name.toLowerCase().includes(searchLower) ||
          e.entityType.toLowerCase().includes(searchLower)
        );
      }

      return results;
    }),

  /**
   * Get all relationships
   */
  getRelationships: protectedProcedure
    .input(z.object({
      entityId: z.number().optional(),
      relationshipType: z.string().optional(),
      limit: z.number().optional().default(100),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];

      let results;

      if (input.entityId && input.relationshipType) {
        // Both filters
        const allRels = await db.select().from(relationships).limit(input.limit);
        results = allRels.filter(r => 
          (r.sourceEntityId === input.entityId || r.targetEntityId === input.entityId) &&
          r.relationshipType === input.relationshipType
        );
      } else if (input.entityId) {
        // Entity filter only
        results = await db.select().from(relationships)
          .where(
            or(
              eq(relationships.sourceEntityId, input.entityId),
              eq(relationships.targetEntityId, input.entityId)
            )
          )
          .limit(input.limit);
      } else if (input.relationshipType) {
        // Relationship type filter only
        results = await db.select().from(relationships)
          .where(eq(relationships.relationshipType, input.relationshipType))
          .limit(input.limit);
      } else {
        // No filters
        results = await db.select().from(relationships).limit(input.limit);
      }
      return results;
    }),

  /**
   * Find shortest path between two entities
   */
  findShortestPath: protectedProcedure
    .input(z.object({
      sourceEntityId: z.number(),
      targetEntityId: z.number(),
      maxDepth: z.number().optional().default(10),
    }))
    .query(async ({ input }) => {
      return await KnowledgeGraphEnhanced.findShortestPath(input);
    }),

  /**
   * Detect clusters of related entities
   */
  detectClusters: protectedProcedure
    .input(z.object({
      minClusterSize: z.number().optional().default(3),
      maxClusters: z.number().optional().default(10),
    }))
    .query(async ({ input }) => {
      return await KnowledgeGraphEnhanced.detectClusters(input);
    }),

  /**
   * Calculate centrality measures
   */
  calculateCentrality: protectedProcedure
    .input(z.object({
      entityId: z.number().optional(),
      measure: z.enum(['degree', 'betweenness', 'closeness']).optional().default('degree'),
    }))
    .query(async ({ input }) => {
      return await KnowledgeGraphEnhanced.calculateCentrality(input);
    }),

  /**
   * Get temporal knowledge
   */
  getTemporalKnowledge: protectedProcedure
    .input(z.object({
      startTime: z.string().transform(s => new Date(s)),
      endTime: z.string().transform(s => new Date(s)),
      entityType: z.string().optional(),
    }))
    .query(async ({ input }) => {
      return await KnowledgeGraphEnhanced.getTemporalKnowledge(input);
    }),

  /**
   * Track entity evolution
   */
  trackEntityEvolution: protectedProcedure
    .input(z.object({
      entityId: z.number(),
    }))
    .query(async ({ input }) => {
      return await KnowledgeGraphEnhanced.trackEntityEvolution(input);
    }),

  /**
   * Apply inference rules
   */
  applyInferenceRules: protectedProcedure
    .input(z.object({
      rules: z.array(z.object({
        id: z.string(),
        name: z.string(),
        description: z.string(),
        pattern: z.object({
          sourceType: z.string().optional(),
          relationshipType: z.string().optional(),
          targetType: z.string().optional(),
        }),
        inference: z.object({
          newRelationshipType: z.string(),
          confidence: z.number(),
        }),
      })).optional(),
    }))
    .mutation(async ({ input }) => {
      return await KnowledgeGraphEnhanced.applyInferenceRules(input);
    }),

  /**
   * Get graph visualization data
   */
  getVisualizationData: protectedProcedure
    .input(z.object({
      maxNodes: z.number().optional().default(100),
      centerEntityId: z.number().optional(),
      depth: z.number().optional().default(2),
    }))
    .query(async ({ input }) => {
      return await KnowledgeGraphEnhanced.getVisualizationData(input);
    }),

  /**
   * Get entity types (for filters)
   */
  getEntityTypes: protectedProcedure
    .query(async () => {
      const db = await getDb();
      if (!db) return [];

      const allEntities = await db.select().from(entities);
      const types = new Set(allEntities.map(e => e.entityType));
      return Array.from(types).sort();
    }),

  /**
   * Get relationship types (for filters)
   */
  getRelationshipTypes: protectedProcedure
    .query(async () => {
      const db = await getDb();
      if (!db) return [];

      const allRelationships = await db.select().from(relationships);
      const types = new Set(allRelationships.map(r => r.relationshipType));
      return Array.from(types).sort();
    }),

  /**
   * Get entity with full details (including relationships)
   */
  getEntityDetails: protectedProcedure
    .input(z.object({
      entityId: z.number(),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return null;

      // Get entity
      const entity = await db
        .select()
        .from(entities)
        .where(eq(entities.id, input.entityId))
        .limit(1);

      if (entity.length === 0) return null;

      // Get outgoing relationships
      const outgoing = await db
        .select()
        .from(relationships)
        .where(eq(relationships.sourceEntityId, input.entityId));

      // Get incoming relationships
      const incoming = await db
        .select()
        .from(relationships)
        .where(eq(relationships.targetEntityId, input.entityId));

      // Get connected entities
      const connectedEntityIds = [
        ...outgoing.map(r => r.targetEntityId),
        ...incoming.map(r => r.sourceEntityId),
      ];

      const connectedEntities = connectedEntityIds.length > 0
        ? await db.select().from(entities).where(
            or(...connectedEntityIds.map(id => eq(entities.id, id)))
          )
        : [];

      return {
        entity: entity[0],
        outgoingRelationships: outgoing,
        incomingRelationships: incoming,
        connectedEntities,
      };
    }),
});
