/**
 * OAuth Router
 * 
 * Handles OAuth flows for external service integrations:
 * - Gmail
 * - Google Calendar
 * - Financial services (Plaid)
 */

import { z } from 'zod';
import { router, protectedProcedure } from '../../_core/trpc';
import { TRPCError } from '@trpc/server';
import { GmailOAuthConnector } from '../../services/oauth/GmailOAuthConnector';
import { GoogleCalendarOAuthConnector } from '../../services/oauth/GoogleCalendarOAuthConnector';
import { plaidConnector } from '../../services/oauth/PlaidConnector';

// Store active OAuth sessions (in production, use database)
const oauthSessions = new Map<string, {
  type: 'gmail' | 'calendar' | 'plaid';
  userId: number;
  state: string;
  createdAt: Date;
}>();

// Store connected accounts (in production, use database)
const connectedAccounts = new Map<string, {
  type: 'gmail' | 'calendar' | 'plaid';
  userId: number;
  tokens: any;
  profile: any;
  connectedAt: Date;
}>();

export const oauthRouter = router({
  /**
   * Get OAuth authorization URL for Gmail
   */
  getGmailAuthUrl: protectedProcedure
    .mutation(async ({ ctx }) => {
      const clientId = process.env.GOOGLE_CLIENT_ID;
      const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
      const redirectUri = process.env.GOOGLE_REDIRECT_URI || `${process.env.APP_URL}/api/oauth/callback/gmail`;

      if (!clientId || !clientSecret) {
        throw new TRPCError({
          code: 'PRECONDITION_FAILED',
          message: 'Google OAuth credentials not configured',
        });
      }

      const connector = new GmailOAuthConnector({
        clientId,
        clientSecret,
        redirectUri,
      });

      const state = `gmail_${ctx.user.id}_${Date.now()}`;
      
      oauthSessions.set(state, {
        type: 'gmail',
        userId: ctx.user.id,
        state,
        createdAt: new Date(),
      });

      const authUrl = connector.getAuthUrl(state);

      return { authUrl, state };
    }),

  /**
   * Get OAuth authorization URL for Google Calendar
   */
  getCalendarAuthUrl: protectedProcedure
    .mutation(async ({ ctx }) => {
      const clientId = process.env.GOOGLE_CLIENT_ID;
      const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
      const redirectUri = process.env.GOOGLE_REDIRECT_URI || `${process.env.APP_URL}/api/oauth/callback/calendar`;

      if (!clientId || !clientSecret) {
        throw new TRPCError({
          code: 'PRECONDITION_FAILED',
          message: 'Google OAuth credentials not configured',
        });
      }

      const connector = new GoogleCalendarOAuthConnector({
        clientId,
        clientSecret,
        redirectUri,
      });

      const state = `calendar_${ctx.user.id}_${Date.now()}`;
      
      oauthSessions.set(state, {
        type: 'calendar',
        userId: ctx.user.id,
        state,
        createdAt: new Date(),
      });

      const authUrl = connector.getAuthUrl(state);

      return { authUrl, state };
    }),

  /**
   * Handle OAuth callback
   */
  handleCallback: protectedProcedure
    .input(z.object({
      code: z.string(),
      state: z.string(),
    }))
    .mutation(async ({ ctx, input }) => {
      const session = oauthSessions.get(input.state);
      
      if (!session) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Invalid or expired OAuth session',
        });
      }

      if (session.userId !== ctx.user.id) {
        throw new TRPCError({
          code: 'FORBIDDEN',
          message: 'OAuth session does not belong to current user',
        });
      }

      const clientId = process.env.GOOGLE_CLIENT_ID!;
      const clientSecret = process.env.GOOGLE_CLIENT_SECRET!;

      try {
        if (session.type === 'gmail') {
          const redirectUri = process.env.GOOGLE_REDIRECT_URI || `${process.env.APP_URL}/api/oauth/callback/gmail`;
          const connector = new GmailOAuthConnector({ clientId, clientSecret, redirectUri });
          
          const tokens = await connector.exchangeCode(input.code);
          const profile = await connector.getProfile();

          const accountKey = `gmail_${ctx.user.id}`;
          connectedAccounts.set(accountKey, {
            type: 'gmail',
            userId: ctx.user.id,
            tokens,
            profile,
            connectedAt: new Date(),
          });

          oauthSessions.delete(input.state);

          return {
            success: true,
            type: 'gmail',
            profile: {
              email: profile.email,
              messagesTotal: profile.messagesTotal,
            },
          };
        } else if (session.type === 'calendar') {
          const redirectUri = process.env.GOOGLE_REDIRECT_URI || `${process.env.APP_URL}/api/oauth/callback/calendar`;
          const connector = new GoogleCalendarOAuthConnector({ clientId, clientSecret, redirectUri });
          
          const tokens = await connector.exchangeCode(input.code);
          const calendars = await connector.listCalendars();
          const primaryCalendar = calendars.find(c => c.primary) || calendars[0];

          const accountKey = `calendar_${ctx.user.id}`;
          connectedAccounts.set(accountKey, {
            type: 'calendar',
            userId: ctx.user.id,
            tokens,
            profile: { calendars, primaryCalendar },
            connectedAt: new Date(),
          });

          oauthSessions.delete(input.state);

          return {
            success: true,
            type: 'calendar',
            profile: {
              calendarCount: calendars.length,
              primaryCalendar: primaryCalendar?.summary,
            },
          };
        }

        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Unknown OAuth type',
        });
      } catch (error) {
        console.error('[OAuth] Callback error:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to complete OAuth flow',
        });
      }
    }),

  /**
   * Get connected accounts status
   */
  getConnectedAccounts: protectedProcedure
    .query(async ({ ctx }) => {
      const accounts: {
        type: string;
        connected: boolean;
        profile?: any;
        connectedAt?: Date;
      }[] = [];

      // Check Gmail
      const gmailAccount = connectedAccounts.get(`gmail_${ctx.user.id}`);
      accounts.push({
        type: 'gmail',
        connected: !!gmailAccount,
        profile: gmailAccount?.profile,
        connectedAt: gmailAccount?.connectedAt,
      });

      // Check Calendar
      const calendarAccount = connectedAccounts.get(`calendar_${ctx.user.id}`);
      accounts.push({
        type: 'calendar',
        connected: !!calendarAccount,
        profile: calendarAccount?.profile,
        connectedAt: calendarAccount?.connectedAt,
      });

      // Check Plaid
      const plaidAccount = connectedAccounts.get(`plaid_${ctx.user.id}`);
      accounts.push({
        type: 'plaid',
        connected: !!plaidAccount,
        profile: plaidAccount?.profile,
        connectedAt: plaidAccount?.connectedAt,
      });

      return accounts;
    }),

  /**
   * Disconnect an account
   */
  disconnectAccount: protectedProcedure
    .input(z.object({
      type: z.enum(['gmail', 'calendar', 'plaid']),
    }))
    .mutation(async ({ ctx, input }) => {
      const accountKey = `${input.type}_${ctx.user.id}`;
      const account = connectedAccounts.get(accountKey);

      if (!account) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Account not connected',
        });
      }

      connectedAccounts.delete(accountKey);

      return { success: true };
    }),

  /**
   * Test Gmail connection
   */
  testGmailConnection: protectedProcedure
    .mutation(async ({ ctx }) => {
      const account = connectedAccounts.get(`gmail_${ctx.user.id}`);
      
      if (!account) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Gmail not connected',
        });
      }

      const clientId = process.env.GOOGLE_CLIENT_ID!;
      const clientSecret = process.env.GOOGLE_CLIENT_SECRET!;
      const redirectUri = process.env.GOOGLE_REDIRECT_URI || `${process.env.APP_URL}/api/oauth/callback/gmail`;

      const connector = new GmailOAuthConnector({ clientId, clientSecret, redirectUri });
      await connector.setTokens(account.tokens);

      try {
        const profile = await connector.getProfile();
        return {
          success: true,
          profile: {
            email: profile.email,
            messagesTotal: profile.messagesTotal,
          },
        };
      } catch (error) {
        return {
          success: false,
          error: 'Connection test failed',
        };
      }
    }),

  /**
   * Test Calendar connection
   */
  testCalendarConnection: protectedProcedure
    .mutation(async ({ ctx }) => {
      const account = connectedAccounts.get(`calendar_${ctx.user.id}`);
      
      if (!account) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Calendar not connected',
        });
      }

      const clientId = process.env.GOOGLE_CLIENT_ID!;
      const clientSecret = process.env.GOOGLE_CLIENT_SECRET!;
      const redirectUri = process.env.GOOGLE_REDIRECT_URI || `${process.env.APP_URL}/api/oauth/callback/calendar`;

      const connector = new GoogleCalendarOAuthConnector({ clientId, clientSecret, redirectUri });
      await connector.setTokens(account.tokens);

      try {
        const calendars = await connector.listCalendars();
        return {
          success: true,
          calendarCount: calendars.length,
        };
      } catch (error) {
        return {
          success: false,
          error: 'Connection test failed',
        };
      }
    }),

  /**
   * Fetch recent emails
   */
  fetchRecentEmails: protectedProcedure
    .input(z.object({
      maxResults: z.number().min(1).max(50).default(10),
      query: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const account = connectedAccounts.get(`gmail_${ctx.user.id}`);
      
      if (!account) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Gmail not connected',
        });
      }

      const clientId = process.env.GOOGLE_CLIENT_ID!;
      const clientSecret = process.env.GOOGLE_CLIENT_SECRET!;
      const redirectUri = process.env.GOOGLE_REDIRECT_URI || `${process.env.APP_URL}/api/oauth/callback/gmail`;

      const connector = new GmailOAuthConnector({ clientId, clientSecret, redirectUri });
      await connector.setTokens(account.tokens);

      const { messages } = await connector.listMessages({
        maxResults: input.maxResults,
        query: input.query,
      });

      return messages.map(m => ({
        id: m.id,
        from: m.from,
        subject: m.subject,
        date: m.date,
        isUnread: m.isUnread,
        hasAttachments: m.hasAttachments,
      }));
    }),

  /**
   * Create Plaid Link token
   */
  createPlaidLinkToken: protectedProcedure
    .mutation(async ({ ctx }) => {
      const clientId = process.env.PLAID_CLIENT_ID;
      const secret = process.env.PLAID_SECRET;
      const environment = (process.env.PLAID_ENVIRONMENT || 'sandbox') as 'sandbox' | 'development' | 'production';

      if (!clientId || !secret) {
        throw new TRPCError({
          code: 'PRECONDITION_FAILED',
          message: 'Plaid credentials not configured. Please add PLAID_CLIENT_ID and PLAID_SECRET in Settings → Secrets.',
        });
      }

      plaidConnector.initialize({ clientId, secret, environment });

      const linkToken = await plaidConnector.createLinkToken({
        userId: String(ctx.user.id),
        clientName: 'HAI Engine',
        products: ['transactions', 'auth'],
        countryCodes: ['US'],
        language: 'en',
      });

      return {
        linkToken: linkToken.linkToken,
        expiration: linkToken.expiration,
      };
    }),

  /**
   * Exchange Plaid public token for access token
   */
  exchangePlaidToken: protectedProcedure
    .input(z.object({
      publicToken: z.string(),
      institutionId: z.string(),
      institutionName: z.string(),
    }))
    .mutation(async ({ ctx, input }) => {
      const clientId = process.env.PLAID_CLIENT_ID;
      const secret = process.env.PLAID_SECRET;
      const environment = (process.env.PLAID_ENVIRONMENT || 'sandbox') as 'sandbox' | 'development' | 'production';

      if (!clientId || !secret) {
        throw new TRPCError({
          code: 'PRECONDITION_FAILED',
          message: 'Plaid credentials not configured',
        });
      }

      plaidConnector.initialize({ clientId, secret, environment });

      const { accessToken, itemId } = await plaidConnector.exchangePublicToken(input.publicToken);
      const accounts = await plaidConnector.getAccounts(accessToken);

      // Store the tokens
      plaidConnector.storeTokens(String(ctx.user.id), {
        accessToken,
        itemId,
        institutionId: input.institutionId,
        institutionName: input.institutionName,
        linkedAt: new Date(),
      });

      // Store in connected accounts
      connectedAccounts.set(`plaid_${ctx.user.id}`, {
        type: 'plaid',
        userId: ctx.user.id,
        tokens: { accessToken, itemId },
        profile: {
          institutionName: input.institutionName,
          accountCount: accounts.length,
          accounts: accounts.map(a => ({
            name: a.name,
            type: a.type,
            mask: a.mask,
          })),
        },
        connectedAt: new Date(),
      });

      return {
        success: true,
        accountCount: accounts.length,
        accounts: accounts.map(a => ({
          accountId: a.accountId,
          name: a.name,
          type: a.type,
          subtype: a.subtype,
          mask: a.mask,
        })),
      };
    }),

  /**
   * Get Plaid account balances
   */
  getPlaidBalances: protectedProcedure
    .query(async ({ ctx }) => {
      const account = connectedAccounts.get(`plaid_${ctx.user.id}`);
      
      if (!account) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Plaid not connected',
        });
      }

      const clientId = process.env.PLAID_CLIENT_ID!;
      const secret = process.env.PLAID_SECRET!;
      const environment = (process.env.PLAID_ENVIRONMENT || 'sandbox') as 'sandbox' | 'development' | 'production';

      plaidConnector.initialize({ clientId, secret, environment });

      const balances = await plaidConnector.getBalances(account.tokens.accessToken);

      return balances.map(a => ({
        accountId: a.accountId,
        name: a.name,
        type: a.type,
        subtype: a.subtype,
        mask: a.mask,
        balances: a.balances,
      }));
    }),

  /**
   * Get Plaid transactions
   */
  getPlaidTransactions: protectedProcedure
    .input(z.object({
      startDate: z.string(),
      endDate: z.string(),
      count: z.number().min(1).max(500).default(100),
    }))
    .query(async ({ ctx, input }) => {
      const account = connectedAccounts.get(`plaid_${ctx.user.id}`);
      
      if (!account) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Plaid not connected',
        });
      }

      const clientId = process.env.PLAID_CLIENT_ID!;
      const secret = process.env.PLAID_SECRET!;
      const environment = (process.env.PLAID_ENVIRONMENT || 'sandbox') as 'sandbox' | 'development' | 'production';

      plaidConnector.initialize({ clientId, secret, environment });

      const { transactions, totalTransactions } = await plaidConnector.getTransactions(
        account.tokens.accessToken,
        input.startDate,
        input.endDate,
        { count: input.count }
      );

      return {
        transactions: transactions.map(t => ({
          transactionId: t.transactionId,
          accountId: t.accountId,
          amount: t.amount,
          date: t.date,
          name: t.name,
          merchantName: t.merchantName,
          category: t.category,
          pending: t.pending,
        })),
        totalTransactions,
      };
    }),

  /**
   * Search financial institutions
   */
  searchInstitutions: protectedProcedure
    .input(z.object({
      query: z.string().min(1),
    }))
    .query(async ({ input }) => {
      const clientId = process.env.PLAID_CLIENT_ID;
      const secret = process.env.PLAID_SECRET;
      const environment = (process.env.PLAID_ENVIRONMENT || 'sandbox') as 'sandbox' | 'development' | 'production';

      if (!clientId || !secret) {
        return [];
      }

      plaidConnector.initialize({ clientId, secret, environment });

      const institutions = await plaidConnector.searchInstitutions(input.query);

      return institutions.map(i => ({
        institutionId: i.institutionId,
        name: i.name,
        logo: i.logo,
        primaryColor: i.primaryColor,
      }));
    }),

  /**
   * Fetch upcoming calendar events
   */
  fetchUpcomingEvents: protectedProcedure
    .input(z.object({
      days: z.number().min(1).max(30).default(7),
      maxResults: z.number().min(1).max(100).default(20),
    }))
    .mutation(async ({ ctx, input }) => {
      const account = connectedAccounts.get(`calendar_${ctx.user.id}`);
      
      if (!account) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Calendar not connected',
        });
      }

      const clientId = process.env.GOOGLE_CLIENT_ID!;
      const clientSecret = process.env.GOOGLE_CLIENT_SECRET!;
      const redirectUri = process.env.GOOGLE_REDIRECT_URI || `${process.env.APP_URL}/api/oauth/callback/calendar`;

      const connector = new GoogleCalendarOAuthConnector({ clientId, clientSecret, redirectUri });
      await connector.setTokens(account.tokens);

      const now = new Date();
      const future = new Date(now.getTime() + input.days * 24 * 60 * 60 * 1000);

      const { events } = await connector.listEvents({
        timeMin: now,
        timeMax: future,
        maxResults: input.maxResults,
      });

      return events.map(e => ({
        id: e.id,
        summary: e.summary,
        start: e.start,
        end: e.end,
        location: e.location,
        isAllDay: e.isAllDay,
        attendeeCount: e.attendees?.length || 0,
      }));
    }),
});

export default oauthRouter;
