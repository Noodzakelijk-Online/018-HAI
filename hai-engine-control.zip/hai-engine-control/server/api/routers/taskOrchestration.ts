import { z } from "zod";
import { protectedProcedure, router } from "../../_core/trpc";
import { TaskOrchestrationEngine } from "../../services/TaskOrchestrationEngine";
import { getDb } from "../../db";
import { tasks } from "../../../drizzle/schema";
import { eq, and, desc } from "drizzle-orm";

export const taskOrchestrationRouter = router({
  /**
   * Decompose a goal into subtasks
   */
  decomposeGoal: protectedProcedure
    .input(
      z.object({
        goal: z.string(),
        context: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const decomposition = await TaskOrchestrationEngine.decomposeGoal({
        userId: ctx.user.id,
        goal: input.goal,
        context: input.context,
      });

      return decomposition;
    }),

  /**
   * Create tasks from decomposition
   */
  createTasksFromDecomposition: protectedProcedure
    .input(
      z.object({
        decomposition: z.object({
          goal: z.string(),
          subtasks: z.array(
            z.object({
              title: z.string(),
              description: z.string(),
              taskType: z.string(),
              priority: z.enum(['low', 'medium', 'high', 'urgent']),
              estimatedTime: z.number().optional(),
              dependencies: z.array(z.number()).optional(),
              assignedEngine: z.string().optional(),
            })
          ),
          executionOrder: z.array(z.number()),
          estimatedTotalTime: z.number(),
          complexity: z.enum(['simple', 'moderate', 'complex']),
        }),
        requireApproval: z.boolean().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const createdTasks = await TaskOrchestrationEngine.createTasksFromDecomposition({
        userId: ctx.user.id,
        decomposition: input.decomposition,
        requireApproval: input.requireApproval,
      });

      return createdTasks;
    }),

  /**
   * Get tasks ready for execution
   */
  getReadyTasks: protectedProcedure.query(async ({ ctx }) => {
    const readyTasks = await TaskOrchestrationEngine.getReadyTasks(ctx.user.id);
    return readyTasks;
  }),

  /**
   * Start a task
   */
  startTask: protectedProcedure
    .input(z.object({ taskId: z.number() }))
    .mutation(async ({ input }) => {
      const success = await TaskOrchestrationEngine.startTask(input.taskId);
      return { success };
    }),

  /**
   * Complete a task
   */
  completeTask: protectedProcedure
    .input(
      z.object({
        taskId: z.number(),
        result: z.any().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const success = await TaskOrchestrationEngine.completeTask({
        taskId: input.taskId,
        result: input.result,
      });
      return { success };
    }),

  /**
   * Fail a task
   */
  failTask: protectedProcedure
    .input(
      z.object({
        taskId: z.number(),
        error: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const success = await TaskOrchestrationEngine.failTask({
        taskId: input.taskId,
        error: input.error,
      });
      return { success };
    }),

  /**
   * Cancel a task
   */
  cancelTask: protectedProcedure
    .input(z.object({ taskId: z.number() }))
    .mutation(async ({ input }) => {
      const success = await TaskOrchestrationEngine.cancelTask(input.taskId);
      return { success };
    }),

  /**
   * Get all tasks for user
   */
  getAllTasks: protectedProcedure
    .input(
      z.object({
        status: z.string().optional(),
        limit: z.number().optional(),
      })
    )
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];

      if (input.status) {
        const result = await db
          .select()
          .from(tasks)
          .where(and(
            eq(tasks.userId, ctx.user.id),
            eq(tasks.status, input.status as any)
          ))
          .orderBy(desc(tasks.createdAt))
          .limit(input.limit || 100);
        return result;
      } else {
        const result = await db
          .select()
          .from(tasks)
          .where(eq(tasks.userId, ctx.user.id))
          .orderBy(desc(tasks.createdAt))
          .limit(input.limit || 100);
        return result;
      }
    }),

  /**
   * Get task by ID
   */
  getTaskById: protectedProcedure
    .input(z.object({ taskId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return null;

      const result = await db
        .select()
        .from(tasks)
        .where(and(
          eq(tasks.id, input.taskId),
          eq(tasks.userId, ctx.user.id)
        ))
        .limit(1);

      return result.length > 0 ? result[0] : null;
    }),

  /**
   * Get task statistics
   */
  getTaskStats: protectedProcedure.query(async ({ ctx }) => {
    const stats = await TaskOrchestrationEngine.getTaskStats(ctx.user.id);
    return stats;
  }),

  /**
   * Approve a task
   */
  approveTask: protectedProcedure
    .input(z.object({ taskId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return { success: false };

      try {
        await db
          .update(tasks)
          .set({ status: 'approved' as any })
          .where(and(
            eq(tasks.id, input.taskId),
            eq(tasks.userId, ctx.user.id)
          ));

        return { success: true };
      } catch (error) {
        console.error('Error approving task:', error);
        return { success: false };
      }
    }),

  /**
   * Get tasks by goal
   */
  getTasksByGoal: protectedProcedure
    .input(z.object({ goal: z.string() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];

      const allTasks = await db
        .select()
        .from(tasks)
        .where(eq(tasks.userId, ctx.user.id))
        .orderBy(desc(tasks.createdAt));

      // Filter by goal in metadata
      const filteredTasks = allTasks.filter((task: any) => {
        const metadata = task.metadata as any;
        return metadata?.goal === input.goal;
      });

      return filteredTasks;
    }),
});
