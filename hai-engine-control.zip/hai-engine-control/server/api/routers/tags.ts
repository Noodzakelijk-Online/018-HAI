import { z } from "zod";
import { router, protectedProcedure } from "../../_core/trpc";
import { getDb } from "../../db";
import { tags, serviceTags } from "../../../drizzle/schema";
import { eq, and } from "drizzle-orm";
import { TRPCError } from "@trpc/server";

export const tagsRouter = router({
  // List all tags for current user
  list: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });

    const userTags = await db
      .select()
      .from(tags)
      .where(eq(tags.userId, ctx.user.id));

    return userTags;
  }),

  // Create a new tag
  create: protectedProcedure
    .input(
      z.object({
        name: z.string().min(1).max(50),
        color: z.string().regex(/^#[0-9A-Fa-f]{6}$/),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });

      const result = await db.insert(tags).values({
        userId: ctx.user.id,
        name: input.name,
        color: input.color,
      });

      return { id: Number((result as any).insertId) };
    }),

  // Update a tag
  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1).max(50).optional(),
        color: z.string().regex(/^#[0-9A-Fa-f]{6}$/).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });

      // Verify ownership
      const tag = await db
        .select()
        .from(tags)
        .where(and(eq(tags.id, input.id), eq(tags.userId, ctx.user.id)))
        .limit(1);

      if (tag.length === 0) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Tag not found" });
      }

      const updateData: any = {};
      if (input.name !== undefined) updateData.name = input.name;
      if (input.color !== undefined) updateData.color = input.color;

      await db.update(tags).set(updateData).where(eq(tags.id, input.id));

      return { success: true };
    }),

  // Delete a tag
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });

      // Verify ownership
      const tag = await db
        .select()
        .from(tags)
        .where(and(eq(tags.id, input.id), eq(tags.userId, ctx.user.id)))
        .limit(1);

      if (tag.length === 0) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Tag not found" });
      }

      // Delete all service-tag associations first
      await db.delete(serviceTags).where(eq(serviceTags.tagId, input.id));

      // Delete the tag
      await db.delete(tags).where(eq(tags.id, input.id));

      return { success: true };
    }),

  // Add tag to service
  addToService: protectedProcedure
    .input(
      z.object({
        serviceId: z.number(),
        tagId: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });

      // Verify tag ownership
      const tag = await db
        .select()
        .from(tags)
        .where(and(eq(tags.id, input.tagId), eq(tags.userId, ctx.user.id)))
        .limit(1);

      if (tag.length === 0) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Tag not found" });
      }

      // Check if already exists
      const existing = await db
        .select()
        .from(serviceTags)
        .where(
          and(
            eq(serviceTags.serviceId, input.serviceId),
            eq(serviceTags.tagId, input.tagId)
          )
        )
        .limit(1);

      if (existing.length > 0) {
        return { success: true, message: "Tag already added" };
      }

      await db.insert(serviceTags).values({
        serviceId: input.serviceId,
        tagId: input.tagId,
      });

      return { success: true };
    }),

  // Remove tag from service
  removeFromService: protectedProcedure
    .input(
      z.object({
        serviceId: z.number(),
        tagId: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });

      await db
        .delete(serviceTags)
        .where(
          and(
            eq(serviceTags.serviceId, input.serviceId),
            eq(serviceTags.tagId, input.tagId)
          )
        );

      return { success: true };
    }),

  // Get tags for a specific service
  getServiceTags: protectedProcedure
    .input(z.object({ serviceId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });

      const result = await db
        .select({
          id: tags.id,
          name: tags.name,
          color: tags.color,
        })
        .from(serviceTags)
        .innerJoin(tags, eq(serviceTags.tagId, tags.id))
        .where(
          and(
            eq(serviceTags.serviceId, input.serviceId),
            eq(tags.userId, ctx.user.id)
          )
        );

      return result;
    }),
});
