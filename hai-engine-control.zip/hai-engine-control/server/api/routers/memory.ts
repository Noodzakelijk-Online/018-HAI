/**
 * HOUSEHOLD MEMORY API ROUTER
 */

import { z } from 'zod';
import { router, protectedProcedure } from '../../_core/trpc';
import { householdMemoryService, type MemoryType, type MemoryImportance, type ConflictStatus } from '../../services/memory/HouseholdMemory';

export const memoryRouter = router({
  // Memory Management
  memories: router({
    store: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        type: z.enum(['fact', 'preference', 'event', 'relationship', 'routine', 'conflict', 'resolution']),
        category: z.string(),
        subject: z.string(),
        content: z.string(),
        importance: z.enum(['critical', 'high', 'medium', 'low']).optional(),
        relatedMembers: z.array(z.number()).optional(),
        tags: z.array(z.string()).optional(),
        source: z.string(),
        confidence: z.number().optional(),
        validFrom: z.date().optional(),
        validUntil: z.date().optional(),
      }))
      .mutation(async ({ input }) => {
        return await householdMemoryService.storeMemory(input.householdId, {
          type: input.type as MemoryType,
          category: input.category,
          subject: input.subject,
          content: input.content,
          importance: input.importance as MemoryImportance | undefined,
          relatedMembers: input.relatedMembers,
          tags: input.tags,
          source: input.source,
          confidence: input.confidence,
          validFrom: input.validFrom,
          validUntil: input.validUntil,
        });
      }),

    recall: protectedProcedure
      .input(z.object({ memoryId: z.number() }))
      .query(async ({ input }) => {
        return await householdMemoryService.recallMemory(input.memoryId);
      }),

    search: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        type: z.enum(['fact', 'preference', 'event', 'relationship', 'routine', 'conflict', 'resolution']).optional(),
        category: z.string().optional(),
        tags: z.array(z.string()).optional(),
        memberId: z.number().optional(),
        keyword: z.string().optional(),
        importance: z.enum(['critical', 'high', 'medium', 'low']).optional(),
        limit: z.number().optional(),
      }))
      .query(async ({ input }) => {
        return await householdMemoryService.searchMemories(input.householdId, {
          type: input.type as MemoryType | undefined,
          category: input.category,
          tags: input.tags,
          memberId: input.memberId,
          keyword: input.keyword,
          importance: input.importance as MemoryImportance | undefined,
          limit: input.limit,
        });
      }),

    update: protectedProcedure
      .input(z.object({
        memoryId: z.number(),
        content: z.string().optional(),
        importance: z.enum(['critical', 'high', 'medium', 'low']).optional(),
        tags: z.array(z.string()).optional(),
        confidence: z.number().optional(),
        validUntil: z.date().optional(),
      }))
      .mutation(async ({ input }) => {
        const { memoryId, ...updates } = input;
        return await householdMemoryService.updateMemory(memoryId, {
          ...updates,
          importance: updates.importance as MemoryImportance | undefined,
        });
      }),

    forget: protectedProcedure
      .input(z.object({ memoryId: z.number() }))
      .mutation(async ({ input }) => {
        const success = await householdMemoryService.forgetMemory(input.memoryId);
        return { success };
      }),
  }),

  // Conflict Resolution
  conflicts: router({
    record: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        title: z.string(),
        description: z.string(),
        involvedMembers: z.array(z.number()),
        severity: z.enum(['minor', 'moderate', 'major']),
        category: z.string(),
        rootCause: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await householdMemoryService.recordConflict(input.householdId, input);
      }),

    get: protectedProcedure
      .input(z.object({ conflictId: z.number() }))
      .query(async ({ input }) => {
        return await householdMemoryService.getConflict(input.conflictId);
      }),

    list: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        status: z.enum(['active', 'mediating', 'resolved', 'escalated']).optional(),
      }))
      .query(async ({ input }) => {
        return await householdMemoryService.getConflicts(input.householdId, input.status as ConflictStatus | undefined);
      }),

    mediate: protectedProcedure
      .input(z.object({
        conflictId: z.number(),
        approach: z.string(),
        outcome: z.string(),
        success: z.boolean(),
      }))
      .mutation(async ({ input }) => {
        return await householdMemoryService.attemptMediation(input.conflictId, input.approach, input.outcome, input.success);
      }),

    resolve: protectedProcedure
      .input(z.object({
        conflictId: z.number(),
        approach: z.string(),
        outcome: z.string(),
        agreedBy: z.array(z.number()),
        preventionSuggestions: z.array(z.string()).optional(),
      }))
      .mutation(async ({ input }) => {
        return await householdMemoryService.resolveConflict(input.conflictId, input);
      }),
  }),

  // Context
  context: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ input }) => {
      return await householdMemoryService.getContextSnapshot(input.householdId);
    }),

  // Statistics
  statistics: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ input }) => {
      return await householdMemoryService.getStatistics(input.householdId);
    }),
});
