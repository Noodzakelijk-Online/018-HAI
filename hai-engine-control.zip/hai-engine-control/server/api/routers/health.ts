/**
 * Health Check API Router
 * Provides endpoints for monitoring system health and real-time metrics
 */

import { z } from 'zod';
import { publicProcedure, protectedProcedure, router } from '../../_core/trpc';
import healthCheck from '../../services/healthCheck';
import { metricsStreaming } from '../../services/metricsStreaming';
import { getRecentLogs, getLogStats } from '../../services/logger';
import { queryAuditLogs, getAuditStats } from '../../services/auditLog';
import { databaseBackup } from '../../services/databaseBackup';
import { alertNotifications } from '../../services/alertNotifications';

export const healthRouter = router({
  /**
   * Full system health check
   */
  system: publicProcedure.query(async () => {
    return healthCheck.getSystemHealth();
  }),

  /**
   * Quick liveness check (is the service running?)
   */
  liveness: publicProcedure.query(() => {
    return healthCheck.getLivenessCheck();
  }),

  /**
   * Readiness check (is the service ready to accept traffic?)
   */
  readiness: publicProcedure.query(async () => {
    return healthCheck.getReadinessCheck();
  }),

  /**
   * Get specific component health
   */
  component: publicProcedure
    .input(z.object({
      name: z.enum(['database', 'eventBus', 'memory', 'externalServices', 'storage']),
    }))
    .query(async ({ input }) => {
      const health = await healthCheck.getComponentHealth(input.name);
      if (!health) {
        throw new Error(`Unknown component: ${input.name}`);
      }
      return health;
    }),

  /**
   * Get health history
   */
  history: publicProcedure
    .input(z.object({
      limit: z.number().min(1).max(100).default(10),
    }).optional())
    .query(({ input }) => {
      const history = healthCheck.getHealthHistory();
      const limit = input?.limit ?? 10;
      return history.slice(-limit);
    }),

  /**
   * Get real-time metrics snapshot
   */
  metrics: protectedProcedure.query(() => {
    return metricsStreaming.getSnapshot();
  }),

  /**
   * Get metrics history
   */
  metricsHistory: protectedProcedure
    .input(z.object({
      limit: z.number().min(1).max(500).default(100),
    }).optional())
    .query(({ input }) => {
      const limit = input?.limit ?? 100;
      return metricsStreaming.getHistory(limit);
    }),

  /**
   * Get aggregated stats for a time period
   */
  aggregatedStats: protectedProcedure
    .input(z.object({
      periodMs: z.number().min(60000).max(86400000).default(3600000),
    }).optional())
    .query(({ input }) => {
      const periodMs = input?.periodMs ?? 3600000;
      return metricsStreaming.getAggregatedStats(periodMs);
    }),

  /**
   * Get recent system logs
   */
  logs: protectedProcedure
    .input(z.object({
      count: z.number().min(1).max(500).default(100),
      level: z.enum(['debug', 'info', 'warn', 'error', 'fatal']).optional(),
      service: z.string().optional(),
    }).optional())
    .query(({ input }) => {
      return getRecentLogs(input?.count ?? 100, {
        level: input?.level,
        service: input?.service,
      });
    }),

  /**
   * Get log statistics
   */
  logStats: protectedProcedure.query(() => {
    return getLogStats();
  }),

  /**
   * Get audit logs
   */
  auditLogs: protectedProcedure
    .input(z.object({
      limit: z.number().min(1).max(500).default(100),
      offset: z.number().min(0).default(0),
      action: z.string().optional(),
      severity: z.enum(['info', 'warning', 'critical']).optional(),
      userId: z.number().optional(),
      targetType: z.string().optional(),
    }).optional())
    .query(async ({ input }) => {
      return queryAuditLogs({
        limit: input?.limit ?? 100,
        offset: input?.offset ?? 0,
        action: input?.action as any,
        severity: input?.severity,
        userId: input?.userId,
        targetType: input?.targetType,
      });
    }),

  /**
   * Get audit statistics
   */
  auditStats: protectedProcedure.query(() => {
    return getAuditStats();
  }),

  /**
   * Get backup history
   */
  backups: protectedProcedure
    .input(z.object({
      status: z.enum(['pending', 'in_progress', 'completed', 'failed']).optional(),
      limit: z.number().min(1).max(100).default(20),
    }).optional())
    .query(({ input }) => {
      return databaseBackup.getBackups({
        status: input?.status,
        limit: input?.limit ?? 20,
      });
    }),

  /**
   * Get backup statistics
   */
  backupStats: protectedProcedure.query(() => {
    return databaseBackup.getStats();
  }),

  /**
   * Get backup schedule
   */
  backupSchedule: protectedProcedure.query(() => {
    return databaseBackup.getSchedule();
  }),

  /**
   * Trigger manual backup
   */
  createBackup: protectedProcedure.mutation(async () => {
    return databaseBackup.createBackup();
  }),

  /**
   * Get active alerts
   */
  alerts: protectedProcedure
    .input(z.object({
      severity: z.enum(['info', 'warning', 'critical']).optional(),
      acknowledged: z.boolean().optional(),
      limit: z.number().min(1).max(100).default(50),
    }).optional())
    .query(({ input }) => {
      return alertNotifications.getAlerts({
        severity: input?.severity,
        acknowledged: input?.acknowledged,
        limit: input?.limit ?? 50,
      });
    }),

  /**
   * Get alert statistics
   */
  alertStats: protectedProcedure.query(() => {
    return alertNotifications.getStats();
  }),

  /**
   * Get alert rules
   */
  alertRules: protectedProcedure.query(() => {
    return alertNotifications.getRules();
  }),

  /**
   * Acknowledge an alert
   */
  acknowledgeAlert: protectedProcedure
    .input(z.object({ alertId: z.string() }))
    .mutation(({ input, ctx }) => {
      return alertNotifications.acknowledgeAlert(input.alertId, ctx.user.id);
    }),
});

export default healthRouter;
