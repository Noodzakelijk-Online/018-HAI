/**
 * PILLAR 1: Decision Authority API Router
 * 
 * Exposes the Autonomous Action Engine, Override Mechanism,
 * Financial Logic Engine, and Authority Level Matrix via tRPC.
 */

import { z } from 'zod';
import { router, protectedProcedure, publicProcedure } from '../../_core/trpc';
import { autonomousActionEngine } from '../../services/pillar1/AutonomousActionEngine';
import { overrideMechanism } from '../../services/pillar1/OverrideMechanism';
import { financialLogicEngine } from '../../services/pillar1/FinancialLogicEngine';
import { authorityLevelMatrix } from '../../services/pillar1/AuthorityLevelMatrix';

// ============================================================================
// AUTONOMOUS ACTION ENGINE ROUTER
// ============================================================================

const actionRouter = router({
  // Create a new action
  create: protectedProcedure
    .input(z.object({
      actionType: z.string(),
      actionCategory: z.enum(['communication', 'financial', 'scheduling', 'household', 'health', 'security', 'maintenance', 'social']),
      targetService: z.string(),
      targetResourceId: z.string().optional(),
      actionPayload: z.record(z.any()),
      actionDescription: z.string(),
      confidenceScore: z.number().min(0).max(1),
      priorityScore: z.number().min(0).max(100).optional(),
      scheduledAt: z.date().optional(),
      householdId: z.number(),
      triggeredByMemberId: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      return autonomousActionEngine.createAction(input);
    }),

  // Execute an action
  execute: protectedProcedure
    .input(z.object({ actionId: z.number() }))
    .mutation(async ({ input }) => {
      return autonomousActionEngine.executeAction(input.actionId);
    }),

  // Cancel an action
  cancel: protectedProcedure
    .input(z.object({
      actionId: z.number(),
      reason: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      return autonomousActionEngine.cancelAction(input.actionId, input.reason);
    }),

  // Rollback an action
  rollback: protectedProcedure
    .input(z.object({
      actionId: z.number(),
      reason: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      return autonomousActionEngine.rollbackAction(input.actionId, input.reason);
    }),

  // Get action by ID
  get: protectedProcedure
    .input(z.object({ actionId: z.number() }))
    .query(async ({ input }) => {
      return autonomousActionEngine.getAction(input.actionId);
    }),

  // Get household actions
  list: protectedProcedure
    .input(z.object({
      householdId: z.number(),
      status: z.enum(['pending', 'executing', 'completed', 'failed', 'cancelled', 'overridden', 'rolled_back']).optional(),
      category: z.enum(['communication', 'financial', 'scheduling', 'household', 'health', 'security', 'maintenance', 'social']).optional(),
      limit: z.number().min(1).max(100).optional(),
      offset: z.number().min(0).optional(),
    }))
    .query(async ({ input }) => {
      return autonomousActionEngine.getHouseholdActions(input.householdId, {
        status: input.status,
        category: input.category,
        limit: input.limit,
        offset: input.offset,
      });
    }),

  // Get pending actions
  pending: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ input }) => {
      return autonomousActionEngine.getPendingActions(input.householdId);
    }),

  // Get action feed
  feed: protectedProcedure
    .input(z.object({
      householdId: z.number(),
      limit: z.number().min(1).max(50).optional(),
    }))
    .query(async ({ input }) => {
      return autonomousActionEngine.getActionFeed(input.householdId, input.limit);
    }),

  // Get action logs
  logs: protectedProcedure
    .input(z.object({ actionId: z.number() }))
    .query(async ({ input }) => {
      return autonomousActionEngine.getActionLogs(input.actionId);
    }),

  // Get statistics
  statistics: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ input }) => {
      return autonomousActionEngine.getStatistics(input.householdId);
    }),
});

// ============================================================================
// OVERRIDE MECHANISM ROUTER
// ============================================================================

const overrideRouter = router({
  // Execute an override
  execute: protectedProcedure
    .input(z.object({
      actionId: z.number(),
      overriddenByUserId: z.number(),
      overriddenByMemberId: z.number().optional(),
      overrideType: z.enum(['cancel', 'modify', 'rollback', 'emergency_stop', 'redirect']),
      overrideReason: z.string().optional(),
      modifiedPayload: z.record(z.any()).optional(),
      shouldLearnFrom: z.boolean().optional(),
    }))
    .mutation(async ({ input }) => {
      return overrideMechanism.executeOverride(input);
    }),

  // Get override patterns
  patterns: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ input }) => {
      return overrideMechanism.getPatterns(input.householdId);
    }),

  // Update a pattern
  updatePattern: protectedProcedure
    .input(z.object({
      patternId: z.number(),
      suggestedBehavior: z.enum(['always_ask', 'lower_confidence', 'add_delay', 'notify_first', 'skip']).optional(),
      isActive: z.boolean().optional(),
      confidenceAdjustment: z.number().min(-0.5).max(0.5).optional(),
    }))
    .mutation(async ({ input }) => {
      const { patternId, ...updates } = input;
      return overrideMechanism.updatePattern(patternId, updates);
    }),

  // Delete a pattern
  deletePattern: protectedProcedure
    .input(z.object({ patternId: z.number() }))
    .mutation(async ({ input }) => {
      return overrideMechanism.deletePattern(input.patternId);
    }),

  // Get override history
  history: protectedProcedure
    .input(z.object({
      householdId: z.number(),
      limit: z.number().min(1).max(100).optional(),
      offset: z.number().min(0).optional(),
    }))
    .query(async ({ input }) => {
      return overrideMechanism.getOverrideHistory(input.householdId, {
        limit: input.limit,
        offset: input.offset,
      });
    }),

  // Get statistics
  statistics: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ input }) => {
      return overrideMechanism.getOverrideStatistics(input.householdId);
    }),

  // Check if action should be blocked
  checkBlock: protectedProcedure
    .input(z.object({
      householdId: z.number(),
      actionType: z.string(),
      actionCategory: z.string(),
      memberId: z.number().optional(),
    }))
    .query(async ({ input }) => {
      return overrideMechanism.shouldBlockAction(
        input.householdId,
        input.actionType,
        input.actionCategory,
        input.memberId
      );
    }),
});

// ============================================================================
// FINANCIAL LOGIC ENGINE ROUTER
// ============================================================================

const financialRouter = router({
  // Evaluate a payment
  evaluatePayment: protectedProcedure
    .input(z.object({
      householdId: z.number(),
      transaction: z.object({
        id: z.string(),
        vendorName: z.string(),
        amount: z.number(),
        category: z.string().optional(),
        timestamp: z.date(),
        location: z.string().optional(),
        paymentMethod: z.string().optional(),
        metadata: z.record(z.any()).optional(),
      }),
    }))
    .mutation(async ({ input }) => {
      return financialLogicEngine.evaluatePayment(input.householdId, input.transaction);
    }),

  // Create a financial rule
  createRule: protectedProcedure
    .input(z.object({
      householdId: z.number(),
      ruleName: z.string(),
      ruleDescription: z.string().optional(),
      ruleType: z.enum(['auto_approve_threshold', 'vendor_trust', 'category_limit', 'recurring_bill', 'anomaly_threshold', 'time_based']),
      vendorName: z.string().optional(),
      category: z.string().optional(),
      maxAmount: z.number().optional(),
      minAmount: z.number().optional(),
      vendorTrustScore: z.number().min(0).max(1).optional(),
      autoApproveConfidence: z.number().min(0).max(1).optional(),
      validFromTime: z.string().optional(),
      validToTime: z.string().optional(),
      validDays: z.array(z.number().min(0).max(6)).optional(),
      requiresApproval: z.boolean(),
      notifyOnExecution: z.boolean(),
      priority: z.number().min(0).max(100),
    }))
    .mutation(async ({ input }) => {
      const { householdId, ...data } = input;
      return financialLogicEngine.createRule(householdId, data);
    }),

  // Get rules
  rules: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ input }) => {
      return financialLogicEngine.getRules(input.householdId);
    }),

  // Update a rule
  updateRule: protectedProcedure
    .input(z.object({
      ruleId: z.number(),
      updates: z.record(z.any()),
    }))
    .mutation(async ({ input }) => {
      return financialLogicEngine.updateRule(input.ruleId, input.updates);
    }),

  // Delete a rule
  deleteRule: protectedProcedure
    .input(z.object({ ruleId: z.number() }))
    .mutation(async ({ input }) => {
      return financialLogicEngine.deleteRule(input.ruleId);
    }),

  // Register recurring bill
  registerBill: protectedProcedure
    .input(z.object({
      householdId: z.number(),
      vendorName: z.string(),
      vendorId: z.string().optional(),
      category: z.string().optional(),
      expectedAmount: z.number(),
      amountVarianceThreshold: z.number().optional(),
      frequency: z.enum(['weekly', 'biweekly', 'monthly', 'quarterly', 'annually']),
      expectedDay: z.number().optional(),
      nextExpectedDate: z.date().optional(),
      autoPayEnabled: z.boolean(),
      paymentMethodId: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const { householdId, ...data } = input;
      return financialLogicEngine.registerRecurringBill(householdId, data);
    }),

  // Get upcoming bills
  upcomingBills: protectedProcedure
    .input(z.object({
      householdId: z.number(),
      daysAhead: z.number().min(1).max(90).optional(),
    }))
    .query(async ({ input }) => {
      return financialLogicEngine.getUpcomingBills(input.householdId, input.daysAhead);
    }),

  // Record bill payment
  recordPayment: protectedProcedure
    .input(z.object({
      billId: z.number(),
      amount: z.number(),
    }))
    .mutation(async ({ input }) => {
      return financialLogicEngine.recordBillPayment(input.billId, input.amount);
    }),

  // Resolve anomaly
  resolveAnomaly: protectedProcedure
    .input(z.object({
      anomalyId: z.number(),
      status: z.enum(['detected', 'reviewing', 'confirmed_fraud', 'false_positive', 'resolved']),
      resolvedByUserId: z.number(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      return financialLogicEngine.resolveAnomaly(
        input.anomalyId,
        input.status,
        input.resolvedByUserId,
        input.notes
      );
    }),

  // Get statistics
  statistics: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ input }) => {
      return financialLogicEngine.getStatistics(input.householdId);
    }),
});

// ============================================================================
// AUTHORITY LEVEL MATRIX ROUTER
// ============================================================================

const authorityRouter = router({
  // Check authority
  check: protectedProcedure
    .input(z.object({
      householdId: z.number(),
      memberId: z.number(),
      actionType: z.string(),
      actionCategory: z.string().optional(),
      context: z.record(z.any()).optional(),
    }))
    .query(async ({ input }) => {
      return authorityLevelMatrix.checkAuthority(
        input.householdId,
        input.memberId,
        input.actionType,
        input.actionCategory,
        input.context
      );
    }),

  // Get authority levels
  levels: publicProcedure.query(async () => {
    return authorityLevelMatrix.getAuthorityLevels();
  }),

  // Assign authority
  assign: protectedProcedure
    .input(z.object({
      householdId: z.number(),
      memberId: z.number(),
      authorityLevelId: z.number(),
      delegatedByMemberId: z.number().optional(),
      delegationExpires: z.date().optional(),
    }))
    .mutation(async ({ input }) => {
      return authorityLevelMatrix.assignAuthority(
        input.householdId,
        input.memberId,
        input.authorityLevelId,
        input.delegatedByMemberId,
        input.delegationExpires
      );
    }),

  // Delegate authority
  delegate: protectedProcedure
    .input(z.object({
      householdId: z.number(),
      fromMemberId: z.number(),
      toMemberId: z.number(),
      durationMinutes: z.number().min(1).max(10080), // Max 1 week
    }))
    .mutation(async ({ input }) => {
      return authorityLevelMatrix.delegateAuthority(
        input.householdId,
        input.fromMemberId,
        input.toMemberId,
        input.durationMinutes
      );
    }),

  // Revoke delegation
  revokeDelegation: protectedProcedure
    .input(z.object({ assignmentId: z.number() }))
    .mutation(async ({ input }) => {
      return authorityLevelMatrix.revokeDelegation(input.assignmentId);
    }),

  // Create escalation
  createEscalation: protectedProcedure
    .input(z.object({
      actionId: z.number(),
      fromLevel: z.number(),
      toLevel: z.number(),
      reason: z.string(),
      expiresInMinutes: z.number().min(1).max(1440).optional(), // Max 24 hours
    }))
    .mutation(async ({ input }) => {
      return authorityLevelMatrix.createEscalation(
        input.actionId,
        input.fromLevel,
        input.toLevel,
        input.reason,
        input.expiresInMinutes
      );
    }),

  // Resolve escalation
  resolveEscalation: protectedProcedure
    .input(z.object({
      escalationId: z.number(),
      approved: z.boolean(),
      resolvedByMemberId: z.number(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      return authorityLevelMatrix.resolveEscalation(
        input.escalationId,
        input.approved,
        input.resolvedByMemberId,
        input.notes
      );
    }),

  // Get pending escalations
  pendingEscalations: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ input }) => {
      return authorityLevelMatrix.getPendingEscalations(input.householdId);
    }),

  // Get requirements
  requirements: publicProcedure.query(async () => {
    return authorityLevelMatrix.getRequirements();
  }),

  // Get statistics
  statistics: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ input }) => {
      return authorityLevelMatrix.getStatistics(input.householdId);
    }),
});

// ============================================================================
// COMBINED PILLAR 1 ROUTER
// ============================================================================

export const pillar1Router = router({
  action: actionRouter,
  override: overrideRouter,
  financial: financialRouter,
  authority: authorityRouter,
});
