/**
 * PILLAR 4 API ROUTER
 * 
 * "Anticipates, Doesn't Just React"
 * 
 * Exposes APIs for:
 * - Confidence Scoring
 * - Anticipatory Actions
 * - Trust Building
 */

import { z } from 'zod';
import { router, protectedProcedure } from '../../_core/trpc';
import { confidenceScoringService, type ConfidenceLevel } from '../../services/pillar4/ConfidenceScoring';
import { anticipatoryActionsService, type AnticipationType, type AnticipationPriority, type AnticipationStatus } from '../../services/pillar4/AnticipatoryActions';

// ============================================================================
// ROUTER
// ============================================================================

export const pillar4Router = router({
  // ============================================================================
  // CONFIDENCE SCORING
  // ============================================================================
  
  confidence: router({
    // Calculate confidence score
    calculate: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        actionType: z.string(),
        factors: z.object({
          patternStrength: z.number().min(0).max(1).optional(),
          successRate: z.number().min(0).max(1).optional(),
          observationCount: z.number().optional(),
          contextMatch: z.number().min(0).max(1).optional(),
          timeRelevance: z.number().min(0).max(1).optional(),
          memberPreference: z.number().min(0).max(1).optional(),
          reversibility: z.number().min(0).max(1).optional(),
          financialImpact: z.number().min(0).max(1).optional(),
          privacyRisk: z.number().min(0).max(1).optional(),
          recentOverrides: z.number().min(0).max(1).optional(),
          explicitApproval: z.number().min(0).max(1).optional(),
        }),
        context: z.record(z.any()).optional(),
      }))
      .mutation(async ({ input }) => {
        return await confidenceScoringService.calculateScore(
          input.householdId,
          input.actionType,
          input.factors,
          input.context
        );
      }),

    // Get a score by ID
    get: protectedProcedure
      .input(z.object({ scoreId: z.number() }))
      .query(async ({ input }) => {
        return await confidenceScoringService.getScore(input.scoreId);
      }),

    // Get recent scores
    recent: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        limit: z.number().optional(),
      }))
      .query(async ({ input }) => {
        return await confidenceScoringService.getRecentScores(input.householdId, input.limit);
      }),

    // Record outcome
    recordOutcome: protectedProcedure
      .input(z.object({
        scoreId: z.number(),
        outcome: z.enum(['success', 'failure', 'overridden', 'cancelled']),
        feedback: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await confidenceScoringService.recordOutcome(input.scoreId, input.outcome, input.feedback);
        return { success: true };
      }),

    // Get history
    history: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        actionType: z.string().optional(),
        limit: z.number().optional(),
      }))
      .query(async ({ input }) => {
        return await confidenceScoringService.getHistory(
          input.householdId,
          input.actionType,
          input.limit
        );
      }),

    // Get thresholds
    thresholds: protectedProcedure
      .input(z.object({ actionType: z.string() }))
      .query(async ({ input }) => {
        return confidenceScoringService.getThresholds(input.actionType);
      }),

    // Set thresholds
    setThresholds: protectedProcedure
      .input(z.object({
        actionType: z.string(),
        executeThreshold: z.number().min(0).max(1).optional(),
        suggestThreshold: z.number().min(0).max(1).optional(),
        askThreshold: z.number().min(0).max(1).optional(),
      }))
      .mutation(async ({ input }) => {
        const { actionType, ...thresholds } = input;
        confidenceScoringService.setThresholds(actionType, thresholds);
        return { success: true };
      }),

    // Get statistics
    statistics: protectedProcedure
      .input(z.object({ householdId: z.number() }))
      .query(async ({ input }) => {
        return await confidenceScoringService.getStatistics(input.householdId);
      }),
  }),

  // ============================================================================
  // ANTICIPATORY ACTIONS
  // ============================================================================
  
  anticipation: router({
    // Create anticipation
    create: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        type: z.enum([
          'schedule_conflict', 'bill_due', 'maintenance_needed', 'supply_low',
          'appointment_reminder', 'travel_preparation', 'weather_alert',
          'health_reminder', 'social_event', 'opportunity'
        ]),
        title: z.string(),
        description: z.string(),
        anticipatedAt: z.date(),
        leadTime: z.number(),
        confidenceScore: z.number().min(0).max(1),
        predictionBasis: z.array(z.string()),
        suggestedAction: z.object({
          type: z.string(),
          description: z.string(),
          parameters: z.record(z.any()),
          estimatedDuration: z.number(),
          estimatedCost: z.number().optional(),
        }),
        priority: z.enum(['critical', 'high', 'medium', 'low']).optional(),
        memberId: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const { householdId, ...data } = input;
        return await anticipatoryActionsService.createAnticipation(householdId, {
          ...data,
          type: data.type as AnticipationType,
          priority: data.priority as AnticipationPriority | undefined,
        });
      }),

    // Get anticipation by ID
    get: protectedProcedure
      .input(z.object({ actionId: z.number() }))
      .query(async ({ input }) => {
        return await anticipatoryActionsService.getAnticipation(input.actionId);
      }),

    // Get pending anticipations
    pending: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        type: z.enum([
          'schedule_conflict', 'bill_due', 'maintenance_needed', 'supply_low',
          'appointment_reminder', 'travel_preparation', 'weather_alert',
          'health_reminder', 'social_event', 'opportunity'
        ]).optional(),
        priority: z.enum(['critical', 'high', 'medium', 'low']).optional(),
        limit: z.number().optional(),
      }))
      .query(async ({ input }) => {
        return await anticipatoryActionsService.getPendingAnticipations(input.householdId, {
          type: input.type as AnticipationType | undefined,
          priority: input.priority as AnticipationPriority | undefined,
          limit: input.limit,
        });
      }),

    // Update status
    updateStatus: protectedProcedure
      .input(z.object({
        actionId: z.number(),
        status: z.enum(['predicted', 'confirmed', 'acted', 'dismissed', 'expired']),
        actionTaken: z.string().optional(),
        outcome: z.enum(['helpful', 'unnecessary', 'wrong', 'too_late']).optional(),
        feedback: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await anticipatoryActionsService.updateStatus(
          input.actionId,
          input.status as AnticipationStatus,
          {
            actionTaken: input.actionTaken,
            outcome: input.outcome,
            feedback: input.feedback,
          }
        );
      }),

    // Run predictions
    runPredictions: protectedProcedure
      .input(z.object({
        householdId: z.number(),
        context: z.object({
          currentTime: z.date(),
          upcomingEvents: z.array(z.object({
            type: z.string(),
            date: z.date(),
            data: z.any(),
          })),
          recurringItems: z.array(z.object({
            type: z.string(),
            nextDue: z.date(),
            data: z.any(),
          })),
          conditions: z.record(z.any()),
        }),
      }))
      .mutation(async ({ input }) => {
        return await anticipatoryActionsService.runPredictions(input.householdId, input.context);
      }),

    // Get active patterns
    patterns: protectedProcedure
      .input(z.object({ householdId: z.number() }))
      .query(async ({ input }) => {
        return await anticipatoryActionsService.getActivePatterns(input.householdId);
      }),

    // Get statistics
    statistics: protectedProcedure
      .input(z.object({ householdId: z.number() }))
      .query(async ({ input }) => {
        return await anticipatoryActionsService.getStatistics(input.householdId);
      }),
  }),

  // ============================================================================
  // COMBINED STATISTICS
  // ============================================================================
  
  statistics: protectedProcedure
    .input(z.object({ householdId: z.number() }))
    .query(async ({ input }) => {
      const [confidenceStats, anticipationStats] = await Promise.all([
        confidenceScoringService.getStatistics(input.householdId),
        anticipatoryActionsService.getStatistics(input.householdId),
      ]);

      return {
        confidence: confidenceStats,
        anticipation: anticipationStats,
        summary: {
          totalScores: confidenceStats.totalScores,
          avgConfidence: confidenceStats.avgScore,
          successRate: confidenceStats.successRate,
          pendingAnticipations: anticipationStats.pendingCount,
          helpfulRate: anticipationStats.helpfulRate,
          patternAccuracy: anticipationStats.patternAccuracy,
        },
      };
    }),
});
