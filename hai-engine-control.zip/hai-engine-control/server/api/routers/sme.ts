import { z } from "zod";
import { protectedProcedure, router } from "../../_core/trpc";
import { SelfModelEngine } from "../../services/SelfModelEngine";
import { getDb } from "../../db";
import { messages } from "../../../drizzle/schema";
import { eq } from "drizzle-orm";

export const smeRouter = router({
  /**
   * Get user profile with all learned traits
   */
  getProfile: protectedProcedure.query(async ({ ctx }) => {
    const profile = await SelfModelEngine.getUserProfile(ctx.user.id);
    return profile;
  }),

  /**
   * Learn traits from a specific conversation
   */
  learnFromConversation: protectedProcedure
    .input(z.object({ conversationId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new Error('Database not available');
      }

      // Get conversation messages
      const conversationMessages = await db
        .select()
        .from(messages)
        .where(eq(messages.conversationId, input.conversationId))
        .orderBy(messages.createdAt);

      if (conversationMessages.length === 0) {
        return { traits: [], message: 'No messages found in conversation' };
      }

      // Learn from conversation
      const traits = await SelfModelEngine.learnFromConversation({
        userId: ctx.user.id,
        conversationId: input.conversationId,
        messages: conversationMessages.map(m => ({
          role: m.role,
          content: m.content,
        })),
      });

      return {
        traits,
        message: `Learned ${traits.length} traits from conversation`,
      };
    }),

  /**
   * Manually add a trait
   */
  addTrait: protectedProcedure
    .input(
      z.object({
        traitType: z.string(),
        traitValue: z.string(),
        confidence: z.number().min(0).max(100).optional(),
        context: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const trait = await SelfModelEngine.storeTrait({
        userId: ctx.user.id,
        traitType: input.traitType,
        traitValue: input.traitValue,
        confidence: input.confidence || 80,
        context: input.context || 'Manually added by user',
      });

      return trait;
    }),

  /**
   * Update trait confidence (reinforce or weaken)
   */
  updateTraitConfidence: protectedProcedure
    .input(
      z.object({
        traitId: z.number(),
        reinforcement: z.number().min(-100).max(100),
      })
    )
    .mutation(async ({ input }) => {
      const success = await SelfModelEngine.updateTraitConfidence({
        traitId: input.traitId,
        reinforcement: input.reinforcement,
      });

      return { success };
    }),

  /**
   * Delete a trait
   */
  deleteTrait: protectedProcedure
    .input(z.object({ traitId: z.number() }))
    .mutation(async ({ input }) => {
      const success = await SelfModelEngine.deleteTrait(input.traitId);
      return { success };
    }),

  /**
   * Detect patterns in user behavior
   */
  detectPatterns: protectedProcedure.query(async ({ ctx }) => {
    const patterns = await SelfModelEngine.detectPatterns(ctx.user.id);
    return patterns;
  }),

  /**
   * Get trait recommendations
   */
  getRecommendations: protectedProcedure.query(async ({ ctx }) => {
    const recommendations = await SelfModelEngine.getTraitRecommendations(ctx.user.id);
    return recommendations;
  }),

  /**
   * Get profile summary for display
   */
  getProfileSummary: protectedProcedure.query(async ({ ctx }) => {
    const profile = await SelfModelEngine.getUserProfile(ctx.user.id);
    
    if (!profile) {
      return {
        summary: 'No profile data yet. Start chatting with HAI to build your profile!',
        completeness: 0,
        confidence: 0,
        traitCount: 0,
      };
    }

    const topTraits = profile.traits
      .sort((a, b) => b.confidence - a.confidence)
      .slice(0, 5)
      .map(t => `${t.traitType}: ${t.traitValue} (${t.confidence}% confident)`);

    return {
      summary: `HAI has learned ${profile.traits.length} traits about you across ${Object.keys(profile.traitsByCategory).length} categories.`,
      completeness: profile.completeness,
      confidence: profile.overallConfidence,
      traitCount: profile.traits.length,
      topTraits,
      lastUpdated: profile.lastUpdated,
    };
  }),
});
